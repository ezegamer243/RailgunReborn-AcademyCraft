package com.railgunreborn;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.IModBusEvent;

/**
 * Cada {@code @SubscribeEvent} tiene que estar en el bus de su evento: un evento del bus del mod en una clase del bus
 * del juego (o al revés) hace fallar el arranque, y los GameTests no cargan el cliente, así que no lo ven.
 */
class EventBusSubscriberTest {
    /** Las clases compiladas del mod; los tests corren en {@code build/minecraft-junit}, se busca hacia arriba. */
    private static final Path CLASSES = findClasses();
    private static final String COMPAT_PACKAGE = "com.railgunreborn.compat.";

    private static Path findClasses() {
        Path relative = Path.of("build", "classes", "java", "main");
        for (Path dir = Path.of("").toAbsolutePath(); dir != null; dir = dir.getParent()) {
            if (Files.isDirectory(dir.resolve(relative).resolve("com").resolve("railgunreborn"))) {
                return dir.resolve(relative);
            }
        }
        return relative;
    }

    @Test
    void subscribersUseTheBusOfTheirEvents() throws IOException {
        List<String> wrong = new ArrayList<>();
        for (Class<?> type : modClasses()) {
            EventBusSubscriber subscriber = type.getAnnotation(EventBusSubscriber.class);
            if (subscriber == null) {
                continue;
            }
            @SuppressWarnings("removal")
            boolean modBus = subscriber.bus() == EventBusSubscriber.Bus.MOD;
            for (Method method : type.getDeclaredMethods()) {
                if (!method.isAnnotationPresent(SubscribeEvent.class) || method.getParameterCount() != 1) {
                    continue;
                }
                boolean modEvent = IModBusEvent.class.isAssignableFrom(method.getParameterTypes()[0]);
                if (modEvent != modBus) {
                    wrong.add(type.getName() + "#" + method.getName() + " ("
                            + method.getParameterTypes()[0].getSimpleName() + ", bus " + (modBus ? "MOD" : "GAME")
                            + ")");
                }
            }
        }
        assertTrue(wrong.isEmpty(), "Eventos en el bus equivocado: " + wrong);
    }

    private static List<Class<?>> modClasses() throws IOException {
        Path root = CLASSES.resolve("com").resolve("railgunreborn");
        assertTrue(Files.isDirectory(root), "No se encuentran las clases compiladas en " + root.toAbsolutePath());
        List<Class<?>> classes = new ArrayList<>();
        try (Stream<Path> files = Files.walk(root)) {
            for (Path file : (Iterable<Path>) files.filter(p -> p.toString().endsWith(".class"))::iterator) {
                String name = CLASSES.relativize(file).toString().replace('\\', '.').replace('/', '.');
                name = name.substring(0, name.length() - ".class".length());
                // compat/: plugins de mods opcionales (JEI) cuya API es compileOnly y no está en el classpath de los
                // tests; cargarlos daría NoClassDefFoundError. No usan @EventBusSubscriber (los carga el otro mod).
                if (name.startsWith(COMPAT_PACKAGE)) {
                    continue;
                }
                try {
                    classes.add(Class.forName(name, false, EventBusSubscriberTest.class.getClassLoader()));
                } catch (ClassNotFoundException e) {
                    throw new IllegalStateException(name, e);
                }
            }
        }
        return classes;
    }
}
