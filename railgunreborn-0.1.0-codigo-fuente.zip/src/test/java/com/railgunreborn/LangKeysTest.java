package com.railgunreborn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.jupiter.api.Test;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/** Los textos de energía (JEI y tooltips, T107) existen en inglés y en español, y los dos idiomas tienen las mismas claves. */
class LangKeysTest {
    private static final List<String> ENERGY_KEYS = List.of(
            "jei.railgunreborn.energy",
            "jei.railgunreborn.info.solar_gen",
            "jei.railgunreborn.info.phase_gen",
            "jei.railgunreborn.info.windgen",
            "jei.railgunreborn.info.cat_engine",
            "jei.railgunreborn.info.matrix",
            "jei.railgunreborn.info.node",
            "jei.railgunreborn.info.energy_unit",
            "jei.railgunreborn.info.developer",
            "tooltip.railgunreborn.energy.produces",
            "tooltip.railgunreborn.energy.produces_range",
            "tooltip.railgunreborn.energy.consumes",
            "tooltip.railgunreborn.energy.per_stim",
            "tooltip.railgunreborn.energy.node",
            "tooltip.railgunreborn.energy.needs");

    private static JsonObject load(String lang) throws IOException {
        Path relative = Path.of("src", "main", "resources", "assets", "railgunreborn", "lang", lang + ".json");
        for (Path dir = Path.of("").toAbsolutePath(); dir != null; dir = dir.getParent()) {
            if (Files.isRegularFile(dir.resolve(relative))) {
                try (Reader reader = Files.newBufferedReader(dir.resolve(relative), StandardCharsets.UTF_8)) {
                    return JsonParser.parseReader(reader).getAsJsonObject();
                }
            }
        }
        throw new IOException("No se encontró " + relative);
    }

    @Test
    void energyKeysExistInBothLanguages() throws IOException {
        JsonObject en = load("en_us");
        JsonObject es = load("es_es");
        for (String key : ENERGY_KEYS) {
            assertTrue(en.has(key) && !en.get(key).getAsString().isBlank(), "Falta en en_us: " + key);
            assertTrue(es.has(key) && !es.get(key).getAsString().isBlank(), "Falta en es_es: " + key);
        }
    }

    @Test
    void bothLanguagesHaveTheSameKeys() throws IOException {
        Set<String> en = new TreeSet<>(load("en_us").keySet());
        Set<String> es = new TreeSet<>(load("es_es").keySet());
        Set<String> onlyEn = new TreeSet<>(en);
        onlyEn.removeAll(es);
        Set<String> onlyEs = new TreeSet<>(es);
        onlyEs.removeAll(en);
        assertEquals(Set.of(), onlyEn, "Solo en inglés");
        assertEquals(Set.of(), onlyEs, "Solo en español");
    }
}
