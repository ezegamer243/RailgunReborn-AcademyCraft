package com.railgunreborn.ability.vecmanip;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha blood-retro §9 y decisiones del usuario. */
class BloodRetroRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void referenceValues() {
        assertEquals(280f, BloodRetroRules.cp(0f), EPS);
        assertEquals(315f, BloodRetroRules.cp(0.5f), EPS);
        assertEquals(350f, BloodRetroRules.cp(1f), EPS);
        assertEquals(55f, BloodRetroRules.overload(0f), EPS);
        assertEquals(47.5f, BloodRetroRules.overload(0.5f), EPS);
        assertEquals(40f, BloodRetroRules.overload(1f), EPS);
        assertEquals(90, BloodRetroRules.cooldownTicks(0f));
        assertEquals(65, BloodRetroRules.cooldownTicks(0.5f));
        assertEquals(40, BloodRetroRules.cooldownTicks(1f));
        assertEquals(30f, BloodRetroRules.damage(0f), EPS);
        assertEquals(45f, BloodRetroRules.damage(0.5f), EPS);
        assertEquals(60f, BloodRetroRules.damage(1f), EPS);
    }

    @Test
    void slowdownCurve() {
        assertEquals(0.0, BloodRetroRules.slowAmount(0), 1e-9);
        assertEquals(-0.465, BloodRetroRules.slowAmount(10), 1e-9);
        assertEquals(-0.93, BloodRetroRules.slowAmount(20), 1e-9);
        assertEquals(-0.93, BloodRetroRules.slowAmount(30), 1e-9);
        assertEquals(0.0, BloodRetroRules.slowAmount(-5), 1e-9);
    }

    @Test
    void autoReleaseAtThirtyTicks() {
        assertFalse(BloodRetroRules.autoReleases(29));
        assertTrue(BloodRetroRules.autoReleases(30));
    }

    @Test
    void bloodIsSmallerThanTheOriginal() {
        assertTrue(BloodRetroRules.BLOOD_MIN == 4 && BloodRetroRules.BLOOD_MAX == 6);
        assertEquals(0.7f, BloodRetroRules.BLOOD_SIZE_MIN, EPS);
        assertEquals(1.1f, BloodRetroRules.BLOOD_SIZE_MAX, EPS);
        assertEquals(0.5f, BloodRetroRules.SOUND_VOLUME, EPS);
    }
}
