package com.railgunreborn.ability.vecmanip;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha dir-shock §11 y la dirección corregida del empuje. */
class DirShockRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void referenceValues() {
        assertEquals(50f, DirShockRules.cp(0f), EPS);
        assertEquals(75f, DirShockRules.cp(0.5f), EPS);
        assertEquals(100f, DirShockRules.cp(1f), EPS);
        assertEquals(18f, DirShockRules.overload(0f), EPS);
        assertEquals(15f, DirShockRules.overload(0.5f), EPS);
        assertEquals(12f, DirShockRules.overload(1f), EPS);
        assertEquals(60, DirShockRules.cooldownTicks(0f));
        assertEquals(40, DirShockRules.cooldownTicks(0.5f));
        assertEquals(20, DirShockRules.cooldownTicks(1f));
        assertEquals(7f, DirShockRules.damage(0f), EPS);
        assertEquals(11f, DirShockRules.damage(0.5f), EPS);
        assertEquals(15f, DirShockRules.damage(1f), EPS);
    }

    @Test
    void knockbackThreshold() {
        assertFalse(DirShockRules.knockbackEnabled(0.24f));
        assertTrue(DirShockRules.knockbackEnabled(0.25f));
    }

    @Test
    void holdWindow() {
        assertFalse(DirShockRules.holdAccepted(6));
        assertTrue(DirShockRules.holdAccepted(7));
        assertTrue(DirShockRules.holdAccepted(49));
        assertFalse(DirShockRules.holdAccepted(50));
        // El servidor da 2 ticks de margen por cada lado.
        assertFalse(DirShockRules.serverHoldAccepted(4));
        assertTrue(DirShockRules.serverHoldAccepted(5));
        assertTrue(DirShockRules.serverHoldAccepted(51));
        assertFalse(DirShockRules.serverHoldAccepted(52));
    }

    @Test
    void strongPushGoesOutwardInEveryDirection() {
        double[] zero = {0, 0, 0};
        double[][] directions = {{0, 0, 1}, {0, 0, -1}, {1, 0, 0}, {-1, 0, 0}, {0.6, 0, -0.8}};
        for (double[] d : directions) {
            double[] head = {d[0] * 2, 1.6 + d[1] * 2, d[2] * 2};
            double[] v = DirShockRules.knockbackVelocity(new double[] {0, 1.6, 0}, head, zero, new double[] {
                    d[0] * 2, 0, d[2] * 2}, zero, 1f);
            // Hacia fuera (el signo de Z era el error del original) y algo hacia arriba.
            assertTrue(v[0] * d[0] + v[2] * d[2] > 0.5, "outward for " + d[0] + "," + d[2]);
            assertTrue(v[1] > 0);
        }
    }

    @Test
    void strongPushReplacesVelocityAndBasicPushAdds() {
        double[] zero = {0, 0, 0};
        double[] current = {5, 5, 5};
        double[] feet = {0, 0, 2};
        double[] strong = DirShockRules.knockbackVelocity(zero, new double[] {0, 0, 2}, zero, feet, current, 1f);
        // 0.7 * normalizar((0, 0.6, 2)) + 0.24 * (0, 0, 1)
        double len = Math.sqrt(0.36 + 4);
        assertEquals(0.0, strong[0], 1e-9);
        assertEquals(0.7 * 0.6 / len, strong[1], 1e-9);
        assertEquals(0.7 * 2 / len + 0.24, strong[2], 1e-9);
        double[] weak = DirShockRules.knockbackVelocity(zero, new double[] {0, 0, 2}, zero, feet, current, 0.1f);
        assertEquals(5.0, weak[0], 1e-9);
        assertEquals(5.0, weak[1], 1e-9);
        assertEquals(5.24, weak[2], 1e-9);
    }

    @Test
    void zeroDistanceDoesNotProduceNaN() {
        double[] zero = {0, 0, 0};
        double[] v = DirShockRules.knockbackVelocity(zero, zero, zero, zero, zero, 0f);
        assertEquals(0.0, v[0] + v[1] + v[2], 1e-9);
    }
}
