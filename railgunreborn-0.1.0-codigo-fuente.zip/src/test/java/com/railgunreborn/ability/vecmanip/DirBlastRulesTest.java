package com.railgunreborn.ability.vecmanip;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha dir-blast §11 y decisiones del usuario. */
class DirBlastRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void referenceValues() {
        assertEquals(160f, DirBlastRules.cp(0f), EPS);
        assertEquals(180f, DirBlastRules.cp(0.5f), EPS);
        assertEquals(200f, DirBlastRules.cp(1f), EPS);
        assertEquals(50f, DirBlastRules.overload(0f), EPS);
        assertEquals(40f, DirBlastRules.overload(0.5f), EPS);
        assertEquals(30f, DirBlastRules.overload(1f), EPS);
        assertEquals(80, DirBlastRules.cooldownTicks(0f));
        assertEquals(65, DirBlastRules.cooldownTicks(0.5f));
        assertEquals(50, DirBlastRules.cooldownTicks(1f));
        assertEquals(10f, DirBlastRules.damage(0f), EPS);
        assertEquals(17.5f, DirBlastRules.damage(0.5f), EPS);
        assertEquals(25f, DirBlastRules.damage(1f), EPS);
        assertEquals(0.5, DirBlastRules.breakProb(0f), EPS);
        assertEquals(0.65, DirBlastRules.breakProb(0.5f), EPS);
        assertEquals(0.8, DirBlastRules.breakProb(1f), EPS);
    }

    @Test
    void hardnessBands() {
        assertEquals(2.9f, DirBlastRules.hardnessLimit(0f), EPS);
        assertEquals(2.9f, DirBlastRules.hardnessLimit(0.24f), EPS);
        assertEquals(25f, DirBlastRules.hardnessLimit(0.25f), EPS);
        assertEquals(55f, DirBlastRules.hardnessLimit(0.5f), EPS);
        assertEquals(55f, DirBlastRules.hardnessLimit(1f), EPS);
        assertTrue(DirBlastRules.canBreak(1.5f, 0f), "stone at exp 0");
        assertFalse(DirBlastRules.canBreak(3f, 0f), "ores need exp 0.25");
        assertTrue(DirBlastRules.canBreak(50f, 0.5f), "obsidian at exp 0.5");
        assertFalse(DirBlastRules.canBreak(-1f, 1f), "unbreakable never");
    }

    @Test
    void dropsTheBlockItselfOnlyAtFullExp() {
        assertFalse(DirBlastRules.dropsBlockItself(0.99f));
        assertTrue(DirBlastRules.dropsBlockItself(1f));
    }

    @Test
    void holdWindowLikeDirectedShock() {
        assertFalse(DirBlastRules.holdAccepted(6));
        assertTrue(DirBlastRules.holdAccepted(7));
        assertTrue(DirBlastRules.holdAccepted(49));
        assertFalse(DirBlastRules.holdAccepted(50));
        assertTrue(DirBlastRules.serverHoldAccepted(5));
        assertTrue(DirBlastRules.serverHoldAccepted(51));
        assertFalse(DirBlastRules.serverHoldAccepted(4));
        assertFalse(DirBlastRules.serverHoldAccepted(52));
    }

    @Test
    void expOnlyWhenSomethingWasHit() {
        assertEquals(0.0025f, DirBlastRules.expGain(true, false), 1e-7f);
        assertEquals(0.0025f, DirBlastRules.expGain(true, true), 1e-7f);
        assertEquals(0.0012f, DirBlastRules.expGain(false, true), 1e-7f);
        assertEquals(0f, DirBlastRules.expGain(false, false));
    }

    @Test
    void cellsAreThe81OfTheSphere() {
        List<int[]> cells = DirBlastRules.cells();
        assertEquals(81, cells.size());
        assertArrayEquals(new int[] {0, 0, 0}, cells.get(0));
        Set<String> unique = new HashSet<>();
        for (int[] c : cells) {
            assertTrue(c[0] * c[0] + c[1] * c[1] + c[2] * c[2] <= 6);
            unique.add(c[0] + "," + c[1] + "," + c[2]);
        }
        assertEquals(81, unique.size());
    }

    @Test
    void strongPushAwayFromTheCenter() {
        double[] v = DirBlastRules.knockback(0, 0, 2, 0, 0, 1);
        assertEquals(1.2, Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]), 1e-9);
        assertTrue(v[0] > 1.0 && v[1] > 0.3 && Math.abs(v[2]) < 1e-9, "outwards along +x and up");
    }

    @Test
    void pushAtTheCenterFollowsTheGaze() {
        double[] v = DirBlastRules.knockback(5, 5, 5.1, 5, 0, 1);
        assertTrue(v[2] > 1.0 && Math.abs(v[0]) < 1e-9 && v[1] > 0.3, "along the look (+z) and up");
    }
}
