package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/** Tabla de la ficha rad-intensify §2, §3 y §8. */
class RadIntensifyRulesTest {
    private static final float EPS = 1e-3f;
    private static final float INIT_CP_5 = 8000f;

    @Test
    void expIsMaxCpOverLevel5InitialCp() {
        assertEquals(0.225f, RadIntensifyRules.exp(1800f, INIT_CP_5), EPS);
        assertEquals(0.35f, RadIntensifyRules.exp(2800f, INIT_CP_5), EPS);
        assertEquals(0.5f, RadIntensifyRules.exp(4000f, INIT_CP_5), EPS);
        assertEquals(0.625f, RadIntensifyRules.exp(5000f, INIT_CP_5), EPS);
        assertEquals(0.725f, RadIntensifyRules.exp(5800f, INIT_CP_5), EPS);
        assertEquals(1f, RadIntensifyRules.exp(8000f, INIT_CP_5), EPS);
    }

    @Test
    void expIsClamped() {
        assertEquals(1f, RadIntensifyRules.exp(20000f, INIT_CP_5), 0f);
        assertEquals(0f, RadIntensifyRules.exp(-5f, INIT_CP_5), 0f);
        assertEquals(0f, RadIntensifyRules.exp(1000f, 0f), 0f);
        assertEquals(0f, RadIntensifyRules.exp(Float.NaN, INIT_CP_5), 0f);
    }

    @Test
    void rateGoesFrom1_4To1_8() {
        assertEquals(1.4f, RadIntensifyRules.rate(0f), EPS);
        assertEquals(1.6f, RadIntensifyRules.rate(0.5f), EPS);
        assertEquals(1.8f, RadIntensifyRules.rate(1f), EPS);
        assertEquals(1.49f, RadIntensifyRules.rate(0.225f), EPS);
        assertEquals(1.69f, RadIntensifyRules.rate(0.725f), EPS);
        assertEquals(1.8f, RadIntensifyRules.rate(3f), EPS);
    }

    @Test
    void markLastsThreeSeconds() {
        assertEquals(60, RadIntensifyRules.MARK_TICKS);
    }
}
