package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha ray-barrage §12 y la zona del abanico (decisión 2). */
class RayBarrageRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costs() {
        assertEquals(450f, RayBarrageRules.cp(0f), EPS);
        assertEquals(415f, RayBarrageRules.cp(0.5f), EPS);
        assertEquals(380f, RayBarrageRules.cp(1f), EPS);
        assertEquals(300f, RayBarrageRules.overload(0f), EPS);
        assertEquals(220f, RayBarrageRules.overload(0.5f), EPS);
        assertEquals(140f, RayBarrageRules.overload(1f), EPS);
    }

    @Test
    void cooldownFrom100To40() {
        assertEquals(100, RayBarrageRules.cooldown(0f));
        assertEquals(70, RayBarrageRules.cooldown(0.5f));
        assertEquals(40, RayBarrageRules.cooldown(1f));
    }

    @Test
    void damage() {
        assertEquals(10f, RayBarrageRules.damageFan(0f), EPS);
        assertEquals(14f, RayBarrageRules.damageFan(0.5f), EPS);
        assertEquals(18f, RayBarrageRules.damageFan(1f), EPS);
        assertEquals(25f, RayBarrageRules.damageDirect(0f), EPS);
        assertEquals(42.5f, RayBarrageRules.damageDirect(0.5f), EPS);
        assertEquals(60f, RayBarrageRules.damageDirect(1f), EPS);
    }

    @Test
    void expOnlyWhenHurting() {
        assertEquals(0.005f, RayBarrageRules.expGain(true), EPS);
        assertEquals(0f, RayBarrageRules.expGain(false), EPS);
    }

    @Test
    void anglesFollowMinecraftConvention() {
        assertEquals(0.0, RayBarrageRules.yawOf(0, 1), 1e-9);
        assertEquals(90.0, RayBarrageRules.yawOf(-1, 0), 1e-9);
        assertEquals(-90.0, RayBarrageRules.yawOf(1, 0), 1e-9);
        assertEquals(45.0, RayBarrageRules.pitchOf(0, -1, 1), 1e-9);
        assertEquals(-170.0, RayBarrageRules.wrapDegrees(190.0), 1e-9);
        assertEquals(180.0, RayBarrageRules.wrapDegrees(-180.0), 1e-9);
    }

    /** Mirando a +Z y horizontal desde el origen. */
    private static boolean inFan(double x, double y, double z) {
        return RayBarrageRules.isInFan(0, 0, 0, 0, 0, x, y, z);
    }

    @Test
    void fanIsWideHorizontally() {
        assertTrue(inFan(0, 0, 10), "straight ahead");
        // 50° a cada lado: dentro; 60°: fuera.
        double r = 10;
        assertTrue(inFan(Math.sin(Math.toRadians(50)) * r, 0, Math.cos(Math.toRadians(50)) * r));
        assertTrue(inFan(-Math.sin(Math.toRadians(50)) * r, 0, Math.cos(Math.toRadians(50)) * r));
        assertFalse(inFan(Math.sin(Math.toRadians(60)) * r, 0, Math.cos(Math.toRadians(60)) * r));
        assertFalse(inFan(0, 0, -10), "behind");
        assertFalse(inFan(10, 0, 0), "to the side");
    }

    @Test
    void fanIsLowVertically() {
        double r = 10;
        assertTrue(inFan(0, Math.sin(Math.toRadians(25)) * r, Math.cos(Math.toRadians(25)) * r));
        assertTrue(inFan(0, -Math.sin(Math.toRadians(25)) * r, Math.cos(Math.toRadians(25)) * r));
        assertFalse(inFan(0, Math.sin(Math.toRadians(30)) * r, Math.cos(Math.toRadians(30)) * r));
        assertFalse(inFan(0, -10, 1), "almost straight below");
    }

    @Test
    void fanReachesTwentyBlocks() {
        assertTrue(inFan(0, 0, 19.9));
        assertFalse(inFan(0, 0, 20.1));
        assertFalse(inFan(0, 0, 0), "the origin itself");
    }

    @Test
    void fanFollowsTheLook() {
        // Mirando a -X (yaw 90) y 70° hacia abajo: un punto abajo y delante entra, uno detrás no.
        assertTrue(RayBarrageRules.isInFan(0, 5, 0, 90, 70, -2, 0, 0));
        assertFalse(RayBarrageRules.isInFan(0, 5, 0, 90, 70, 2, 0, 0));
        // El salto de -180 a 180 no rompe la comparación del yaw.
        assertTrue(RayBarrageRules.isInFan(0, 0, 0, 179, 0, 1, 0, -10));
        assertTrue(RayBarrageRules.isInFan(0, 0, 0, -179, 0, -1, 0, -10));
    }
}
