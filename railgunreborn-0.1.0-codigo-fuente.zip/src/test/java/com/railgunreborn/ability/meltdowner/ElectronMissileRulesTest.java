package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha electron-missile §10 y decisiones 1-2. */
class ElectronMissileRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void referenceValues() {
        assertEquals(12f, ElectronMissileRules.cpPerTick(0f), EPS);
        assertEquals(8.5f, ElectronMissileRules.cpPerTick(0.5f), EPS);
        assertEquals(5f, ElectronMissileRules.cpPerTick(1f), EPS);
        assertEquals(60f, ElectronMissileRules.cpPerAttack(0f), EPS);
        assertEquals(42.5f, ElectronMissileRules.cpPerAttack(0.5f), EPS);
        assertEquals(25f, ElectronMissileRules.cpPerAttack(1f), EPS);
        assertEquals(9f, ElectronMissileRules.overloadPerAttack(0f), EPS);
        assertEquals(6.5f, ElectronMissileRules.overloadPerAttack(0.5f), EPS);
        assertEquals(4f, ElectronMissileRules.overloadPerAttack(1f), EPS);
        assertEquals(10f, ElectronMissileRules.damage(0f), EPS);
        assertEquals(14f, ElectronMissileRules.damage(0.5f), EPS);
        assertEquals(18f, ElectronMissileRules.damage(1f), EPS);
        assertEquals(5.0, ElectronMissileRules.range(0f), EPS);
        assertEquals(9.0, ElectronMissileRules.range(0.5f), EPS);
        assertEquals(13.0, ElectronMissileRules.range(1f), EPS);
        assertEquals(80, ElectronMissileRules.maxTicks(0f));
        assertEquals(140, ElectronMissileRules.maxTicks(0.5f));
        assertEquals(200, ElectronMissileRules.maxTicks(1f));
    }

    @Test
    void cooldownFrom700To400() {
        assertEquals(700, ElectronMissileRules.cooldown(0f));
        assertEquals(550, ElectronMissileRules.cooldown(0.5f));
        assertEquals(400, ElectronMissileRules.cooldown(1f));
    }

    @Test
    void ballsEveryTenTicksUpToFive() {
        assertTrue(ElectronMissileRules.spawnsBall(0, 0));
        assertFalse(ElectronMissileRules.spawnsBall(5, 1));
        assertTrue(ElectronMissileRules.spawnsBall(40, 4));
        assertFalse(ElectronMissileRules.spawnsBall(50, 5));
    }

    @Test
    void attacksEveryEightTicksButNotAtZero() {
        assertFalse(ElectronMissileRules.isAttackTick(0));
        assertFalse(ElectronMissileRules.isAttackTick(4));
        assertTrue(ElectronMissileRules.isAttackTick(8));
        assertTrue(ElectronMissileRules.isAttackTick(80));
    }

    @Test
    void picksTheClosestInRange() {
        List<Double> dist = List.of(16.0, 4.0, 9.0, 4.0);
        Double best = ElectronMissileRules.pickClosest(dist, d -> d, 5);
        assertEquals(4.0, best);
        assertTrue(best == dist.get(1), "on a tie the first one wins");
        assertEquals(16.0, ElectronMissileRules.pickClosest(List.of(16.0, 30.0), d -> d, 4));
        assertNull(ElectronMissileRules.pickClosest(List.of(26.0, 30.0), d -> d, 5));
        assertNull(ElectronMissileRules.pickClosest(List.<Double>of(), d -> d, 5));
    }

    @Test
    void skipsSelfPetsArmorStandsAndProtectedPlayers() {
        assertTrue(ElectronMissileRules.isValidTarget(false, false, false, false));
        assertFalse(ElectronMissileRules.isValidTarget(true, false, false, false));
        assertFalse(ElectronMissileRules.isValidTarget(false, true, false, false));
        assertFalse(ElectronMissileRules.isValidTarget(false, false, true, false));
        assertFalse(ElectronMissileRules.isValidTarget(false, false, false, true));
    }
}
