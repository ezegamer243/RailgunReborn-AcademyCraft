package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha scatter-bomb §9. */
class ScatterBombRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costsAndDamageInterpolate() {
        assertEquals(80f, ScatterBombRules.initialOverload(0f), EPS);
        assertEquals(70f, ScatterBombRules.initialOverload(0.5f), EPS);
        assertEquals(60f, ScatterBombRules.initialOverload(1f), EPS);
        assertEquals(3f, ScatterBombRules.cpPerTick(0f), EPS);
        assertEquals(4.5f, ScatterBombRules.cpPerTick(0.5f), EPS);
        assertEquals(6f, ScatterBombRules.cpPerTick(1f), EPS);
        assertEquals(5f, ScatterBombRules.damage(0f), EPS);
        assertEquals(7f, ScatterBombRules.damage(0.5f), EPS);
        assertEquals(9f, ScatterBombRules.damage(1f), EPS);
    }

    @Test
    void ballsAppearEveryTenTicksFrom20To80() {
        int count = 0;
        for (int t = 0; t <= 300; t++) {
            if (ScatterBombRules.canSpawnBall(t)) {
                count++;
                assertTrue(t >= 20 && t <= 80 && t % 10 == 0);
            }
        }
        assertEquals(ScatterBombRules.MAX_BALLS, count);
        assertFalse(ScatterBombRules.canSpawnBall(19));
        assertFalse(ScatterBombRules.canSpawnBall(90));
    }

    @Test
    void cpIsPaidOnlyUpTo80Ticks() {
        assertFalse(ScatterBombRules.paysCp(0));
        assertTrue(ScatterBombRules.paysCp(1));
        assertTrue(ScatterBombRules.paysCp(80));
        assertFalse(ScatterBombRules.paysCp(81));
    }

    @Test
    void blowsAt200Ticks() {
        assertFalse(ScatterBombRules.isBlowTick(199));
        assertTrue(ScatterBombRules.isBlowTick(200));
    }

    @Test
    void autoAimNeedsMoreThanHalfExp() {
        assertEquals(0, ScatterBombRules.autoCount(7, 0.5f));
        assertEquals(4, ScatterBombRules.autoCount(7, 0.6f));
        assertEquals(5, ScatterBombRules.autoCount(7, 0.8f));
        assertEquals(7, ScatterBombRules.autoCount(7, 1f));
        assertEquals(0, ScatterBombRules.autoCount(0, 1f));
    }

    @Test
    void expIsPerBallThatHits() {
        assertEquals(0f, ScatterBombRules.expGain(0), EPS);
        assertEquals(0.007f, ScatterBombRules.expGain(7), EPS);
    }

    @Test
    void scatterStaysWithinTheConeRelativeToTheLook() {
        double[][] looks = {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}, {0, -1, 0},
                {Math.sqrt(0.5), Math.sqrt(0.5), 0}};
        double maxCos = Math.cos(Math.toRadians(ScatterBombRules.SCATTER_DEG * Math.sqrt(2)));
        for (double[] look : looks) {
            for (double r1 : new double[] {0, 0.5, 0.999}) {
                for (double r2 : new double[] {0, 0.5, 0.999}) {
                    double[] d = ScatterBombRules.scatterDirection(look, r1, r2);
                    assertEquals(1.0, Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]), 1e-9);
                    assertTrue(d[0] * look[0] + d[1] * look[1] + d[2] * look[2] >= maxCos - 1e-9);
                }
            }
        }
        double[] centered = ScatterBombRules.scatterDirection(new double[] {0, 0, 1}, 0.5, 0.5);
        assertEquals(1.0, centered[2], 1e-9);
    }
}
