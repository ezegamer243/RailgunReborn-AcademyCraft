package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.common.TunnelRules;

/** Valores de referencia de la ficha meltdowner-skill §2-4 y §8. */
class MeltdownerRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void rateFollowsChargeAndIsClamped() {
        assertEquals(0.8f, MeltdownerRules.rate(20), EPS);
        assertEquals(1.0f, MeltdownerRules.rate(30), EPS);
        assertEquals(1.2f, MeltdownerRules.rate(40), EPS);
        assertEquals(1.2f, MeltdownerRules.rate(90), EPS);
        assertEquals(0.8f, MeltdownerRules.rate(5), EPS);
    }

    @Test
    void firingWindow() {
        assertFalse(MeltdownerRules.canFire(10));
        assertFalse(MeltdownerRules.canFire(19));
        assertTrue(MeltdownerRules.canFire(20));
        assertTrue(MeltdownerRules.canFire(40));
        assertTrue(MeltdownerRules.canFire(100));
        assertFalse(MeltdownerRules.canFire(101));
        assertFalse(MeltdownerRules.isOverTolerance(100));
        assertTrue(MeltdownerRules.isOverTolerance(101));
    }

    @Test
    void costs() {
        assertEquals(200f, MeltdownerRules.initialOverload(0f), EPS);
        assertEquals(185f, MeltdownerRules.initialOverload(0.5f), EPS);
        assertEquals(170f, MeltdownerRules.initialOverload(1f), EPS);
        assertEquals(10f, MeltdownerRules.cpPerTick(0f), EPS);
        assertEquals(15f, MeltdownerRules.cpPerTick(1f), EPS);
    }

    @Test
    void referenceTable() {
        // e=0, ct=20 | e=0.5, ct=30 | e=1, ct=40
        assertEquals(2.0, MeltdownerRules.radius(0f), EPS);
        assertEquals(2.5, MeltdownerRules.radius(0.5f), EPS);
        assertEquals(3.0, MeltdownerRules.radius(1f), EPS);
        assertEquals(240.0, MeltdownerRules.energy(0f, 20), 1e-3);
        assertEquals(500.0, MeltdownerRules.energy(0.5f, 30), 1e-3);
        assertEquals(840.0, MeltdownerRules.energy(1f, 40), 1e-3);
        assertEquals(14.4f, MeltdownerRules.damage(0f, 20), EPS);
        assertEquals(34f, MeltdownerRules.damage(0.5f, 30), EPS);
        assertEquals(60f, MeltdownerRules.damage(1f, 40), EPS);
        assertEquals(0.0016f, MeltdownerRules.expGain(20), 1e-7f);
        assertEquals(0.002f, MeltdownerRules.expGain(30), 1e-7f);
        assertEquals(0.0024f, MeltdownerRules.expGain(40), 1e-7f);
    }

    @Test
    void cooldownTable() {
        assertEquals(240, MeltdownerRules.cooldown(0f, 20));
        assertEquals(300, MeltdownerRules.cooldown(0f, 30));
        assertEquals(360, MeltdownerRules.cooldown(0f, 40));
        assertEquals(176, MeltdownerRules.cooldown(0.5f, 20));
        assertEquals(220, MeltdownerRules.cooldown(0.5f, 30));
        assertEquals(264, MeltdownerRules.cooldown(0.5f, 40));
        assertEquals(112, MeltdownerRules.cooldown(1f, 20));
        assertEquals(140, MeltdownerRules.cooldown(1f, 30));
        assertEquals(168, MeltdownerRules.cooldown(1f, 40));
    }

    @Test
    void slownessGrowsOnePercentPerTick() {
        assertEquals(0.0, MeltdownerRules.slowAmount(0), 1e-9);
        assertEquals(-0.4, MeltdownerRules.slowAmount(40), 1e-9);
        assertEquals(-1.0, MeltdownerRules.slowAmount(100), 1e-9);
        assertEquals(-1.0, MeltdownerRules.slowAmount(150), 1e-9);
    }

    @Test
    void reflectDamage() {
        assertEquals(10f, MeltdownerRules.reflectDamage(0f), EPS);
        assertEquals(25f, MeltdownerRules.reflectDamage(1f), EPS);
    }

    @Test
    void tunnelGridGrowsWithRadius() {
        assertEquals(2, TunnelRules.gridHalf(MeltdownerRules.radius(0f)));
        assertEquals(3, TunnelRules.gridHalf(MeltdownerRules.radius(1f)));
        TunnelRules.Vec origin = new TunnelRules.Vec(0.5, 0.5, 0.5);
        TunnelRules.Vec dir = new TunnelRules.Vec(0, 0, 1);
        int small = TunnelRules.lineStarts(origin, dir, MeltdownerRules.radius(0f), () -> 0.5).size();
        int large = TunnelRules.lineStarts(origin, dir, MeltdownerRules.radius(1f), () -> 0.5).size();
        assertTrue(large > small, "radius 3 has more lines than radius 2: " + small + " vs " + large);
    }
}
