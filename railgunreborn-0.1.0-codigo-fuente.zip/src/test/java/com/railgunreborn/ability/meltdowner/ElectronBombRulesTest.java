package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha electron-bomb §9. */
class ElectronBombRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void damageFrom6To12() {
        assertEquals(6f, ElectronBombRules.damage(0f), EPS);
        assertEquals(9f, ElectronBombRules.damage(0.5f), EPS);
        assertEquals(10.8f, ElectronBombRules.damage(0.8f), EPS);
        assertEquals(12f, ElectronBombRules.damage(1f), EPS);
    }

    @Test
    void cooldownFrom20To10() {
        assertEquals(20, ElectronBombRules.cooldownTicks(0f));
        assertEquals(15, ElectronBombRules.cooldownTicks(0.5f));
        assertEquals(12, ElectronBombRules.cooldownTicks(0.8f));
        assertEquals(10, ElectronBombRules.cooldownTicks(1f));
    }

    @Test
    void lifeThresholdIsExclusive() {
        assertEquals(20, ElectronBombRules.life(0.8f));
        assertEquals(5, ElectronBombRules.life(0.81f));
        assertEquals(18, ElectronBombRules.fireTick(0f));
        assertEquals(3, ElectronBombRules.fireTick(1f));
    }

    @Test
    void expOnlyWhenHittingALivingEntity() {
        assertEquals(0.005f, ElectronBombRules.expGain(true), EPS);
        assertEquals(0f, ElectronBombRules.expGain(false), EPS);
    }

    @Test
    void ballOffsetStaysInFrontOfThePlayer() {
        for (double r1 : new double[] {0, 0.25, 0.5, 0.99}) {
            for (double r2 : new double[] {0, 1}) {
                double[] o = ElectronBombRules.ballOffset(0, r1, r2, 0.5);
                // yaw 0 mira a +Z: la bola queda delante (dz > 0) a 0.8-1.3 bloques en horizontal.
                assertTrue(o[2] > 0, "z should be in front");
                double horizontal = Math.hypot(o[0], o[2]);
                assertTrue(horizontal >= 0.8 - 1e-9 && horizontal <= 1.3 + 1e-9);
            }
        }
        assertEquals(0.4, ElectronBombRules.ballOffset(0, 0, 0, 0)[1], 1e-9);
        assertEquals(1.8, ElectronBombRules.ballOffset(0, 0, 0, 1)[1], 1e-9);
        assertEquals(0.8, ElectronBombRules.ballOffset(0, 0.5, 0, 0.5)[2], 1e-9);
    }
}
