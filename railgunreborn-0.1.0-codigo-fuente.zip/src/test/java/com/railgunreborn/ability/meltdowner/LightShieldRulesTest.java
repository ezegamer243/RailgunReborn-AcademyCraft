package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha light-shield §10 y decisiones. */
class LightShieldRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void referenceValues() {
        assertEquals(110f, LightShieldRules.initialOverload(0f), EPS);
        assertEquals(85f, LightShieldRules.initialOverload(0.5f), EPS);
        assertEquals(60f, LightShieldRules.initialOverload(1f), EPS);
        assertEquals(9f, LightShieldRules.cpPerTick(0f), EPS);
        assertEquals(6.5f, LightShieldRules.cpPerTick(0.5f), EPS);
        assertEquals(4f, LightShieldRules.cpPerTick(1f), EPS);
        assertEquals(120, LightShieldRules.maxTicks(0f));
        assertEquals(150, LightShieldRules.maxTicks(0.5f));
        assertEquals(180, LightShieldRules.maxTicks(1f));
        assertEquals(15f, LightShieldRules.absorbAmount(0f), EPS);
        assertEquals(32.5f, LightShieldRules.absorbAmount(0.5f), EPS);
        assertEquals(50f, LightShieldRules.absorbAmount(1f), EPS);
        assertEquals(2f, LightShieldRules.touchDamage(0f), EPS);
        assertEquals(4f, LightShieldRules.touchDamage(0.5f), EPS);
        assertEquals(6f, LightShieldRules.touchDamage(1f), EPS);
    }

    @Test
    void actionCostsUseTheIntendedOrder() {
        // Decisión 1: CP 50-30 y overload 5-3 (el original los tenía al revés al absorber).
        assertEquals(50f, LightShieldRules.actionCp(0f), EPS);
        assertEquals(40f, LightShieldRules.actionCp(0.5f), EPS);
        assertEquals(30f, LightShieldRules.actionCp(1f), EPS);
        assertEquals(5f, LightShieldRules.actionOverload(0f), EPS);
        assertEquals(4f, LightShieldRules.actionOverload(0.5f), EPS);
        assertEquals(3f, LightShieldRules.actionOverload(1f), EPS);
    }

    @Test
    void cooldownAndDuration() {
        assertEquals(240, LightShieldRules.cooldown(0f, 120));
        assertEquals(225, LightShieldRules.cooldown(0.5f, 150));
        assertEquals(180, LightShieldRules.cooldown(1f, 180));
        assertEquals(0, LightShieldRules.cooldown(0f, 0));
        assertFalse(LightShieldRules.isOver(120, 0f));
        assertTrue(LightShieldRules.isOver(121, 0f));
    }

    @Test
    void absorbClampsAtZero() {
        assertEquals(5f, LightShieldRules.absorb(20f, 15f), EPS);
        assertEquals(0f, LightShieldRules.absorb(10f, 15f), EPS);
        assertEquals(0f, LightShieldRules.absorb(0f, 15f), EPS);
        assertEquals(7f, LightShieldRules.absorb(7f, -3f), EPS);
    }

    @Test
    void oneAbsorbEvery18Ticks() {
        assertTrue(LightShieldRules.intervalElapsed(0, Integer.MIN_VALUE));
        assertFalse(LightShieldRules.intervalElapsed(10, 10));
        assertFalse(LightShieldRules.intervalElapsed(28, 10));
        assertTrue(LightShieldRules.intervalElapsed(29, 10));
    }

    @Test
    void coneFacesTheYaw() {
        // yaw 0 mira a +Z; 90 mira a -X; 180 a -Z.
        assertTrue(LightShieldRules.inCone(0, 1, 0));
        assertFalse(LightShieldRules.inCone(0, -1, 0));
        assertTrue(LightShieldRules.inCone(-1, 0, 90));
        assertFalse(LightShieldRules.inCone(1, 0, 90));
        assertTrue(LightShieldRules.inCone(0, -1, 180));
        // Bordes: 59° dentro, 61° fuera.
        double in = Math.toRadians(59);
        double out = Math.toRadians(61);
        assertTrue(LightShieldRules.inCone(-Math.sin(in), Math.cos(in), 0));
        assertFalse(LightShieldRules.inCone(-Math.sin(out), Math.cos(out), 0));
    }

    @Test
    void coneWorksWithUnnormalizedYaw() {
        // Decisión 4: el yaw puede pasar de ±180 tras girar varias vueltas.
        assertTrue(LightShieldRules.inCone(0, 1, 720));
        assertTrue(LightShieldRules.inCone(0, 1, -360));
        assertTrue(LightShieldRules.inCone(0, -1, 540));
        assertTrue(LightShieldRules.inCone(0, -1, -180));
        assertTrue(LightShieldRules.inCone(-1, 0, 450));
        assertFalse(LightShieldRules.inCone(0, -1, 1080));
        // Cerca de la discontinuidad de ±180: yaw 170 y punto a -170.
        double a = Math.toRadians(-170);
        assertTrue(LightShieldRules.inCone(-Math.sin(a), Math.cos(a), 170));
    }

    @Test
    void wrapDegreesRange() {
        assertEquals(0, LightShieldRules.wrapDegrees(360), 1e-9);
        assertEquals(-180, LightShieldRules.wrapDegrees(180), 1e-9);
        assertEquals(170, LightShieldRules.wrapDegrees(-190), 1e-9);
        assertEquals(-90, LightShieldRules.wrapDegrees(990), 1e-9);
    }
}
