package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.meltdowner.MineRayRules.Variant;

/** Valores de referencia de la ficha mine-ray §4 y §11. */
class MineRayRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void basicReferenceValues() {
        Variant v = Variant.BASIC;
        assertEquals(10.0, v.range);
        assertEquals(0, v.fortune);
        assertEquals(0.0005f, v.expPerBlock, 1e-7f);
        assertEquals(0.2f, MineRayRules.speed(v, 0f), EPS);
        assertEquals(0.3f, MineRayRules.speed(v, 0.5f), EPS);
        assertEquals(0.4f, MineRayRules.speed(v, 1f), EPS);
        assertEquals(12f, MineRayRules.cpPerTick(v, 0f), EPS);
        assertEquals(9.5f, MineRayRules.cpPerTick(v, 0.5f), EPS);
        assertEquals(7f, MineRayRules.cpPerTick(v, 1f), EPS);
        assertEquals(200f, MineRayRules.initialOverload(v, 0f), EPS);
        assertEquals(175f, MineRayRules.initialOverload(v, 0.5f), EPS);
        assertEquals(150f, MineRayRules.initialOverload(v, 1f), EPS);
        assertEquals(40, MineRayRules.cooldown(v, 0f));
        assertEquals(30, MineRayRules.cooldown(v, 0.5f));
        assertEquals(20, MineRayRules.cooldown(v, 1f));
    }

    @Test
    void expertAndLuckReferenceValues() {
        for (Variant v : new Variant[] {Variant.EXPERT, Variant.LUCK}) {
            assertEquals(20.0, v.range);
            assertEquals(0.0003f, v.expPerBlock, 1e-7f);
            assertEquals(0.5f, MineRayRules.speed(v, 0f), EPS);
            assertEquals(0.75f, MineRayRules.speed(v, 0.5f), EPS);
            assertEquals(1.0f, MineRayRules.speed(v, 1f), EPS);
            assertEquals(60, MineRayRules.cooldown(v, 0f));
            assertEquals(45, MineRayRules.cooldown(v, 0.5f));
            assertEquals(30, MineRayRules.cooldown(v, 1f));
        }
        assertEquals(0, Variant.EXPERT.fortune);
        assertEquals(3, Variant.LUCK.fortune);
        assertEquals(25f, MineRayRules.cpPerTick(Variant.EXPERT, 0f), EPS);
        assertEquals(20f, MineRayRules.cpPerTick(Variant.EXPERT, 0.5f), EPS);
        assertEquals(15f, MineRayRules.cpPerTick(Variant.EXPERT, 1f), EPS);
        assertEquals(300f, MineRayRules.initialOverload(Variant.EXPERT, 0f), EPS);
        assertEquals(250f, MineRayRules.initialOverload(Variant.EXPERT, 0.5f), EPS);
        assertEquals(200f, MineRayRules.initialOverload(Variant.EXPERT, 1f), EPS);
        assertEquals(50f, MineRayRules.cpPerTick(Variant.LUCK, 0f), EPS);
        assertEquals(42.5f, MineRayRules.cpPerTick(Variant.LUCK, 0.5f), EPS);
        assertEquals(35f, MineRayRules.cpPerTick(Variant.LUCK, 1f), EPS);
        assertEquals(350f, MineRayRules.initialOverload(Variant.LUCK, 0f), EPS);
        assertEquals(325f, MineRayRules.initialOverload(Variant.LUCK, 0.5f), EPS);
        assertEquals(300f, MineRayRules.initialOverload(Variant.LUCK, 1f), EPS);
    }

    @Test
    void harvestTier() {
        assertTrue(MineRayRules.canMine(Variant.BASIC, 1.5f, false), "basic: stone");
        assertTrue(MineRayRules.canMine(Variant.BASIC, 3f, false), "basic: diamond ore (iron tier)");
        assertFalse(MineRayRules.canMine(Variant.BASIC, 50f, true), "basic: no obsidian");
        assertTrue(MineRayRules.canMine(Variant.EXPERT, 50f, true), "expert: obsidian");
        assertTrue(MineRayRules.canMine(Variant.LUCK, 50f, true), "luck: obsidian");
        for (Variant v : Variant.values()) {
            assertFalse(MineRayRules.canMine(v, -1f, false), v + ": bedrock never");
            assertTrue(MineRayRules.canMine(v, 0f, false), v + ": instant blocks");
        }
    }

    /** Tabla de §4: 1 tick para elegir el bloque y luego uno por cada resta. */
    @Test
    void ticksToBreakTable() {
        assertEquals(4, MineRayRules.ticksToBreak(0.5f, 0.2f));
        assertEquals(3, MineRayRules.ticksToBreak(0.5f, 0.4f));
        assertEquals(2, MineRayRules.ticksToBreak(0.5f, 0.5f));
        assertEquals(9, MineRayRules.ticksToBreak(1.5f, 0.2f));
        assertEquals(5, MineRayRules.ticksToBreak(1.5f, 0.4f));
        assertEquals(4, MineRayRules.ticksToBreak(1.5f, 0.5f));
        assertEquals(3, MineRayRules.ticksToBreak(1.5f, 1.0f));
        int ironBasic = MineRayRules.ticksToBreak(3f, 0.2f);
        assertTrue(ironBasic == 16 || ironBasic == 17, "iron ore, basic e=0: ~16, was " + ironBasic);
        assertEquals(9, MineRayRules.ticksToBreak(3f, 0.4f));
        assertEquals(7, MineRayRules.ticksToBreak(3f, 0.5f));
        assertEquals(4, MineRayRules.ticksToBreak(3f, 1.0f));
        assertEquals(101, MineRayRules.ticksToBreak(50f, 0.5f));
        assertEquals(51, MineRayRules.ticksToBreak(50f, 1.0f));
        assertEquals(Integer.MAX_VALUE, MineRayRules.ticksToBreak(-1f, 1.0f));
    }
}
