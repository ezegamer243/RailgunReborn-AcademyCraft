package com.railgunreborn.ability.meltdowner;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha jet-engine §10 y el dash que para en el destino (decisión 2). */
class JetEngineRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void realCostsOfTheOriginal() {
        assertEquals(60f, JetEngineRules.cpCost(0f), EPS);
        assertEquals(55f, JetEngineRules.cpCost(0.5f), EPS);
        assertEquals(50f, JetEngineRules.cpCost(1f), EPS);
        assertEquals(170f, JetEngineRules.overload(0f), EPS);
        assertEquals(155f, JetEngineRules.overload(0.5f), EPS);
        assertEquals(140f, JetEngineRules.overload(1f), EPS);
        assertEquals(JetEngineRules.cpCost(0.3f), JetEngineRules.cpToHold(0.3f), EPS);
    }

    @Test
    void cooldownAndDamage() {
        assertEquals(60, JetEngineRules.cooldown(0f));
        assertEquals(45, JetEngineRules.cooldown(0.5f));
        assertEquals(30, JetEngineRules.cooldown(1f));
        assertEquals(7f, JetEngineRules.damage(0f), EPS);
        assertEquals(13.5f, JetEngineRules.damage(0.5f), EPS);
        assertEquals(20f, JetEngineRules.damage(1f), EPS);
    }

    @Test
    void dashReachesTheDestinationIn8TicksAndStops() {
        double[] start = {0, 64, 0};
        double[] dest = {0, 64, 12};
        assertArrayEquals(start, JetEngineRules.dashPosition(start, dest, 0), 1e-9);
        assertArrayEquals(new double[] {0, 64, 6}, JetEngineRules.dashPosition(start, dest, 4), 1e-9);
        assertArrayEquals(dest, JetEngineRules.dashPosition(start, dest, 8), 1e-9);
        // El original seguía hasta el doble; aquí no pasa del destino.
        assertArrayEquals(dest, JetEngineRules.dashPosition(start, dest, 15), 1e-9);
        assertEquals(0.0, JetEngineRules.progress(-3), 1e-9);
    }

    @Test
    void arrivalAndFlightLength() {
        assertFalse(JetEngineRules.arrived(7));
        assertTrue(JetEngineRules.arrived(8));
        assertFalse(JetEngineRules.flightOver(14));
        assertTrue(JetEngineRules.flightOver(15));
    }

    @Test
    void stepLimitAndPlausibleDestination() {
        assertEquals(3.0, JetEngineRules.maxStep(12.0), 1e-9);
        assertEquals(0.5, JetEngineRules.maxStep(0.5), 1e-9);
        assertTrue(JetEngineRules.plausibleDestination(13.6));
        assertFalse(JetEngineRules.plausibleDestination(40.0));
        assertFalse(JetEngineRules.plausibleDestination(Double.NaN));
    }
}
