package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;

class FlashingRulesTest {
    private static final double EPS = 1e-6;

    @Test
    void referenceValues() {
        // Tabla §8 de la ficha.
        assertEquals(250f, FlashingRules.startOverload(0f), EPS);
        assertEquals(215f, FlashingRules.startOverload(0.5f), EPS);
        assertEquals(180f, FlashingRules.startOverload(1f), EPS);
        assertEquals(80f, FlashingRules.startCp(0f), EPS);
        assertEquals(70f, FlashingRules.startCp(0.5f), EPS);
        assertEquals(60f, FlashingRules.startCp(1f), EPS);
        assertEquals(13f, FlashingRules.jumpCp(0f), EPS);
        assertEquals(9.5f, FlashingRules.jumpCp(0.5f), EPS);
        assertEquals(6f, FlashingRules.jumpCp(1f), EPS);
        assertEquals(60, FlashingRules.maxTicks(0f));
        assertEquals(105, FlashingRules.maxTicks(0.5f));
        assertEquals(150, FlashingRules.maxTicks(1f));
        assertEquals(12, FlashingRules.distance(0f), EPS);
        assertEquals(15, FlashingRules.distance(0.5f), EPS);
        assertEquals(18, FlashingRules.distance(1f), EPS);
        assertEquals(900, FlashingRules.cooldown(0f));
        assertEquals(650, FlashingRules.cooldown(0.5f));
        assertEquals(400, FlashingRules.cooldown(1f));
        assertEquals(0.002f, FlashingRules.JUMP_EXP, EPS);
        assertEquals(40, FlashingRules.HOVER_TICKS);
        assertEquals(0.5f, FlashingRules.SOUND_VOLUME, EPS);
    }

    @Test
    void directionsFacingSouthHorizontally() {
        // yaw 0 = mirando a +Z: la izquierda es +X.
        assertArrayEquals(new double[] {0, 0, 1}, FlashingRules.direction(FlashingRules.Dir.FORWARD, 0f, 0f), EPS);
        assertArrayEquals(new double[] {0, 0, -1}, FlashingRules.direction(FlashingRules.Dir.BACK, 0f, 0f), EPS);
        assertArrayEquals(new double[] {1, 0, 0}, FlashingRules.direction(FlashingRules.Dir.LEFT, 0f, 0f), EPS);
        assertArrayEquals(new double[] {-1, 0, 0}, FlashingRules.direction(FlashingRules.Dir.RIGHT, 0f, 0f), EPS);
    }

    @Test
    void directionsFollowYaw() {
        // yaw 90 = mirando a -X: la izquierda es +Z.
        assertArrayEquals(new double[] {-1, 0, 0}, FlashingRules.direction(FlashingRules.Dir.FORWARD, 90f, 0f), EPS);
        assertArrayEquals(new double[] {0, 0, 1}, FlashingRules.direction(FlashingRules.Dir.LEFT, 90f, 0f), EPS);
    }

    @Test
    void forwardAndBackFollowPitchButSidesDoNot() {
        // pitch 90 = mirando al suelo.
        assertArrayEquals(new double[] {0, -1, 0}, FlashingRules.direction(FlashingRules.Dir.FORWARD, 0f, 90f), EPS);
        assertArrayEquals(new double[] {0, 1, 0}, FlashingRules.direction(FlashingRules.Dir.BACK, 0f, 90f), EPS);
        assertArrayEquals(new double[] {1, 0, 0}, FlashingRules.direction(FlashingRules.Dir.LEFT, 0f, 90f), EPS);
        double[] up = FlashingRules.direction(FlashingRules.Dir.FORWARD, 30f, -40f);
        assertEquals(1.0, Math.sqrt(up[0] * up[0] + up[1] * up[1] + up[2] * up[2]), EPS);
        assertTrue(up[1] > 0, "looking up goes up");
    }

    @Test
    void dirIdsRoundTrip() {
        for (FlashingRules.Dir dir : FlashingRules.Dir.values()) {
            assertSame(dir, FlashingRules.Dir.byId(dir.id()));
        }
        assertNull(FlashingRules.Dir.byId(-1));
        assertNull(FlashingRules.Dir.byId(4));
    }

    @Test
    void sweepWithoutObstaclesGoesAllTheWay() {
        assertEquals(12, FlashingRules.sweep(12, d -> true), EPS);
        assertEquals(0, FlashingRules.sweep(0, d -> true), EPS);
    }

    @Test
    void sweepStopsJustBeforeTheFirstObstacle() {
        // Choca a partir de 4.37 (p. ej. la cara de una pared).
        double stop = FlashingRules.sweep(12, d -> d < 4.37);
        assertTrue(stop < 4.37 && stop > 4.37 - 0.002, "stops right before the wall, was " + stop);
    }

    @Test
    void sweepDoesNotTunnelThroughThinObstacles() {
        // Un obstáculo de 0.3 entre 5 y 5.3 y hueco libre detrás: el barrido se queda delante.
        double stop = FlashingRules.sweep(12, d -> d < 5 || d > 5.3);
        assertTrue(stop < 5, "does not pass through, was " + stop);
    }

    @Test
    void sweepAgainstAnAdjacentWallIsZero() {
        assertTrue(FlashingRules.sweep(12, d -> false) < FlashingRules.MIN_JUMP);
    }

    @Test
    void sweepCostIsBounded() {
        AtomicInteger calls = new AtomicInteger();
        FlashingRules.sweep(18, d -> calls.incrementAndGet() < 40);
        assertTrue(calls.get() <= 40 + FlashingRules.SWEEP_REFINE, "calls " + calls.get());
    }
}
