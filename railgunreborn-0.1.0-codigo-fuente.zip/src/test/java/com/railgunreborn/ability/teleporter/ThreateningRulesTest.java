package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha threatening-teleport §11. */
class ThreateningRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costs() {
        assertEquals(35f, ThreateningRules.cp(0f), EPS);
        assertEquals(67.5f, ThreateningRules.cp(0.5f), EPS);
        assertEquals(100f, ThreateningRules.cp(1f), EPS);
        assertEquals(18f, ThreateningRules.overload(0f), EPS);
        assertEquals(14f, ThreateningRules.overload(0.5f), EPS);
        assertEquals(10f, ThreateningRules.overload(1f), EPS);
    }

    @Test
    void rangeAndCooldown() {
        assertEquals(8f, ThreateningRules.range(0f), EPS);
        assertEquals(11.5f, ThreateningRules.range(0.5f), EPS);
        assertEquals(15f, ThreateningRules.range(1f), EPS);
        assertEquals(30, ThreateningRules.cooldownTicks(0f));
        assertEquals(22, ThreateningRules.cooldownTicks(0.5f));
        assertEquals(15, ThreateningRules.cooldownTicks(1f));
    }

    @Test
    void damageAndNeedle() {
        assertEquals(3f, ThreateningRules.baseDamage(0f, false), EPS);
        assertEquals(4.5f, ThreateningRules.baseDamage(0.5f, false), EPS);
        assertEquals(6f, ThreateningRules.baseDamage(1f, false), EPS);
        assertEquals(4.5f, ThreateningRules.baseDamage(0f, true), EPS);
        assertEquals(6.75f, ThreateningRules.baseDamage(0.5f, true), EPS);
        assertEquals(9f, ThreateningRules.baseDamage(1f, true), EPS);
    }
}
