package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/** Fórmulas, recorte y máquina de etapas de Penetrate Teleport ({@code penetrate-teleport.md} §2-§4 y §10). */
class PenetrateRulesTest {
    private static final double EPS = 1e-6;

    /** Mundo sintético: muros en los rangos de bloques X {@code [from, to]} (todas las Y y Z). */
    private static PenetrateRules.FreeCheck wallsAtX(int... ranges) {
        return (x, y, z) -> {
            for (int i = 0; i < ranges.length; i += 2) {
                if (x >= ranges[i] && x <= ranges[i + 1]) {
                    return false;
                }
            }
            return true;
        };
    }

    private static PenetrateRules.Dest alongX(double distance, PenetrateRules.FreeCheck free) {
        return PenetrateRules.findDestination(0.5, 64, 0.5, 1, 0, 0, distance, free);
    }

    @Test
    void formulas() {
        assertEquals(10f, PenetrateRules.maxDistance(0f), 1e-4);
        assertEquals(22.5f, PenetrateRules.maxDistance(0.5f), 1e-4);
        assertEquals(35f, PenetrateRules.maxDistance(1f), 1e-4);
        assertEquals(14f, PenetrateRules.cpPerBlock(0f), 1e-4);
        assertEquals(11.5f, PenetrateRules.cpPerBlock(0.5f), 1e-4);
        assertEquals(9f, PenetrateRules.cpPerBlock(1f), 1e-4);
        assertEquals(80f, PenetrateRules.overload(0f), 1e-4);
        assertEquals(65f, PenetrateRules.overload(0.5f), 1e-4);
        assertEquals(50f, PenetrateRules.overload(1f), 1e-4);
        assertEquals(50, PenetrateRules.cooldownTicks(0f));
        assertEquals(40, PenetrateRules.cooldownTicks(0.5f));
        assertEquals(30, PenetrateRules.cooldownTicks(1f));
    }

    @Test
    void requestedDistanceIsClamped() {
        assertEquals(10, PenetrateRules.clampRequested(100, 0f), EPS);
        assertEquals(0.5, PenetrateRules.clampRequested(-3, 0f), EPS);
        assertEquals(10, PenetrateRules.clampRequested(Double.NaN, 0f), EPS);
        assertEquals(7, PenetrateRules.clampRequested(7, 0f), EPS);
        assertEquals(9, PenetrateRules.wheel(10, -1, 0f), EPS);
        assertEquals(10, PenetrateRules.wheel(10, 1, 0f), EPS);
        assertEquals(0.5, PenetrateRules.wheel(1, -3, 0f), EPS);
    }

    @Test
    void cpLimitsTheDistance() {
        assertEquals(5, PenetrateRules.cpLimited(10, 70f, 14f), EPS);
        assertEquals(10, PenetrateRules.cpLimited(10, 1000f, 14f), EPS);
        assertEquals(0, PenetrateRules.cpLimited(10, 0f, 14f), EPS);
    }

    @Test
    void noWallIsAStraightJumpToTheRequestedDistance() {
        PenetrateRules.Dest dest = alongX(7.3, wallsAtX());
        assertEquals(PenetrateRules.Stage.BEFORE, dest.stage());
        assertTrue(dest.available());
        assertEquals(7.8, dest.x(), EPS);
        assertEquals(7.3, dest.distance(), EPS);
    }

    @Test
    void thinWallExitsAndKeepsAboutFourBlocks() {
        // Muro en X 2-3: la salida es el primer punto en X ≥ 4 (d = 4.0, X 4.5); luego 5 pasos más.
        PenetrateRules.Dest dest = alongX(20, wallsAtX(2, 3));
        assertEquals(PenetrateRules.Stage.AFTER, dest.stage());
        assertTrue(dest.available());
        assertEquals(4.0, dest.exitDistance(), EPS);
        assertEquals(8.0, dest.distance(), EPS);
        assertEquals(8.5, dest.x(), EPS);
    }

    @Test
    void theExtraBlocksNeverPassTheRequestedDistance() {
        PenetrateRules.Dest dest = alongX(5.5, wallsAtX(2, 3));
        assertEquals(PenetrateRules.Stage.AFTER, dest.stage());
        assertEquals(5.5, dest.distance(), EPS);
        assertEquals(6.0, dest.x(), EPS);
    }

    @Test
    void wallThickerThanTheReachIsNotAvailable() {
        PenetrateRules.Dest dest = alongX(6, wallsAtX(2, 20));
        assertEquals(PenetrateRules.Stage.INSIDE, dest.stage());
        assertFalse(dest.available());
    }

    @Test
    void secondWallStopsBeforeItNotInside() {
        // Sale en X 4.5 y el segundo muro empieza en X 6: se queda en el último punto libre (X 5.3).
        PenetrateRules.Dest dest = alongX(20, wallsAtX(2, 3, 6, 7));
        assertEquals(PenetrateRules.Stage.AFTER, dest.stage());
        assertEquals(5.3, dest.x(), EPS);
    }

    @Test
    void negativeCoordinatesUseFloor() {
        List<Integer> seen = new ArrayList<>();
        PenetrateRules.findDestination(-0.5, 64, 0.5, -1, 0, 0, 1.0, (x, y, z) -> {
            seen.add(x);
            return true;
        });
        // X -1.3 y -1.5: con (int) serían -1; con floor, -2.
        assertEquals(List.of(-2, -2), seen);
    }

    @Test
    void zeroDistanceIsNotAvailable() {
        assertFalse(alongX(0, wallsAtX()).available());
    }
}
