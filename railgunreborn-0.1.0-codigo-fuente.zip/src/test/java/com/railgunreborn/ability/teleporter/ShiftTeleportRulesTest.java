package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha shift-teleport §10 y la prueba línea-caja. */
class ShiftTeleportRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costsAndCooldown() {
        assertEquals(260f, ShiftTeleportRules.cpCost(0f), EPS);
        assertEquals(290f, ShiftTeleportRules.cpCost(0.5f), EPS);
        assertEquals(320f, ShiftTeleportRules.cpCost(1f), EPS);
        assertEquals(40f, ShiftTeleportRules.overload(0f), EPS);
        assertEquals(35f, ShiftTeleportRules.overload(0.5f), EPS);
        assertEquals(30f, ShiftTeleportRules.overload(1f), EPS);
        assertEquals(100, ShiftTeleportRules.cooldown(0f));
        assertEquals(80, ShiftTeleportRules.cooldown(0.5f));
        assertEquals(60, ShiftTeleportRules.cooldown(1f));
    }

    @Test
    void damageAndRange() {
        assertEquals(15f, ShiftTeleportRules.damage(0f), EPS);
        assertEquals(25f, ShiftTeleportRules.damage(0.5f), EPS);
        assertEquals(35f, ShiftTeleportRules.damage(1f), EPS);
        assertEquals(25f, ShiftTeleportRules.range(0f), EPS);
        assertEquals(30f, ShiftTeleportRules.range(0.5f), EPS);
        assertEquals(35f, ShiftTeleportRules.range(1f), EPS);
    }

    @Test
    void expOnlyForPlacingAndRealHits() {
        assertEquals(0.002f, ShiftTeleportRules.expGain(true, 0), 1e-7f);
        assertEquals(0.004f, ShiftTeleportRules.expGain(true, 1), 1e-7f);
        assertEquals(0.008f, ShiftTeleportRules.expGain(true, 3), 1e-7f);
        assertEquals(0f, ShiftTeleportRules.expGain(false, 0), 1e-7f);
        assertEquals(0.004f, ShiftTeleportRules.expGain(false, 2), 1e-7f);
    }

    @Test
    void cellFloorsNegatives() {
        assertEquals(3, ShiftTeleportRules.cell(3.7));
        assertEquals(-4, ShiftTeleportRules.cell(-3.2));
        assertEquals(0, ShiftTeleportRules.cell(0.0));
    }

    @Test
    void lineThroughBox() {
        // Caja unidad en (2..3, 0..1, 0..1).
        assertTrue(ShiftTeleportRules.lineHits(0, 0.5, 0.5, 5, 0.5, 0.5, 2, 0, 0, 3, 1, 1));
        // Pasa por encima.
        assertFalse(ShiftTeleportRules.lineHits(0, 1.5, 0.5, 5, 1.5, 0.5, 2, 0, 0, 3, 1, 1));
        // Se queda corta.
        assertFalse(ShiftTeleportRules.lineHits(0, 0.5, 0.5, 1.9, 0.5, 0.5, 2, 0, 0, 3, 1, 1));
        // Diagonal que la cruza.
        assertTrue(ShiftTeleportRules.lineHits(0, 2, 0.5, 5, -1, 0.5, 2, 0, 0, 3, 1, 1));
        // Paralela a un eje, fuera de la franja.
        assertFalse(ShiftTeleportRules.lineHits(2.5, 0.5, 2, 2.5, 5, 2, 2, 0, 0, 3, 1, 1));
        // Segmento de longitud 0 dentro.
        assertTrue(ShiftTeleportRules.lineHits(2.5, 0.5, 0.5, 2.5, 0.5, 0.5, 2, 0, 0, 3, 1, 1));
    }
}
