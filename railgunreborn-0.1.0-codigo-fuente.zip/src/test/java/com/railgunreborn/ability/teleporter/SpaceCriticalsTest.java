package com.railgunreborn.ability.teleporter;

import static com.railgunreborn.ability.teleporter.SpaceCriticals.NONE;
import static com.railgunreborn.ability.teleporter.SpaceCriticals.NOT_LEARNED;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.function.DoubleSupplier;

import org.junit.jupiter.api.Test;

import net.minecraft.util.RandomSource;

class SpaceCriticalsTest {
    private static final float EPS = 1e-4f;

    /** Números fijos; falla si se piden más de los dados. */
    private static DoubleSupplier rolls(double... values) {
        Deque<Double> queue = new ArrayDeque<>();
        for (double v : values) {
            queue.add(v);
        }
        return queue::pop;
    }

    @Test
    void probabilitiesMatchTheSpecTable() {
        assertEquals(0.28f, SpaceCriticals.probability(0, 0f, 0f), EPS);
        assertEquals(0.10f, SpaceCriticals.probability(1, 0f, 0f), EPS);
        assertEquals(0.01f, SpaceCriticals.probability(2, 0f, 0f), EPS);
        assertEquals(0.365f, SpaceCriticals.probability(0, 0.5f, 0.5f), EPS);
        assertEquals(0.125f, SpaceCriticals.probability(1, 0.5f, 0.5f), EPS);
        assertEquals(0.02f, SpaceCriticals.probability(2, 0.5f, 0.5f), EPS);
        assertEquals(0.45f, SpaceCriticals.probability(0, 1f, 1f), EPS);
        assertEquals(0.15f, SpaceCriticals.probability(1, 1f, 1f), EPS);
        assertEquals(0.03f, SpaceCriticals.probability(2, 1f, 1f), EPS);
    }

    @Test
    void unlearnedPassiveContributesNothing() {
        for (int tier = 0; tier < 3; tier++) {
            assertEquals(0f, SpaceCriticals.probability(tier, NOT_LEARNED, NOT_LEARNED), EPS);
        }
        // Solo Dim Folding: 10-20 % de ×1.3 y nada más.
        assertEquals(0.10f, SpaceCriticals.probability(0, 0f, NOT_LEARNED), EPS);
        assertEquals(0.20f, SpaceCriticals.probability(0, 1f, NOT_LEARNED), EPS);
        assertEquals(0f, SpaceCriticals.probability(1, 1f, NOT_LEARNED), EPS);
        assertEquals(0f, SpaceCriticals.probability(2, 1f, NOT_LEARNED), EPS);
        // Solo Space Fluctuation: la parte base de ×1.3 sí cuenta.
        assertEquals(0.18f, SpaceCriticals.probability(0, NOT_LEARNED, 0f), EPS);
        assertEquals(0.269f, SpaceCriticals.totalProbability(NOT_LEARNED, 0f), 1e-3f);
        assertEquals(0.382f, SpaceCriticals.totalProbability(NOT_LEARNED, 1f), 1e-3f);
    }

    @Test
    void totalsAndExpectedMultiplierMatchTheSpec() {
        assertEquals(0.358f, SpaceCriticals.totalProbability(0f, 0f), 1e-3f);
        assertEquals(0.455f, SpaceCriticals.totalProbability(0.5f, 0.5f), 1e-3f);
        assertEquals(0.547f, SpaceCriticals.totalProbability(1f, 1f), 1e-3f);
        assertEquals(1.14f, SpaceCriticals.expectedMultiplier(0f, 0f), 5e-3f);
        assertEquals(1.21f, SpaceCriticals.expectedMultiplier(1f, 1f), 5e-3f);
        assertEquals(0.014f, SpaceCriticals.effectiveProbability(2, 1f, 1f), 1e-3f);
    }

    @Test
    void rollsInOrderAndStopsAtTheFirstHit() {
        // Exp 1 en ambas: p = 0.45, 0.15, 0.03.
        assertEquals(0, SpaceCriticals.roll(rolls(0.44), 1f, 1f));
        assertEquals(1, SpaceCriticals.roll(rolls(0.9, 0.1), 1f, 1f));
        assertEquals(2, SpaceCriticals.roll(rolls(0.9, 0.9, 0.02), 1f, 1f));
        assertEquals(NONE, SpaceCriticals.roll(rolls(0.9, 0.9, 0.5), 1f, 1f));
        // Un número bajo en el nivel 2 no sirve si el 1 ya salió (no se acumulan).
        assertEquals(0, SpaceCriticals.roll(rolls(0.0, 0.0, 0.0), 1f, 1f));
    }

    @Test
    void noPassivesMeansNoCriticalAndNoRolls() {
        assertEquals(NONE, SpaceCriticals.roll(rolls(), NOT_LEARNED, NOT_LEARNED));
    }

    @Test
    void onlyDimFoldingNeverGivesHigherTiers() {
        assertEquals(NONE, SpaceCriticals.roll(rolls(0.5, 0.0, 0.0), 1f, NOT_LEARNED));
    }

    @Test
    void ratesAndGains() {
        assertEquals(1f, SpaceCriticals.rate(NONE));
        assertEquals(List.of("1.3", "1.6", "2.6"),
                List.of(SpaceCriticals.formatRate(0), SpaceCriticals.formatRate(1), SpaceCriticals.formatRate(2)));
        assertEquals(0.005f, SpaceCriticals.dimFoldingExpGain(0), 1e-6f);
        assertEquals(0.010f, SpaceCriticals.dimFoldingExpGain(1), 1e-6f);
        assertEquals(0.015f, SpaceCriticals.dimFoldingExpGain(2), 1e-6f);
        assertEquals(0.001f, SpaceCriticals.SPACE_FLUCT_EXP_GAIN, 1e-7f);
    }

    @Test
    void seededRandomIsReproducibleAndRoughlyMatchesTheRates() {
        int[] counts = new int[4];
        RandomSource a = RandomSource.create(1234L);
        RandomSource b = RandomSource.create(1234L);
        int n = 20000;
        for (int i = 0; i < n; i++) {
            int tier = SpaceCriticals.roll(a, 1f, 1f);
            assertEquals(tier, SpaceCriticals.roll(b, 1f, 1f));
            counts[tier + 1]++;
        }
        assertEquals(0.45, counts[1] / (double) n, 0.02);
        assertEquals(0.0825, counts[2] / (double) n, 0.01);
        assertEquals(0.014, counts[3] / (double) n, 0.005);
    }
}
