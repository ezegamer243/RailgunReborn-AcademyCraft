package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.teleporter.LocationTeleportRules.Problem;

class LocationTeleportRulesTest {
    private static final double EPS = 1e-3;

    @Test
    void costReferenceValues() {
        // Tabla §2 y §10 de la ficha.
        assertEquals(1600, LocationTeleportRules.cpCost(0f, 10, false), EPS);
        assertEquals(1200, LocationTeleportRules.cpCost(1f, 64, false), EPS);
        assertEquals(4000, LocationTeleportRules.cpCost(0f, 400, false), EPS);
        assertEquals(3000, LocationTeleportRules.cpCost(1f, 400, false), EPS);
        assertEquals(200 * Math.sqrt(800), LocationTeleportRules.cpCost(0f, 800, false), EPS);
        assertEquals(200 * Math.sqrt(800), LocationTeleportRules.cpCost(0f, 1_000_000, false), EPS);
        assertEquals(3200, LocationTeleportRules.cpCost(0f, 10, true), EPS);
        assertEquals(8000, LocationTeleportRules.cpCost(0f, 400, true), EPS);
        assertEquals(175 * 8, LocationTeleportRules.cpCost(0.5f, 0, false), EPS);
    }

    @Test
    void overloadCooldownAndExp() {
        assertEquals(240f, LocationTeleportRules.overload());
        assertEquals(30, LocationTeleportRules.cooldown(0f));
        assertEquals(25, LocationTeleportRules.cooldown(0.5f));
        assertEquals(20, LocationTeleportRules.cooldown(1f));
        assertEquals(0.015f, LocationTeleportRules.expGain(5));
        assertEquals(0.015f, LocationTeleportRules.expGain(199.9));
        assertEquals(0.03f, LocationTeleportRules.expGain(200));
    }

    @Test
    void crossingDimensionNeedsMoreThan08() {
        assertFalse(LocationTeleportRules.canCrossDimension(0.8f));
        assertTrue(LocationTeleportRules.canCrossDimension(0.81f));
        assertEquals(Problem.CROSS_DIMENSION_EXP, LocationTeleportRules.check(true, true, 0.8f, true));
        // La dimensión se comprueba antes que el CP.
        assertEquals(Problem.CROSS_DIMENSION_EXP, LocationTeleportRules.check(true, true, 0.5f, false));
        assertEquals(Problem.CP, LocationTeleportRules.check(true, true, 0.9f, false));
        assertEquals(Problem.NONE, LocationTeleportRules.check(true, false, 0f, true));
        assertEquals(Problem.MISSING_DIMENSION, LocationTeleportRules.check(false, false, 1f, true));
    }

    @Test
    void capOf16() {
        assertTrue(LocationTeleportRules.canAdd(0));
        assertTrue(LocationTeleportRules.canAdd(15));
        assertFalse(LocationTeleportRules.canAdd(16));
        assertFalse(LocationTeleportRules.canAdd(17));
        assertTrue(LocationTeleportRules.isValidIndex(0, 1));
        assertFalse(LocationTeleportRules.isValidIndex(1, 1));
        assertFalse(LocationTeleportRules.isValidIndex(-1, 3));
    }

    @Test
    void nameIsSanitized() {
        assertEquals("Home", LocationTeleportRules.sanitizeName("  Home  "));
        assertEquals("", LocationTeleportRules.sanitizeName("   "));
        assertEquals("", LocationTeleportRules.sanitizeName(null));
        assertEquals("cRedBase", LocationTeleportRules.sanitizeName("§cRed\u0007Base\n"));
        assertEquals("abcdefghijklmnop", LocationTeleportRules.sanitizeName("abcdefghijklmnopqrstuvwxyz"));
        // Corta por puntos de código: 16 emojis enteros, sin medio par suplente.
        String emojis = "😀".repeat(20);
        String cut = LocationTeleportRules.sanitizeName(emojis);
        assertEquals(16, cut.codePointCount(0, cut.length()));
        assertEquals("😀".repeat(16), cut);
        // Si al cortar queda un espacio al final, se quita.
        assertEquals("fifteen chars ab", LocationTeleportRules.sanitizeName("fifteen chars ab c"));
        assertEquals("abcdefghijklmno", LocationTeleportRules.sanitizeName("abcdefghijklmno x"));
    }

    @Test
    void whoTravels() {
        // Jugadores y hostiles, nunca; aunque vayan montados o atados.
        assertFalse(LocationTeleportRules.canCarry(true, false, false, false, true, 0.6, 1.8));
        assertFalse(LocationTeleportRules.canCarry(false, true, true, true, true, 0.6, 1.95));
        // Mascota propia, atado o montado, sí.
        assertTrue(LocationTeleportRules.canCarry(false, false, true, false, false, 0.6, 0.85));
        assertTrue(LocationTeleportRules.canCarry(false, false, false, true, false, 0.9, 1.4));
        assertTrue(LocationTeleportRules.canCarry(false, false, false, false, true, 1.4, 1.6));
        // Un animal cualquiera cerca, no.
        assertFalse(LocationTeleportRules.canCarry(false, false, false, false, false, 0.9, 0.9));
        // Lo enorme se queda.
        assertFalse(LocationTeleportRules.canCarry(false, false, true, false, false, 16, 8));
    }

    @Test
    void searchStartsAtTheExactSpotAndIsUnique() {
        List<int[]> offsets = LocationTeleportRules.searchOffsets();
        assertEquals(0, offsets.get(0)[0]);
        assertEquals(0, offsets.get(0)[1]);
        assertEquals(0, offsets.get(0)[2]);
        assertEquals(1, offsets.get(1)[1]);
        Set<String> seen = new HashSet<>();
        for (int[] o : offsets) {
            assertTrue(seen.add(o[0] + "," + o[1] + "," + o[2]));
            assertTrue(Math.abs(o[0]) <= LocationTeleportRules.SEARCH_RADIUS);
            assertTrue(Math.abs(o[2]) <= LocationTeleportRules.SEARCH_RADIUS);
        }
        assertEquals(9 * 4, offsets.size());
    }
}
