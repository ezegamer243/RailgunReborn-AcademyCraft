package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha flesh-ripping §10. */
class FleshRippingRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costs() {
        assertEquals(130f, FleshRippingRules.cp(0f), EPS);
        assertEquals(200f, FleshRippingRules.cp(0.5f), EPS);
        assertEquals(270f, FleshRippingRules.cp(1f), EPS);
        assertEquals(60f, FleshRippingRules.overload(0f), EPS);
        assertEquals(55f, FleshRippingRules.overload(0.5f), EPS);
        assertEquals(50f, FleshRippingRules.overload(1f), EPS);
    }

    @Test
    void rangeDamageAndCooldown() {
        assertEquals(6f, FleshRippingRules.range(0f), EPS);
        assertEquals(10f, FleshRippingRules.range(0.5f), EPS);
        assertEquals(14f, FleshRippingRules.range(1f), EPS);
        assertEquals(5f, FleshRippingRules.damage(0f), EPS);
        assertEquals(8.5f, FleshRippingRules.damage(0.5f), EPS);
        assertEquals(12f, FleshRippingRules.damage(1f), EPS);
        assertEquals(90, FleshRippingRules.cooldownTicks(0f));
        assertEquals(65, FleshRippingRules.cooldownTicks(0.5f));
        assertEquals(40, FleshRippingRules.cooldownTicks(1f));
    }

    @Test
    void disgustThreshold() {
        assertTrue(FleshRippingRules.disgusted(0.0));
        assertTrue(FleshRippingRules.disgusted(0.049));
        assertFalse(FleshRippingRules.disgusted(0.051));
        assertFalse(FleshRippingRules.disgusted(0.99));
        assertEquals(100, FleshRippingRules.DISGUST_TICKS);
        assertEquals(0.005f, FleshRippingRules.EXP_HIT, EPS);
    }
}
