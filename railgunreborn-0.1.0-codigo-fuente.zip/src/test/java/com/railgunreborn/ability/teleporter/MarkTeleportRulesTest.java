package com.railgunreborn.ability.teleporter;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class MarkTeleportRulesTest {
    private static final double EPS = 1e-6;

    @Test
    void referenceValues() {
        // Tabla §11 de la ficha.
        assertEquals(25, MarkTeleportRules.maxRange(0f), EPS);
        assertEquals(42.5, MarkTeleportRules.maxRange(0.5f), EPS);
        assertEquals(60, MarkTeleportRules.maxRange(1f), EPS);
        assertEquals(12f, MarkTeleportRules.cpPerBlock(0f), EPS);
        assertEquals(8f, MarkTeleportRules.cpPerBlock(0.5f), EPS);
        assertEquals(4f, MarkTeleportRules.cpPerBlock(1f), EPS);
        assertEquals(40f, MarkTeleportRules.overload(0f), EPS);
        assertEquals(30f, MarkTeleportRules.overload(0.5f), EPS);
        assertEquals(20f, MarkTeleportRules.overload(1f), EPS);
        assertEquals(30, MarkTeleportRules.cooldown(0f));
        assertEquals(15, MarkTeleportRules.cooldown(0.5f));
        assertEquals(0, MarkTeleportRules.cooldown(1f));
    }

    @Test
    void rangeGrowsTwoBlocksPerTickUpToTheMaximum() {
        double plenty = 1e9;
        assertEquals(2, MarkTeleportRules.rangeNow(0f, 0, plenty), EPS);
        assertEquals(4, MarkTeleportRules.rangeNow(0f, 1, plenty), EPS);
        assertEquals(6, MarkTeleportRules.rangeNow(0f, 2, plenty), EPS);
        assertEquals(24, MarkTeleportRules.rangeNow(0f, 11, plenty), EPS);
        assertEquals(25, MarkTeleportRules.rangeNow(0f, 12, plenty), EPS);
        assertEquals(25, MarkTeleportRules.rangeNow(0f, 100, plenty), EPS);
        assertEquals(60, MarkTeleportRules.rangeNow(1f, 100, plenty), EPS);
    }

    @Test
    void rangeIsLimitedByAvailableCp() {
        // 48 CP a 12 por bloque: 4 bloques.
        assertEquals(4, MarkTeleportRules.rangeNow(0f, 20, 48), EPS);
        assertEquals(0, MarkTeleportRules.rangeNow(0f, 20, 0), EPS);
    }

    @Test
    void ticksToMaxRangeMatchesTheTable() {
        assertEquals(12, MarkTeleportRules.ticksToMaxRange(0f));
        assertEquals(21, MarkTeleportRules.ticksToMaxRange(0.5f));
        assertEquals(29, MarkTeleportRules.ticksToMaxRange(1f));
        for (float exp : new float[] {0f, 0.3f, 0.5f, 1f}) {
            int t = MarkTeleportRules.ticksToMaxRange(exp);
            assertEquals(MarkTeleportRules.maxRange(exp), MarkTeleportRules.rangeNow(exp, t, 1e9), EPS);
            assertTrue(MarkTeleportRules.rangeNow(exp, t - 1, 1e9) < MarkTeleportRules.maxRange(exp));
        }
    }

    @Test
    void costIsPerBlockButNeverMoreThanAvailable() {
        assertEquals(72f, MarkTeleportRules.cpCost(0f, 6, 1000), 1e-4);
        assertEquals(240f, MarkTeleportRules.cpCost(1f, 60, 1000), 1e-4);
        assertEquals(50f, MarkTeleportRules.cpCost(0f, 6, 50), 1e-4);
    }

    @Test
    void expAndMinimumDistance() {
        assertEquals(0.0045f, MarkTeleportRules.expGain(25), 1e-7);
        assertEquals(0.0108f, MarkTeleportRules.expGain(60), 1e-7);
        assertFalse(MarkTeleportRules.farEnough(2.99));
        assertTrue(MarkTeleportRules.farEnough(3.0));
    }

    @Test
    void sideFaceOffsetsFromTheWall() {
        // Cara norte (normal -Z) del bloque en y = 5.
        double[] feet = MarkTeleportRules.sideDestination(10.3, 20.0, 0, -1, 5);
        assertArrayEquals(new double[] {10.3, 6.7, 19.4}, feet, EPS);
        // Cara este (normal +X).
        assertArrayEquals(new double[] {-3.4, 1.7, 7.5}, MarkTeleportRules.sideDestination(-4.0, 7.5, 1, 0, 0), EPS);
    }

    @Test
    void sideHeadCheckUsesFloorAndDropsWhenBlocked() {
        assertArrayEquals(new int[] {-4, 2, 7}, MarkTeleportRules.sideHeadPos(new double[] {-3.4, 1.7, 7.5}));
        assertEquals(6.7, MarkTeleportRules.sideHeadAdjust(6.7, false), EPS);
        assertEquals(5.45, MarkTeleportRules.sideHeadAdjust(6.7, true), EPS);
    }

    @Test
    void ceilingKeepsTheHeadBelow() {
        double feet = MarkTeleportRules.ceilingFeetY(10.0, 1.8);
        assertTrue(feet + 1.8 < 10.0);
        assertEquals(8.15, feet, EPS);
    }
}
