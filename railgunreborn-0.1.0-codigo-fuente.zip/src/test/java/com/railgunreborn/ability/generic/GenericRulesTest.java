package com.railgunreborn.ability.generic;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.EnumSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.generic.GenericRules.Kind;

/** Valores de la ficha generic-skills §6 y decisiones del port (Brain Course Advanced suma 1500). */
class GenericRulesTest {
    private static final float EPS = 1e-3f;

    @Test
    void nothingLearnedChangesNothing() {
        Set<Kind> none = EnumSet.noneOf(Kind.class);
        assertEquals(0f, GenericRules.maxCpBonus(none), EPS);
        assertEquals(0f, GenericRules.maxOverloadBonus(none), EPS);
        assertEquals(1f, GenericRules.cpRecoverFactor(none), EPS);
    }

    @Test
    void bonusesAccumulate() {
        assertEquals(1000f, GenericRules.maxCpBonus(EnumSet.of(Kind.BRAIN_COURSE)), EPS);
        assertEquals(0f, GenericRules.maxOverloadBonus(EnumSet.of(Kind.BRAIN_COURSE)), EPS);
        Set<Kind> both = EnumSet.of(Kind.BRAIN_COURSE, Kind.BRAIN_COURSE_ADVANCED);
        assertEquals(2500f, GenericRules.maxCpBonus(both), EPS);
        assertEquals(100f, GenericRules.maxOverloadBonus(both), EPS);
    }

    @Test
    void mindCourseOnlyAffectsRecovery() {
        Set<Kind> mind = EnumSet.of(Kind.MIND_COURSE);
        assertEquals(1.2f, GenericRules.cpRecoverFactor(mind), EPS);
        assertEquals(0f, GenericRules.maxCpBonus(mind), EPS);
        assertEquals(0f, GenericRules.maxOverloadBonus(mind), EPS);
    }

    @Test
    void levelsMatchTheCondition() {
        assertEquals(3, Kind.BRAIN_COURSE.level());
        assertEquals(4, Kind.BRAIN_COURSE_ADVANCED.level());
        assertEquals(5, Kind.MIND_COURSE.level());
    }
}
