package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha thunderclap §12 y decisiones del port. */
class ThunderclapRulesTest {
    private static final float EPS = 1e-3f;

    @Test
    void costs() {
        assertEquals(390f, ThunderclapRules.overloadCost(0f), EPS);
        assertEquals(321f, ThunderclapRules.overloadCost(0.5f), EPS);
        assertEquals(252f, ThunderclapRules.overloadCost(1f), EPS);
        assertEquals(18f, ThunderclapRules.cpPerTick(0f), EPS);
        assertEquals(21.5f, ThunderclapRules.cpPerTick(0.5f), EPS);
        assertEquals(25f, ThunderclapRules.cpPerTick(1f), EPS);
        assertTrue(ThunderclapRules.paysCp(1));
        assertTrue(ThunderclapRules.paysCp(40));
        assertFalse(ThunderclapRules.paysCp(41));
    }

    @Test
    void chargeMultiplierGoesFrom1To1067() {
        assertEquals(1.0f, ThunderclapRules.chargeMultiplier(40), 1e-5f);
        assertEquals(1.0333f, ThunderclapRules.chargeMultiplier(50), 1e-4f);
        assertEquals(1.0667f, ThunderclapRules.chargeMultiplier(60), 1e-4f);
    }

    @Test
    void centerDamageAtFullCharge() {
        assertEquals(38.4f, ThunderclapRules.centerDamage(0f, 60), EPS);
        assertEquals(57.6f, ThunderclapRules.centerDamage(0.5f, 60), EPS);
        assertEquals(76.8f, ThunderclapRules.centerDamage(1f, 60), EPS);
        assertEquals(36f, ThunderclapRules.centerDamage(0f, 40), EPS);
    }

    @Test
    void radiusAndLinearFalloff() {
        assertEquals(15.0, ThunderclapRules.radius(0f), 1e-6);
        assertEquals(22.5, ThunderclapRules.radius(0.5f), 1e-6);
        assertEquals(30.0, ThunderclapRules.radius(1f), 1e-6);
        assertEquals(1f, ThunderclapRules.falloff(0, 15), 1e-6f);
        assertEquals(0.5f, ThunderclapRules.falloff(7.5, 15), 1e-6f);
        assertEquals(0f, ThunderclapRules.falloff(15, 15), 1e-6f);
        assertEquals(0f, ThunderclapRules.falloff(40, 15), 1e-6f);
        // Mitad del radio a 60 ticks (tabla §12).
        assertEquals(19.2f, ThunderclapRules.damageAt(0f, 60, 7.5), EPS);
        assertEquals(38.4f, ThunderclapRules.damageAt(1f, 60, 15), EPS);
    }

    @Test
    void cooldownDependsOnChargeTicks() {
        assertEquals(600, ThunderclapRules.cooldownTicks(0f, 60));
        assertEquals(480, ThunderclapRules.cooldownTicks(0.5f, 60));
        assertEquals(360, ThunderclapRules.cooldownTicks(1f, 60));
        assertEquals(400, ThunderclapRules.cooldownTicks(0f, 40));
        assertEquals(500, ThunderclapRules.cooldownTicks(0f, 50));
    }

    @Test
    void releaseFiresFromFortyTicks() {
        assertFalse(ThunderclapRules.releaseFires(0));
        assertFalse(ThunderclapRules.releaseFires(39));
        assertTrue(ThunderclapRules.releaseFires(40));
        assertTrue(ThunderclapRules.releaseFires(60));
    }

    @Test
    void speedFactorDropsTo1Percent() {
        assertEquals(1.0, ThunderclapRules.speedFactor(0), 1e-9);
        assertEquals(0.34, ThunderclapRules.speedFactor(40), 1e-9);
        assertEquals(0.01, ThunderclapRules.speedFactor(60), 1e-9);
        assertEquals(0.01, ThunderclapRules.speedFactor(100), 1e-9);
        assertEquals(-0.99, ThunderclapRules.speedModifierAmount(60), 1e-9);
    }

    @Test
    void rippleRings() {
        assertEquals(0.0, ThunderclapRules.ripplePhase(0, 0), 1e-9);
        assertEquals(1.2, ThunderclapRules.ripplePhase(0, 1), 1e-9);
        assertEquals(0.4, ThunderclapRules.ripplePhase(4.0, 0), 1e-9);
        assertEquals(1.9, ThunderclapRules.rippleSize(0), 1e-9);
        assertEquals(1.4, ThunderclapRules.rippleSize(3.6), 1e-9);
        assertEquals(0.0, ThunderclapRules.rippleAlpha(0), 1e-9);
        assertEquals(1.0, ThunderclapRules.rippleAlpha(1.8), 1e-9);
        assertEquals(0.5, ThunderclapRules.rippleAlpha(2.8), 1e-9);
    }
}
