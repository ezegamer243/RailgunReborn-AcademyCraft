package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.electromaster.ArcGenRules.BlockAction;
import com.railgunreborn.ability.electromaster.ArcGenRules.HitKind;

class ArcGenRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void cpCostInterpolatesFrom30To70() {
        assertEquals(30f, ArcGenRules.cpCost(0f), EPS);
        assertEquals(50f, ArcGenRules.cpCost(0.5f), EPS);
        assertEquals(70f, ArcGenRules.cpCost(1f), EPS);
    }

    @Test
    void overloadCostInterpolatesFrom18To11() {
        assertEquals(18f, ArcGenRules.overloadCost(0f), EPS);
        assertEquals(14.5f, ArcGenRules.overloadCost(0.5f), EPS);
        assertEquals(11f, ArcGenRules.overloadCost(1f), EPS);
    }

    @Test
    void rangeInterpolatesFrom6To15() {
        assertEquals(6f, ArcGenRules.range(0f), EPS);
        assertEquals(10.5f, ArcGenRules.range(0.5f), EPS);
        assertEquals(15f, ArcGenRules.range(1f), EPS);
    }

    @Test
    void baseDamageInterpolatesFrom5To9() {
        assertEquals(5f, ArcGenRules.baseDamage(0f), EPS);
        assertEquals(7f, ArcGenRules.baseDamage(0.5f), EPS);
        assertEquals(9f, ArcGenRules.baseDamage(1f), EPS);
    }

    @Test
    void cooldownTicksFrom15To5() {
        assertEquals(15, ArcGenRules.cooldownTicks(0f));
        assertEquals(10, ArcGenRules.cooldownTicks(0.5f));
        assertEquals(5, ArcGenRules.cooldownTicks(1f));
    }

    @Test
    void igniteProbFrom0To06() {
        assertEquals(0.0, ArcGenRules.igniteProb(0f), EPS);
        assertEquals(0.3, ArcGenRules.igniteProb(0.5f), EPS);
        assertEquals(0.6, ArcGenRules.igniteProb(1f), EPS);
    }

    @Test
    void fishProbOnlyAboveHalfExp() {
        assertEquals(0.0, ArcGenRules.fishProb(0f));
        assertEquals(0.0, ArcGenRules.fishProb(0.5f));
        assertEquals(0.0, ArcGenRules.fishProb(0.4999f));
        assertEquals(0.1, ArcGenRules.fishProb(0.5001f));
        assertEquals(0.1, ArcGenRules.fishProb(1f));
    }

    @Test
    void expGainEntityAndBlock() {
        assertEquals(0.0048f, ArcGenRules.expGain(HitKind.ENTITY, 0f), EPS);
        assertEquals(0.0060f, ArcGenRules.expGain(HitKind.ENTITY, 0.5f), EPS);
        assertEquals(0.0072f, ArcGenRules.expGain(HitKind.ENTITY, 1f), EPS);
        assertEquals(0.0018f, ArcGenRules.expGain(HitKind.BLOCK, 0f), EPS);
        assertEquals(0.00225f, ArcGenRules.expGain(HitKind.BLOCK, 0.5f), EPS);
        assertEquals(0.0027f, ArcGenRules.expGain(HitKind.BLOCK, 1f), EPS);
    }

    @Test
    void missGivesNoExp() {
        for (float e : new float[] {0f, 0.5f, 1f}) {
            assertEquals(0f, ArcGenRules.expGain(HitKind.MISS, e));
        }
    }

    @Test
    void waterNeverIgnites() {
        float[] exps = {0f, 0.25f, 0.5f, 0.75f, 1f};
        double[] rolls = {0.0, 0.05, 0.3, 0.59, 0.99};
        for (float e : exps) {
            for (double r : rolls) {
                assertTrue(ArcGenRules.blockAction(true, e, r) != BlockAction.IGNITE,
                        "water ignited at exp=" + e + " roll=" + r);
            }
        }
    }

    @Test
    void fishOnlyWhenExpAboveHalf() {
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(true, 0.5f, 0.0));
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(true, 0f, 0.0));
        assertEquals(BlockAction.DROP_FISH, ArcGenRules.blockAction(true, 0.9f, 0.0));
        assertEquals(BlockAction.DROP_FISH, ArcGenRules.blockAction(true, 0.9f, 0.0999));
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(true, 0.9f, 0.1));
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(true, 0.9f, 0.99));
    }

    @Test
    void igniteRollBoundaries() {
        // exp 0: probabilidad 0, nunca prende (ni con roll 0).
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(false, 0f, 0.0));
        // exp 1: probabilidad 0.6, el borde es exclusivo.
        assertEquals(BlockAction.IGNITE, ArcGenRules.blockAction(false, 1f, 0.0));
        assertEquals(BlockAction.IGNITE, ArcGenRules.blockAction(false, 1f, 0.5999));
        // La probabilidad es float (0.6f = 0.60000002...), por eso el primer roll que falla es algo mayor que 0.6.
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(false, 1f, 0.6001));
        assertEquals(BlockAction.NONE, ArcGenRules.blockAction(false, 1f, 0.9999));
    }

    @Test
    void creeperChargeBoundaries() {
        assertTrue(ArcGenRules.shouldChargeCreeper(0.0));
        assertTrue(ArcGenRules.shouldChargeCreeper(0.2999));
        assertFalse(ArcGenRules.shouldChargeCreeper(0.3));
        assertFalse(ArcGenRules.shouldChargeCreeper(0.9999));
    }

    @Test
    void protectedPlayerGivesNoExp() {
        assertEquals(0f, ArcGenRules.expGain(ArcGenRules.HitKind.PROTECTED_PLAYER, 0f));
        assertEquals(0f, ArcGenRules.expGain(ArcGenRules.HitKind.PROTECTED_PLAYER, 1f));
    }

    @Test
    void playerDamageNeedsBothFlags() {
        assertTrue(ArcGenRules.canDamagePlayer(true, true));
        assertFalse(ArcGenRules.canDamagePlayer(true, false));
        assertFalse(ArcGenRules.canDamagePlayer(false, true));
        assertFalse(ArcGenRules.canDamagePlayer(false, false));
    }
}
