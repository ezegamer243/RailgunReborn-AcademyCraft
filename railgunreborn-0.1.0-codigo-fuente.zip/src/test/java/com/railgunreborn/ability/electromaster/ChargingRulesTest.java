package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import net.neoforged.neoforge.energy.EnergyStorage;

class ChargingRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void overloadCostInterpolatesFrom65To48() {
        assertEquals(65f, ChargingRules.overloadCost(0f), EPS);
        assertEquals(56.5f, ChargingRules.overloadCost(0.5f), EPS);
        assertEquals(48f, ChargingRules.overloadCost(1f), EPS);
    }

    @Test
    void cpPerTickInterpolatesFrom3To7() {
        assertEquals(3f, ChargingRules.cpPerTick(0f), EPS);
        assertEquals(5f, ChargingRules.cpPerTick(0.5f), EPS);
        assertEquals(7f, ChargingRules.cpPerTick(1f), EPS);
    }

    @Test
    void chargePerTickIsFlooredFrom15To35() {
        assertEquals(15, ChargingRules.chargePerTick(0f));
        assertEquals(16, ChargingRules.chargePerTick(0.07f)); // 16.4
        assertEquals(25, ChargingRules.chargePerTick(0.5f));
        assertEquals(34, ChargingRules.chargePerTick(0.99f)); // 34.8
        assertEquals(35, ChargingRules.chargePerTick(1f));
    }

    @Test
    void expRatesMatchOriginal() {
        assertEquals(0.0001f, ChargingRules.expGain(true), 1e-9f);
        assertEquals(0.00003f, ChargingRules.expGain(false), 1e-9f);
        // Sin objetivo, de 0 a 1 son ~33 333 ticks (~27.8 min), como dice la ficha.
        assertEquals(33_333, (int) (1f / ChargingRules.EXP_IDLE), 1);
    }

    @Test
    void chargesStorageWithinItsLimits() {
        EnergyStorage storage = new EnergyStorage(1000, 20);
        assertTrue(ChargingRules.charge(storage, 35));
        // El almacén solo acepta 20 por tick: el resto se pierde.
        assertEquals(20, storage.getEnergyStored());
        assertTrue(ChargingRules.charge(storage, 15));
        assertEquals(35, storage.getEnergyStored());
    }

    @Test
    void fullStorageStillCountsAsEffective() {
        EnergyStorage storage = new EnergyStorage(10, 100, 100, 10);
        assertTrue(ChargingRules.charge(storage, 15));
        assertEquals(10, storage.getEnergyStored());
    }

    @Test
    void nothingToChargeIsNotEffective() {
        assertFalse(ChargingRules.charge(null, 15));
        // Solo extrae (maxReceive 0): no se puede cargar.
        EnergyStorage outputOnly = new EnergyStorage(100, 0, 10, 0);
        assertFalse(ChargingRules.charge(outputOnly, 15));
        assertEquals(0, outputOnly.getEnergyStored());
    }
}
