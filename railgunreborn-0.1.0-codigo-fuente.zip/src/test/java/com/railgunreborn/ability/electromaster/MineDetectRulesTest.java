package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class MineDetectRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costsFollowTheSpec() {
        assertEquals(1500f, MineDetectRules.cpCost(0f), EPS);
        assertEquals(1250f, MineDetectRules.cpCost(0.5f), EPS);
        assertEquals(1000f, MineDetectRules.cpCost(1f), EPS);
        assertEquals(200f, MineDetectRules.overloadCost(0f), EPS);
        assertEquals(190f, MineDetectRules.overloadCost(0.5f), EPS);
        assertEquals(180f, MineDetectRules.overloadCost(1f), EPS);
    }

    @Test
    void cooldownFollowsTheSpec() {
        assertEquals(900, MineDetectRules.cooldownTicks(0f));
        assertEquals(650, MineDetectRules.cooldownTicks(0.5f));
        assertEquals(400, MineDetectRules.cooldownTicks(1f));
        // Primer uso: la exp ya sumada (0.008) baja el cooldown a 896.
        assertEquals(896, MineDetectRules.cooldownTicks(MineDetectRules.EXP_GAIN));
    }

    @Test
    void rangeIsClippedOnTheClient() {
        assertEquals(15f, MineDetectRules.range(0f), EPS);
        assertEquals(22.5f, MineDetectRules.range(0.5f), EPS);
        assertEquals(30f, MineDetectRules.range(1f), EPS);
        assertEquals(22.5f, MineDetectRules.clientRange(22.5f), EPS);
        assertEquals(28f, MineDetectRules.clientRange(30f), EPS);
        assertEquals(0f, MineDetectRules.clientRange(-3f), EPS);
    }

    @Test
    void advancedNeedsExpAboveHalfAndLevelFour() {
        assertFalse(MineDetectRules.isAdvanced(0.5f, 4));
        assertFalse(MineDetectRules.isAdvanced(0.9f, 3));
        assertTrue(MineDetectRules.isAdvanced(0.51f, 4));
        assertTrue(MineDetectRules.isAdvanced(1f, 5));
    }

    @Test
    void colorsByToolTier() {
        for (int tier = 0; tier <= 3; tier++) {
            assertEquals(0, MineDetectRules.colorIndex(false, tier));
        }
        assertEquals(1, MineDetectRules.colorIndex(true, MineDetectRules.TOOL_NONE));
        assertEquals(2, MineDetectRules.colorIndex(true, MineDetectRules.TOOL_STONE));
        assertEquals(3, MineDetectRules.colorIndex(true, MineDetectRules.TOOL_IRON));
        assertEquals(4, MineDetectRules.colorIndex(true, MineDetectRules.TOOL_DIAMOND));
        assertEquals(0x73C8E3, MineDetectRules.color(0));
        assertEquals(0xA1B5BC, MineDetectRules.color(1));
        assertEquals(0x57E7F8, MineDetectRules.color(2));
        assertEquals(0x61CC5E, MineDetectRules.color(3));
        assertEquals(0xEB6D54, MineDetectRules.color(4));
    }

    @Test
    void alphaFadesWithDistanceButStaysVisible() {
        assertEquals(1f, MineDetectRules.alpha(0, 20f), EPS);
        assertEquals(0.3f, MineDetectRules.alpha(10, 22f), EPS); // range / 2.2
        assertEquals(MineDetectRules.MIN_ALPHA, MineDetectRules.alpha(14, 20f), EPS); // donde el original llegaba a 0
        assertEquals(MineDetectRules.MIN_ALPHA, MineDetectRules.alpha(20, 20f), EPS); // en el borde no da la vuelta
        assertTrue(MineDetectRules.alpha(3, 20f) > MineDetectRules.alpha(6, 20f));
    }
}
