package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;

import org.junit.jupiter.api.Test;

import net.minecraft.util.RandomSource;

class BodyIntensifyRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void costsInterpolate() {
        assertEquals(200f, BodyIntensifyRules.overloadCost(0f), EPS);
        assertEquals(120f, BodyIntensifyRules.overloadCost(1f), EPS);
        assertEquals(20f, BodyIntensifyRules.cpPerTick(0f), EPS);
        assertEquals(17.5f, BodyIntensifyRules.cpPerTick(0.5f), EPS);
        assertEquals(15f, BodyIntensifyRules.cpPerTick(1f), EPS);
        assertEquals(900, BodyIntensifyRules.cooldownTicks(0f));
        assertEquals(750, BodyIntensifyRules.cooldownTicks(0.5f));
        assertEquals(600, BodyIntensifyRules.cooldownTicks(1f));
    }

    @Test
    void probabilityFollowsTheSheet() {
        assertEquals(0f, BodyIntensifyRules.probability(10), EPS);
        assertEquals(0.5f, BodyIntensifyRules.probability(19), EPS);
        assertEquals(1f, BodyIntensifyRules.probability(28), EPS);
        assertEquals(1.6667f, BodyIntensifyRules.probability(40), EPS);
        assertEquals(1.6667f, BodyIntensifyRules.probability(90), EPS);
    }

    @Test
    void amplifierIsOneFrom28Ticks() {
        for (BodyIntensifyRules.Buff buff : BodyIntensifyRules.Buff.values()) {
            assertEquals(0, BodyIntensifyRules.amplifier(27, buff));
            assertEquals(1, BodyIntensifyRules.amplifier(28, buff));
            assertEquals(1, BodyIntensifyRules.amplifier(40, buff));
        }
    }

    @Test
    void durationsMatchTheReferenceTable() {
        assertEquals(60, BodyIntensifyRules.buffTicks(40, 0f, 1f));
        assertEquals(119, BodyIntensifyRules.buffTicks(40, 0f, 1.9999f));
        assertEquals(100, BodyIntensifyRules.buffTicks(40, 1f, 1f));
        assertEquals(199, BodyIntensifyRules.buffTicks(40, 1f, 1.9999f));
        assertEquals(42, BodyIntensifyRules.buffTicks(28, 0f, 1f));
        assertEquals(12, BodyIntensifyRules.hungerTicks(10));
        assertEquals(50, BodyIntensifyRules.hungerTicks(40));
        assertEquals(50, BodyIntensifyRules.hungerTicks(100));
    }

    @Test
    void noBuffsAtTenTicksAndAtLeastOneFromTwentyEight() {
        for (int seed = 0; seed < 200; seed++) {
            assertTrue(BodyIntensifyRules.chooseBuffs(10, RandomSource.create(seed)).isEmpty());
            assertEquals(1, BodyIntensifyRules.chooseBuffs(28, RandomSource.create(seed)).size());
            int n = BodyIntensifyRules.chooseBuffs(40, RandomSource.create(seed)).size();
            assertTrue(n == 1 || n == 2, "got " + n);
        }
    }

    @Test
    void chosenBuffsNeverRepeatAndEveryBuffCanAppear() {
        HashSet<BodyIntensifyRules.Buff> seen = new HashSet<>();
        int doubles = 0;
        for (int seed = 0; seed < 1000; seed++) {
            List<BodyIntensifyRules.Buff> buffs = BodyIntensifyRules.chooseBuffs(40, RandomSource.create(seed));
            assertEquals(buffs.size(), new HashSet<>(buffs).size());
            if (buffs.size() == 2) {
                doubles++;
            }
            seen.addAll(buffs);
        }
        assertEquals(BodyIntensifyRules.Buff.values().length, seen.size());
        // P - 1 = 66.7 %: con 1000 semillas queda cerca de 667.
        assertTrue(doubles > 550 && doubles < 780, "doubles " + doubles);
    }
}
