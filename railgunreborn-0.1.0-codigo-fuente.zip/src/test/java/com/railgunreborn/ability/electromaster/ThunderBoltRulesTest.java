package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha thunder-bolt §12. */
class ThunderBoltRulesTest {
    private static final float EPS = 1e-4f;

    @Test
    void cpCostIsTruncatedFrom280To420() {
        assertEquals(280f, ThunderBoltRules.cpCost(0f), EPS);
        assertEquals(350f, ThunderBoltRules.cpCost(0.5f), EPS);
        assertEquals(420f, ThunderBoltRules.cpCost(1f), EPS);
        assertEquals(281f, ThunderBoltRules.cpCost(0.01f), EPS); // 281.4
    }

    @Test
    void overloadCostFrom50To27() {
        assertEquals(50f, ThunderBoltRules.overloadCost(0f), EPS);
        assertEquals(38.5f, ThunderBoltRules.overloadCost(0.5f), EPS);
        assertEquals(27f, ThunderBoltRules.overloadCost(1f), EPS);
    }

    @Test
    void cooldownFrom120To50Ticks() {
        assertEquals(120, ThunderBoltRules.cooldownTicks(0f));
        assertEquals(85, ThunderBoltRules.cooldownTicks(0.5f));
        assertEquals(50, ThunderBoltRules.cooldownTicks(1f));
    }

    @Test
    void damageValues() {
        assertEquals(10f, ThunderBoltRules.directDamage(0f), EPS);
        assertEquals(17.5f, ThunderBoltRules.directDamage(0.5f), EPS);
        assertEquals(25f, ThunderBoltRules.directDamage(1f), EPS);
        assertEquals(6f, ThunderBoltRules.aoeDamage(0f), EPS);
        assertEquals(10.5f, ThunderBoltRules.aoeDamage(0.5f), EPS);
        assertEquals(15f, ThunderBoltRules.aoeDamage(1f), EPS);
    }

    @Test
    void slownessNeedsExpAbove02AndRollBelow08() {
        assertFalse(ThunderBoltRules.slownessApplies(0f, 0.0));
        assertFalse(ThunderBoltRules.slownessApplies(0.2f, 0.0));
        assertTrue(ThunderBoltRules.slownessApplies(0.21f, 0.0));
        assertTrue(ThunderBoltRules.slownessApplies(1f, 0.79));
        assertFalse(ThunderBoltRules.slownessApplies(1f, 0.8));
        assertEquals(3, ThunderBoltRules.SLOW_AMPLIFIER);
        assertEquals(40, ThunderBoltRules.DIRECT_SLOW_TICKS);
        assertEquals(20, ThunderBoltRules.AOE_SLOW_TICKS);
    }

    @Test
    void expGain() {
        assertEquals(0.005f, ThunderBoltRules.expGain(true), 1e-9f);
        assertEquals(0.003f, ThunderBoltRules.expGain(false), 1e-9f);
    }

    @Test
    void aoeIsASphereOfRadius8() {
        assertTrue(ThunderBoltRules.inAoe(0));
        assertTrue(ThunderBoltRules.inAoe(64));
        assertFalse(ThunderBoltRules.inAoe(64.01));
        assertEquals(20f, ThunderBoltRules.RANGE, EPS);
    }
}
