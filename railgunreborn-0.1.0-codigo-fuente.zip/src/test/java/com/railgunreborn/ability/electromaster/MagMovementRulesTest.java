package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.electromaster.MagMovementRules.HitKind;

import net.minecraft.world.phys.Vec3;

class MagMovementRulesTest {
    private static final float EPS = 1e-4f;
    private static final double DEPS = 1e-9;

    @Test
    void overloadInterpolatesFrom60To30() {
        assertEquals(60f, MagMovementRules.overloadCost(0f), EPS);
        assertEquals(45f, MagMovementRules.overloadCost(0.5f), EPS);
        assertEquals(30f, MagMovementRules.overloadCost(1f), EPS);
    }

    @Test
    void cpPerTickInterpolatesFrom15To8() {
        assertEquals(15f, MagMovementRules.cpPerTick(0f), EPS);
        assertEquals(11.5f, MagMovementRules.cpPerTick(0.5f), EPS);
        assertEquals(8f, MagMovementRules.cpPerTick(1f), EPS);
    }

    @Test
    void weakBlocksNeedExp06() {
        assertTrue(MagMovementRules.isValidTarget(HitKind.MAGNETIC_BLOCK, 0f));
        assertTrue(MagMovementRules.isValidTarget(HitKind.MAGNETIC_ENTITY, 0f));
        assertFalse(MagMovementRules.isValidTarget(HitKind.WEAK_MAGNETIC_BLOCK, 0.59f));
        assertTrue(MagMovementRules.isValidTarget(HitKind.WEAK_MAGNETIC_BLOCK, 0.6f));
        assertFalse(MagMovementRules.isValidTarget(HitKind.NON_MAGNETIC, 1f));
        assertFalse(MagMovementRules.isValidTarget(HitKind.NONE, 1f));
    }

    @Test
    void expHasMinimumAndGrowsWithDistance() {
        assertEquals(0.005f, MagMovementRules.expGain(0), 1e-7f);
        assertEquals(0.005f, MagMovementRules.expGain(4.5), 1e-7f);
        assertEquals(0.011f, MagMovementRules.expGain(10), 1e-7f);
        assertEquals(0.0275f, MagMovementRules.expGain(25), 1e-7f);
    }

    @Test
    void desiredVelocityHasUnitLengthAndNoNaN() {
        Vec3 v = MagMovementRules.desiredVelocity(Vec3.ZERO, new Vec3(3, 4, 0));
        assertEquals(1.0, v.length(), DEPS);
        assertEquals(0.6, v.x, DEPS);
        assertEquals(0.8, v.y, DEPS);
        // Sin frenar al acercarse.
        assertEquals(1.0, MagMovementRules.desiredVelocity(Vec3.ZERO, new Vec3(0, 0, 0.5)).length(), DEPS);
        // Destino encima: velocidad 0, nunca NaN.
        Vec3 still = MagMovementRules.desiredVelocity(new Vec3(1, 2, 3), new Vec3(1, 2.01, 3));
        assertEquals(Vec3.ZERO, still);
    }

    @Test
    void accelerationIsLimitedPerAxis() {
        Vec3 next = MagMovementRules.nextVelocity(Vec3.ZERO, new Vec3(1, -0.05, 0.6), 0.08);
        assertEquals(0.08, next.x, DEPS);
        assertEquals(-0.05, next.y, DEPS); // alcanza el valor sin pasarse
        assertEquals(0.08, next.z, DEPS);
        Vec3 down = MagMovementRules.nextVelocity(new Vec3(1, 0, 0), new Vec3(-1, 0, 0), 0.08);
        assertEquals(0.92, down.x, DEPS);
    }

    @Test
    void resyncOnlyAfterLargeDifference() {
        Vec3 internal = new Vec3(1, 0, 0);
        assertFalse(MagMovementRules.shouldResync(internal, new Vec3(0.8, 0, 0))); // 1 - 0.64 = 0.36
        assertTrue(MagMovementRules.shouldResync(internal, new Vec3(0.5, 0, 0))); // 0.75
        // Tras chocar contra una pared la velocidad interna parte de la real.
        Vec3 next = MagMovementRules.step(internal, Vec3.ZERO, Vec3.ZERO, new Vec3(10, 0, 0));
        assertEquals(0.08, next.x, DEPS);
    }

    @Test
    void reachesFullSpeedAfterAboutThirteenTicks() {
        Vec3 velocity = Vec3.ZERO;
        Vec3 pos = Vec3.ZERO;
        Vec3 dest = new Vec3(0, 0, 100);
        int ticks = 0;
        while (velocity.z < 1.0 && ticks < 100) {
            velocity = MagMovementRules.step(velocity, velocity, pos, dest);
            pos = pos.add(velocity);
            ticks++;
        }
        assertEquals(13, ticks);
        assertEquals(1.0, velocity.z, DEPS);
    }
}
