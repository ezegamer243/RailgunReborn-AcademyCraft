package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.electromaster.MagManipRules.Cell;

import net.minecraft.world.phys.Vec3;

class MagManipRulesTest {
    private static final float EPS = 1e-4f;
    private static final double DEPS = 1e-9;

    @Test
    void costsFollowTheSpec() {
        assertEquals(140f, MagManipRules.cpCost(0f), EPS);
        assertEquals(205f, MagManipRules.cpCost(0.5f), EPS);
        assertEquals(270f, MagManipRules.cpCost(1f), EPS);
        assertEquals(35f, MagManipRules.overloadCost(0f), EPS);
        assertEquals(27.5f, MagManipRules.overloadCost(0.5f), EPS);
        assertEquals(20f, MagManipRules.overloadCost(1f), EPS);
    }

    @Test
    void cooldownSpeedAndDamage() {
        assertEquals(60, MagManipRules.cooldownTicks(0f));
        assertEquals(50, MagManipRules.cooldownTicks(0.5f));
        assertEquals(40, MagManipRules.cooldownTicks(1f));
        assertEquals(0.5, MagManipRules.throwSpeed(0f), DEPS);
        assertEquals(0.75, MagManipRules.throwSpeed(0.5f), DEPS);
        assertEquals(1.0, MagManipRules.throwSpeed(1f), DEPS);
        assertEquals(8f, MagManipRules.damage(0f), EPS);
        assertEquals(11.5f, MagManipRules.damage(0.5f), EPS);
        assertEquals(15f, MagManipRules.damage(1f), EPS);
        // Fuera de rango se recorta.
        assertEquals(15f, MagManipRules.damage(2f), EPS);
        assertEquals(8f, MagManipRules.damage(-1f), EPS);
    }

    @Test
    void throwNeedsDistanceUnder5AndPayment() {
        assertTrue(MagManipRules.canThrow(24.9, true));
        assertFalse(MagManipRules.canThrow(25.0, true));
        assertFalse(MagManipRules.canThrow(1.0, false));
    }

    @Test
    void grabbableExcludesBlockEntitiesDoorsAndUnbreakable() {
        assertTrue(MagManipRules.isGrabbable(true, false, false, false));
        assertFalse(MagManipRules.isGrabbable(false, false, false, false));
        assertFalse(MagManipRules.isGrabbable(true, true, false, false));
        assertFalse(MagManipRules.isGrabbable(true, false, true, false));
        assertFalse(MagManipRules.isGrabbable(true, false, false, true));
    }

    @Test
    void holdVelocitySlowsDownNearTheTarget() {
        Vec3 far = MagManipRules.holdVelocity(Vec3.ZERO, new Vec3(0, 0, 10));
        assertEquals(MagManipRules.HOLD_SPEED, far.length(), DEPS);
        assertEquals(1.0, far.normalize().z, DEPS);
        // A 1 bloque: 0.2 * 1/4.
        Vec3 near = MagManipRules.holdVelocity(Vec3.ZERO, new Vec3(1, 0, 0));
        assertEquals(0.05, near.length(), DEPS);
        assertEquals(Vec3.ZERO, MagManipRules.holdVelocity(Vec3.ZERO, Vec3.ZERO));
        // Nunca se pasa del destino.
        Vec3 tiny = MagManipRules.holdVelocity(Vec3.ZERO, new Vec3(0.01, 0, 0));
        assertTrue(tiny.length() <= 0.01 + DEPS);
    }

    @Test
    void holdPointIsTwoBlocksAheadOrBeforeAWall() {
        Vec3 eyes = new Vec3(0, 10, 0);
        Vec3 look = new Vec3(0, 0, 1);
        Vec3 free = MagManipRules.holdPoint(eyes, look, Double.NaN);
        assertEquals(0.0, free.x, DEPS);
        assertEquals(9.9, free.y, DEPS);
        assertEquals(2.0, free.z, DEPS);
        Vec3 wall = MagManipRules.holdPoint(eyes, look, 1.5);
        assertEquals(0.9, wall.z, DEPS);
        Vec3 touching = MagManipRules.holdPoint(eyes, look, 0.2);
        assertEquals(0.0, touching.z, DEPS);
    }

    @Test
    void placementCandidatesStartAtHitThenFrontWithoutRepeats() {
        Cell hit = new Cell(5, 5, 5);
        List<Cell> list = MagManipRules.placementCandidates(hit, 0, 1, 0);
        assertEquals(hit, list.get(0));
        assertEquals(new Cell(5, 6, 5), list.get(1));
        assertEquals(list.size(), new HashSet<>(list).size(), "no repeated cells");
        // golpeada + 26 vecinas + pasos 2..10 por la normal
        assertEquals(1 + 26 + (MagManipRules.MAX_FACE_STEPS - 1), list.size());
        assertEquals(new Cell(5, 15, 5), list.get(list.size() - 1));
        // Tras la de delante, las más cercanas a ella (las que están a su lado sobre la cara).
        Cell third = list.get(2);
        assertEquals(6, third.y());
    }
}
