package com.railgunreborn.ability.electromaster;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;
import java.util.Random;

import com.railgunreborn.ability.common.TunnelRules.BreakOutcome;
import com.railgunreborn.ability.common.TunnelRules.Cell;
import com.railgunreborn.ability.common.TunnelRules.LineBudget;
import com.railgunreborn.ability.common.TunnelRules.Vec;

import org.junit.jupiter.api.Test;

/** Valores de referencia de la ficha railgun §12 y la geometría corregida (decisiones 2-5). */
class RailgunRulesTest {
    private static final float EPS = 1e-4f;
    private static final double D_EPS = 1e-9;

    @Test
    void costsCooldownDamageAndEnergyMatchTheReferenceTable() {
        assertEquals(200f, RailgunRules.cpCost(0f), EPS);
        assertEquals(325f, RailgunRules.cpCost(0.5f), EPS);
        assertEquals(450f, RailgunRules.cpCost(1f), EPS);
        assertEquals(180f, RailgunRules.overloadCost(0f), EPS);
        assertEquals(150f, RailgunRules.overloadCost(0.5f), EPS);
        assertEquals(120f, RailgunRules.overloadCost(1f), EPS);
        assertEquals(300, RailgunRules.cooldownTicks(0f));
        assertEquals(230, RailgunRules.cooldownTicks(0.5f));
        assertEquals(160, RailgunRules.cooldownTicks(1f));
        assertEquals(60f, RailgunRules.damage(0f), EPS);
        assertEquals(85f, RailgunRules.damage(0.5f), EPS);
        assertEquals(110f, RailgunRules.damage(1f), EPS);
        assertEquals(900f, RailgunRules.energy(0f), EPS);
        assertEquals(1450f, RailgunRules.energy(0.5f), EPS);
        assertEquals(2000f, RailgunRules.energy(1f), EPS);
    }

    @Test
    void expDependsOnHittingSomethingAlive() {
        assertEquals(0.01f, RailgunRules.expGain(true), 1e-7f);
        assertEquals(0.005f, RailgunRules.expGain(false), 1e-7f);
    }

    @Test
    void lineEnergyIsSharedWithFivePercentNoise() {
        assertEquals(100.0 * 0.95, RailgunRules.lineEnergy(1500, 15, 0.0), 1e-6);
        assertEquals(100.0, RailgunRules.lineEnergy(1500, 15, 0.5), 1e-6);
        assertEquals(100.0 * 1.05, RailgunRules.lineEnergy(1500, 15, 1.0), 1e-6);
        assertEquals(0.0, RailgunRules.lineEnergy(1500, 0, 0.5), 1e-6);
    }

    @Test
    void beamCylinderUsesHitRadiusAndRange() {
        assertTrue(RailgunRules.inBeam(10, 2.4));
        assertFalse(RailgunRules.inBeam(10, 2.41));
        assertFalse(RailgunRules.inBeam(-0.1, 0));
        assertTrue(RailgunRules.inBeam(50, 0));
        assertFalse(RailgunRules.inBeam(50.1, 0));
    }

    @Test
    void axesArePerpendicularForAnyDirection() {
        Random random = new Random(1);
        for (int i = 0; i < 200; i++) {
            Vec dir = new Vec(random.nextGaussian(), random.nextGaussian(), random.nextGaussian()).normalize();
            assertAxes(dir);
        }
        assertAxes(new Vec(0, 1, 0));
        assertAxes(new Vec(0, -1, 0));
        assertAxes(new Vec(0, 0, 1));
        assertAxes(new Vec(1, 0, 0));
    }

    private static void assertAxes(Vec dir) {
        Vec[] axes = RailgunRules.perpendicularAxes(dir);
        assertEquals(1.0, axes[0].length(), 1e-9);
        assertEquals(1.0, axes[1].length(), 1e-9);
        assertEquals(0.0, axes[0].dot(dir), 1e-9);
        assertEquals(0.0, axes[1].dot(dir), 1e-9);
        assertEquals(0.0, axes[0].dot(axes[1]), 1e-9);
    }

    @Test
    void discIsPerpendicularToTheLookAndCenteredOnTheEyes() {
        // El bug del original: mirando hacia Z el disco era una ranura. Aquí debe ser igual en cualquier dirección.
        Vec eyes = new Vec(10.5, 64.62, -3.5);
        for (Vec dir : List.of(new Vec(0, 0, 1), new Vec(1, 0, 0), new Vec(0.6, -0.48, 0.64), new Vec(0, 1, 0))) {
            Vec d = dir.normalize();
            List<Vec> points = RailgunRules.discPoints(eyes, d, () -> 0.5);
            // Radio fijo 2 (tirada 0.5): 13 puntos de la rejilla 5x5 con s²+t² <= 4.
            assertEquals(13, points.size(), "points for " + dir);
            Vec sum = new Vec(0, 0, 0);
            for (Vec p : points) {
                Vec rel = p.sub(eyes);
                assertEquals(0.0, rel.dot(d), 1e-9, "point off the disc plane for " + dir);
                assertTrue(rel.length() <= RailgunRules.RADIUS + D_EPS);
                sum = sum.add(rel);
            }
            assertEquals(0.0, sum.length(), 1e-9, "disc must be centered on the eyes");
        }
    }

    @Test
    void discEdgeDependsOnTheRoll() {
        Vec eyes = new Vec(0.5, 0.5, 0.5);
        Vec dir = new Vec(0, 0, 1);
        assertEquals(13, RailgunRules.discPoints(eyes, dir, () -> 0.0).size()); // rr = 1.8
        assertEquals(21, RailgunRules.discPoints(eyes, dir, () -> 0.999).size()); // rr ≈ 2.2
    }

    @Test
    void lineStartsHaveNoDuplicateCells() {
        Random random = new Random(7);
        for (int i = 0; i < 100; i++) {
            Vec eyes = new Vec(random.nextDouble() * 10, 60 + random.nextDouble(), random.nextDouble() * 10);
            Vec dir = new Vec(random.nextGaussian(), random.nextGaussian(), random.nextGaussian()).normalize();
            List<Cell> starts = RailgunRules.lineStarts(eyes, dir, random::nextDouble);
            assertEquals(starts.size(), new HashSet<>(starts).size(), "duplicate start cells");
            assertTrue(starts.size() >= 5 && starts.size() <= 21, "unexpected line count " + starts.size());
            for (Cell cell : starts) {
                assertTrue(cell.center().sub(eyes).length() <= RailgunRules.RADIUS * 1.1 + Math.sqrt(3) / 2 + D_EPS);
            }
        }
    }

    @Test
    void axisAlignedDiscGivesOneLinePerCellAcrossTheView() {
        // Mirando a +Z desde el centro de un bloque: todas las casillas están en el mismo z y no se repiten en x/y.
        Vec eyes = new Vec(4.5, 2.5, 1.5);
        List<Cell> starts = RailgunRules.lineStarts(eyes, new Vec(0, 0, 1), () -> 0.5);
        assertEquals(13, starts.size());
        for (Cell cell : starts) {
            assertEquals(1, cell.z());
        }
    }

    @Test
    void lineStepsAlongTheDominantAxis() {
        List<Cell> line = RailgunRules.line(new Cell(0, 0, 0), new Vec(0, 0, 1), 50);
        assertEquals(51, line.size());
        for (int i = 0; i < line.size(); i++) {
            assertEquals(new Cell(0, 0, i), line.get(i));
        }
        List<Cell> diagonal = RailgunRules.line(new Cell(0, 0, 0), new Vec(1, 0.5, 0).normalize(), 4);
        assertEquals(new Cell(4, 2, 0), diagonal.get(4));
        // Cada paso avanza exactamente 1 en el eje dominante y como mucho 1 en los otros (línea continua).
        for (int i = 1; i < diagonal.size(); i++) {
            assertEquals(1, diagonal.get(i).x() - diagonal.get(i - 1).x());
            assertTrue(Math.abs(diagonal.get(i).y() - diagonal.get(i - 1).y()) <= 1);
        }
    }

    @Test
    void axisDistancesSplitAlongAndPerpendicular() {
        double[] d = RailgunRules.axisDistances(new Vec(0, 0, 0), new Vec(0, 0, 2), new Vec(3, 4, 10));
        assertEquals(10.0, d[0], 1e-9);
        assertEquals(5.0, d[1], 1e-9);
    }

    @Test
    void budgetBreaksUntilEnergyRunsOutAndStops() {
        LineBudget budget = new LineBudget(4.0);
        assertEquals(BreakOutcome.BREAK, budget.tryBreak(1.5, true)); // piedra
        assertEquals(BreakOutcome.BREAK, budget.tryBreak(0.0, true)); // hierba: gratis
        assertEquals(BreakOutcome.BREAK, budget.tryBreak(1.5, true));
        assertEquals(1.0, budget.remaining(), 1e-9);
        assertEquals(BreakOutcome.STOP, budget.tryBreak(1.5, true));
        assertTrue(budget.exhausted());
    }

    @Test
    void unbreakableOrForbiddenBlocksStopTheLine() {
        LineBudget bedrock = new LineBudget(2000.0);
        assertEquals(BreakOutcome.STOP, bedrock.tryBreak(-1.0, true));
        assertTrue(bedrock.exhausted());
        LineBudget protectedBlock = new LineBudget(2000.0);
        assertEquals(BreakOutcome.STOP, protectedBlock.tryBreak(0.5, false));
        assertTrue(protectedBlock.exhausted());
        assertEquals(RailgunRules.UNBREAKABLE_HARDNESS, RailgunRules.effectiveHardness(-1.0), 0.0);
    }
}
