package com.railgunreborn.ability.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;
import java.util.Random;

import com.railgunreborn.ability.common.TunnelRules.Cell;
import com.railgunreborn.ability.common.TunnelRules.Vec;
import com.railgunreborn.ability.electromaster.RailgunRules;

import org.junit.jupiter.api.Test;

/** Túnel con radio parametrizable (Railgun 2, Meltdowner hasta 3). */
class TunnelRulesTest {
    private static final Vec EYES = new Vec(0.5, 1.62, 0.5);
    private static final Vec FORWARD = new Vec(0, 0, 1);

    @Test
    void gridHalfFollowsRadius() {
        assertEquals(2, TunnelRules.gridHalf(2.0));
        assertEquals(2, TunnelRules.gridHalf(2.5));
        assertEquals(3, TunnelRules.gridHalf(2.7));
        assertEquals(3, TunnelRules.gridHalf(3.0));
    }

    @Test
    void radiusTwoMatchesRailgun() {
        Random a = new Random(42);
        Random b = new Random(42);
        assertEquals(RailgunRules.lineStarts(EYES, FORWARD, a::nextDouble),
                TunnelRules.lineStarts(EYES, FORWARD, 2.0, b::nextDouble));
    }

    @Test
    void discPointCountsForRadiusThree() {
        // rr = 3 * 0.9 = 2.7 con roll 0; rejilla ±3 de paso 0.9: s² + t² <= 7.29 → |i|,|j| con i² + j² <= 9.
        assertEquals(29, TunnelRules.discPoints(EYES, FORWARD, 3.0, () -> 0.0).size());
        // rr ≈ 3.3: i² + j² <= 13.4 → 7 + 2·7 + 2·7 + 2·5.
        assertEquals(45, TunnelRules.discPoints(EYES, FORWARD, 3.0, () -> 0.999).size());
    }

    @Test
    void biggerRadiusGivesMoreLines() {
        int r2 = TunnelRules.lineStarts(EYES, FORWARD, 2.0, () -> 0.5).size();
        int r3 = TunnelRules.lineStarts(EYES, FORWARD, 3.0, () -> 0.5).size();
        assertTrue(r3 > r2, "radius 3 should start more lines than radius 2 (" + r3 + " vs " + r2 + ")");
    }

    @Test
    void radiusThreeStartsAreUniqueAndCenteredOnTheEyes() {
        List<Cell> starts = TunnelRules.lineStarts(EYES, FORWARD, 3.0, () -> 0.5);
        assertEquals(starts.size(), new HashSet<>(starts).size());
        for (Cell c : starts) {
            assertEquals(0, c.z(), "the disc is in the eye plane (z = 0)");
            assertTrue(Math.abs(c.x() + 0.5 - EYES.x()) <= 3.5 && Math.abs(c.y() + 0.5 - EYES.y()) <= 3.5);
        }
    }

    @Test
    void cylinderUsesRangeAndRadius() {
        assertTrue(TunnelRules.inCylinder(10, 3.6, 30, 3.6));
        assertTrue(!TunnelRules.inCylinder(10, 3.61, 30, 3.6));
        assertTrue(!TunnelRules.inCylinder(30.1, 0, 30, 3.6));
        assertTrue(!TunnelRules.inCylinder(-0.1, 0, 30, 3.6));
    }
}
