package com.railgunreborn.ability.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

import org.junit.jupiter.api.Test;

class SafeTeleportRulesTest {
    @Test
    void backOffReturnsTheFarthestFreeDistance() {
        // Libre solo por debajo de 7.6: el primer paso válido desde 10 es 7.5.
        Optional<Double> found = SafeTeleportRules.backOff(10, 3, 0.25, d -> d < 7.6 ? Optional.of(d) : Optional.empty());
        assertEquals(7.5, found.orElseThrow(), 1e-9);
    }

    @Test
    void backOffTriesTheFullDistanceFirst() {
        List<Double> tried = new ArrayList<>();
        SafeTeleportRules.backOff(5, 3, 0.25, d -> {
            tried.add(d);
            return Optional.of(d);
        });
        assertEquals(List.of(5.0), tried);
    }

    @Test
    void backOffNeverGoesBelowTheMinimumAndAlwaysTriesIt() {
        List<Double> tried = new ArrayList<>();
        Optional<Double> found = SafeTeleportRules.backOff(4.1, 3, 0.25, d -> {
            tried.add(d);
            return Optional.<Double>empty();
        });
        assertTrue(found.isEmpty());
        assertEquals(3.0, tried.get(tried.size() - 1), 1e-9);
        assertTrue(tried.stream().allMatch(d -> d >= 3.0 - 1e-9), "tried " + tried);
        assertEquals(6, tried.size(), "4.1, 3.85, 3.6, 3.35, 3.1 and 3");
    }

    @Test
    void backOffRejectsShortRequests() {
        assertTrue(SafeTeleportRules.backOff(2.5, 3, 0.25, Optional::of).isEmpty());
        assertEquals(3.0, SafeTeleportRules.backOff(3, 3, 0.25, Optional::of).orElseThrow(), 1e-9);
    }

    @Test
    void groundDropSnapsOnlyWithinThreeBlocks() {
        OptionalDouble standing = SafeTeleportRules.groundDrop(0);
        assertEquals(0, standing.getAsDouble(), 1e-9);
        assertEquals(-2.5, SafeTeleportRules.groundDrop(-2.5).getAsDouble(), 1e-9);
        assertFalse(SafeTeleportRules.groundDrop(-3).isPresent(), "nothing within 3 blocks: stays in the air");
    }
}
