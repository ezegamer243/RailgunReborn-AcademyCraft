package com.railgunreborn.ability.develop;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.railgunreborn.ability.develop.DevelopRules.LearnFacts;

class DevelopRulesTest {
    /** Caso que cumple todo para una habilidad del nivel dado, jugador en nivel 5. */
    private static LearnFacts ok(int skillLevel) {
        return new LearnFacts(true, true, false, 5, skillLevel, true, true, true);
    }

    @Test
    void developerTypeTicksAndLimits() {
        assertEquals(26, DeveloperType.PORTABLE.ticksPerStim());
        assertEquals(21, DeveloperType.NORMAL.ticksPerStim());
        assertEquals(16, DeveloperType.ADVANCED.ticksPerStim());
        assertEquals(2, DeveloperType.PORTABLE.maxSkillLevel());
        assertEquals(3, DeveloperType.NORMAL.maxSkillLevel());
        assertEquals(5, DeveloperType.ADVANCED.maxSkillLevel());
    }

    @Test
    void minimumTypeByLevel() {
        assertEquals(DeveloperType.PORTABLE, DeveloperType.minimumFor(1));
        assertEquals(DeveloperType.PORTABLE, DeveloperType.minimumFor(2));
        assertEquals(DeveloperType.NORMAL, DeveloperType.minimumFor(3));
        assertEquals(DeveloperType.ADVANCED, DeveloperType.minimumFor(4));
        assertEquals(DeveloperType.ADVANCED, DeveloperType.minimumFor(5));
        assertThrows(IllegalArgumentException.class, () -> DeveloperType.minimumFor(6));
    }

    @Test
    void stimCosts() {
        assertEquals(5, DevelopRules.stimsForLevelAction(0));
        assertEquals(10, DevelopRules.stimsForLevelAction(1));
        assertEquals(25, DevelopRules.stimsForLevelAction(4));
        int[] expected = {3, 5, 7, 11, 15};
        for (int level = 1; level <= 5; level++) {
            assertEquals(expected[level - 1], DevelopRules.stimsForSkill(level), "level " + level);
        }
        assertEquals(78, DevelopRules.totalTicks(3, DeveloperType.PORTABLE));
    }

    @Test
    void levelActionRules() {
        assertEquals(DevelopResult.OK, DevelopRules.checkLevelAction(false, 0, 0f), "obtaining a category");
        assertEquals(DevelopResult.LEVEL_PROGRESS_INCOMPLETE, DevelopRules.checkLevelAction(true, 1, 0.99f));
        assertEquals(DevelopResult.OK, DevelopRules.checkLevelAction(true, 1, 1f));
        assertEquals(DevelopResult.MAX_LEVEL, DevelopRules.checkLevelAction(true, 5, 1f));
    }

    @Test
    void learnAcceptsWhenEverythingIsMet() {
        assertEquals(DevelopResult.OK, DevelopRules.checkLearn(ok(1), DeveloperType.PORTABLE));
        assertEquals(DevelopResult.OK, DevelopRules.checkLearn(ok(5), DeveloperType.ADVANCED));
    }

    @Test
    void learnRejectsEachMissingCondition() {
        assertEquals(DevelopResult.NO_CATEGORY, DevelopRules.checkLearn(
                new LearnFacts(false, false, false, 0, 1, true, true, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.WRONG_CATEGORY, DevelopRules.checkLearn(
                new LearnFacts(true, false, false, 5, 1, true, true, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.ALREADY_LEARNED, DevelopRules.checkLearn(
                new LearnFacts(true, true, true, 5, 1, true, true, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.LEVEL_TOO_LOW, DevelopRules.checkLearn(
                new LearnFacts(true, true, false, 2, 3, true, true, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.PARENT_NOT_MET, DevelopRules.checkLearn(
                new LearnFacts(true, true, false, 5, 1, false, true, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.DEPENDENCY_NOT_MET, DevelopRules.checkLearn(
                new LearnFacts(true, true, false, 5, 1, true, false, true), DeveloperType.ADVANCED));
        assertEquals(DevelopResult.ANY_SKILL_NOT_MET, DevelopRules.checkLearn(
                new LearnFacts(true, true, false, 5, 3, true, true, false), DeveloperType.ADVANCED));
    }

    @Test
    void learnRespectsDeveloperType() {
        assertEquals(DevelopResult.DEVELOPER_TOO_WEAK, DevelopRules.checkLearn(ok(3), DeveloperType.PORTABLE));
        assertEquals(DevelopResult.OK, DevelopRules.checkLearn(ok(3), DeveloperType.NORMAL));
        assertEquals(DevelopResult.DEVELOPER_TOO_WEAK, DevelopRules.checkLearn(ok(4), DeveloperType.NORMAL));
        assertEquals(DevelopResult.OK, DevelopRules.checkLearn(ok(2), DeveloperType.PORTABLE));
    }

    @Test
    void sessionCompletesAfterStimsTimesTicks() {
        DevelopSession session = new DevelopSession();
        session.begin(3, 26);
        for (int i = 0; i < 77; i++) {
            assertFalse(session.tick(), "tick " + i);
        }
        assertEquals(2, session.stim());
        assertTrue(session.tick());
        session.finish(DevelopResult.OK);
        assertEquals(DevelopSession.State.DONE, session.state());
        assertFalse(session.tick(), "a finished session does not tick");
        assertEquals(1f, session.progress(), 1e-6f);
    }

    @Test
    void sessionProgressIsSmoothAndCancelResets() {
        DevelopSession session = new DevelopSession();
        session.begin(2, 10);
        for (int i = 0; i < 5; i++) {
            session.tick();
        }
        assertEquals(0.25f, session.progress(), 1e-6f);
        session.cancel(DevelopResult.ABORTED);
        assertEquals(DevelopSession.State.IDLE, session.state());
        assertEquals(0, session.stim());
        assertFalse(session.tick());
    }

    @Test
    void failedFinishAndReject() {
        DevelopSession session = new DevelopSession();
        session.reject(DevelopResult.LEVEL_TOO_LOW);
        assertEquals(DevelopSession.State.FAILED, session.state());
        assertEquals(0f, session.progress());
        session.begin(1, 1);
        assertTrue(session.tick());
        session.finish(DevelopResult.ALREADY_LEARNED);
        assertEquals(DevelopSession.State.FAILED, session.state());
        assertEquals(DevelopResult.ALREADY_LEARNED, session.result());
    }
}
