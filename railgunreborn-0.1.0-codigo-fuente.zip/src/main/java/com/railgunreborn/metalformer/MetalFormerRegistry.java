package com.railgunreborn.metalformer;

import java.util.function.Supplier;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registros del Metal Former (T87). Van juntos y aparte de ModBlocks/ModItems para que la máquina sea autocontenida.
 * Todo se engancha al bus del MOD desde {@link RailgunReborn}.
 */
public final class MetalFormerRegistry {
    private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RailgunReborn.MODID);
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RailgunReborn.MODID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister
            .create(Registries.BLOCK_ENTITY_TYPE, RailgunReborn.MODID);
    private static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU,
            RailgunReborn.MODID);
    private static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(Registries.RECIPE_TYPE,
            RailgunReborn.MODID);
    private static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister
            .create(Registries.RECIPE_SERIALIZER, RailgunReborn.MODID);

    /** Dureza 4 y pico de piedra, como el resto de máquinas del original. */
    public static final DeferredBlock<MetalFormerBlock> METAL_FORMER = BLOCKS.register("metal_former",
            () -> new MetalFormerBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops()));
    public static final DeferredItem<BlockItem> METAL_FORMER_ITEM = ITEMS.registerSimpleBlockItem(METAL_FORMER,
            new Item.Properties());

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MetalFormerBlockEntity>> BLOCK_ENTITY =
            BLOCK_ENTITIES.register("metal_former", () -> BlockEntityType.Builder
                    .of(MetalFormerBlockEntity::new, METAL_FORMER.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<MetalFormerMenu>> MENU = MENUS.register("metal_former",
            () -> IMenuTypeExtension.create(MetalFormerMenu::new));

    public static final DeferredHolder<RecipeType<?>, RecipeType<MetalFormerRecipe>> RECIPE_TYPE = RECIPE_TYPES
            .register("metal_former", () -> RecipeType.simple(
                    ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "metal_former")));
    public static final DeferredHolder<RecipeSerializer<?>, MetalFormerRecipe.Serializer> RECIPE_SERIALIZER =
            RECIPE_SERIALIZERS.register("metal_former", MetalFormerRecipe.Serializer::new);

    /** Sonido de trabajo: compartido con el Imag Fusor, registrado una sola vez en {@link ModSounds}. */
    public static final Supplier<SoundEvent> MACHINE_WORK = ModSounds.MACHINE_WORK;

    private MetalFormerRegistry() {
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        RECIPE_TYPES.register(modEventBus);
        RECIPE_SERIALIZERS.register(modEventBus);
        modEventBus.addListener(MetalFormerRegistry::registerCapabilities);
    }

    /** Arriba y lados: entrada; abajo: salida (tolvas y tuberías de otros mods). */
    private static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BLOCK_ENTITY.get(),
                (be, side) -> be.getItemHandler(side));
    }
}
