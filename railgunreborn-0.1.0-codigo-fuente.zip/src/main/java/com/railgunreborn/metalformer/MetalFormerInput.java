package com.railgunreborn.metalformer;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

/** Entrada de una receta del Metal Former: el ítem de la ranura de entrada y el modo elegido. */
public record MetalFormerInput(ItemStack stack, MetalFormerMode mode) implements RecipeInput {
    @Override
    public ItemStack getItem(int index) {
        return index == 0 ? stack : ItemStack.EMPTY;
    }

    @Override
    public int size() {
        return 1;
    }
}
