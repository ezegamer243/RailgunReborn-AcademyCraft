package com.railgunreborn.metalformer.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.metalformer.MetalFormerRegistry;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Registro de la pantalla del Metal Former (solo cliente, bus del MOD). */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class MetalFormerClient {
    private MetalFormerClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(MetalFormerRegistry.MENU.get(), MetalFormerScreen::new);
    }
}
