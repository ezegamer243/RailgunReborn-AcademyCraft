package com.railgunreborn.metalformer.client;

import java.util.HashSet;
import java.util.Set;

import com.railgunreborn.metalformer.MetalFormerBlock;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerRegistry;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Sonido en bucle machine_work mientras el Metal Former trabaja (solo cliente). */
public final class MetalFormerSoundHandler {
    /** El original usaba 0.6; un poco más bajo para que no canse. */
    private static final float VOLUME = 0.4f;
    private static final Set<BlockPos> PLAYING = new HashSet<>();

    private MetalFormerSoundHandler() {
    }

    public static void clientTick(MetalFormerBlockEntity be) {
        Level level = be.getLevel();
        if (level == null || !be.getBlockState().getValue(MetalFormerBlock.WORKING)) {
            return;
        }
        BlockPos pos = be.getBlockPos().immutable();
        if (PLAYING.add(pos)) {
            Minecraft.getInstance().getSoundManager().play(new WorkSound(level, pos));
        }
    }

    private static final class WorkSound extends AbstractTickableSoundInstance {
        private final Level level;
        private final BlockPos pos;

        WorkSound(Level level, BlockPos pos) {
            super(MetalFormerRegistry.MACHINE_WORK.get(), SoundSource.BLOCKS, SoundInstance.createUnseededRandom());
            this.level = level;
            this.pos = pos;
            this.looping = true;
            this.delay = 0;
            this.volume = VOLUME;
            this.x = pos.getX() + 0.5;
            this.y = pos.getY() + 0.5;
            this.z = pos.getZ() + 0.5;
        }

        @Override
        public void tick() {
            BlockState state = level.getBlockState(pos);
            if (Minecraft.getInstance().level != level || !state.hasProperty(MetalFormerBlock.WORKING)
                    || !state.getValue(MetalFormerBlock.WORKING)) {
                PLAYING.remove(pos);
                stop();
            }
        }
    }
}
