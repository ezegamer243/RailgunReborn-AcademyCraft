package com.railgunreborn.metalformer.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerMenu;
import com.railgunreborn.metalformer.MetalFormerMode;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla del Metal Former, reconstruida a partir de page_metalformer.xml del original: fondo, marco de la máquina,
 * icono del modo con flechas a los lados y barra de progreso, en el estilo de {@link AcStyle}. El inventario usa una
 * cuadrícula propia alineada con las ranuras.
 */
public class MetalFormerScreen extends AbstractContainerScreen<MetalFormerMenu> {
    private static final ResourceLocation BACKGROUND = tex("parent_background");
    private static final ResourceLocation INVENTORY = tex("ui_inventory");
    private static final ResourceLocation MACHINE = tex("ui_metalformer");
    private static final ResourceLocation PROGRESS = tex("progress_metalformer");
    private static final ResourceLocation ARROW_LEFT = tex("button_arrowlefta");
    private static final ResourceLocation ARROW_RIGHT = tex("button_arrowrighta");

    public MetalFormerScreen(MetalFormerMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/metal_former/" + name + ".png");
    }

    private static ResourceLocation iconOf(MetalFormerMode mode) {
        return tex("icon_former_" + mode.getSerializedName());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (inside(TechUiLayout.ICON_AREA, rx, ry)) {
            graphics.renderTooltip(font, Component.translatable(menu.getMode().translationKey()), mouseX, mouseY);
        } else if (inside(TechUiLayout.ENERGY_BAR, rx, ry)) {
            graphics.renderTooltip(font, Component.literal(
                    EnergyFormat.fraction(menu.getEnergy(), MetalFormerBlockEntity.ENERGY_CAPACITY)), mouseX, mouseY);
        } else if (inside(TechUiLayout.LEFT_ARROW_AREA, rx, ry) || inside(TechUiLayout.RIGHT_ARROW_AREA, rx, ry)) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.metal_former.switch_mode"),
                    mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        AcStyle.pushArtSpace(graphics, x, y);
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, MACHINE);
        AcStyle.blit(graphics, INVENTORY, TechUiLayout.LOGO_U, TechUiLayout.LOGO_V, TechUiLayout.LOGO_U, TechUiLayout.LOGO_V,
                TechUiLayout.LOGO_W, TechUiLayout.LOGO_H, TechUiLayout.TEX_W, TechUiLayout.TEX_H);
        int max = menu.getMaxProgress();
        float ratio = max > 0 ? Math.min(1f, menu.getProgress() / (float) max) : 0f;
        int w = Math.round(TechUiLayout.FORMER_PROGRESS_W * ratio);
        if (w > 0) {
            AcStyle.blit(graphics, PROGRESS, TechUiLayout.FORMER_PROGRESS_U, TechUiLayout.FORMER_PROGRESS_V, 0, 0, w,
                    TechUiLayout.FORMER_PROGRESS_H, TechUiLayout.FORMER_PROGRESS_W, TechUiLayout.FORMER_PROGRESS_H);
        }
        int icon = TechUiLayout.ICON_TEX;
        AcStyle.blit(graphics, iconOf(menu.getMode()), TechUiLayout.ICON_U, TechUiLayout.ICON_V, 0, 0, icon, icon, icon, icon);
        int rx = mouseX - x;
        int ry = mouseY - y;
        drawArrow(graphics, ARROW_LEFT, TechUiLayout.ARROW_LEFT_U, inside(TechUiLayout.LEFT_ARROW_AREA, rx, ry));
        drawArrow(graphics, ARROW_RIGHT, TechUiLayout.ARROW_RIGHT_U, inside(TechUiLayout.RIGHT_ARROW_AREA, rx, ry));
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);

        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);
        TechUiLayout.Rect b = TechUiLayout.ENERGY_BAR;
        AcStyle.energyBar(graphics, new TechUiLayout.Rect(x + b.x(), y + b.y(), b.w(), b.h()),
                EnergyMath.fill(menu.getEnergy(), MetalFormerBlockEntity.ENERGY_CAPACITY));
        AcStyle.end();
    }

    private static void drawArrow(GuiGraphics graphics, ResourceLocation texture, int u, boolean hovered) {
        AcStyle.tint(graphics, hovered ? 1.0f : 0.7f);
        int size = TechUiLayout.ARROW_TEX;
        AcStyle.blit(graphics, texture, u, TechUiLayout.ARROW_V, 0, 0, size, size, size, size);
    }

    /** La interfaz del original no tiene títulos de texto. */
    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int rx = (int) mouseX - leftPos;
            int ry = (int) mouseY - topPos;
            int id = inside(TechUiLayout.LEFT_ARROW_AREA, rx, ry) ? MetalFormerMenu.BUTTON_PREVIOUS
                    : inside(TechUiLayout.RIGHT_ARROW_AREA, rx, ry) ? MetalFormerMenu.BUTTON_NEXT : -1;
            if (id >= 0 && minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
                minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private static boolean inside(TechUiLayout.Rect area, int x, int y) {
        return x >= area.x() && x < area.x() + area.w() && y >= area.y() && y < area.y() + area.h();
    }
}
