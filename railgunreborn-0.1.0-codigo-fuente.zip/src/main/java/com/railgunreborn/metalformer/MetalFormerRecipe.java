package com.railgunreborn.metalformer;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.crafting.SizedIngredient;

/**
 * Receta del Metal Former (tabla 3.3 de {@code survival.md}). JSON:
 * <pre>
 * { "type": "railgunreborn:metal_former", "mode": "plate",
 *   "ingredient": { "item": "minecraft:iron_ingot", "count": 1 },
 *   "result": { "id": "railgunreborn:reinforced_iron_plate", "count": 1 },
 *   "time": 60, "energy": 800 }
 * </pre>
 * Como en el original, la entrada debe tener la cantidad indicada o más. {@code energy} es la energía total de la
 * operación (IF), que la máquina reparte a lo largo de {@code time} ticks.
 */
public class MetalFormerRecipe implements Recipe<MetalFormerInput> {
    public static final int DEFAULT_TIME = 60;
    /** 13.3 IF/tick x 60 ticks, redondeado como en la ficha. */
    public static final int DEFAULT_ENERGY = 800;

    private final MetalFormerMode mode;
    private final SizedIngredient ingredient;
    private final ItemStack result;
    private final int time;
    private final int energy;

    public MetalFormerRecipe(MetalFormerMode mode, SizedIngredient ingredient, ItemStack result, int time, int energy) {
        this.mode = mode;
        this.ingredient = ingredient;
        this.result = result;
        this.time = time;
        this.energy = energy;
    }

    public MetalFormerMode mode() {
        return mode;
    }

    public SizedIngredient ingredient() {
        return ingredient;
    }

    public ItemStack result() {
        return result;
    }

    public int time() {
        return time;
    }

    public int energy() {
        return energy;
    }

    @Override
    public boolean matches(MetalFormerInput input, Level level) {
        return input.mode() == mode && ingredient.test(input.stack());
    }

    @Override
    public ItemStack assemble(MetalFormerInput input, HolderLookup.Provider registries) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return result;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return NonNullList.of(Ingredient.EMPTY, ingredient.ingredient());
    }

    @Override
    public boolean isSpecial() {
        // No es de mesa: que el libro de recetas no la muestre.
        return true;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return MetalFormerRegistry.RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return MetalFormerRegistry.RECIPE_TYPE.get();
    }

    public static class Serializer implements RecipeSerializer<MetalFormerRecipe> {
        private static final MapCodec<MetalFormerRecipe> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
                MetalFormerMode.CODEC.fieldOf("mode").forGetter(MetalFormerRecipe::mode),
                SizedIngredient.FLAT_CODEC.fieldOf("ingredient").forGetter(MetalFormerRecipe::ingredient),
                ItemStack.STRICT_CODEC.fieldOf("result").forGetter(MetalFormerRecipe::result),
                Codec.intRange(1, 72000).optionalFieldOf("time", DEFAULT_TIME).forGetter(MetalFormerRecipe::time),
                Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("energy", DEFAULT_ENERGY)
                        .forGetter(MetalFormerRecipe::energy))
                .apply(i, MetalFormerRecipe::new));

        private static final StreamCodec<RegistryFriendlyByteBuf, MetalFormerRecipe> STREAM_CODEC = StreamCodec.composite(
                MetalFormerMode.STREAM_CODEC, MetalFormerRecipe::mode,
                SizedIngredient.STREAM_CODEC, MetalFormerRecipe::ingredient,
                ItemStack.STREAM_CODEC, MetalFormerRecipe::result,
                ByteBufCodecs.VAR_INT, MetalFormerRecipe::time,
                ByteBufCodecs.VAR_INT, MetalFormerRecipe::energy,
                MetalFormerRecipe::new);

        @Override
        public MapCodec<MetalFormerRecipe> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, MetalFormerRecipe> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
