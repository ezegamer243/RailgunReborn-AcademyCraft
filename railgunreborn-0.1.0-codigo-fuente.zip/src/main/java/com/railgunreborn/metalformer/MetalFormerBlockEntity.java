package com.railgunreborn.metalformer;

import java.util.Optional;

import javax.annotation.Nullable;

import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.energy.ModEnergyStorage;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.wrapper.RangedWrapper;

/**
 * Lógica del Metal Former: con una entrada que tenga receta para el modo actual, avanza un contador y al llegar al
 * tiempo de la receta consume la entrada y deja el resultado en la salida.
 *
 * <p>Energía (energy.md, E2): buffer de {@link #ENERGY_CAPACITY} IF (cable por cualquier cara o ranura de batería).
 * La receta trae la energía total ({@code energy}) y el original gastaba 13,3 IF/tick, o sea una fracción: se reparte
 * sin estado extra con {@link #energyForTick}, que cobra en el tick {@code n} la diferencia entera entre
 * {@code floor((n+1)·E/T)} y {@code floor(n·E/T)}; la suma de los T ticks es exactamente E. Si {@code energyRequired}
 * está activa y el buffer no paga el tick, se pierde el progreso y la máquina para.
 */
public class MetalFormerBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_INPUT = 0;
    public static final int SLOT_OUTPUT = 1;
    /** Acepta cualquier ítem FE; cada tick se descarga al buffer. */
    public static final int SLOT_BATTERY = 2;
    public static final int SLOT_COUNT = 3;

    public static final int ENERGY_CAPACITY = 3000;
    /** Tope por llamada para cables y otros mods (energy.md 1.1); la ranura de batería no lo usa. */
    public static final int ENERGY_MAX_RECEIVE = 50;

    // Índices de ContainerData: progreso (0), tiempo total (1), modo (2) y la energía (dos ranuras, ContainerDataInts).
    public static final int DATA_ENERGY = 3;
    public static final int DATA_COUNT = 3 + ContainerDataInts.SLOTS;

    private final ItemStackHandler items = new ItemStackHandler(SLOT_COUNT) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return slot != SLOT_BATTERY || BatterySlot.isEnergyItem(stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    /** Arriba y lados: solo se puede meter en la entrada. */
    private final IItemHandler inputSide = new RangedWrapper(items, SLOT_INPUT, SLOT_INPUT + 1) {
        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return ItemStack.EMPTY;
        }
    };
    /** Abajo: solo se puede sacar de la salida. */
    private final IItemHandler outputSide = new RangedWrapper(items, SLOT_OUTPUT, SLOT_OUTPUT + 1) {
        @Override
        public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            return stack;
        }
    };

    private final ModEnergyStorage energy = ModEnergyStorage.receiver(ENERGY_CAPACITY, ENERGY_MAX_RECEIVE,
            this::setChanged);

    private MetalFormerMode mode = MetalFormerMode.PLATE;
    private int progress;
    private int maxProgress = MetalFormerRecipe.DEFAULT_TIME;

    /** Datos que el menú sincroniza: progreso, tiempo total y modo. */
    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> progress;
                case 1 -> maxProgress;
                case 2 -> mode.ordinal();
                case DATA_ENERGY, DATA_ENERGY + 1 ->
                    ContainerDataInts.part(energy.getEnergyStored(), index - DATA_ENERGY);
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> progress = value;
                case 1 -> maxProgress = value;
                case 2 -> mode = MetalFormerMode.byId(value);
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public MetalFormerBlockEntity(BlockPos pos, BlockState state) {
        super(MetalFormerRegistry.BLOCK_ENTITY.get(), pos, state);
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ContainerData getData() {
        return data;
    }

    public MetalFormerMode getMode() {
        return mode;
    }

    public int getProgress() {
        return progress;
    }

    public void setMode(MetalFormerMode newMode) {
        if (newMode != mode) {
            mode = newMode;
            progress = 0;
            setChanged();
        }
    }

    @Nullable
    public IItemHandler getItemHandler(@Nullable Direction side) {
        if (side == null) {
            return items;
        }
        return side == Direction.DOWN ? outputSide : inputSide;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MetalFormerBlockEntity be) {
        BatterySlot.dischargeItem(be.items.getStackInSlot(SLOT_BATTERY), be.energy, Integer.MAX_VALUE);
        boolean working = be.tickWork(level);
        if (state.getValue(MetalFormerBlock.WORKING) != working) {
            level.setBlock(pos, state.setValue(MetalFormerBlock.WORKING, working), 3);
        }
    }

    /** Un tick de trabajo. Devuelve si la máquina está trabajando. */
    private boolean tickWork(Level level) {
        Optional<MetalFormerRecipes.Operation> op = MetalFormerRecipes.find(level, mode, items.getStackInSlot(SLOT_INPUT));
        if (op.isEmpty() || !canOutput(op.get().result())) {
            if (progress != 0) {
                progress = 0;
                setChanged();
            }
            return false;
        }
        MetalFormerRecipes.Operation operation = op.get();
        maxProgress = operation.time();
        if (RailgunConfig.energyRequired()
                && !energy.tryConsume(energyForTick(operation.energy(), operation.time(), progress))) {
            // Sin la energía del tick se pierde el progreso (decisión del usuario, igual que el original).
            if (progress != 0) {
                progress = 0;
                setChanged();
            }
            return false;
        }
        progress++;
        if (progress >= maxProgress) {
            progress = 0;
            items.extractItem(SLOT_INPUT, operation.inputCount(), false);
            items.insertItem(SLOT_OUTPUT, operation.result().copy(), false);
        }
        setChanged();
        return true;
    }

    /**
     * Energía del tick número {@code tick} (0 = primero) de una operación de {@code total} IF en {@code time} ticks:
     * reparto entero exacto (la suma de todos los ticks es {@code total}), de 13 o 14 IF con la receta por defecto.
     */
    public static int energyForTick(int total, int time, int tick) {
        if (time <= 0) {
            return 0;
        }
        return (int) ((long) total * (tick + 1) / time - (long) total * tick / time);
    }

    private boolean canOutput(ItemStack result) {
        return items.insertItem(SLOT_OUTPUT, result.copy(), true).isEmpty();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("items", items.serializeNBT(registries));
        tag.putString("mode", mode.getSerializedName());
        tag.putInt("progress", progress);
        energy.save(tag, "energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("items")) {
            items.deserializeNBT(registries, tag.getCompound("items"));
        }
        String name = tag.getString("mode");
        for (MetalFormerMode m : MetalFormerMode.values()) {
            if (m.getSerializedName().equals(name)) {
                mode = m;
            }
        }
        progress = tag.getInt("progress");
        energy.load(tag, "energy", registries);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.railgunreborn.metal_former");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new MetalFormerMenu(containerId, inventory, this);
    }
}
