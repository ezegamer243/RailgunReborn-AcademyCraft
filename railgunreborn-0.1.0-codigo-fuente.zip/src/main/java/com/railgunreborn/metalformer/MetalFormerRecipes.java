package com.railgunreborn.metalformer;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.Level;

/** Búsqueda de la operación que hará el Metal Former con una entrada y un modo. */
public final class MetalFormerRecipes {
    /**
     * Menas de otros mods (estaño, plata, plomo...) que el modo REFINE convierte en el doble de lo que da el horno, con
     * tope de 64, como hacía el original con el OreDictionary. Así no hace falta una receta por cada metal de cada mod.
     */
    public static final TagKey<Item> REFINE_BY_SMELTING = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "metal_former/refine_by_smelting"));

    /** Operación encontrada: cuántos ítems de entrada consume, qué da, cuánto tarda y cuánta energía gasta en total. */
    public record Operation(int inputCount, ItemStack result, int time, int energy) {
    }

    private MetalFormerRecipes() {
    }

    public static Optional<Operation> find(Level level, MetalFormerMode mode, ItemStack input) {
        if (input.isEmpty()) {
            return Optional.empty();
        }
        MetalFormerInput recipeInput = new MetalFormerInput(input, mode);
        Optional<Operation> fromRecipe = level.getRecipeManager()
                .getRecipeFor(MetalFormerRegistry.RECIPE_TYPE.get(), recipeInput, level)
                .map(h -> new Operation(h.value().ingredient().count(),
                        h.value().assemble(recipeInput, level.registryAccess()), h.value().time(),
                        h.value().energy()));
        if (fromRecipe.isPresent() || mode != MetalFormerMode.REFINE || !input.is(REFINE_BY_SMELTING)) {
            return fromRecipe;
        }
        SingleRecipeInput smeltInput = new SingleRecipeInput(input.copyWithCount(1));
        return level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, smeltInput, level).map(h -> {
            ItemStack out = h.value().assemble(smeltInput, level.registryAccess());
            out.setCount(Math.min(Math.min(out.getCount() * 2, 64), out.getMaxStackSize()));
            return new Operation(1, out, MetalFormerRecipe.DEFAULT_TIME, MetalFormerRecipe.DEFAULT_ENERGY);
        }).filter(op -> !op.result().isEmpty());
    }
}
