package com.railgunreborn.metalformer;

import com.mojang.serialization.Codec;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.StringRepresentable;

/** Modos del Metal Former, en el mismo orden que el original (TileMetalFormer.Mode). */
public enum MetalFormerMode implements StringRepresentable {
    PLATE, INCISE, ETCH, REFINE;

    public static final Codec<MetalFormerMode> CODEC = StringRepresentable.fromEnum(MetalFormerMode::values);
    public static final StreamCodec<ByteBuf, MetalFormerMode> STREAM_CODEC = ByteBufCodecs.VAR_INT
            .map(MetalFormerMode::byId, MetalFormerMode::ordinal);

    private final String name = name().toLowerCase(java.util.Locale.ROOT);

    @Override
    public String getSerializedName() {
        return name;
    }

    public String translationKey() {
        return "gui.railgunreborn.metal_former.mode." + name;
    }

    public MetalFormerMode next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public MetalFormerMode previous() {
        return values()[(ordinal() + values().length - 1) % values().length];
    }

    public static MetalFormerMode byId(int id) {
        MetalFormerMode[] all = values();
        return id >= 0 && id < all.length ? all[id] : PLATE;
    }
}
