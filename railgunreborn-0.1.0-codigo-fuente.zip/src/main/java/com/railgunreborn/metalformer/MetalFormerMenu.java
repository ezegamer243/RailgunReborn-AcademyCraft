package com.railgunreborn.metalformer;

import javax.annotation.Nullable;

import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Menú del Metal Former (GUI de 176x187). Las ranuras van centradas en las cajas del arte del original
 * ({@link TechUiLayout}). Los botones de modo usan {@link #clickMenuButton}: el servidor decide, sin paquete propio.
 */
public class MetalFormerMenu extends AbstractContainerMenu {
    public static final int BUTTON_PREVIOUS = 0;
    public static final int BUTTON_NEXT = 1;

    private static final int MACHINE_SLOTS = MetalFormerBlockEntity.SLOT_COUNT;
    private static final int PLAYER_START = MACHINE_SLOTS;
    private static final int PLAYER_END = PLAYER_START + 36;

    @Nullable
    private final MetalFormerBlockEntity blockEntity;
    private final ContainerLevelAccess access;
    private final ContainerData data;

    /** Cliente. */
    public MetalFormerMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, null, new ItemStackHandler(MACHINE_SLOTS), new SimpleContainerData(MetalFormerBlockEntity.DATA_COUNT),
                ContainerLevelAccess.create(inventory.player.level(), buf.readBlockPos()));
    }

    /** Servidor. */
    public MetalFormerMenu(int containerId, Inventory inventory, MetalFormerBlockEntity be) {
        this(containerId, inventory, be, be.getItems(), be.getData(),
                ContainerLevelAccess.create(be.getLevel(), be.getBlockPos()));
    }

    private MetalFormerMenu(int containerId, Inventory inventory, @Nullable MetalFormerBlockEntity be,
            IItemHandler items, ContainerData data, ContainerLevelAccess access) {
        super(MetalFormerRegistry.MENU.get(), containerId);
        this.blockEntity = be;
        this.access = access;
        this.data = data;
        addSlot(new SlotItemHandler(items, MetalFormerBlockEntity.SLOT_INPUT, TechUiLayout.INPUT_X, TechUiLayout.INPUT_Y));
        addSlot(new SlotItemHandler(items, MetalFormerBlockEntity.SLOT_OUTPUT, TechUiLayout.OUTPUT_X, TechUiLayout.OUTPUT_Y) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }
        });
        addSlot(new SlotItemHandler(items, MetalFormerBlockEntity.SLOT_BATTERY, TechUiLayout.BATTERY_X, TechUiLayout.BATTERY_Y) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                // La copia del cliente no tiene el filtro de la BlockEntity: se repite aquí.
                return BatterySlot.isEnergyItem(stack);
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, TechUiLayout.playerSlotX(col),
                        TechUiLayout.playerSlotY(row)));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, TechUiLayout.playerSlotX(col), TechUiLayout.playerSlotY(3)));
        }
        addDataSlots(data);
    }

    public int getProgress() {
        return data.get(0);
    }

    public int getMaxProgress() {
        return data.get(1);
    }

    public int getEnergy() {
        return ContainerDataInts.get(data, MetalFormerBlockEntity.DATA_ENERGY);
    }

    public MetalFormerMode getMode() {
        return MetalFormerMode.byId(data.get(2));
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (blockEntity == null || (id != BUTTON_PREVIOUS && id != BUTTON_NEXT)) {
            return false;
        }
        MetalFormerMode mode = blockEntity.getMode();
        blockEntity.setMode(id == BUTTON_NEXT ? mode.next() : mode.previous());
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < MACHINE_SLOTS) {
            if (!moveItemStackTo(stack, PLAYER_START, PLAYER_END, true)) {
                return ItemStack.EMPTY;
            }
        } else if (BatterySlot.isEnergyItem(stack)) {
            if (!moveItemStackTo(stack, MetalFormerBlockEntity.SLOT_BATTERY, MetalFormerBlockEntity.SLOT_BATTERY + 1,
                    false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, MetalFormerBlockEntity.SLOT_INPUT, MetalFormerBlockEntity.SLOT_INPUT + 1,
                false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, MetalFormerRegistry.METAL_FORMER.get());
    }
}
