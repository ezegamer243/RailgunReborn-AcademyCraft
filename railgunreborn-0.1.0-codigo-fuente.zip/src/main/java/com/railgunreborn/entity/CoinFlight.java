package com.railgunreborn.entity;

/**
 * Física pura del vuelo de la moneda (sin Minecraft, testeable). Se simula por tick igual que el original
 * ({@code docs/spec/railgun.md} 13.3): primero la gravedad sobre la velocidad y luego se mueve. La edad 1 es el
 * primer tick de vida de la entidad.
 */
public final class CoinFlight {
    /** Velocidad vertical añadida al lanzar, en bloques por tick. */
    public static final double BASE_SPEED = 0.92;
    public static final double GRAVITY = 0.06;
    /** El progreso por encima de este valor es la ventana del QTE del Railgun. */
    public static final double WINDOW_PROGRESS = 0.7;
    /** Tope de seguridad: 6 s. */
    public static final int MAX_TICKS = 120;

    private final double[] height = new double[MAX_TICKS + 2];
    private final double[] progress = new double[MAX_TICKS + 2];
    private final int landingTick;
    private final int firstWindowTick;
    private final double peak;

    public CoinFlight(double initialSpeed) {
        double y = 0;
        double v = initialSpeed;
        double max = 0;
        int landing = MAX_TICKS;
        double[] vel = new double[MAX_TICKS + 2];
        for (int t = 1; t <= MAX_TICKS; t++) {
            v -= GRAVITY;
            y += v;
            height[t] = y;
            vel[t] = v;
            max = Math.max(max, y);
            if (y < 0 && v < 0) {
                landing = t;
                break;
            }
        }
        this.peak = max;
        this.landingTick = landing;
        int first = landing;
        for (int t = 1; t < landing; t++) {
            double p;
            if (vel[t] > 0) {
                p = (BASE_SPEED - vel[t]) / BASE_SPEED * 0.5;
            } else if (peak <= 0) {
                p = 1;
            } else {
                p = Math.min(1, 0.5 + (peak - height[t]) / peak * 0.5);
            }
            progress[t] = Math.max(0, p);
            if (first == landing && progress[t] > WINDOW_PROGRESS) {
                first = t;
            }
        }
        this.firstWindowTick = first;
    }

    /** Primera edad en que la moneda ya no está en el aire: el vuelo termina aquí. */
    public int landingTick() {
        return landingTick;
    }

    /** Primera edad con progreso > 0.7. */
    public int firstWindowTick() {
        return firstWindowTick;
    }

    /** Última edad en vuelo con progreso > 0.7. */
    public int lastWindowTick() {
        return landingTick - 1;
    }

    public double peak() {
        return peak;
    }

    /** Altura sobre el punto de lanzamiento en la edad dada (0 antes de empezar). */
    public double heightAt(int age) {
        if (age <= 0) {
            return 0;
        }
        return height[Math.min(age, landingTick)];
    }

    /** Progreso 0 a 1 en la edad dada; 1 una vez aterrizada. */
    public double progressAt(int age) {
        if (age <= 0) {
            return 0;
        }
        if (age >= landingTick) {
            return 1;
        }
        return progress[age];
    }

    public boolean inWindow(int age, int toleranceTicks) {
        return age >= firstWindowTick && age <= lastWindowTick() + Math.max(0, toleranceTicks);
    }
}
