package com.railgunreborn.entity;

import java.util.UUID;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.ArcGenRules;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagManipRules;
import com.railgunreborn.ability.electromaster.MagManipRules.Cell;
import com.railgunreborn.ability.electromaster.MagManipSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.neoforged.neoforge.common.util.BlockSnapshot;
import net.neoforged.neoforge.event.EventHooks;

/**
 * Bloque metálico de Magnet Manipulation ({@code MagManipEntityBlock} del original): flota delante del dueño mientras
 * se sostiene ({@link Mode#HELD}), vuela con gravedad tras lanzarse ({@link Mode#THROWN}) o cae sin hacer daño si se
 * soltó sin lanzar ({@link Mode#FALLING}). Al chocar con un bloque se coloca; si no hay sitio o está protegido se
 * suelta como ítem: el material nunca se pierde. Se guarda en disco: al cargar, uno "sostenido" pasa a caer.
 *
 * <p>La física solo corre en el servidor; el cliente interpola las posiciones recibidas (llegan cada tick).
 */
public class MagneticBlockEntity extends Entity {
    public enum Mode {
        HELD,
        THROWN,
        FALLING;

        static Mode byId(int id) {
            Mode[] values = values();
            return id >= 0 && id < values.length ? values[id] : FALLING;
        }
    }

    private static final EntityDataAccessor<BlockState> DATA_BLOCK = SynchedEntityData.defineId(
            MagneticBlockEntity.class, EntityDataSerializers.BLOCK_STATE);
    private static final EntityDataAccessor<Byte> DATA_MODE = SynchedEntityData.defineId(MagneticBlockEntity.class,
            EntityDataSerializers.BYTE);

    /** Medio lado de la caja usada para el barrido contra bloques (un pelo menos que 0.5 para no rozar vecinos). */
    private static final double SWEEP_HALF = 0.49;

    @Nullable
    private UUID ownerId;
    @Nullable
    private ServerPlayer ownerCache;
    /** Lo pone el contexto que lo sostiene; sin él un bloque "sostenido" cae (p. ej. tras cargar el mundo). */
    private boolean controlled;
    private float damage;
    private int flightTicks;

    private int lerpSteps;
    private double lerpX;
    private double lerpY;
    private double lerpZ;

    public MagneticBlockEntity(EntityType<? extends MagneticBlockEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    /** Crea y añade el bloque con su centro en {@code center}, sostenido por {@code owner} (solo servidor). */
    public static MagneticBlockEntity spawnHeld(ServerPlayer owner, BlockState state, Vec3 center) {
        MagneticBlockEntity entity = new MagneticBlockEntity(ModEntities.MAGNETIC_BLOCK.get(), owner.level());
        entity.setBlockState(state);
        entity.ownerId = owner.getUUID();
        entity.ownerCache = owner;
        entity.controlled = true;
        entity.setPos(center.x, center.y - 0.5, center.z);
        owner.level().addFreshEntity(entity);
        return entity;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_BLOCK, Blocks.IRON_BLOCK.defaultBlockState());
        builder.define(DATA_MODE, (byte) Mode.HELD.ordinal());
    }

    public BlockState getBlockState() {
        return entityData.get(DATA_BLOCK);
    }

    private void setBlockState(BlockState state) {
        entityData.set(DATA_BLOCK, state);
    }

    public Mode getMode() {
        return Mode.byId(entityData.get(DATA_MODE));
    }

    private void setMode(Mode mode) {
        entityData.set(DATA_MODE, (byte) mode.ordinal());
    }

    public boolean isHeld() {
        return getMode() == Mode.HELD;
    }

    public Vec3 getCenter() {
        return position().add(0, 0.5, 0);
    }

    public boolean isOwnedBy(Player player) {
        return player.getUUID().equals(ownerId);
    }

    /** Lanza con esa velocidad; el impacto con un ser vivo hará {@code damage} (ya escalado). */
    public void launch(Vec3 velocity, float damage) {
        this.controlled = false;
        this.damage = damage;
        this.flightTicks = 0;
        setDeltaMovement(velocity);
        setMode(Mode.THROWN);
    }

    /** Deja de sostenerlo sin lanzar: cae con la velocidad que llevaba y se coloca donde choque, sin daño. */
    public void drop() {
        this.controlled = false;
        this.flightTicks = 0;
        if (getMode() == Mode.HELD) {
            setMode(Mode.FALLING);
        }
    }

    @Nullable
    private ServerPlayer owner() {
        if (ownerCache != null && !ownerCache.isRemoved()) {
            return ownerCache;
        }
        ownerCache = null;
        if (ownerId != null && level() instanceof ServerLevel server
                && server.getPlayerByUUID(ownerId) instanceof ServerPlayer player) {
            ownerCache = player;
        }
        return ownerCache;
    }

    // --- Tick ---

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (lerpSteps > 0) {
                double f = 1.0 / lerpSteps;
                setPos(getX() + (lerpX - getX()) * f, getY() + (lerpY - getY()) * f, getZ() + (lerpZ - getZ()) * f);
                lerpSteps--;
            }
            return;
        }
        if (isRemoved()) {
            return;
        }
        if (getBlockState().isAir()) {
            discard();
            return;
        }
        if (getMode() == Mode.HELD) {
            tickHeld();
        } else {
            tickFlight();
        }
    }

    private void tickHeld() {
        ServerPlayer owner = owner();
        if (!controlled || owner == null || !owner.isAlive() || owner.level() != level()) {
            drop();
            return;
        }
        Vec3 eyes = owner.getEyePosition();
        Vec3 look = owner.getViewVector(1.0f);
        Vec3 far = eyes.add(look.scale(MagManipRules.HOLD_DISTANCE));
        BlockHitResult wall = level().clip(new ClipContext(eyes, far, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, owner));
        double wallDistance = wall.getType() == HitResult.Type.MISS ? Double.NaN : wall.getLocation().distanceTo(eyes);
        Vec3 target = MagManipRules.holdPoint(eyes, look, wallDistance);
        Vec3 velocity = MagManipRules.holdVelocity(getCenter(), target);
        setDeltaMovement(velocity);
        setPos(getX() + velocity.x, getY() + velocity.y, getZ() + velocity.z);
    }

    private void tickFlight() {
        if (++flightTicks > MagManipRules.MAX_FLIGHT_TICKS) {
            dropAsItem(getCenter());
            return;
        }
        Vec3 velocity = getDeltaMovement();
        Vec3 center = getCenter();
        double length = velocity.length();
        if (length > 1e-7) {
            BlockHitResult blockHit = sweepBlocks(center, velocity);
            double blockT = blockHit == null ? Double.POSITIVE_INFINITY
                    : blockHit.getLocation().subtract(center).dot(velocity) / (length * length);
            if (getMode() == Mode.THROWN) {
                double[] entityT = {Double.POSITIVE_INFINITY};
                LivingEntity victim = sweepEntities(center, velocity, entityT);
                if (victim != null && entityT[0] <= blockT) {
                    hitEntity(victim, center.add(velocity.scale(Math.max(0, entityT[0]))));
                    return;
                }
            }
            if (blockHit != null) {
                land(blockHit);
                return;
            }
        }
        setPos(getX() + velocity.x, getY() + velocity.y, getZ() + velocity.z);
        setDeltaMovement(velocity.x, velocity.y - MagManipRules.GRAVITY, velocity.z);
    }

    /**
     * Barrido contra bloques con colisión: el rayo del centro y de las 8 esquinas de la caja (como el original). El
     * fluido no detiene. Devuelve el impacto más cercano, con la posición <i>del centro</i> en ese momento.
     */
    @Nullable
    private BlockHitResult sweepBlocks(Vec3 center, Vec3 velocity) {
        BlockHitResult best = null;
        double bestDist = Double.POSITIVE_INFINITY;
        for (int i = 0; i < 9; i++) {
            Vec3 offset = i == 8 ? Vec3.ZERO : new Vec3((i & 1) == 0 ? -SWEEP_HALF : SWEEP_HALF,
                    (i & 2) == 0 ? -SWEEP_HALF : SWEEP_HALF, (i & 4) == 0 ? -SWEEP_HALF : SWEEP_HALF);
            Vec3 from = center.add(offset);
            BlockHitResult hit = level().clip(new ClipContext(from, from.add(velocity), ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, CollisionContext.empty()));
            if (hit.getType() != HitResult.Type.BLOCK) {
                continue;
            }
            double dist = hit.getLocation().distanceToSqr(from);
            if (dist < bestDist) {
                bestDist = dist;
                best = new BlockHitResult(hit.getLocation().subtract(offset), hit.getDirection(), hit.getBlockPos(),
                        hit.isInside());
            }
        }
        return best;
    }

    /** Primer ser vivo que corta la caja del bloque en su recorrido (suma de Minkowski con medio bloque). */
    @Nullable
    private LivingEntity sweepEntities(Vec3 center, Vec3 velocity, double[] outT) {
        ServerPlayer owner = owner();
        AABB search = getBoundingBox().expandTowards(velocity).inflate(1.0);
        LivingEntity best = null;
        double lengthSqr = velocity.lengthSqr();
        for (Entity entity : level().getEntities(this, search, e -> canHit(e, owner))) {
            AABB box = entity.getBoundingBox().inflate(0.5);
            double t;
            if (box.contains(center)) {
                t = 0;
            } else {
                var clip = box.clip(center, center.add(velocity));
                if (clip.isEmpty()) {
                    continue;
                }
                t = clip.get().subtract(center).dot(velocity) / lengthSqr;
            }
            if (t < outT[0]) {
                outT[0] = t;
                best = (LivingEntity) entity;
            }
        }
        return best;
    }

    /** Seres vivos salvo el lanzador; un jugador protegido por PvP no cuenta: el bloque lo atraviesa. */
    private static boolean canHit(Entity entity, @Nullable ServerPlayer owner) {
        if (!(entity instanceof LivingEntity) || !entity.isAlive() || entity.isSpectator() || !entity.isPickable()
                || entity == owner) {
            return false;
        }
        if (entity instanceof Player other) {
            return owner != null && ArcGenRules.canDamagePlayer(MagManipSkill.ATTACK_PLAYER, owner.canHarmPlayer(other));
        }
        return true;
    }

    /** Daña al primero que toca y se detiene ahí (decisión 5): desde ese punto cae sin hacer más daño. */
    private void hitEntity(LivingEntity victim, Vec3 contactCenter) {
        ServerPlayer owner = owner();
        // Sin dueño conectado no hay a quién atribuir el daño (mensaje de muerte): solo se detiene.
        if (owner != null) {
            victim.hurt(damageSources().source(ModDamageTypes.MAG_MANIP, this, owner), damage);
        }
        setPos(contactCenter.x, contactCenter.y - 0.5, contactCenter.z);
        setDeltaMovement(Vec3.ZERO);
        setMode(Mode.FALLING);
    }

    // --- Colocación ---

    /** Coloca el bloque cerca del impacto (protecciones como Arc Gen); si no puede, lo suelta como ítem. */
    private void land(BlockHitResult hit) {
        ServerLevel level = (ServerLevel) level();
        ServerPlayer owner = owner();
        MagManipSkill skill = Electromaster.MAG_MANIP.get();
        if (owner != null && skill.mayModifyWorld(owner)) {
            BlockPos hitPos = hit.getBlockPos();
            Direction face = hit.getDirection();
            for (Cell cell : MagManipRules.placementCandidates(new Cell(hitPos.getX(), hitPos.getY(), hitPos.getZ()),
                    face.getStepX(), face.getStepY(), face.getStepZ())) {
                BlockPos pos = new BlockPos(cell.x(), cell.y(), cell.z());
                BlockState state = placeState(level, pos);
                if (!level.isInWorldBounds(pos) || !level.getBlockState(pos).canBeReplaced()
                        || !state.canSurvive(level, pos)
                        || !level.isUnobstructed(state, pos, CollisionContext.empty())
                        || !MagManipSkill.mayPlaceAt(owner, pos)) {
                    continue;
                }
                if (place(level, owner, pos, state, face)) {
                    discard();
                    return;
                }
                break; // un mod de protección lo canceló: no buscar otro sitio
            }
        }
        dropAsItem(hit.getLocation());
    }

    /** El estado guardado, adaptado a los vecinos (rieles, barrotes) y al agua de la casilla. */
    private BlockState placeState(ServerLevel level, BlockPos pos) {
        BlockState state = Block.updateFromNeighbourShapes(getBlockState(), level, pos);
        if (state.hasProperty(BlockStateProperties.WATERLOGGED)) {
            state = state.setValue(BlockStateProperties.WATERLOGGED,
                    level.getFluidState(pos).getType() == Fluids.WATER);
        }
        return state;
    }

    /** Como al colocar con NeoForge: foto, colocar, evento; si alguien lo cancela se deshace. */
    private static boolean place(ServerLevel level, ServerPlayer owner, BlockPos pos, BlockState state, Direction face) {
        BlockSnapshot snapshot = BlockSnapshot.create(level.dimension(), level, pos);
        level.setBlock(pos, state, Block.UPDATE_ALL);
        if (EventHooks.onBlockPlace(owner, snapshot, face)) {
            snapshot.restore();
            return false;
        }
        level.gameEvent(owner, GameEvent.BLOCK_PLACE, pos);
        SoundType sound = state.getSoundType(level, pos, owner);
        level.playSound(null, pos, sound.getPlaceSound(), SoundSource.BLOCKS, (sound.getVolume() + 1f) / 2f,
                sound.getPitch() * 0.8f);
        return true;
    }

    private void dropAsItem(Vec3 at) {
        ItemStack stack = new ItemStack(getBlockState().getBlock());
        if (stack.isEmpty()) {
            RailgunReborn.LOGGER.warn("Magnet Manipulation: {} has no item form and could not be placed",
                    getBlockState());
        } else {
            ItemEntity item = new ItemEntity(level(), at.x, at.y, at.z, stack);
            item.setDeltaMovement(Vec3.ZERO);
            item.setDefaultPickUpDelay();
            level().addFreshEntity(item);
        }
        discard();
    }

    // --- Cliente ---

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpSteps = Math.max(1, steps);
    }

    @Override
    public double lerpTargetX() {
        return lerpSteps > 0 ? lerpX : getX();
    }

    @Override
    public double lerpTargetY() {
        return lerpSteps > 0 ? lerpY : getY();
    }

    @Override
    public double lerpTargetZ() {
        return lerpSteps > 0 ? lerpZ : getZ();
    }

    // --- Varios ---

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 128 * 128;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setBlockState(NbtUtils.readBlockState(level().holderLookup(Registries.BLOCK), tag.getCompound("block_state")));
        ownerId = tag.hasUUID("owner") ? tag.getUUID("owner") : null;
        damage = tag.getFloat("damage");
        flightTicks = tag.getInt("flight_ticks");
        Mode mode = Mode.byId(tag.getByte("mode"));
        // Ningún contexto sobrevive a un guardado: lo que estaba sostenido cae y se coloca.
        setMode(mode == Mode.HELD ? Mode.FALLING : mode);
        controlled = false;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("block_state", NbtUtils.writeBlockState(getBlockState()));
        if (ownerId != null) {
            tag.putUUID("owner", ownerId);
        }
        tag.putFloat("damage", damage);
        tag.putInt("flight_ticks", flightTicks);
        tag.putByte("mode", (byte) getMode().ordinal());
    }
}
