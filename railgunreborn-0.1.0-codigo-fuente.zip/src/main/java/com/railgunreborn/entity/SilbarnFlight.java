package com.railgunreborn.entity;

/** Física pura del Silicon Barn lanzado (sin Minecraft): rozamiento por tick y gravedad que empieza tarde. */
public final class SilbarnFlight {
    /** Velocidad inicial en bloques/tick a lo largo de la mirada. */
    public static final double LAUNCH_SPEED = 1.0;
    /** Se multiplica la velocidad por este factor cada tick. */
    public static final double DRAG = 0.8;
    /** Ticks sin gravedad (2.5 s). */
    public static final int HOVER_TICKS = 50;
    public static final double GRAVITY = 0.12;
    /** Vida máxima de seguridad (20 s). */
    public static final int MAX_LIFETIME = 400;
    /** Ticks entre el choque (o disparo) y la eliminación. */
    public static final int REMOVE_DELAY = 10;

    private SilbarnFlight() {
    }

    /** Gravedad aplicada en el tick de edad {@code age} (1 = primer tick). */
    public static double gravityAt(int age) {
        return age > HOVER_TICKS ? GRAVITY : 0.0;
    }

    /** Nueva velocidad vertical: primero la gravedad, luego el rozamiento. */
    public static double nextVerticalVelocity(double vy, int age) {
        return (vy - gravityAt(age)) * DRAG;
    }

    /** Nueva velocidad horizontal (un eje): solo rozamiento. */
    public static double nextHorizontalVelocity(double v) {
        return v * DRAG;
    }
}
