package com.railgunreborn.entity;

import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/** Se publica (servidor, bus de NeoForge) cuando un jugador lanza una moneda; punto de enganche para otras habilidades. */
public class CoinThrowEvent extends PlayerEvent {
    private final CoinEntity coin;

    public CoinThrowEvent(Player player, CoinEntity coin) {
        super(player);
        this.coin = coin;
    }

    public CoinEntity getCoin() {
        return coin;
    }
}
