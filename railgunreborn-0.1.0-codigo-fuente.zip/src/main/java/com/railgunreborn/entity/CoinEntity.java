package com.railgunreborn.entity;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.Nullable;

import com.railgunreborn.registry.ModEntities;
import com.railgunreborn.registry.ModItems;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Moneda lanzada con el clic derecho. Servidor y cliente simulan el mismo vuelo de forma determinista a partir de
 * la edad ({@link CoinFlight}); la X/Z sigue al dueño. No se guarda en disco. La fuente de verdad del QTE del Railgun
 * es la del servidor ({@link #isInQteWindow(int)}).
 */
public class CoinEntity extends Entity {
    /** Tolerancia de latencia del servidor para aceptar el disparo tras el fin visual del vuelo. */
    public static final int QTE_TOLERANCE_TICKS = 4;
    /** Altura de la mano respecto a los pies, donde empieza el vuelo. */
    public static final double HAND_HEIGHT = 1.0;

    private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER = SynchedEntityData.defineId(CoinEntity.class,
            EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Float> DATA_SPEED = SynchedEntityData.defineId(CoinEntity.class,
            EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_BASE_Y = SynchedEntityData.defineId(CoinEntity.class,
            EntityDataSerializers.FLOAT);

    private CoinFlight flight;
    private float flightSpeed = Float.NaN;
    private boolean refundOnEnd;
    private boolean consumed;
    private boolean attemptSpent;

    public CoinEntity(EntityType<? extends CoinEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    /** Crea y añade la moneda en la mano del jugador (solo servidor). */
    public static CoinEntity spawn(Player owner, boolean refundOnEnd) {
        Level level = owner.level();
        CoinEntity coin = new CoinEntity(ModEntities.COIN.get(), level);
        double baseY = owner.getY() + HAND_HEIGHT;
        coin.entityData.set(DATA_OWNER, Optional.of(owner.getUUID()));
        coin.entityData.set(DATA_BASE_Y, (float) baseY);
        coin.entityData.set(DATA_SPEED, (float) (CoinFlight.BASE_SPEED
                + Math.max(-0.1, Math.min(0.6, owner.getDeltaMovement().y))));
        coin.refundOnEnd = refundOnEnd;
        coin.setPos(owner.getX(), baseY, owner.getZ());
        level.addFreshEntity(coin);
        return coin;
    }

    /** La moneda activa (viva, en vuelo o en el margen de tolerancia) del jugador, si la hay. Sirve en cliente y servidor. */
    @Nullable
    public static CoinEntity findActive(Player player) {
        List<CoinEntity> coins = player.level().getEntitiesOfClass(CoinEntity.class,
                player.getBoundingBox().inflate(4, 16, 4), c -> c.isAlive() && c.isOwnedBy(player));
        return coins.isEmpty() ? null : coins.get(0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_OWNER, Optional.empty());
        builder.define(DATA_SPEED, (float) CoinFlight.BASE_SPEED);
        builder.define(DATA_BASE_Y, 0f);
    }

    public CoinFlight flight() {
        float speed = entityData.get(DATA_SPEED);
        if (flight == null || speed != flightSpeed) {
            flightSpeed = speed;
            flight = new CoinFlight(speed);
        }
        return flight;
    }

    public boolean isOwnedBy(Player player) {
        return entityData.get(DATA_OWNER).map(id -> id.equals(player.getUUID())).orElse(false);
    }

    @Nullable
    public Player getOwner() {
        return entityData.get(DATA_OWNER).map(level()::getPlayerByUUID).orElse(null);
    }

    /** Edad de vuelo en ticks (1 = primer tick). */
    public int getAge() {
        return tickCount;
    }

    /** Progreso del vuelo 0 a 1 (0.5 en el punto más alto). */
    public float getProgress() {
        return (float) flight().progressAt(tickCount);
    }

    /** La moneda sigue en el aire (se dibuja); tras aterrizar espera unos ticks de tolerancia sin dibujarse. */
    public boolean isFlying() {
        return tickCount < flight().landingTick();
    }

    /** Ventana estricta (progreso &gt; 0.7, sin tolerancia): para el aviso visual del cliente. */
    public boolean isInQteWindow() {
        return isInQteWindow(0);
    }

    /** Ventana con tolerancia de latencia en ticks (el servidor usa {@link #QTE_TOLERANCE_TICKS}). */
    public boolean isInQteWindow(int toleranceTicks) {
        return isAlive() && !consumed && flight().inWindow(tickCount, toleranceTicks);
    }

    public boolean isAttemptSpent() {
        return attemptSpent;
    }

    /** Un solo intento por moneda: pulsar antes de la ventana lo gasta (el siguiente disparo falla). */
    public void spendAttempt() {
        attemptSpent = true;
    }

    /** La moneda se gasta en un disparo: desaparece sin devolverse al jugador. */
    public void consume() {
        consumed = true;
        discard();
    }

    /** Altura de la moneda sobre la mano. */
    public double getHeightAboveHand() {
        return flight().heightAt(tickCount);
    }

    @Override
    public void tick() {
        super.tick();
        Player owner = getOwner();
        if (!level().isClientSide) {
            if (owner == null || !owner.isAlive() || owner.isRemoved() || owner.level() != level()
                    || tickCount >= flight().landingTick() + QTE_TOLERANCE_TICKS) {
                discard();
                return;
            }
        }
        double x = owner != null ? owner.getX() : getX();
        double z = owner != null ? owner.getZ() : getZ();
        setPos(x, entityData.get(DATA_BASE_Y) + flight().heightAt(tickCount), z);
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && !consumed && refundOnEnd && !isRemoved()) {
            refundOnEnd = false;
            giveBack();
        }
        super.remove(reason);
    }

    // Devuelve la moneda: mano principal si está vacía, si no al inventario y, si no cabe, cae como ítem.
    private void giveBack() {
        ItemStack coin = new ItemStack(ModItems.COIN.get());
        Player owner = getOwner();
        if (owner != null && owner.isAlive()) {
            if (owner.getMainHandItem().isEmpty()) {
                owner.setItemInHand(InteractionHand.MAIN_HAND, coin);
                return;
            }
            owner.getInventory().add(coin);
            if (coin.isEmpty()) {
                return;
            }
        }
        double x = owner != null ? owner.getX() : getX();
        double y = owner != null ? owner.getY() + 0.6 : getY();
        double z = owner != null ? owner.getZ() : getZ();
        level().addFreshEntity(new ItemEntity(level(), x, y, z, coin));
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }
}
