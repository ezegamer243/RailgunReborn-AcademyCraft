package com.railgunreborn.entity;

import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.registry.ModEntities;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Silicon Barn lanzado con el clic derecho. La física corre en el servidor ({@link SilbarnFlight}); el cliente
 * recibe la posición por el rastreo normal. Un barn "usable" es el que no ha chocado ni se ha disparado:
 * Ray Barrage (T49) lo busca con {@link #findLookedAt} y lo gasta con {@link #consume()}.
 */
public class SilbarnEntity extends Entity {
    private static final EntityDataAccessor<Boolean> DATA_HIT = SynchedEntityData.defineId(SilbarnEntity.class,
            EntityDataSerializers.BOOLEAN);
    /** Margen añadido a la caja al apuntar. */
    public static final double AIM_MARGIN = 0.3;

    private int removeAtTick = -1;
    private boolean hitHandled;

    public SilbarnEntity(EntityType<? extends SilbarnEntity> type, Level level) {
        super(type, level);
    }

    /** Lanza un barn desde los ojos del jugador a lo largo de su mirada (solo servidor). */
    public static SilbarnEntity launch(Player player) {
        Level level = player.level();
        SilbarnEntity barn = new SilbarnEntity(ModEntities.SILBARN.get(), level);
        Vec3 eye = player.getEyePosition();
        barn.setPos(eye.x, eye.y - barn.getBbHeight() / 2, eye.z);
        barn.setDeltaMovement(player.getLookAngle().scale(SilbarnFlight.LAUNCH_SPEED));
        barn.setYRot(player.getYHeadRot());
        level.addFreshEntity(barn);
        return barn;
    }

    /**
     * El barn usable más cercano que {@code player} mira a menos de {@code range} bloques (cualquiera, sea quien
     * sea su lanzador), sin bloques en medio. Sirve en cliente y servidor.
     */
    @Nullable
    public static SilbarnEntity findLookedAt(Player player, double range) {
        Level level = player.level();
        Vec3 from = player.getEyePosition();
        Vec3 to = from.add(player.getViewVector(1.0f).scale(range));
        double blockDist = range * range;
        HitResult block = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                player));
        if (block.getType() != HitResult.Type.MISS) {
            blockDist = block.getLocation().distanceToSqr(from);
        }
        List<SilbarnEntity> candidates = level.getEntitiesOfClass(SilbarnEntity.class,
                new AABB(from, to).inflate(1.0), SilbarnEntity::isUsable);
        SilbarnEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (SilbarnEntity barn : candidates) {
            var hit = barn.getBoundingBox().inflate(AIM_MARGIN).clip(from, to);
            if (hit.isPresent()) {
                double dist = hit.get().distanceToSqr(from);
                if (dist < bestDist && dist <= blockDist) {
                    best = barn;
                    bestDist = dist;
                }
            }
        }
        return best;
    }

    /** Sigue en el aire y sin chocar ni haber sido disparado: válido para Ray Barrage. */
    public boolean isUsable() {
        return isAlive() && !isHit();
    }

    public boolean isHit() {
        return entityData.get(DATA_HIT);
    }

    /** Centro de la caja: desde donde se dibujan los rayos. */
    public Vec3 getCenter() {
        return getBoundingBox().getCenter();
    }

    /**
     * Gasta el barn (solo servidor): queda como chocado, suena el sonido pesado y se elimina a los 10 ticks.
     * Devuelve false si ya no era usable.
     */
    public boolean consume() {
        if (level().isClientSide || !isUsable()) {
            return false;
        }
        markHit(true);
        return true;
    }

    /** Igual que {@link #consume()}, sin devolver nada. */
    public void shatter() {
        consume();
    }

    private void markHit(boolean heavy) {
        entityData.set(DATA_HIT, true);
        removeAtTick = tickCount + SilbarnFlight.REMOVE_DELAY;
        level().playSound(null, getX(), getY(), getZ(), heavy ? ModSounds.SILBARN_HEAVY.get()
                : ModSounds.SILBARN_LIGHT.get(), SoundSource.NEUTRAL, 0.5f, 1.0f);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_HIT, false);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_HIT.equals(key) && level().isClientSide && isHit() && !hitHandled) {
            hitHandled = true;
            spawnFragments();
        }
    }

    // Fragmentos con partículas de ítem (18 a 26, velocidad aleatoria y un empujón hacia arriba).
    private void spawnFragments() {
        var particle = new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(ModItems.SILBARN.get()));
        int count = 18 + random.nextInt(9);
        Vec3 c = getCenter();
        for (int i = 0; i < count; i++) {
            Vec3 dir = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian()).normalize();
            double speed = 0.08 + random.nextDouble() * 0.1;
            level().addParticle(particle, c.x, c.y, c.z, dir.x * speed, dir.y * speed + 0.2, dir.z * speed);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (removeAtTick >= 0 && tickCount >= removeAtTick) {
            discard();
            return;
        }
        if (tickCount > SilbarnFlight.MAX_LIFETIME || getY() < level().getMinBuildHeight() - 16) {
            discard();
            return;
        }
        Vec3 v = getDeltaMovement();
        setDeltaMovement(SilbarnFlight.nextHorizontalVelocity(v.x),
                SilbarnFlight.nextVerticalVelocity(v.y, tickCount), SilbarnFlight.nextHorizontalVelocity(v.z));
        move(MoverType.SELF, getDeltaMovement());
        if (!isHit() && (horizontalCollision || verticalCollision)) {
            markHit(false);
        }
    }

    /** Se puede apuntar a él (trazados de mirada), pero no es un obstáculo físico. */
    @Override
    public boolean isPickable() {
        return isUsable();
    }

    @Override
    public boolean isNoGravity() {
        return true;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    /** Sonido del lanzamiento: el del huevo de vanilla, con tono grave aleatorio. */
    public static void playThrowSound(Player player) {
        float pitch = 0.4f / (player.getRandom().nextFloat() * 0.4f + 0.8f);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.EGG_THROW,
                SoundSource.PLAYERS, 0.5f, pitch);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }
}
