package com.railgunreborn.item;

import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.entity.CoinThrowEvent;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.NeoForge;

/** Moneda: el clic derecho la lanza al aire. Solo una moneda en el aire por jugador. */
public class CoinItem extends Item {
    public CoinItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (CoinEntity.findActive(player) != null) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide) {
            boolean creative = player.getAbilities().instabuild;
            CoinEntity coin = CoinEntity.spawn(player, !creative);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.COIN_FLIP.get(),
                    SoundSource.PLAYERS, 0.5f, 1.0f);
            if (!creative) {
                stack.shrink(1);
            }
            NeoForge.EVENT_BUS.post(new CoinThrowEvent(player, coin));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
