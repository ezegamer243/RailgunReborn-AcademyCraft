package com.railgunreborn.item;

import com.railgunreborn.terminal.TerminalAccess;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Data Terminal: el clic derecho instala el Terminal para el jugador (una vez) y consume el ítem. */
public class TerminalInstallerItem extends Item {
    public TerminalInstallerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        // Se mira el dato y no isInstalled: un jugador en creativo también debe poder instalarlo de verdad.
        if (TerminalAccess.hasInstalledFlag(serverPlayer)) {
            serverPlayer.displayClientMessage(Component.translatable("railgunreborn.terminal.already_installed"), true);
            return InteractionResultHolder.fail(stack);
        }
        TerminalAccess.setInstalled(serverPlayer, true);
        level.playSound(null, serverPlayer.getX(), serverPlayer.getY(), serverPlayer.getZ(),
                SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.8f, 1.5f);
        // La tecla va como argumento: cada cliente la resuelve con su propia configuración.
        serverPlayer.sendSystemMessage(Component.translatable("railgunreborn.terminal.installed",
                Component.keybind("key.railgunreborn.open_terminal")));
        if (!serverPlayer.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
