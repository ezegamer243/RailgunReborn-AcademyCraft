package com.railgunreborn.item;

import java.util.List;

import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;
import com.railgunreborn.registry.ModDataComponents;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.neoforged.neoforge.energy.ComponentEnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Batería de mano (energy.md 1.1). La Energy Unit guarda 10 000 IF con 20 IF por operación; las baterías High
 * (20 000 / 40) y Mega (40 000 / 80) usan la misma clase con otros parámetros (T110). La energía vive en el
 * componente {@code railgunreborn:energy}; la capacidad FE se registra en ModCapabilities. Se fabrican vacías.
 * Textura según la carga (predicado {@code railgunreborn:energy}, ver EnergyUnitClient).
 */
public class EnergyUnitItem extends Item {
    public static final int CAPACITY = 10_000;
    public static final int MAX_TRANSFER = 20;
    public static final int HIGH_CAPACITY = 20_000;
    public static final int HIGH_MAX_TRANSFER = 40;
    public static final int MEGA_CAPACITY = 40_000;
    public static final int MEGA_MAX_TRANSFER = 80;
    private static final int BAR_COLOR = 0x3FD3FF;

    private final int capacity;
    private final int maxTransfer;

    public EnergyUnitItem(Properties properties) {
        this(properties, CAPACITY, MAX_TRANSFER);
    }

    public EnergyUnitItem(Properties properties, int capacity, int maxTransfer) {
        super(properties);
        this.capacity = capacity;
        this.maxTransfer = maxTransfer;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getMaxTransfer() {
        return maxTransfer;
    }

    /** Capacidad de la pila: la de su ítem, o la de la Energy Unit si no es una batería nuestra. */
    public static int capacityOf(ItemStack stack) {
        return stack.getItem() instanceof EnergyUnitItem unit ? unit.capacity : CAPACITY;
    }

    public static IEnergyStorage createStorage(ItemStack stack) {
        int transfer = stack.getItem() instanceof EnergyUnitItem unit ? unit.maxTransfer : MAX_TRANSFER;
        return new ComponentEnergyStorage(stack, ModDataComponents.ENERGY.get(), capacityOf(stack), transfer);
    }

    public static int getEnergy(ItemStack stack) {
        return Math.max(0, Math.min(capacityOf(stack), stack.getOrDefault(ModDataComponents.ENERGY.get(), 0)));
    }

    public static ItemStack withEnergy(ItemStack stack, int energy) {
        stack.set(ModDataComponents.ENERGY.get(), Math.max(0, Math.min(capacityOf(stack), energy)));
        return stack;
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return EnergyMath.barWidth(getEnergy(stack), capacity, 13);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return BAR_COLOR;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.railgunreborn.energy_stored",
                EnergyFormat.fraction(getEnergy(stack), capacity)).withStyle(ChatFormatting.GRAY));
    }
}
