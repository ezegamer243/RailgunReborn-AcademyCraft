package com.railgunreborn.item;

import java.util.List;
import java.util.Optional;

import com.railgunreborn.registry.ModDataComponents;
import com.railgunreborn.registry.ModItems;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * Ability Induction Factor: consumible que fija la categoría al desarrollarla en la consola del Developer. Un solo
 * ítem; la categoría va en el componente {@link ModDataComponents#FACTOR_CATEGORY}.
 */
public class InductionFactorItem extends Item {
    public InductionFactorItem(Properties properties) {
        super(properties);
    }

    public static ItemStack of(ResourceLocation category) {
        ItemStack stack = new ItemStack(ModItems.INDUCTION_FACTOR.get());
        stack.set(ModDataComponents.FACTOR_CATEGORY.get(), category);
        return stack;
    }

    public static Optional<ResourceLocation> categoryOf(ItemStack stack) {
        return Optional.ofNullable(stack.get(ModDataComponents.FACTOR_CATEGORY.get()));
    }

    /** Ranura del inventario con un factor de esa categoría, o -1. */
    public static int findSlot(Inventory inventory, ResourceLocation category) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.is(ModItems.INDUCTION_FACTOR.get()) && category.equals(categoryOf(stack).orElse(null))) {
                return i;
            }
        }
        return -1;
    }

    public static boolean has(Player player, ResourceLocation category) {
        return findSlot(player.getInventory(), category) >= 0;
    }

    /** Gasta un factor de esa categoría; false si no había. */
    public static boolean consumeOne(Player player, ResourceLocation category) {
        int slot = findSlot(player.getInventory(), category);
        if (slot < 0) {
            return false;
        }
        player.getInventory().getItem(slot).shrink(1);
        return true;
    }

    /** Nombre por clave de traducción (no depende del registro de categorías, que el cliente puede no tener a mano). */
    private static Component categoryName(ResourceLocation category) {
        return Component.translatable(category.getNamespace() + ".ability." + category.getPath() + ".name");
    }

    @Override
    public Component getName(ItemStack stack) {
        return categoryOf(stack)
                .<Component>map(c -> Component.translatable("item.railgunreborn.induction_factor.named", categoryName(c)))
                .orElseGet(() -> super.getName(stack));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.railgunreborn.induction_factor.tooltip")
                .withStyle(ChatFormatting.GRAY));
    }
}
