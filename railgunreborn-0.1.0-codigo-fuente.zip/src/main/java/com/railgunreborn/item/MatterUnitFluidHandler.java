package com.railgunreborn.item;

import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;

import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

/**
 * Capacidad de fluido de la unidad de materia: un depósito de 1000 mB que solo admite líquido de fase, todo o nada
 * (como el cubo). Al llenarse/vaciarse cambia el ítem contenedor (vacía <-> llena). Como {@code FluidBucketWrapper},
 * no hace nada con pilas de más de una unidad: quien la use separa una (FluidUtil ya lo hace).
 */
public class MatterUnitFluidHandler implements IFluidHandlerItem {
    public static final int CAPACITY = 1000;

    private ItemStack container;

    public MatterUnitFluidHandler(ItemStack container) {
        this.container = container;
    }

    private boolean isFull() {
        return container.is(ModItems.MATTER_UNIT_PHASE_LIQUID.get());
    }

    @Override
    public ItemStack getContainer() {
        return container;
    }

    @Override
    public int getTanks() {
        return 1;
    }

    @Override
    public FluidStack getFluidInTank(int tank) {
        return isFull() ? new FluidStack(ModFluids.PHASE_LIQUID.get(), CAPACITY) : FluidStack.EMPTY;
    }

    @Override
    public int getTankCapacity(int tank) {
        return CAPACITY;
    }

    @Override
    public boolean isFluidValid(int tank, FluidStack stack) {
        return stack.getFluid().isSame(ModFluids.PHASE_LIQUID.get());
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (container.getCount() != 1 || isFull() || !container.is(ModItems.MATTER_UNIT.get())
                || resource.getAmount() < CAPACITY || !isFluidValid(0, resource)) {
            return 0;
        }
        if (action.execute()) {
            container = new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get());
        }
        return CAPACITY;
    }

    @Override
    public FluidStack drain(FluidStack resource, FluidAction action) {
        if (resource.isEmpty() || !isFluidValid(0, resource)) {
            return FluidStack.EMPTY;
        }
        return drain(resource.getAmount(), action);
    }

    @Override
    public FluidStack drain(int maxDrain, FluidAction action) {
        if (container.getCount() != 1 || !isFull() || maxDrain < CAPACITY) {
            return FluidStack.EMPTY;
        }
        FluidStack drained = getFluidInTank(0);
        if (action.execute()) {
            container = new ItemStack(ModItems.MATTER_UNIT.get());
        }
        return drained;
    }
}
