package com.railgunreborn.item;

import java.util.List;

import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;
import com.railgunreborn.registry.ModDataComponents;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.energy.ComponentEnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Developer portátil: clic derecho abre el menú de desarrollo. Solo vale en la mano principal. Lleva una batería FE
 * propia (10 000 IF, 50 por operación de carga) en el componente {@code railgunreborn:energy}; el desarrollo gasta de
 * ella directamente (sin el tope de ancho de banda, que solo vale para cargadores externos).
 */
public class DeveloperPortableItem extends Item {
    public static final int CAPACITY = DeveloperType.PORTABLE.energyCapacity();
    public static final int MAX_TRANSFER = DeveloperType.PORTABLE.energyBandwidth();
    private static final int BAR_COLOR = 0x3FD3FF;

    public DeveloperPortableItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    public static IEnergyStorage createStorage(ItemStack stack) {
        return new ComponentEnergyStorage(stack, ModDataComponents.ENERGY.get(), CAPACITY, MAX_TRANSFER);
    }

    public static int getEnergy(ItemStack stack) {
        return Math.max(0, Math.min(CAPACITY, stack.getOrDefault(ModDataComponents.ENERGY.get(), 0)));
    }

    public static ItemStack withEnergy(ItemStack stack, int energy) {
        stack.set(ModDataComponents.ENERGY.get(), Math.max(0, Math.min(CAPACITY, energy)));
        return stack;
    }

    /** Gasta {@code amount} solo si está entero (todo o nada). */
    public static boolean tryConsume(ItemStack stack, int amount) {
        int stored = getEnergy(stack);
        if (stored < amount) {
            return false;
        }
        if (amount > 0) {
            withEnergy(stack, stored - amount);
        }
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            DeveloperMenu.open(serverPlayer, DeveloperType.PORTABLE, null);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return EnergyMath.barWidth(getEnergy(stack), CAPACITY, 13);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return BAR_COLOR;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.railgunreborn.energy_stored",
                EnergyFormat.fraction(getEnergy(stack), CAPACITY)).withStyle(ChatFormatting.GRAY));
    }
}
