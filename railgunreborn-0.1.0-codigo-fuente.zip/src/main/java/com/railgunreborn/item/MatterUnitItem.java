package com.railgunreborn.item;

import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Unidad de materia (original: {@code matter_unit} con material {@code none} / {@code phase_liquid}).
 * En 1.21 cada estado es un ítem propio (como cubo / cubo de agua): {@code matter_unit} vacía y
 * {@code matter_unit_phase_liquid} llena (1000 mB). Clic derecho vacía sobre una fuente de líquido de fase: la recoge.
 * Clic derecho llena sobre un bloque: coloca la fuente y devuelve la unidad vacía.
 */
public class MatterUnitItem extends Item {
    // Igual que el cubo vanilla: avisar a vecinos y clientes, y rehacer la luz.
    private static final int UPDATE_FLAGS = 11;

    private final boolean filled;

    public MatterUnitItem(boolean filled, Properties properties) {
        super(properties);
        this.filled = filled;
    }

    public boolean isFilled() {
        return filled;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        BlockHitResult hit = getPlayerPOVHitResult(level, player, filled ? ClipContext.Fluid.NONE : ClipContext.Fluid.SOURCE_ONLY);
        if (hit.getType() != HitResult.Type.BLOCK) {
            return InteractionResultHolder.pass(stack);
        }
        BlockPos pos = hit.getBlockPos();
        if (!level.mayInteract(player, pos) || !player.mayUseItemAt(pos.relative(hit.getDirection()), hit.getDirection(), stack)) {
            return InteractionResultHolder.fail(stack);
        }
        if (!filled) {
            if (!collect(level, pos)) {
                return InteractionResultHolder.pass(stack);
            }
            level.playSound(player, pos, SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1.0f, 1.0f);
            level.gameEvent(player, GameEvent.FLUID_PICKUP, pos);
            ItemStack result = ItemUtils.createFilledResult(stack, player, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get()));
            return InteractionResultHolder.sidedSuccess(result, level.isClientSide());
        }
        // Como el cubo: si el bloque apuntado no admite el líquido, se pone en la cara de al lado.
        BlockPos target = canPlaceAt(level, pos) ? pos : pos.relative(hit.getDirection());
        if (!place(level, target)) {
            return InteractionResultHolder.fail(stack);
        }
        level.playSound(player, target, SoundEvents.BUCKET_EMPTY, SoundSource.PLAYERS, 1.0f, 1.0f);
        level.gameEvent(player, GameEvent.FLUID_PLACE, target);
        ItemStack result = ItemUtils.createFilledResult(stack, player, new ItemStack(ModItems.MATTER_UNIT.get()));
        return InteractionResultHolder.sidedSuccess(result, level.isClientSide());
    }

    /** Quita una fuente de líquido de fase en {@code pos}. Devuelve false si ahí no hay una fuente. */
    public static boolean collect(Level level, BlockPos pos) {
        FluidState fluid = level.getFluidState(pos);
        if (!fluid.isSource() || !fluid.is(ModFluids.PHASE_LIQUID.get())) {
            return false;
        }
        if (!level.isClientSide()) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), UPDATE_FLAGS);
        }
        return true;
    }

    /** Coloca una fuente de líquido de fase en {@code pos} si el bloque lo admite (aire, plantas, líquido que fluye...). */
    public static boolean place(Level level, BlockPos pos) {
        if (!canPlaceAt(level, pos)) {
            return false;
        }
        if (!level.isClientSide()) {
            BlockState state = level.getBlockState(pos);
            if (!state.isAir() && !state.liquid()) {
                level.destroyBlock(pos, true);
            }
            level.setBlock(pos, ModFluids.PHASE_LIQUID.get().defaultFluidState().createLegacyBlock(), UPDATE_FLAGS);
        }
        return true;
    }

    private static boolean canPlaceAt(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        FluidState fluid = state.getFluidState();
        if (fluid.isSource()) {
            return false;
        }
        return state.isAir() || state.canBeReplaced(ModFluids.PHASE_LIQUID.get());
    }
}
