package com.railgunreborn.ability.context;

/** Resultado de validar en el servidor el inicio de una habilidad ({@link SkillContexts#validateStart}). */
public enum StartResult {
    OK,
    /** Pasiva/genérica: no se ejecuta con tecla. */
    NOT_CONTROLLABLE,
    /** El jugador no tiene categoría o es otra distinta de la de la habilidad. */
    WRONG_CATEGORY,
    NOT_LEARNED,
    MODE_OFF,
    OVERLOADED,
    COOLDOWN,
    /** Ya hay un contexto vivo de esa habilidad para el jugador. */
    ALREADY_ACTIVE,
    /** Demasiados contextos vivos (protección contra spam). */
    TOO_MANY,
    /** La habilidad no crea contextos ({@code Skill#createContext} devolvió null). */
    NOT_EXECUTABLE;

    public boolean isSuccess() {
        return this == OK;
    }
}
