package com.railgunreborn.ability.context;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.CooldownData;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Eventos de servidor de los contextos y cooldowns. Sobrecarga, modo desactivado y cambio de categoría se
 * detectan en {@link SkillContexts#tick} (así también cubren los comandos); aquí van muerte, desconexión y
 * cambio de dimensión, que tienen evento propio.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class SkillContextEvents {
    private SkillContextEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        CooldownData.get(player).tick();
        SkillContexts.tick(player);
        SkillContexts.syncCooldowns(player);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SkillContexts.terminateAll(player, TerminationReason.DEATH);
            // El jugador nuevo ya empieza sin cooldowns (attachment sin copyOnDeath); esto cubre el caso de que
            // otro mod cancele la muerte.
            CooldownData.get(player).clear();
            SkillContexts.syncCooldowns(player);
        }
    }

    /** Volver del End crea un ServerPlayer nuevo sin muerte: lo que vivía en el viejo no debe quedar huérfano. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.getOriginal() instanceof ServerPlayer old) {
            SkillContexts.terminateAll(old,
                    event.isWasDeath() ? TerminationReason.DEATH : TerminationReason.DIMENSION_CHANGE);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SkillContexts.terminateAll(player, TerminationReason.LOGOUT);
        }
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SkillContexts.terminateAll(player, TerminationReason.DIMENSION_CHANGE);
            // El cliente crea un jugador local nuevo, sin su copia de cooldowns.
            SkillContexts.forceSyncCooldowns(player);
        }
    }
}
