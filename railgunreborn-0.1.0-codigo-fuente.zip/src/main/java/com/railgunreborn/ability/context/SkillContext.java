package com.railgunreborn.ability.context;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.network.SkillContextMessagePayload;
import com.railgunreborn.network.SkillEffectPayload;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Una ejecución de una habilidad por un jugador, en el <b>servidor</b> (el Context del original).
 *
 * <p>Lo crea {@link Skill#createContext} cuando el cliente pulsa la tecla y el servidor lo acepta
 * ({@link SkillContexts}). El servidor decide todo lo que toca el mundo (consumo, daño, bloques, exp, cooldown);
 * los clientes solo capturan la tecla y pintan efectos. Ver {@code docs/spec/context-design.md}.
 *
 * <p>Ciclo: {@link #onKeyDown()} al aceptarse; mientras la tecla siga pulsada, cada tick {@link #onKeyTick()} y
 * luego {@link #tick()}; al soltar {@link #onKeyUp()} (o {@link #onKeyAbort()}); al terminar, una sola vez,
 * {@link #onTerminated}. Por defecto soltar o abortar termina el contexto ("vive mientras se mantiene la tecla");
 * en una habilidad de interruptor ({@link Skill#isToggle()}) no: la cierra el cliente al volver a pulsar la tecla o V
 * (llega como terminación {@link TerminationReason#CLIENT}). El keep-alive no depende de la tecla. Un contexto
 * terminado ya no recibe nada.
 */
public abstract class SkillContext {
    /** Radio de los efectos visuales para otros jugadores (el original: 25 bloques). */
    public static final double DEFAULT_EFFECT_RANGE = 25.0;

    private final ServerPlayer player;
    private final Skill skill;
    private int id = -1;
    private boolean terminated;
    boolean keyHeld;
    int ticksAlive;
    int ticksSinceClientPing;

    protected SkillContext(ServerPlayer player, Skill skill) {
        this.player = player;
        this.skill = skill;
    }

    final void bind(int contextId) {
        this.id = contextId;
    }

    final boolean markTerminated() {
        if (terminated) {
            return false;
        }
        terminated = true;
        return true;
    }

    // --- Ganchos para las habilidades ---

    /** La tecla se pulsó y el servidor aceptó el inicio. */
    protected void onKeyDown() {
    }

    /** Cada tick de servidor mientras la tecla siga pulsada. */
    protected void onKeyTick() {
    }

    /** Por defecto termina el contexto, salvo en las habilidades de interruptor ({@link Skill#isToggle()}). */
    protected void onKeyUp() {
        if (!skill.isToggle()) {
            terminate();
        }
    }

    /**
     * La tecla se canceló en el cliente (p. ej. se quedó sin poder usar habilidades). Igual que
     * {@link #onKeyUp()}: un interruptor sigue (la sobrecarga o el modo apagado ya lo cortan en
     * {@link SkillContexts#tick}).
     */
    protected void onKeyAbort() {
        if (!skill.isToggle()) {
            terminate();
        }
    }

    /** Cada tick de servidor mientras el contexto viva (después de {@link #onKeyTick()}). */
    protected void tick() {
    }

    /** Mensaje de la mitad cliente local ({@code ClientSkillContext#sendToServer}). */
    protected void onClientMessage(String channel, CompoundTag data) {
    }

    /** Se llama una sola vez. No mandar mensajes desde aquí: el cliente puede no estar ya. */
    protected void onTerminated(TerminationReason reason) {
    }

    // --- Utilidades ---

    public final ServerPlayer getPlayer() {
        return player;
    }

    public final Skill getSkill() {
        return skill;
    }

    /** Id elegido por el cliente que lo inició (único por jugador mientras viva). */
    public final int getId() {
        return id;
    }

    public final boolean isTerminated() {
        return terminated;
    }

    public final boolean isKeyHeld() {
        return keyHeld;
    }

    public final int getTicksAlive() {
        return ticksAlive;
    }

    public final void terminate() {
        SkillContexts.terminate(this, TerminationReason.SELF);
    }

    /** Exp actual (0..1) de la habilidad. Leerla en el constructor para "valores al pulsar", como el original. */
    protected final float getSkillExp() {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    /** Suma exp aplicando {@code exp_incr_speed} de la habilidad. */
    protected final void addSkillExp(float amount) {
        AbilityData.get(player).addSkillExp(skill.getId(), amount * skill.getExpIncrSpeed());
    }

    /** Si {@link #consume} tendría éxito, sin efectos. */
    protected final boolean canConsume(float overload, float cp) {
        return CPData.get(player).canConsume(player, overload * skill.getOverloadConsumeSpeed(),
                cp * skill.getCpConsumeSpeed());
    }

    /** Consume CP y añade overload con los multiplicadores de la habilidad. false = no había CP (nada cambia). */
    protected final boolean consume(float overload, float cp) {
        return CPData.get(player).consume(player, overload * skill.getOverloadConsumeSpeed(),
                cp * skill.getCpConsumeSpeed());
    }

    protected final void setCooldown(int ticks) {
        setCooldown(0, ticks);
    }

    /** Cooldown de la habilidad (sub 0) o de una sub-acción. Se manda al cliente en el acto. */
    protected final void setCooldown(int sub, int ticks) {
        CooldownData.get(player).set(skill.getId(), sub, ticks);
        SkillContexts.syncCooldowns(player);
    }

    /** Mensaje solo para la mitad cliente del jugador que lo ejecuta. */
    protected final void sendToLocal(String channel, CompoundTag data) {
        if (!terminated) {
            PacketDistributor.sendToPlayer(player, new SkillContextMessagePayload(id, channel, data.copy()));
        }
    }

    /**
     * Efecto visual/sonoro para el que lo ejecuta y los jugadores a {@link #getEffectRange()} bloques. Lo reciben
     * los manejadores de efectos del cliente registrados para esta habilidad ({@code client.context.SkillEffects}).
     * Se puede llamar justo antes de {@link #terminate()}.
     */
    protected final void sendEffect(String channel, CompoundTag data) {
        PacketDistributor.sendToPlayersNear(player.serverLevel(), null, player.getX(), player.getY(), player.getZ(),
                getEffectRange(), new SkillEffectPayload(player.getId(), skill, id, channel, data.copy()));
    }

    protected double getEffectRange() {
        return DEFAULT_EFFECT_RANGE;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[" + skill.getId() + " #" + id + " " + player.getScoreboardName()
                + (terminated ? " terminated" : "") + "]";
    }
}
