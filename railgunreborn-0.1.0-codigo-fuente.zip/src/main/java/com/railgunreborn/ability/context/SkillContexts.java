package com.railgunreborn.ability.context;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.network.SkillContextStatePayload;
import com.railgunreborn.network.SyncCooldownPayload;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Lado servidor de los contextos: validar el inicio, repartir teclas/mensajes, tick, keep-alive y terminaciones.
 * Todo es estático y opera sobre el attachment {@link Active} del jugador; la validación
 * ({@link #validateStart}) no toca red ni cliente para poder probarla con GameTests.
 */
public final class SkillContexts {
    /** Cada cuántos ticks cliente y servidor se avisan de que el contexto sigue vivo (original: 0.5 s). */
    public static final int KEEP_ALIVE_INTERVAL = 10;
    /** Sin aviso del otro lado durante este tiempo, el contexto se termina (original: 1.5 s). */
    public static final int KEEP_ALIVE_TIMEOUT = 30;
    /** Contextos vivos por jugador como máximo: un cliente modificado no puede llenar el servidor. */
    public static final int MAX_CONTEXTS_PER_PLAYER = 8;

    private SkillContexts() {
    }

    /** Contextos vivos de un jugador, por id de cliente (attachment no persistente). */
    public static final class Active {
        private final Map<Integer, SkillContext> contexts = new LinkedHashMap<>();

        public boolean isEmpty() {
            return contexts.isEmpty();
        }

        public List<SkillContext> snapshot() {
            return List.copyOf(contexts.values());
        }
    }

    public static Active active(Player player) {
        return player.getData(ModAttachments.SKILL_CONTEXTS);
    }

    /**
     * Contexto vivo de {@code skill} del jugador, si lo hay (como mucho uno: {@link #validateStart} no deja abrir
     * dos). Sirve para preguntar "¿tiene el campo activo?" desde eventos sin recorrer a mano los contextos.
     */
    public static Optional<SkillContext> find(Player player, Skill skill) {
        for (SkillContext ctx : active(player).contexts.values()) {
            if (ctx.getSkill() == skill && !ctx.isTerminated()) {
                return Optional.of(ctx);
            }
        }
        return Optional.empty();
    }

    // --- Validación (sin efectos) ---

    /**
     * Si el jugador puede empezar a usar la habilidad ahora mismo (decisión del usuario: el servidor valida;
     * el original solo lo hacía en el cliente). No comprueba CP: cuánto cuesta lo sabe la habilidad al consumir.
     */
    public static StartResult validateStart(Player player, Skill skill) {
        if (!skill.canControl()) {
            return StartResult.NOT_CONTROLLABLE;
        }
        AbilityData ability = AbilityData.get(player);
        if (!ability.getCategory().map(skill.getCategoryId()::equals).orElse(false)) {
            return StartResult.WRONG_CATEGORY;
        }
        if (!ability.isLearned(skill.getId())) {
            return StartResult.NOT_LEARNED;
        }
        CPData cp = CPData.get(player);
        if (!cp.isActivated()) {
            return StartResult.MODE_OFF;
        }
        if (!cp.canUseAbility()) {
            return StartResult.OVERLOADED;
        }
        if (CooldownData.get(player).isInCooldown(skill.getId())) {
            return StartResult.COOLDOWN;
        }
        Active active = active(player);
        if (active.contexts.values().stream().anyMatch(ctx -> ctx.getSkill() == skill)) {
            return StartResult.ALREADY_ACTIVE;
        }
        if (active.contexts.size() >= MAX_CONTEXTS_PER_PLAYER) {
            return StartResult.TOO_MANY;
        }
        return StartResult.OK;
    }

    // --- Entrada desde la red ---

    /** El cliente pulsó la tecla de una habilidad. Si se rechaza: aviso al cliente y sonido de denegado. */
    public static StartResult start(ServerPlayer player, int contextId, Skill skill) {
        applyPendingCategoryChange(player);
        // Un id repetido solo puede venir de un cliente desincronizado: el contexto viejo sobra.
        SkillContext previous = active(player).contexts.get(contextId);
        if (previous != null) {
            terminate(previous, TerminationReason.REPLACED);
        }

        StartResult result = validateStart(player, skill);
        SkillContext ctx = null;
        if (result.isSuccess()) {
            ctx = skill.createContext(player);
            if (ctx == null) {
                result = StartResult.NOT_EXECUTABLE;
            }
        }
        if (ctx == null) {
            RailgunReborn.LOGGER.debug("Rejected {} for {}: {}", skill.getId(), player.getScoreboardName(), result);
            PacketDistributor.sendToPlayer(player,
                    new SkillContextStatePayload(contextId, SkillContextStatePayload.State.REJECTED));
            player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
            return result;
        }

        ctx.bind(contextId);
        ctx.keyHeld = true;
        active(player).contexts.put(contextId, ctx);
        PacketDistributor.sendToPlayer(player,
                new SkillContextStatePayload(contextId, SkillContextStatePayload.State.ALIVE));
        ctx.onKeyDown();
        return result;
    }

    public static void handleAction(ServerPlayer player, int contextId, SkillContextActionPayload.Action action) {
        SkillContext ctx = active(player).contexts.get(contextId);
        if (ctx == null || ctx.isTerminated()) {
            return;
        }
        ctx.ticksSinceClientPing = 0;
        switch (action) {
            case KEY_UP -> {
                if (ctx.keyHeld) {
                    ctx.keyHeld = false;
                    ctx.onKeyUp();
                }
            }
            case KEY_ABORT -> {
                if (ctx.keyHeld) {
                    ctx.keyHeld = false;
                    ctx.onKeyAbort();
                }
            }
            case KEEP_ALIVE -> {
            }
            case TERMINATE -> terminate(ctx, TerminationReason.CLIENT);
        }
    }

    public static void handleClientMessage(ServerPlayer player, int contextId, String channel, CompoundTag data) {
        SkillContext ctx = active(player).contexts.get(contextId);
        if (ctx != null && !ctx.isTerminated()) {
            ctx.ticksSinceClientPing = 0;
            ctx.onClientMessage(channel, data);
        }
    }

    // --- Tick ---

    /** Una vez por tick de servidor del jugador ({@link SkillContextEvents}). */
    public static void tick(ServerPlayer player) {
        applyPendingCategoryChange(player);
        Active active = active(player);
        if (active.isEmpty()) {
            return;
        }
        TerminationReason forced = forcedTermination(player);
        if (forced != null) {
            terminateAll(player, forced);
            return;
        }
        for (SkillContext ctx : active.snapshot()) {
            if (ctx.isTerminated()) {
                continue;
            }
            if (++ctx.ticksSinceClientPing > KEEP_ALIVE_TIMEOUT) {
                terminate(ctx, TerminationReason.TIMEOUT);
                continue;
            }
            if (ctx.keyHeld) {
                ctx.onKeyTick();
            }
            if (!ctx.isTerminated()) {
                ctx.tick();
            }
            if (!ctx.isTerminated() && ++ctx.ticksAlive % KEEP_ALIVE_INTERVAL == 0) {
                PacketDistributor.sendToPlayer(player,
                        new SkillContextStatePayload(ctx.getId(), SkillContextStatePayload.State.KEEP_ALIVE));
            }
        }
    }

    /** Motivo para cortar todo lo que esté vivo, o null si puede seguir. */
    @Nullable
    private static TerminationReason forcedTermination(ServerPlayer player) {
        if (!player.isAlive()) {
            return TerminationReason.DEATH;
        }
        CPData cp = CPData.get(player);
        if (cp.isOverloaded()) {
            return TerminationReason.OVERLOAD;
        }
        if (!cp.canUseAbility()) {
            return TerminationReason.MODE_OFF;
        }
        return null;
    }

    // --- Terminación ---

    public static void terminate(SkillContext ctx, TerminationReason reason) {
        if (!ctx.markTerminated()) {
            return;
        }
        ServerPlayer player = ctx.getPlayer();
        active(player).contexts.remove(ctx.getId(), ctx);
        RailgunReborn.LOGGER.debug("Terminated {}: {}", ctx, reason);
        try {
            ctx.onTerminated(reason);
        } finally {
            if (reason.notifiesClient()) {
                PacketDistributor.sendToPlayer(player,
                        new SkillContextStatePayload(ctx.getId(), SkillContextStatePayload.State.TERMINATED));
            }
        }
    }

    public static void terminateAll(ServerPlayer player, TerminationReason reason) {
        for (SkillContext ctx : active(player).snapshot()) {
            terminate(ctx, reason);
        }
    }

    /** CategoryChangeEvent del original: termina contextos y limpia cooldowns (ver {@link AbilityData#setCategory}). */
    public static void applyPendingCategoryChange(ServerPlayer player) {
        if (AbilityData.get(player).consumeCategoryChangedForSkills()) {
            terminateAll(player, TerminationReason.CATEGORY_CHANGE);
            CooldownData.get(player).clear();
            syncCooldowns(player);
        }
    }

    // --- Cooldowns ---

    /** Manda al cliente la foto de cooldowns si cambió algo desde el último envío. */
    public static void syncCooldowns(ServerPlayer player) {
        CooldownData cooldowns = CooldownData.get(player);
        if (cooldowns.consumeDirty()) {
            PacketDistributor.sendToPlayer(player, SyncCooldownPayload.of(cooldowns));
        }
    }

    /** Envío completo aunque no haya cambios (el cliente creó un jugador local nuevo). */
    public static void forceSyncCooldowns(ServerPlayer player) {
        CooldownData cooldowns = CooldownData.get(player);
        cooldowns.consumeDirty();
        PacketDistributor.sendToPlayer(player, SyncCooldownPayload.of(cooldowns));
    }
}
