package com.railgunreborn.ability.context;

/** Por qué terminó un {@link SkillContext} en el servidor. */
public enum TerminationReason {
    /** La propia habilidad llamó a {@link SkillContext#terminate()} (incluido soltar la tecla por defecto). */
    SELF(true),
    /** El cliente pidió terminar (ya lo quitó de su lado). */
    CLIENT(false),
    /**
     * El cliente reutilizó el id de un contexto todavía vivo. Sin aviso: el cliente ya usa ese id para el nuevo
     * y un TERMINATED con él lo cerraría.
     */
    REPLACED(false),
    /** Sin keep-alive del cliente durante {@link SkillContexts#KEEP_ALIVE_TIMEOUT} ticks. */
    TIMEOUT(true),
    OVERLOAD(true),
    /** Modo habilidad desactivado (o sin categoría). */
    MODE_OFF(true),
    CATEGORY_CHANGE(true),
    DEATH(true),
    DIMENSION_CHANGE(true),
    /** El jugador se desconecta: no tiene sentido avisarle. */
    LOGOUT(false);

    private final boolean notifyClient;

    TerminationReason(boolean notifyClient) {
        this.notifyClient = notifyClient;
    }

    public boolean notifiesClient() {
        return notifyClient;
    }
}
