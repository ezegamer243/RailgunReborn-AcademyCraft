package com.railgunreborn.ability;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevCondition;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperType;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Habilidad registrada en {@link AbilityRegistries#SKILL_KEY}, con id {@code <ns>:<categoría>/<habilidad>}.
 *
 * <p>Aquí solo van los datos estáticos (nivel, árbol, valores de config por defecto). Cada habilidad concreta
 * extiende esta clase.
 *
 * <p>La ejecución va en un {@link SkillContext} que crea {@link #createContext} cuando el servidor acepta la
 * pulsación (ver {@code docs/spec/context-design.md}). Las pasivas ({@link #canControl()} false) no lo usan.
 */
public abstract class Skill {
    private final ResourceLocation categoryId;
    private final int level;
    @Nullable
    private final Dependency parent;
    private final List<Dependency> extraDependencies;
    private final boolean controllable;
    private final float damageScale;
    private final float cpConsumeSpeed;
    private final float overloadConsumeSpeed;
    private final float expIncrSpeed;
    private final boolean destroyBlocks;
    private final int guiX;
    private final int guiY;
    private final int requiredAnySkillLevel;

    protected Skill(Properties props) {
        this.categoryId = props.categoryId;
        this.level = props.level;
        this.parent = props.parent;
        this.extraDependencies = List.copyOf(props.extraDependencies);
        this.controllable = props.controllable;
        this.damageScale = props.damageScale;
        this.cpConsumeSpeed = props.cpConsumeSpeed;
        this.overloadConsumeSpeed = props.overloadConsumeSpeed;
        this.expIncrSpeed = props.expIncrSpeed;
        this.destroyBlocks = props.destroyBlocks;
        this.guiX = props.guiX;
        this.guiY = props.guiY;
        this.requiredAnySkillLevel = props.requiredAnySkillLevel;
    }

    public ResourceLocation getId() {
        ResourceLocation id = AbilityRegistries.SKILL_REGISTRY.getKey(this);
        if (id == null) {
            throw new IllegalStateException("Skill not registered: " + getClass().getName());
        }
        return id;
    }

    public ResourceLocation getCategoryId() {
        return categoryId;
    }

    public Category getCategory() {
        return AbilityRegistries.category(categoryId)
                .orElseThrow(() -> new IllegalStateException("Unknown category " + categoryId + " for " + getId()));
    }

    /** Nivel requerido (1..5). */
    public int getLevel() {
        return level;
    }

    /** Habilidad previa del árbol con su exp mínima; vacío = raíz. */
    public Optional<Dependency> getParent() {
        return Optional.ofNullable(parent);
    }

    /** Dependencias adicionales ({@code addSkillDep} del original). */
    public List<Dependency> getExtraDependencies() {
        return extraDependencies;
    }

    /** false = pasiva/genérica: no va en presets ni cuenta para el umbral de nivel. */
    public boolean canControl() {
        return controllable;
    }

    /**
     * Habilidad de interruptor: pulsar la tecla abre el contexto y volver a pulsarla (o V) lo cierra; soltarla no
     * lo termina. El contexto sigue terminando por sobrecarga, muerte, desconexión, cambio de dimensión o de
     * categoría, o cuando la propia habilidad llama a {@code terminate()}. Ver {@code SkillContext#onKeyUp} y
     * {@code ClientSkillContext#onKeyDownWhileAlive}.
     */
    public boolean isToggle() {
        return false;
    }

    // TODO(config): estos cuatro valores (y destroy_blocks) son los defaults de default.conf; la config los
    // sobrescribirá. enabled no existe aún: toda habilidad registrada está activa.

    public float getDamageScale() {
        return damageScale;
    }

    public float getCpConsumeSpeed() {
        return cpConsumeSpeed;
    }

    public float getOverloadConsumeSpeed() {
        return overloadConsumeSpeed;
    }

    /** Multiplica la exp ganada antes de pasarla a {@link AbilityData#addSkillExp}. */
    public float getExpIncrSpeed() {
        return expIncrSpeed;
    }

    public boolean canDestroyBlocks() {
        return destroyBlocks;
    }

    // --- Developer (developer.md 2.5, 3.2) ---

    /** Posición del nodo en el árbol, relativa a la esquina del área (257x139). */
    public int getGuiX() {
        return guiX;
    }

    public int getGuiY() {
        return guiY;
    }

    /** Estímulos para aprenderla: {@code (int)(3 + nivel² / 2)}. */
    public int getLearningStims() {
        return DevelopRules.stimsForSkill(level);
    }

    /** Developer mínimo según el nivel: 1-2 portátil, 3 normal, 4-5 avanzado. */
    public DeveloperType getMinimumDeveloperType() {
        return DeveloperType.minimumFor(level);
    }

    /** Nivel N de la condición "alguna habilidad de nivel N aprendida" (genéricas); 0 = sin condición. */
    public int getRequiredAnySkillLevel() {
        return requiredAnySkillLevel;
    }

    /** Si puede aprenderla en ese Developer ahora (categoría, no aprendida, nivel, tipo, padre, dependencias, genérica). */
    public DevelopResult checkLearn(AbilityData data, DeveloperType type) {
        // getKey y no getId: una habilidad sin registrar (tests) cuenta como no aprendida en vez de lanzar.
        ResourceLocation id = AbilityRegistries.SKILL_REGISTRY.getKey(this);
        return DevelopRules.checkLearn(new DevelopRules.LearnFacts(
                data.hasCategory(),
                data.getCategory().map(categoryId::equals).orElse(false),
                id != null && data.isLearned(id),
                data.getLevel(),
                level,
                parent == null || parent.isMet(data),
                extraDependencies.stream().allMatch(dep -> dep.isMet(data)),
                anySkillOfLevelMet(data)), type);
    }

    /** Condiciones con icono para la pantalla, en orden: tipo de Developer, padre, dependencias, genérica. */
    public List<DevCondition> getDevConditions(AbilityData data, DeveloperType type) {
        List<DevCondition> list = new ArrayList<>();
        DeveloperType minimum = getMinimumDeveloperType();
        list.add(new DevCondition(DevCondition.Kind.DEVELOPER_TYPE, null, minimum, 0, 0f,
                type.ordinal() >= minimum.ordinal()));
        if (parent != null) {
            list.add(new DevCondition(DevCondition.Kind.PARENT, parent.skill(), null, 0, parent.minExp(),
                    parent.isMet(data)));
        }
        for (Dependency dep : extraDependencies) {
            list.add(new DevCondition(DevCondition.Kind.DEPENDENCY, dep.skill(), null, 0, dep.minExp(),
                    dep.isMet(data)));
        }
        if (requiredAnySkillLevel > 0) {
            list.add(new DevCondition(DevCondition.Kind.ANY_SKILL_OF_LEVEL, null, null, requiredAnySkillLevel, 0f,
                    anySkillOfLevelMet(data)));
        }
        return list;
    }

    private boolean anySkillOfLevelMet(AbilityData data) {
        if (requiredAnySkillLevel <= 0) {
            return true;
        }
        return data.getLearnedSkills().stream()
                .map(AbilityRegistries::skill)
                .flatMap(Optional::stream)
                .anyMatch(s -> s != this && s.getCategoryId().equals(categoryId)
                        && s.getLevel() == requiredAnySkillLevel);
    }

    /** {@code <ns>:textures/skill/<categoría>/<habilidad>.png}. */
    public ResourceLocation getIcon() {
        return getId().withPath(p -> "textures/skill/" + p + ".png");
    }

    /** {@code <ns>.ability.<categoría>.<habilidad>.name}. */
    public String getNameKey() {
        return langPrefix() + ".name";
    }

    public String getDescriptionKey() {
        return langPrefix() + ".desc";
    }

    public Component getDisplayName() {
        return Component.translatable(getNameKey());
    }

    private String langPrefix() {
        ResourceLocation id = getId();
        return id.getNamespace() + ".ability." + id.getPath().replace('/', '.');
    }

    /**
     * Si el jugador cumple nivel y árbol (padre + dependencias con su exp mínima). No comprueba el tipo de
     * Developer ni si ya está aprendida: para eso {@link #checkLearn}.
     */
    public boolean meetsPrerequisites(AbilityData data) {
        if (!data.getCategory().map(categoryId::equals).orElse(false) || data.getLevel() < level) {
            return false;
        }
        if (parent != null && !parent.isMet(data)) {
            return false;
        }
        return extraDependencies.stream().allMatch(dep -> dep.isMet(data));
    }

    /**
     * Exp calculada en vez de guardada (Rad Intensify: del CP máximo). Vacío = la normal de {@link AbilityData}. Vale
     * en ambos lados (en cliente con los datos sincronizados).
     */
    public Optional<Float> getDerivedExp(Player player) {
        return Optional.empty();
    }

    /** Exp que se muestra y se usa: la derivada si la hay, si no la guardada en {@link AbilityData}. */
    public float getExp(Player player) {
        return getDerivedExp(player).orElseGet(() -> AbilityData.get(player).getSkillExp(getId()));
    }

    /**
     * Crea la ejecución en el servidor cuando el jugador pulsa la tecla y {@code SkillContexts} ya validó
     * categoría, aprendida, modo habilidad, overload y cooldown. Los valores que dependen de la exp se leen al
     * crear el contexto (el original los fija al pulsar). null = esta habilidad no se ejecuta.
     */
    @Nullable
    public SkillContext createContext(ServerPlayer player) {
        return null;
    }

    @Override
    public String toString() {
        ResourceLocation id = AbilityRegistries.SKILL_REGISTRY.getKey(this);
        return "Skill[" + (id == null ? "unregistered" : id) + "]";
    }

    /** Requisito "habilidad X aprendida con exp ≥ minExp". Por id para no depender del orden de registro. */
    public record Dependency(ResourceLocation skill, float minExp) {
        public boolean isMet(AbilityData data) {
            // Si la habilidad requerida no existe en el registro se ignora, como el original con enabled: false.
            if (AbilityRegistries.skill(skill).isEmpty()) {
                return true;
            }
            return data.isLearned(skill) && data.getSkillExp(skill) >= minExp;
        }
    }

    /** Datos de una habilidad. Valores por defecto = {@code default.conf} del original. */
    public static final class Properties {
        private final ResourceLocation categoryId;
        private final int level;
        @Nullable
        private Dependency parent;
        private final List<Dependency> extraDependencies = new ArrayList<>();
        private boolean controllable = true;
        private float damageScale = 1.0f;
        private float cpConsumeSpeed = 1.0f;
        private float overloadConsumeSpeed = 1.0f;
        private float expIncrSpeed = 1.0f;
        private boolean destroyBlocks = true;
        private int guiX;
        private int guiY;
        private int requiredAnySkillLevel;

        public Properties(ResourceLocation categoryId, int level) {
            if (level < 1 || level > AbilityData.MAX_LEVEL) {
                throw new IllegalArgumentException("Skill level out of range: " + level);
            }
            this.categoryId = categoryId;
            this.level = level;
        }

        public Properties parent(ResourceLocation skill, float minExp) {
            this.parent = new Dependency(skill, minExp);
            return this;
        }

        public Properties dependency(ResourceLocation skill, float minExp) {
            extraDependencies.add(new Dependency(skill, minExp));
            return this;
        }

        /** Posición del nodo en el árbol del Developer ({@code electromaster.md}: arc_gen 24, 46). */
        public Properties guiPos(int x, int y) {
            this.guiX = x;
            this.guiY = y;
            return this;
        }

        /** Genéricas: exige alguna habilidad de la categoría de nivel {@code skillLevel} aprendida. */
        public Properties requiresAnySkillOfLevel(int skillLevel) {
            if (skillLevel < 1 || skillLevel > AbilityData.MAX_LEVEL) {
                throw new IllegalArgumentException("Skill level out of range: " + skillLevel);
            }
            this.requiredAnySkillLevel = skillLevel;
            return this;
        }

        /** Para las genéricas pasivas (brain_course...). */
        public Properties passive() {
            this.controllable = false;
            return this;
        }

        public Properties damageScale(float value) {
            this.damageScale = value;
            return this;
        }

        public Properties cpConsumeSpeed(float value) {
            this.cpConsumeSpeed = value;
            return this;
        }

        public Properties overloadConsumeSpeed(float value) {
            this.overloadConsumeSpeed = value;
            return this;
        }

        public Properties expIncrSpeed(float value) {
            this.expIncrSpeed = value;
            return this;
        }

        public Properties destroyBlocks(boolean value) {
            this.destroyBlocks = value;
            return this;
        }
    }
}
