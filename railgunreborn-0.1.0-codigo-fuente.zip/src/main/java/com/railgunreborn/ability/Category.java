package com.railgunreborn.ability;

import java.util.List;

import com.railgunreborn.ability.data.AbilityData;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Categoría de habilidades (Electromaster, Meltdowner...). Entrada del registro {@link AbilityRegistries#CATEGORY_KEY}.
 *
 * <p>No guarda la lista de habilidades: se deriva del registro de habilidades ({@link #getSkills()}), así no
 * importa en qué orden NeoForge rellena los dos registros. Icono, overlay y nombre salen del id por convención.
 *
 * <p>Subir de nivel <b>no es automático</b> (ficha {@code ability-system.md} 2.2): se hace en la máquina
 * "Developer", que todavía no existe. Aquí solo se calcula el umbral y si el jugador ya podría subir.
 */
public class Category {
    /** {@code prog_incr_rate} global del original. TODO(config): leer de la config cuando exista. */
    public static final float GLOBAL_PROG_INCR_RATE = 1.0f;

    // k del umbral N * k por nivel (índice = nivel actual). Nivel 5 no sube.
    private static final float LOW_LEVEL_K = 0.666f;
    private static final float LEVEL_4_K = 1.333f;

    private final int color;
    private final float progIncrRate;

    /**
     * @param color        color de la categoría para HUD/VFX, ARGB
     * @param progIncrRate multiplicador del progreso de nivel de esta categoría ({@code prog_incr_rate}, 1.0)
     */
    public Category(int color, float progIncrRate) {
        this.color = color;
        this.progIncrRate = progIncrRate;
    }

    public ResourceLocation getId() {
        ResourceLocation id = AbilityRegistries.CATEGORY_REGISTRY.getKey(this);
        if (id == null) {
            throw new IllegalStateException("Category not registered: " + this);
        }
        return id;
    }

    /** ARGB. */
    public int getColor() {
        return color;
    }

    /** TODO(config): {@code prog_incr_rate} de la categoría desde la config. */
    public float getProgIncrRate() {
        return progIncrRate;
    }

    /** {@code <ns>:textures/category/<categoría>_icon.png}. */
    public ResourceLocation getIcon() {
        return getId().withPath(p -> "textures/category/" + p + "_icon.png");
    }

    /** Overlay usado como recorte en el HUD de CP: {@code <ns>:textures/category/<categoría>_icon_overlay.png}. */
    public ResourceLocation getIconOverlay() {
        return getId().withPath(p -> "textures/category/" + p + "_icon_overlay.png");
    }

    /** {@code <ns>.ability.<categoría>.name}. */
    public String getNameKey() {
        ResourceLocation id = getId();
        return id.getNamespace() + ".ability." + id.getPath() + ".name";
    }

    public Component getDisplayName() {
        return Component.translatable(getNameKey());
    }

    /** Habilidades de la categoría, en orden de registro. */
    public List<Skill> getSkills() {
        ResourceLocation id = getId();
        return AbilityRegistries.SKILL_REGISTRY.stream()
                .filter(skill -> skill.getCategoryId().equals(id))
                .toList();
    }

    /** Multiplicador total que se aplica a la exp ganada al sumarla al progreso de nivel. */
    public float getTotalProgIncrRate() {
        return progIncrRate * GLOBAL_PROG_INCR_RATE;
    }

    /**
     * Progreso bruto necesario para pasar de {@code level} a {@code level + 1}: {@code N * k}, con N = habilidades
     * controlables de la categoría de ese mismo nivel, k = 0.666 (niveles 1-3) o 1.333 (nivel 4).
     * Fuera de 1..4 (sin categoría o ya en el máximo) devuelve infinito: no se puede subir.
     */
    public float levelUpThreshold(int level) {
        if (level < 1 || level >= AbilityData.MAX_LEVEL) {
            return Float.POSITIVE_INFINITY;
        }
        long n = getSkills().stream().filter(s -> s.canControl() && s.getLevel() == level).count();
        return n * (level == 4 ? LEVEL_4_K : LOW_LEVEL_K);
    }

    /**
     * Progreso de nivel en 0..1 ({@code min(1, progreso / umbral)}).
     * Si la categoría no tiene habilidades controlables en ese nivel (umbral 0) se considera completo, como el
     * original con progreso > 0. Ojo: mientras solo exista Arc Gen, los niveles 2-4 quedan así.
     */
    public float levelProgressFraction(int level, float rawProgress) {
        float threshold = levelUpThreshold(level);
        if (Float.isInfinite(threshold)) {
            return 0f;
        }
        if (threshold <= 0f) {
            return 1f;
        }
        return Math.min(1f, rawProgress / threshold);
    }

    /** Si la máquina de desarrollo (futura) le dejaría subir de nivel. No sube nada por sí mismo. */
    public boolean canLevelUp(AbilityData data) {
        return data.getLevel() >= 1 && data.getLevel() < AbilityData.MAX_LEVEL
                && levelProgressFraction(data.getLevel(), data.getLevelProgress()) >= 1f;
    }

    @Override
    public String toString() {
        ResourceLocation id = AbilityRegistries.CATEGORY_REGISTRY.getKey(this);
        return "Category[" + (id == null ? "unregistered" : id) + "]";
    }
}
