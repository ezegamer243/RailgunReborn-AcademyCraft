package com.railgunreborn.ability.common;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.DoubleSupplier;

/**
 * Geometría pura de los rayos que abren túneles (Railgun, Meltdowner), sin Minecraft, para probarla con JUnit.
 * Sacada de {@code RailgunRules} con el radio como parámetro ({@code railgun.md}, {@code meltdowner-skill.md}).
 *
 * <p>El disco de líneas es perpendicular a la mirada y está centrado en los ojos; las posiciones que caen en el mismo
 * bloque se cuentan una sola vez; el paso 0 (el plano del disco, donde está el jugador) no se rompe.
 */
public final class TunnelRules {
    /** Primer paso que se rompe: el paso 0 es el plano de los ojos y bajaría de los pies (quitaría el suelo). */
    public static final int FIRST_STEP = 1;
    /** Separación de la rejilla de muestreo del disco (el original: 0.9). */
    public static final double GRID_STEP = 0.9;
    /** Dureza que se usa para los bloques irrompibles (dureza negativa): ninguna línea tiene tanta energía. */
    public static final double UNBREAKABLE_HARDNESS = 233333.0;
    public static final double DROP_PROB = 0.05;
    public static final double NEIGHBOR_PROB = 0.05;
    public static final double BREAK_SOUND_PROB = 0.1;
    /** El sonido de rotura solo en los primeros pasos de cada línea (como el original). */
    public static final int BREAK_SOUND_MAX_STEP = 19;

    private TunnelRules() {
    }

    /** Energía de una línea: la total entre las líneas únicas, con ±5 % al azar. */
    public static double lineEnergy(double total, int lines, double roll) {
        if (lines <= 0) {
            return 0;
        }
        return total / lines * (0.95 + 0.1 * roll);
    }

    /** Dureza efectiva: negativa (bedrock, barrera...) = irrompible. */
    public static double effectiveHardness(double hardness) {
        return hardness < 0 ? UNBREAKABLE_HARDNESS : hardness;
    }

    /** Si un punto a {@code along} a lo largo del eje y a {@code perpendicular} del eje entra en el cilindro. */
    public static boolean inCylinder(double along, double perpendicular, double range, double radius) {
        return along >= 0 && along <= range && perpendicular <= radius;
    }

    /** Celdas de la rejilla a cada lado del centro: {@code floor(radio / 0.9)} (radio 2 → ±2, radio 3 → ±3). */
    public static int gridHalf(double radius) {
        return (int) Math.floor(radius / GRID_STEP + 1.0e-9);
    }

    // --- Geometría ---

    /** Vector de doubles (sin Minecraft). */
    public record Vec(double x, double y, double z) {
        public Vec add(Vec o) {
            return new Vec(x + o.x, y + o.y, z + o.z);
        }

        public Vec sub(Vec o) {
            return new Vec(x - o.x, y - o.y, z - o.z);
        }

        public Vec scale(double s) {
            return new Vec(x * s, y * s, z * s);
        }

        public double dot(Vec o) {
            return x * o.x + y * o.y + z * o.z;
        }

        public Vec cross(Vec o) {
            return new Vec(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);
        }

        public double length() {
            return Math.sqrt(dot(this));
        }

        public Vec normalize() {
            double len = length();
            return len < 1.0e-9 ? new Vec(0, 0, 0) : scale(1.0 / len);
        }
    }

    /** Casilla de bloque. */
    public record Cell(int x, int y, int z) {
        public static Cell of(Vec v) {
            return new Cell((int) Math.floor(v.x()), (int) Math.floor(v.y()), (int) Math.floor(v.z()));
        }

        public Vec center() {
            return new Vec(x + 0.5, y + 0.5, z + 0.5);
        }
    }

    /**
     * Dos ejes unitarios perpendiculares a {@code dir} y entre sí ({@code [derecha, arriba]} respecto a la mirada).
     * Mirando en vertical se usa X del mundo como referencia.
     */
    public static Vec[] perpendicularAxes(Vec dir) {
        Vec d = dir.normalize();
        Vec reference = Math.abs(d.y()) > 0.999 ? new Vec(1, 0, 0) : new Vec(0, 1, 0);
        Vec right = d.cross(reference).normalize();
        Vec up = right.cross(d).normalize();
        return new Vec[] {right, up};
    }

    /**
     * Puntos de la rejilla del disco: offsets {@code (s, t)} en {@code {-n·0.9 .. n·0.9}} con {@code n =}
     * {@link #gridHalf}, que cumplen {@code s² + t² <= rr²}, {@code rr = radius * (0.9 + 0.2 * roll)} con una tirada
     * por punto (borde irregular).
     */
    public static List<Vec> discPoints(Vec origin, Vec dir, double radius, DoubleSupplier roll) {
        Vec[] axes = perpendicularAxes(dir);
        int n = gridHalf(radius);
        List<Vec> points = new ArrayList<>();
        for (int i = -n; i <= n; i++) {
            for (int j = -n; j <= n; j++) {
                double s = i * GRID_STEP;
                double t = j * GRID_STEP;
                double rr = radius * (0.9 + 0.2 * roll.getAsDouble());
                if (s * s + t * t <= rr * rr) {
                    points.add(origin.add(axes[0].scale(s)).add(axes[1].scale(t)));
                }
            }
        }
        return points;
    }

    /** Casillas de inicio de las líneas, sin duplicados (en el orden en que aparecen). */
    public static List<Cell> lineStarts(Vec origin, Vec dir, double radius, DoubleSupplier roll) {
        Set<Cell> cells = new LinkedHashSet<>();
        for (Vec p : discPoints(origin, dir, radius, roll)) {
            cells.add(Cell.of(p));
        }
        return new ArrayList<>(cells);
    }

    /**
     * Línea de bloques (equivalente a {@code Plotter}): desde el centro de {@code start} en la dirección {@code dir},
     * un paso por bloque del eje dominante (DDA 3D), pasos {@code 0..maxSteps}. El índice de la lista es el paso.
     */
    public static List<Cell> line(Cell start, Vec dir, int maxSteps) {
        double m = Math.max(Math.abs(dir.x()), Math.max(Math.abs(dir.y()), Math.abs(dir.z())));
        List<Cell> cells = new ArrayList<>(maxSteps + 1);
        if (m < 1.0e-9) {
            cells.add(start);
            return cells;
        }
        Vec step = dir.scale(1.0 / m);
        Vec from = start.center();
        for (int i = 0; i <= maxSteps; i++) {
            cells.add(Cell.of(from.add(step.scale(i))));
        }
        return cells;
    }

    /** Distancia de {@code point} a lo largo del eje (desde {@code origin}) y al eje, en ese orden. */
    public static double[] axisDistances(Vec origin, Vec dir, Vec point) {
        Vec d = dir.normalize();
        Vec rel = point.sub(origin);
        double along = rel.dot(d);
        double perp = rel.sub(d.scale(along)).length();
        return new double[] {along, perp};
    }

    // --- Energía de una línea ---

    /** Resultado de intentar romper un bloque con la energía que le queda a la línea. */
    public enum BreakOutcome {
        /** Se rompe y la línea sigue. */
        BREAK,
        /** No se puede (sin energía, irrompible o sin permiso): la línea termina. */
        STOP
    }

    /** Presupuesto de energía de una línea ({@code RangedRayDamage} del original). */
    public static final class LineBudget {
        private double energy;

        public LineBudget(double energy) {
            this.energy = energy;
        }

        public double remaining() {
            return energy;
        }

        public boolean exhausted() {
            return energy <= 0;
        }

        /**
         * Un bloque de la línea con dureza {@code hardness} (la de Minecraft, negativa = irrompible). Si no está
         * permitido romperlo o no hay energía suficiente, la línea se detiene (la energía pasa a 0). El aire y la
         * dureza 0 no cuestan nada.
         */
        public BreakOutcome tryBreak(double hardness, boolean allowed) {
            double cost = effectiveHardness(hardness);
            if (!allowed || energy < cost) {
                energy = 0;
                return BreakOutcome.STOP;
            }
            energy -= cost;
            return BreakOutcome.BREAK;
        }
    }
}
