package com.railgunreborn.ability.common;

import com.railgunreborn.ability.Skill;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;

/**
 * Un rayo reflejable (Railgun, Meltdowner) está a punto de dañar a un <b>jugador</b> ({@code docs/spec/vec-reflection.md}
 * §11; el {@code ReflectEvent} del original). Solo servidor, en el bus del juego ({@code NeoForge.EVENT_BUS}); lo
 * lanza {@link BeamReflect#reflects}, nunca para seres vivos que no sean jugadores ni si el PvP impide el golpe.
 *
 * <p><b>Cancelar = "este jugador refleja el rayo"</b>: el atacante no le daña y corta el rayo (y el túnel) a su
 * distancia. El contragolpe lo ejecuta quien cancela (normalmente con {@link BeamReflect#counterAttack}), usando
 * {@link #getCounterDamage()} que propone la habilidad atacante; el atacante solo mira si se canceló.
 */
public class BeamReflectEvent extends Event implements ICancellableEvent {
    private final ServerPlayer caster;
    private final Skill skill;
    private final ServerPlayer target;
    private final Vec3 origin;
    private final Vec3 dir;
    private final float damage;
    private final float counterDamage;

    public BeamReflectEvent(ServerPlayer caster, Skill skill, ServerPlayer target, Vec3 origin, Vec3 dir,
            float damage, float counterDamage) {
        this.caster = caster;
        this.skill = skill;
        this.target = target;
        this.origin = origin;
        this.dir = dir;
        this.damage = damage;
        this.counterDamage = counterDamage;
    }

    /** Quien dispara el rayo. */
    public ServerPlayer getCaster() {
        return caster;
    }

    /** Habilidad que dispara (para el estilo del rayo de vuelta, el coste...). */
    public Skill getSkill() {
        return skill;
    }

    /** El jugador al que el rayo va a dañar ahora. */
    public ServerPlayer getTarget() {
        return target;
    }

    /** Origen del rayo (ojos del atacante). */
    public Vec3 getOrigin() {
        return origin;
    }

    /** Dirección del rayo (unitaria). */
    public Vec3 getDir() {
        return dir;
    }

    /** Daño que haría el rayo a este objetivo, antes de {@code damage_scale} (sirve para el coste del reflejo). */
    public float getDamage() {
        return damage;
    }

    /** Contragolpe que corresponde a la habilidad atacante (Meltdowner 10-25, Railgun 14). */
    public float getCounterDamage() {
        return counterDamage;
    }
}
