package com.railgunreborn.ability.common;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Protección de caída tras un teletransporte que deja al jugador en el aire ({@link SafeTeleport#guardFall}). Bus del
 * juego, solo servidor. El movimiento del jugador lo decide el cliente, así que la caída se anula en
 * {@link LivingFallEvent} (al aterrizar) y no solo en el tick.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class TeleportFallGuard {
    /**
     * Ticks tras el teletransporte en los que no se mira {@code onGround}: en el servidor sigue valiendo lo de antes de
     * saltar hasta que llegan los paquetes de movimiento del cliente.
     */
    static final int GROUND_CHECK_DELAY = 5;

    /** Ventana de protección en tiempo de juego del nivel (no se guarda: un reinicio la quita). */
    public record Window(long start, long until) {
    }

    private TeleportFallGuard() {
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && SafeTeleport.isFallGuarded(player)) {
            event.setCanceled(true);
            player.resetFallDistance();
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        Window window = player.getExistingDataOrNull(ModAttachments.TP_FALL_GUARD);
        if (window == null) {
            return;
        }
        long now = player.serverLevel().getGameTime();
        boolean landed = now > window.start() + GROUND_CHECK_DELAY && player.onGround();
        if (landed || now > window.until()) {
            player.removeData(ModAttachments.TP_FALL_GUARD);
            return;
        }
        player.resetFallDistance();
        MagMovementSkill.resetFlying(player);
    }
}
