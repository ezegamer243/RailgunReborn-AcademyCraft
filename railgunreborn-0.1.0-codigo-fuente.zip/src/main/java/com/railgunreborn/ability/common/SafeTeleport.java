package com.railgunreborn.ability.common;

import java.util.Optional;
import java.util.OptionalDouble;

import javax.annotation.Nullable;

import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;

/**
 * Teletransporte seguro común a Mark, Penetrate, Location y Flashing ({@code mark-teleport.md} y
 * {@code penetrate-teleport.md}, decisiones de 2026-10-08). Todas las posiciones son de los <b>pies</b>.
 *
 * <p>Un destino es válido si la caja de la entidad allí: no choca con bloques (ni con entidades sólidas), no toca lava,
 * fuego, magma, cactus..., está en chunks cargados, dentro del borde del mundo y por encima de la altura mínima. Si hay
 * suelo a ≤ {@link SafeTeleportRules#GROUND_SNAP} bloques debajo, el destino se posa en él; si no, al llegar se activa
 * la protección de caída ({@link TeleportFallGuard}).
 *
 * <p>Uso típico en una habilidad: {@code findSafe(level, player, from, to, minDist)} → si vacío, rechazar sin coste;
 * si no, cobrar y {@code teleport(player, destino)}.
 *
 * <p>Las consultas ({@code isSafeSpot}, {@code validate}, {@code findSafe}...) aceptan cualquier {@link Level}: el
 * cliente las repite para dibujar la silueta del destino (Mark Teleport).
 */
public final class SafeTeleport {
    private static final double GROUNDED_EPS = 1.0 / 16.0;

    private SafeTeleport() {
    }

    /** Caja de {@code entity} con los pies en {@code feet}. */
    public static AABB boxAt(Entity entity, Vec3 feet) {
        return entity.getDimensions(entity.getPose()).makeBoundingBox(feet);
    }

    /** Si la entidad cabe en {@code feet} sin colisiones ni peligros (no posa ni retrocede). */
    public static boolean isSafeSpot(Level level, Entity entity, Vec3 feet) {
        AABB box = boxAt(entity, feet);
        if (feet.y < level.getMinBuildHeight() || !level.getWorldBorder().isWithinBounds(box)) {
            return false;
        }
        if (!chunksLoaded(level, box)) {
            return false;
        }
        if (!level.noCollision(entity, box)) {
            return false;
        }
        // Incluye el bloque bajo los pies (magma, fogata...).
        BlockPos min = BlockPos.containing(box.minX, box.minY - 0.5, box.minZ);
        BlockPos max = BlockPos.containing(box.maxX - 1e-7, box.maxY - 1e-7, box.maxZ - 1e-7);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (isHazard(level.getBlockState(pos))) {
                return false;
            }
        }
        return true;
    }

    /** Bloques en los que no se debe aparecer aunque no tengan colisión. */
    public static boolean isHazard(BlockState state) {
        return state.getFluidState().is(FluidTags.LAVA)
                || state.is(BlockTags.FIRE)
                || state.is(BlockTags.CAMPFIRES)
                || state.is(Blocks.MAGMA_BLOCK)
                || state.is(Blocks.CACTUS)
                || state.is(Blocks.SWEET_BERRY_BUSH)
                || state.is(Blocks.WITHER_ROSE)
                || state.is(Blocks.POWDER_SNOW);
    }

    private static boolean chunksLoaded(Level level, AABB box) {
        int minX = SectionPos.blockToSectionCoord(Math.floor(box.minX));
        int maxX = SectionPos.blockToSectionCoord(Math.floor(box.maxX));
        int minZ = SectionPos.blockToSectionCoord(Math.floor(box.minZ));
        int maxZ = SectionPos.blockToSectionCoord(Math.floor(box.maxZ));
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (!level.hasChunk(x, z)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Cuánto puede bajar la caja hasta chocar, intentando bajar {@code maxDrop} (≤ 0; {@code -maxDrop} si no hay
     * nada).
     */
    private static double allowedDrop(Level level, Entity entity, AABB box, double maxDrop) {
        return Shapes.collide(Direction.Axis.Y, box, level.getBlockCollisions(entity, box.expandTowards(0, -maxDrop, 0)),
                -maxDrop);
    }

    /** {@code feet} posado en el suelo si lo hay a ≤ 3 bloques; si no, {@code feet} tal cual. */
    public static Vec3 snapToGround(Level level, Entity entity, Vec3 feet) {
        OptionalDouble drop = SafeTeleportRules.groundDrop(
                allowedDrop(level, entity, boxAt(entity, feet), SafeTeleportRules.GROUND_SNAP));
        return drop.isPresent() ? feet.add(0, drop.getAsDouble(), 0) : feet;
    }

    /** Si la entidad estaría apoyada (suelo a menos de 1/16 de bloque) con los pies en {@code feet}. */
    public static boolean isGrounded(Level level, Entity entity, Vec3 feet) {
        return allowedDrop(level, entity, boxAt(entity, feet), GROUNDED_EPS) > -GROUNDED_EPS + 1e-7;
    }

    /**
     * Valida un destino concreto: seguro y, si hay suelo a ≤ 3 bloques, posado en él (el punto posado también tiene que
     * ser seguro: no se baja a lava).
     *
     * @return el destino final, o vacío si no vale
     */
    public static Optional<Vec3> validate(Level level, Entity entity, Vec3 feet) {
        if (!isSafeSpot(level, entity, feet)) {
            return Optional.empty();
        }
        Vec3 grounded = snapToGround(level, entity, feet);
        if (grounded != feet && !isSafeSpot(level, entity, grounded)) {
            return Optional.empty();
        }
        return Optional.of(grounded);
    }

    /**
     * Busca el destino más lejano válido sobre el rayo de {@code from} a {@code to}, retrocediendo desde {@code to} de
     * {@link SafeTeleportRules#BACK_OFF_STEP} en {@code BACK_OFF_STEP} sin acercarse a menos de {@code minDistance} de
     * {@code from}. El destino puede quedar posado (ver {@link #validate}).
     */
    public static Optional<Vec3> findSafe(Level level, Entity entity, Vec3 from, Vec3 to, double minDistance) {
        Vec3 delta = to.subtract(from);
        double distance = delta.length();
        if (distance < 1e-6) {
            return minDistance <= 0 ? validate(level, entity, to) : Optional.empty();
        }
        Vec3 dir = delta.scale(1 / distance);
        return SafeTeleportRules.backOff(distance, minDistance, SafeTeleportRules.BACK_OFF_STEP,
                d -> validate(level, entity, from.add(dir.scale(d))));
    }

    /**
     * Teletransporta al jugador dentro de su dimensión, conservando la mirada: baja de la montura y suelta a los
     * pasajeros, anula la caída acumulada y la velocidad vertical hacia abajo, reinicia el contador anti-vuelo y, si
     * llega en el aire, activa la protección de caída. No valida: llamar antes a {@link #validate}/{@link #findSafe}.
     */
    public static void teleport(ServerPlayer player, Vec3 feet) {
        player.stopRiding();
        player.ejectPassengers();
        player.connection.teleport(feet.x, feet.y, feet.z, player.getYRot(), player.getXRot());
        afterArrival(player, player.serverLevel(), feet);
    }

    /**
     * Igual, pero a otra dimensión (Location Teleport) con {@link DimensionTransition}, sin portales ni plataformas. Si
     * {@code level} es la dimensión actual, equivale a {@link #teleport(ServerPlayer, Vec3)}.
     *
     * @return false si el cambio de dimensión no se hizo (otro mod lo canceló...)
     */
    public static boolean teleport(ServerPlayer player, ServerLevel level, Vec3 feet) {
        if (level == player.serverLevel()) {
            teleport(player, feet);
            return true;
        }
        player.stopRiding();
        player.ejectPassengers();
        DimensionTransition transition = new DimensionTransition(level, feet, Vec3.ZERO, player.getYRot(),
                player.getXRot(), DimensionTransition.DO_NOTHING);
        if (player.changeDimension(transition) == null) {
            return false;
        }
        afterArrival(player, level, feet);
        return true;
    }

    /**
     * Lleva una entidad que no es el jugador (mascotas, pasajeros de Location Teleport) a {@code feet} en
     * {@code level}. Entre dimensiones la entidad se recrea: usar la devuelta.
     *
     * @return la entidad en el destino, o null si no se pudo
     */
    @Nullable
    public static Entity teleportEntity(Entity entity, ServerLevel level, Vec3 feet) {
        if (entity instanceof ServerPlayer player) {
            return teleport(player, level, feet) ? player : null;
        }
        entity.stopRiding();
        entity.ejectPassengers();
        Entity moved;
        if (level == entity.level()) {
            entity.teleportTo(feet.x, feet.y, feet.z);
            moved = entity;
        } else {
            moved = entity.changeDimension(new DimensionTransition(level, feet, Vec3.ZERO, entity.getYRot(),
                    entity.getXRot(), DimensionTransition.DO_NOTHING));
        }
        if (moved != null) {
            moved.resetFallDistance();
        }
        return moved;
    }

    private static void afterArrival(ServerPlayer player, ServerLevel level, Vec3 feet) {
        player.resetFallDistance();
        Vec3 motion = player.getDeltaMovement();
        if (motion.y < 0) {
            player.setDeltaMovement(motion.x, 0, motion.z);
        }
        MagMovementSkill.resetFlying(player);
        if (!isGrounded(level, player, feet)) {
            guardFall(player, SafeTeleportRules.FALL_GUARD_TICKS);
        }
    }

    /** Anula el daño de caída durante {@code ticks} o hasta tocar el suelo, lo primero ({@link TeleportFallGuard}). */
    public static void guardFall(ServerPlayer player, int ticks) {
        long now = player.serverLevel().getGameTime();
        player.setData(ModAttachments.TP_FALL_GUARD, new TeleportFallGuard.Window(now, now + ticks));
    }

    /** Si el jugador tiene la protección de caída activa. */
    public static boolean isFallGuarded(ServerPlayer player) {
        TeleportFallGuard.Window window = player.getExistingDataOrNull(ModAttachments.TP_FALL_GUARD);
        return window != null && player.serverLevel().getGameTime() <= window.until();
    }
}
