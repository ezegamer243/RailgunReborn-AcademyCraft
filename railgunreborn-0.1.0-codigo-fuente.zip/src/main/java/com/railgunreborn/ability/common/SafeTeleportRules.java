package com.railgunreborn.ability.common;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.DoubleFunction;

/**
 * Reglas puras de {@link SafeTeleport} (sin mundo): el retroceso por el rayo y la decisión de posar en el suelo.
 * Fichas: {@code mark-teleport.md} y {@code penetrate-teleport.md} ([DUDA] de seguridad del destino y de caída).
 */
public final class SafeTeleportRules {
    /** Paso del retroceso por el rayo, en bloques. */
    public static final double BACK_OFF_STEP = 0.25;
    /** Se posa en el suelo si hay uno a esta distancia o menos bajo el destino. */
    public static final double GROUND_SNAP = 3.0;
    /** Protección de caída si se llega en el aire (o hasta tocar suelo, lo primero). */
    public static final int FALL_GUARD_TICKS = 40;
    private static final double EPS = 1e-6;

    private SafeTeleportRules() {
    }

    /**
     * Prueba distancias desde {@code distance} hacia atrás, de {@code step} en {@code step}, sin bajar de
     * {@code minDistance}, y devuelve el primer resultado presente de {@code tryAt}. La última distancia probada es
     * siempre {@code minDistance} (si {@code distance >= minDistance}), aunque no caiga en un paso exacto.
     */
    public static <T> Optional<T> backOff(double distance, double minDistance, double step,
            DoubleFunction<Optional<T>> tryAt) {
        if (step <= 0) {
            throw new IllegalArgumentException("step must be positive");
        }
        if (distance < minDistance - EPS) {
            return Optional.empty();
        }
        for (double d = distance; d > minDistance + EPS; d -= step) {
            Optional<T> found = tryAt.apply(d);
            if (found.isPresent()) {
                return found;
            }
        }
        return tryAt.apply(Math.max(minDistance, 0));
    }

    /**
     * Cuánto bajar para posarse, dado el desplazamiento vertical que permite la colisión al intentar bajar
     * {@link #GROUND_SNAP} ({@code allowedDrop} ≤ 0, como devuelve {@code Shapes.collide}). Vacío si no hay suelo a esa
     * distancia (se queda en el aire). 0 si ya está apoyado.
     */
    public static OptionalDouble groundDrop(double allowedDrop) {
        if (allowedDrop <= -GROUND_SNAP + EPS) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(Math.min(0, allowedDrop));
    }
}
