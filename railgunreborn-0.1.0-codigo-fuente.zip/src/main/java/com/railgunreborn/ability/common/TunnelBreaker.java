package com.railgunreborn.ability.common;

import java.util.List;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.TunnelRules.BreakOutcome;
import com.railgunreborn.ability.common.TunnelRules.Cell;
import com.railgunreborn.ability.common.TunnelRules.LineBudget;
import com.railgunreborn.ability.common.TunnelRules.Vec;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Túnel de los rayos (Railgun, Meltdowner): disco de líneas perpendicular a la mirada centrado en {@code origin}
 * (los ojos), sin casillas repetidas, con la energía total repartida entre las líneas y gastada según la dureza de
 * cada bloque. El paso 0 (plano de los pies) no se rompe. Respeta {@link BlockPermissions}. Geometría en
 * {@link TunnelRules}.
 */
public final class TunnelBreaker {
    private TunnelBreaker() {
    }

    /**
     * Parámetros de un túnel.
     *
     * @param radius            radio del disco (Railgun 2; Meltdowner {@code lerp(2, 3, exp)})
     * @param totalEnergy       energía repartida entre las líneas
     * @param maxSteps          pasos (bloques) de cada línea
     * @param dropProb          probabilidad de que cada drop de un bloque roto caiga
     * @param neighborProb      probabilidad por paso de romper además un vecino al azar
     * @param breakSoundProb    probabilidad del sonido de rotura (solo en los primeros pasos)
     * @param breakSoundMaxStep último paso (exclusivo) con sonido de rotura
     */
    public record Spec(double radius, double totalEnergy, int maxSteps, double dropProb, double neighborProb,
            double breakSoundProb, int breakSoundMaxStep) {
        /** Con las probabilidades del original (las del Railgun). */
        public Spec(double radius, double totalEnergy, int maxSteps) {
            this(radius, totalEnergy, maxSteps, TunnelRules.DROP_PROB, TunnelRules.NEIGHBOR_PROB,
                    TunnelRules.BREAK_SOUND_PROB, TunnelRules.BREAK_SOUND_MAX_STEP);
        }
    }

    /**
     * Abre el túnel. Comprueba {@link BlockPermissions#mayModifyWorld} (si no, no toca nada) y el permiso de cada
     * bloque; un bloque sin permiso o sin energía suficiente detiene su línea. Con radio 3 y 50 pasos son unos
     * pocos cientos de bloques como mucho: se hace en un solo tick.
     *
     * @return bloques rotos
     */
    public static int breakTunnel(ServerPlayer player, Skill skill, Vec3 origin, Vec3 dir, Spec spec) {
        if (!BlockPermissions.mayModifyWorld(player, skill)) {
            return 0;
        }
        RandomSource random = player.getRandom();
        Vec d = new Vec(dir.x, dir.y, dir.z);
        List<Cell> starts = TunnelRules.lineStarts(new Vec(origin.x, origin.y, origin.z), d, spec.radius(),
                random::nextDouble);
        int broken = 0;
        for (Cell start : starts) {
            LineBudget budget = new LineBudget(
                    TunnelRules.lineEnergy(spec.totalEnergy(), starts.size(), random.nextDouble()));
            List<Cell> line = TunnelRules.line(start, d, spec.maxSteps());
            for (int step = TunnelRules.FIRST_STEP; step < line.size() && !budget.exhausted(); step++) {
                Cell cell = line.get(step);
                BlockPos pos = new BlockPos(cell.x(), cell.y(), cell.z());
                int result = breakAt(player, pos, step, budget, spec);
                if (result < 0) {
                    break;
                }
                broken += result;
                BlockPos neighbor = random.nextDouble() < spec.neighborProb()
                        ? pos.relative(Direction.getRandom(random)) : null;
                // El vecino al azar tampoco puede caer en el plano del jugador (p. ej. el suelo bajo sus pies).
                if (neighbor != null && alongDir(neighbor, origin, dir) >= TunnelRules.FIRST_STEP) {
                    int extra = breakAt(player, neighbor, step, budget, spec);
                    if (extra < 0) {
                        break;
                    }
                    broken += extra;
                }
            }
        }
        return broken;
    }

    /** Distancia del centro del bloque al origen medida a lo largo de la dirección del rayo. */
    private static double alongDir(BlockPos pos, Vec3 origin, Vec3 dir) {
        return Vec3.atCenterOf(pos).subtract(origin).dot(dir.normalize());
    }

    /** @return 1 roto, 0 era aire (gratis), -1 la línea se detiene */
    private static int breakAt(ServerPlayer player, BlockPos pos, int step, LineBudget budget, Spec spec) {
        ServerLevel level = player.serverLevel();
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) {
            return 0;
        }
        double hardness = state.getDestroySpeed(level, pos);
        // El permiso (y su evento) solo se pide si hay energía para romperlo de verdad.
        boolean allowed = budget.remaining() >= TunnelRules.effectiveHardness(hardness)
                && BlockPermissions.mayBreakAt(player, pos, state);
        if (budget.tryBreak(hardness, allowed) == BreakOutcome.STOP) {
            return -1;
        }
        RandomSource random = player.getRandom();
        for (ItemStack drop : Block.getDrops(state, level, pos, level.getBlockEntity(pos), player, ItemStack.EMPTY)) {
            if (random.nextDouble() < spec.dropProb()) {
                Block.popResource(level, pos, drop);
            }
        }
        if (step < spec.breakSoundMaxStep() && random.nextDouble() < spec.breakSoundProb()) {
            SoundType sound = state.getSoundType(level, pos, player);
            level.playSound(null, pos, sound.getBreakSound(), SoundSource.BLOCKS, (sound.getVolume() + 1f) / 2f,
                    sound.getPitch());
        }
        // Sin partículas de rotura (como el original); los contenedores sueltan su contenido al quitarse.
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        return 1;
    }
}
