package com.railgunreborn.ability.common;

import com.railgunreborn.ability.Skill;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.BlockEvent;

/**
 * Política común de las habilidades que tocan bloques (Arc Gen, Mag Manip, Railgun, Meltdowner, Mining Ray...).
 *
 * <p>Dos niveles: {@link #mayModifyWorld} (la habilidad y el mundo lo permiten: {@code destroy_blocks} y la gamerule
 * {@code mobGriefing}) y el permiso por casilla ({@link #mayBuildAt}, {@link #mayBreakAt}), que respeta el modo
 * aventura, la protección del spawn/borde del mundo y, al romper, el evento de NeoForge (mods de protección).
 */
public final class BlockPermissions {
    private BlockPermissions() {
    }

    /** {@code destroy_blocks} de la habilidad y gamerule {@code mobGriefing}. Si es false, la habilidad daña igual. */
    public static boolean mayModifyWorld(ServerPlayer player, Skill skill) {
        return skill.canDestroyBlocks()
                && player.serverLevel().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /**
     * Permiso de construcción en la casilla, sin evento: límites del mundo, permisos (aventura), protección del
     * spawn/borde. Para colocar (Arc Gen, Mag Manip) el evento de colocación se lanza aparte, al colocar.
     */
    public static boolean mayBuildAt(ServerPlayer player, BlockPos pos) {
        ServerLevel level = player.serverLevel();
        return level.isInWorldBounds(pos)
                && player.mayUseItemAt(pos, Direction.UP, ItemStack.EMPTY)
                && player.mayInteract(level, pos)
                && !player.blockActionRestricted(level, pos, player.gameMode.getGameModeForPlayer());
    }

    /** {@link #mayBuildAt} más el evento de rotura de NeoForge (cancelable por mods de protección). */
    public static boolean mayBreakAt(ServerPlayer player, BlockPos pos, BlockState state) {
        if (!mayBuildAt(player, pos)) {
            return false;
        }
        return !NeoForge.EVENT_BUS.post(new BlockEvent.BreakEvent(player.serverLevel(), pos, state, player))
                .isCanceled();
    }
}
