package com.railgunreborn.ability.common;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Rayos reflejables ({@code docs/spec/vec-reflection.md} §11). Dos lados:
 * <ul>
 * <li>El <b>atacante</b> (Railgun, Meltdowner) llama a {@link #reflects} antes de dañar a cada objetivo; si devuelve
 * true no le daña y corta el rayo y el túnel en {@link #cutLength}.</li>
 * <li>El <b>reflector</b> (Vector Reflection) escucha {@link BeamReflectEvent}, lo cancela y hace el contragolpe con
 * {@link #counterAttack}.</li>
 * </ul>
 * Así las categorías no se llaman entre sí: sin nadie escuchando, los rayos se comportan igual que siempre.
 */
public final class BeamReflect {
    /** Alcance del contragolpe desde los ojos del reflector, en la dirección de su mirada (original: 10). */
    public static final double COUNTER_RANGE = 10.0;

    private BeamReflect() {
    }

    /**
     * Lanza {@link BeamReflectEvent} si {@code target} es otro jugador al que {@code caster} puede dañar (PvP), y
     * devuelve si alguien lo canceló (= lo refleja). Para cualquier otro objetivo no lanza nada y devuelve false.
     *
     * @param damage        daño del rayo antes de {@code damage_scale}
     * @param counterDamage contragolpe propio de la habilidad atacante
     */
    public static boolean reflects(ServerPlayer caster, Skill skill, LivingEntity target, Vec3 origin, Vec3 dir,
            float damage, float counterDamage) {
        if (!(target instanceof ServerPlayer player) || player == caster || !caster.canHarmPlayer(player)) {
            return false;
        }
        return NeoForge.EVENT_BUS.post(new BeamReflectEvent(caster, skill, player, origin, dir.normalize(), damage,
                counterDamage)).isCanceled();
    }

    /** Distancia a lo largo del rayo hasta el centro de la caja de {@code target} (≥ 0): la nueva longitud. */
    public static double cutLength(Vec3 origin, Vec3 dir, Entity target) {
        return Math.max(0, target.getBoundingBox().getCenter().subtract(origin).dot(dir.normalize()));
    }

    /** Resultado del contragolpe: dónde acaba el trazado, a quién tocó (o null) y si el daño se aplicó. */
    public record Counter(Vec3 end, @Nullable LivingEntity hit, boolean hurt) {
    }

    /**
     * Contragolpe del reflector: trazado de {@link #COUNTER_RANGE} bloques desde sus ojos en su mirada, parado por
     * bloques; al primer ser vivo (puede ser el atacante) le hace {@code damage} con una fuente de {@code type} <b>a
     * nombre del reflector</b>, respetando el PvP. No cobra ni manda efectos: eso es de quien refleja.
     */
    public static Counter counterAttack(ServerPlayer reflector, float damage, ResourceKey<DamageType> type) {
        Vec3 eye = reflector.getEyePosition();
        Vec3 far = eye.add(reflector.getViewVector(1.0f).scale(COUNTER_RANGE));
        HitResult block = reflector.level().clip(
                new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, reflector));
        Vec3 end = block.getType() == HitResult.Type.MISS ? far : block.getLocation();
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(reflector.level(), reflector, eye, end,
                new AABB(eye, end).inflate(1.0), SkillTargets::isTargetable);
        if (entityHit == null || !(entityHit.getEntity() instanceof LivingEntity hit)) {
            return new Counter(end, null, false);
        }
        boolean hurt = SkillTargets.mayHarm(reflector, hit, true)
                && hit.hurt(ModDamageTypes.source(reflector, type), damage);
        return new Counter(entityHit.getLocation(), hit, hurt);
    }
}
