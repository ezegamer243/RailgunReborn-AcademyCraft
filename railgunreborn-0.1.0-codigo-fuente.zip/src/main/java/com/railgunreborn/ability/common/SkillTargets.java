package com.railgunreborn.ability.common;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.railgunreborn.ability.common.TunnelRules.Vec;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Selección de objetivos común a las habilidades de daño (rayos de Electromaster y Meltdowner). */
public final class SkillTargets {
    private SkillTargets() {
    }

    /** Seres vivos a los que puede apuntar una habilidad (vivos, con caja seleccionable y no espectadores). */
    public static boolean isTargetable(Entity entity) {
        return entity instanceof LivingEntity && entity.isAlive() && entity.isPickable() && !entity.isSpectator();
    }

    /**
     * Si una habilidad puede dañar a {@code target}: si es otro jugador, la opción {@code attackPlayer} de la
     * habilidad y el PvP/equipos del servidor ({@code Player#canHarmPlayer}) deben permitirlo.
     */
    public static boolean mayHarm(Player attacker, Entity target, boolean attackPlayerOption) {
        if (target instanceof Player other) {
            return attackPlayerOption && attacker.canHarmPlayer(other);
        }
        return true;
    }

    /**
     * Seres vivos dentro del cilindro de radio {@code radius} alrededor del eje que sale de {@code origin} hacia
     * {@code dir}, hasta {@code range}, medidos por el centro de su caja, de cerca a lejos. Atraviesa bloques. Excluye
     * a {@code player}.
     */
    public static List<LivingEntity> inCylinder(Player player, Vec3 origin, Vec3 dir, double range, double radius) {
        Vec o = new Vec(origin.x, origin.y, origin.z);
        Vec d = new Vec(dir.x, dir.y, dir.z);
        AABB box = new AABB(origin, origin.add(dir.normalize().scale(range))).inflate(radius + 1.0);
        List<LivingEntity> result = new ArrayList<>();
        List<Double> along = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, box, SkillTargets::isTargetable)) {
            Vec3 c = entity.getBoundingBox().getCenter();
            double[] dist = TunnelRules.axisDistances(o, d, new Vec(c.x, c.y, c.z));
            if (TunnelRules.inCylinder(dist[0], dist[1], range, radius)) {
                result.add((LivingEntity) entity);
                along.add(dist[0]);
            }
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < result.size(); i++) {
            order.add(i);
        }
        order.sort(Comparator.comparingDouble(along::get));
        return order.stream().map(result::get).toList();
    }
}
