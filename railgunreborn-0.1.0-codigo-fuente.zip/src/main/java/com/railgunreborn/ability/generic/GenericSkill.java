package com.railgunreborn.ability.generic;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Habilidad pasiva genérica (Brain Course...). No hace nada por sí misma: sus efectos los aplica {@code CPData}
 * leyendo {@link #learned}.
 */
public final class GenericSkill extends Skill {
    private final GenericRules.Kind kind;

    public GenericSkill(GenericRules.Kind kind, Properties props) {
        super(props);
        this.kind = kind;
    }

    public GenericRules.Kind kind() {
        return kind;
    }

    /** Id de la genérica {@code kind} de la categoría {@code categoryId} (mismo esquema que {@code Electromaster}). */
    public static ResourceLocation idFor(ResourceLocation categoryId, GenericRules.Kind kind) {
        return categoryId.withPath(p -> p + "/" + kind.path());
    }

    /** Genéricas aprendidas por el jugador en su categoría actual. */
    public static Set<GenericRules.Kind> learned(AbilityData data) {
        Set<GenericRules.Kind> set = EnumSet.noneOf(GenericRules.Kind.class);
        data.getCategory().ifPresent(category -> {
            for (GenericRules.Kind kind : GenericRules.Kind.values()) {
                if (data.isLearned(idFor(category, kind))) {
                    set.add(kind);
                }
            }
        });
        return set;
    }

    /**
     * Registra las tres genéricas de una categoría (como {@code addGenericSkills} del original); llamar después de
     * sus habilidades propias para mantener el orden del registro. Posiciones: fila inferior del árbol.
     */
    public static Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> registerFor(
            DeferredRegister<Skill> register, ResourceLocation categoryId) {
        Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> holders =
                new java.util.EnumMap<>(GenericRules.Kind.class);
        ResourceLocation brain = idFor(categoryId, GenericRules.Kind.BRAIN_COURSE);
        ResourceLocation advanced = idFor(categoryId, GenericRules.Kind.BRAIN_COURSE_ADVANCED);
        holders.put(GenericRules.Kind.BRAIN_COURSE, add(register, categoryId, GenericRules.Kind.BRAIN_COURSE,
                props(categoryId, GenericRules.Kind.BRAIN_COURSE).guiPos(30, 110)));
        holders.put(GenericRules.Kind.BRAIN_COURSE_ADVANCED, add(register, categoryId,
                GenericRules.Kind.BRAIN_COURSE_ADVANCED,
                props(categoryId, GenericRules.Kind.BRAIN_COURSE_ADVANCED).parent(brain, 0f).guiPos(115, 110)));
        holders.put(GenericRules.Kind.MIND_COURSE, add(register, categoryId, GenericRules.Kind.MIND_COURSE,
                props(categoryId, GenericRules.Kind.MIND_COURSE).parent(advanced, 0f).guiPos(205, 110)));
        return holders;
    }

    private static DeferredHolder<Skill, GenericSkill> add(DeferredRegister<Skill> register,
            ResourceLocation categoryId, GenericRules.Kind kind, Properties props) {
        return register.register(categoryId.getPath() + "/" + kind.path(), () -> new GenericSkill(kind, props));
    }

    private static Properties props(ResourceLocation categoryId, GenericRules.Kind kind) {
        return new Properties(categoryId, kind.level()).passive().requiresAnySkillOfLevel(kind.level());
    }
}
