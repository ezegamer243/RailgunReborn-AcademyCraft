package com.railgunreborn.ability.generic;

import java.util.Set;

/** Reglas puras de las habilidades genéricas ({@code docs/spec/generic-skills.md}); sin Minecraft, para JUnit. */
public final class GenericRules {
    /** Las tres genéricas; cada una con el nivel que exige tanto la habilidad como la condición "alguna de nivel N". */
    public enum Kind {
        BRAIN_COURSE("brain_course", 3),
        BRAIN_COURSE_ADVANCED("brain_course_advanced", 4),
        MIND_COURSE("mind_course", 5);

        private final String path;
        private final int level;

        Kind(String path, int level) {
            this.path = path;
            this.level = level;
        }

        /** Nombre de la habilidad dentro de su categoría. */
        public String path() {
            return path;
        }

        public int level() {
            return level;
        }
    }

    public static final float BRAIN_COURSE_CP = 1000f;
    /** El texto original decía 1000, pero el código del juego sumaba 1500 (decisión del usuario: 1500). */
    public static final float BRAIN_COURSE_ADVANCED_CP = 1500f;
    public static final float BRAIN_COURSE_ADVANCED_OVERLOAD = 100f;
    public static final float MIND_COURSE_RECOVER_FACTOR = 1.2f;

    private GenericRules() {
    }

    public static float maxCpBonus(Set<Kind> learned) {
        return (learned.contains(Kind.BRAIN_COURSE) ? BRAIN_COURSE_CP : 0f)
                + (learned.contains(Kind.BRAIN_COURSE_ADVANCED) ? BRAIN_COURSE_ADVANCED_CP : 0f);
    }

    public static float maxOverloadBonus(Set<Kind> learned) {
        return learned.contains(Kind.BRAIN_COURSE_ADVANCED) ? BRAIN_COURSE_ADVANCED_OVERLOAD : 0f;
    }

    /** Solo regeneración de CP; la de overload no cambia. */
    public static float cpRecoverFactor(Set<Kind> learned) {
        return learned.contains(Kind.MIND_COURSE) ? MIND_COURSE_RECOVER_FACTOR : 1f;
    }
}
