package com.railgunreborn.ability.electromaster;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;

import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Body Intensify: nivel 3. Se mantiene la tecla para cargar y al soltar (con al menos 10 ticks) da efectos de pocion
 * al azar a cambio de hambre. Ficha: {@code docs/spec/body-intensify.md} (mandan las decisiones del final). Numeros en
 * {@link BodyIntensifyRules}.
 */
public class BodyIntensifySkill extends Skill {
    /** Al pulsar (solo lo pinta el propio jugador: bucle de sonido y capa de pantalla). */
    public static final String START_CHANNEL = "start";
    /** Fin de la carga, con {@link #PERFORMED_KEY}. */
    public static final String END_CHANNEL = "end";
    public static final String PERFORMED_KEY = "performed";

    public BodyIntensifySkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new BodyIntensifyContext(player, this);
    }

    private static Holder<MobEffect> effectOf(BodyIntensifyRules.Buff buff) {
        return switch (buff) {
            case SPEED -> MobEffects.MOVEMENT_SPEED;
            case STRENGTH -> MobEffects.DAMAGE_BOOST;
            case JUMP -> MobEffects.JUMP;
            case RESISTANCE -> MobEffects.DAMAGE_RESISTANCE;
            case REGENERATION -> MobEffects.REGENERATION;
        };
    }

    private static final class BodyIntensifyContext extends SkillContext {
        private final float exp;
        private int ticks;
        /** Overload tras pagar el inicial: no se deja bajar de aqui mientras se mantiene. */
        private float overloadFloor;
        private boolean endSent;

        BodyIntensifyContext(ServerPlayer player, BodyIntensifySkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            consume(BodyIntensifyRules.overloadCost(exp), 0f);
            overloadFloor = CPData.get(getPlayer()).getOverload();
            sendEffect(START_CHANNEL, new CompoundTag());
        }

        @Override
        protected void onKeyTick() {
            CPData.get(getPlayer()).raiseOverloadTo(overloadFloor);
            ticks++;
            boolean paid = ticks > BodyIntensifyRules.MAX_CHARGE_TICKS
                    || consume(0f, BodyIntensifyRules.cpPerTick(exp));
            if (!paid || ticks >= BodyIntensifyRules.TIMEOUT_TICKS) {
                sendEnd(false);
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            if (ticks >= BodyIntensifyRules.MIN_TICKS) {
                perform();
                sendEnd(true);
            } else {
                sendEnd(false);
            }
            terminate();
        }

        private void perform() {
            ServerPlayer player = getPlayer();
            int charge = BodyIntensifyRules.chargeTicks(ticks);
            int duration = BodyIntensifyRules.buffTicks(charge, exp, 1f + player.getRandom().nextFloat());
            for (BodyIntensifyRules.Buff buff : BodyIntensifyRules.chooseBuffs(charge, player.getRandom())) {
                player.addEffect(new MobEffectInstance(effectOf(buff), duration,
                        BodyIntensifyRules.amplifier(charge, buff), false, true));
            }
            player.addEffect(new MobEffectInstance(MobEffects.HUNGER, BodyIntensifyRules.hungerTicks(charge),
                    BodyIntensifyRules.HUNGER_AMPLIFIER, false, true));
            addSkillExp(BodyIntensifyRules.EXP_GAIN);
            // Tras la exp: el cooldown usa la exp ya actualizada.
            setCooldown(BodyIntensifyRules.cooldownTicks(getSkillExp()));
        }

        private void sendEnd(boolean performed) {
            if (endSent) {
                return;
            }
            endSent = true;
            CompoundTag data = new CompoundTag();
            data.putBoolean(PERFORMED_KEY, performed);
            sendEffect(END_CHANNEL, data);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            // V, sobrecarga, logout...: que pare el bucle sin dar nada (si ya se envio, no repite).
            sendEnd(false);
        }
    }
}
