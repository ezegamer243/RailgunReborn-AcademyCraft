package com.railgunreborn.ability.electromaster;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.electromaster.MagMovementRules.HitKind;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Magnet Movement: nivel 2. Se mantiene la tecla: el jugador es arrastrado hacia el bloque o la entidad metálicos a los
 * que apuntaba al pulsar. Ficha: {@code docs/spec/mag-movement.md} (mandan las decisiones del final). Números en
 * {@link MagMovementRules}; qué es metálico, en {@link MagneticTargets}.
 *
 * <p>El servidor elige el objetivo una sola vez y se lo manda a la mitad cliente local ({@link #TARGET_CHANNEL}), que
 * es la que mueve al jugador (como el original). El servidor cobra, vigila que el objetivo siga valiendo y evita que
 * el arrastre cuente como caída o como "volar".
 */
public class MagMovementSkill extends Skill {
    /** Servidor → cliente local: el objetivo (mismos datos que {@link #STATE_CHANNEL}). */
    public static final String TARGET_CHANNEL = "target";
    /** Efecto para los cercanos: objetivo del arco. Al empezar y cada {@link #STATE_INTERVAL} ticks. */
    public static final String STATE_CHANNEL = "state";
    public static final String STOP_CHANNEL = "stop";
    /** Id de la entidad objetivo; si no está, el objetivo es el punto {@link #POINT_KEY}. */
    public static final String ENTITY_KEY = "entity";
    /** Punto de impacto en la superficie del bloque (3 doubles). */
    public static final String POINT_KEY = "point";
    public static final int STATE_INTERVAL = 10;

    public MagMovementSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MagMovementContext(player, this);
    }

    /** Objetivo elegido al pulsar: una entidad, o un punto fijo sobre un bloque. */
    public record Target(@Nullable Entity entity, @Nullable BlockPos block, Vec3 point) {
        /** Destino actual: ojos de la entidad (vivo) o el punto de impacto. */
        public Vec3 destination() {
            return entity != null ? entity.getEyePosition() : point;
        }

        public CompoundTag write() {
            CompoundTag tag = new CompoundTag();
            if (entity != null) {
                tag.putInt(ENTITY_KEY, entity.getId());
            }
            writeVec(tag, POINT_KEY, point);
            return tag;
        }
    }

    /**
     * Objetivo al que apunta el jugador, o null si el primer impacto no es metálico (o es un bloque débil sin exp
     * suficiente) o no toca nada.
     */
    @Nullable
    public static Target findTarget(ServerPlayer player, float exp) {
        HitResult hit = MagneticTargets.trace(player, MagMovementRules.RANGE);
        HitKind kind = MagneticTargets.classify(player.level(), hit);
        if (!MagMovementRules.isValidTarget(kind, exp)) {
            return null;
        }
        if (hit instanceof EntityHitResult entityHit) {
            return new Target(entityHit.getEntity(), null, hit.getLocation());
        }
        return new Target(null, ((BlockHitResult) hit).getBlockPos(), hit.getLocation());
    }

    public static void writeVec(CompoundTag tag, String key, Vec3 vec) {
        CompoundTag v = new CompoundTag();
        v.putDouble("x", vec.x);
        v.putDouble("y", vec.y);
        v.putDouble("z", vec.z);
        tag.put(key, v);
    }

    @Nullable
    public static Vec3 readVec(CompoundTag tag, String key) {
        if (!tag.contains(key)) {
            return null;
        }
        CompoundTag v = tag.getCompound(key);
        Vec3 vec = new Vec3(v.getDouble("x"), v.getDouble("y"), v.getDouble("z"));
        return Double.isFinite(vec.x) && Double.isFinite(vec.y) && Double.isFinite(vec.z) ? vec : null;
    }

    /**
     * Reinicia el contador del anticheat que expulsa por "volar" (ficha [DUDA] 5): el arrastre lo decide el cliente y
     * puede pasar más de 4 s sin tocar el suelo. El campo se abre con el access transformer.
     */
    public static void resetFlying(ServerPlayer player) {
        if (player.connection != null) {
            player.connection.aboveGroundTickCount = 0;
        }
    }

    private static final class MagMovementContext extends SkillContext {
        private final float exp;
        @Nullable
        private Target target;
        private Vec3 startPos = Vec3.ZERO;

        MagMovementContext(ServerPlayer player, MagMovementSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            ServerPlayer player = getPlayer();
            Target found = findTarget(player, exp);
            // Decisión 1: apuntar a nada (o a algo no metálico) no cobra ni da exp.
            if (found == null || !consume(MagMovementRules.overloadCost(exp), 0f)) {
                terminate();
                return;
            }
            target = found;
            startPos = player.position();
            sendToLocal(TARGET_CHANNEL, found.write());
            sendEffect(STATE_CHANNEL, found.write());
        }

        @Override
        protected void onKeyTick() {
            // Consumir cada tick también reinicia la espera de recuperación: el overload queda "congelado".
            if (target == null || !consume(0f, MagMovementRules.cpPerTick(exp)) || !targetStillValid()) {
                terminate();
                return;
            }
            ServerPlayer player = getPlayer();
            // [DUDA] 4: sin daño de caída mientras dura (el cliente mueve; el servidor acumula la caída).
            player.resetFallDistance();
            resetFlying(player);
            if (getTicksAlive() % STATE_INTERVAL == STATE_INTERVAL - 1) {
                sendEffect(STATE_CHANNEL, target.write());
            }
        }

        /** Entidad viva y cargada, o bloque que sigue siendo metálico ([DUDA] 6). */
        private boolean targetStillValid() {
            if (target.entity() != null) {
                Entity entity = target.entity();
                return entity.isAlive() && !entity.isRemoved() && entity.level() == getPlayer().level();
            }
            Level level = getPlayer().level();
            return MagMovementRules.isValidTarget(MagneticTargets.classify(level.getBlockState(target.block())), exp);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (target == null) {
                return;
            }
            ServerPlayer player = getPlayer();
            addSkillExp(MagMovementRules.expGain(player.position().distanceTo(startPos)));
            player.resetFallDistance();
            resetFlying(player);
            sendEffect(STOP_CHANNEL, new CompoundTag());
        }
    }
}
