package com.railgunreborn.ability.electromaster;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import net.minecraft.world.phys.Vec3;

/**
 * Números y decisiones de Magnet Manipulation ({@code docs/spec/mag-manip.md}; mandan las decisiones del final), sin
 * mundo: se prueban con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class MagManipRules {
    /** Alcance del trazado para agarrar un bloque del mundo (con línea de visión, decisión 2). */
    public static final float GRAB_RANGE = 10f;
    /** Distancia² máxima (ojos del jugador - centro del bloque) para poder lanzar al soltar: menos de 5 bloques. */
    public static final double MAX_THROW_DISTANCE_SQR = 25.0;
    /** Alcance del trazado que decide hacia dónde se lanza. */
    public static final float AIM_RANGE = 20f;
    /** El bloque sostenido flota a esta distancia delante de los ojos... */
    public static final double HOLD_DISTANCE = 2.0;
    /** ...y esto por debajo de ellos. */
    public static final double HOLD_DROP = 0.1;
    /** Velocidad hacia el punto de sostén, en bloques/tick (cifra del código, [DUDA] 7: una sola actualización). */
    public static final double HOLD_SPEED = 0.2;
    /** Separación mínima entre el centro del bloque sostenido y una pared que corte la mirada. */
    public static final double HOLD_WALL_MARGIN = 0.6;
    /** Gravedad en vuelo (sin rozamiento), bloques/tick². */
    public static final double GRAVITY = 0.04;
    public static final float EXP_GAIN = 0.005f;
    /** Si tras esto sigue volando (p. ej. lanzado hacia arriba en un hueco enorme), se suelta como ítem. */
    public static final int MAX_FLIGHT_TICKS = 1200;
    /** Pasos a lo largo de la normal de la cara golpeada buscando sitio (último recurso, ficha 6.2.4). */
    public static final int MAX_FACE_STEPS = 10;
    /** Altura relativa de los ojos a la que se apunta cuando el trazado de puntería toca una entidad (ficha 6.1.3). */
    public static final double AIM_EYE_FRACTION = 0.6;

    private MagManipRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    private static float clampExp(float exp) {
        return Math.max(0f, Math.min(1f, exp));
    }

    /** CP al lanzar: 140 → 270. */
    public static float cpCost(float exp) {
        return lerp(140f, 270f, clampExp(exp));
    }

    /** Overload al lanzar: 35 → 20. */
    public static float overloadCost(float exp) {
        return lerp(35f, 20f, clampExp(exp));
    }

    /** Cooldown tras un lanzamiento con éxito: 60 → 40 ticks. */
    public static int cooldownTicks(float exp) {
        return (int) lerp(60f, 40f, clampExp(exp));
    }

    /** Daño del impacto antes de escalas (decisión 1): 8 → 15. */
    public static float damage(float exp) {
        return lerp(8f, 15f, clampExp(exp));
    }

    /** Velocidad de lanzamiento: 0.5 → 1.0 bloques/tick. */
    public static double throwSpeed(float exp) {
        return lerp(0.5f, 1.0f, clampExp(exp));
    }

    /** Factor de frenado al llegar: 1 lejos, {@code distancia²/4} a menos de 2 bloques. */
    public static double holdSpeedFactor(double distanceSqr) {
        return distanceSqr < 4.0 ? Math.max(0.0, distanceSqr) / 4.0 : 1.0;
    }

    /** Velocidad de este tick hacia el punto de sostén (se sobrescribe cada tick, no se acumula). */
    public static Vec3 holdVelocity(Vec3 center, Vec3 target) {
        Vec3 delta = target.subtract(center);
        double distSqr = delta.lengthSqr();
        if (distSqr < 1e-8) {
            return Vec3.ZERO;
        }
        double speed = HOLD_SPEED * holdSpeedFactor(distSqr);
        // Sin pasarse del destino: a poca distancia el paso sería mayor que lo que falta.
        return delta.normalize().scale(Math.min(speed, Math.sqrt(distSqr)));
    }

    /**
     * Punto de sostén: {@link #HOLD_DISTANCE} delante de los ojos y {@link #HOLD_DROP} por debajo. Si una pared corta
     * la mirada a {@code wallDistance} (o {@code NaN} si no hay), se acerca para no meter el bloque en ella
     * ([DUDA] 8: sostenido no colisiona).
     */
    public static Vec3 holdPoint(Vec3 eyes, Vec3 look, double wallDistance) {
        double dist = HOLD_DISTANCE;
        if (!Double.isNaN(wallDistance)) {
            dist = Math.max(0.0, Math.min(dist, wallDistance - HOLD_WALL_MARGIN));
        }
        return eyes.add(look.scale(dist)).subtract(0, HOLD_DROP, 0);
    }

    /** Se lanza si el bloque está a menos de 5 bloques y se pudo pagar; si no, cae y se coloca (ficha 6.1.2). */
    public static boolean canThrow(double distanceSqr, boolean paid) {
        return distanceSqr < MAX_THROW_DISTANCE_SQR && paid;
    }

    /**
     * Si un bloque del mundo se puede agarrar: metálico (normal o débil, sin requisito de exp), sin BlockEntity
     * (decisión 6), que no sea puerta ni pieza de pistón extendido, y rompible.
     */
    public static boolean isGrabbable(boolean magnetic, boolean hasBlockEntity, boolean excludedShape,
            boolean unbreakable) {
        return magnetic && !hasBlockEntity && !excludedShape && !unbreakable;
    }

    /** Casilla de bloque. */
    public record Cell(int x, int y, int z) {
        public Cell offset(int dx, int dy, int dz) {
            return new Cell(x + dx, y + dy, z + dz);
        }
    }

    /**
     * Casillas donde intentar colocar el bloque al chocar, en orden (ficha 6.2, sin la condición mal escrita del
     * original): la golpeada, la de delante de la cara golpeada, las 26 vecinas de la golpeada (de más cerca a más
     * lejos de la de delante) y hasta {@link #MAX_FACE_STEPS} más a lo largo de la normal. Sin repetir.
     *
     * @param faceX componente x de la normal de la cara golpeada (un solo eje vale ±1; igual faceY y faceZ)
     */
    public static List<Cell> placementCandidates(Cell hit, int faceX, int faceY, int faceZ) {
        List<Cell> list = new ArrayList<>();
        Cell front = hit.offset(faceX, faceY, faceZ);
        list.add(hit);
        list.add(front);
        List<Cell> neighbors = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) {
                        continue;
                    }
                    Cell cell = hit.offset(dx, dy, dz);
                    if (!cell.equals(front)) {
                        neighbors.add(cell);
                    }
                }
            }
        }
        // Orden estable: primero las más cercanas a la casilla de delante (el lado por el que llegó el bloque).
        neighbors.sort(Comparator.comparingInt(c -> distSqr(c, front)));
        list.addAll(neighbors);
        for (int step = 2; step <= MAX_FACE_STEPS; step++) {
            Cell cell = hit.offset(faceX * step, faceY * step, faceZ * step);
            if (!list.contains(cell)) {
                list.add(cell);
            }
        }
        return list;
    }

    private static int distSqr(Cell a, Cell b) {
        int dx = a.x - b.x;
        int dy = a.y - b.y;
        int dz = a.z - b.z;
        return dx * dx + dy * dy + dz * dz;
    }
}
