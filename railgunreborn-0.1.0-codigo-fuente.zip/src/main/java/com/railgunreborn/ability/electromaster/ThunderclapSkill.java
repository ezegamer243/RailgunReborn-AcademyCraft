package com.railgunreborn.ability.electromaster;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Thunderclap: nivel 5. Se mantiene la tecla para cargar (el jugador se va frenando); soltar a partir de 40 ticks o
 * llegar a 60 hace caer un rayo en el punto apuntado que daña a los seres vivos de una esfera de 15-30 bloques con
 * caída lineal. Ficha: {@code docs/spec/thunderclap.md} (mandan las decisiones del final). Números en
 * {@link ThunderclapRules}.
 */
public class ThunderclapSkill extends Skill {
    /** Arranque de la carga: aura para todos; marca del suelo solo para el que carga. */
    public static final String START_CHANNEL = "start";
    /** Fin de la carga (con o sin rayo). */
    public static final String STOP_CHANNEL = "stop";

    /** Modificador temporal de velocidad del que carga. */
    public static final ResourceLocation SLOW_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "thunder_clap_charge");

    // TODO(config): attackPlayer de la ficha, como en Arc Gen.
    private static final boolean ATTACK_PLAYER = true;

    public ThunderclapSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ThunderclapContext(player, this);
    }

    /**
     * Punto de impacto (ficha 5): trazado de 40 bloques solo contra bloques con colisión (atraviesa plantas, agua y
     * entidades); si no golpea nada, el final del trazado. Sirve en ambos lados.
     */
    public static Vec3 aim(Player player) {
        Vec3 eyes = player.getEyePosition();
        Vec3 end = eyes.add(player.getViewVector(1.0f).scale(ThunderclapRules.TRACE_RANGE));
        HitResult hit = player.level().clip(new ClipContext(eyes, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
    }

    /** Seres vivos de la esfera (distancia a los pies) alrededor de {@code point}, sin el lanzador. */
    public static List<LivingEntity> targets(Player player, Vec3 point, double radius) {
        AABB box = new AABB(point, point).inflate(radius);
        double radiusSqr = radius * radius;
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, box, ArcGenSkill::isTargetable)) {
            if (entity.position().distanceToSqr(point) <= radiusSqr) {
                result.add((LivingEntity) entity);
            }
        }
        return result;
    }

    /** Quita la ralentización de la carga (no hace nada si no estaba). */
    public static void removeSlowness(Player player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SLOW_MODIFIER_ID);
        }
    }

    private static final class ThunderclapContext extends SkillContext {
        private final ThunderclapSkill skill;
        private final float exp;
        private int ticks;
        private Vec3 point;
        /** START enviado y STOP pendiente. */
        private boolean effectRunning;

        ThunderclapContext(ServerPlayer player, ThunderclapSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
            this.point = player.getEyePosition();
        }

        @Override
        protected void onKeyDown() {
            // Decisión: sin CP para el primer tick no se cobra el overload.
            if (!canConsume(0f, ThunderclapRules.cpPerTick(exp))
                    || !consume(ThunderclapRules.overloadCost(exp), 0f)) {
                terminate();
                return;
            }
            point = aim(getPlayer());
            updateSlowness();
            sendEffect(START_CHANNEL, new CompoundTag());
            effectRunning = true;
        }

        @Override
        protected void onKeyTick() {
            ticks++;
            point = aim(getPlayer());
            updateSlowness();
            if (ThunderclapRules.paysCp(ticks) && !consume(0f, ThunderclapRules.cpPerTick(exp))) {
                // Sin CP justo en el tick 40 aún dispara (como el original); antes, cancela.
                finish();
                return;
            }
            if (ticks >= ThunderclapRules.MAX_TICKS) {
                finish();
            }
        }

        @Override
        protected void onKeyUp() {
            finish();
        }

        private void finish() {
            if (ThunderclapRules.releaseFires(ticks)) {
                strike();
            }
            terminate();
        }

        private void updateSlowness() {
            AttributeInstance speed = getPlayer().getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                speed.addOrUpdateTransientModifier(new AttributeModifier(SLOW_MODIFIER_ID,
                        ThunderclapRules.speedModifierAmount(ticks), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
        }

        private void strike() {
            ServerPlayer player = getPlayer();
            spawnVisualBolt(player);

            double radius = ThunderclapRules.radius(exp);
            for (LivingEntity victim : targets(player, point, radius)) {
                if (victim instanceof Player other
                        && !ArcGenRules.canDamagePlayer(ATTACK_PLAYER, player.canHarmPlayer(other))) {
                    continue;
                }
                float damage = ThunderclapRules.damageAt(exp, ticks, victim.position().distanceTo(point));
                if (damage > 0f) {
                    victim.hurt(ModDamageTypes.source(player, ModDamageTypes.THUNDER_CLAP),
                            damage * skill.getDamageScale());
                }
            }

            addSkillExp(ThunderclapRules.EXP_GAIN);
            setCooldown(ThunderclapRules.cooldownTicks(exp, ticks));
        }

        /**
         * Rayo vanilla solo visual: sin daño, fuego ni conversiones. Se coloca un poco hacia el jugador para que su
         * bloque de impacto sea el hueco delante de la superficie y nunca el bloque golpeado: así tampoco activa
         * pararrayos ni limpia el cobre.
         */
        private void spawnVisualBolt(ServerPlayer player) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(player.serverLevel());
            if (bolt == null) {
                return;
            }
            Vec3 at = point.subtract(player.getViewVector(1.0f).scale(0.1));
            bolt.moveTo(at.x, at.y, at.z);
            bolt.setVisualOnly(true);
            player.serverLevel().addFreshEntity(bolt);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            // Siempre: soltar, V, sobrecarga, muerte, logout, cambio de dimensión...
            removeSlowness(getPlayer());
            if (effectRunning) {
                effectRunning = false;
                sendEffect(STOP_CHANNEL, new CompoundTag());
            }
        }
    }
}
