package com.railgunreborn.ability.electromaster;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Thunder Bolt: nivel 4. Un clic: rayo grueso de 20 bloques que daña al ser vivo apuntado y a todos los seres vivos a
 * 8 bloques del punto de impacto. Ficha: {@code docs/spec/thunder-bolt.md} (las decisiones del final mandan). Números
 * en {@link ThunderBoltRules}.
 */
public class ThunderBoltSkill extends Skill {
    /**
     * Canal de {@code SkillEffects}: {@link #EFFECT_POINT_KEY} (3 doubles, punto de impacto) y
     * {@link #EFFECT_AFFECTED_KEY} (ids de los afectados por el área; las posiciones se leen en el cliente).
     */
    public static final String EFFECT_CHANNEL = "effect";
    public static final String EFFECT_POINT_KEY = "point";
    public static final String EFFECT_AFFECTED_KEY = "affected";

    // TODO(config): attackPlayer de la ficha, como en Arc Gen.
    private static final boolean ATTACK_PLAYER = true;

    public ThunderBoltSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ThunderBoltContext(player, this);
    }

    /** Ser vivo apuntado (o null) y punto de impacto: ojos del objetivo, superficie del bloque o final del alcance. */
    public record Target(@Nullable LivingEntity direct, Vec3 point) {
    }

    /** Trazado de la ficha §5: como Arc Gen pero el agua no detiene el rayo. Sirve en ambos lados. */
    public static Target aim(Player player) {
        HitResult hit = ArcGenSkill.trace(player, ThunderBoltRules.RANGE, ClipContext.Fluid.NONE);
        if (hit instanceof EntityHitResult entityHit && entityHit.getEntity() instanceof LivingEntity living) {
            return new Target(living, living.getEyePosition());
        }
        if (hit.getType() == HitResult.Type.MISS) {
            Vec3 end = player.getEyePosition().add(player.getViewVector(1.0f).scale(ThunderBoltRules.RANGE));
            return new Target(null, end);
        }
        return new Target(null, hit.getLocation());
    }

    /** Seres vivos del área: esfera de 8 bloques (a los pies) alrededor de {@code point}, sin el lanzador ni el directo. */
    public static List<LivingEntity> aoeTargets(Player player, Target target) {
        Vec3 point = target.point();
        AABB box = new AABB(point, point).inflate(ThunderBoltRules.AOE_RADIUS);
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, box, ArcGenSkill::isTargetable)) {
            if (entity != target.direct() && ThunderBoltRules.inAoe(entity.position().distanceToSqr(point))) {
                result.add((LivingEntity) entity);
            }
        }
        return result;
    }

    private static final class ThunderBoltContext extends SkillContext {
        private final ThunderBoltSkill skill;
        private final float exp;

        ThunderBoltContext(ServerPlayer player, ThunderBoltSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            if (consume(ThunderBoltRules.overloadCost(exp), ThunderBoltRules.cpCost(exp))) {
                fire();
            }
            terminate();
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            Target target = aim(player);
            List<LivingEntity> aoe = aoeTargets(player, target);

            boolean effective = false;
            if (target.direct() != null) {
                effective = strike(target.direct(), ThunderBoltRules.directDamage(exp),
                        ThunderBoltRules.DIRECT_SLOW_TICKS);
            }
            for (LivingEntity victim : aoe) {
                effective |= strike(victim, ThunderBoltRules.aoeDamage(exp), ThunderBoltRules.AOE_SLOW_TICKS);
            }

            addSkillExp(ThunderBoltRules.expGain(effective));
            setCooldown(ThunderBoltRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            CompoundTag point = new CompoundTag();
            point.putDouble("x", target.point().x);
            point.putDouble("y", target.point().y);
            point.putDouble("z", target.point().z);
            data.put(EFFECT_POINT_KEY, point);
            data.putIntArray(EFFECT_AFFECTED_KEY, aoe.stream().mapToInt(Entity::getId).toArray());
            sendEffect(EFFECT_CHANNEL, data);
        }

        /**
         * Daño + posible carga del creeper + posible Lentitud IV.
         *
         * @return false si es un jugador protegido por PvP: ni daño, ni Lentitud, ni cuenta para la exp.
         */
        private boolean strike(LivingEntity victim, float baseDamage, int slowTicks) {
            ServerPlayer player = getPlayer();
            if (victim instanceof Player other
                    && !ArcGenRules.canDamagePlayer(ATTACK_PLAYER, player.canHarmPlayer(other))) {
                return false;
            }
            victim.hurt(ModDamageTypes.source(player, ModDamageTypes.THUNDER_BOLT),
                    baseDamage * skill.getDamageScale());
            // Como Arc Gen: solo el dato sincronizado, sin el daño ni el fuego de un rayo de verdad.
            if (victim instanceof Creeper creeper && creeper.isAlive() && !creeper.isPowered()
                    && ArcGenRules.shouldChargeCreeper(player.getRandom().nextDouble())) {
                creeper.getEntityData().set(Creeper.DATA_IS_POWERED, true);
            }
            if (victim.isAlive() && ThunderBoltRules.slownessApplies(exp, player.getRandom().nextDouble())) {
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, slowTicks,
                        ThunderBoltRules.SLOW_AMPLIFIER), player);
            }
            return true;
        }
    }
}
