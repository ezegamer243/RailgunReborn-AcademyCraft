package com.railgunreborn.ability.electromaster;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.generic.GenericSkill;

import java.util.Map;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

/**
 * Categoría Electromaster y sus habilidades.
 *
 * <p>Están Arc Gen, Current Charging, Body Intensify, Magnet Movement, Thunder Bolt, Magnet Manipulation, Railgun,
 * Mine Detection y Thunderclap (nivel, padre y dependencias en {@code docs/spec/electromaster.md}).
 * Al final se registran las genéricas pasivas (Brain Course, Brain Course Advanced, Mind Course) con
 * {@link GenericSkill#registerFor}; sus efectos los aplica {@code CPData}.
 */
public final class Electromaster {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "electromaster");

    /** Color de estilo del original: RGBA 20, 113, 208, 100 (alfa sobre 255). */
    public static final int COLOR = 0x641471D0;

    public static final DeferredHolder<Category, Category> CATEGORY =
            AbilityRegistries.CATEGORIES.register(ID.getPath(), () -> new Category(COLOR, 1.0f));

    public static final DeferredHolder<Skill, ArcGenSkill> ARC_GEN =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/arc_gen",
                    () -> new ArcGenSkill(new Skill.Properties(ID, 1).guiPos(24, 46)));

    public static final DeferredHolder<Skill, ChargingSkill> CHARGING =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/charging",
                    () -> new ChargingSkill(new Skill.Properties(ID, 1)
                            .parent(ARC_GEN.getId(), 0.3f)
                            .guiPos(55, 18)));

    public static final DeferredHolder<Skill, BodyIntensifySkill> BODY_INTENSIFY =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/body_intensify",
                    () -> new BodyIntensifySkill(new Skill.Properties(ID, 3)
                            .parent(ARC_GEN.getId(), 1.0f)
                            .dependency(CHARGING.getId(), 1.0f)
                            .guiPos(97, 15)));

    public static final DeferredHolder<Skill, MagMovementSkill> MAG_MOVEMENT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mag_movement",
                    () -> new MagMovementSkill(new Skill.Properties(ID, 2)
                            .parent(ARC_GEN.getId(), 0.0f)
                            .dependency(CHARGING.getId(), 0.7f)
                            .guiPos(137, 35)));

    public static final DeferredHolder<Skill, ThunderBoltSkill> THUNDER_BOLT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/thunder_bolt",
                    () -> new ThunderBoltSkill(new Skill.Properties(ID, 4)
                            .parent(ARC_GEN.getId(), 0.0f)
                            .dependency(CHARGING.getId(), 0.7f)
                            .guiPos(86, 67)));

    public static final DeferredHolder<Skill, MagManipSkill> MAG_MANIP =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mag_manip",
                    () -> new MagManipSkill(new Skill.Properties(ID, 2)
                            .parent(MAG_MOVEMENT.getId(), 0.5f)
                            .guiPos(204, 33)));

    public static final DeferredHolder<Skill, RailgunSkill> RAILGUN =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/railgun",
                    () -> new RailgunSkill(new Skill.Properties(ID, 4)
                            .parent(THUNDER_BOLT.getId(), 0.3f)
                            .dependency(MAG_MANIP.getId(), 1.0f)
                            .guiPos(164, 59)));

    public static final DeferredHolder<Skill, MineDetectSkill> MINE_DETECT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mine_detect",
                    () -> new MineDetectSkill(new Skill.Properties(ID, 3)
                            .parent(MAG_MANIP.getId(), 1.0f)
                            .guiPos(225, 12)));

    public static final DeferredHolder<Skill, ThunderclapSkill> THUNDER_CLAP =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/thunder_clap",
                    () -> new ThunderclapSkill(new Skill.Properties(ID, 5)
                            .parent(THUNDER_BOLT.getId(), 1.0f)
                            .guiPos(204, 80)));

    // Siempre después de las habilidades propias (orden estable del registro); otras categorías hacen lo mismo.
    public static final Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> GENERICS =
            GenericSkill.registerFor(AbilityRegistries.SKILLS, ID);

    private Electromaster() {
    }

    /** Solo fuerza la carga de la clase (y con ella el registro de las entradas de arriba). */
    public static void init() {
    }
}
