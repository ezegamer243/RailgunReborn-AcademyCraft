package com.railgunreborn.ability.electromaster;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.MagMovementRules.HitKind;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Qué cuenta como metálico para las habilidades magnéticas (Magnet Movement y, más adelante, Magnet Manipulation):
 * tags de datos que sustituyen a las listas de {@code academy.cfg} del original (ficha mag-movement 4.3). Un
 * datapack puede ampliarlos sin tocar código.
 */
public final class MagneticTargets {
    public static final TagKey<Block> MAGNETIC_BLOCKS = TagKey.create(Registries.BLOCK,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "magnetic_blocks"));
    /** Bloques "débiles": solo valen con exp suficiente ({@link MagMovementRules#WEAK_BLOCK_MIN_EXP}). */
    public static final TagKey<Block> WEAK_MAGNETIC_BLOCKS = TagKey.create(Registries.BLOCK,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "weak_magnetic_blocks"));
    public static final TagKey<EntityType<?>> MAGNETIC_ENTITIES = TagKey.create(Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "magnetic_entities"));

    /** Caja de las entidades agrandada como en el trazado de Arc Gen. */
    private static final double ENTITY_INFLATE = ArcGenRules.ENTITY_HITBOX_INFLATE;

    private MagneticTargets() {
    }

    public static HitKind classify(BlockState state) {
        if (state.is(MAGNETIC_BLOCKS)) {
            return HitKind.MAGNETIC_BLOCK;
        }
        if (state.is(WEAK_MAGNETIC_BLOCKS)) {
            return HitKind.WEAK_MAGNETIC_BLOCK;
        }
        return HitKind.NON_MAGNETIC;
    }

    public static boolean isMagnetic(Entity entity) {
        return entity.getType().is(MAGNETIC_ENTITIES);
    }

    /** Clasifica el resultado de {@link #trace}. */
    public static HitKind classify(Level level, HitResult hit) {
        if (hit instanceof EntityHitResult entityHit) {
            return isMagnetic(entityHit.getEntity()) ? HitKind.MAGNETIC_ENTITY : HitKind.NON_MAGNETIC;
        }
        if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
            return classify(level.getBlockState(blockHit.getBlockPos()));
        }
        return HitKind.NONE;
    }

    /**
     * Trazado desde los ojos: bloques por su <b>contorno</b> (así cuentan rieles y barrotes, decisión 3), los fluidos no
     * paran el rayo, y cualquier entidad seleccionable (no solo seres vivos: las vagonetas también) salvo el propio
     * jugador y los espectadores, con la caja agrandada. Gana el primer impacto. Nunca null.
     */
    public static HitResult trace(Player player, float range) {
        Level level = player.level();
        Vec3 start = player.getEyePosition();
        Vec3 delta = player.getViewVector(1.0f).scale(range);
        Vec3 end = start.add(delta);

        BlockHitResult blockHit = level.clip(
                new ClipContext(start, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getLocation();
        double bestDist = start.distanceToSqr(limit);

        Entity bestEntity = null;
        Vec3 bestPos = null;
        AABB search = player.getBoundingBox().expandTowards(delta).inflate(1.0 + ENTITY_INFLATE);
        for (Entity entity : level.getEntities(player, search, MagneticTargets::isTraceable)) {
            AABB box = entity.getBoundingBox().inflate(ENTITY_INFLATE);
            if (box.contains(start)) {
                if (bestEntity == null || bestDist > 0) {
                    bestEntity = entity;
                    bestPos = start;
                    bestDist = 0;
                }
                continue;
            }
            var clip = box.clip(start, limit);
            if (clip.isPresent()) {
                double dist = start.distanceToSqr(clip.get());
                if (dist < bestDist || (bestEntity == null && dist <= bestDist)) {
                    bestEntity = entity;
                    bestPos = clip.get();
                    bestDist = dist;
                }
            }
        }
        if (bestEntity != null) {
            return new EntityHitResult(bestEntity, bestPos);
        }
        return blockHit;
    }

    private static boolean isTraceable(Entity entity) {
        return entity.isAlive() && entity.isPickable() && !entity.isSpectator();
    }
}
