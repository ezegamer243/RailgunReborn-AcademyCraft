package com.railgunreborn.ability.electromaster;

import java.util.Objects;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.energy.DirectChargeable;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Current Charging: nivel 1, hija de Arc Gen. Ficha: {@code docs/spec/current-charging.md}; mandan sus
 * "Decisiones del usuario" (carga FE de otros mods ya, exp sin objetivo como el original).
 *
 * <p>Se mantiene la tecla: overload al empezar, CP cada tick, sin cooldown. Modo ítem si alguna mano lleva algo con
 * energía FE (se carga eso); si no, modo bloque (rayo de 15 bloques que carga el bloque con energía al que apunta).
 * Números en {@link ChargingRules}.
 */
public class ChargingSkill extends Skill {
    /**
     * Estado del efecto para los clientes: al empezar, cuando cambia el objetivo y cada {@link #STATE_INTERVAL}
     * ticks (así lo ve también quien entra en rango tarde, y el cliente puede cortar si deja de llegar).
     */
    public static final String STATE_CHANNEL = "state";
    /** Fin del efecto (siempre, termine como termine). */
    public static final String STOP_CHANNEL = "stop";
    public static final String ITEM_MODE_KEY = "item";
    /** Bloque cargable al que apunta (long de {@link BlockPos#asLong()}); ausente = ninguno. */
    public static final String TARGET_KEY = "target";
    public static final int STATE_INTERVAL = 10;

    public ChargingSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ChargingContext(player, this);
    }

    /** Mano con algo que se pueda cargar (primero la principal), o null. */
    @Nullable
    public static InteractionHand findChargeableHand(Player player) {
        for (InteractionHand hand : InteractionHand.values()) {
            if (ChargingRules.isChargeable(itemEnergy(player.getItemInHand(hand)))) {
                return hand;
            }
        }
        return null;
    }

    @Nullable
    private static IEnergyStorage itemEnergy(ItemStack stack) {
        return stack.isEmpty() ? null : stack.getCapability(Capabilities.EnergyStorage.ITEM);
    }

    /** Almacén FE del bloque golpeado, por la cara golpeada; null si no es un bloque o no tiene. */
    @Nullable
    public static IEnergyStorage blockEnergy(Player player, HitResult hit) {
        if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
            return player.level().getCapability(Capabilities.EnergyStorage.BLOCK, blockHit.getBlockPos(),
                    blockHit.getDirection());
        }
        return null;
    }

    private static final class ChargingContext extends SkillContext {
        private final float exp;
        /** Mano que se carga en modo ítem; null = modo bloque. Fijo desde que se pulsa hasta que se suelta. */
        @Nullable
        private InteractionHand hand;
        @Nullable
        private BlockPos target;
        private int ticks;

        ChargingContext(ServerPlayer player, ChargingSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            // Decisión de la ficha ([DUDA] 2): sin CP para un tick no se cobra el overload.
            if (!canConsume(0f, ChargingRules.cpPerTick(exp)) || !consume(ChargingRules.overloadCost(exp), 0f)) {
                terminate();
                return;
            }
            hand = findChargeableHand(getPlayer());
            sendState();
        }

        @Override
        protected void onKeyTick() {
            // Consumir cada tick también reinicia la espera de recuperación del overload: queda "congelado"
            // mientras se mantiene, como en el original. Exp solo si el consumo tuvo éxito ([DUDA] 4).
            if (!consume(0f, ChargingRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            ServerPlayer player = getPlayer();
            int amount = ChargingRules.chargePerTick(exp);
            boolean effective;
            if (hand != null) {
                effective = ChargingRules.charge(itemEnergy(player.getItemInHand(hand)), amount);
            } else {
                HitResult hit = ArcGenSkill.trace(player, ChargingRules.RANGE);
                IEnergyStorage storage = blockEnergy(player, hit);
                DirectChargeable direct = hit instanceof BlockHitResult bh && hit.getType() == HitResult.Type.BLOCK
                        ? DirectChargeable.find(player.level(), bh.getBlockPos()) : null;
                // Bloques del mod: carga directa (sin tope de ancho de banda); el resto, por la capacidad FE.
                effective = direct != null ? ChargingRules.chargeDirect(direct, amount)
                        : ChargingRules.charge(storage, amount);
                BlockPos newTarget = effective ? ((BlockHitResult) hit).getBlockPos() : null;
                if (!Objects.equals(newTarget, target)) {
                    target = newTarget;
                    sendState();
                }
            }
            addSkillExp(ChargingRules.expGain(effective));
            if (++ticks % STATE_INTERVAL == 0) {
                sendState();
            }
        }

        private void sendState() {
            CompoundTag data = new CompoundTag();
            data.putBoolean(ITEM_MODE_KEY, hand != null);
            if (target != null) {
                data.putLong(TARGET_KEY, target.asLong());
            }
            sendEffect(STATE_CHANNEL, data);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            // A todos los cercanos: la mitad cliente de los demás no recibe el TERMINATED del contexto ([DUDA] 5).
            sendEffect(STOP_CHANNEL, new CompoundTag());
        }
    }
}
