package com.railgunreborn.ability.electromaster;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.electromaster.ArcGenRules.BlockAction;
import com.railgunreborn.ability.electromaster.ArcGenRules.HitKind;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.util.BlockSnapshot;
import net.neoforged.neoforge.event.EventHooks;

/**
 * Arc Generation: nivel 1, raíz del árbol de Electromaster. Ficha: {@code docs/spec/arc-gen.md}
 * (incluidas las "Decisiones del usuario", que mandan sobre el original). Números y decisiones puras en
 * {@link ArcGenRules}.
 */
public class ArcGenSkill extends Skill {
    /** Canal de {@code SkillEffects} con el arco; lleva {@link #EFFECT_RANGE_KEY} (float, alcance completo). */
    public static final String EFFECT_CHANNEL = "effect";
    public static final String EFFECT_RANGE_KEY = "range";

    // TODO(config): attackPlayer de la ficha; por ahora siempre se puede (el PvP del servidor se respeta igual).
    private static final boolean ATTACK_PLAYER = true;

    public ArcGenSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ArcGenContext(player, this);
    }

    /**
     * Trazado desde los ojos hacia donde mira, de longitud {@code range}: bloques con colisión y cualquier agua
     * detienen el rayo; entidades vivas (salvo el propio jugador y espectadores) con la caja agrandada
     * {@link ArcGenRules#ENTITY_HITBOX_INFLATE}. Gana lo más cercano. Nunca null: si no toca nada es {@code MISS}.
     * Sirve en ambos lados: Current Charging lo repite en el cliente para dibujar su rayo.
     */
    public static HitResult trace(Player player, float range) {
        return trace(player, range, ClipContext.Fluid.WATER);
    }

    /** Como {@link #trace(Player, float)}, eligiendo qué fluidos detienen el rayo (Thunder Bolt: ninguno). */
    public static HitResult trace(Player player, float range, ClipContext.Fluid fluids) {
        Level level = player.level();
        Vec3 start = player.getEyePosition();
        Vec3 delta = player.getViewVector(1.0f).scale(range);
        Vec3 end = start.add(delta);

        BlockHitResult blockHit = level.clip(
                new ClipContext(start, end, ClipContext.Block.COLLIDER, fluids, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getLocation();
        double bestDist = start.distanceToSqr(limit);

        Entity bestEntity = null;
        Vec3 bestPos = null;
        AABB search = player.getBoundingBox().expandTowards(delta).inflate(1.0 + ArcGenRules.ENTITY_HITBOX_INFLATE);
        for (Entity entity : level.getEntities(player, search, ArcGenSkill::isTargetable)) {
            AABB box = entity.getBoundingBox().inflate(ArcGenRules.ENTITY_HITBOX_INFLATE);
            if (box.contains(start)) {
                // Pegado al objetivo: cuenta como impacto a distancia 0.
                if (bestEntity == null || bestDist > 0) {
                    bestEntity = entity;
                    bestPos = start;
                    bestDist = 0;
                }
                continue;
            }
            var clip = box.clip(start, limit);
            if (clip.isPresent()) {
                double dist = start.distanceToSqr(clip.get());
                if (dist < bestDist || (bestEntity == null && dist <= bestDist)) {
                    bestEntity = entity;
                    bestPos = clip.get();
                    bestDist = dist;
                }
            }
        }
        if (bestEntity != null) {
            return new EntityHitResult(bestEntity, bestPos);
        }
        return blockHit;
    }

    /** Seres vivos a los que apunta un rayo; el área de Thunder Bolt usa el mismo filtro ({@link SkillTargets}). */
    static boolean isTargetable(Entity entity) {
        return SkillTargets.isTargetable(entity);
    }

    /**
     * Si el jugador puede poner fuego en {@code pos}: {@code destroy_blocks} de la habilidad, gamerule
     * {@code mobGriefing} y el permiso de construcción de la casilla ({@link BlockPermissions}). El evento de
     * colocación de NeoForge se lanza aparte, tras colocar (ver {@link ArcGenContext#ignite}).
     */
    public boolean mayIgnite(ServerPlayer player, BlockPos pos) {
        return BlockPermissions.mayModifyWorld(player, this) && BlockPermissions.mayBuildAt(player, pos);
    }

    private static final class ArcGenContext extends SkillContext {
        private final ArcGenSkill arcGen;
        private final float exp;

        ArcGenContext(ServerPlayer player, ArcGenSkill skill) {
            super(player, skill);
            this.arcGen = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            if (consume(ArcGenRules.overloadCost(exp), ArcGenRules.cpCost(exp))) {
                fire();
            }
            terminate();
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            float range = ArcGenRules.range(exp);
            HitResult hit = trace(player, range);

            HitKind kind;
            if (hit instanceof EntityHitResult entityHit) {
                kind = hitEntity(entityHit.getEntity()) ? HitKind.ENTITY : HitKind.PROTECTED_PLAYER;
            } else if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
                kind = HitKind.BLOCK;
                hitBlock(blockHit);
            } else {
                kind = HitKind.MISS;
            }

            float gained = ArcGenRules.expGain(kind, exp);
            if (gained > 0) {
                addSkillExp(gained);
            }
            setCooldown(ArcGenRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            data.putFloat(EFFECT_RANGE_KEY, range);
            sendEffect(EFFECT_CHANNEL, data);
        }

        /** @return false si el objetivo es un jugador que no se puede dañar (PvP apagado). */
        private boolean hitEntity(Entity target) {
            ServerPlayer player = getPlayer();
            boolean damage = !(target instanceof Player other)
                    || ArcGenRules.canDamagePlayer(ATTACK_PLAYER, player.canHarmPlayer(other));
            if (damage) {
                float amount = ArcGenRules.baseDamage(exp) * arcGen.getDamageScale();
                target.hurt(ModDamageTypes.source(player, ModDamageTypes.ARC_GEN), amount);
            }
            // Cargar el creeper tocando solo su dato sincronizado: thunderHit() traería el daño y el fuego del rayo.
            if (target instanceof Creeper creeper && creeper.isAlive() && !creeper.isPowered()
                    && ArcGenRules.shouldChargeCreeper(player.getRandom().nextDouble())) {
                creeper.getEntityData().set(Creeper.DATA_IS_POWERED, true);
            }
            return damage;
        }

        private void hitBlock(BlockHitResult hit) {
            ServerPlayer player = getPlayer();
            ServerLevel level = player.serverLevel();
            BlockPos pos = hit.getBlockPos();
            boolean water = level.getFluidState(pos).is(FluidTags.WATER);
            BlockAction action = ArcGenRules.blockAction(water, exp, player.getRandom().nextDouble());
            switch (action) {
                case DROP_FISH -> {
                    Vec3 at = hit.getLocation();
                    level.addFreshEntity(new ItemEntity(level, at.x, at.y, at.z, new ItemStack(Items.COOKED_COD)));
                }
                case IGNITE -> ignite(level, pos.above());
                case NONE -> {
                }
            }
        }

        private void ignite(ServerLevel level, BlockPos pos) {
            ServerPlayer player = getPlayer();
            if (!level.getBlockState(pos).isAir() || !arcGen.mayIgnite(player, pos)) {
                return;
            }
            // Como al colocar un bloque con NeoForge: foto, colocar, evento; si alguien lo cancela se deshace.
            BlockSnapshot snapshot = BlockSnapshot.create(level.dimension(), level, pos);
            level.setBlock(pos, BaseFireBlock.getState(level, pos), Block.UPDATE_ALL_IMMEDIATE);
            if (EventHooks.onBlockPlace(player, snapshot, Direction.UP)) {
                snapshot.restore();
                return;
            }
            level.gameEvent(player, GameEvent.BLOCK_PLACE, pos);
        }
    }
}
