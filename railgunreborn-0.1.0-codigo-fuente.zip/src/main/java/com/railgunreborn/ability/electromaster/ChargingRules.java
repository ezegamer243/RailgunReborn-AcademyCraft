package com.railgunreborn.ability.electromaster;

import javax.annotation.Nullable;

import com.railgunreborn.energy.DirectChargeable;

import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Números y decisiones de Current Charging ({@code docs/spec/current-charging.md}), sin mundo: se prueban con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class ChargingRules {
    /** Distancia del trazado en modo bloque (fija). */
    public static final float RANGE = 15f;
    /** Exp por tick con algo que cargar (bloque o ítem con energía FE). */
    public static final float EXP_EFFECTIVE = 0.0001f;
    /** Exp por tick sin nada que cargar (decisión del usuario: igual que el original). */
    public static final float EXP_IDLE = 0.00003f;

    private ChargingRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Overload que se cobra una sola vez al empezar. */
    public static float overloadCost(float exp) {
        return lerp(65f, 48f, exp);
    }

    /** CP por tick mientras se mantiene. */
    public static float cpPerTick(float exp) {
        return lerp(3f, 7f, exp);
    }

    /** Energía (FE, 1 IF = 1 FE) que se intenta meter por tick: 15 a 35. */
    public static int chargePerTick(float exp) {
        return (int) Math.floor(lerp(15f, 35f, exp));
    }

    public static float expGain(boolean effective) {
        return effective ? EXP_EFFECTIVE : EXP_IDLE;
    }

    /** Si ese almacén cuenta como "algo que cargar" (como el original: aunque esté lleno). */
    public static boolean isChargeable(@Nullable IEnergyStorage storage) {
        return storage != null && storage.canReceive();
    }

    /**
     * Carga {@code amount} FE en el almacén si se puede. El almacén aplica su propio límite de entrada por tick
     * (en FE no hay forma de saltárselo, a diferencia del modo bloque del original). Lo que no cabe se pierde.
     *
     * @return si el tick fue efectivo (había algo que cargar)
     */
    public static boolean charge(@Nullable IEnergyStorage storage, int amount) {
        return chargeStorage(storage, amount);
    }

    /** Como {@link #charge} pero sin tope de ancho de banda (bloques del mod). Siempre cuenta como efectivo. */
    public static boolean chargeDirect(DirectChargeable target, int amount) {
        if (amount > 0) {
            target.chargeDirect(amount, false);
        }
        return true;
    }

    private static boolean chargeStorage(@Nullable IEnergyStorage storage, int amount) {
        if (!isChargeable(storage)) {
            return false;
        }
        if (amount > 0) {
            storage.receiveEnergy(amount, false);
        }
        return true;
    }
}
