package com.railgunreborn.ability.electromaster;

/**
 * Números y decisiones de Thunder Bolt ({@code docs/spec/thunder-bolt.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar; los {@code roll} son aleatorios uniformes en [0, 1).
 */
public final class ThunderBoltRules {
    /** Alcance del trazado (coincide con la longitud de los patrones del rayo). */
    public static final float RANGE = 20f;
    /** Radio de la esfera del área, medido desde el punto de impacto hasta los pies de cada ser vivo. */
    public static final double AOE_RADIUS = 8.0;

    /** La Lentitud solo aparece con exp estrictamente mayor que esto. */
    public static final float SLOW_MIN_EXP = 0.2f;
    public static final double SLOW_PROB = 0.8;
    /** Lentitud IV. */
    public static final int SLOW_AMPLIFIER = 3;
    public static final int DIRECT_SLOW_TICKS = 40;
    /** Decisión del usuario: el área también ralentiza (lo que pretendía el original). */
    public static final int AOE_SLOW_TICKS = 20;

    public static final float EXP_EFFECTIVE = 0.005f;
    public static final float EXP_EMPTY = 0.003f;

    private ThunderBoltRules() {
    }

    /** CP por disparo; el original lo trunca a entero. */
    public static float cpCost(float exp) {
        return (int) ArcGenRules.lerp(280f, 420f, exp);
    }

    public static float overloadCost(float exp) {
        return ArcGenRules.lerp(50f, 27f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) ArcGenRules.lerp(120f, 50f, exp);
    }

    /** Daño al objetivo apuntado, antes de {@code damage_scale}. */
    public static float directDamage(float exp) {
        return ArcGenRules.lerp(10f, 25f, exp);
    }

    /** Daño plano a cada ser vivo del área, antes de {@code damage_scale}. */
    public static float aoeDamage(float exp) {
        return ArcGenRules.lerp(6f, 15f, exp);
    }

    public static boolean slownessApplies(float exp, double roll) {
        return exp > SLOW_MIN_EXP && roll < SLOW_PROB;
    }

    /**
     * Exp ganada (antes de {@code exp_incr_speed}). Efectivo = se dañó al objetivo directo o a alguien del área; los
     * jugadores protegidos por PvP no cuentan.
     */
    public static float expGain(boolean effective) {
        return effective ? EXP_EFFECTIVE : EXP_EMPTY;
    }

    /** Si un ser vivo con los pies a esa distancia² del punto de impacto entra en el área. */
    public static boolean inAoe(double distanceSqr) {
        return distanceSqr <= AOE_RADIUS * AOE_RADIUS;
    }
}
