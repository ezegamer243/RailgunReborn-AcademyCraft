package com.railgunreborn.ability.electromaster;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.entity.MagneticBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.piston.MovingPistonBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.piston.PistonHeadBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Magnet Manipulation: nivel 2. Mantener agarra un bloque metálico (el de la mano o uno del mundo a la vista) que flota
 * delante del jugador; soltar lo lanza como proyectil ({@link MagneticBlockEntity}). Ficha:
 * {@code docs/spec/mag-manip.md} (mandan las decisiones del final). Números en {@link MagManipRules}; qué es
 * metálico, en {@link MagneticTargets}.
 *
 * <p>Retirar y colocar bloques siguen la política de Arc Gen/Railgun: {@code destroy_blocks}, {@code mobGriefing},
 * permisos de construcción/protección del spawn y los eventos de NeoForge.
 */
public class MagManipSkill extends Skill {
    /** Al lanzar con éxito (para el sonido {@code mag_manip} en los cercanos). */
    public static final String THROW_CHANNEL = "throw";

    // TODO(config): attackPlayer de la ficha, como en Arc Gen.
    public static final boolean ATTACK_PLAYER = true;

    public MagManipSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MagManipContext(player, this);
    }

    // --- Qué se puede agarrar ---

    /** Metálico (normal o débil), sin BlockEntity, ni puerta ni pistón extendido, y rompible (decisión 6). */
    public static boolean isGrabbable(BlockGetter level, BlockPos pos, BlockState state) {
        boolean magnetic = state.is(MagneticTargets.MAGNETIC_BLOCKS) || state.is(MagneticTargets.WEAK_MAGNETIC_BLOCKS);
        Block block = state.getBlock();
        boolean excludedShape = block instanceof DoorBlock || block instanceof PistonHeadBlock
                || block instanceof MovingPistonBlock
                || (block instanceof PistonBaseBlock && state.getValue(PistonBaseBlock.EXTENDED));
        return MagManipRules.isGrabbable(magnetic, state.hasBlockEntity(), excludedShape,
                state.getDestroySpeed(level, pos) < 0);
    }

    /**
     * Primer bloque que corta la mirada en {@link MagManipRules#GRAB_RANGE} (decisión 2: línea de visión). Los metálicos
     * cuentan por su contorno (rieles), el resto por su colisión (la hierba alta no tapa); los fluidos no tapan.
     */
    public static BlockHitResult traceGrab(ServerPlayer player) {
        Level level = player.level();
        Vec3 from = player.getEyePosition();
        Vec3 to = from.add(player.getViewVector(1.0f).scale(MagManipRules.GRAB_RANGE));
        CollisionContext collision = CollisionContext.of(player);
        return BlockGetter.traverseBlocks(from, to, collision, (ctx, pos) -> {
            BlockState state = level.getBlockState(pos);
            boolean magnetic = state.is(MagneticTargets.MAGNETIC_BLOCKS)
                    || state.is(MagneticTargets.WEAK_MAGNETIC_BLOCKS);
            VoxelShape shape = magnetic ? state.getShape(level, pos, ctx) : state.getCollisionShape(level, pos, ctx);
            return level.clipWithInteractionOverride(from, to, pos.immutable(), shape, state);
        }, ctx -> BlockHitResult.miss(to, Direction.getNearest(to.x - from.x, to.y - from.y, to.z - from.z),
                BlockPos.containing(to)));
    }

    // --- Protecciones ---

    /** Si esta habilidad puede tocar bloques en este mundo: {@link BlockPermissions#mayModifyWorld}. */
    public boolean mayModifyWorld(ServerPlayer player) {
        return BlockPermissions.mayModifyWorld(player, this);
    }

    /**
     * Permiso por casilla para colocar: {@link BlockPermissions#mayBuildAt}. El evento de colocación se lanza aparte,
     * al colocar.
     */
    public static boolean mayPlaceAt(ServerPlayer player, BlockPos pos) {
        return BlockPermissions.mayBuildAt(player, pos);
    }

    /** Hacia dónde apunta el jugador para lanzar (ficha 6.1.3, desde los ojos por [DUDA] 13). */
    static Vec3 aimPoint(ServerPlayer player) {
        HitResult hit = ArcGenSkill.trace(player, MagManipRules.AIM_RANGE, ClipContext.Fluid.NONE);
        if (hit instanceof EntityHitResult entityHit) {
            Entity entity = entityHit.getEntity();
            return new Vec3(entity.getX(), entity.getY() + entity.getEyeHeight() * MagManipRules.AIM_EYE_FRACTION,
                    entity.getZ());
        }
        if (hit.getType() == HitResult.Type.BLOCK) {
            return hit.getLocation();
        }
        return player.getEyePosition().add(player.getViewVector(1.0f).scale(MagManipRules.AIM_RANGE));
    }

    private static final class MagManipContext extends SkillContext {
        private final MagManipSkill skill;
        private final float exp;
        @Nullable
        private MagneticBlockEntity block;
        private boolean launched;

        MagManipContext(ServerPlayer player, MagManipSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            block = grabFromHand();
            if (block == null) {
                block = grabFromWorld();
            }
            // Sin bloque válido termina sin coste.
            if (block == null) {
                terminate();
            }
        }

        /** Prioridad: un bloque agarrable en la mano principal (gasta 1, salvo en creativo; sin permisos de mundo). */
        @Nullable
        private MagneticBlockEntity grabFromHand() {
            ServerPlayer player = getPlayer();
            ItemStack stack = player.getItemInHand(InteractionHand.MAIN_HAND);
            if (!(stack.getItem() instanceof BlockItem blockItem)) {
                return null;
            }
            BlockState state = blockItem.getBlock().defaultBlockState();
            if (!isGrabbable(player.level(), player.blockPosition(), state)) {
                return null;
            }
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            return MagneticBlockEntity.spawnHeld(player, state, player.getEyePosition());
        }

        @Nullable
        private MagneticBlockEntity grabFromWorld() {
            ServerPlayer player = getPlayer();
            BlockHitResult hit = traceGrab(player);
            if (hit.getType() != HitResult.Type.BLOCK) {
                return null;
            }
            ServerLevel level = player.serverLevel();
            BlockPos pos = hit.getBlockPos();
            BlockState state = level.getBlockState(pos);
            if (!isGrabbable(level, pos, state) || !skill.mayModifyWorld(player)
                    || !BlockPermissions.mayBreakAt(player, pos, state)) {
                return null;
            }
            // Sin drops ni partículas: el bloque pasa entero a la entidad, con su estado completo ([DUDA] 5).
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            return MagneticBlockEntity.spawnHeld(player, state, Vec3.atCenterOf(pos));
        }

        @Override
        protected void tick() {
            if (block == null || block.isRemoved() || !block.isHeld()) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            release();
            terminate();
        }

        private void release() {
            if (block == null || block.isRemoved() || !block.isHeld()) {
                return;
            }
            ServerPlayer player = getPlayer();
            Vec3 center = block.getCenter();
            double distanceSqr = player.getEyePosition().distanceToSqr(center);
            // El orden importa: lejos no se cobra.
            boolean paid = distanceSqr < MagManipRules.MAX_THROW_DISTANCE_SQR
                    && consume(MagManipRules.overloadCost(exp), MagManipRules.cpCost(exp));
            if (!MagManipRules.canThrow(distanceSqr, paid)) {
                block.drop();
                return;
            }
            Vec3 dir = aimPoint(player).subtract(center);
            if (dir.lengthSqr() < 1e-4) {
                dir = player.getViewVector(1.0f);
            }
            block.launch(dir.normalize().scale(MagManipRules.throwSpeed(exp)),
                    MagManipRules.damage(exp) * skill.getDamageScale());
            launched = true;
            setCooldown(MagManipRules.cooldownTicks(exp));
            addSkillExp(MagManipRules.EXP_GAIN);
            sendEffect(THROW_CHANNEL, new CompoundTag());
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            // Cancelar (V, overload, muerte, desconexión...) sin lanzar: el bloque cae y se coloca donde choque.
            if (block != null && !launched && !block.isRemoved()) {
                block.drop();
            }
        }
    }
}
