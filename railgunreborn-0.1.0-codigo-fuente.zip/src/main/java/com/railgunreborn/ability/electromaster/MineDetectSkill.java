package com.railgunreborn.ability.electromaster;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.AbilityData;

import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Mine Detection: nivel 3. Un clic: Ceguera 5 s y, durante esos 5 s, solo el cliente del jugador ve los minerales
 * cercanos a través de las paredes. Ficha: {@code docs/spec/mine-detect.md} (las decisiones del final mandan).
 * Números en {@link MineDetectRules}.
 *
 * <p>El servidor no busca minerales (como el original): el cliente ya tiene esos bloques y los escanea él mismo
 * ({@code client.electromaster.MineDetectClient}); así no hay que mandar listas de posiciones ni cargar al servidor.
 */
public class MineDetectSkill extends Skill {
    /** Canal de {@code sendToLocal} con {@link #RANGE_KEY} (float, radio del servidor) y {@link #ADVANCED_KEY}. */
    public static final String EFFECT_CHANNEL = "effect";
    public static final String RANGE_KEY = "range";
    public static final String ADVANCED_KEY = "advanced";

    /** Qué cuenta como mineral: por defecto {@code #c:ores} completo (decisión 3); un datapack puede cambiarlo. */
    public static final TagKey<Block> DETECTABLE_ORES = TagKey.create(Registries.BLOCK,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "detectable_ores"));

    public MineDetectSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MineDetectContext(player, this);
    }

    public static boolean isDetectable(BlockState state) {
        return state.is(DETECTABLE_ORES);
    }

    /** Nivel de herramienta para el color del modo avanzado ({@code MineDetectRules.TOOL_*}). */
    public static int toolTier(BlockState state) {
        if (state.is(BlockTags.NEEDS_DIAMOND_TOOL)) {
            return MineDetectRules.TOOL_DIAMOND;
        }
        if (state.is(BlockTags.NEEDS_IRON_TOOL)) {
            return MineDetectRules.TOOL_IRON;
        }
        if (state.is(BlockTags.NEEDS_STONE_TOOL)) {
            return MineDetectRules.TOOL_STONE;
        }
        return MineDetectRules.TOOL_NONE;
    }

    private static final class MineDetectContext extends SkillContext {
        // Rango y modo avanzado se fijan al pulsar; coste y cooldown al ejecutar (ficha, notación).
        private final float range;
        private final boolean advanced;

        MineDetectContext(ServerPlayer player, MineDetectSkill skill) {
            super(player, skill);
            float exp = getSkillExp();
            this.range = MineDetectRules.range(exp);
            this.advanced = MineDetectRules.isAdvanced(exp, AbilityData.get(player).getLevel());
        }

        @Override
        protected void onKeyDown() {
            float exp = getSkillExp();
            if (consume(MineDetectRules.overloadCost(exp), MineDetectRules.cpCost(exp))) {
                activate();
            }
            terminate();
        }

        private void activate() {
            ServerPlayer player = getPlayer();
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, MineDetectRules.EFFECT_TICKS), player);
            addSkillExp(MineDetectRules.EXP_GAIN);

            CompoundTag data = new CompoundTag();
            data.putFloat(RANGE_KEY, range);
            data.putBoolean(ADVANCED_KEY, advanced);
            sendToLocal(EFFECT_CHANNEL, data);

            setCooldown(MineDetectRules.cooldownTicks(getSkillExp()));
        }
    }
}
