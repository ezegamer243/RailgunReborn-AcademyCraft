package com.railgunreborn.ability.electromaster;

import java.util.List;
import java.util.function.DoubleSupplier;

import com.railgunreborn.ability.common.TunnelRules;
import com.railgunreborn.ability.common.TunnelRules.Cell;
import com.railgunreborn.ability.common.TunnelRules.Vec;

/**
 * Números, decisiones y geometría del Railgun ({@code docs/spec/railgun.md}, mandan las "Decisiones para el port"),
 * en Java puro para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al disparar; los
 * {@code roll} son aleatorios uniformes en [0, 1).
 *
 * <p>La geometría del túnel (corregida respecto al original) es común con Meltdowner: {@link TunnelRules}. Aquí
 * quedan los atajos con el radio del Railgun.
 */
public final class RailgunRules {
    /** Radio del disco de líneas (y base del cilindro de daño). */
    public static final double RADIUS = 2.0;
    /** Distancia máxima (al eje) de un ser vivo dañado: {@code radio * 1.2} como el original. */
    public static final double HIT_RADIUS = RADIUS * 1.2;
    /** Alcance del daño a entidades y longitud del rayo visual (decisión: unificados en 50). */
    public static final double RANGE = 50.0;
    /** Pasos de cada línea de bloques (el paso 0, el plano de los ojos, no se rompe: ver {@link #FIRST_STEP}). */
    public static final int MAX_STEPS = 50;
    /** Primer paso que se rompe (ver {@link TunnelRules#FIRST_STEP}). */
    public static final int FIRST_STEP = TunnelRules.FIRST_STEP;
    public static final double GRID_STEP = TunnelRules.GRID_STEP;
    /** Ticks que hay que mantener la tecla con hierro en la mano. */
    public static final int HOLD_TICKS = 20;
    public static final double UNBREAKABLE_HARDNESS = TunnelRules.UNBREAKABLE_HARDNESS;

    /** Contragolpe fijo si un jugador refleja el rayo (Vector Reflection; {@code railgun.md} §13). */
    public static final float REFLECT_DAMAGE = 14f;

    public static final float EXP_HIT = 0.01f;
    public static final float EXP_EMPTY = 0.005f;

    private RailgunRules() {
    }

    public static float cpCost(float exp) {
        return ArcGenRules.lerp(200f, 450f, exp);
    }

    public static float overloadCost(float exp) {
        return ArcGenRules.lerp(180f, 120f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) ArcGenRules.lerp(300f, 160f, exp);
    }

    /** Daño constante a cada ser vivo del cilindro, antes de {@code damage_scale} (sin caída por distancia). */
    public static float damage(float exp) {
        return ArcGenRules.lerp(60f, 110f, exp);
    }

    /** Energía total para romper bloques, repartida entre las líneas. */
    public static float energy(float exp) {
        return ArcGenRules.lerp(900f, 2000f, exp);
    }

    /** 0.01 si dañó al menos a un ser vivo (los jugadores protegidos por PvP no cuentan), 0.005 si no. */
    public static float expGain(boolean hitLiving) {
        return hitLiving ? EXP_HIT : EXP_EMPTY;
    }

    /** Energía de una línea: ver {@link TunnelRules#lineEnergy}. */
    public static double lineEnergy(double total, int lines, double roll) {
        return TunnelRules.lineEnergy(total, lines, roll);
    }

    /** Dureza efectiva: negativa (bedrock, barrera...) = irrompible. */
    public static double effectiveHardness(double hardness) {
        return TunnelRules.effectiveHardness(hardness);
    }

    /** Si un ser vivo a esa distancia a lo largo del eje y a esa distancia del eje entra en el cilindro de daño. */
    public static boolean inBeam(double along, double perpendicular) {
        return TunnelRules.inCylinder(along, perpendicular, RANGE, HIT_RADIUS);
    }

    // --- Geometría con el radio del Railgun ---

    public static Vec[] perpendicularAxes(Vec dir) {
        return TunnelRules.perpendicularAxes(dir);
    }

    /** Puntos de la rejilla del disco de radio {@link #RADIUS} (rejilla ±2): {@link TunnelRules#discPoints}. */
    public static List<Vec> discPoints(Vec origin, Vec dir, DoubleSupplier roll) {
        return TunnelRules.discPoints(origin, dir, RADIUS, roll);
    }

    /** Casillas de inicio de las líneas, sin duplicados (en el orden en que aparecen). */
    public static List<Cell> lineStarts(Vec origin, Vec dir, DoubleSupplier roll) {
        return TunnelRules.lineStarts(origin, dir, RADIUS, roll);
    }

    public static List<Cell> line(Cell start, Vec dir, int maxSteps) {
        return TunnelRules.line(start, dir, maxSteps);
    }

    public static double[] axisDistances(Vec origin, Vec dir, Vec point) {
        return TunnelRules.axisDistances(origin, dir, point);
    }
}
