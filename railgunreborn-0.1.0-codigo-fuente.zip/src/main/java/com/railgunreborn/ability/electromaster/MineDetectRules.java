package com.railgunreborn.ability.electromaster;

/**
 * Números y decisiones de Mine Detection ({@code docs/spec/mine-detect.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1].
 */
public final class MineDetectRules {
    /** Ceguera y visión duran lo mismo. */
    public static final int EFFECT_TICKS = 100;
    public static final float EXP_GAIN = 0.008f;
    /** Tope de rendimiento del cliente del original (la ficha lo mantiene). */
    public static final float MAX_CLIENT_RANGE = 28f;
    /** El modo avanzado exige exp estrictamente mayor que esto... */
    public static final float ADVANCED_MIN_EXP = 0.5f;
    /** ...y al menos este nivel de jugador. */
    public static final int ADVANCED_MIN_LEVEL = 4;
    /** Como el original, un máximo de cubos por escaneo; si sobran se quedan los más cercanos. */
    public static final int MAX_RESULTS = 8400;
    /** El cliente repite el escaneo cada tantos ticks mientras dure la visión. */
    public static final int RESCAN_INTERVAL = 5;
    /** Decisión 1: los lejanos se ven tenues pero visibles (el original daba la vuelta al alfa negativo). */
    public static final float MIN_ALPHA = 0.15f;

    /** Nivel de herramienta que pide un bloque (tags vanilla {@code needs_*_tool}). */
    public static final int TOOL_NONE = 0;
    public static final int TOOL_STONE = 1;
    public static final int TOOL_IRON = 2;
    public static final int TOOL_DIAMOND = 3;

    /**
     * Paleta RGB: 0 = modo normal; en modo avanzado 1-4 = sin nivel, piedra, hierro, diamante (decisión 2: el naranja
     * del escombro antiguo, inalcanzable en el original).
     */
    private static final int[] COLORS = {
            0x73C8E3, // azul claro
            0xA1B5BC, // gris azulado
            0x57E7F8, // cian
            0x61CC5E, // verde
            0xEB6D54, // naranja
    };

    private MineDetectRules() {
    }

    public static float cpCost(float exp) {
        return ArcGenRules.lerp(1500f, 1000f, exp);
    }

    public static float overloadCost(float exp) {
        return ArcGenRules.lerp(200f, 180f, exp);
    }

    /** Con la exp ya sumada la de esta activación (el original suma primero y lee después). */
    public static int cooldownTicks(float expAfterGain) {
        return (int) ArcGenRules.lerp(900f, 400f, expAfterGain);
    }

    /** Radio que calcula el servidor al pulsar. */
    public static float range(float exp) {
        return ArcGenRules.lerp(15f, 30f, exp);
    }

    /** Radio que usa el cliente (recortado a {@link #MAX_CLIENT_RANGE}; también descarta valores absurdos). */
    public static float clientRange(float range) {
        return Math.max(0f, Math.min(range, MAX_CLIENT_RANGE));
    }

    public static boolean isAdvanced(float exp, int playerLevel) {
        return exp > ADVANCED_MIN_EXP && playerLevel >= ADVANCED_MIN_LEVEL;
    }

    /** Índice de la paleta: en modo normal siempre 0; en avanzado según el nivel de herramienta (0-3). */
    public static int colorIndex(boolean advanced, int toolTier) {
        if (!advanced) {
            return 0;
        }
        return 1 + Math.max(TOOL_NONE, Math.min(TOOL_DIAMOND, toolTier));
    }

    /** Color RGB (0xRRGGBB) del índice de {@link #colorIndex}. */
    public static int color(int index) {
        return COLORS[Math.max(0, Math.min(COLORS.length - 1, index))];
    }

    /**
     * Alfa (0-1) de un cubo a distancia {@code distance} del jugador: la fórmula del original
     * {@code 0.3 + (1 - 2.2 d / range) × 0.7}, pero acotada a [{@link #MIN_ALPHA}, 1].
     */
    public static float alpha(double distance, float range) {
        if (range <= 0f) {
            return 1f;
        }
        float a = 0.3f + (1f - 2.2f * (float) distance / range) * 0.7f;
        return Math.max(MIN_ALPHA, Math.min(1f, a));
    }
}
