package com.railgunreborn.ability.electromaster;

import net.minecraft.world.phys.Vec3;

/**
 * Números y decisiones de Magnet Movement ({@code docs/spec/mag-movement.md}), sin mundo: se prueban con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class MagMovementRules {
    /** Alcance del trazado al pulsar (fijo, no depende de exp ni nivel). */
    public static final float RANGE = 25f;
    /** Exp a partir de la cual valen los bloques "débiles" (decisión 2 de la ficha). */
    public static final float WEAK_BLOCK_MIN_EXP = 0.6f;
    /** Velocidad objetivo, en bloques/tick. */
    public static final double SPEED = 1.0;
    /** Cambio máximo de velocidad por tick, por eje (no del módulo). */
    public static final double ACCEL = 0.08;
    /** Diferencia de módulos² a partir de la cual la velocidad interna se cambia por la real (tras chocar). */
    public static final double RESYNC_THRESHOLD = 0.5;
    /** Más cerca que esto del destino no hay dirección: se pide velocidad 0 (evita el NaN del original). */
    public static final double MIN_DISTANCE = 0.05;
    public static final float MIN_EXP_GAIN = 0.005f;
    public static final float EXP_PER_BLOCK = 0.0011f;

    /** Qué hay delante al pulsar, tal como lo ve el trazado (primer impacto). */
    public enum HitKind {
        NONE,
        NON_MAGNETIC,
        MAGNETIC_BLOCK,
        WEAK_MAGNETIC_BLOCK,
        MAGNETIC_ENTITY
    }

    private MagMovementRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Overload que se cobra una sola vez al empezar (solo si hay objetivo). */
    public static float overloadCost(float exp) {
        return lerp(60f, 30f, exp);
    }

    /** CP por tick mientras se mantiene. */
    public static float cpPerTick(float exp) {
        return lerp(15f, 8f, exp);
    }

    /** Si el primer impacto sirve de objetivo. Sin objetivo no se cobra nada ni se da exp (decisión 1). */
    public static boolean isValidTarget(HitKind kind, float exp) {
        return switch (kind) {
            case MAGNETIC_BLOCK, MAGNETIC_ENTITY -> true;
            case WEAK_MAGNETIC_BLOCK -> exp >= WEAK_BLOCK_MIN_EXP;
            case NONE, NON_MAGNETIC -> false;
        };
    }

    /** Exp al terminar un arrastre; {@code distance} = en línea recta del inicio al final (pies). */
    public static float expGain(double distance) {
        return Math.max(MIN_EXP_GAIN, (float) (EXP_PER_BLOCK * distance));
    }

    /** Velocidad deseada: hacia el destino a {@link #SPEED}, sin frenar al acercarse. */
    public static Vec3 desiredVelocity(Vec3 from, Vec3 to) {
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < MIN_DISTANCE) {
            return Vec3.ZERO;
        }
        return delta.scale(SPEED / length);
    }

    /** Acerca cada componente de {@code current} a la de {@code desired} como mucho {@code accel}. */
    public static Vec3 nextVelocity(Vec3 current, Vec3 desired, double accel) {
        return new Vec3(approach(current.x, desired.x, accel), approach(current.y, desired.y, accel),
                approach(current.z, desired.z, accel));
    }

    static double approach(double from, double to, double step) {
        if (from < to) {
            return Math.min(to, from + step);
        }
        return Math.max(to, from - step);
    }

    /** Si la velocidad real (tras colisiones, golpes...) se separa tanto que hay que tomarla como interna. */
    public static boolean shouldResync(Vec3 internal, Vec3 actual) {
        return Math.abs(internal.lengthSqr() - actual.lengthSqr()) > RESYNC_THRESHOLD;
    }

    /** Un tick de movimiento completo: resincroniza si hace falta y acelera hacia el destino. */
    public static Vec3 step(Vec3 internal, Vec3 actual, Vec3 position, Vec3 destination) {
        Vec3 base = shouldResync(internal, actual) ? actual : internal;
        return nextVelocity(base, desiredVelocity(position, destination), ACCEL);
    }
}
