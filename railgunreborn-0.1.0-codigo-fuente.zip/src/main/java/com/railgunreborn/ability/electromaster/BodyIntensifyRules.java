package com.railgunreborn.ability.electromaster;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.util.RandomSource;

/**
 * Numeros y decisiones de Body Intensify ({@code docs/spec/body-intensify.md}), sin mundo: se prueban con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1]; {@code ticks} son los ticks mantenidos (se limitan a
 * {@link #MAX_CHARGE_TICKS} en los calculos).
 */
public final class BodyIntensifyRules {
    /** Minimo para que soltar de efecto (y cooldown/exp/hambre). */
    public static final int MIN_TICKS = 10;
    /** Desde aqui el efecto es garantizado y de nivel II (P = 1). */
    public static final int STRONG_TICKS = MIN_TICKS + 18;
    /** Hasta aqui se paga CP y mejora el resultado. */
    public static final int MAX_CHARGE_TICKS = 40;
    /** Mantener hasta aqui cancela sola sin dar nada. */
    public static final int TIMEOUT_TICKS = 100;
    public static final float EXP_GAIN = 0.01f;
    public static final int HUNGER_AMPLIFIER = 2;

    /** Efectos posibles, con su amplificador maximo. Decision del usuario: al azar entre los 5, sin repetir. */
    public enum Buff {
        SPEED(3), STRENGTH(1), JUMP(1), RESISTANCE(1), REGENERATION(1);

        private final int maxAmplifier;

        Buff(int maxAmplifier) {
            this.maxAmplifier = maxAmplifier;
        }

        public int maxAmplifier() {
            return maxAmplifier;
        }
    }

    private BodyIntensifyRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static int chargeTicks(int ticks) {
        return Math.clamp(ticks, 0, MAX_CHARGE_TICKS);
    }

    /** Overload que se cobra una sola vez al pulsar. */
    public static float overloadCost(float exp) {
        return lerp(200f, 120f, exp);
    }

    /** CP por tick durante los primeros {@link #MAX_CHARGE_TICKS}. */
    public static float cpPerTick(float exp) {
        return lerp(20f, 15f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(900f, 600f, exp);
    }

    /** Probabilidad base de la ficha: 0 en 10 ticks, 1 en 28, 1.667 en 40. */
    public static float probability(int ticks) {
        return (chargeTicks(ticks) - MIN_TICKS) / (float) (STRONG_TICKS - MIN_TICKS);
    }

    /** Amplificador comun: floor(P) (0 hasta 27 ticks, 1 desde 28), recortado al tope de cada efecto. */
    public static int amplifier(int ticks, Buff buff) {
        return Math.min((int) Math.floor(probability(ticks)), buff.maxAmplifier());
    }

    /** Duracion comun de los efectos; {@code r} uniforme en [1, 2). */
    public static int buffTicks(int ticks, float exp, float r) {
        return (int) (r * chargeTicks(ticks) * lerp(1.5f, 2.5f, exp));
    }

    /** Duracion del Hambre III. */
    public static int hungerTicks(int ticks) {
        return (int) (1.25f * chargeTicks(ticks));
    }

    /**
     * Efectos concedidos: bucle con {@code p = P}; en cada vuelta, con probabilidad {@code p}, se anade un efecto
     * distinto de los ya elegidos (al azar entre los 5) y {@code p -= 1}, mientras {@code p > 0}.
     */
    public static List<Buff> chooseBuffs(int ticks, RandomSource random) {
        List<Buff> remaining = new ArrayList<>(List.of(Buff.values()));
        List<Buff> chosen = new ArrayList<>();
        float p = probability(ticks);
        while (p > 0f && !remaining.isEmpty()) {
            if (random.nextFloat() < p) {
                chosen.add(remaining.remove(random.nextInt(remaining.size())));
            }
            p -= 1f;
        }
        return chosen;
    }
}
