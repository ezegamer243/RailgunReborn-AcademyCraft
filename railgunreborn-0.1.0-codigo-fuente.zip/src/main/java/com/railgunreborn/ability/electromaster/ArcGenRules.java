package com.railgunreborn.ability.electromaster;

/**
 * Números y decisiones de Arc Gen ({@code docs/spec/arc-gen.md}), en Java puro: sin mundo ni Minecraft, para poder
 * probarlos directamente (T15). {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar; los {@code roll} son
 * números aleatorios uniformes en [0, 1).
 */
public final class ArcGenRules {
    /** Lo que golpeó el rayo. */
    public enum HitKind {
        ENTITY,
        BLOCK,
        /** No golpeó nada en todo el alcance (disparo al aire). */
        MISS,
        /** Golpeó a un jugador protegido (PvP apagado): decisión del usuario, sin exp para no farmear. */
        PROTECTED_PLAYER
    }

    /** Qué hacer con un impacto en bloque. */
    public enum BlockAction {
        NONE,
        DROP_FISH,
        IGNITE
    }

    public static final double CREEPER_CHARGE_PROB = 0.3;
    public static final double FISH_PROB = 0.1;
    public static final float FISH_MIN_EXP = 0.5f;
    /** Cuánto se agranda (por cada lado) la caja de las entidades al apuntar. */
    public static final double ENTITY_HITBOX_INFLATE = 0.3;

    private ArcGenRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static float cpCost(float exp) {
        return lerp(30f, 70f, exp);
    }

    public static float overloadCost(float exp) {
        return lerp(18f, 11f, exp);
    }

    public static float range(float exp) {
        return lerp(6f, 15f, exp);
    }

    /** Daño base, antes de {@code damage_scale}. */
    public static float baseDamage(float exp) {
        return lerp(5f, 9f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(15f, 5f, exp);
    }

    public static double igniteProb(float exp) {
        return lerp(0f, 0.6f, exp);
    }

    /** 10 % solo con exp &gt; 0.5; si no, nunca. */
    public static double fishProb(float exp) {
        return exp > FISH_MIN_EXP ? FISH_PROB : 0.0;
    }

    /** Exp ganada (antes de {@code exp_incr_speed}). Al aire no se gana nada (decisión del usuario). */
    public static float expGain(HitKind kind, float exp) {
        return switch (kind) {
            case ENTITY -> lerp(0.0048f, 0.0072f, exp);
            case BLOCK -> lerp(0.0018f, 0.0027f, exp);
            case MISS, PROTECTED_PLAYER -> 0f;
        };
    }

    /**
     * Qué hace un impacto en bloque. Agua (quieta o corriente): solo puede soltar pescado, nunca fuego. Otro bloque:
     * puede prender fuego encima (si luego hay aire y el jugador puede modificar ese sitio: eso lo mira el servidor).
     */
    public static BlockAction blockAction(boolean water, float exp, double roll) {
        if (water) {
            return roll < fishProb(exp) ? BlockAction.DROP_FISH : BlockAction.NONE;
        }
        return roll < igniteProb(exp) ? BlockAction.IGNITE : BlockAction.NONE;
    }

    public static boolean shouldChargeCreeper(double roll) {
        return roll < CREEPER_CHARGE_PROB;
    }

    /**
     * Si se daña a un jugador: requiere que la habilidad pueda atacar jugadores ({@code attackPlayer}) y que el
     * servidor lo permita (PvP/equipos, {@code Player#canHarmPlayer}).
     */
    public static boolean canDamagePlayer(boolean attackPlayerOption, boolean serverAllowsHarm) {
        return attackPlayerOption && serverAllowsHarm;
    }
}
