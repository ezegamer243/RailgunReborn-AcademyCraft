package com.railgunreborn.ability.electromaster;

import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BeamReflect;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.common.TunnelBreaker;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.entity.CoinThrowEvent;
import com.railgunreborn.network.SkillEffectPayload;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Railgun: nivel 4. Ficha: {@code docs/spec/railgun.md} (mandan las "Decisiones para el port"). Números y geometría
 * en {@link RailgunRules}.
 *
 * <p>Dos formas de disparar con la tecla de la ranura: (1) con una moneda propia en el aire, un solo intento por
 * moneda validado en el servidor con la ventana del QTE más {@link CoinEntity#QTE_TOLERANCE_TICKS} de tolerancia; (2)
 * sin moneda, con un lingote o bloque de hierro (tag {@link #CATALYSTS}) en la mano principal, manteniendo
 * {@link RailgunRules#HOLD_TICKS} ticks. En ambos casos el CP se comprueba antes de gastar la moneda o el hierro.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public class RailgunSkill extends Skill {
    /** Canal del disparo: {@link #ORIGIN_KEY} y {@link #DIR_KEY} (3 doubles cada uno) y {@link #LENGTH_KEY}. */
    public static final String PERFORM_CHANNEL = "perform";
    /** Chispas en la mano al lanzar la moneda (contexto 0: lo manda el evento de lanzamiento, no un contexto). */
    public static final String CHARGE_CHANNEL = "charge";
    public static final String ORIGIN_KEY = "origin";
    public static final String DIR_KEY = "dir";
    public static final String LENGTH_KEY = "length";
    /** Radio del aviso de chispas al lanzar la moneda (el original: 30 bloques). */
    public static final double CHARGE_EFFECT_RANGE = 30.0;

    /** Lingote y bloque de hierro (datos: {@code data/railgunreborn/tags/item/railgun_catalysts.json}). */
    public static final TagKey<Item> CATALYSTS = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "railgun_catalysts"));

    // TODO(config): attackPlayer de la ficha, como en Arc Gen.
    private static final boolean ATTACK_PLAYER = true;

    public RailgunSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new RailgunContext(player, this);
    }

    public static boolean isCatalyst(ItemStack stack) {
        return !stack.isEmpty() && stack.is(CATALYSTS);
    }

    /**
     * Si el jugador puede disparar sin moneda, con hierro en la mano. Decisión del usuario (2026-10-08): apagado
     * por ahora; lo desbloqueará un bauble futuro. Mientras tanto solo lo activa la etiqueta de jugador
     * {@link #IRON_MODE_TAG} ({@code /tag @s add railgunreborn.iron_mode}), que usan los GameTests. Cuando exista
     * el bauble, este método debe consultarlo.
     */
    public static boolean ironModeUnlocked(Player player) {
        return player.getTags().contains(IRON_MODE_TAG);
    }

    public static final String IRON_MODE_TAG = "railgunreborn.iron_mode";

    public static boolean canUseIronMode(Player player) {
        return ironModeUnlocked(player) && isCatalyst(player.getMainHandItem());
    }

    // --- Daño ---

    /**
     * Seres vivos del cilindro (radio {@link RailgunRules#HIT_RADIUS} alrededor del eje que sale de los ojos, hasta
     * {@link RailgunRules#RANGE}), medidos por el centro de su caja, de cerca a lejos. Atraviesa bloques.
     */
    public static List<LivingEntity> beamTargets(Player player, Vec3 origin, Vec3 dir) {
        return SkillTargets.inCylinder(player, origin, dir, RailgunRules.RANGE, RailgunRules.HIT_RADIUS);
    }

    // --- Bloques (política y túnel comunes: BlockPermissions, TunnelBreaker) ---

    /**
     * Si se puede abrir túnel en este mundo y con esta habilidad (sin mirar el bloque): {@code destroy_blocks} y
     * gamerule {@code mobGriefing}. Si es false el rayo daña igual pero no toca bloques.
     */
    public boolean mayBreakBlocks(ServerPlayer player) {
        return BlockPermissions.mayModifyWorld(player, this);
    }

    /** Permiso por bloque: {@link BlockPermissions#mayBreakAt}. */
    public static boolean mayBreakAt(ServerPlayer player, BlockPos pos, BlockState state) {
        return BlockPermissions.mayBreakAt(player, pos, state);
    }

    /**
     * Abre el túnel de radio {@link RailgunRules#RADIUS} con {@code totalEnergy} repartida entre las líneas
     * ({@link TunnelBreaker}).
     *
     * @return bloques rotos
     */
    public int breakTunnel(ServerPlayer player, Vec3 origin, Vec3 dir, double totalEnergy, int maxSteps) {
        return TunnelBreaker.breakTunnel(player, this, origin, dir,
                new TunnelBreaker.Spec(RailgunRules.RADIUS, totalEnergy, maxSteps));
    }

    // --- Lanzamiento de la moneda: chispas en la mano ---

    @SubscribeEvent
    public static void onCoinThrow(CoinThrowEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        RailgunSkill skill = Electromaster.RAILGUN.get();
        if (!CPData.get(player).canUseAbility() || !hasInActivePreset(player, skill)) {
            return;
        }
        PacketDistributor.sendToPlayersNear(player.serverLevel(), null, player.getX(), player.getY(), player.getZ(),
                CHARGE_EFFECT_RANGE, new SkillEffectPayload(player.getId(), skill, 0, CHARGE_CHANNEL,
                        new CompoundTag()));
    }

    private static boolean hasInActivePreset(Player player, Skill skill) {
        PresetData presets = PresetData.get(player);
        for (int slot = 0; slot < PresetData.MAX_SLOTS; slot++) {
            if (skill.getId().equals(presets.getSlot(presets.getActive(), slot))) {
                return true;
            }
        }
        return false;
    }

    // --- Contexto ---

    private static final class RailgunContext extends SkillContext {
        private final RailgunSkill skill;
        private final float exp;
        /** -1 = no se está cargando con hierro. */
        private int holdTicks = -1;

        RailgunContext(ServerPlayer player, RailgunSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            ServerPlayer player = getPlayer();
            CoinEntity coin = CoinEntity.findActive(player);
            if (coin != null) {
                // Un solo intento por moneda: pulsar fuera de la ventana lo gasta sin coste.
                if (!coin.isAttemptSpent()) {
                    coin.spendAttempt();
                    if (coin.isInQteWindow(CoinEntity.QTE_TOLERANCE_TICKS) && canPay()) {
                        coin.consume();
                        fire();
                    }
                }
                terminate();
                return;
            }
            if (canUseIronMode(player)) {
                holdTicks = 0; // las chispas de la mano las pone el cliente local (ficha 9.3: solo él las ve)
                return;
            }
            terminate();
        }

        @Override
        protected void onKeyTick() {
            if (holdTicks < 0) {
                return;
            }
            ServerPlayer player = getPlayer();
            // Lanzar una moneda mientras se carga cancela la carga con hierro (ficha 1.2).
            if (!canUseIronMode(player) || CoinEntity.findActive(player) != null) {
                terminate();
                return;
            }
            if (++holdTicks >= RailgunRules.HOLD_TICKS) {
                if (canPay()) {
                    if (!player.getAbilities().instabuild) {
                        player.getItemInHand(InteractionHand.MAIN_HAND).shrink(1);
                    }
                    fire();
                }
                terminate();
            }
        }

        /** CP y overload primero (decisión 5): sin CP no se gasta ni la moneda ni el hierro. */
        private boolean canPay() {
            return canConsume(RailgunRules.overloadCost(exp), RailgunRules.cpCost(exp));
        }

        private void fire() {
            if (!consume(RailgunRules.overloadCost(exp), RailgunRules.cpCost(exp))) {
                return;
            }
            ServerPlayer player = getPlayer();
            Vec3 origin = player.getEyePosition();
            Vec3 dir = player.getViewVector(1.0f);

            boolean hitLiving = false;
            float baseDamage = RailgunRules.damage(exp);
            float damage = baseDamage * skill.getDamageScale();
            double length = RailgunRules.RANGE;
            int maxSteps = RailgunRules.MAX_STEPS;
            for (LivingEntity victim : beamTargets(player, origin, dir)) {
                if (victim instanceof Player other
                        && !ArcGenRules.canDamagePlayer(ATTACK_PLAYER, player.canHarmPlayer(other))) {
                    continue;
                }
                if (BeamReflect.reflects(player, skill, victim, origin, dir, baseDamage,
                        RailgunRules.REFLECT_DAMAGE)) {
                    // El rayo se detiene en el reflector: ni más daño ni bloques más allá.
                    length = BeamReflect.cutLength(origin, dir, victim);
                    maxSteps = Math.min(RailgunRules.MAX_STEPS, (int) Math.ceil(length));
                    break;
                }
                victim.hurt(ModDamageTypes.source(player, ModDamageTypes.RAILGUN), damage);
                hitLiving = true;
            }

            skill.breakTunnel(player, origin, dir, RailgunRules.energy(exp), maxSteps);

            addSkillExp(RailgunRules.expGain(hitLiving));
            setCooldown(RailgunRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            data.put(ORIGIN_KEY, vecTag(origin));
            data.put(DIR_KEY, vecTag(dir));
            data.putFloat(LENGTH_KEY, (float) length);
            sendEffect(PERFORM_CHANNEL, data);
        }

        private static CompoundTag vecTag(Vec3 v) {
            CompoundTag tag = new CompoundTag();
            tag.putDouble("x", v.x);
            tag.putDouble("y", v.y);
            tag.putDouble("z", v.z);
            return tag;
        }
    }

    /** Lee un vector de {@link #ORIGIN_KEY}/{@link #DIR_KEY}; null si falta. */
    @Nullable
    public static Vec3 readVec(CompoundTag data, String key) {
        if (!data.contains(key)) {
            return null;
        }
        CompoundTag tag = data.getCompound(key);
        return new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"));
    }
}
