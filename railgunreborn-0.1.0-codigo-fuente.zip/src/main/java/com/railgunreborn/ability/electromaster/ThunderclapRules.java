package com.railgunreborn.ability.electromaster;

/**
 * Números y decisiones de Thunderclap ({@code docs/spec/thunderclap.md}, mandan las decisiones del final), en Java puro
 * para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar; {@code ticks} son los
 * ticks de carga contados en el servidor.
 */
public final class ThunderclapRules {
    /** Desde aquí soltar dispara (decisión del usuario); antes cancela. */
    public static final int MIN_TICKS = 40;
    /** Al llegar aquí dispara solo. */
    public static final int MAX_TICKS = 60;
    /** El CP solo se paga durante los primeros {@code MIN_TICKS} ticks. */
    public static final int PAID_TICKS = MIN_TICKS;
    public static final double TRACE_RANGE = 40.0;
    public static final float EXP_GAIN = 0.003f;
    /** Factor mínimo de velocidad del que carga (1 %). */
    public static final double MIN_SPEED_FACTOR = 0.01;

    // Marca del suelo (ficha 9.2), en segundos.
    public static final double RIPPLE_CYCLE = 3.6;
    public static final double RIPPLE_FADE = 1.6;
    public static final double[] RIPPLE_OFFSETS = {0.0, -1.2, -2.4};

    private ThunderclapRules() {
    }

    public static float overloadCost(float exp) {
        return ArcGenRules.lerp(390f, 252f, exp);
    }

    public static float cpPerTick(float exp) {
        return ArcGenRules.lerp(18f, 25f, exp);
    }

    /** Si en este tick de carga (1, 2, ...) se paga CP. */
    public static boolean paysCp(int ticks) {
        return ticks <= PAID_TICKS;
    }

    /** Multiplicador por carga: {@code lerp(1.0, 1.2, (ticks - 40) / 60)}; a 60 ticks da 1.0667 (el 1.2 es inalcanzable). */
    public static float chargeMultiplier(int ticks) {
        return ArcGenRules.lerp(1.0f, 1.2f, (ticks - MIN_TICKS) / 60f);
    }

    /** Daño en el centro, antes de {@code damage_scale}. */
    public static float centerDamage(float exp, int ticks) {
        return ArcGenRules.lerp(36f, 72f, exp) * chargeMultiplier(ticks);
    }

    public static double radius(float exp) {
        return ArcGenRules.lerp(15f, 30f, exp);
    }

    /** Caída lineal: 1 en el centro, 0 en el borde del radio y fuera. */
    public static float falloff(double distance, double radius) {
        if (radius <= 0) {
            return 0f;
        }
        double ratio = Math.clamp(distance / radius, 0.0, 1.0);
        return (float) (1.0 - ratio);
    }

    public static float damageAt(float exp, int ticks, double distance) {
        return centerDamage(exp, ticks) * falloff(distance, radius(exp));
    }

    public static int cooldownTicks(float exp, int ticks) {
        return (int) (ticks * ArcGenRules.lerp(10f, 6f, exp));
    }

    /** Si soltar con estos ticks dispara (si no, cancela sin efecto). */
    public static boolean releaseFires(int ticks) {
        return ticks >= MIN_TICKS;
    }

    /** Factor de velocidad del que carga: de 1 a 0.01 en 60 ticks (ficha 9.3, impuesto en el servidor). */
    public static double speedFactor(int ticks) {
        return Math.max(MIN_SPEED_FACTOR, 1.0 - (1.0 - MIN_SPEED_FACTOR) * ticks / MAX_TICKS);
    }

    /** Cantidad del modificador {@code ADD_MULTIPLIED_TOTAL}: {@code factor - 1}. */
    public static double speedModifierAmount(int ticks) {
        return speedFactor(ticks) - 1.0;
    }

    /** Momento del ciclo (0..3.6 s) del anillo {@code ring} a los {@code seconds} desde que empezó la carga. */
    public static double ripplePhase(double seconds, int ring) {
        double mod = (seconds - RIPPLE_OFFSETS[ring]) % RIPPLE_CYCLE;
        return mod < 0 ? mod + RIPPLE_CYCLE : mod;
    }

    /** Lado del anillo en bloques: se contrae de 1.9 a 1.4 a lo largo del ciclo. */
    public static double rippleSize(double phase) {
        return 1.9 + (1.4 - 1.9) * phase / RIPPLE_CYCLE;
    }

    /** Altura sobre el punto: sube 0.3 bloques por segundo. */
    public static double rippleHeight(double phase) {
        return 0.3 * phase;
    }

    /** Alfa relativo (0..1): entra durante 1.6 s, se mantiene y sale durante los últimos 1.6 s. */
    public static double rippleAlpha(double phase) {
        if (phase < RIPPLE_FADE) {
            return phase / RIPPLE_FADE;
        }
        if (phase > RIPPLE_CYCLE - RIPPLE_FADE) {
            return Math.max(0.0, (RIPPLE_CYCLE - phase) / RIPPLE_FADE);
        }
        return 1.0;
    }
}
