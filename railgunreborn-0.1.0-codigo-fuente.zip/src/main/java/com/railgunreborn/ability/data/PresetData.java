package com.railgunreborn.ability.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Presets de teclas del modo habilidad ({@code datapart/PresetData} del original): {@value #MAX_PRESETS} presets
 * con {@value #MAX_SLOTS} ranuras cada uno; cada ranura guarda el id de una habilidad o está vacía.
 *
 * <p>Mismo patrón que {@link AbilityData}/{@link CPData}: clase mutable, Codec tolerante y {@link #markDirty()}
 * como aviso para {@code network.DataSync}. El servidor es la autoridad; el cliente solo lee la copia sincronizada.
 */
public final class PresetData {
    public static final int MAX_PRESETS = 4;
    public static final int MAX_SLOTS = 4;

    // Las ranuras vacías se guardan como "" para poder usar listas sin huecos; al cargar se corrige lo raro.
    public static final Codec<PresetData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.INT.optionalFieldOf("active", 0).forGetter(d -> d.active),
            Codec.STRING.listOf().listOf().optionalFieldOf("slots", List.of()).forGetter(PresetData::encodeSlots)
    ).apply(inst, PresetData::fromSaved));

    private int active;
    private final ResourceLocation[][] slots = new ResourceLocation[MAX_PRESETS][MAX_SLOTS];
    private boolean dirty;

    public PresetData() {
    }

    private static PresetData fromSaved(int active, List<List<String>> saved) {
        PresetData data = new PresetData();
        data.active = Math.clamp(active, 0, MAX_PRESETS - 1);
        for (int p = 0; p < Math.min(MAX_PRESETS, saved.size()); p++) {
            List<String> row = saved.get(p);
            for (int s = 0; s < Math.min(MAX_SLOTS, row.size()); s++) {
                data.slots[p][s] = row.get(s).isEmpty() ? null : ResourceLocation.tryParse(row.get(s));
            }
        }
        return data;
    }

    private List<List<String>> encodeSlots() {
        List<List<String>> out = new ArrayList<>();
        for (ResourceLocation[] row : slots) {
            List<String> encoded = new ArrayList<>();
            for (ResourceLocation id : row) {
                encoded.add(id == null ? "" : id.toString());
            }
            out.add(encoded);
        }
        return out;
    }

    /** En servidor aplica antes el vaciado pendiente por cambio de categoría (ver {@link AbilityData}). */
    public static PresetData get(Player player) {
        PresetData data = player.getData(ModAttachments.PRESET_DATA);
        // En cliente la copia llega ya corregida del servidor.
        if (!player.level().isClientSide() && AbilityData.get(player).consumePresetsClearPending()) {
            data.clearAll();
        }
        return data;
    }

    /** Preset activo, 0-based. */
    public int getActive() {
        return active;
    }

    public void setActive(int preset) {
        checkPreset(preset);
        if (preset != active) {
            active = preset;
            markDirty();
        }
    }

    /** Pasa al siguiente preset (cíclico) y devuelve el nuevo índice. */
    public int cycleActive() {
        setActive((active + 1) % MAX_PRESETS);
        return active;
    }

    /** Habilidad de la ranura (0-based), o null si está vacía. */
    @Nullable
    public ResourceLocation getSlot(int preset, int slot) {
        checkPreset(preset);
        checkSlot(slot);
        return slots[preset][slot];
    }

    public Optional<ResourceLocation> getActiveSlot(int slot) {
        return Optional.ofNullable(getSlot(active, slot));
    }

    public void setSlot(int preset, int slot, @Nullable ResourceLocation skill) {
        checkPreset(preset);
        checkSlot(slot);
        slots[preset][slot] = skill;
        markDirty();
    }

    public void clearAll() {
        boolean changed = active != 0;
        active = 0;
        for (ResourceLocation[] row : slots) {
            for (int s = 0; s < row.length; s++) {
                changed |= row[s] != null;
                row[s] = null;
            }
        }
        if (changed) {
            markDirty();
        }
    }

    private static void checkPreset(int preset) {
        if (preset < 0 || preset >= MAX_PRESETS) {
            throw new IllegalArgumentException("Preset out of range: " + preset);
        }
    }

    private static void checkSlot(int slot) {
        if (slot < 0 || slot >= MAX_SLOTS) {
            throw new IllegalArgumentException("Slot out of range: " + slot);
        }
    }

    // --- Cambios ---

    private void markDirty() {
        dirty = true;
    }

    public boolean isDirty() {
        return dirty;
    }

    /** Devuelve si había cambios pendientes y los limpia (el envío es siempre completo). */
    public boolean consumeDirty() {
        boolean was = dirty;
        dirty = false;
        return was;
    }
}
