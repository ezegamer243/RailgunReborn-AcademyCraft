package com.railgunreborn.ability.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.generic.GenericSkill;
import com.railgunreborn.registry.ModAttachments;

import java.util.Set;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * CP, overload y modo habilidad de un jugador ({@code datapart/CPData} del original).
 *
 * <p>Mismo patrón que {@link AbilityData}: clase mutable, Codec tolerante al cargar y {@link #markDirty()} como
 * punto único de aviso para el sync de T06. La lógica por tick la llama {@link CPEvents} solo en servidor.
 *
 * <p>Los métodos que dependen del nivel o del modo de juego reciben el {@link Player}: el attachment no conoce
 * a su dueño (el Codec no tiene acceso al holder).
 */
public final class CPData {
    // ac.ability.data del default.conf original; índice = nivel 0..5.
    private static final float[] INIT_CP = {1800, 1800, 2800, 4000, 5800, 8000};
    private static final float[] ADD_CP_CAP = {0, 900, 1000, 1500, 1700, 12000};
    private static final float[] INIT_OVERLOAD = {100, 100, 150, 240, 350, 500};
    private static final float[] ADD_OVERLOAD_CAP = {0, 40, 70, 80, 100, 500};

    private static final float MAX_CP_INCR_RATE = 0.0025f;
    private static final float MAX_OVERLOAD_INCR_RATE = 0.0058f;
    /** Tope por consumo del bonus de overload ({@code clamp(o * 0.0058, 0, 10)}). */
    private static final float MAX_OVERLOAD_INCR_PER_USE = 10f;

    private static final int CP_RECOVER_COOLDOWN = 15;
    private static final int OVERLOAD_RECOVER_COOLDOWN = 32;
    private static final float CP_RECOVER_SPEED = 1.0f;
    private static final float OVERLOAD_RECOVER_SPEED = 1.0f;

    // TODO(config): cp_consume_speed / overload_consume_speed por habilidad (1.0 por defecto) cuando exista
    // el sistema de config. Ahora se aplican como constantes globales.
    private static final float CP_CONSUME_SPEED = 1.0f;
    private static final float OVERLOAD_CONSUME_SPEED = 1.0f;

    public static final Codec<CPData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.BOOL.optionalFieldOf("activated", false).forGetter(d -> d.activated),
            Codec.FLOAT.optionalFieldOf("cur_cp", INIT_CP[0]).forGetter(d -> d.curCP),
            Codec.FLOAT.optionalFieldOf("max_cp", INIT_CP[0]).forGetter(d -> d.maxCP),
            Codec.FLOAT.optionalFieldOf("add_max_cp", 0f).forGetter(d -> d.addMaxCP),
            Codec.FLOAT.optionalFieldOf("cur_overload", 0f).forGetter(d -> d.curOverload),
            Codec.FLOAT.optionalFieldOf("max_overload", INIT_OVERLOAD[0]).forGetter(d -> d.maxOverload),
            Codec.FLOAT.optionalFieldOf("add_max_overload", 0f).forGetter(d -> d.addMaxOverload),
            Codec.BOOL.optionalFieldOf("overload_fine", true).forGetter(d -> d.overloadFine),
            Codec.INT.optionalFieldOf("until_recover", 0).forGetter(d -> d.untilRecover),
            Codec.INT.optionalFieldOf("until_overload_recover", 0).forGetter(d -> d.untilOverloadRecover)
    ).apply(inst, CPData::fromSaved));

    private boolean activated;
    private float curCP = INIT_CP[0];
    /** Máximo base (init_cp del nivel); el total suma {@link #addMaxCP}. */
    private float maxCP = INIT_CP[0];
    private float addMaxCP;
    private float curOverload;
    private float maxOverload = INIT_OVERLOAD[0];
    private float addMaxOverload;
    /** false = sobrecargado: no puede usar habilidades hasta que el overload vuelva a 0. */
    private boolean overloadFine = true;
    private int untilRecover;
    private int untilOverloadRecover;
    private boolean dirty;
    /** Cambio que el cliente debe ver ya (recálculos, modo, overload): el sync no espera a su cadencia. */
    private boolean urgent;

    public CPData() {
    }

    private static CPData fromSaved(boolean activated, float curCP, float maxCP, float addMaxCP, float curOverload,
            float maxOverload, float addMaxOverload, boolean overloadFine, int untilRecover, int untilOverloadRecover) {
        CPData data = new CPData();
        data.activated = activated;
        data.maxCP = positiveOr(maxCP, INIT_CP[0]);
        data.addMaxCP = sanitizeNonNegative(addMaxCP);
        data.curCP = Math.clamp(sanitizeNonNegative(curCP), 0f, data.getMaxCP());
        data.maxOverload = positiveOr(maxOverload, INIT_OVERLOAD[0]);
        data.addMaxOverload = sanitizeNonNegative(addMaxOverload);
        data.curOverload = Math.clamp(sanitizeNonNegative(curOverload), 0f, data.getMaxOverload());
        data.overloadFine = overloadFine || data.curOverload == 0f;
        data.untilRecover = Math.clamp(untilRecover, 0, CP_RECOVER_COOLDOWN);
        data.untilOverloadRecover = Math.clamp(untilOverloadRecover, 0, OVERLOAD_RECOVER_COOLDOWN);
        return data;
    }

    /** CP máximo base de un nivel (0..5) sin bonus de genéricas ni por uso ({@code init_cp}). */
    public static float initCp(int level) {
        return INIT_CP[Math.clamp(level, 0, INIT_CP.length - 1)];
    }

    /** Obtiene los datos y aplica antes los cambios de nivel/categoría pendientes de {@link AbilityData}. */
    public static CPData get(Player player) {
        CPData data = player.getData(ModAttachments.CP_DATA);
        // En cliente los datos llegan ya recalculados del servidor (T06): recalcular aquí los pisaría.
        if (!player.level().isClientSide()) {
            data.applyAbilityChanges(player);
        }
        return data;
    }

    // --- Lectura ---

    public boolean isActivated() {
        return activated;
    }

    public float getCP() {
        return curCP;
    }

    /** CP máximo total = base del nivel + bonus por uso. El base ya incluye los bonus de las genéricas. */
    public float getMaxCP() {
        return maxCP + addMaxCP;
    }

    public float getAddMaxCP() {
        return addMaxCP;
    }

    public float getOverload() {
        return curOverload;
    }

    public float getMaxOverload() {
        return maxOverload + addMaxOverload;
    }

    public float getAddMaxOverload() {
        return addMaxOverload;
    }

    public boolean isOverloaded() {
        return !overloadFine;
    }

    /** {@code activated && overloadFine} (la interferencia del original queda fuera de alcance). */
    public boolean canUseAbility() {
        return activated && overloadFine;
    }

    // --- Modo habilidad ---

    /** Sin categoría no se puede activar. @return true si cambió el estado. */
    public boolean setActivated(Player player, boolean value) {
        boolean newValue = value && AbilityData.get(player).hasCategory();
        if (newValue == activated) {
            return false;
        }
        activated = newValue;
        markDirtyUrgent();
        return true;
    }

    // --- Consumo ---

    /** Validación sin efectos: misma regla que {@link #consume}. */
    public boolean canConsume(Player player, float overload, float cp) {
        if (!overloadFine) {
            return false;
        }
        return player.isCreative() || curCP >= sanitizeNonNegative(cp) * CP_CONSUME_SPEED;
    }

    /**
     * Consume CP y añade overload ({@code perform} del original). Falla sin efectos si está sobrecargado o no
     * hay CP suficiente. En creativo siempre tiene éxito sin consumir, pero sí cuenta el bonus al máximo.
     */
    public boolean consume(Player player, float overload, float cp) {
        if (!canConsume(player, overload, cp)) {
            return false;
        }
        float realCP = sanitizeNonNegative(cp) * CP_CONSUME_SPEED;
        float realOverload = sanitizeNonNegative(overload) * OVERLOAD_CONSUME_SPEED;
        if (!player.isCreative()) {
            curCP = Math.max(0f, curCP - realCP);
            untilRecover = CP_RECOVER_COOLDOWN;
            addOverload(realOverload);
        }
        addMaxBonus(AbilityData.get(player).getLevel(), realOverload, realCP);
        markDirty();
        return true;
    }

    /** {@code performWithForce}: consume sin validar (CP no baja de 0). No cuenta bonus. */
    public void consumeWithForce(Player player, float overload, float cp) {
        if (player.isCreative()) {
            return;
        }
        curCP = Math.max(0f, curCP - sanitizeNonNegative(cp) * CP_CONSUME_SPEED);
        untilRecover = CP_RECOVER_COOLDOWN;
        addOverload(sanitizeNonNegative(overload) * OVERLOAD_CONSUME_SPEED);
        markDirty();
    }

    /**
     * Sube el overload hasta {@code floor} si bajó y reinicia la espera de recuperación; nunca provoca sobrecarga ni
     * toca el CP. Lo usa Body Intensify para que el overload no se recupere mientras se mantiene la carga.
     */
    public void raiseOverloadTo(float floor) {
        float target = Math.min(getMaxOverload() - 0.001f, floor);
        if (target > curOverload) {
            curOverload = target;
            markDirty();
        }
        untilOverloadRecover = OVERLOAD_RECOVER_COOLDOWN;
    }

    private void addOverload(float amount) {
        curOverload = Math.min(getMaxOverload(), curOverload + amount);
        untilOverloadRecover = OVERLOAD_RECOVER_COOLDOWN;
        if (overloadFine && curOverload >= getMaxOverload()) {
            overloadFine = false;
            markDirtyUrgent();
            // OverloadEvent del original: SkillContexts.tick ve canUseAbility() == false y termina los contextos
            // activos del jugador en su siguiente tick (a lo sumo 1 tick de retraso).
        }
    }

    private void addMaxBonus(int level, float overload, float cp) {
        addMaxCP = Math.min(ADD_CP_CAP[level], addMaxCP + cp * MAX_CP_INCR_RATE);
        addMaxOverload = Math.min(ADD_OVERLOAD_CAP[level],
                addMaxOverload + Math.clamp(overload * MAX_OVERLOAD_INCR_RATE, 0f, MAX_OVERLOAD_INCR_PER_USE));
    }

    // --- Tick (servidor) ---

    /** Lo llama {@link CPEvents}; público para que los GameTests (jugador falso sin tick propio) lo avancen a mano. */
    public void tick(Player player) {
        if (!AbilityData.get(player).hasCategory()) {
            return;
        }
        boolean changed = false;

        if (untilRecover > 0) {
            untilRecover--;
        } else if (curCP < getMaxCP()) {
            // Usa el máximo base (sin addMaxCP) como el original. mind_course multiplica x1.2.
            float mod = GenericRules.cpRecoverFactor(GenericSkill.learned(AbilityData.get(player)));
            float gain = CP_RECOVER_SPEED * 0.0003f * maxCP * Mth.lerp(curCP / maxCP, 1f, 2f) * mod;
            curCP = Math.min(getMaxCP(), curCP + gain);
            changed = true;
        }

        if (untilOverloadRecover > 0) {
            untilOverloadRecover--;
        } else if (curOverload > 0f) {
            float mod = 1f;
            float loss = OVERLOAD_RECOVER_SPEED * Math.max(0.002f * maxOverload,
                    0.007f * maxOverload * Mth.lerp(curOverload / maxOverload / 2f, 1f, 0.5f)) * mod;
            curOverload = Math.max(0f, curOverload - loss);
            changed = true;
        }
        if (!overloadFine && curOverload == 0f) {
            overloadFine = true;
            markDirtyUrgent();
        }

        if (changed) {
            markDirty();
        }
    }

    // --- Recálculos ---

    /** CP al máximo y overload a 0 ({@code recoverAll}): al morir y (T08) al dormir. */
    public void recoverAll() {
        curCP = getMaxCP();
        curOverload = 0f;
        overloadFine = true;
        untilRecover = 0;
        untilOverloadRecover = 0;
        markDirtyUrgent();
    }

    /** Equivale a {@code recalcMaxValue}: máximos base del nivel, CP lleno y overload a 0. */
    public void recalcMaxValues(Player player) {
        AbilityData ability = AbilityData.get(player);
        int level = ability.getLevel();
        Set<GenericRules.Kind> generics = GenericSkill.learned(ability);
        maxCP = INIT_CP[level] + GenericRules.maxCpBonus(generics);
        maxOverload = INIT_OVERLOAD[level] + GenericRules.maxOverloadBonus(generics);
        addMaxCP = Math.min(addMaxCP, ADD_CP_CAP[level]);
        addMaxOverload = Math.min(addMaxOverload, ADD_OVERLOAD_CAP[level]);
        recoverAll();
    }

    /**
     * Reacciona a LevelChangeEvent / CategoryChangeEvent del original: un cambio de nivel borra los bonus por uso;
     * cualquiera de los dos recalcula máximos; sin categoría se apaga el modo habilidad.
     */
    private void applyAbilityChanges(Player player) {
        AbilityData ability = player.getData(ModAttachments.ABILITY_DATA);
        boolean levelChanged = ability.consumeLevelChangedForCP();
        boolean categoryChanged = ability.consumeCategoryChangedForCP();
        boolean genericLearned = ability.consumeGenericLearnedForCP();
        if (!levelChanged && !categoryChanged && !genericLearned) {
            return;
        }
        if (levelChanged) {
            addMaxCP = 0f;
            addMaxOverload = 0f;
        }
        if (!ability.hasCategory()) {
            activated = false;
        }
        recalcMaxValues(player);
    }

    /** Al reaparecer tras morir (los datos ya vienen copiados por copyOnDeath). */
    void onRespawnAfterDeath() {
        activated = false;
        recoverAll();
    }

    // --- Cambios ---

    /** Cambio normal: se envía al cliente con la cadencia periódica ({@code network.DataSync}). */
    private void markDirty() {
        dirty = true;
    }

    private void markDirtyUrgent() {
        dirty = true;
        urgent = true;
    }

    public boolean isDirty() {
        return dirty;
    }

    public boolean isUrgent() {
        return urgent;
    }

    /** Devuelve si había cambios pendientes y limpia ambas marcas (el envío es siempre completo). */
    public boolean consumeDirty() {
        boolean was = dirty;
        dirty = false;
        urgent = false;
        return was;
    }

    private static float sanitizeNonNegative(float value) {
        return Float.isNaN(value) || Float.isInfinite(value) || value < 0f ? 0f : value;
    }

    private static float positiveOr(float value, float fallback) {
        return Float.isNaN(value) || Float.isInfinite(value) || value <= 0f ? fallback : value;
    }
}
