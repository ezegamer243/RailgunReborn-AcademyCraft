package com.railgunreborn.ability.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.railgunreborn.registry.ModAttachments;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Cooldowns de habilidades de un jugador ({@code datapart/CooldownData} del original), en ticks.
 *
 * <p>No se guarda (la ficha, sección 8): se pierde al reconectar. Servidor y cliente tienen cada uno su copia y la
 * descuentan por su cuenta cada tick; el servidor manda una foto completa al cliente cada vez que fija o borra
 * algo ({@code ability.context.SkillContexts#syncCooldowns}). El servidor es el que valida.
 *
 * <p>{@code sub} permite varios cooldowns para una misma habilidad (0 = la habilidad en sí).
 */
public final class CooldownData {
    private final Map<Key, Cooldown> cooldowns = new LinkedHashMap<>();
    private boolean dirty;

    public static CooldownData get(Player player) {
        return player.getData(ModAttachments.COOLDOWN_DATA);
    }

    public boolean isInCooldown(ResourceLocation skill) {
        return isInCooldown(skill, 0);
    }

    public boolean isInCooldown(ResourceLocation skill, int sub) {
        return cooldowns.containsKey(new Key(skill, sub));
    }

    /** Ticks restantes (0 = libre). */
    public int getRemaining(ResourceLocation skill, int sub) {
        Cooldown cd = cooldowns.get(new Key(skill, sub));
        return cd == null ? 0 : cd.remaining;
    }

    /** Fracción restante en 0..1 (relleno gris del icono en el HUD). */
    public float getProgress(ResourceLocation skill, int sub) {
        Cooldown cd = cooldowns.get(new Key(skill, sub));
        return cd == null ? 0f : (float) cd.remaining / cd.max;
    }

    public void set(ResourceLocation skill, int ticks) {
        set(skill, 0, ticks);
    }

    /** Como el original: si ya hay un cooldown se queda el mayor de los dos. */
    public void set(ResourceLocation skill, int sub, int ticks) {
        if (ticks <= 0) {
            return;
        }
        Key key = new Key(skill, sub);
        Cooldown current = cooldowns.get(key);
        if (current == null || current.remaining < ticks) {
            cooldowns.put(key, new Cooldown(ticks, ticks));
            dirty = true;
        }
    }

    public void clear() {
        if (!cooldowns.isEmpty()) {
            cooldowns.clear();
            dirty = true;
        }
    }

    /** Descuenta un tick (en ambos lados); no marca cambios: cada lado cuenta por su cuenta. */
    public void tick() {
        Iterator<Cooldown> it = cooldowns.values().iterator();
        while (it.hasNext()) {
            if (--it.next().remaining <= 0) {
                it.remove();
            }
        }
    }

    public boolean consumeDirty() {
        boolean was = dirty;
        dirty = false;
        return was;
    }

    // --- Red ---

    public List<Entry> snapshot() {
        List<Entry> out = new ArrayList<>(cooldowns.size());
        cooldowns.forEach((k, v) -> out.add(new Entry(k.skill(), k.sub(), v.remaining, v.max)));
        return out;
    }

    /** Cliente: reemplaza todo con la foto del servidor. */
    public void applySnapshot(List<Entry> entries) {
        cooldowns.clear();
        for (Entry e : entries) {
            if (e.remaining() > 0) {
                cooldowns.put(new Key(e.skill(), e.sub()), new Cooldown(e.remaining(), Math.max(e.remaining(), e.max())));
            }
        }
    }

    private record Key(ResourceLocation skill, int sub) {
    }

    private static final class Cooldown {
        private int remaining;
        private final int max;

        private Cooldown(int remaining, int max) {
            this.remaining = remaining;
            this.max = max;
        }
    }

    public record Entry(ResourceLocation skill, int sub, int remaining, int max) {
        public static final StreamCodec<ByteBuf, Entry> STREAM_CODEC = StreamCodec.composite(
                ResourceLocation.STREAM_CODEC, Entry::skill,
                ByteBufCodecs.VAR_INT, Entry::sub,
                ByteBufCodecs.VAR_INT, Entry::remaining,
                ByteBufCodecs.VAR_INT, Entry::max,
                Entry::new);
    }
}
