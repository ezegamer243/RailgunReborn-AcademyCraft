package com.railgunreborn.ability.data;

import com.railgunreborn.RailgunReborn;

import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Lógica de servidor de {@link CPData}: tick y muerte. */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class CPEvents {
    private CPEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) {
            return;
        }
        CPData.get(player).tick(player);
    }

    /**
     * Se usa Clone y no LivingDeathEvent: copyOnDeath copia los datos al nuevo jugador antes de este evento, y
     * así el ajuste no depende de que otro mod cancele la muerte. Volver del End (sin muerte) no toca nada.
     */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            CPData.get(event.getEntity()).onRespawnAfterDeath();
        }
    }
}
