package com.railgunreborn.ability.data;

import javax.annotation.Nullable;

import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Reglas del servidor para editar una ranura de preset. Las usan el comando {@code /railgunreborn preset} y el
 * payload de edición, para que ambos apliquen exactamente lo mismo. Nunca lanzan excepciones por índices malos.
 */
public final class PresetRules {
    public enum Result {
        OK,
        NO_CATEGORY,
        BAD_INDEX,
        UNKNOWN_SKILL,
        WRONG_CATEGORY,
        NOT_LEARNED,
        NOT_CONTROLLABLE,
        /** La habilidad ya está en otra ranura del mismo preset. */
        DUPLICATE
    }

    private PresetRules() {
    }

    /** Comprueba la edición sin aplicarla. {@code skill == null} = vaciar la ranura (siempre permitido con categoría). */
    public static Result validateEdit(Player player, PresetData presets, int preset, int slot,
            @Nullable ResourceLocation skillId) {
        AbilityData ability = AbilityData.get(player);
        if (!ability.hasCategory()) {
            return Result.NO_CATEGORY;
        }
        if (preset < 0 || preset >= PresetData.MAX_PRESETS || slot < 0 || slot >= PresetData.MAX_SLOTS) {
            return Result.BAD_INDEX;
        }
        if (skillId == null) {
            return Result.OK;
        }
        Skill skill = AbilityRegistries.skill(skillId).orElse(null);
        if (skill == null) {
            return Result.UNKNOWN_SKILL;
        }
        if (!ability.getCategory().map(skill.getCategoryId()::equals).orElse(false)) {
            return Result.WRONG_CATEGORY;
        }
        if (!skill.canControl()) {
            return Result.NOT_CONTROLLABLE;
        }
        if (!ability.isLearned(skillId)) {
            return Result.NOT_LEARNED;
        }
        for (int other = 0; other < PresetData.MAX_SLOTS; other++) {
            if (other != slot && skillId.equals(presets.getSlot(preset, other))) {
                return Result.DUPLICATE;
            }
        }
        return Result.OK;
    }

    /** Valida y, si procede, escribe la ranura. Devuelve el resultado; con algo distinto de OK no cambia nada. */
    public static Result applyEdit(Player player, int preset, int slot, @Nullable ResourceLocation skillId) {
        PresetData presets = PresetData.get(player);
        Result result = validateEdit(player, presets, preset, slot, skillId);
        if (result == Result.OK) {
            presets.setSlot(preset, slot, skillId);
        }
        return result;
    }
}
