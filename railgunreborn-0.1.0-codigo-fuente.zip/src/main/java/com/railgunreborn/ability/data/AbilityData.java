package com.railgunreborn.ability.data;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.generic.GenericSkill;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Datos persistentes de habilidades de un jugador (categoría, nivel, progreso, habilidades aprendidas y su exp).
 *
 * <p>Clase mutable: es lo habitual con attachments (se obtiene con {@link #get(Player)} y se modifica en sitio,
 * NeoForge la serializa al guardar). Toda modificación pasa por {@link #markDirty()}.
 *
 * <p>CP/overload van en otro attachment (T05); presets y cooldowns tampoco van aquí.
 */
public final class AbilityData {
    public static final int MIN_LEVEL = 0;
    public static final int MAX_LEVEL = 5;

    // Al cargar se corrige en vez de fallar: un valor fuera de rango no debe borrar todos los datos del jugador.
    public static final Codec<AbilityData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            ResourceLocation.CODEC.optionalFieldOf("category").forGetter(d -> Optional.ofNullable(d.category)),
            Codec.INT.optionalFieldOf("level", 0).forGetter(d -> d.level),
            Codec.FLOAT.optionalFieldOf("level_progress", 0f).forGetter(d -> d.levelProgress),
            ResourceLocation.CODEC.listOf().optionalFieldOf("learned", List.of())
                    .forGetter(d -> List.copyOf(d.learnedSkills)),
            Codec.unboundedMap(ResourceLocation.CODEC, Codec.FLOAT).optionalFieldOf("skill_exp", Map.of())
                    .forGetter(d -> Map.copyOf(d.skillExps)),
            Codec.BOOL.optionalFieldOf("needle_only", false).forGetter(d -> d.needleOnly)
    ).apply(inst, AbilityData::fromSaved));

    @Nullable
    private ResourceLocation category;
    private int level;
    /** Progreso acumulado hacia el siguiente nivel ({@code expAddedThisLevel} del original); sin tope. */
    private float levelProgress;
    private final Set<ResourceLocation> learnedSkills = new LinkedHashSet<>();
    private final Map<ResourceLocation, Float> skillExps = new HashMap<>();
    /** Opción del jugador: Threatening Teleport solo funciona con la aguja en la mano principal. */
    private boolean needleOnly;
    private boolean dirty;
    private boolean urgent;
    // Equivalen a LevelChangeEvent / CategoryChangeEvent: CPData los consume (no se guardan) para no acoplar
    // esta clase al jugador ni a CPData.
    private boolean levelChangedForCP;
    private boolean categoryChangedForCP;
    /** CPData lo consume (no se guarda): se aprendió una genérica, hay que recalcular máximos y rellenar CP. */
    private boolean genericLearnedForCP;
    /** PresetData lo consume (no se guarda): vaciar presets tras cambiar de categoría. */
    private boolean presetsClearPending;
    /** SkillContexts lo consume (no se guarda): terminar contextos y limpiar cooldowns. */
    private boolean categoryChangedForSkills;

    public AbilityData() {
    }

    private static AbilityData fromSaved(Optional<ResourceLocation> category, int level, float progress,
            List<ResourceLocation> learned, Map<ResourceLocation, Float> exps, boolean needleOnly) {
        AbilityData data = new AbilityData();
        data.category = category.orElse(null);
        data.needleOnly = needleOnly;
        data.level = data.category == null ? 0 : Math.clamp(level, 1, MAX_LEVEL);
        data.levelProgress = sanitizeNonNegative(progress);
        data.learnedSkills.addAll(learned);
        exps.forEach((id, exp) -> {
            data.learnedSkills.add(id);
            data.skillExps.put(id, clampExp(exp));
        });
        return data;
    }

    public static AbilityData get(Player player) {
        return player.getData(ModAttachments.ABILITY_DATA);
    }

    // --- Categoría y nivel ---

    public Optional<ResourceLocation> getCategory() {
        return Optional.ofNullable(category);
    }

    public boolean hasCategory() {
        return category != null;
    }

    /**
     * Cambia la categoría ({@code null} = quitarla). Como en el original: borra habilidades aprendidas y exps;
     * sin categoría el nivel pasa a 0, y si era 0 pasa a 1.
     * CP/overload se recalculan vía {@link CPData#get} y los presets se vacían vía {@link PresetData#get} (misma
     * bandera pendiente); los contextos activos se terminan y los cooldowns se limpian vía {@code SkillContexts}.
     */
    public void setCategory(@Nullable ResourceLocation newCategory) {
        category = newCategory;
        categoryChangedForCP = true;
        presetsClearPending = true;
        categoryChangedForSkills = true;
        learnedSkills.clear();
        skillExps.clear();
        if (newCategory == null) {
            setLevelInternal(0);
        } else if (level == 0) {
            setLevelInternal(1);
        }
        markDirty();
    }

    public int getLevel() {
        return level;
    }

    /** Pone el nivel y reinicia el progreso de nivel. Con categoría: 1..5; sin categoría solo 0. */
    public void setLevel(int newLevel) {
        if (category == null ? newLevel != 0 : newLevel < 1 || newLevel > MAX_LEVEL) {
            throw new IllegalArgumentException("Invalid level " + newLevel + " (category: " + category + ")");
        }
        setLevelInternal(newLevel);
        markDirty();
    }

    private void setLevelInternal(int newLevel) {
        level = newLevel;
        levelProgress = 0f;
        levelChangedForCP = true;
    }

    /** Valor bruto acumulado; el umbral y la fracción 0..1 los calcula {@link Category#levelProgressFraction}. */
    public float getLevelProgress() {
        return levelProgress;
    }

    public void setLevelProgress(float progress) {
        levelProgress = requireNonNegative(progress, "level progress");
        markDirty();
    }

    // --- Habilidades ---

    public boolean isLearned(ResourceLocation skill) {
        return learnedSkills.contains(skill);
    }

    /** @return true si no estaba aprendida. */
    public boolean learnSkill(ResourceLocation skill) {
        boolean added = learnedSkills.add(skill);
        if (added) {
            noteLearned(skill);
            markDirty();
        }
        return added;
    }

    /** Solo las genéricas (pasivas) piden recalcular máximos al aprenderse; el resto no. */
    private void noteLearned(ResourceLocation skill) {
        if (AbilityRegistries.skill(skill).map(s -> s instanceof GenericSkill).orElse(false)) {
            genericLearnedForCP = true;
        }
    }

    public Set<ResourceLocation> getLearnedSkills() {
        return Collections.unmodifiableSet(learnedSkills);
    }

    public float getSkillExp(ResourceLocation skill) {
        return skillExps.getOrDefault(skill, 0f);
    }

    /** Fija la exp (se recorta a 0..1) y aprende la habilidad si no lo estaba. */
    public void setSkillExp(ResourceLocation skill, float exp) {
        if (Float.isNaN(exp)) {
            throw new IllegalArgumentException("Skill exp is NaN");
        }
        if (learnedSkills.add(skill)) {
            noteLearned(skill);
        }
        skillExps.put(skill, clampExp(exp));
        markDirty();
    }

    /**
     * Suma exp a la habilidad (tope 1.0) y aprende la habilidad (aprender por uso, como el original).
     * También suma {@code amount} al progreso de nivel aunque la habilidad ya esté al 100%.
     * {@code amount} ya debe venir multiplicado por {@code exp_incr_speed} de la habilidad; al progreso se le
     * aplican además los {@code prog_incr_rate} de la categoría y global ({@link Category#getTotalProgIncrRate}).
     */
    public void addSkillExp(ResourceLocation skill, float amount) {
        requireNonNegative(amount, "skill exp amount");
        if (learnedSkills.add(skill)) {
            noteLearned(skill);
        }
        skillExps.put(skill, clampExp(getSkillExp(skill) + amount));
        levelProgress += amount * AbilityRegistries.category(category)
                .map(Category::getTotalProgIncrRate)
                .orElse(Category.GLOBAL_PROG_INCR_RATE);
        // Ganar exp es frecuente (habilidades continuas): el sync lo agrupa con un retraso, como el original.
        dirty = true;
    }

    public boolean isNeedleOnly() {
        return needleOnly;
    }

    public void setNeedleOnly(boolean value) {
        needleOnly = value;
        markDirty();
    }

    // --- Cambios ---

    /** Cambio que se envía al cliente de inmediato (categoría, nivel, aprender...); ver {@code network.DataSync}. */
    private void markDirty() {
        dirty = true;
        urgent = true;
    }

    public boolean isDirty() {
        return dirty;
    }

    public boolean isUrgent() {
        return urgent;
    }

    /** Devuelve si había cambios pendientes y limpia ambas marcas (el envío es siempre completo). */
    public boolean consumeDirty() {
        boolean was = dirty;
        dirty = false;
        urgent = false;
        return was;
    }

    boolean consumeLevelChangedForCP() {
        boolean was = levelChangedForCP;
        levelChangedForCP = false;
        return was;
    }

    boolean consumeGenericLearnedForCP() {
        boolean was = genericLearnedForCP;
        genericLearnedForCP = false;
        return was;
    }

    boolean consumePresetsClearPending() {
        boolean was = presetsClearPending;
        presetsClearPending = false;
        return was;
    }

    /** Para {@code ability.context.SkillContexts} (otro paquete); devuelve y limpia la bandera. */
    public boolean consumeCategoryChangedForSkills() {
        boolean was = categoryChangedForSkills;
        categoryChangedForSkills = false;
        return was;
    }

    boolean consumeCategoryChangedForCP() {
        boolean was = categoryChangedForCP;
        categoryChangedForCP = false;
        return was;
    }

    private static float clampExp(float exp) {
        return Float.isNaN(exp) ? 0f : Math.clamp(exp, 0f, 1f);
    }

    private static float sanitizeNonNegative(float value) {
        return Float.isNaN(value) || Float.isInfinite(value) || value < 0f ? 0f : value;
    }

    private static float requireNonNegative(float value, String what) {
        if (Float.isNaN(value) || Float.isInfinite(value) || value < 0f) {
            throw new IllegalArgumentException("Invalid " + what + ": " + value);
        }
        return value;
    }
}
