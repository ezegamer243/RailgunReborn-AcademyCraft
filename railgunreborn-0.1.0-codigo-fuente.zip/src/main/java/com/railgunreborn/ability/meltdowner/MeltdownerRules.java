package com.railgunreborn.ability.meltdowner;

/**
 * Números y decisiones de la habilidad Meltdowner ({@code docs/spec/meltdowner-skill.md}), en Java puro para probarlos
 * con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar; {@code ticks} son los ticks de carga.
 */
public final class MeltdownerRules {
    /** Carga mínima para disparar: soltar antes no dispara (el overload inicial ya se gastó). */
    public static final int MIN_TICKS = 20;
    /** Carga máxima: más allá solo se gasta CP. */
    public static final int MAX_TICKS = 40;
    /** Pasado este tick la carga se cancela sin disparar ({@code TICKS_TOLE} del original). */
    public static final int TOLERANCE_TICKS = 100;
    /** Largo del cilindro de daño y del rayo. */
    public static final double RANGE = 50.0;
    /** Pasos (bloques) de cada línea del túnel ({@code maxIncrement}). */
    public static final int MAX_STEPS = 50;
    /** Ralentización por tick de carga (multiplicador total): 60 % de la velocidad a 40 ticks, parado a 100. */
    public static final double SLOW_PER_TICK = 0.01;

    private MeltdownerRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Ticks de carga que cuentan para los números: acotados a [20, 40]. */
    public static int chargeTicks(int ticks) {
        return Math.clamp(ticks, MIN_TICKS, MAX_TICKS);
    }

    /** Si soltar con {@code ticks} de carga dispara. */
    public static boolean canFire(int ticks) {
        return ticks >= MIN_TICKS && ticks <= TOLERANCE_TICKS;
    }

    /** Si la carga se cancela sola (pasó del límite). */
    public static boolean isOverTolerance(int ticks) {
        return ticks > TOLERANCE_TICKS;
    }

    /** "Tasa por tiempo": 0.8 con la carga mínima, 1.0 a 30 ticks, 1.2 con la máxima. */
    public static float rate(int ticks) {
        return lerp(0.8f, 1.2f, (chargeTicks(ticks) - MIN_TICKS) / (float) (MAX_TICKS - MIN_TICKS));
    }

    public static float initialOverload(float exp) {
        return lerp(200f, 170f, exp);
    }

    public static float cpPerTick(float exp) {
        return lerp(10f, 15f, exp);
    }

    /** Radio del cilindro de daño y del túnel. */
    public static double radius(float exp) {
        return lerp(2f, 3f, exp);
    }

    /** Energía de rotura repartida entre las líneas del túnel. */
    public static double energy(float exp, int ticks) {
        return rate(ticks) * lerp(300f, 700f, exp);
    }

    /** Daño a cada ser vivo del cilindro (antes de {@code damage_scale}); constante a lo largo del rayo. */
    public static float damage(float exp, int ticks) {
        return rate(ticks) * lerp(18f, 50f, exp);
    }

    public static int cooldown(float exp, int ticks) {
        return (int) (rate(ticks) * 20f * lerp(15f, 7f, exp));
    }

    /** Exp por disparo (acierte o no). */
    public static float expGain(int ticks) {
        return 0.002f * rate(ticks);
    }

    /** Modificador de velocidad ({@code ADD_MULTIPLIED_TOTAL}) tras {@code ticks} de carga, entre -1 y 0. */
    public static double slowAmount(int ticks) {
        return -Math.min(1.0, Math.max(0, ticks) * SLOW_PER_TICK);
    }

    /** Daño del contragolpe de un reflejo (Vector Reflection, fase 10): sin escala por carga. */
    public static float reflectDamage(float exp) {
        return 0.5f * lerp(20f, 50f, exp);
    }
}
