package com.railgunreborn.ability.meltdowner;

import java.util.List;
import java.util.function.ToDoubleFunction;

/**
 * Números y decisiones de Electron Missile ({@code docs/spec/electron-missile.md}), en Java puro para probarlos con
 * JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar. Los ticks se numeran desde 0 (el primer tick
 * con la tecla mantenida).
 */
public final class ElectronMissileRules {
    /** Overload al pulsar (sin CP). */
    public static final float OVERLOAD_START = 200f;
    public static final int BALL_INTERVAL = 10;
    public static final int ATTACK_INTERVAL = 8;
    public static final int MAX_BALLS = 5;
    public static final float EXP_PER_ATTACK = 0.001f;

    private ElectronMissileRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cpPerTick(float exp) {
        return lerp(12f, 5f, exp);
    }

    public static float cpPerAttack(float exp) {
        return lerp(60f, 25f, exp);
    }

    public static float overloadPerAttack(float exp) {
        return lerp(9f, 4f, exp);
    }

    public static float damage(float exp) {
        return lerp(10f, 18f, exp);
    }

    /** Alcance (bloques, de pies a posición del objetivo). */
    public static double range(float exp) {
        return lerp(5f, 13f, exp);
    }

    /** Último tick con bolas y ataques; al pasarlo termina. */
    public static int maxTicks(float exp) {
        return (int) lerp(80f, 200f, exp);
    }

    /** Decisión 1: {@code lerp(700, 400, exp)} (el original quedaba siempre en 700 por un error de argumentos). */
    public static int cooldown(float exp) {
        return (int) lerp(700f, 400f, exp);
    }

    public static boolean spawnsBall(int tick, int balls) {
        return tick % BALL_INTERVAL == 0 && balls < MAX_BALLS;
    }

    public static boolean isAttackTick(int tick) {
        return tick != 0 && tick % ATTACK_INTERVAL == 0;
    }

    /**
     * El candidato más cercano con distancia al cuadrado {@code <= range^2}; {@code null} si no hay ninguno. En empate
     * gana el primero de la lista.
     */
    public static <T> T pickClosest(List<T> candidates, ToDoubleFunction<T> distanceSqr, double range) {
        T best = null;
        double bestDist = range * range;
        for (T candidate : candidates) {
            double d = distanceSqr.applyAsDouble(candidate);
            if (d <= bestDist && (best == null || d < bestDist)) {
                best = candidate;
                bestDist = d;
            }
        }
        return best;
    }

    /** Decisión 2: seres vivos salvo el propio jugador, sus mascotas, los soportes de armadura y jugadores protegidos. */
    public static boolean isValidTarget(boolean self, boolean ownPet, boolean armorStand, boolean protectedPlayer) {
        return !self && !ownPet && !armorStand && !protectedPlayer;
    }
}
