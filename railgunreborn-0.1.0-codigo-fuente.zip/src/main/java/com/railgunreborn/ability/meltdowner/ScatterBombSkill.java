package com.railgunreborn.ability.meltdowner;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.phys.Vec3;

/**
 * Scatter Bomb: nivel 2 de Meltdowner. Se mantiene la tecla: cada 10 ticks (del 20 al 80) aparece una bola fija delante
 * del jugador (max. 7) y al terminar salen todas, dispersas, con alcance ~30 bloques. Ficha:
 * {@code docs/spec/scatter-bomb.md} (mandan las decisiones del final). Numeros en {@link ScatterBombRules}.
 */
public class ScatterBombSkill extends Skill {
    /** Al pulsar: solo lo usa el jugador local (contorno de carga del icono). */
    public static final String CHANNEL_START = "start";
    /** Nueva bola: {@link ElectronBombSkill#OFFSET_KEY}. */
    public static final String CHANNEL_BALL = "ball";
    /** Fin: {@link #RAYS_KEY} (lista de {from, to}, vacia si no se disparo). */
    public static final String CHANNEL_END = "end";
    public static final String RAYS_KEY = "rays";

    public ScatterBombSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ScatterBombContext(player, this);
    }

    public static final class ScatterBombContext extends SkillContext {
        private final ScatterBombSkill skill;
        private final float exp;
        private final List<Vec3> balls = new ArrayList<>();
        private int ticks;
        /** Overload tras pagar el inicial: no se deja bajar de aqui mientras se mantiene. */
        private float overloadFloor;
        private boolean ended;

        ScatterBombContext(ServerPlayer player, ScatterBombSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        /** Bolas acumuladas hasta ahora (para pruebas). */
        public int ballCount() {
            return balls.size();
        }

        @Override
        protected void onKeyDown() {
            consume(ScatterBombRules.initialOverload(exp), 0f);
            overloadFloor = CPData.get(getPlayer()).getOverload();
            sendEffect(CHANNEL_START, new CompoundTag());
        }

        @Override
        protected void onKeyTick() {
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadFloor);
            ticks++;
            if (ScatterBombRules.paysCp(ticks) && !consume(0f, ScatterBombRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            if (ScatterBombRules.canSpawnBall(ticks) && balls.size() < ScatterBombRules.MAX_BALLS) {
                addBall(player);
            }
            if (ScatterBombRules.isBlowTick(ticks)) {
                player.hurt(player.damageSources().source(ModDamageTypes.SCATTER_BOMB_SELF),
                        ScatterBombRules.SELF_DAMAGE);
                terminate();
            }
        }

        private void addBall(ServerPlayer player) {
            var random = player.getRandom();
            double[] o = ElectronBombRules.ballOffset(Math.toRadians(player.getYRot()), random.nextDouble(),
                    random.nextDouble(), random.nextDouble());
            Vec3 offset = new Vec3(o[0], o[1], o[2]);
            balls.add(offset);
            CompoundTag data = new CompoundTag();
            data.put(ElectronBombSkill.OFFSET_KEY, ElectronBombSkill.vec(offset));
            sendEffect(CHANNEL_BALL, data);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (ended) {
                return;
            }
            ended = true;
            // Muerte, cambio de dimension, desconexion...: las bolas se pierden sin dano ni exp (decision 6).
            boolean fire = switch (reason) {
                case SELF, CLIENT, TIMEOUT, OVERLOAD, MODE_OFF -> true;
                default -> false;
            };
            ListTag rays = new ListTag();
            if (fire && getPlayer().isAlive() && !balls.isEmpty()) {
                fireAll(rays);
            }
            CompoundTag data = new CompoundTag();
            data.put(RAYS_KEY, rays);
            sendEffect(CHANNEL_END, data);
        }

        private void fireAll(ListTag rays) {
            ServerPlayer player = getPlayer();
            var random = player.getRandom();
            Vec3 eyes = player.getEyePosition();
            Vec3 look = player.getViewVector(1.0f);
            List<Mob> candidates = autoCandidates(player);
            int auto = candidates.isEmpty() ? 0 : ScatterBombRules.autoCount(balls.size(), exp);
            float damage = ScatterBombRules.damage(exp);
            int hits = 0;

            for (Vec3 offset : balls) {
                Vec3 from = player.position().add(offset);
                Vec3 to;
                if (auto > 0) {
                    auto--;
                    to = candidates.get(random.nextInt(candidates.size())).getEyePosition();
                } else {
                    double[] d = ScatterBombRules.scatterDirection(new double[] {look.x, look.y, look.z},
                            random.nextDouble(), random.nextDouble());
                    to = eyes.add(look.scale(ScatterBombRules.RANGE_A))
                            .add(new Vec3(d[0], d[1], d[2]).scale(ScatterBombRules.RANGE_B));
                }
                ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, from, to);
                // Solo da exp la bola que daña a un ser vivo; se salta la invulnerabilidad para que todas peguen.
                if (hit.entity() != null && MdDamage.attack(player, skill, ModDamageTypes.SCATTER_BOMB, hit.entity(),
                        damage, true, true)) {
                    hits++;
                }
                CompoundTag ray = new CompoundTag();
                ray.put(ElectronBombSkill.FROM_KEY, ElectronBombSkill.vec(from));
                ray.put(ElectronBombSkill.TO_KEY, ElectronBombSkill.vec(hit.end()));
                rays.add(ray);
            }
            if (hits > 0) {
                addSkillExp(ScatterBombRules.expGain(hits));
            }
        }

        /** Mobs a 5 bloques o menos del jugador, sin sus mascotas ni aliados. */
        private List<Mob> autoCandidates(ServerPlayer player) {
            double r = ScatterBombRules.AUTO_RADIUS;
            return player.level().getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(r),
                    mob -> mob.isAlive() && mob.distanceTo(player) <= r && !mob.isAlliedTo(player)
                            && !(mob instanceof TamableAnimal pet && pet.isOwnedBy(player)));
        }
    }
}
