package com.railgunreborn.ability.meltdowner;

import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.generic.GenericSkill;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

/**
 * Categoría Meltdowner y sus habilidades ({@code docs/spec/meltdowner.md}: niveles, padres y posiciones del árbol).
 *
 * <p>Por ahora Electron Bomb, β Radiation Intensify (pasiva), Scatter Bomb, Light Shield, Meltdowner, las tres Mining Ray y Ray Barrage; cada habilidad activa se añade en su tarea, respetando el orden
 * del original: electron_bomb, rad_intensify, scatter_bomb, light_shield, meltdowner, mine_ray_basic, ray_barrage,
 * jet_engine, mine_ray_expert, mine_ray_luck, electron_missile; luego las genéricas.
 */
public final class Meltdowner {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "meltdowner");

    /** Color de estilo del original: RGBA 126, 255, 132, 80 (alfa sobre 255). */
    public static final int COLOR = 0x507EFF84;

    public static final DeferredHolder<Category, Category> CATEGORY =
            AbilityRegistries.CATEGORIES.register(ID.getPath(), () -> new Category(COLOR, 1.0f));

    /** Id de Electron Bomb, padre de Rad Intensify y de las demás. */
    public static final ResourceLocation ELECTRON_BOMB_ID = skillId("electron_bomb");

    public static final DeferredHolder<Skill, ElectronBombSkill> ELECTRON_BOMB =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/electron_bomb",
                    () -> new ElectronBombSkill(new Skill.Properties(ID, 1)
                            .guiPos(15, 45)));

    public static final DeferredHolder<Skill, RadIntensifySkill> RAD_INTENSIFY =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/rad_intensify",
                    () -> new RadIntensifySkill(new Skill.Properties(ID, 1)
                            .passive()
                            .parent(ELECTRON_BOMB_ID, 0.5f)
                            .guiPos(35, 75)));

    public static final DeferredHolder<Skill, ScatterBombSkill> SCATTER_BOMB =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/scatter_bomb",
                    () -> new ScatterBombSkill(new Skill.Properties(ID, 2)
                            .parent(ELECTRON_BOMB_ID, 0.8f)
                            .guiPos(70, 50)));

    public static final DeferredHolder<Skill, LightShieldSkill> LIGHT_SHIELD =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/light_shield",
                    () -> new LightShieldSkill(new Skill.Properties(ID, 2)
                            .parent(ELECTRON_BOMB_ID, 1.0f)
                            .guiPos(55, 15)));

    public static final DeferredHolder<Skill, MeltdownerSkill> MELTDOWNER =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/meltdowner",
                    () -> new MeltdownerSkill(new Skill.Properties(ID, 3)
                            .parent(skillId("scatter_bomb"), 0.8f)
                            .dependency(skillId("light_shield"), 0.8f)
                            .guiPos(115, 40)));

    // Ray Barrage (y Jet Engine, en su tarea) van entre la Mining Ray básica y la experta, como en el original. El
    // orden solo importa para el listado: se guardan por id de texto.
    public static final DeferredHolder<Skill, MineRaySkill> MINE_RAY_BASIC =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mine_ray_basic",
                    () -> new MineRaySkill(new Skill.Properties(ID, 3)
                            .parent(skillId("meltdowner"), 0.3f)
                            .guiPos(140, 70), MineRayRules.Variant.BASIC));

    public static final DeferredHolder<Skill, RayBarrageSkill> RAY_BARRAGE =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/ray_barrage",
                    () -> new RayBarrageSkill(new Skill.Properties(ID, 4)
                            .parent(skillId("meltdowner"), 0.5f)
                            .guiPos(140, 10)));

    public static final DeferredHolder<Skill, JetEngineSkill> JET_ENGINE =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/jet_engine",
                    () -> new JetEngineSkill(new Skill.Properties(ID, 4)
                            .parent(skillId("meltdowner"), 1.0f)
                            .guiPos(170, 32)));

    public static final DeferredHolder<Skill, MineRaySkill> MINE_RAY_EXPERT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mine_ray_expert",
                    () -> new MineRaySkill(new Skill.Properties(ID, 4)
                            .parent(skillId("mine_ray_basic"), 0.8f)
                            .guiPos(172, 70), MineRayRules.Variant.EXPERT));

    public static final DeferredHolder<Skill, MineRaySkill> MINE_RAY_LUCK =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mine_ray_luck",
                    () -> new MineRaySkill(new Skill.Properties(ID, 5)
                            .parent(skillId("mine_ray_expert"), 1.0f)
                            .guiPos(205, 82), MineRayRules.Variant.LUCK));

    public static final DeferredHolder<Skill, ElectronMissileSkill> ELECTRON_MISSILE =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/electron_missile",
                    () -> new ElectronMissileSkill(new Skill.Properties(ID, 5)
                            .parent(skillId("jet_engine"), 0.3f)
                            .guiPos(210, 35)));

    // Siempre después de las habilidades propias (orden estable del registro).
    public static final Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> GENERICS =
            GenericSkill.registerFor(AbilityRegistries.SKILLS, ID);

    private Meltdowner() {
    }

    public static ResourceLocation skillId(String name) {
        return ID.withPath(p -> p + "/" + name);
    }

    /** Solo fuerza la carga de la clase (y con ella el registro de las entradas de arriba). */
    public static void init() {
    }
}
