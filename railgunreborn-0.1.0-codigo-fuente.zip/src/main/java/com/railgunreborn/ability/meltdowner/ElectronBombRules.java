package com.railgunreborn.ability.meltdowner;

/**
 * Números y decisiones de Electron Bomb ({@code docs/spec/electron-bomb.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class ElectronBombRules {
    /** Alcance del trazado de la mirada y del rayo. */
    public static final float RANGE = 15f;
    public static final int LIFE = 20;
    public static final int LIFE_IMPROVED = 5;
    /** Con exp estrictamente mayor que esto la bola dura {@link #LIFE_IMPROVED}. */
    public static final float IMPROVED_EXP = 0.8f;
    /** El rayo sale este número de ticks antes de que la bola desaparezca. */
    public static final int FIRE_OFFSET = 2;
    public static final float EXP_GAIN = 0.005f;
    /** Margen añadido a la caja de cada ser vivo al trazar el rayo. */
    public static final double HITBOX_INFLATE = 0.3;

    /** Ángulo máximo respecto a la mirada para colocar la bola (0.45 pi). */
    public static final double MAX_ANGLE = 0.45 * Math.PI;
    public static final double MIN_DIST = 0.8;
    public static final double MAX_DIST = 1.3;
    /** Altura de la bola sobre los pies: de 0.4 a 1.8 (el original: -1.2..0.2 sobre "ojos - 1.6"). */
    public static final double MIN_HEIGHT = 0.4;
    public static final double MAX_HEIGHT = 1.8;

    private ElectronBombRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float damage(float exp) {
        return lerp(6f, 12f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(20f, 10f, exp);
    }

    public static int life(float exp) {
        return exp > IMPROVED_EXP ? LIFE_IMPROVED : LIFE;
    }

    /** Tick (contando desde el clic) en el que sale el rayo. */
    public static int fireTick(float exp) {
        return life(exp) - FIRE_OFFSET;
    }

    public static float expGain(boolean hitLiving) {
        return hitLiving ? EXP_GAIN : 0f;
    }

    /**
     * Posición de la bola respecto a los pies del jugador, fija en esas coordenadas relativas durante su vida.
     *
     * @param yawRadians mirada del jugador al pulsar, convención de Minecraft (0 = +Z)
     * @param r1         aleatorio en [0, 1): ángulo a un lado u otro de la mirada
     * @param r2         aleatorio en [0, 1): distancia horizontal
     * @param r3         aleatorio en [0, 1): altura
     * @return {@code [dx, dy, dz]}
     */
    public static double[] ballOffset(double yawRadians, double r1, double r2, double r3) {
        double angle = yawRadians + (r1 * 2 - 1) * MAX_ANGLE;
        double dist = MIN_DIST + (MAX_DIST - MIN_DIST) * r2;
        double height = MIN_HEIGHT + (MAX_HEIGHT - MIN_HEIGHT) * r3;
        return new double[] {-Math.sin(angle) * dist, height, Math.cos(angle) * dist};
    }
}
