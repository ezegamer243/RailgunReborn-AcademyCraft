package com.railgunreborn.ability.meltdowner;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.meltdowner.MineRayRules.Variant;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * Mining Ray (básico, experto y de suerte): niveles 3/4/5 de Meltdowner, mismo código con una {@link Variant}. Se
 * mantiene la tecla: un rayo desde los ojos rompe uno tras otro los bloques apuntados, soltando sus drops (mano vacía;
 * Fortuna III en la de suerte) y su XP. Ficha: {@code docs/spec/mine-ray.md} (mandan las decisiones del final).
 * Números en {@link MineRayRules}.
 */
public class MineRaySkill extends Skill {
    /** Inicio: rayo que sigue al jugador, arranque y bucle de sonido en los clientes cercanos. */
    public static final String CHANNEL_START = "start";
    /** Bloque que se está minando ({@link #POS_KEY}), solo al cambiar; sin la clave = sin objetivo. */
    public static final String CHANNEL_TARGET = "target";
    /** Bloque roto ({@link #POS_KEY}): chispas finales (las partículas y el sonido de rotura son los de 1.21). */
    public static final String CHANNEL_BREAK = "break";
    /** Fin: quita el rayo y para el bucle. */
    public static final String CHANNEL_STOP = "stop";
    public static final String POS_KEY = "pos";

    private final Variant variant;

    public MineRaySkill(Properties props, Variant variant) {
        super(props);
        this.variant = variant;
    }

    public Variant variant() {
        return variant;
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MineRayContext(player, this);
    }

    /**
     * Trazado del rayo: solo bloques con caja de colisión (atraviesa aire, hierba alta, flores, antorchas y
     * líquidos, como el original); las entidades se ignoran. Null si no hay bloque dentro del alcance.
     */
    @Nullable
    public static BlockHitResult trace(Level level, Vec3 eye, Vec3 look, double range, @Nullable ServerPlayer player) {
        Vec3 end = eye.add(look.normalize().scale(range));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                player == null ? CollisionContext.empty() : CollisionContext.of(player)));
        return hit.getType() == HitResult.Type.BLOCK ? hit : null;
    }

    /** Si la variante llega al nivel de cosecha del bloque y no es indestructible. */
    public static boolean canMine(Variant variant, Level level, BlockPos pos, BlockState state) {
        return !state.isAir() && MineRayRules.canMine(variant, state.getDestroySpeed(level, pos),
                state.is(BlockTags.INCORRECT_FOR_IRON_TOOL));
    }

    /** Herramienta virtual para los drops: mano vacía, o un pico con Fortuna (sin Toque de Seda) en la de suerte. */
    public static ItemStack tool(ServerLevel level, Variant variant) {
        if (variant.fortune <= 0) {
            return ItemStack.EMPTY;
        }
        ItemStack pick = new ItemStack(Items.DIAMOND_PICKAXE);
        pick.enchant(level.registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                .getHolderOrThrow(Enchantments.FORTUNE), variant.fortune);
        return pick;
    }

    /**
     * Rompe el bloque si los permisos lo dejan (comprobados otra vez: pueden haber cambiado desde que se eligió):
     * drops y XP con la herramienta virtual (pasan por {@code BlockDropsEvent}) y después la rotura estándar
     * ({@code destroyBlock} sin drops: partículas y sonido para todos; los contenedores sueltan su contenido).
     *
     * @return true si se rompió
     */
    public static boolean breakBlock(ServerPlayer player, MineRaySkill skill, BlockPos pos) {
        ServerLevel level = player.serverLevel();
        BlockState state = level.getBlockState(pos);
        if (!canMine(skill.variant, level, pos, state) || !BlockPermissions.mayModifyWorld(player, skill)
                || !BlockPermissions.mayBreakAt(player, pos, state)) {
            return false;
        }
        BlockEntity blockEntity = level.getBlockEntity(pos);
        Block.dropResources(state, level, pos, blockEntity, player, tool(level, skill.variant));
        return level.destroyBlock(pos, false, player);
    }

    public static final class MineRayContext extends SkillContext {
        private final MineRaySkill skill;
        private final Variant variant;
        private final float exp;
        private float overloadFloor;
        private boolean started;
        @Nullable
        private BlockPos target;
        @Nullable
        private BlockState targetState;
        private float remaining;
        /** Último bloque descartado (sin permiso o sin nivel): no se vuelve a preguntar mientras se apunte a él. */
        @Nullable
        private BlockPos rejected;
        @Nullable
        private BlockState rejectedState;
        private int broken;

        MineRayContext(ServerPlayer player, MineRaySkill skill) {
            super(player, skill);
            this.skill = skill;
            this.variant = skill.variant;
            this.exp = getSkillExp();
        }

        /** Bloques rotos en este contexto (para pruebas). */
        public int brokenBlocks() {
            return broken;
        }

        @Nullable
        public BlockPos target() {
            return target;
        }

        @Override
        protected void onKeyDown() {
            // Sin CP para el primer tick no se cobra el overload (como Light Shield y Meltdowner).
            if (!canConsume(0f, MineRayRules.cpPerTick(variant, exp))
                    || !consume(MineRayRules.initialOverload(variant, exp), 0f)) {
                terminate();
                return;
            }
            overloadFloor = CPData.get(getPlayer()).getOverload();
            started = true;
            sendEffect(CHANNEL_START, new CompoundTag());
        }

        @Override
        protected void onKeyTick() {
            if (!started) {
                return;
            }
            ServerPlayer player = getPlayer();
            // El overload no se recupera mientras se mantiene el rayo.
            CPData.get(player).raiseOverloadTo(overloadFloor);
            if (!consume(0f, MineRayRules.cpPerTick(variant, exp))) {
                terminate();
                return;
            }
            ServerLevel level = player.serverLevel();
            BlockHitResult hit = trace(level, player.getEyePosition(), player.getViewVector(1.0f), variant.range,
                    player);
            if (hit == null) {
                setTarget(null, null, 0f);
                return;
            }
            BlockPos pos = hit.getBlockPos();
            BlockState state = level.getBlockState(pos);
            if (!pos.equals(target) || state != targetState) {
                select(level, pos, state);
                return;
            }
            remaining -= MineRayRules.speed(variant, exp);
            if (remaining <= 0f) {
                setTarget(null, null, 0f);
                if (breakBlock(player, skill, pos)) {
                    broken++;
                    addSkillExp(variant.expPerBlock);
                    sendEffect(CHANNEL_BREAK, posTag(pos));
                }
            }
        }

        /** Cambio de bloque: se elige sin restar nada este tick; el progreso del anterior se pierde. */
        private void select(ServerLevel level, BlockPos pos, BlockState state) {
            if (pos.equals(rejected) && state == rejectedState) {
                setTarget(null, null, 0f);
                return;
            }
            ServerPlayer player = getPlayer();
            if (canMine(variant, level, pos, state) && BlockPermissions.mayModifyWorld(player, skill)
                    && BlockPermissions.mayBreakAt(player, pos, state)) {
                rejected = null;
                rejectedState = null;
                setTarget(pos.immutable(), state, state.getDestroySpeed(level, pos));
            } else {
                rejected = pos.immutable();
                rejectedState = state;
                setTarget(null, null, 0f);
            }
        }

        private void setTarget(@Nullable BlockPos pos, @Nullable BlockState state, float hardness) {
            boolean changed = pos == null ? target != null : !pos.equals(target);
            target = pos;
            targetState = state;
            remaining = hardness;
            if (changed) {
                sendEffect(CHANNEL_TARGET, pos == null ? new CompoundTag() : posTag(pos));
            }
        }

        private static CompoundTag posTag(BlockPos pos) {
            CompoundTag tag = new CompoundTag();
            tag.put(POS_KEY, NbtUtils.writeBlockPos(pos));
            return tag;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (!started) {
                return;
            }
            started = false;
            if (reason == TerminationReason.LOGOUT) {
                return;
            }
            sendEffect(CHANNEL_STOP, new CompoundTag());
            setCooldown(MineRayRules.cooldown(variant, exp));
        }
    }

    /** Lee la posición de un mensaje {@link #CHANNEL_TARGET}/{@link #CHANNEL_BREAK}; null si no trae. */
    @Nullable
    public static BlockPos readPos(CompoundTag data) {
        return NbtUtils.readBlockPos(data, POS_KEY).orElse(null);
    }
}
