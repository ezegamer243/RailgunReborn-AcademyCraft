package com.railgunreborn.ability.meltdowner;

/**
 * Números y decisiones de Light Shield ({@code docs/spec/light-shield.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class LightShieldRules {
    /** Como máximo un golpe absorbido cada 18 ticks (los que llegan antes pasan enteros). */
    public static final int ACTION_INTERVAL = 18;
    public static final double TOUCH_RADIUS = 3.0;
    /** Medio ángulo del cono frontal, en horizontal. */
    public static final double CONE_DEG = 60.0;
    public static final int SLOW_TICKS = 100;
    /** Lentitud II. */
    public static final int SLOW_AMPLIFIER = 1;
    public static final float EXP_ABSORB = 0.001f;
    public static final float EXP_TOUCH = 0.001f;
    public static final float EXP_TICK = 1e-6f;

    private LightShieldRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float initialOverload(float exp) {
        return lerp(110f, 60f, exp);
    }

    public static float cpPerTick(float exp) {
        return lerp(9f, 4f, exp);
    }

    /** Duración máxima: se termina cuando los ticks activos pasan de este valor. */
    public static int maxTicks(float exp) {
        return (int) lerp(120f, 180f, exp);
    }

    public static float absorbAmount(float exp) {
        return lerp(15f, 50f, exp);
    }

    public static float touchDamage(float exp) {
        return lerp(2f, 6f, exp);
    }

    /** CP por golpe absorbido o por contacto que daña (orden corregido respecto al original, decisión 1). */
    public static float actionCp(float exp) {
        return lerp(50f, 30f, exp);
    }

    /** Overload por golpe absorbido o por contacto que daña. */
    public static float actionOverload(float exp) {
        return lerp(5f, 3f, exp);
    }

    /** {@code (int) lerp(2t, t, exp)} con {@code t} los ticks que estuvo activo. */
    public static int cooldown(float exp, int ticks) {
        return (int) lerp(2f * ticks, ticks, exp);
    }

    public static boolean isOver(int ticks, float exp) {
        return ticks > maxTicks(exp);
    }

    /** Si ya pasó el intervalo desde la última absorción (más de 18 ticks). */
    public static boolean intervalElapsed(int now, int lastAbsorb) {
        return (long) now - lastAbsorb > ACTION_INTERVAL;
    }

    /**
     * Ángulo horizontal (convención de Minecraft: 0 = +Z, 90 = -X) desde el jugador hacia un punto desplazado
     * {@code (dx, dz)}.
     */
    public static double yawTowards(double dx, double dz) {
        return Math.toDegrees(Math.atan2(-dx, dz));
    }

    /** Diferencia normalizada a [-180, 180) (decisión 4: el original no normalizaba el yaw). */
    public static double wrapDegrees(double degrees) {
        double d = degrees % 360.0;
        if (d >= 180.0) {
            d -= 360.0;
        }
        if (d < -180.0) {
            d += 360.0;
        }
        return d;
    }

    /** Si el punto desplazado {@code (dx, dz)} queda en el cono frontal de un jugador con rotación {@code yaw}. */
    public static boolean inCone(double dx, double dz, double yaw) {
        if (dx * dx + dz * dz < 1e-8) {
            return true;
        }
        return Math.abs(wrapDegrees(yawTowards(dx, dz) - yaw)) < CONE_DEG;
    }

    /** Daño que queda tras absorber hasta {@code amount}. */
    public static float absorb(float damage, float amount) {
        return damage - Math.min(damage, Math.max(amount, 0f));
    }
}
