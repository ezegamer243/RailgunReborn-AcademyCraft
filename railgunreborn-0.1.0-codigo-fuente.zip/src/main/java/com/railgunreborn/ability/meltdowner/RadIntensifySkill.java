package com.railgunreborn.ability.meltdowner;

import java.util.Optional;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * β Radiation Intensify: nivel 1, pasiva ({@code docs/spec/rad-intensify.md}, mandan sus decisiones). No tiene tecla:
 * si el atacante la tiene aprendida, {@link MdDamage} marca a los objetivos que daña y, mientras dure la marca, todo
 * el daño que reciben se multiplica ({@link RadIntensifyEvents}). Números en {@link RadIntensifyRules}.
 */
public class RadIntensifySkill extends Skill {
    public RadIntensifySkill(Properties props) {
        super(props);
    }

    /** Exp derivada del CP máximo: {@code CP máx. / CP inicial de nivel 5}. */
    @Override
    public Optional<Float> getDerivedExp(Player player) {
        return Optional.of(RadIntensifyRules.exp(CPData.get(player).getMaxCP(), CPData.initCp(AbilityData.MAX_LEVEL)));
    }

    public boolean isLearnedBy(Player player) {
        return AbilityData.get(player).isLearned(getId());
    }

    /**
     * Marca a {@code target} si {@code attacker} tiene la pasiva: 60 ticks y el multiplicador de su exp actual
     * (reinicia la marca si ya la tenía).
     *
     * @return si marcó
     */
    public boolean tryMark(Player attacker, LivingEntity target) {
        if (!isLearnedBy(attacker) || !target.isAlive()) {
            return false;
        }
        float rate = RadIntensifyRules.rate(getExp(attacker));
        target.setData(ModAttachments.MD_MARK, new MdMark(RadIntensifyRules.MARK_TICKS, rate));
        return true;
    }

    /** Marca activa de {@code entity}, o null. No crea el attachment. */
    public static MdMark activeMark(LivingEntity entity) {
        MdMark mark = entity.getExistingDataOrNull(ModAttachments.MD_MARK);
        return mark != null && mark.isActive() ? mark : null;
    }
}
