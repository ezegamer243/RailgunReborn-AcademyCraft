package com.railgunreborn.ability.meltdowner;

/**
 * Numeros y decisiones de Scatter Bomb ({@code docs/spec/scatter-bomb.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leida al pulsar.
 */
public final class ScatterBombRules {
    public static final int MAX_BALLS = 7;
    /** Primer tick con bola; luego una cada {@link #BALL_INTERVAL}. */
    public static final int FIRST_BALL_TICK = 20;
    public static final int BALL_INTERVAL = 10;
    /** Hasta este tick (inclusive) se crean bolas y se paga CP. */
    public static final int MAX_CP_TICKS = 80;
    /** A este tick se hace dano propio y se dispara. */
    public static final int BLOW_TICK = 200;
    public static final float SELF_DAMAGE = 6f;
    public static final float EXP_PER_BALL = 0.001f;

    /** Dispersion maxima (grados) a cada lado de la mirada, en horizontal y vertical. */
    public static final double SCATTER_DEG = 12.5;
    /** Dos tramos de 15 bloques como el original: el destino queda a ~30 bloques. */
    public static final double RANGE_A = 15;
    public static final double RANGE_B = 15;
    public static final double AUTO_RADIUS = 5;
    /** Con exp estrictamente mayor que esto hay autoapuntado. */
    public static final float AUTO_EXP = 0.5f;

    private ScatterBombRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float initialOverload(float exp) {
        return lerp(80f, 60f, exp);
    }

    public static float cpPerTick(float exp) {
        return lerp(3f, 6f, exp);
    }

    public static float damage(float exp) {
        return lerp(5f, 9f, exp);
    }

    public static boolean canSpawnBall(int ticks) {
        return ticks >= FIRST_BALL_TICK && ticks <= MAX_CP_TICKS && ticks % BALL_INTERVAL == 0;
    }

    public static boolean paysCp(int ticks) {
        return ticks >= 1 && ticks <= MAX_CP_TICKS;
    }

    public static boolean isBlowTick(int ticks) {
        return ticks >= BLOW_TICK;
    }

    /** Bolas que apuntan solas a mobs cercanos: {@code (int)(bolas * exp)} si exp > 0.5. */
    public static int autoCount(int balls, float exp) {
        return exp > AUTO_EXP ? (int) (balls * exp) : 0;
    }

    public static float expGain(int hits) {
        return EXP_PER_BALL * hits;
    }

    /**
     * Direccion de una bola: la mirada desviada hasta {@link #SCATTER_DEG} grados en horizontal y vertical, relativa a
     * la mirada (decision 10 de la ficha).
     *
     * @param look vector de mirada (unitario)
     * @param r1   aleatorio en [0, 1): desvio lateral
     * @param r2   aleatorio en [0, 1): desvio vertical
     * @return vector unitario {@code [x, y, z]}
     */
    public static double[] scatterDirection(double[] look, double r1, double r2) {
        double rx = -look[2];
        double rz = look[0];
        double len = Math.hypot(rx, rz);
        double[] right = len < 1e-6 ? new double[] {1, 0, 0} : new double[] {rx / len, 0, rz / len};
        // up = right x look
        double[] up = {right[1] * look[2] - right[2] * look[1], right[2] * look[0] - right[0] * look[2],
                right[0] * look[1] - right[1] * look[0]};
        double yaw = Math.tan(Math.toRadians((r1 - 0.5) * 2 * SCATTER_DEG));
        double pitch = Math.tan(Math.toRadians((r2 - 0.5) * 2 * SCATTER_DEG));
        double[] d = new double[3];
        double norm = 0;
        for (int i = 0; i < 3; i++) {
            d[i] = look[i] + right[i] * yaw + up[i] * pitch;
            norm += d[i] * d[i];
        }
        norm = Math.sqrt(norm);
        for (int i = 0; i < 3; i++) {
            d[i] /= norm;
        }
        return d;
    }
}
