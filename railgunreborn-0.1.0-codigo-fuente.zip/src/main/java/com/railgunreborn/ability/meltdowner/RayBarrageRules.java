package com.railgunreborn.ability.meltdowner;

/**
 * Números y decisiones de Ray Barrage ({@code docs/spec/ray-barrage.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class RayBarrageRules {
    /** Alcance de la búsqueda del barn, del rayo directo y de la zona del abanico. */
    public static final double RANGE = 20.0;
    public static final float EXP_GAIN = 0.005f;
    /** Zona del abanico (decisión 2: como el dibujo): ±55° en horizontal y ±27.5° en vertical respecto a la mirada. */
    public static final double FAN_HALF_YAW = 55.0;
    public static final double FAN_HALF_PITCH = 27.5;

    /** Dibujo del abanico (§9.2): 25-29 sub-rayos de 15 bloques, desvío ±R (R entre 50 y 60°) y ±R/2 en vertical. */
    public static final int FAN_RAYS_MIN = 25;
    public static final int FAN_RAYS_MAX = 29;
    public static final double FAN_SPREAD_MIN = 50.0;
    public static final double FAN_SPREAD_MAX = 60.0;
    public static final double FAN_RAY_LENGTH = 15.0;

    private RayBarrageRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cp(float exp) {
        return lerp(450f, 380f, exp);
    }

    public static float overload(float exp) {
        return lerp(300f, 140f, exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(100f, 40f, exp);
    }

    /** Daño a cada ser vivo dentro del abanico. */
    public static float damageFan(float exp) {
        return lerp(10f, 18f, exp);
    }

    /** Daño del rayo directo (sin barn) al ser vivo mirado. */
    public static float damageDirect(float exp) {
        return lerp(25f, 60f, exp);
    }

    /** Decisión 2: exp solo si el disparo dañó al menos a un ser vivo. */
    public static float expGain(boolean hurtSomeone) {
        return hurtSomeone ? EXP_GAIN : 0f;
    }

    /** Ángulo en (-180, 180]. */
    public static double wrapDegrees(double degrees) {
        double d = degrees % 360.0;
        if (d > 180.0) {
            d -= 360.0;
        } else if (d <= -180.0) {
            d += 360.0;
        }
        return d;
    }

    /** Yaw de Minecraft (grados, 0 = +Z, 90 = -X) de la dirección {@code (dx, dz)}. */
    public static double yawOf(double dx, double dz) {
        return Math.toDegrees(Math.atan2(-dx, dz));
    }

    /** Pitch de Minecraft (grados, positivo = hacia abajo) de la dirección {@code (dx, dy, dz)}. */
    public static double pitchOf(double dx, double dy, double dz) {
        return Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));
    }

    /**
     * Si el punto {@code (tx, ty, tz)} cae dentro de la zona del abanico vista desde {@code (ox, oy, oz)} con la
     * mirada {@code (yaw, pitch)} (grados de Minecraft): a menos de {@code range} y con la diferencia de yaw y de
     * pitch dentro de los semiángulos. Se compara con los ángulos de la mirada, igual que se dibujan los sub-rayos.
     */
    public static boolean isInFan(double ox, double oy, double oz, double yaw, double pitch, double tx, double ty,
            double tz, double halfYaw, double halfPitch, double range) {
        double dx = tx - ox;
        double dy = ty - oy;
        double dz = tz - oz;
        double distSqr = dx * dx + dy * dy + dz * dz;
        if (distSqr < 1.0e-8 || distSqr > range * range) {
            return false;
        }
        double yawDiff = Math.abs(wrapDegrees(yawOf(dx, dz) - yaw));
        double pitchDiff = Math.abs(pitchOf(dx, dy, dz) - pitch);
        return yawDiff <= halfYaw && pitchDiff <= halfPitch;
    }

    /** {@link #isInFan} con la zona de la decisión 2 y el alcance de la habilidad. */
    public static boolean isInFan(double ox, double oy, double oz, double yaw, double pitch, double tx, double ty,
            double tz) {
        return isInFan(ox, oy, oz, yaw, pitch, tx, ty, tz, FAN_HALF_YAW, FAN_HALF_PITCH, RANGE);
    }
}
