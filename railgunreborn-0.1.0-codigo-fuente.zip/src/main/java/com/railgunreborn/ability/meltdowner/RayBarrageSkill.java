package com.railgunreborn.ability.meltdowner;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.entity.SilbarnEntity;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Ray Barrage: nivel 4 de Meltdowner. Un clic con dos modos (ficha {@code docs/spec/ray-barrage.md}, mandan las
 * decisiones del final): mirando a un Silicon Barn usable lo gasta y desata un abanico que daña a todos los seres vivos
 * de la zona delante del jugador; sin barn, un rayo directo de 20 bloques al ser vivo mirado. Números en
 * {@link RayBarrageRules}.
 */
public class RayBarrageSkill extends Skill {
    /**
     * Canal {@code shot}: {@link #FROM_KEY}/{@link #TO_KEY} (rayo previo), {@link #BARN_KEY} (si hubo abanico) y, en
     * ese caso, {@link #BARN_POS_KEY}, {@link #YAW_KEY}, {@link #PITCH_KEY} y {@link #TARGETS_KEY} (centros dañados).
     */
    public static final String CHANNEL_SHOT = "shot";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";
    public static final String BARN_KEY = "barn";
    public static final String BARN_POS_KEY = "barn_pos";
    public static final String YAW_KEY = "yaw";
    public static final String PITCH_KEY = "pitch";
    public static final String TARGETS_KEY = "targets";
    /** Máximo de rayos extra hacia los afectados que se mandan al cliente. */
    public static final int MAX_TARGET_RAYS = 32;

    public RayBarrageSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new RayBarrageContext(player, this);
    }

    /** Seres vivos que puede dañar la habilidad (sin soportes de armadura: decisión 4 de la ficha). */
    static boolean isVictim(Entity entity) {
        return SkillTargets.isTargetable(entity) && !(entity instanceof ArmorStand);
    }

    /** Seres vivos dentro de la zona del abanico de {@code player} (desde sus ojos, con su mirada actual). */
    public static List<LivingEntity> fanTargets(ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        // Ángulos de la mirada real (la de getViewVector, que usa la cabeza), no de getYRot.
        Vec3 look = player.getViewVector(1.0f);
        double yaw = RayBarrageRules.yawOf(look.x, look.z);
        double pitch = RayBarrageRules.pitchOf(look.x, look.y, look.z);
        AABB box = new AABB(eye, eye).inflate(RayBarrageRules.RANGE + 1.0);
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, box, RayBarrageSkill::isVictim)) {
            Vec3 c = entity.getBoundingBox().getCenter();
            if (RayBarrageRules.isInFan(eye.x, eye.y, eye.z, yaw, pitch, c.x, c.y, c.z)) {
                result.add((LivingEntity) entity);
            }
        }
        return result;
    }

    private static final class RayBarrageContext extends SkillContext {
        private final RayBarrageSkill skill;
        private final float exp;

        RayBarrageContext(ServerPlayer player, RayBarrageSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            // Sin CP u overload suficiente no pasa nada: ni barn, ni cooldown, ni efecto.
            if (!consume(RayBarrageRules.overload(exp), RayBarrageRules.cp(exp))) {
                terminate();
                return;
            }
            ServerPlayer player = getPlayer();
            Vec3 eye = player.getEyePosition();
            SilbarnEntity barn = SilbarnEntity.findLookedAt(player, RayBarrageRules.RANGE);
            CompoundTag data = new CompoundTag();
            data.put(FROM_KEY, ElectronBombSkill.vec(eye));
            boolean hurt = false;

            if (barn != null && barn.consume()) {
                ListTag targets = new ListTag();
                float damage = RayBarrageRules.damageFan(exp);
                for (LivingEntity target : fanTargets(player)) {
                    if (MdDamage.attack(player, skill, ModDamageTypes.RAY_BARRAGE, target, damage)) {
                        hurt = true;
                        if (targets.size() < MAX_TARGET_RAYS) {
                            targets.add(ElectronBombSkill.vec(target.getBoundingBox().getCenter()));
                        }
                    }
                }
                Vec3 center = barn.getCenter();
                data.put(TO_KEY, ElectronBombSkill.vec(center));
                data.putBoolean(BARN_KEY, true);
                data.put(BARN_POS_KEY, ElectronBombSkill.vec(center));
                Vec3 look = player.getViewVector(1.0f);
                data.putFloat(YAW_KEY, (float) RayBarrageRules.yawOf(look.x, look.z));
                data.putFloat(PITCH_KEY, (float) RayBarrageRules.pitchOf(look.x, look.y, look.z));
                data.put(TARGETS_KEY, targets);
            } else {
                Vec3 to = eye.add(player.getViewVector(1.0f).scale(RayBarrageRules.RANGE));
                ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, eye, to);
                Vec3 end = hit.end();
                if (hit.entity() != null && isVictim(hit.entity())) {
                    hurt = MdDamage.attack(player, skill, ModDamageTypes.RAY_BARRAGE, hit.entity(),
                            RayBarrageRules.damageDirect(exp));
                    // Como el original: el rayo acaba a un 60 % de la altura de los ojos de la entidad.
                    end = hit.entity().position().add(0, hit.entity().getEyeHeight() * 0.6, 0);
                }
                data.put(TO_KEY, ElectronBombSkill.vec(end));
                data.putBoolean(BARN_KEY, false);
            }

            float gain = RayBarrageRules.expGain(hurt);
            if (gain > 0) {
                addSkillExp(gain);
            }
            setCooldown(RayBarrageRules.cooldown(exp));
            sendEffect(CHANNEL_SHOT, data);
            terminate();
        }
    }
}
