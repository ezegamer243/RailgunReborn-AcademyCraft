package com.railgunreborn.ability.meltdowner;

/**
 * Números y reglas de las tres Mining Ray ({@code docs/spec/mine-ray.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class MineRayRules {
    /** Las tres variantes: solo cambian los números, el nivel de cosecha y la Fortuna. */
    public enum Variant {
        BASIC("mine_ray_basic", 10.0, false, 0, 0.0005f,
                12f, 7f, 200f, 150f, 40f, 20f, 0.2f, 0.4f),
        EXPERT("mine_ray_expert", 20.0, true, 0, 0.0003f,
                25f, 15f, 300f, 200f, 60f, 30f, 0.5f, 1.0f),
        LUCK("mine_ray_luck", 20.0, true, 3, 0.0003f,
                50f, 35f, 350f, 300f, 60f, 30f, 0.5f, 1.0f);

        public final String path;
        /** Alcance del trazado en bloques. */
        public final double range;
        /** true = todo lo que no sea indestructible; false = hasta nivel hierro (no obsidiana). */
        public final boolean unlimitedTier;
        /** Nivel de Fortuna de la herramienta virtual (0 = mano vacía). */
        public final int fortune;
        /** Exp por bloque roto. */
        public final float expPerBlock;
        private final float cp0;
        private final float cp1;
        private final float overload0;
        private final float overload1;
        private final float cooldown0;
        private final float cooldown1;
        private final float speed0;
        private final float speed1;

        Variant(String path, double range, boolean unlimitedTier, int fortune, float expPerBlock, float cp0,
                float cp1, float overload0, float overload1, float cooldown0, float cooldown1, float speed0,
                float speed1) {
            this.path = path;
            this.range = range;
            this.unlimitedTier = unlimitedTier;
            this.fortune = fortune;
            this.expPerBlock = expPerBlock;
            this.cp0 = cp0;
            this.cp1 = cp1;
            this.overload0 = overload0;
            this.overload1 = overload1;
            this.cooldown0 = cooldown0;
            this.cooldown1 = cooldown1;
            this.speed0 = speed0;
            this.speed1 = speed1;
        }
    }

    private MineRayRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** CP por tick mientras se mantiene (haya o no bloque apuntado). */
    public static float cpPerTick(Variant v, float exp) {
        return lerp(v.cp0, v.cp1, exp);
    }

    /** Overload que se cobra una vez al pulsar. */
    public static float initialOverload(Variant v, float exp) {
        return lerp(v.overload0, v.overload1, exp);
    }

    /** Cooldown al terminar el contexto, en ticks. */
    public static int cooldown(Variant v, float exp) {
        return (int) lerp(v.cooldown0, v.cooldown1, exp);
    }

    /** Dureza restada por tick al mismo bloque. */
    public static float speed(Variant v, float exp) {
        return lerp(v.speed0, v.speed1, exp);
    }

    /**
     * Si la variante puede minar un bloque de esta dureza.
     *
     * @param needsBetterThanIron el bloque está en {@code incorrect_for_iron_tool} (obsidiana, escombros antiguos...)
     */
    public static boolean canMine(Variant v, float hardness, boolean needsBetterThanIron) {
        return hardness >= 0f && (v.unlimitedTier || !needsBetterThanIron);
    }

    /**
     * Ticks hasta romper un bloque desde que se apunta: 1 para elegirlo y luego uno por cada resta de dureza.
     * Simula la misma resta en float que el contexto (por los redondeos puede diferir de la fórmula cerrada).
     */
    public static int ticksToBreak(float hardness, float speed) {
        if (hardness < 0f || speed <= 0f) {
            return Integer.MAX_VALUE;
        }
        float remaining = hardness;
        int ticks = 1;
        do {
            remaining -= speed;
            ticks++;
        } while (remaining > 0f);
        return ticks;
    }
}
