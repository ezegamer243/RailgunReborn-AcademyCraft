package com.railgunreborn.ability.meltdowner;

/**
 * Números y decisiones de Jet Engine ({@code docs/spec/jet-engine.md}), en Java puro para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class JetEngineRules {
    /** Alcance del trazado del destino (desde los ojos, [DUDA] 3). */
    public static final double REACH = 12.0;
    /** Ticks que tarda el dash en llegar al destino. */
    public static final int TRAVEL_TICKS = 8;
    /** Ticks de vuelo (escudo, partículas, sin caída) contados desde que se suelta. */
    public static final int FLIGHT_TICKS = 15;
    public static final float EXP_GAIN = 0.004f;
    /** Margen de la caja del jugador al barrer el recorrido en busca de seres vivos. */
    public static final double HIT_MARGIN = 0.3;
    /** Color de la marca de destino: RGBA 51, 255, 51, 179. */
    public static final int MARK_RED = 51;
    public static final int MARK_GREEN = 255;
    public static final int MARK_BLUE = 51;
    public static final float MARK_ALPHA = 179f / 255f;

    private JetEngineRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** CP que se gasta al soltar (decisión 1: el valor real del original). */
    public static float cpCost(float exp) {
        return lerp(60f, 50f, exp);
    }

    /** Overload que se añade al soltar (decisión 1). */
    public static float overload(float exp) {
        return lerp(170f, 140f, exp);
    }

    /** CP que hace falta tener mientras se mantiene la tecla: el mismo que se gastará ([DUDA] 1). */
    public static float cpToHold(float exp) {
        return cpCost(exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(60f, 30f, exp);
    }

    public static float damage(float exp) {
        return lerp(7f, 20f, exp);
    }

    /** Fracción del recorrido hecha al final del tick {@code tick} del dash: llega en 8 y se queda (decisión 2). */
    public static double progress(int tick) {
        if (tick <= 0) {
            return 0.0;
        }
        return Math.min(1.0, tick / (double) TRAVEL_TICKS);
    }

    /** Posición prevista (x, y, z) al final del tick {@code tick} del dash, sin pasar nunca del destino. */
    public static double[] dashPosition(double[] start, double[] dest, int tick) {
        double t = progress(tick);
        return new double[] {
                start[0] + (dest[0] - start[0]) * t,
                start[1] + (dest[1] - start[1]) * t,
                start[2] + (dest[2] - start[2]) * t};
    }

    /**
     * Paso máximo por tick que el cliente aplica para corregir hacia la posición prevista: el doble del paso nominal
     * (si una colisión lo frenó, recupera algo, pero no salta de golpe cuando el obstáculo desaparece).
     */
    public static double maxStep(double distance) {
        return Math.max(0.5, 2.0 * distance / TRAVEL_TICKS);
    }

    /** Si el dash ya llegó (desde aquí el cliente deja de empujar). */
    public static boolean arrived(int tick) {
        return tick >= TRAVEL_TICKS;
    }

    /** Si el vuelo (escudo y protección de caída) terminó tras {@code tick} ticks. */
    public static boolean flightOver(int tick) {
        return tick >= FLIGHT_TICKS;
    }

    /**
     * Un destino recibido por la red es creíble si está a lo sumo a {@link #REACH} de los ojos; desde los pies se
     * admite además la altura de los ojos y algo de margen por latencia.
     */
    public static boolean plausibleDestination(double distanceFromFeet) {
        return Double.isFinite(distanceFromFeet) && distanceFromFeet <= REACH + 4.0;
    }
}
