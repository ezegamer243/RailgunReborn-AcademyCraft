package com.railgunreborn.ability.meltdowner;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Daño común de las habilidades de Meltdowner ({@code MDDamageHelper} del original, {@code rad-intensify.md} §6):
 * respeta el PvP del servidor, aplica {@code damage_scale} de la habilidad, daña con su {@link DamageType} (con
 * armadura) y, si el golpe se aplicó y el atacante tiene Rad Intensify, marca al objetivo.
 */
public final class MdDamage {
    // TODO(config): attackPlayer de la ficha, como en Arc Gen.
    public static final boolean ATTACK_PLAYER = true;

    private MdDamage() {
    }

    /** {@link #attack(ServerPlayer, Skill, ResourceKey, Entity, float, boolean, boolean)} marcando y sin saltar la invulnerabilidad. */
    public static boolean attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage) {
        return attack(player, skill, type, target, damage, true, false);
    }

    /**
     * @param damage               daño antes de {@code damage_scale}
     * @param marks                si el golpe puede dejar la marca de Rad Intensify (Meltdowner y las bolas: sí)
     * @param ignoreInvulnerability pone a 0 los ticks de invulnerabilidad antes de dañar (varios impactos en el mismo
     *                             tick, como las bolas de Scatter Bomb)
     * @return si el daño se aplicó (un jugador protegido por PvP, un objetivo invulnerable... devuelven false: sin exp
     *         ni marca)
     */
    public static boolean attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage, boolean marks, boolean ignoreInvulnerability) {
        if (target == player || !SkillTargets.mayHarm(player, target, ATTACK_PLAYER)) {
            return false;
        }
        if (ignoreInvulnerability) {
            target.invulnerableTime = 0;
        }
        boolean hurt = target.hurt(ModDamageTypes.source(player, type), damage * skill.getDamageScale());
        if (hurt && marks && target instanceof LivingEntity living) {
            Meltdowner.RAD_INTENSIFY.get().tryMark(player, living);
        }
        return hurt;
    }
}
