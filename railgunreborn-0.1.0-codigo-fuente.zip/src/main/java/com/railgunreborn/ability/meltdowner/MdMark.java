package com.railgunreborn.ability.meltdowner;

/**
 * Marca de Rad Intensify en un ser vivo (attachment {@code MD_MARK}, solo servidor, no se guarda): ticks restantes y
 * multiplicador fijado al marcar con la exp del atacante en ese momento.
 */
public final class MdMark {
    private int ticks;
    private float rate = 1f;

    public MdMark() {
    }

    public MdMark(int ticks, float rate) {
        this.ticks = ticks;
        this.rate = rate;
    }

    public int ticks() {
        return ticks;
    }

    public float rate() {
        return rate;
    }

    public boolean isActive() {
        return ticks > 0;
    }

    /** Descuenta un tick; devuelve si sigue activa. */
    boolean tickDown() {
        if (ticks > 0) {
            ticks--;
        }
        return ticks > 0;
    }
}
