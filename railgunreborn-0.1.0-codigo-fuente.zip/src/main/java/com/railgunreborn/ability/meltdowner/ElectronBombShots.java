package com.railgunreborn.ability.meltdowner;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.network.SkillEffectPayload;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Disparos pendientes de Electron Bomb: la bola ya no depende de ningún contexto, así que pueden solaparse varias.
 * Se avanzan en el tick del servidor (bus del juego). Si el jugador muere, se desconecta o cambia de dimensión, el
 * disparo se cancela sin daño ni exp (decisión 7 de la ficha).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class ElectronBombShots {
    private static final List<Shot> PENDING = new ArrayList<>();

    private ElectronBombShots() {
    }

    private static final class Shot {
        final ServerPlayer player;
        final ServerLevel level;
        final Skill skill;
        final float exp;
        final Vec3 offset;
        int ticksLeft;

        Shot(ServerPlayer player, Skill skill, float exp, Vec3 offset) {
            this.player = player;
            this.level = player.serverLevel();
            this.skill = skill;
            this.exp = exp;
            this.offset = offset;
            this.ticksLeft = ElectronBombRules.fireTick(exp);
        }
    }

    static void add(ServerPlayer player, Skill skill, float exp, Vec3 offset) {
        PENDING.add(new Shot(player, skill, exp, offset));
    }

    public static int pendingCount() {
        return PENDING.size();
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (PENDING.isEmpty()) {
            return;
        }
        for (Shot shot : new ArrayList<>(PENDING)) {
            if (!shot.player.isAlive() || shot.player.hasDisconnected() || shot.player.isRemoved()
                    || shot.player.serverLevel() != shot.level) {
                PENDING.remove(shot);
            } else if (--shot.ticksLeft <= 0) {
                PENDING.remove(shot);
                fire(shot);
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        PENDING.clear();
    }

    private static void fire(Shot shot) {
        ServerPlayer player = shot.player;
        // Origen: donde se ve la bola, siguiendo al jugador; destino: hacia donde mira ahora.
        Vec3 from = player.position().add(shot.offset);
        Vec3 to = ElectronBombSkill.aimPoint(player);
        ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, from, to);

        boolean hurt = false;
        if (hit.entity() != null) {
            hurt = MdDamage.attack(player, shot.skill, ModDamageTypes.ELECTRON_BOMB, hit.entity(),
                    ElectronBombRules.damage(shot.exp));
        }
        float gain = ElectronBombRules.expGain(hurt);
        if (gain > 0) {
            AbilityData.get(player).addSkillExp(shot.skill.getId(), gain * shot.skill.getExpIncrSpeed());
        }

        CompoundTag data = new CompoundTag();
        data.put(ElectronBombSkill.FROM_KEY, ElectronBombSkill.vec(from));
        data.put(ElectronBombSkill.TO_KEY, ElectronBombSkill.vec(hit.end()));
        PacketDistributor.sendToPlayersNear(shot.level, null, player.getX(), player.getY(), player.getZ(),
                SkillContext.DEFAULT_EFFECT_RANGE,
                new SkillEffectPayload(player.getId(), shot.skill, 0, ElectronBombSkill.CHANNEL_RAY, data));
    }
}
