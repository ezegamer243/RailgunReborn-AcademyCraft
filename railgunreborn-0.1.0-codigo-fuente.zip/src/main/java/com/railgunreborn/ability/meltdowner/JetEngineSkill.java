package com.railgunreborn.ability.meltdowner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Jet Engine: nivel 4 de Meltdowner. Se mantiene para apuntar (marca verde en el destino, solo en el cliente local) y
 * al soltar el jugador sale disparado en línea recta hasta ese punto en 8 ticks, dañando a los seres vivos que
 * atraviesa. Ficha: {@code docs/spec/jet-engine.md} (mandan las decisiones del final). Números en
 * {@link JetEngineRules}.
 *
 * <p>Como Magnet Movement, el servidor cobra y fija el destino y el cliente local mueve al jugador (con colisiones).
 * El servidor barre cada tick el tramo que el jugador recorrió de verdad para dañar, y evita la caída y la expulsión
 * por "volar".
 */
public class JetEngineSkill extends Skill {
    /** Al soltar con éxito. Al cliente local: {@link #START_KEY} y {@link #DEST_KEY}; efecto: {@link #DEST_KEY}. */
    public static final String CHANNEL_DASH = "dash";
    /** Fin del vuelo: quita escudo y partículas. */
    public static final String CHANNEL_STOP = "stop";
    public static final String START_KEY = "start";
    public static final String DEST_KEY = "dest";

    public JetEngineSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new JetEngineContext(player, this);
    }

    /**
     * Destino del dash (ficha §4.1 con [DUDA] 3): trazado de {@link JetEngineRules#REACH} bloques desde los ojos, solo
     * contra bloques con colisión (atraviesa plantas, líquidos y entidades); el punto de choque o el final del trazado.
     * Sirve en ambos lados (el cliente dibuja la marca con el mismo cálculo).
     */
    public static Vec3 destination(Player player) {
        Vec3 eyes = player.getEyePosition();
        Vec3 end = eyes.add(player.getViewVector(1.0f).scale(JetEngineRules.REACH));
        HitResult hit = player.level().clip(new ClipContext(eyes, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        return hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
    }

    /**
     * Seres vivos que toca la caja del jugador (+{@link JetEngineRules#HIT_MARGIN}) al ir de {@code from} a su
     * posición actual, sin el propio jugador.
     */
    public static List<LivingEntity> sweptTargets(Player player, Vec3 from) {
        AABB swept = player.getBoundingBox().expandTowards(from.subtract(player.position()))
                .inflate(JetEngineRules.HIT_MARGIN);
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, swept, SkillTargets::isTargetable)) {
            result.add((LivingEntity) entity);
        }
        return result;
    }

    /** Vuelo activo del jugador, o null. */
    @Nullable
    public static JetEngineContext activeDash(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof JetEngineContext jet && !jet.isTerminated() && jet.flying) {
                return jet;
            }
        }
        return null;
    }

    public static final class JetEngineContext extends SkillContext {
        private final JetEngineSkill skill;
        private final float exp;
        private final Set<Integer> hit = new HashSet<>();
        private boolean flying;
        private int flightTicks;
        private Vec3 lastPos = Vec3.ZERO;
        private Vec3 dest = Vec3.ZERO;

        JetEngineContext(ServerPlayer player, JetEngineSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        /** Destino oficial fijado al soltar (para pruebas). */
        public Vec3 destination() {
            return dest;
        }

        public int flightTicks() {
            return flightTicks;
        }

        @Override
        protected void onKeyDown() {
            // No se cobra al pulsar (como el original); solo se comprueba que alcance el CP.
            if (!canConsume(0f, JetEngineRules.cpToHold(exp))) {
                terminate();
            }
        }

        @Override
        protected void onKeyTick() {
            // Decisión 2: el CP solo se vigila mientras se apunta.
            if (!canConsume(0f, JetEngineRules.cpToHold(exp))) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            if (!consume(JetEngineRules.overload(exp), JetEngineRules.cpCost(exp))) {
                terminate();
                return;
            }
            ServerPlayer player = getPlayer();
            player.stopRiding();
            Vec3 start = player.position();
            dest = JetEngineSkill.destination(player);
            addSkillExp(JetEngineRules.EXP_GAIN);
            setCooldown(JetEngineRules.cooldown(exp));
            flying = true;
            lastPos = start;
            player.resetFallDistance();
            MagMovementSkill.resetFlying(player);

            CompoundTag local = new CompoundTag();
            MagMovementSkill.writeVec(local, START_KEY, start);
            MagMovementSkill.writeVec(local, DEST_KEY, dest);
            sendToLocal(CHANNEL_DASH, local);
            CompoundTag effect = new CompoundTag();
            MagMovementSkill.writeVec(effect, DEST_KEY, dest);
            sendEffect(CHANNEL_DASH, effect);
        }

        @Override
        protected void tick() {
            if (!flying) {
                return;
            }
            ServerPlayer player = getPlayer();
            flightTicks++;
            player.stopRiding();
            player.resetFallDistance();
            MagMovementSkill.resetFlying(player);
            sweep(player);
            if (JetEngineRules.flightOver(flightTicks)) {
                terminate();
            }
        }

        /** Daña una sola vez a cada ser vivo del tramo recorrido desde el tick anterior ([DUDA] 5). */
        private void sweep(ServerPlayer player) {
            Vec3 now = player.position();
            // Un salto absurdo (teletransporte, cambio de dimensión) no es un recorrido: no daña.
            if (now.distanceTo(lastPos) <= JetEngineRules.REACH * 2) {
                for (LivingEntity target : sweptTargets(player, lastPos)) {
                    if (!hit.contains(target.getId()) && MdDamage.attack(player, skill, ModDamageTypes.JET_ENGINE,
                            target, JetEngineRules.damage(exp))) {
                        hit.add(target.getId());
                    }
                }
            }
            lastPos = now;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (!flying) {
                return;
            }
            flying = false;
            sendEffect(CHANNEL_STOP, new CompoundTag());
            if (reason == TerminationReason.DEATH || reason == TerminationReason.LOGOUT) {
                return;
            }
            ServerPlayer player = getPlayer();
            player.resetFallDistance();
            MagMovementSkill.resetFlying(player);
        }
    }
}
