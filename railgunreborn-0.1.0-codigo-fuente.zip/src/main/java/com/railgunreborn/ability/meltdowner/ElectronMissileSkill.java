package com.railgunreborn.ability.meltdowner;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * Electron Missile: nivel 5 de Meltdowner. Torreta automática mientras se mantiene la tecla: una bola cada 10 ticks
 * (máx. 5) delante del jugador y, cada 8 ticks, una bola dispara al ser vivo más cercano al alcance (sin línea de
 * visión). Ficha {@code docs/spec/electron-missile.md} (mandan las decisiones del final). Números en
 * {@link ElectronMissileRules}.
 */
public class ElectronMissileSkill extends Skill {
    /** Inicio: {@link #MAX_TICKS_KEY} (duración máxima, para el contorno del icono). */
    public static final String CHANNEL_START = "start";
    /** Nueva bola: {@link #BALL_KEY} y {@link ElectronBombSkill#OFFSET_KEY}. */
    public static final String CHANNEL_BALL = "ball_spawn";
    /** Ataque: {@link #BALL_KEY} (bola gastada), {@link ElectronBombSkill#FROM_KEY}/{@link ElectronBombSkill#TO_KEY}. */
    public static final String CHANNEL_ATTACK = "ball_attack";
    /** Fin: borra todas las bolas. */
    public static final String CHANNEL_STOP = "stop";
    public static final String BALL_KEY = "ball";
    public static final String MAX_TICKS_KEY = "max_ticks";

    public ElectronMissileSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ElectronMissileContext(player, this);
    }

    /** Si la torreta puede elegir a {@code entity} como objetivo (decisión 2 de la ficha). */
    public static boolean isTarget(ServerPlayer player, Entity entity) {
        return SkillTargets.isTargetable(entity) && ElectronMissileRules.isValidTarget(entity == player,
                entity instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID()),
                entity instanceof ArmorStand, !SkillTargets.mayHarm(player, entity, MdDamage.ATTACK_PLAYER));
    }

    /** El ser vivo válido más cercano a los pies del jugador dentro de {@code range}, o null. */
    public static @Nullable LivingEntity closestTarget(ServerPlayer player, double range) {
        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate(range + 1.0),
                e -> isTarget(player, e))) {
            candidates.add((LivingEntity) entity);
        }
        return ElectronMissileRules.pickClosest(candidates, e -> e.distanceToSqr(player), range);
    }

    private record Ball(int id, Vec3 offset) {
    }

    public static final class ElectronMissileContext extends SkillContext {
        private final ElectronMissileSkill skill;
        private final float exp;
        private final List<Ball> balls = new ArrayList<>();
        private int ticks;
        private int nextBallId;
        private float overloadFloor;
        private boolean started;

        ElectronMissileContext(ServerPlayer player, ElectronMissileSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        /** Bolas activas (para pruebas). */
        public int ballCount() {
            return balls.size();
        }

        @Override
        protected void onKeyDown() {
            if (!consume(ElectronMissileRules.OVERLOAD_START, 0f)) {
                terminate();
                return;
            }
            started = true;
            overloadFloor = CPData.get(getPlayer()).getOverload();
            CompoundTag data = new CompoundTag();
            data.putInt(MAX_TICKS_KEY, ElectronMissileRules.maxTicks(exp));
            sendEffect(CHANNEL_START, data);
        }

        @Override
        protected void onKeyTick() {
            ServerPlayer player = getPlayer();
            // El overload no se recupera mientras se mantiene (los ataques sí lo suben).
            CPData.get(player).raiseOverloadTo(overloadFloor);
            if (!consume(0f, ElectronMissileRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            int tick = ticks++;
            if (tick > ElectronMissileRules.maxTicks(exp)) {
                terminate();
                return;
            }
            if (ElectronMissileRules.spawnsBall(tick, balls.size())) {
                addBall(player);
            }
            if (ElectronMissileRules.isAttackTick(tick) && !balls.isEmpty()) {
                attack(player);
            }
        }

        private void addBall(ServerPlayer player) {
            var random = player.getRandom();
            // ballOffset ya da la altura dibujada (pies + 0.4..1.8): el rayo sale de donde se ve la bola.
            double[] o = ElectronBombRules.ballOffset(Math.toRadians(player.getYRot()), random.nextDouble(),
                    random.nextDouble(), random.nextDouble());
            Ball ball = new Ball(nextBallId++, new Vec3(o[0], o[1], o[2]));
            balls.add(ball);
            CompoundTag data = new CompoundTag();
            data.putInt(BALL_KEY, ball.id());
            data.put(ElectronBombSkill.OFFSET_KEY, ElectronBombSkill.vec(ball.offset()));
            sendEffect(CHANNEL_BALL, data);
        }

        private void attack(ServerPlayer player) {
            LivingEntity target = closestTarget(player, ElectronMissileRules.range(exp));
            if (target == null || !consume(ElectronMissileRules.overloadPerAttack(exp),
                    ElectronMissileRules.cpPerAttack(exp))) {
                return;
            }
            Ball ball = balls.remove(player.getRandom().nextInt(balls.size()));
            Vec3 from = player.position().add(ball.offset());
            Vec3 to = target.getEyePosition();
            // Decisión 7 de la ficha: el golpe siempre entra aunque el objetivo acabe de recibir daño.
            if (MdDamage.attack(player, skill, ModDamageTypes.ELECTRON_MISSILE, target,
                    ElectronMissileRules.damage(exp), true, true)) {
                addSkillExp(ElectronMissileRules.EXP_PER_ATTACK);
            }
            CompoundTag data = new CompoundTag();
            data.putInt(BALL_KEY, ball.id());
            data.put(ElectronBombSkill.FROM_KEY, ElectronBombSkill.vec(from));
            data.put(ElectronBombSkill.TO_KEY, ElectronBombSkill.vec(to));
            sendEffect(CHANNEL_ATTACK, data);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (!started) {
                return;
            }
            started = false;
            balls.clear();
            if (reason == TerminationReason.LOGOUT) {
                return;
            }
            sendEffect(CHANNEL_STOP, new CompoundTag());
            setCooldown(ElectronMissileRules.cooldown(exp));
        }
    }
}
