package com.railgunreborn.ability.meltdowner;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Light Shield: nivel 2 de Meltdowner. Se mantiene la tecla: un disco de electrones delante del jugador absorbe parte
 * de un golpe frontal (uno cada 18 ticks) y daña a los seres vivos que se acercan por delante. Al terminar, Lentitud
 * II. Ficha: {@code docs/spec/light-shield.md} (mandan las decisiones del final). Números en {@link LightShieldRules}.
 */
public class LightShieldSkill extends Skill {
    /** Inicio: disco y sonidos en todos los clientes cercanos. */
    public static final String CHANNEL_START = "start";
    /** Fin: quita el disco y para el bucle. */
    public static final String CHANNEL_STOP = "stop";

    public LightShieldSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new LightShieldContext(player, this);
    }

    /** Escudo activo del propio jugador, o null (decisión 2: nunca el de otro). */
    @Nullable
    public static LightShieldContext activeShield(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof LightShieldContext shield && !shield.isTerminated() && shield.started) {
                return shield;
            }
        }
        return null;
    }

    public static final class LightShieldContext extends SkillContext {
        private final LightShieldSkill skill;
        private final float exp;
        private int ticks;
        private int lastAbsorb = Integer.MIN_VALUE;
        private float overloadFloor;
        private boolean started;

        LightShieldContext(ServerPlayer player, LightShieldSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        /** Ticks que lleva activo (para pruebas). */
        public int activeTicks() {
            return ticks;
        }

        @Override
        protected void onKeyDown() {
            // Sin CP para el primer tick no se cobra el overload (como Thunderclap).
            if (!canConsume(0f, LightShieldRules.cpPerTick(exp))
                    || !consume(LightShieldRules.initialOverload(exp), 0f)) {
                terminate();
                return;
            }
            overloadFloor = CPData.get(getPlayer()).getOverload();
            started = true;
            sendEffect(CHANNEL_START, new CompoundTag());
        }

        @Override
        protected void onKeyTick() {
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadFloor);
            ticks++;
            if (!consume(0f, LightShieldRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            addSkillExp(LightShieldRules.EXP_TICK);
            touch(player);
            if (LightShieldRules.isOver(ticks, exp)) {
                terminate();
            }
        }

        /** Daño por contacto (decisión 3): solo seres vivos y solo se cobra si el golpe se aplicó. */
        private void touch(ServerPlayer player) {
            double r = LightShieldRules.TOUCH_RADIUS;
            float cp = LightShieldRules.actionCp(exp);
            float overload = LightShieldRules.actionOverload(exp);
            for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate(r),
                    e -> SkillTargets.isTargetable(e) && e.distanceToSqr(player) <= r * r)) {
                LivingEntity living = (LivingEntity) entity;
                if (living.invulnerableTime > 0 || !inFront(player, living.position())) {
                    continue;
                }
                if (!canConsume(overload, cp)) {
                    return;
                }
                if (MdDamage.attack(player, skill, ModDamageTypes.LIGHT_SHIELD, living,
                        LightShieldRules.touchDamage(exp))) {
                    consume(overload, cp);
                    addSkillExp(LightShieldRules.EXP_TOUCH);
                }
            }
        }

        private static boolean inFront(Player player, Vec3 point) {
            return LightShieldRules.inCone(point.x - player.getX(), point.z - player.getZ(), player.getYHeadRot());
        }

        /**
         * Daño que le queda al jugador tras el escudo (ficha §4, con las decisiones): uno cada 18 ticks, solo desde
         * el frente si hay entidad directa, nunca el daño que ignora la invulnerabilidad (vacío, /kill).
         */
        public float handleAttacked(DamageSource source, float damage) {
            if (damage <= 0f || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                    || !LightShieldRules.intervalElapsed(ticks, lastAbsorb)) {
                return damage;
            }
            ServerPlayer player = getPlayer();
            Entity direct = source.getDirectEntity();
            if (direct != null && direct != player && !inFront(player, direct.position())) {
                return damage;
            }
            // Cuenta para el intervalo aunque no se pueda pagar (como el original).
            lastAbsorb = ticks;
            if (!consume(LightShieldRules.actionOverload(exp), LightShieldRules.actionCp(exp))) {
                return damage;
            }
            addSkillExp(LightShieldRules.EXP_ABSORB);
            return LightShieldRules.absorb(damage, LightShieldRules.absorbAmount(exp));
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (!started) {
                return;
            }
            started = false;
            sendEffect(CHANNEL_STOP, new CompoundTag());
            // Muerte o desconexión: no queda jugador al que aplicar nada (decisión 10).
            if (reason == TerminationReason.DEATH || reason == TerminationReason.LOGOUT) {
                return;
            }
            ServerPlayer player = getPlayer();
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, LightShieldRules.SLOW_TICKS,
                    LightShieldRules.SLOW_AMPLIFIER));
            setCooldown(LightShieldRules.cooldown(exp, ticks));
        }
    }
}
