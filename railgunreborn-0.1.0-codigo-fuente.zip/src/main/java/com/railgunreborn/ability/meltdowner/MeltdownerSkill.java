package com.railgunreborn.ability.meltdowner;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BeamReflect;
import com.railgunreborn.ability.common.BeamReflectEvent;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.common.TunnelBreaker;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Meltdowner: nivel 3 de Meltdowner. Se mantiene para cargar (20-40 ticks) y se suelta para lanzar un rayo de 50
 * bloques que daña a los seres vivos de un cilindro de radio 2-3 y abre un túnel. Ficha:
 * {@code docs/spec/meltdowner-skill.md} (mandan las decisiones del final). Números en {@link MeltdownerRules}.
 */
public class MeltdownerSkill extends Skill {
    /** Inicio de la carga: sonido y partículas en los clientes cercanos; contorno del icono en el local. */
    public static final String CHANNEL_START = "start";
    /** Disparo: {@link #ORIGIN_KEY}, {@link #DIR_KEY} y {@link #LENGTH_KEY}. */
    public static final String CHANNEL_FIRE = "fire";
    /** Fin de la carga (con o sin disparo): para el sonido y las partículas. */
    public static final String CHANNEL_STOP = "stop";
    public static final String ORIGIN_KEY = "origin";
    public static final String DIR_KEY = "dir";
    public static final String LENGTH_KEY = "length";

    /** Modificador temporal de velocidad mientras se carga (decisión 9 de la ficha). */
    public static final ResourceLocation SLOW_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "meltdowner_charge");

    public MeltdownerSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MeltdownerContext(player, this);
    }

    public static void removeSlowness(Player player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SLOW_MODIFIER_ID);
        }
    }

    /**
     * Gancho de reflejo ({@code RangedRayDamage.Reflectible} del original): si {@code target} refleja el rayo
     * ({@link BeamReflectEvent} cancelado), no se le daña y el rayo se corta en su distancia; el contragolpe de
     * {@link MeltdownerRules#reflectDamage} (10 bloques en la mirada del reflector) lo hace quien refleja.
     */
    static boolean reflects(ServerPlayer caster, MeltdownerSkill skill, LivingEntity target, Vec3 origin, Vec3 dir,
            float damage, float exp) {
        return BeamReflect.reflects(caster, skill, target, origin, dir, damage, MeltdownerRules.reflectDamage(exp));
    }

    public static final class MeltdownerContext extends SkillContext {
        private final MeltdownerSkill skill;
        private final float exp;
        private int ticks;
        /** Overload tras pagar el inicial: no se deja bajar de aquí mientras se carga. */
        private float overloadFloor;
        private boolean started;
        private boolean fired;

        MeltdownerContext(ServerPlayer player, MeltdownerSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        /** Ticks de carga hasta ahora (para pruebas). */
        public int chargeTicks() {
            return ticks;
        }

        @Override
        protected void onKeyDown() {
            // Sin CP para el primer tick de carga no se cobra el overload (como Light Shield).
            if (!canConsume(0f, MeltdownerRules.cpPerTick(exp))
                    || !consume(MeltdownerRules.initialOverload(exp), 0f)) {
                terminate();
                return;
            }
            overloadFloor = CPData.get(getPlayer()).getOverload();
            started = true;
            sendEffect(CHANNEL_START, new CompoundTag());
        }

        @Override
        protected void onKeyTick() {
            if (!started) {
                return;
            }
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadFloor);
            ticks++;
            if (MeltdownerRules.isOverTolerance(ticks) || !consume(0f, MeltdownerRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                speed.addOrUpdateTransientModifier(new AttributeModifier(SLOW_MODIFIER_ID,
                        MeltdownerRules.slowAmount(ticks), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
        }

        @Override
        protected void onKeyUp() {
            if (started && MeltdownerRules.canFire(ticks) && getPlayer().isAlive()) {
                fire();
            }
            terminate();
        }

        private void fire() {
            fired = true;
            ServerPlayer player = getPlayer();
            // Desde los ojos y en la dirección real de la mirada (el original salía de los pies y quedaba inclinado).
            Vec3 origin = player.getEyePosition();
            Vec3 dir = player.getViewVector(1.0f).normalize();
            double radius = MeltdownerRules.radius(exp);
            double length = MeltdownerRules.RANGE;
            float damage = MeltdownerRules.damage(exp, ticks);

            for (LivingEntity target : SkillTargets.inCylinder(player, origin, dir, MeltdownerRules.RANGE, radius)) {
                if (reflects(player, skill, target, origin, dir, damage, exp)) {
                    // El rayo se detiene en el reflector: ni más daño ni bloques más allá.
                    length = BeamReflect.cutLength(origin, dir, target);
                    break;
                }
                MdDamage.attack(player, skill, ModDamageTypes.MELTDOWNER, target, damage);
            }

            // Respeta destroy_blocks, mobGriefing y las protecciones; si no puede, el daño de arriba ya se hizo.
            int steps = Math.min(MeltdownerRules.MAX_STEPS, (int) Math.ceil(length));
            TunnelBreaker.breakTunnel(player, skill, origin, dir,
                    new TunnelBreaker.Spec(radius, MeltdownerRules.energy(exp, ticks), steps));

            addSkillExp(MeltdownerRules.expGain(ticks));
            setCooldown(MeltdownerRules.cooldown(exp, ticks));

            CompoundTag data = new CompoundTag();
            data.put(ORIGIN_KEY, ElectronBombSkill.vec(origin));
            data.put(DIR_KEY, ElectronBombSkill.vec(dir));
            data.putFloat(LENGTH_KEY, (float) length);
            sendEffect(CHANNEL_FIRE, data);
        }

        /** Si el disparo ya se hizo (para pruebas). */
        public boolean hasFired() {
            return fired;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            removeSlowness(getPlayer());
            if (!started) {
                return;
            }
            started = false;
            if (reason != TerminationReason.LOGOUT) {
                sendEffect(CHANNEL_STOP, new CompoundTag());
            }
        }
    }
}
