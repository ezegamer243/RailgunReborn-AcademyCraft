package com.railgunreborn.ability.meltdowner;

import com.railgunreborn.RailgunReborn;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/**
 * Absorción de Light Shield (bus del juego, solo servidor). {@code LivingDamageEvent.Pre} va después de armadura y
 * pociones y antes de la absorción amarilla, como el {@code LivingHurtEvent} del original, así que los 15-50 puntos
 * se comparan con el daño ya reducido por la armadura (ficha §4). Prioridad baja: se aplica después de la marca de
 * Rad Intensify ({@link RadIntensifyEvents}) y absorbe el daño final.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class LightShieldEvents {
    private LightShieldEvents() {
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onLivingDamage(LivingDamageEvent.Pre event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LightShieldSkill.LightShieldContext shield = LightShieldSkill.activeShield(player);
        if (shield != null) {
            event.setNewDamage(shield.handleAttacked(event.getSource(), event.getNewDamage()));
        }
    }
}
