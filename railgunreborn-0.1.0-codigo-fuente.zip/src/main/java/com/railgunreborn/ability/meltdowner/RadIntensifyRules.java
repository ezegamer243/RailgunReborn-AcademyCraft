package com.railgunreborn.ability.meltdowner;

/**
 * Números de β Radiation Intensify ({@code docs/spec/rad-intensify.md}), en Java puro para JUnit.
 *
 * <p>La exp no se gana usando: es el CP máximo actual entre el CP inicial del nivel 5 (8000), recortado a [0, 1].
 */
public final class RadIntensifyRules {
    /** Duración de la marca (decisión: fija, se reinicia con cada impacto que marca). */
    public static final int MARK_TICKS = 60;
    public static final float MIN_RATE = 1.4f;
    public static final float MAX_RATE = 1.8f;

    private RadIntensifyRules() {
    }

    /** {@code clamp(0, 1, maxCp / initCpLevel5)}; 0 si el divisor no es positivo. */
    public static float exp(float maxCp, float initCpLevel5) {
        if (!(initCpLevel5 > 0f) || Float.isNaN(maxCp)) {
            return 0f;
        }
        return Math.clamp(maxCp / initCpLevel5, 0f, 1f);
    }

    /** Multiplicador del daño sobre un objetivo marcado: {@code lerp(1.4, 1.8, exp)}. */
    public static float rate(float exp) {
        float e = Math.clamp(exp, 0f, 1f);
        return MIN_RATE + (MAX_RATE - MIN_RATE) * e;
    }
}
