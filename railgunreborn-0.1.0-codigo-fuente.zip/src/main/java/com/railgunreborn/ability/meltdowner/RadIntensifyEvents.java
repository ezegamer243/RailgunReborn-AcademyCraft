package com.railgunreborn.ability.meltdowner;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * Efecto de la marca de Rad Intensify (bus del juego, solo servidor). {@code LivingDamageEvent.Pre} va después de la
 * armadura, encantamientos y pociones y antes de la absorción, como el {@code LivingHurtEvent} del original; se
 * multiplica el daño de <b>cualquier</b> fuente mientras dure la marca (ficha, decisión 4).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class RadIntensifyEvents {
    private RadIntensifyEvents() {
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent.Pre event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) {
            return;
        }
        MdMark mark = RadIntensifySkill.activeMark(entity);
        if (mark != null) {
            event.setNewDamage(event.getNewDamage() * mark.rate());
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof LivingEntity living) || !(living.level() instanceof ServerLevel level)) {
            return;
        }
        MdMark mark = living.getExistingDataOrNull(ModAttachments.MD_MARK);
        if (mark == null) {
            return;
        }
        if (!mark.tickDown()) {
            living.removeData(ModAttachments.MD_MARK);
            return;
        }
        spawnMarkParticles(level, living);
    }

    /** 0-2 partículas Md alrededor del cuerpo (ficha §5, corregido: sobre el objetivo y visibles para todos). */
    private static void spawnMarkParticles(ServerLevel level, LivingEntity living) {
        RandomSource random = living.getRandom();
        int count = random.nextInt(3);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double r = (0.6 + random.nextDouble() * 0.1) * living.getBbWidth();
            double x = living.getX() + Math.cos(angle) * r;
            double y = living.getY() + random.nextDouble() * living.getBbHeight();
            double z = living.getZ() + Math.sin(angle) * r;
            // count 0: los tres valores siguientes son la velocidad exacta de la partícula.
            level.sendParticles(ModParticles.MD.get(), x, y, z, 0,
                    (random.nextDouble() - 0.5) * 0.04, (random.nextDouble() - 0.5) * 0.04,
                    (random.nextDouble() - 0.5) * 0.04, 1.0);
        }
    }
}
