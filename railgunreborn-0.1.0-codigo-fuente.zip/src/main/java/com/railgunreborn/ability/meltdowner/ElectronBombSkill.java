package com.railgunreborn.ability.meltdowner;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.electromaster.ArcGenSkill;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Electron Bomb: nivel 1 de Meltdowner. Un clic gratis: aparece una bola delante del jugador y, 18 ticks después (3 si
 * exp > 0.8), sale un rayo de 15 bloques hacia donde mire en ESE momento. Ficha: {@code docs/spec/electron-bomb.md}
 * (las decisiones del final mandan). Números en {@link ElectronBombRules}; el disparo diferido, en
 * {@link ElectronBombShots}.
 */
public class ElectronBombSkill extends Skill {
    /** Canal {@code ball} (al pulsar): {@link #LIFE_KEY} (int) y {@link #OFFSET_KEY} (dx, dy, dz respecto a los pies). */
    public static final String CHANNEL_BALL = "ball";
    /** Canal {@code ray} (al disparar): {@link #FROM_KEY} y {@link #TO_KEY} (x, y, z en el mundo). */
    public static final String CHANNEL_RAY = "ray";
    public static final String LIFE_KEY = "life";
    public static final String OFFSET_KEY = "offset";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";

    public ElectronBombSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ElectronBombContext(player, this);
    }

    /** Ser vivo alcanzado (o null) y hasta dónde llegó el rayo. */
    public record RayHit(@Nullable LivingEntity entity, Vec3 end) {
    }

    /**
     * Punto al que apunta el jugador ahora mismo: ojos del ser vivo mirado, o el punto de impacto/final del alcance
     * (medido desde los ojos: corrige el original, que lo medía desde los pies).
     */
    public static Vec3 aimPoint(Player player) {
        HitResult hit = ArcGenSkill.trace(player, ElectronBombRules.RANGE, ClipContext.Fluid.NONE);
        if (hit instanceof EntityHitResult entityHit && entityHit.getEntity() instanceof LivingEntity living) {
            return living.getEyePosition();
        }
        if (hit.getType() == HitResult.Type.MISS) {
            return player.getEyePosition().add(player.getViewVector(1.0f).scale(ElectronBombRules.RANGE));
        }
        return hit.getLocation();
    }

    /** Trazado de {@code from} a {@code to}: bloques con colisión (sin agua) y seres vivos (caja +0.3); gana lo más cercano. */
    public static RayHit traceRay(Player player, Vec3 from, Vec3 to) {
        var level = player.level();
        var blockHit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? to : blockHit.getLocation();
        double bestDist = from.distanceToSqr(limit);
        LivingEntity best = null;
        Vec3 bestPos = limit;

        AABB search = new AABB(from, limit).inflate(1.0 + ElectronBombRules.HITBOX_INFLATE);
        for (Entity entity : level.getEntities(player, search, SkillTargets::isTargetable)) {
            AABB box = entity.getBoundingBox().inflate(ElectronBombRules.HITBOX_INFLATE);
            Vec3 point = box.contains(from) ? from : box.clip(from, limit).orElse(null);
            if (point != null && from.distanceToSqr(point) <= bestDist) {
                bestDist = from.distanceToSqr(point);
                best = (LivingEntity) entity;
                bestPos = point;
            }
        }
        return new RayHit(best, bestPos);
    }

    static CompoundTag vec(Vec3 v) {
        CompoundTag tag = new CompoundTag();
        tag.putDouble("x", v.x);
        tag.putDouble("y", v.y);
        tag.putDouble("z", v.z);
        return tag;
    }

    public static Vec3 readVec(CompoundTag tag) {
        return new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"));
    }

    private static final class ElectronBombContext extends SkillContext {
        private final ElectronBombSkill skill;
        private final float exp;

        ElectronBombContext(ServerPlayer player, ElectronBombSkill skill) {
            super(player, skill);
            this.skill = skill;
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            ServerPlayer player = getPlayer();
            var random = player.getRandom();
            double yaw = Math.toRadians(player.getYRot());
            double[] o = ElectronBombRules.ballOffset(yaw, random.nextDouble(), random.nextDouble(),
                    random.nextDouble());
            Vec3 offset = new Vec3(o[0], o[1], o[2]);

            ElectronBombShots.add(player, skill, exp, offset);
            setCooldown(ElectronBombRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            data.putInt(LIFE_KEY, ElectronBombRules.life(exp));
            data.put(OFFSET_KEY, vec(offset));
            sendEffect(CHANNEL_BALL, data);
            // Gratis y sin contexto vivo: el disparo diferido lo gestiona ElectronBombShots.
            terminate();
        }
    }
}
