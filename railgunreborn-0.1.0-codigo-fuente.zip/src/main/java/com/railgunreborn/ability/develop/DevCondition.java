package com.railgunreborn.ability.develop;

import javax.annotation.Nullable;

import net.minecraft.resources.ResourceLocation;

/**
 * Una condición de aprendizaje con icono en la pantalla ({@code developer.md} 2.5 y 3.5). El nivel no va aquí
 * (el original no lo muestra con icono). La calculan cliente (solo visual) y servidor con la misma lógica.
 *
 * @param skill       habilidad requerida (PARENT/DEPENDENCY), si no null
 * @param developer   tipo mínimo (DEVELOPER_TYPE), si no null
 * @param level       nivel de ANY_SKILL_OF_LEVEL, 0 en los demás
 * @param minExp      exp mínima de la habilidad requerida (PARENT/DEPENDENCY)
 */
public record DevCondition(Kind kind, @Nullable ResourceLocation skill, @Nullable DeveloperType developer, int level,
        float minExp, boolean met) {
    public enum Kind {
        DEVELOPER_TYPE, PARENT, DEPENDENCY, ANY_SKILL_OF_LEVEL
    }
}
