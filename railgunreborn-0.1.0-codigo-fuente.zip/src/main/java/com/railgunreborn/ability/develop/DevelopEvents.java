package com.railgunreborn.ability.develop;

import com.railgunreborn.RailgunReborn;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Avanza la sesión del Developer abierto. La validez (distancia, ítem) la comprueba vanilla con {@code stillValid}. */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class DevelopEvents {
    private DevelopEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player && player.containerMenu instanceof DeveloperMenu menu) {
            menu.serverTick(player);
        }
    }
}
