package com.railgunreborn.ability.develop;

/**
 * Reglas puras del Developer ({@code developer.md} 2.2 y 2.5): costes en estímulos y si una acción es posible.
 * Sin Minecraft: quien llama resume los datos del jugador en {@link LearnFacts} o en primitivos.
 */
public final class DevelopRules {
    public static final int MAX_LEVEL = 5;

    private DevelopRules() {
    }

    /** Obtener categoría (nivel 0) o subir de nivel: {@code 5 * (nivel + 1)}. */
    public static int stimsForLevelAction(int currentLevel) {
        return 5 * (currentLevel + 1);
    }

    /** Aprender una habilidad: {@code (int)(3 + nivel² / 2)} = 3, 5, 7, 11, 15. */
    public static int stimsForSkill(int skillLevel) {
        return (int) (3 + skillLevel * skillLevel * 0.5f);
    }

    /** Ticks totales de una acción en un Developer. */
    public static int totalTicks(int stims, DeveloperType type) {
        return stims * type.ticksPerStim();
    }

    /**
     * Obtener categoría (sin categoría) o subir de nivel. No depende del tipo de Developer (como el original).
     *
     * @param levelProgressFraction progreso de nivel 0..1 ({@code Category.levelProgressFraction})
     */
    public static DevelopResult checkLevelAction(boolean hasCategory, int level, float levelProgressFraction) {
        if (!hasCategory) {
            return DevelopResult.OK;
        }
        if (level >= MAX_LEVEL) {
            return DevelopResult.MAX_LEVEL;
        }
        if (levelProgressFraction < 1f) {
            return DevelopResult.LEVEL_PROGRESS_INCOMPLETE;
        }
        return DevelopResult.OK;
    }

    /** Aprender una habilidad: devuelve el primer motivo de rechazo en orden fijo, u OK. */
    public static DevelopResult checkLearn(LearnFacts facts, DeveloperType type) {
        if (!facts.hasCategory()) {
            return DevelopResult.NO_CATEGORY;
        }
        if (!facts.sameCategory()) {
            return DevelopResult.WRONG_CATEGORY;
        }
        if (facts.alreadyLearned()) {
            return DevelopResult.ALREADY_LEARNED;
        }
        if (facts.playerLevel() < facts.skillLevel()) {
            return DevelopResult.LEVEL_TOO_LOW;
        }
        if (!type.canTeach(facts.skillLevel())) {
            return DevelopResult.DEVELOPER_TOO_WEAK;
        }
        if (!facts.parentMet()) {
            return DevelopResult.PARENT_NOT_MET;
        }
        if (!facts.dependenciesMet()) {
            return DevelopResult.DEPENDENCY_NOT_MET;
        }
        if (!facts.anySkillOfLevelMet()) {
            return DevelopResult.ANY_SKILL_NOT_MET;
        }
        return DevelopResult.OK;
    }

    /**
     * Lo que hace falta saber del jugador para aprender una habilidad.
     *
     * @param parentMet          sin padre = true
     * @param anySkillOfLevelMet condición de las genéricas ("alguna habilidad de nivel N aprendida"); sin ella = true
     */
    public record LearnFacts(boolean hasCategory, boolean sameCategory, boolean alreadyLearned, int playerLevel,
            int skillLevel, boolean parentMet, boolean dependenciesMet, boolean anySkillOfLevelMet) {
    }
}
