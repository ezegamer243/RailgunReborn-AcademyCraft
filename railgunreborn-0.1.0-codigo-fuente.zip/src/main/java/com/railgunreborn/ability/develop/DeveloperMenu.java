package com.railgunreborn.ability.develop;

import javax.annotation.Nullable;

import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.registry.ModMenus;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Menú (sin ranuras) de una sesión de desarrollo ({@code developer.md}, sección "Implementación T20").
 *
 * <p>En el servidor guarda la {@link DevelopSession} y la {@link DevelopAction} en curso; el estado viaja al cliente
 * por {@link ContainerData}. Cerrar el menú, o que deje de ser válido (lejos, bloque roto, ítem fuera de la mano,
 * muerte), lo destruye y con él la sesión: <b>cancela sin aplicar nada</b> (decisión del usuario).
 *
 * <p>Buffer de apertura: {@code DeveloperType} (enum), {@code boolean} hay bloque, y si lo hay su {@code BlockPos}.
 * Sin bloque = Developer portátil en la mano principal.
 */
public class DeveloperMenu extends AbstractContainerMenu {
    /** Distancia máxima (bloques) de los pies del jugador al centro del bloque. */
    public static final double MAX_DISTANCE = 8.0;
    public static final Component TITLE = Component.translatable("container.railgunreborn.developer");

    // Índices de ContainerData (se sincronizan como short: valores pequeños).
    public static final int DATA_STATE = 0;
    public static final int DATA_STIM = 1;
    public static final int DATA_MAX_STIM = 2;
    public static final int DATA_TICK_IN_STIM = 3;
    public static final int DATA_TICKS_PER_STIM = 4;
    public static final int DATA_RESULT = 5;
    /** 0 = ninguna, 1 = LEVEL, 2 = SKILL (la última pedida). */
    public static final int DATA_ACTION_KIND = 6;
    /**
     * Contador de intentos (start/reject) módulo 2^15: el cliente sabe que su petición ya tiene respuesta aunque el
     * estado y el motivo coincidan con los del intento anterior (p. ej. dos rechazos seguidos por la misma razón).
     */
    public static final int DATA_ATTEMPT = 7;
    /** Energía del Developer (buffer del bloque o batería del ítem): ocupa dos ranuras ({@link ContainerDataInts}). */
    public static final int DATA_ENERGY = 8;
    /** 1 si el servidor exige energía ({@code energyRequired}), 0 si es gratis. */
    public static final int DATA_ENERGY_REQUIRED = DATA_ENERGY + ContainerDataInts.SLOTS;
    public static final int DATA_COUNT = DATA_ENERGY_REQUIRED + 1;

    private final DeveloperType type;
    @Nullable
    private final BlockPos blockPos;
    private final ContainerData data;

    // Solo servidor (null en el cliente).
    @Nullable
    private final DevelopSession session;
    @Nullable
    private final Block block;
    @Nullable
    private final Item portableItem;
    @Nullable
    private final Player owner;
    @Nullable
    private DevelopAction action;
    private int lastActionKind;
    private int attempt;

    /** Cliente: lo crea {@code IMenuTypeExtension} con el buffer de {@link #open}. */
    public DeveloperMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, buf.readEnum(DeveloperType.class), buf.readBoolean() ? buf.readBlockPos() : null,
                null, null, null, null);
    }

    private DeveloperMenu(int containerId, DeveloperType type, @Nullable BlockPos blockPos,
            @Nullable DevelopSession session, @Nullable Block block, @Nullable Item portableItem,
            @Nullable Player owner) {
        super(ModMenus.DEVELOPER.get(), containerId);
        this.type = type;
        this.blockPos = blockPos;
        this.session = session;
        this.block = block;
        this.portableItem = portableItem;
        this.owner = owner;
        this.data = session == null ? new SimpleContainerData(DATA_COUNT) : new SessionData();
        addDataSlots(data);
    }

    /**
     * Abre el Developer (solo servidor). {@code blockPos} null = portátil: el ítem de la mano principal es el
     * Developer y debe seguir ahí. Con bloque: el bloque que hay ahora en {@code blockPos} debe seguir ahí y a
     * ≤ {@link #MAX_DISTANCE} bloques.
     *
     * @return el menú abierto, o null si no se pudo (mano vacía, aire, demasiado lejos)
     */
    @Nullable
    public static DeveloperMenu open(ServerPlayer player, DeveloperType type, @Nullable BlockPos blockPos) {
        Block block = null;
        Item item = null;
        BlockPos pos = blockPos == null ? null : blockPos.immutable();
        if (pos != null) {
            BlockState state = player.level().getBlockState(pos);
            if (state.isAir()) {
                return null;
            }
            block = state.getBlock();
        } else {
            ItemStack held = player.getMainHandItem();
            if (held.isEmpty()) {
                return null;
            }
            item = held.getItem();
        }
        if (!isValid(player, pos, block, item)) {
            return null;
        }
        Block finalBlock = block;
        Item finalItem = item;
        player.openMenu(new SimpleMenuProvider(
                (id, inventory, p) -> new DeveloperMenu(id, type, pos, new DevelopSession(), finalBlock, finalItem, p),
                TITLE), buf -> {
                    buf.writeEnum(type);
                    buf.writeBoolean(pos != null);
                    if (pos != null) {
                        buf.writeBlockPos(pos);
                    }
                });
        return player.containerMenu instanceof DeveloperMenu menu ? menu : null;
    }

    private static boolean isValid(Player player, @Nullable BlockPos pos, @Nullable Block block,
            @Nullable Item item) {
        if (!player.isAlive()) {
            return false;
        }
        if (pos != null) {
            return block != null && player.level().getBlockState(pos).is(block)
                    && player.distanceToSqr(Vec3.atCenterOf(pos)) <= MAX_DISTANCE * MAX_DISTANCE;
        }
        ItemStack held = player.getMainHandItem();
        return item != null && !held.isEmpty() && held.is(item);
    }

    // --- Servidor: acciones ---

    /**
     * Empieza a desarrollar. Valida Developer y acción; si se rechaza el estado queda FAILED con el motivo (salvo
     * BUSY, que no toca el desarrollo en curso).
     */
    public DevelopResult start(ServerPlayer player, DevelopAction newAction) {
        DevelopSession s = requireServer();
        if (s.isDeveloping()) {
            return DevelopResult.BUSY;
        }
        lastActionKind = newAction.kind().ordinal() + 1;
        attempt = (attempt + 1) & 0x7FFF;
        DevelopResult result = stillValid(player)
                ? newAction.check(player, type)
                : DevelopResult.INVALID_DEVELOPER;
        if (!result.isOk()) {
            action = null;
            s.reject(result);
            return result;
        }
        int stims = newAction.stims(AbilityData.get(player));
        // Como el original: antes de empezar hace falta TODA la energía estimada (el factor no se toca al rechazar).
        if (RailgunConfig.energyRequired() && energyStored() < type.energyForStims(stims)) {
            action = null;
            s.reject(DevelopResult.NO_ENERGY);
            return DevelopResult.NO_ENERGY;
        }
        action = newAction;
        s.begin(stims, type.ticksPerStim());
        return DevelopResult.OK;
    }

    // --- Energía (servidor) ---

    /** Energía disponible ahora: buffer del bloque o batería del ítem en la mano principal. */
    private int energyStored() {
        if (owner == null) {
            return 0;
        }
        if (blockPos == null) {
            ItemStack held = owner.getMainHandItem();
            return portableItem != null && held.is(portableItem) ? DeveloperPortableItem.getEnergy(held) : 0;
        }
        return owner.level().getBlockEntity(blockPos) instanceof DeveloperBlockEntity be
                ? be.getEnergy().getEnergyStored() : 0;
    }

    /** Cobra {@code amount} entero o nada (sin el tope de ancho de banda, que es solo para entradas externas). */
    private boolean payEnergy(int amount) {
        if (owner == null) {
            return false;
        }
        if (blockPos == null) {
            ItemStack held = owner.getMainHandItem();
            return portableItem != null && held.is(portableItem) && DeveloperPortableItem.tryConsume(held, amount);
        }
        return owner.level().getBlockEntity(blockPos) instanceof DeveloperBlockEntity be
                && be.getEnergy().tryConsume(amount);
    }

    /** Rechazo sin acción construible (p. ej. habilidad desconocida en el payload). No pisa un desarrollo en curso. */
    public void reject(DevelopResult result) {
        DevelopSession s = requireServer();
        if (!s.isDeveloping()) {
            action = null;
            attempt = (attempt + 1) & 0x7FFF;
            s.reject(result);
        }
    }

    /** Aborta el desarrollo en curso sin aplicar nada (botón de la pantalla). */
    public void abort() {
        DevelopSession s = requireServer();
        if (s.isDeveloping()) {
            s.cancel(DevelopResult.ABORTED);
            action = null;
        }
    }

    /** Un tick de servidor ({@code DevelopEvents}). Al completar los estímulos revalida y aplica. */
    public void serverTick(ServerPlayer player) {
        DevelopSession s = requireServer();
        // Cada estímulo se cobra entero al empezar. Si no se puede pagar (otro consumidor vació el buffer, el
        // portátil se soltó) el desarrollo FALLA como en el original: se pierde el progreso y no hay reembolso. No
        // se llama a apply, así que el Induction Factor no se consume.
        if (s.isDeveloping() && s.tickInStim() == 0 && s.stim() < s.maxStim() && RailgunConfig.energyRequired()
                && !payEnergy(type.energyPerStim())) {
            action = null;
            s.finish(stillValid(player) ? DevelopResult.NO_ENERGY : DevelopResult.INVALID_DEVELOPER);
            return;
        }
        if (s.tick()) {
            DevelopAction done = action;
            action = null;
            DevelopResult result = !stillValid(player) || done == null
                    ? DevelopResult.INVALID_DEVELOPER
                    : done.check(player, type);
            if (result.isOk()) {
                done.apply(player);
            }
            s.finish(result);
        }
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (session != null && session.isDeveloping()) {
            session.cancel(DevelopResult.ABORTED);
            action = null;
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return session == null || isValid(player, blockPos, block, portableItem);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    private DevelopSession requireServer() {
        if (session == null) {
            throw new IllegalStateException("DeveloperMenu server method called on the client");
        }
        return session;
    }

    // --- Lectura (cliente y servidor) ---

    public DeveloperType getDeveloperType() {
        return type;
    }

    /** Null = portátil. */
    @Nullable
    public BlockPos getBlockPos() {
        return blockPos;
    }

    public DevelopSession.State getState() {
        return DevelopSession.State.byOrdinal(data.get(DATA_STATE));
    }

    public int getStim() {
        return data.get(DATA_STIM);
    }

    public int getMaxStim() {
        return data.get(DATA_MAX_STIM);
    }

    /** Progreso 0..1, suave (incluye los ticks dentro del estímulo). */
    public float getProgress() {
        return DevelopSession.progress(data.get(DATA_STIM), data.get(DATA_MAX_STIM), data.get(DATA_TICK_IN_STIM),
                data.get(DATA_TICKS_PER_STIM));
    }

    /** Resultado del último intento (motivo del rechazo o fallo; OK tras éxito). */
    public DevelopResult getResult() {
        return DevelopResult.byOrdinal(data.get(DATA_RESULT));
    }

    /** Tipo de la última acción pedida, o null si aún no se pidió ninguna. */
    @Nullable
    public DevelopAction.Kind getActionKind() {
        int kind = data.get(DATA_ACTION_KIND);
        return kind <= 0 || kind > DevelopAction.Kind.values().length ? null : DevelopAction.Kind.values()[kind - 1];
    }

    /** Número del último intento (start/reject), ver {@link #DATA_ATTEMPT}. */
    public int getAttempt() {
        return data.get(DATA_ATTEMPT);
    }

    /** Energía del Developer (IF), sincronizada. */
    public int getEnergy() {
        return ContainerDataInts.get(data, DATA_ENERGY);
    }

    /** Si el servidor exige energía para desarrollar. */
    public boolean isEnergyRequired() {
        return data.get(DATA_ENERGY_REQUIRED) != 0;
    }

    /** Solo servidor (tests): acción en curso. */
    @Nullable
    public DevelopAction getAction() {
        return action;
    }

    /** Vista de la sesión para el {@link ContainerData} del servidor. */
    private final class SessionData implements ContainerData {
        @Override
        public int get(int index) {
            DevelopSession s = session;
            return switch (index) {
                case DATA_STATE -> s.state().ordinal();
                case DATA_STIM -> s.stim();
                case DATA_MAX_STIM -> s.maxStim();
                case DATA_TICK_IN_STIM -> s.tickInStim();
                case DATA_TICKS_PER_STIM -> s.ticksPerStim();
                case DATA_RESULT -> s.result().ordinal();
                case DATA_ACTION_KIND -> lastActionKind;
                case DATA_ATTEMPT -> attempt;
                case DATA_ENERGY, DATA_ENERGY + 1 -> ContainerDataInts.part(energyStored(), index - DATA_ENERGY);
                case DATA_ENERGY_REQUIRED -> RailgunConfig.energyRequired() ? 1 : 0;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            // El servidor es la fuente de verdad: el cliente nunca escribe aquí.
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    }
}
