package com.railgunreborn.ability.develop;

/**
 * Resultado de validar o terminar una acción del Developer. Viaja al cliente por {@code ContainerData} (ordinal), así
 * que solo se añaden valores al final.
 */
public enum DevelopResult {
    /** Aún no hay resultado (sesión sin empezar). */
    NONE,
    OK,
    /** Aprender sin categoría. */
    NO_CATEGORY,
    /** Obtener categoría sin ninguna categoría registrada. */
    NO_CATEGORY_AVAILABLE,
    WRONG_CATEGORY,
    UNKNOWN_SKILL,
    ALREADY_LEARNED,
    LEVEL_TOO_LOW,
    DEVELOPER_TOO_WEAK,
    PARENT_NOT_MET,
    DEPENDENCY_NOT_MET,
    ANY_SKILL_NOT_MET,
    LEVEL_PROGRESS_INCOMPLETE,
    MAX_LEVEL,
    /** Ya hay un desarrollo en curso. */
    BUSY,
    /** El Developer ya no es válido (lejos, bloque roto, ítem fuera de la mano). */
    INVALID_DEVELOPER,
    /** El jugador abortó con el botón (no por cerrar: cerrar destruye el menú). */
    ABORTED,
    /** Obtener categoría por nombre sin tener un Induction Factor de ella. */
    NO_FACTOR,
    /** No hay en el Developer la energía estimada del desarrollo, o se acabó a mitad (el desarrollo falla). */
    NO_ENERGY;

    public boolean isOk() {
        return this == OK;
    }

    /** {@code railgunreborn.developer.result.<nombre>}; las traducciones las añade la pantalla (T22). */
    public String translationKey() {
        return "railgunreborn.developer.result." + name().toLowerCase(java.util.Locale.ROOT);
    }

    public static DevelopResult byOrdinal(int ordinal) {
        DevelopResult[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : NONE;
    }
}
