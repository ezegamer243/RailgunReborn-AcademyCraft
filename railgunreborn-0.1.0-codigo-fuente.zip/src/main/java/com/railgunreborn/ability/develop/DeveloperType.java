package com.railgunreborn.ability.develop;

/**
 * Los tres Developer del original ({@code developer.md} 1.1). Clase pura (sin Minecraft) para poder probarla con JUnit.
 *
 * <p>El orden importa: un Developer superior siempre vale donde vale uno inferior (se compara por ordinal).
 */
public enum DeveloperType {
    // ticks efectivos por estímulo: el original declara 25/20/15 pero compara con '>', así que tarda uno más.
    // Decisión del usuario: usar los efectivos (26/21/16).
    PORTABLE(26, 2, 0.3f, 750, 10_000, 50),
    NORMAL(21, 3, 0.7f, 700, 50_000, 100),
    ADVANCED(16, 5, 1.0f, 600, 200_000, 300);

    private final int ticksPerStim;
    private final int maxSkillLevel;
    private final float syncRate;
    private final int energyPerStim;
    private final int energyCapacity;
    private final int energyBandwidth;

    DeveloperType(int ticksPerStim, int maxSkillLevel, float syncRate, int energyPerStim, int energyCapacity,
            int energyBandwidth) {
        this.ticksPerStim = ticksPerStim;
        this.maxSkillLevel = maxSkillLevel;
        this.syncRate = syncRate;
        this.energyPerStim = energyPerStim;
        this.energyCapacity = energyCapacity;
        this.energyBandwidth = energyBandwidth;
    }

    /** Ticks que tarda un estímulo (26/21/16). */
    public int ticksPerStim() {
        return ticksPerStim;
    }

    /** Nivel máximo de habilidad que puede enseñar (2/3/5). No limita subir de nivel. */
    public int maxSkillLevel() {
        return maxSkillLevel;
    }

    public boolean canTeach(int skillLevel) {
        return skillLevel <= maxSkillLevel;
    }

    /** "Sync rate" del original: solo se muestra en la pantalla (barra azul). */
    public float syncRate() {
        return syncRate;
    }

    /** IF por estímulo (750 / 700 / 600). */
    public int energyPerStim() {
        return energyPerStim;
    }

    /** IF totales de un desarrollo de {@code stims} estímulos (la estimación que se exige antes de empezar). */
    public int energyForStims(int stims) {
        return energyPerStim * stims;
    }

    /** IF máximos del buffer. */
    public int energyCapacity() {
        return energyCapacity;
    }

    /** IF por tick que puede recibir. */
    public int energyBandwidth() {
        return energyBandwidth;
    }

    /** Tipo mínimo que enseña una habilidad de ese nivel: 1-2 portátil, 3 normal, 4-5 avanzado. */
    public static DeveloperType minimumFor(int skillLevel) {
        for (DeveloperType type : values()) {
            if (type.canTeach(skillLevel)) {
                return type;
            }
        }
        throw new IllegalArgumentException("No developer can teach level " + skillLevel);
    }

    public static DeveloperType byOrdinal(int ordinal) {
        DeveloperType[] values = values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : PORTABLE;
    }
}
