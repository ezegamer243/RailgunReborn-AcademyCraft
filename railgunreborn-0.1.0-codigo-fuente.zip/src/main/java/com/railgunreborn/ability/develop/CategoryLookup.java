package com.railgunreborn.ability.develop;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;

import net.minecraft.resources.ResourceLocation;

/**
 * Resuelve el texto escrito en la consola del Developer a una categoría: id ({@code teleporter}, {@code ns:id}) o
 * nombre visible en en_us / es_es, sin distinguir mayúsculas, acentos ni espacios de más.
 */
public final class CategoryLookup {
    private static final List<String> LANGS = List.of("en_us", "es_es");
    private static volatile List<JsonObject> langFiles;

    private CategoryLookup() {
    }

    public static String normalize(String text) {
        String s = Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return s.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    public static Optional<ResourceLocation> byName(String text) {
        String wanted = normalize(text);
        if (wanted.isEmpty()) {
            return Optional.empty();
        }
        for (Category category : AbilityRegistries.CATEGORY_REGISTRY) {
            ResourceLocation id = category.getId();
            if (wanted.equals(normalize(id.getPath())) || wanted.equals(normalize(id.toString()))) {
                return Optional.of(id);
            }
            for (JsonObject lang : langFiles()) {
                if (lang.has(category.getNameKey())
                        && wanted.equals(normalize(lang.get(category.getNameKey()).getAsString()))) {
                    return Optional.of(id);
                }
            }
        }
        return Optional.empty();
    }

    private static List<JsonObject> langFiles() {
        List<JsonObject> loaded = langFiles;
        if (loaded == null) {
            loaded = LANGS.stream().map(CategoryLookup::load).toList();
            langFiles = loaded;
        }
        return loaded;
    }

    private static JsonObject load(String code) {
        String path = "/assets/railgunreborn/lang/" + code + ".json";
        try (InputStream in = CategoryLookup.class.getResourceAsStream(path)) {
            if (in == null) {
                return new JsonObject();
            }
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (IOException | RuntimeException e) {
            return new JsonObject();
        }
    }
}
