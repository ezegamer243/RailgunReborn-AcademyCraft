package com.railgunreborn.ability.develop;

import java.util.List;
import java.util.Objects;

import javax.annotation.Nullable;

import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.item.InductionFactorItem;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;

/**
 * Lo que se desarrolla: {@link Kind#LEVEL} (sin categoría = obtenerla; con categoría = subir de nivel, como
 * {@code DevelopActionLevel} del original) o {@link Kind#SKILL} (aprender {@link #skill()}).
 */
public record DevelopAction(Kind kind, @Nullable Skill skill, @Nullable ResourceLocation category) {
    public enum Kind {
        LEVEL, SKILL
    }

    public DevelopAction {
        if ((kind == Kind.SKILL) != (skill != null)) {
            throw new IllegalArgumentException("SKILL needs a skill and LEVEL must not have one");
        }
        if (category != null && kind != Kind.LEVEL) {
            throw new IllegalArgumentException("only LEVEL can carry a factor category");
        }
    }

    public static DevelopAction level() {
        return new DevelopAction(Kind.LEVEL, null, null);
    }

    /** Obtener la categoría indicada gastando un Induction Factor de ella (el servidor lo comprueba). */
    public static DevelopAction levelWithFactor(ResourceLocation category) {
        return new DevelopAction(Kind.LEVEL, null, Objects.requireNonNull(category));
    }

    public static DevelopAction learn(Skill skill) {
        return new DevelopAction(Kind.SKILL, Objects.requireNonNull(skill), null);
    }

    /** Como {@link #check(AbilityData, DeveloperType)} más lo que depende del inventario (el factor). */
    public DevelopResult check(ServerPlayer player, DeveloperType type) {
        AbilityData data = AbilityData.get(player);
        if (category != null) {
            if (data.hasCategory()) {
                return DevelopResult.WRONG_CATEGORY;
            }
            if (AbilityRegistries.category(category).isEmpty()) {
                return DevelopResult.NO_CATEGORY_AVAILABLE;
            }
            if (!InductionFactorItem.has(player, category)) {
                return DevelopResult.NO_FACTOR;
            }
        }
        return check(data, type);
    }

    /** Validación del servidor (al empezar y al terminar). No mira el Developer en sí (eso es {@code stillValid}). */
    public DevelopResult check(AbilityData data, DeveloperType type) {
        if (kind == Kind.SKILL) {
            return skill.checkLearn(data, type);
        }
        if (!data.hasCategory() && AbilityRegistries.CATEGORY_REGISTRY.size() == 0) {
            return DevelopResult.NO_CATEGORY_AVAILABLE;
        }
        float fraction = AbilityRegistries.category(data.getCategory().orElse(null))
                .map(c -> c.levelProgressFraction(data.getLevel(), data.getLevelProgress()))
                .orElse(0f);
        return DevelopRules.checkLevelAction(data.hasCategory(), data.getLevel(), fraction);
    }

    /** Estímulos necesarios según el estado actual del jugador. */
    public int stims(AbilityData data) {
        return kind == Kind.SKILL ? skill.getLearningStims() : DevelopRules.stimsForLevelAction(data.getLevel());
    }

    /**
     * Aplica el efecto (ya validado). Después llama a {@link CPData#get} como los comandos, para que se apliquen al
     * momento los recálculos pendientes de CP/presets.
     */
    public void apply(ServerPlayer player) {
        AbilityData data = AbilityData.get(player);
        if (kind == Kind.SKILL) {
            data.learnSkill(skill.getId());
        } else if (!data.hasCategory()) {
            if (category == null) {
                data.setCategory(randomCategory(player.getRandom()));
            } else if (InductionFactorItem.consumeOne(player, category)) {
                data.setCategory(category);
            }
        } else {
            data.setLevel(data.getLevel() + 1);
        }
        CPData.get(player);
    }

    /**
     * Categoría aleatoria uniforme entre las registradas (decisión del usuario: Electromaster o Meltdowner).
     * Con un Induction Factor se usa {@link #levelWithFactor} en vez de esto.
     */
    static ResourceLocation randomCategory(RandomSource random) {
        List<Category> all = AbilityRegistries.CATEGORY_REGISTRY.stream().toList();
        return all.get(random.nextInt(all.size())).getId();
    }
}
