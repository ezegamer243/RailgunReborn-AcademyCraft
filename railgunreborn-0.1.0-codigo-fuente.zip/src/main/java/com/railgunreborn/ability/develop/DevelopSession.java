package com.railgunreborn.ability.develop;

/**
 * Progreso de un desarrollo ({@code developer.md} 2.3), sin Minecraft. Lo guarda el {@code DeveloperMenu}: no se
 * persiste (cerrar el menú cancela).
 */
public final class DevelopSession {
    public enum State {
        IDLE, DEVELOPING, DONE, FAILED;

        public static State byOrdinal(int ordinal) {
            State[] values = values();
            return ordinal >= 0 && ordinal < values.length ? values[ordinal] : IDLE;
        }
    }

    private State state = State.IDLE;
    private int stim;
    private int maxStim;
    private int tickInStim;
    private int ticksPerStim = 1;
    private DevelopResult result = DevelopResult.NONE;

    public void begin(int maxStim, int ticksPerStim) {
        if (maxStim <= 0 || ticksPerStim <= 0) {
            throw new IllegalArgumentException("maxStim and ticksPerStim must be positive");
        }
        this.state = State.DEVELOPING;
        this.stim = 0;
        this.maxStim = maxStim;
        this.tickInStim = 0;
        this.ticksPerStim = ticksPerStim;
        this.result = DevelopResult.NONE;
    }

    /** Avanza un tick. @return true justo cuando se completa el último estímulo (hay que validar y aplicar). */
    public boolean tick() {
        if (state != State.DEVELOPING) {
            return false;
        }
        if (++tickInStim >= ticksPerStim) {
            tickInStim = 0;
            stim++;
        }
        return stim >= maxStim;
    }

    public void finish(DevelopResult result) {
        this.state = result.isOk() ? State.DONE : State.FAILED;
        this.result = result;
        this.tickInStim = 0;
    }

    /** Rechazo al empezar: no hay progreso. */
    public void reject(DevelopResult result) {
        this.state = State.FAILED;
        this.result = result;
        this.stim = 0;
        this.maxStim = 0;
        this.tickInStim = 0;
    }

    /** Cancela sin aplicar nada (cerrar el menú, abortar). */
    public void cancel(DevelopResult result) {
        this.state = State.IDLE;
        this.result = result;
        this.stim = 0;
        this.tickInStim = 0;
    }

    public boolean isDeveloping() {
        return state == State.DEVELOPING;
    }

    public State state() {
        return state;
    }

    public int stim() {
        return stim;
    }

    public int maxStim() {
        return maxStim;
    }

    public int tickInStim() {
        return tickInStim;
    }

    public int ticksPerStim() {
        return ticksPerStim;
    }

    public DevelopResult result() {
        return result;
    }

    /** Progreso suave 0..1 contando los ticks dentro del estímulo. */
    public float progress() {
        return progress(stim, maxStim, tickInStim, ticksPerStim);
    }

    public static float progress(int stim, int maxStim, int tickInStim, int ticksPerStim) {
        if (maxStim <= 0) {
            return 0f;
        }
        float value = (stim + (ticksPerStim > 0 ? (float) tickInStim / ticksPerStim : 0f)) / maxStim;
        return Math.min(1f, Math.max(0f, value));
    }
}
