package com.railgunreborn.ability.teleporter;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;

import net.minecraft.world.entity.player.Player;

/**
 * Pasivas de los críticos de espacio: Dimension Folding Theorem y Space Fluctuation ({@code dim-folding-theorem.md},
 * {@code space-fluct.md}). No tienen tecla ni contexto: {@link TpDamage} lee si están aprendidas y su exp, y les da
 * exp cuando un crítico llega a dañar.
 */
public class CritPassiveSkill extends Skill {
    public CritPassiveSkill(Properties props) {
        super(props);
    }

    public boolean isLearnedBy(Player player) {
        return AbilityData.get(player).isLearned(getId());
    }

    /** Exp para las tiradas, o {@link SpaceCriticals#NOT_LEARNED} si no está aprendida (no aporta nada). */
    public float critExp(Player player) {
        return isLearnedBy(player) ? getExp(player) : SpaceCriticals.NOT_LEARNED;
    }
}
