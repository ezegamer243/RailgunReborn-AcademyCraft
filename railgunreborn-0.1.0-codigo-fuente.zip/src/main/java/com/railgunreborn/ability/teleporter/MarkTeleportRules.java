package com.railgunreborn.ability.teleporter;

/**
 * Números y reglas de Mark Teleport ({@code docs/spec/mark-teleport.md}, mandan las decisiones del final), en Java puro
 * para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar ([DUDA] 9).
 */
public final class MarkTeleportRules {
    /** Por debajo de esta distancia (pies a pies) no hace nada. */
    public static final double MIN_DISTANCE = 3.0;
    /** El alcance crece 2 bloques por tick mantenido. */
    public static final double RANGE_PER_TICK = 2.0;
    public static final float EXP_PER_BLOCK = 0.00018f;
    public static final float SOUND_VOLUME = 0.4f;
    /** Mirando a un lado de un bloque: el destino se aparta esto de la pared. */
    public static final double WALL_OFFSET = 0.6;
    /** Mirando a un lado: pies a esta altura sobre la base del bloque golpeado. */
    public static final double SIDE_FEET_HEIGHT = 1.7;
    /** Mirando a un lado con un bloque a la altura de la cabeza: se baja esto. */
    public static final double SIDE_HEAD_DROP = 1.25;
    /** Holgura bajo un techo para que la cabeza no roce el bloque. */
    public static final double CEILING_GAP = 0.05;

    private MarkTeleportRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static double maxRange(float exp) {
        return lerp(25f, 60f, exp);
    }

    public static float cpPerBlock(float exp) {
        return lerp(12f, 4f, exp);
    }

    public static float overload(float exp) {
        return lerp(40f, 20f, exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(30f, 0f, exp);
    }

    /**
     * Alcance tras {@code heldTicks} ticks mantenidos: {@code (ticks + 1) * 2}, sin pasar del máximo ni de lo que el CP
     * disponible ({@code cpBudget}, sin multiplicadores) puede pagar.
     */
    public static double rangeNow(float exp, int heldTicks, double cpBudget) {
        double byTime = (Math.max(0, heldTicks) + 1) * RANGE_PER_TICK;
        return Math.max(0.0, Math.min(Math.min(byTime, maxRange(exp)), cpBudget / cpPerBlock(exp)));
    }

    /** Ticks mantenidos a partir de los cuales el alcance ya es el máximo (sin límite de CP). */
    public static int ticksToMaxRange(float exp) {
        return Math.max(0, (int) Math.ceil(maxRange(exp) / RANGE_PER_TICK) - 1);
    }

    /** CP a pagar por recorrer {@code distance}: por bloque, sin pasar de lo que hay ([DUDA] 7). */
    public static float cpCost(float exp, double distance, double cpBudget) {
        return (float) Math.max(0.0, Math.min(distance * cpPerBlock(exp), cpBudget));
    }

    public static float expGain(double distance) {
        return (float) (EXP_PER_BLOCK * distance);
    }

    public static boolean farEnough(double distance) {
        return distance >= MIN_DISTANCE;
    }

    /**
     * Destino (pies) al mirar al lado de un bloque (§5): {@code (x, z)} del impacto apartados {@link #WALL_OFFSET} según
     * la normal de la cara y pies a {@link #SIDE_FEET_HEIGHT} sobre la base del bloque. La comprobación de la cabeza va
     * aparte ({@link #sideHeadPos}/{@link #sideHeadAdjust}).
     */
    public static double[] sideDestination(double hitX, double hitZ, int normalX, int normalZ, int blockY) {
        return new double[] {hitX + normalX * WALL_OFFSET, blockY + SIDE_FEET_HEIGHT, hitZ + normalZ * WALL_OFFSET};
    }

    /** Bloque que se mira para la cabeza en el caso del lado: {@code floor} (no el truncado del original, [DUDA] 10). */
    public static int[] sideHeadPos(double[] feet) {
        return new int[] {(int) Math.floor(feet[0]), (int) Math.floor(feet[1] + 1), (int) Math.floor(feet[2])};
    }

    public static double sideHeadAdjust(double feetY, boolean headBlocked) {
        return headBlocked ? feetY - SIDE_HEAD_DROP : feetY;
    }

    /** Mirando a un techo: pies bajo el techo con la cabeza entera debajo (el original dejaba la cabeza dentro). */
    public static double ceilingFeetY(double hitY, double height) {
        return hitY - height - CEILING_GAP;
    }
}
