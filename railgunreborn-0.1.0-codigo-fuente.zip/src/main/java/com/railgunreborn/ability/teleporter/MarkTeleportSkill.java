package com.railgunreborn.ability.teleporter;

import java.util.Optional;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Mark Teleport: nivel 2 de Teleporter. Mantener la tecla hace crecer el alcance 2 bloques por tick (hasta el máximo y
 * lo que el CP pueda pagar); al soltar, el jugador aparece donde mira. Ficha: {@code docs/spec/mark-teleport.md}
 * (mandan las decisiones del final). Números en {@link MarkTeleportRules}.
 *
 * <p>Trazado solo de bloques (atraviesa mobs, agua y plantas). El destino se valida con {@link SafeTeleport}: sin
 * colisión ni peligros, posado en el suelo si lo hay a ≤ 3 bloques; si no hay hueco a ≥ 3 bloques se rechaza sin coste.
 * La silueta del destino la dibuja solo el cliente local con el mismo cálculo ({@link #aim}).
 */
public class MarkTeleportSkill extends Skill {
    /** Al teletransportar, a los cercanos: {@link #FROM_KEY} y {@link #TO_KEY} (pies). */
    public static final String CHANNEL_TELEPORT = "teleport";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";

    public MarkTeleportSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new MarkTeleportContext(player, this);
    }

    /** Resultado de apuntar. */
    public enum Status {
        OK,
        /** Menos de {@link MarkTeleportRules#MIN_DISTANCE}: no hace nada. */
        TOO_SHORT,
        /** No hay hueco seguro a ≥ 3 bloques: se rechaza sin coste. */
        NO_SPACE
    }

    /**
     * @param feet destino final (pies) si {@code OK}; si no, el destino sin validar (para pintar la silueta en rojo)
     */
    public record Aim(Status status, Vec3 feet) {
    }

    /** CP que se puede gastar, sin multiplicadores de la habilidad (en creativo, sin límite). */
    public static double cpBudget(Player player, Skill skill) {
        if (player.isCreative()) {
            return Double.MAX_VALUE;
        }
        // Un pelo por debajo para que el redondeo no haga fallar el consumo validado.
        return Math.max(0.0, CPData.get(player).getCP() / skill.getCpConsumeSpeed() - 1e-3);
    }

    /**
     * Destino sin validar (pies) a {@code range} bloques de los ojos, según lo que golpee el trazado de bloques (§5):
     * nada → los ojos quedan en el final del rayo; suelo → pies sobre la cara; techo → cabeza justo debajo; lado → reglas
     * del original (apartado 0.6 de la pared, pies a +1.7 de la base del bloque, −1.25 si la cabeza da con algo).
     */
    public static Vec3 rawDestination(Player player, double range) {
        Level level = player.level();
        Vec3 eyes = player.getEyePosition();
        Vec3 end = eyes.add(player.getViewVector(1.0f).scale(range));
        HitResult hit = level.clip(new ClipContext(eyes, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                player));
        double eyeHeight = player.getEyeHeight();
        if (hit.getType() != HitResult.Type.BLOCK || !(hit instanceof BlockHitResult blockHit)) {
            // Desviación del original (pies en el final del rayo): así se cabe por túneles de 2 de alto.
            return end.subtract(0, eyeHeight, 0);
        }
        Vec3 p = blockHit.getLocation();
        Direction face = blockHit.getDirection();
        return switch (face) {
            case UP -> p;
            case DOWN -> new Vec3(p.x, MarkTeleportRules.ceilingFeetY(p.y, player.getBbHeight()), p.z);
            default -> {
                double[] feet = MarkTeleportRules.sideDestination(p.x, p.z, face.getStepX(), face.getStepZ(),
                        blockHit.getBlockPos().getY());
                int[] head = MarkTeleportRules.sideHeadPos(feet);
                boolean blocked = !level.getBlockState(new BlockPos(head[0], head[1], head[2])).isAir();
                yield new Vec3(feet[0], MarkTeleportRules.sideHeadAdjust(feet[1], blocked), feet[2]);
            }
        };
    }

    /** Apunta con {@code range}: destino validado y distancia mínima. Sirve en ambos lados. */
    public static Aim aim(Player player, double range) {
        Vec3 from = player.position();
        Vec3 raw = rawDestination(player, range);
        if (!MarkTeleportRules.farEnough(from.distanceTo(raw))) {
            return new Aim(Status.TOO_SHORT, raw);
        }
        Optional<Vec3> safe = SafeTeleport.findSafe(player.level(), player, from, raw, MarkTeleportRules.MIN_DISTANCE);
        if (safe.isEmpty() || !MarkTeleportRules.farEnough(from.distanceTo(safe.get()))) {
            return new Aim(Status.NO_SPACE, raw);
        }
        return new Aim(Status.OK, safe.get());
    }

    public static final class MarkTeleportContext extends SkillContext {
        private final float exp;
        private int heldTicks;

        MarkTeleportContext(ServerPlayer player, MarkTeleportSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        /** Ticks mantenidos (para pruebas). */
        public int heldTicks() {
            return heldTicks;
        }

        @Override
        protected void onKeyTick() {
            heldTicks++;
        }

        @Override
        protected void onKeyUp() {
            ServerPlayer player = getPlayer();
            double budget = cpBudget(player, getSkill());
            Aim aim = aim(player, MarkTeleportRules.rangeNow(exp, heldTicks, budget));
            if (aim.status() != Status.OK) {
                if (aim.status() == Status.NO_SPACE) {
                    player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                }
                terminate();
                return;
            }
            Vec3 from = player.position();
            Vec3 dest = aim.feet();
            double distance = from.distanceTo(dest);
            if (!consume(MarkTeleportRules.overload(exp), MarkTeleportRules.cpCost(exp, distance, budget))) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
                return;
            }
            // Antes de moverse: lo reciben los cercanos al origen (y el propio jugador).
            CompoundTag effect = new CompoundTag();
            MagMovementSkill.writeVec(effect, FROM_KEY, from);
            MagMovementSkill.writeVec(effect, TO_KEY, dest);
            sendEffect(CHANNEL_TELEPORT, effect);

            SafeTeleport.teleport(player, dest);
            addSkillExp(MarkTeleportRules.expGain(distance));
            setCooldown(MarkTeleportRules.cooldown(exp));
            terminate();
        }
    }
}
