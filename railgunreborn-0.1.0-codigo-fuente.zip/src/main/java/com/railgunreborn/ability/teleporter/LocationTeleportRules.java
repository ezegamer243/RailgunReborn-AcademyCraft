package com.railgunreborn.ability.teleporter;

import java.util.ArrayList;
import java.util.List;

/**
 * Números y reglas de Location Teleport ({@code docs/spec/location-teleport.md}, mandan las decisiones del final), en
 * Java puro para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al calcular.
 */
public final class LocationTeleportRules {
    public static final int MAX_LOCATIONS = 16;
    public static final int MAX_NAME_LENGTH = 16;
    /** Distancia máxima (bloques) de las mascotas y animales atados que viajan contigo. */
    public static final double CARRY_RADIUS = 5.0;
    /** {@code ancho² * alto} a partir del cual una entidad no viaja (el Ender Dragon, como el original). */
    public static final double MAX_CARRY_VOLUME = 80.0;
    /** Decisión del usuario: 240 fijo, como el original. */
    public static final float OVERLOAD = 240f;
    /** Cruzar de dimensión exige exp estrictamente mayor que esto. */
    public static final float CROSS_DIMENSION_EXP = 0.8f;
    public static final double LONG_JUMP = 200.0;
    public static final float EXP_GAIN = 0.015f;
    public static final float EXP_GAIN_LONG = 0.03f;
    public static final float SOUND_VOLUME = 0.4f;
    /** Búsqueda de hueco alrededor de la ubicación guardada: radio horizontal y alturas probadas (arriba primero). */
    public static final int SEARCH_RADIUS = 1;
    private static final int[] SEARCH_DY = {0, 1, 2, -1};

    /** Por qué un destino no se puede usar (en este orden de comprobación). */
    public enum Problem {
        NONE,
        MISSING_DIMENSION,
        CROSS_DIMENSION_EXP,
        CP
    }

    private LocationTeleportRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cpBase(float exp) {
        return lerp(200f, 150f, exp);
    }

    /** {@code max(8, sqrt(min(800, d)))}. */
    public static double distanceFactor(double distance) {
        return Math.max(8.0, Math.sqrt(Math.min(800.0, Math.max(0.0, distance))));
    }

    /** CP sin multiplicadores de la habilidad; ×2 si el destino está en otra dimensión. */
    public static float cpCost(float exp, double distance, boolean crossDimension) {
        return (float) (cpBase(exp) * distanceFactor(distance) * (crossDimension ? 2 : 1));
    }

    public static float overload() {
        return OVERLOAD;
    }

    public static int cooldown(float exp) {
        return (int) lerp(30f, 20f, exp);
    }

    /** Exp por un teletransporte completado, con la distancia medida antes de moverse. */
    public static float expGain(double distance) {
        return distance >= LONG_JUMP ? EXP_GAIN_LONG : EXP_GAIN;
    }

    public static boolean canCrossDimension(float exp) {
        return exp > CROSS_DIMENSION_EXP;
    }

    public static boolean canAdd(int size) {
        return size < MAX_LOCATIONS;
    }

    public static boolean isValidIndex(int index, int size) {
        return index >= 0 && index < size;
    }

    /**
     * Motivo por el que no se puede ir (el de dimensión antes que el de CP, como el original), o {@link Problem#NONE}.
     */
    public static Problem check(boolean dimensionExists, boolean crossDimension, float exp, boolean enoughCp) {
        if (!dimensionExists) {
            return Problem.MISSING_DIMENSION;
        }
        if (crossDimension && !canCrossDimension(exp)) {
            return Problem.CROSS_DIMENSION_EXP;
        }
        return enoughCp ? Problem.NONE : Problem.CP;
    }

    /**
     * Nombre saneado en el servidor: sin caracteres de control ni '§' (formato), sin espacios a los lados y como mucho
     * {@value #MAX_NAME_LENGTH} caracteres (puntos de código, sin partir emojis). Vacío = la pantalla muestra el nombre
     * por defecto ("Ubicación N").
     */
    public static String sanitizeName(String raw) {
        if (raw == null) {
            return "";
        }
        StringBuilder out = new StringBuilder();
        raw.codePoints()
                .filter(cp -> cp >= ' ' && cp != 0x7F && cp != '§' && !Character.isISOControl(cp))
                .forEach(out::appendCodePoint);
        String trimmed = out.toString().strip();
        if (trimmed.codePointCount(0, trimmed.length()) > MAX_NAME_LENGTH) {
            trimmed = trimmed.substring(0, trimmed.offsetByCodePoints(0, MAX_NAME_LENGTH)).strip();
        }
        return trimmed;
    }

    /**
     * Quién viaja contigo (decisión del usuario): tus mascotas, los animales atados a ti y quien va montado contigo;
     * nunca otros jugadores ni hostiles, ni lo enorme.
     */
    public static boolean canCarry(boolean isPlayer, boolean hostile, boolean ownedByCaster, boolean leashedToCaster,
            boolean ridingWithCaster, double width, double height) {
        if (isPlayer || hostile || width * width * height >= MAX_CARRY_VOLUME) {
            return false;
        }
        return ownedByCaster || leashedToCaster || ridingWithCaster;
    }

    /**
     * Desplazamientos {@code {dx, dy, dz}} que se prueban alrededor de la ubicación guardada, en orden: el punto exacto,
     * luego más arriba, y después las columnas vecinas.
     */
    public static List<int[]> searchOffsets() {
        List<int[]> out = new ArrayList<>();
        for (int r = 0; r <= SEARCH_RADIUS; r++) {
            for (int dy : SEARCH_DY) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) == r) {
                            out.add(new int[] {dx, dy, dz});
                        }
                    }
                }
            }
        }
        return out;
    }
}
