package com.railgunreborn.ability.teleporter;

/**
 * Números de Flesh Ripping ({@code docs/spec/flesh-ripping.md}, §10 y decisiones del 2026-10-08), en Java puro para
 * probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class FleshRippingRules {
    /** Exp por impacto efectivo. */
    public static final float EXP_HIT = 0.005f;
    /** Probabilidad fija de que el lanzador se maree tras un impacto. */
    public static final float DISGUST_PROB = 0.05f;
    /** Duración de la Náusea del lanzador (5 s, como el original). */
    public static final int DISGUST_TICKS = 100;
    /** Volumen de {@code teleporter.guts} (0.6 en el original; decisión: 0.5). */
    public static final float SOUND_VOLUME = 0.5f;
    /** Salpicaduras de sangre por impacto (decisión: algo menos que las 4-6 del original). */
    public static final int BLOOD_MIN = 3;
    public static final int BLOOD_MAX = 5;
    public static final float BLOOD_SIZE_MIN = 0.5f;
    public static final float BLOOD_SIZE_MAX = 0.9f;

    private FleshRippingRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cp(float exp) {
        return lerp(130f, 270f, exp);
    }

    public static float overload(float exp) {
        return lerp(60f, 50f, exp);
    }

    public static float range(float exp) {
        return lerp(6f, 14f, exp);
    }

    /** Daño base antes del crítico y de {@code damage_scale}. */
    public static float damage(float exp) {
        return lerp(5f, 12f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(90f, 40f, exp);
    }

    /** {@code roll} en [0, 1): true si el lanzador se marea. */
    public static boolean disgusted(double roll) {
        return roll < DISGUST_PROB;
    }
}
