package com.railgunreborn.ability.teleporter;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;

/**
 * Daño de las habilidades de ataque de Teleporter con críticos de espacio ({@code TPSkillHelper} del original,
 * {@code space-criticals.md}). Lo usan Threatening Teleport, Flesh Ripping y Shift Teleport (una llamada por objetivo).
 *
 * <p>Flujo: exclusiones (uno mismo, mascotas propias, PvP, armor stands si se pide) → tirada del crítico con el
 * aleatorio del nivel → daño {@code base × multiplicador × damage_scale} con el {@link DamageType} dado (la armadura la
 * decide el tipo: {@code minecraft:bypasses_armor}) → <b>solo si el daño se aplicó</b> y hubo crítico: exp cruzada a
 * las pasivas <b>aprendidas</b>, aviso en la barra de acción al atacante y fórmulas visibles para los cercanos.
 *
 * <p>Es el único punto del mod donde una habilidad da exp a otra (las pasivas no tienen contexto).
 */
public final class TpDamage {
    // TODO(config): attackPlayer de la ficha, como en Arc Gen y MdDamage.
    public static final boolean ATTACK_PLAYER = true;

    /** Clave del aviso (la añade T55): "%sx critical hit!". */
    public static final String CRIT_MESSAGE_KEY = "railgunreborn.teleporter.crit";

    /** Resultado de un golpe: si el daño se aplicó y el nivel de crítico ({@link SpaceCriticals#NONE} si no hubo). */
    public record Result(boolean hurt, int tier) {
        public static final Result MISSED = new Result(false, SpaceCriticals.NONE);

        public boolean critical() {
            return tier != SpaceCriticals.NONE;
        }

        /** Multiplicador aplicado (1 sin crítico). */
        public float multiplier() {
            return SpaceCriticals.rate(tier);
        }
    }

    private TpDamage() {
    }

    /** Golpe normal: puede dañar armor stands y respeta la invulnerabilidad. */
    public static Result attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage) {
        return attack(player, skill, type, target, damage, false, false);
    }

    /**
     * @param damage                daño base, antes del crítico y de {@code damage_scale}
     * @param skipArmorStands       la habilidad no daña armor stands (cuenta como no aplicado)
     * @param ignoreInvulnerability pone a 0 los ticks de invulnerabilidad antes de dañar
     */
    public static Result attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage, boolean skipArmorStands, boolean ignoreInvulnerability) {
        return attack(player, skill, type, target, damage, skipArmorStands, ignoreInvulnerability,
                player.serverLevel().getRandom());
    }

    /** Igual, con el aleatorio de las tiradas dado (GameTests con semilla). */
    public static Result attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage, boolean skipArmorStands, boolean ignoreInvulnerability, RandomSource random) {
        if (!mayAttack(player, target, skipArmorStands)) {
            return Result.MISSED;
        }
        CritPassiveSkill dimFolding = Teleporter.DIM_FOLDING.get();
        CritPassiveSkill spaceFluct = Teleporter.SPACE_FLUCT.get();
        int tier = SpaceCriticals.roll(random, dimFolding.critExp(player), spaceFluct.critExp(player));
        if (ignoreInvulnerability) {
            target.invulnerableTime = 0;
        }
        float finalDamage = damage * SpaceCriticals.rate(tier) * skill.getDamageScale();
        boolean hurt = target.hurt(ModDamageTypes.source(player, type), finalDamage);
        if (!hurt) {
            return Result.MISSED;
        }
        if (tier != SpaceCriticals.NONE) {
            confirmCritical(player, target, tier, dimFolding, spaceFluct);
        }
        return new Result(true, tier);
    }

    /** Uno mismo, mascotas propias, armor stands (si se piden fuera) y jugadores protegidos por PvP no se dañan. */
    public static boolean mayAttack(ServerPlayer player, Entity target, boolean skipArmorStands) {
        if (target == player || !target.isAlive()) {
            return false;
        }
        if (target instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID())) {
            return false;
        }
        if (skipArmorStands && target instanceof ArmorStand) {
            return false;
        }
        return SkillTargets.mayHarm(player, target, ATTACK_PLAYER);
    }

    private static void confirmCritical(ServerPlayer player, Entity target, int tier, CritPassiveSkill dimFolding,
            CritPassiveSkill spaceFluct) {
        grantPassiveExp(player, dimFolding, SpaceCriticals.dimFoldingExpGain(tier));
        grantPassiveExp(player, spaceFluct, SpaceCriticals.SPACE_FLUCT_EXP_GAIN);
        player.displayClientMessage(Component.translatable(CRIT_MESSAGE_KEY, SpaceCriticals.formatRate(tier)), true);
        spawnFormulas(player.serverLevel(), target);
    }

    /** Exp a una pasiva solo si ya está aprendida (decisión: el árbol se aprende en el Developer). */
    static void grantPassiveExp(ServerPlayer player, CritPassiveSkill passive, float gain) {
        AbilityData data = AbilityData.get(player);
        if (data.isLearned(passive.getId())) {
            data.addSkillExp(passive.getId(), gain * passive.getExpIncrSpeed());
        }
    }

    /**
     * 5-7 fórmulas en una corona alrededor del objetivo ({@code CriticalHitEffect} del original): radio 0.5-0.7 × su
     * ancho, altura al azar dentro de su caja, deriva lenta. {@code sendParticles} con cuenta 0 manda la velocidad tal
     * cual y llega a los jugadores a menos de 32 bloques.
     */
    private static void spawnFormulas(ServerLevel level, Entity target) {
        RandomSource random = level.getRandom();
        int count = 5 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            float angle = random.nextFloat() * Mth.TWO_PI;
            double radius = target.getBbWidth() * Mth.nextDouble(random, 0.5, 0.7);
            double x = target.getX() + Mth.cos(angle) * radius;
            double y = target.getY() + random.nextDouble() * target.getBbHeight();
            double z = target.getZ() + Mth.sin(angle) * radius;
            level.sendParticles(ModParticles.FORMULA.get(), x, y, z, 0,
                    random.nextGaussian() * 0.03, random.nextGaussian() * 0.03, random.nextGaussian() * 0.03, 1.0);
        }
    }
}
