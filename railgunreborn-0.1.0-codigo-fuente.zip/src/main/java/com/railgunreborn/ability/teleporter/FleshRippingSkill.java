package com.railgunreborn.ability.teleporter;

import java.util.function.DoubleSupplier;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Flesh Ripping: mantener y soltar. Al soltar daña al ser vivo mirado (con línea de visión) ignorando la armadura;
 * 5 % de probabilidad de que el lanzador reciba Náusea. CP y overload se comprueban al pulsar y al soltar; cobro,
 * cooldown, exp y náusea solo con impacto efectivo. Ficha: {@code docs/spec/flesh-ripping.md}.
 */
public class FleshRippingSkill extends Skill {
    /** Canal {@code rip}: {@link #TARGET_KEY} = id de entidad del objetivo. */
    public static final String CHANNEL_RIP = "rip";
    public static final String TARGET_KEY = "target";

    /** Solo para GameTests: sustituye a la tirada de náusea ({@code null} = aleatorio del nivel). */
    @Nullable
    public static volatile DoubleSupplier disgustRollOverride;

    public FleshRippingSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new FleshRippingContext(player, this);
    }

    private static final class FleshRippingContext extends SkillContext {
        private final float exp;

        FleshRippingContext(ServerPlayer player, FleshRippingSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            if (!canConsume(FleshRippingRules.overload(exp), FleshRippingRules.cp(exp))) {
                getPlayer().playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            fire();
            terminate();
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            float cp = FleshRippingRules.cp(exp);
            float overload = FleshRippingRules.overload(exp);
            if (!canConsume(overload, cp)) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return;
            }
            // Se traza al soltar (no hay objetivo guardado de ticks anteriores): soltar rápido no falla.
            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0f).scale(FleshRippingRules.range(exp)));
            Entity target = ElectronBombSkill.traceRay(player, eye, end).entity();
            if (target == null) {
                return;
            }
            var result = TpDamage.attack(player, getSkill(), ModDamageTypes.FLESH_RIPPING, target,
                    FleshRippingRules.damage(exp));
            if (!result.hurt()) {
                return;
            }
            consume(overload, cp);
            addSkillExp(FleshRippingRules.EXP_HIT);
            setCooldown(FleshRippingRules.cooldownTicks(exp));

            DoubleSupplier override = disgustRollOverride;
            double roll = override != null ? override.getAsDouble() : player.getRandom().nextDouble();
            if (FleshRippingRules.disgusted(roll)) {
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, FleshRippingRules.DISGUST_TICKS, 0));
            }

            CompoundTag data = new CompoundTag();
            data.putInt(TARGET_KEY, target.getId());
            sendEffect(CHANNEL_RIP, data);
        }
    }
}
