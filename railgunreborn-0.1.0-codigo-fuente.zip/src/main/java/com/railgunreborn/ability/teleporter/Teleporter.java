package com.railgunreborn.ability.teleporter;

import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.generic.GenericSkill;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

/**
 * Categoría Teleporter y sus habilidades ({@code docs/spec/teleporter.md}: niveles, padres y posiciones del árbol).
 *
 * <p>Por ahora solo las dos pasivas de los críticos de espacio; cada habilidad activa se añade en su tarea (T57-T63)
 * respetando el orden del original: threatening_teleport, dim_folding_theorem, penetrate_teleport, mark_teleport,
 * flesh_ripping, location_teleport, shift_tp, space_fluct, flashing; luego las genéricas. Los padres se declaran por
 * id: mientras la habilidad padre no exista en el registro, {@link Skill.Dependency#isMet} la ignora.
 */
public final class Teleporter {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "teleporter");

    /** Color de estilo del original: RGBA 164, 164, 164, 145 (alfa sobre 255). */
    public static final int COLOR = 0x91A4A4A4;

    public static final DeferredHolder<Category, Category> CATEGORY =
            AbilityRegistries.CATEGORIES.register(ID.getPath(), () -> new Category(COLOR, 1.0f));

    public static final ResourceLocation THREATENING_TELEPORT_ID = skillId("threatening_teleport");
    public static final ResourceLocation SHIFT_TP_ID = skillId("shift_tp");

    public static final ResourceLocation DIM_FOLDING_ID = skillId("dim_folding_theorem");
    public static final ResourceLocation SPACE_FLUCT_ID = skillId("space_fluct");

    public static final DeferredHolder<Skill, ThreateningTeleportSkill> THREATENING_TELEPORT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/threatening_teleport",
                    () -> new ThreateningTeleportSkill(new Skill.Properties(ID, 1)
                            .guiPos(14, 42)));

    public static final DeferredHolder<Skill, CritPassiveSkill> DIM_FOLDING =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/dim_folding_theorem",
                    () -> new CritPassiveSkill(new Skill.Properties(ID, 1)
                            .passive()
                            .parent(THREATENING_TELEPORT_ID, 0.2f)
                            .guiPos(50, 75)));

    // Penetrate Teleport va antes de Mark Teleport (orden del original).
    public static final ResourceLocation PENETRATE_TELEPORT_ID = skillId("penetrate_teleport");
    public static final DeferredHolder<Skill, PenetrateTeleportSkill> PENETRATE_TELEPORT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/penetrate_teleport",
                    () -> new PenetrateTeleportSkill(new Skill.Properties(ID, 2)
                            .parent(THREATENING_TELEPORT_ID, 0.5f)
                            .guiPos(60, 46)));

    public static final DeferredHolder<Skill, MarkTeleportSkill> MARK_TELEPORT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/mark_teleport",
                    () -> new MarkTeleportSkill(new Skill.Properties(ID, 2)
                            .parent(THREATENING_TELEPORT_ID, 0.4f)
                            .guiPos(70, 16)));

    public static final DeferredHolder<Skill, FleshRippingSkill> FLESH_RIPPING =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/flesh_ripping",
                    () -> new FleshRippingSkill(new Skill.Properties(ID, 3)
                            .parent(skillId("mark_teleport"), 0.5f)
                            .dependency(skillId("penetrate_teleport"), 0.5f)
                            .guiPos(130, 12)));

    // Location Teleport (después de Flesh Ripping, antes de Shift Teleport, que cuelga de ella).
    public static final ResourceLocation LOCATION_TELEPORT_ID = skillId("location_teleport");
    public static final DeferredHolder<Skill, LocationTeleportSkill> LOCATION_TELEPORT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/location_teleport",
                    () -> new LocationTeleportSkill(new Skill.Properties(ID, 3)
                            .parent(PENETRATE_TELEPORT_ID, 0.8f)
                            .dependency(skillId("mark_teleport"), 0.8f)
                            .guiPos(118, 50)));

    // Shift Teleport: antes de Space Fluctuation, que cuelga de ella.
    public static final DeferredHolder<Skill, ShiftTeleportSkill> SHIFT_TP =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/shift_tp",
                    () -> new ShiftTeleportSkill(new Skill.Properties(ID, 4)
                            .parent(LOCATION_TELEPORT_ID, 0.5f)
                            .guiPos(175, 47)));

    public static final DeferredHolder<Skill, CritPassiveSkill> SPACE_FLUCT =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/space_fluct",
                    () -> new CritPassiveSkill(new Skill.Properties(ID, 4)
                            .passive()
                            .parent(SHIFT_TP_ID, 0.0f)
                            .guiPos(160, 80)));

    // Flashing: la última habilidad propia (T63).
    public static final DeferredHolder<Skill, FlashingSkill> FLASHING =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/flashing",
                    () -> new FlashingSkill(new Skill.Properties(ID, 5)
                            .parent(SHIFT_TP_ID, 0.8f)
                            .guiPos(220, 20)));

    // Siempre después de las habilidades propias (orden estable del registro).
    public static final Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> GENERICS =
            GenericSkill.registerFor(AbilityRegistries.SKILLS, ID);

    private Teleporter() {
    }

    public static ResourceLocation skillId(String name) {
        return ID.withPath(p -> p + "/" + name);
    }

    /** Solo fuerza la carga de la clase (y con ella el registro de las entradas de arriba). */
    public static void init() {
    }
}
