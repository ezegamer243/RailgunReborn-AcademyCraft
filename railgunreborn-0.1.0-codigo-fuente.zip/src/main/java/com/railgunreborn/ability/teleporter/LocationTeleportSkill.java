package com.railgunreborn.ability.teleporter;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.LocationData.SavedLocation;
import com.railgunreborn.network.DataSync;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.SectionPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Leashable;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Location Teleport: nivel 3 de Teleporter. Un toque abre la pantalla de ubicaciones guardadas (cliente); el contexto
 * de servidor sigue vivo mientras está abierta y recibe por su canal {@link #CHANNEL_ADD}, {@link #CHANNEL_REMOVE} y
 * {@link #CHANNEL_TELEPORT}. El servidor valida todo con su propia lista (nunca se fía de coordenadas del cliente).
 * Ficha: {@code docs/spec/location-teleport.md} (mandan las decisiones del final). Números en
 * {@link LocationTeleportRules}.
 */
public class LocationTeleportSkill extends Skill {
    /** Cliente → servidor: {@link #NAME_KEY}. Guarda la posición actual. */
    public static final String CHANNEL_ADD = "add";
    /** Cliente → servidor: {@link #INDEX_KEY}. */
    public static final String CHANNEL_REMOVE = "remove";
    /** Cliente → servidor: {@link #INDEX_KEY}. */
    public static final String CHANNEL_TELEPORT = "teleport";
    public static final String NAME_KEY = "name";
    public static final String INDEX_KEY = "index";

    private static final String LANG = "railgunreborn.gui.location_teleport.";

    public LocationTeleportSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new LocationContext(player, this);
    }

    /** Distancia que cuenta para el coste y la exp; entre dimensiones, la de las coordenadas (como el original). */
    public static double distance(Player player, SavedLocation location) {
        return player.position().distanceTo(location.pos());
    }

    public static boolean crossesDimension(Player player, SavedLocation location) {
        return !player.level().dimension().equals(location.dimension());
    }

    /** CP sin multiplicadores de la habilidad. */
    public static float cpCost(float exp, Player player, SavedLocation location) {
        return LocationTeleportRules.cpCost(exp, distance(player, location), crossesDimension(player, location));
    }

    /** Clave de lang del motivo, o null si no hay problema. */
    @Nullable
    public static String problemKey(LocationTeleportRules.Problem problem) {
        return switch (problem) {
            case NONE -> null;
            case MISSING_DIMENSION -> LANG + "err_missing_dimension";
            case CROSS_DIMENSION_EXP -> LANG + "err_exp";
            case CP -> LANG + "err_cp";
        };
    }

    /**
     * Destino seguro (pies) para {@code entity} cerca de {@code feet} en {@code level}: el punto exacto o un hueco a
     * pocos bloques ({@link LocationTeleportRules#searchOffsets()}), validado con {@link SafeTeleport#validate}. Carga
     * los chunks necesarios (sin tickets permanentes).
     */
    public static Optional<Vec3> findDestination(ServerLevel level, Entity entity, Vec3 feet) {
        if (!level.getWorldBorder().isWithinBounds(feet.x, feet.z)) {
            return Optional.empty();
        }
        // Con margen para los acompañantes, que llegan a su sitio relativo (hasta 5 bloques).
        loadChunksAround(level, feet, LocationTeleportRules.CARRY_RADIUS + 2);
        for (int[] offset : LocationTeleportRules.searchOffsets()) {
            Optional<Vec3> safe = SafeTeleport.validate(level, entity, feet.add(offset[0], offset[1], offset[2]));
            if (safe.isPresent()) {
                return safe;
            }
        }
        return Optional.empty();
    }

    private static void loadChunksAround(ServerLevel level, Vec3 center, double radius) {
        int minX = SectionPos.blockToSectionCoord(Math.floor(center.x - radius));
        int maxX = SectionPos.blockToSectionCoord(Math.floor(center.x + radius));
        int minZ = SectionPos.blockToSectionCoord(Math.floor(center.z - radius));
        int maxZ = SectionPos.blockToSectionCoord(Math.floor(center.z + radius));
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                level.getChunk(x, z);
            }
        }
    }

    /**
     * Quién viaja con el jugador: lo que monta o lo que lleva encima, y sus mascotas y animales atados a menos de
     * {@link LocationTeleportRules#CARRY_RADIUS} bloques. Nunca otros jugadores ni hostiles.
     */
    public static List<Entity> companions(ServerPlayer player) {
        Set<Entity> riding = new LinkedHashSet<>();
        Entity root = player.getRootVehicle();
        if (root != player) {
            riding.add(root);
        }
        for (Entity passenger : root.getIndirectPassengers()) {
            riding.add(passenger);
        }
        riding.remove(player);

        Set<Entity> out = new LinkedHashSet<>();
        for (Entity entity : riding) {
            if (canCarry(player, entity, true)) {
                out.add(entity);
            }
        }
        double r = LocationTeleportRules.CARRY_RADIUS;
        for (LivingEntity entity : player.serverLevel().getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(r),
                e -> e != player && e.isAlive() && e.distanceTo(player) <= r)) {
            if (canCarry(player, entity, false)) {
                out.add(entity);
            }
        }
        return new ArrayList<>(out);
    }

    private static boolean canCarry(ServerPlayer player, Entity entity, boolean riding) {
        boolean owned = entity instanceof OwnableEntity ownable && player.getUUID().equals(ownable.getOwnerUUID());
        boolean leashed = entity instanceof Leashable leashable && leashable.isLeashed()
                && leashable.getLeashHolder() == player;
        return LocationTeleportRules.canCarry(entity instanceof Player, entity instanceof Enemy, owned, leashed, riding,
                entity.getBbWidth(), entity.getBbHeight());
    }

    public static final class LocationContext extends SkillContext {
        LocationContext(ServerPlayer player, LocationTeleportSkill skill) {
            super(player, skill);
        }

        /** La pantalla sigue abierta aunque se suelte la tecla: la cierra el cliente al terminar el contexto. */
        @Override
        protected void onKeyUp() {
        }

        @Override
        protected void onClientMessage(String channel, CompoundTag data) {
            switch (channel) {
                case CHANNEL_ADD -> add(data.getString(NAME_KEY));
                case CHANNEL_REMOVE -> remove(data.getInt(INDEX_KEY));
                case CHANNEL_TELEPORT -> teleport(data.getInt(INDEX_KEY));
                default -> {
                }
            }
        }

        /** Guarda la posición actual de los pies (sin coste). */
        public void add(String rawName) {
            ServerPlayer player = getPlayer();
            LocationData data = LocationData.get(player);
            if (data.isFull()) {
                deny(LANG + "err_full");
                return;
            }
            data.add(new SavedLocation(LocationTeleportRules.sanitizeName(rawName), player.level().dimension(),
                    player.position()));
            DataSync.sendLocations(player);
        }

        public void remove(int index) {
            ServerPlayer player = getPlayer();
            if (LocationData.get(player).remove(index)) {
                DataSync.sendLocations(player);
            }
        }

        /**
         * Teletransporta a la ubicación {@code index} de la lista del servidor. Si algo falla (dimensión, exp, CP,
         * destino bloqueado) avisa en la barra de acción sin cobrar y el contexto sigue vivo.
         */
        public void teleport(int index) {
            ServerPlayer player = getPlayer();
            Optional<SavedLocation> found = LocationData.get(player).get(index);
            if (found.isEmpty() || !player.isAlive() || CooldownData.get(player).isInCooldown(getSkill().getId())) {
                return;
            }
            SavedLocation location = found.get();
            float exp = getSkillExp();
            ServerLevel target = player.server.getLevel(location.dimension());
            boolean cross = crossesDimension(player, location);
            double distance = distance(player, location);
            float cp = LocationTeleportRules.cpCost(exp, distance, cross);
            LocationTeleportRules.Problem problem = LocationTeleportRules.check(target != null, cross, exp,
                    canConsume(LocationTeleportRules.overload(), cp));
            if (problem != LocationTeleportRules.Problem.NONE) {
                deny(problemKey(problem));
                return;
            }
            Optional<Vec3> dest = findDestination(target, player, location.pos());
            if (dest.isEmpty()) {
                deny(LANG + "err_blocked");
                return;
            }
            List<Entity> companions = companions(player);
            Entity vehicle = player.getVehicle();
            List<Entity> passengers = List.copyOf(player.getPassengers());
            if (!consume(LocationTeleportRules.overload(), cp)) {
                deny(LANG + "err_cp");
                return;
            }

            Vec3 from = player.position();
            ServerLevel origin = player.serverLevel();
            origin.playSound(null, from.x, from.y, from.z, ModSounds.TP.get(), SoundSource.PLAYERS,
                    LocationTeleportRules.SOUND_VOLUME, 1f);
            Map<Entity, Vec3> offsets = new IdentityHashMap<>();
            for (Entity companion : companions) {
                offsets.put(companion, companion.position().subtract(from));
            }
            // Ya cobrado: si otro mod cancela el cambio de dimensión, no hay más que hacer.
            if (!SafeTeleport.teleport(player, target, dest.get())) {
                terminate();
                return;
            }
            Vec3 arrived = dest.get();
            Map<Entity, Entity> moved = new IdentityHashMap<>();
            for (Entity companion : companions) {
                Entity result = moveCompanion(companion, target, arrived, offsets.get(companion));
                if (result != null) {
                    moved.put(companion, result);
                }
            }
            // Se vuelve a montar como estaba si las monturas/pasajeros llegaron.
            Entity newVehicle = vehicle == null ? null : moved.get(vehicle);
            if (newVehicle != null && newVehicle.level() == player.level()) {
                player.startRiding(newVehicle, true);
            }
            for (Entity passenger : passengers) {
                Entity newPassenger = moved.get(passenger);
                if (newPassenger != null && newPassenger.level() == player.level()) {
                    newPassenger.startRiding(player, true);
                }
            }
            target.playSound(null, arrived.x, arrived.y, arrived.z, ModSounds.TP.get(), SoundSource.PLAYERS,
                    LocationTeleportRules.SOUND_VOLUME, 1f);
            addSkillExp(LocationTeleportRules.expGain(distance));
            setCooldown(LocationTeleportRules.cooldown(exp));
            terminate();
        }

        /** Lleva un acompañante a su sitio relativo, o a los pies del jugador si no cabe; si tampoco, se queda. */
        @Nullable
        private static Entity moveCompanion(Entity companion, ServerLevel level, Vec3 playerFeet, Vec3 offset) {
            if (!companion.isAlive()) {
                return null;
            }
            Optional<Vec3> spot = SafeTeleport.validate(level, companion, playerFeet.add(offset));
            if (spot.isEmpty()) {
                spot = SafeTeleport.validate(level, companion, playerFeet);
            }
            return spot.map(pos -> SafeTeleport.teleportEntity(companion, level, pos)).orElse(null);
        }

        private void deny(@Nullable String key) {
            ServerPlayer player = getPlayer();
            if (key != null) {
                player.displayClientMessage(Component.translatable(key), true);
            }
            player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
        }
    }
}
