package com.railgunreborn.ability.teleporter;

import java.util.Optional;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.common.SafeTeleportRules;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Flashing: nivel 5 de Teleporter. Un modo temporal en el que soltar W/A/S/D teletransporta unos bloques en esa
 * dirección. Ficha: {@code docs/spec/flashing.md} (mandan las decisiones del final). Números en {@link FlashingRules}.
 *
 * <p>El contexto vive hasta que acaba el modo (soltar la tecla de la habilidad no lo termina). El cliente solo dice la
 * dirección; el destino lo calcula el servidor con su propia mirada barriendo la caja del jugador hasta el primer
 * bloque ({@link #destination}), sin posarlo en el suelo. La flotación tras cada salto la hace el cliente.
 */
public class FlashingSkill extends Skill {
    /** Servidor → jugador: el modo arrancó, con {@link #MAX_TICKS_KEY}. */
    public static final String CHANNEL_START = "start";
    /** Jugador → servidor: salto con {@link #DIR_KEY}. Servidor → jugador: el salto ocurrió (flotación). */
    public static final String CHANNEL_JUMP = "jump";
    /** Efecto para los cercanos: {@link #FROM_KEY} y {@link #TO_KEY} (pies). */
    public static final String CHANNEL_PERFORM = "perform";
    public static final String MAX_TICKS_KEY = "max";
    public static final String DIR_KEY = "dir";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";
    /** Margen sobre la flotación para la protección de caída del servidor (se quita sola al aterrizar). */
    private static final int FALL_GUARD_MARGIN = 20;

    public FlashingSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new FlashingContext(player, this);
    }

    /** El modo no depende de mantener la tecla: volver a pulsarla o V lo terminan. */
    @Override
    public boolean isToggle() {
        return true;
    }

    /**
     * Destino (pies) de un salto en {@code dir} con la mirada actual de {@code player}: la caja avanza en línea recta
     * hasta {@code distance} o hasta el primer bloque, y retrocede si el punto no es seguro (lava, fuego...). Vacío si
     * no queda hueco a {@link FlashingRules#MIN_JUMP} o más. Sirve en ambos lados (el cliente pinta el marcador).
     */
    public static Optional<Vec3> destination(Player player, FlashingRules.Dir dir, double distance) {
        double[] d = FlashingRules.direction(dir, player.getYRot(), player.getXRot());
        Vec3 unit = new Vec3(d[0], d[1], d[2]);
        Level level = player.level();
        Vec3 from = player.position();
        AABB box = SafeTeleport.boxAt(player, from);
        double free = FlashingRules.sweep(distance, t -> isFree(level, player, box.move(unit.scale(t))));
        return SafeTeleportRules.backOff(free, FlashingRules.MIN_JUMP, SafeTeleportRules.BACK_OFF_STEP, t -> {
            Vec3 feet = from.add(unit.scale(t));
            return SafeTeleport.isSafeSpot(level, player, feet) ? Optional.of(feet) : Optional.empty();
        });
    }

    /** Sin bloques ni entidades sólidas, dentro del mundo y con los chunks cargados (los no cargados no chocan). */
    private static boolean isFree(Level level, Player player, AABB box) {
        return box.minY >= level.getMinBuildHeight()
                && level.getWorldBorder().isWithinBounds(box)
                && level.hasChunksAt((int) Math.floor(box.minX), (int) Math.floor(box.minZ),
                        (int) Math.floor(box.maxX), (int) Math.floor(box.maxZ))
                && level.noCollision(player, box);
    }

    public static final class FlashingContext extends SkillContext {
        private final float exp;
        private final int maxTicks;
        /** Se cobró el arranque: solo entonces hay cooldown al terminar. */
        private boolean started;
        /** Overload tras cobrar el arranque: no se deja bajar mientras dure el modo. */
        private float overloadKeep;
        private int jumps;

        FlashingContext(ServerPlayer player, FlashingSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
            this.maxTicks = FlashingRules.maxTicks(exp);
        }

        public boolean isStarted() {
            return started;
        }

        /** Saltos hechos (para pruebas). */
        public int jumps() {
            return jumps;
        }

        @Override
        protected void onKeyDown() {
            if (!consume(FlashingRules.startOverload(exp), FlashingRules.startCp(exp))) {
                getPlayer().playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
                return;
            }
            started = true;
            overloadKeep = CPData.get(getPlayer()).getOverload();
            CompoundTag data = new CompoundTag();
            data.putInt(MAX_TICKS_KEY, maxTicks);
            sendToLocal(CHANNEL_START, data);
        }

        @Override
        protected void tick() {
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadKeep);
            MagMovementSkill.resetFlying(player);
            if (getTicksAlive() >= maxTicks) {
                terminate();
            }
        }

        @Override
        protected void onClientMessage(String channel, CompoundTag data) {
            if (!started || !CHANNEL_JUMP.equals(channel)) {
                return;
            }
            FlashingRules.Dir dir = FlashingRules.Dir.byId(data.getInt(DIR_KEY));
            if (dir == null) {
                return;
            }
            jump(dir);
        }

        /** Un salto: sin hueco o sin CP no ocurre ni se cobra (el modo sigue). */
        public boolean jump(FlashingRules.Dir dir) {
            ServerPlayer player = getPlayer();
            Optional<Vec3> dest = destination(player, dir, FlashingRules.distance(exp));
            if (dest.isEmpty() || !consume(0f, FlashingRules.jumpCp(exp))) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return false;
            }
            Vec3 from = player.position();
            Vec3 to = dest.get();
            // Antes de moverse: lo reciben los cercanos al origen (y el propio jugador).
            CompoundTag effect = new CompoundTag();
            MagMovementSkill.writeVec(effect, FROM_KEY, from);
            MagMovementSkill.writeVec(effect, TO_KEY, to);
            sendEffect(CHANNEL_PERFORM, effect);

            SafeTeleport.teleport(player, to);
            SafeTeleport.guardFall(player, FlashingRules.HOVER_TICKS + FALL_GUARD_MARGIN);
            addSkillExp(FlashingRules.JUMP_EXP);
            jumps++;
            sendToLocal(CHANNEL_JUMP, new CompoundTag());
            return true;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            if (started) {
                started = false;
                setCooldown(FlashingRules.cooldown(exp));
            }
        }
    }
}
