package com.railgunreborn.ability.teleporter;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * Threatening Teleport: mantener y soltar. Al soltar, el ítem de la mano principal se teletransporta contra el ser
 * vivo mirado (con línea de visión) y le hace daño que ignora la armadura. El ítem nunca se pierde: cae junto al
 * objetivo. Cobro, cooldown y exp solo con impacto efectivo. Ficha: {@code docs/spec/threatening-teleport.md}.
 */
public class ThreateningTeleportSkill extends Skill {
    /** Canal {@code execute}: {@link #POS_KEY} = punto de caída del ítem (x, y, z en el mundo). */
    public static final String CHANNEL_EXECUTE = "execute";
    public static final String POS_KEY = "pos";

    public ThreateningTeleportSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ThreateningContext(player, this);
    }

    private static final class ThreateningContext extends SkillContext {
        private final float exp;

        ThreateningContext(ServerPlayer player, ThreateningTeleportSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            ItemStack held = getPlayer().getItemInHand(InteractionHand.MAIN_HAND);
            if (held.isEmpty()) {
                terminate();
            } else if (blockedByNeedleOnly(held)) {
                getPlayer().playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
            }
        }

        /** Opción {@code needleonly}: con ella activa, cualquier ítem que no sea la aguja no dispara. */
        private boolean blockedByNeedleOnly(ItemStack held) {
            return AbilityData.get(getPlayer()).isNeedleOnly() && !held.is(ModItems.NEEDLE.get());
        }

        @Override
        protected void tick() {
            if (getPlayer().getItemInHand(InteractionHand.MAIN_HAND).isEmpty()) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            fire();
            terminate();
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
            float cp = ThreateningRules.cp(exp);
            float overload = ThreateningRules.overload(exp);
            if (held.isEmpty() || blockedByNeedleOnly(held) || !canConsume(overload, cp)) {
                return;
            }
            // Un solo trazado de bloques y seres vivos: las paredes protegen.
            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0f).scale(ThreateningRules.range(exp)));
            Entity target = ElectronBombSkill.traceRay(player, eye, end).entity();
            if (target == null) {
                return;
            }
            boolean needle = held.is(ModItems.NEEDLE.get());
            var result = TpDamage.attack(player, getSkill(), ModDamageTypes.THREATENING_TELEPORT, target,
                    ThreateningRules.baseDamage(exp, needle));
            if (!result.hurt()) {
                return;
            }
            consume(overload, cp);

            Vec3 drop = dropPoint(player, target);
            if (!player.getAbilities().instabuild) {
                ItemStack one = held.copyWithCount(1);
                held.shrink(1);
                ItemEntity entity = new ItemEntity(player.serverLevel(), drop.x, drop.y, drop.z, one);
                entity.setDefaultPickUpDelay();
                player.serverLevel().addFreshEntity(entity);
            }
            addSkillExp(ThreateningRules.EXP_HIT);
            setCooldown(ThreateningRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            CompoundTag pos = new CompoundTag();
            pos.putDouble("x", drop.x);
            pos.putDouble("y", drop.y);
            pos.putDouble("z", drop.z);
            data.put(POS_KEY, pos);
            sendEffect(CHANNEL_EXECUTE, data);
        }

        /** A los pies del objetivo, 0.2 bloques hacia el tirador. */
        private static Vec3 dropPoint(ServerPlayer player, Entity target) {
            Vec3 feet = target.position();
            Vec3 toShooter = new Vec3(player.getX() - feet.x, 0, player.getZ() - feet.z);
            if (toShooter.lengthSqr() < 1.0e-6) {
                return feet;
            }
            return feet.add(toShooter.normalize().scale(ThreateningRules.DROP_OFFSET));
        }
    }
}
