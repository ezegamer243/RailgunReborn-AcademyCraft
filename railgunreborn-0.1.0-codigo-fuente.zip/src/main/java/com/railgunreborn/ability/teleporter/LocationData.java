package com.railgunreborn.ability.teleporter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Ubicaciones guardadas de Location Teleport ({@code location-teleport.md} §5 y §13.2): como mucho
 * {@value LocationTeleportRules#MAX_LOCATIONS}, en orden de creación, con nombre, dimensión y posición exacta de los
 * pies. Mismo patrón que {@code PresetData}: clase mutable, Codec tolerante y {@link #consumeDirty()} para
 * {@code network.DataSync}. El servidor es la autoridad; el cliente solo lee la copia sincronizada.
 */
public final class LocationData {
    /** Una ubicación. {@code name} vacío = nombre por defecto al mostrarla. */
    public record SavedLocation(String name, ResourceKey<Level> dimension, Vec3 pos) {
        // Cada campo cae a su valor por defecto si viene roto, en lugar de perder la entrada (o la lista).
        public static final Codec<SavedLocation> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                Codec.STRING.lenientOptionalFieldOf("name", "").forGetter(SavedLocation::name),
                Level.RESOURCE_KEY_CODEC.lenientOptionalFieldOf("dimension", Level.OVERWORLD)
                        .forGetter(SavedLocation::dimension),
                Codec.DOUBLE.lenientOptionalFieldOf("x", 0.0).forGetter(l -> l.pos.x),
                Codec.DOUBLE.lenientOptionalFieldOf("y", 0.0).forGetter(l -> l.pos.y),
                Codec.DOUBLE.lenientOptionalFieldOf("z", 0.0).forGetter(l -> l.pos.z)
        ).apply(inst, (name, dim, x, y, z) -> new SavedLocation(LocationTeleportRules.sanitizeName(name), dim,
                new Vec3(x, y, z))));
    }

    public static final Codec<LocationData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            SavedLocation.CODEC.listOf().lenientOptionalFieldOf("locations", List.of())
                    .forGetter(LocationData::list)
    ).apply(inst, LocationData::fromSaved));

    private final List<SavedLocation> locations = new ArrayList<>();
    private boolean dirty;

    public LocationData() {
    }

    private static LocationData fromSaved(List<SavedLocation> saved) {
        LocationData data = new LocationData();
        for (SavedLocation location : saved) {
            if (!data.add(location)) {
                break;
            }
        }
        data.dirty = false;
        return data;
    }

    public static LocationData get(Player player) {
        return player.getData(ModAttachments.LOCATION_DATA);
    }

    public List<SavedLocation> list() {
        return Collections.unmodifiableList(locations);
    }

    public int size() {
        return locations.size();
    }

    public boolean isFull() {
        return !LocationTeleportRules.canAdd(locations.size());
    }

    public Optional<SavedLocation> get(int index) {
        return LocationTeleportRules.isValidIndex(index, locations.size())
                ? Optional.of(locations.get(index))
                : Optional.empty();
    }

    /** Añade al final. false si la lista está llena. El nombre debe venir ya saneado. */
    public boolean add(SavedLocation location) {
        if (isFull()) {
            return false;
        }
        locations.add(location);
        dirty = true;
        return true;
    }

    /** Borra por índice. false si el índice no existe. */
    public boolean remove(int index) {
        if (!LocationTeleportRules.isValidIndex(index, locations.size())) {
            return false;
        }
        locations.remove(index);
        dirty = true;
        return true;
    }

    public boolean isDirty() {
        return dirty;
    }

    /** Devuelve si había cambios pendientes y los limpia (el envío es siempre completo). */
    public boolean consumeDirty() {
        boolean was = dirty;
        dirty = false;
        return was;
    }
}
