package com.railgunreborn.ability.teleporter;

import java.util.List;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Shift Teleport: nivel 4 de Teleporter. Mantener y soltar con un bloque en la mano principal: el bloque aparece en la
 * celda contigua a donde miras (o en el aire, al final del alcance, si no miras a nada) y daña a los seres vivos de la
 * línea entre los ojos y esa celda. Ficha: {@code docs/spec/shift-teleport.md} (mandan las decisiones del final).
 * Números en {@link ShiftTeleportRules}.
 *
 * <p>La colocación es la de un ítem normal ({@link ItemStack#useOn}): dispara los eventos de colocación de NeoForge
 * (mods de protección) y gasta 1 unidad salvo en creativo. Si no se puede colocar, la unidad cae como ítem.
 */
public class ShiftTeleportSkill extends Skill {
    /** Al ejecutar, a los cercanos: {@link #FROM_KEY} (ojos) y {@link #TO_KEY} (centro de la celda destino). */
    public static final String CHANNEL_EXECUTE = "execute";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";

    public ShiftTeleportSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new ShiftTeleportContext(player, this);
    }

    /** Un {@link BlockItem} de bloque distinto de aire. */
    public static boolean isValidBlock(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() instanceof BlockItem item
                && !item.getBlock().defaultBlockState().is(Blocks.AIR);
    }

    /**
     * @param hit  el "clic" con el que se coloca (real si se golpeó un bloque; sintético en la celda si es al aire)
     * @param dest celda donde iría el bloque
     */
    public record Aim(BlockHitResult hit, BlockPos dest) {
        public Vec3 center() {
            return Vec3.atCenterOf(dest);
        }
    }

    /**
     * Destino con el mismo cálculo en ambos lados. Trazado solo de bloques con colisión (el agua y las plantas no lo
     * frenan): si golpea, la celda es la de una colocación normal (la vecina de la cara, o la golpeada si es
     * reemplazable); si no, la celda que contiene el final del rayo (decisión: el bloque puede quedar flotando).
     */
    public static Aim aim(Player player, ItemStack stack, double range) {
        Level level = player.level();
        Vec3 eyes = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0f);
        Vec3 end = eyes.add(look.scale(range));
        HitResult hit = level.clip(new ClipContext(eyes, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                player));
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
            BlockPlaceContext context = new BlockPlaceContext(level, player, InteractionHand.MAIN_HAND, stack,
                    blockHit);
            return new Aim(blockHit, context.getClickedPos());
        }
        BlockPos cell = new BlockPos(ShiftTeleportRules.cell(end.x), ShiftTeleportRules.cell(end.y),
                ShiftTeleportRules.cell(end.z));
        // Como si se hiciera clic en la cara que mira al jugador (orienta troncos, losas...).
        Direction face = Direction.getNearest(look.x, look.y, look.z).getOpposite();
        return new Aim(new BlockHitResult(Vec3.atCenterOf(cell), face, cell, false), cell);
    }

    /**
     * Seres vivos cuya caja cruza la línea {@code from → to}, sin el jugador, sus mascotas ni armor stands. El PvP lo
     * filtra después {@link TpDamage} (solo en el servidor).
     */
    public static List<LivingEntity> lineTargets(Player player, Vec3 from, Vec3 to) {
        AABB area = new AABB(from, to).inflate(0.5);
        return player.level().getEntities(player, area, e -> SkillTargets.isTargetable(e)
                && !(e instanceof ArmorStand)
                && !(e instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID()))
                && crosses(from, to, e))
                .stream().map(LivingEntity.class::cast).toList();
    }

    private static boolean crosses(Vec3 from, Vec3 to, Entity entity) {
        AABB box = entity.getBoundingBox();
        return ShiftTeleportRules.lineHits(from.x, from.y, from.z, to.x, to.y, to.z,
                box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ);
    }

    public static final class ShiftTeleportContext extends SkillContext {
        private final float exp;

        ShiftTeleportContext(ServerPlayer player, ShiftTeleportSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        private ItemStack held() {
            return getPlayer().getItemInHand(InteractionHand.MAIN_HAND);
        }

        @Override
        protected void onKeyDown() {
            if (!isValidBlock(held())) {
                terminate();
            }
        }

        @Override
        protected void onKeyTick() {
            if (!isValidBlock(held())) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            execute();
            terminate();
        }

        private void execute() {
            ServerPlayer player = getPlayer();
            ItemStack held = held();
            if (!isValidBlock(held)
                    || !consume(ShiftTeleportRules.overload(exp), ShiftTeleportRules.cpCost(exp))) {
                return;
            }
            Aim aim = aim(player, held, ShiftTeleportRules.range(exp));
            Vec3 from = player.getEyePosition();
            Vec3 to = aim.center();

            boolean placed = place(player, held, aim);
            if (!placed) {
                drop(player, held, to);
            }

            int hurt = 0;
            float damage = ShiftTeleportRules.damage(exp);
            for (LivingEntity target : lineTargets(player, from, to)) {
                if (TpDamage.attack(player, getSkill(), ModDamageTypes.SHIFT_TELEPORT, target, damage, true, false)
                        .hurt()) {
                    hurt++;
                }
            }

            addSkillExp(ShiftTeleportRules.expGain(placed, hurt));
            setCooldown(ShiftTeleportRules.cooldown(exp));
            // Fuente null: lo oye también el lanzador (el original lo excluía).
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.TP_SHIFT.get(), SoundSource.PLAYERS, ShiftTeleportRules.SOUND_VOLUME, 1.0f);

            CompoundTag effect = new CompoundTag();
            MagMovementSkill.writeVec(effect, FROM_KEY, from);
            MagMovementSkill.writeVec(effect, TO_KEY, to);
            sendEffect(CHANNEL_EXECUTE, effect);
        }

        /** Colocación estándar del ítem (eventos de protección incluidos) si la habilidad y la celda lo permiten. */
        private boolean place(ServerPlayer player, ItemStack held, Aim aim) {
            ServerLevel level = player.serverLevel();
            if (!BlockPermissions.mayModifyWorld(player, getSkill()) || !level.isInWorldBounds(aim.dest())
                    || !BlockPermissions.mayBuildAt(player, aim.dest())) {
                return false;
            }
            BlockPlaceContext context = new BlockPlaceContext(level, player, InteractionHand.MAIN_HAND, held,
                    aim.hit());
            return held.useOn(context).consumesAction();
        }

        /** La unidad cae como ítem en el destino (nunca se pierde). En creativo no se gasta ni se suelta. */
        private static void drop(ServerPlayer player, ItemStack held, Vec3 at) {
            if (player.getAbilities().instabuild) {
                return;
            }
            ItemStack one = held.copyWithCount(1);
            held.shrink(1);
            ItemEntity entity = new ItemEntity(player.serverLevel(), at.x, at.y, at.z, one);
            entity.setDeltaMovement(Vec3.ZERO);
            entity.setDefaultPickUpDelay();
            player.serverLevel().addFreshEntity(entity);
        }
    }
}
