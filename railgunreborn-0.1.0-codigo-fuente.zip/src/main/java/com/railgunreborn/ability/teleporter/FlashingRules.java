package com.railgunreborn.ability.teleporter;

import java.util.function.DoublePredicate;

import javax.annotation.Nullable;

/**
 * Números y reglas de Flashing ({@code docs/spec/flashing.md}, mandan las decisiones del final), en Java puro para
 * probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al activar el modo.
 */
public final class FlashingRules {
    public static final float JUMP_EXP = 0.002f;
    /** Ticks de casi-flotación tras cada salto (en el cliente, como el original). */
    public static final int HOVER_TICKS = 40;
    /** Se suma a la velocidad vertical cada tick de flotación (la gravedad vanilla resta 0.08). */
    public static final double HOVER_BOOST = 0.072;
    public static final float SOUND_VOLUME = 0.5f;
    /** Un salto más corto que esto (pared pegada) no ocurre ni se cobra. */
    public static final double MIN_JUMP = 0.5;
    /** Paso del barrido: menor que el ancho de la caja (0.6), así ningún bloque se queda entre dos pasos. */
    public static final double SWEEP_STEP = 0.25;
    /** Bisecciones para afinar el punto de choque dentro del último paso (0.25 / 2^8 ≈ 0.001). */
    public static final int SWEEP_REFINE = 8;

    /** Dirección de un salto, con el id que manda el cliente. */
    public enum Dir {
        LEFT,
        RIGHT,
        FORWARD,
        BACK;

        public int id() {
            return ordinal();
        }

        @Nullable
        public static Dir byId(int id) {
            Dir[] values = values();
            return id >= 0 && id < values.length ? values[id] : null;
        }
    }

    private FlashingRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float startOverload(float exp) {
        return lerp(250f, 180f, exp);
    }

    public static float startCp(float exp) {
        return lerp(80f, 60f, exp);
    }

    public static float jumpCp(float exp) {
        return lerp(13f, 6f, exp);
    }

    public static int maxTicks(float exp) {
        return (int) lerp(60f, 150f, exp);
    }

    public static double distance(float exp) {
        return lerp(12f, 18f, exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(900f, 400f, exp);
    }

    /**
     * Vector unitario del salto con la mirada en grados de Minecraft (yaw 0 = +Z, pitch positivo = hacia abajo).
     * Delante/detrás siguen la inclinación; izquierda/derecha son horizontales.
     */
    public static double[] direction(Dir dir, float yawDeg, float pitchDeg) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double sinYaw = Math.sin(yaw);
        double cosYaw = Math.cos(yaw);
        return switch (dir) {
            case FORWARD -> new double[] {-sinYaw * Math.cos(pitch), -Math.sin(pitch), cosYaw * Math.cos(pitch)};
            case BACK -> new double[] {sinYaw * Math.cos(pitch), Math.sin(pitch), -cosYaw * Math.cos(pitch)};
            case LEFT -> new double[] {cosYaw, 0, sinYaw};
            case RIGHT -> new double[] {-cosYaw, 0, -sinYaw};
        };
    }

    /**
     * Barrido de la caja del jugador: la mayor distancia en [0, {@code distance}] hasta la que la caja está libre sin
     * haber chocado antes. {@code freeAt.test(d)} dice si la caja desplazada {@code d} está libre (en 0 se supone
     * libre). Avanza de {@link #SWEEP_STEP} en {@link #SWEEP_STEP} y afina el choque por bisección.
     */
    public static double sweep(double distance, DoublePredicate freeAt) {
        if (distance <= 0) {
            return 0;
        }
        double free = 0;
        while (free < distance) {
            double next = Math.min(distance, free + SWEEP_STEP);
            if (!freeAt.test(next)) {
                double blocked = next;
                for (int i = 0; i < SWEEP_REFINE; i++) {
                    double mid = (free + blocked) / 2;
                    if (freeAt.test(mid)) {
                        free = mid;
                    } else {
                        blocked = mid;
                    }
                }
                return free;
            }
            free = next;
        }
        return distance;
    }
}
