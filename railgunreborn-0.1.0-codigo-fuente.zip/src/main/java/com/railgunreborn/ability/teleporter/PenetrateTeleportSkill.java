package com.railgunreborn.ability.teleporter;

import java.util.Optional;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Penetrate Teleport: mantener (la rueda ajusta la distancia) y soltar para teletransportarse en línea recta a través
 * de los muros. El cliente manda la distancia pedida cada vez que cambia; el servidor la recorta, recalcula el destino
 * y lo valida con {@link SafeTeleport}. Si no vale, no hay coste, cooldown ni exp. Ficha:
 * {@code docs/spec/penetrate-teleport.md}.
 */
public class PenetrateTeleportSkill extends Skill {
    /** C→S: {@link #DISTANCE_KEY} = distancia pedida. */
    public static final String CHANNEL_DISTANCE = "distance";
    public static final String DISTANCE_KEY = "d";
    /** Efecto: {@link #FROM_KEY} y {@link #TO_KEY} = pies de origen y destino. */
    public static final String CHANNEL_TELEPORT = "teleport";
    public static final String FROM_KEY = "from";
    public static final String TO_KEY = "to";

    public PenetrateTeleportSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new PenetrateContext(player, this);
    }

    /** Marcha del destino desde los pies de {@code entity} según su mirada (servidor y cliente). */
    public static PenetrateRules.Dest findDestination(Level level, Entity entity, double distance) {
        Vec3 feet = entity.position();
        Vec3 dir = entity.getViewVector(1.0f);
        return PenetrateRules.findDestination(feet.x, feet.y, feet.z, dir.x, dir.y, dir.z, distance,
                (x, y, z) -> isFree(level, x, y, z));
    }

    /** Pies y cabeza sin forma de colisión (aire, plantas, líquidos...); un chunk sin cargar cuenta como ocupado. */
    public static boolean isFree(Level level, int x, int y, int z) {
        for (int dy = 0; dy <= 1; dy++) {
            BlockPos pos = new BlockPos(x, y + dy, z);
            if (!level.hasChunkAt(pos)) {
                return false;
            }
            if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /** CP por bloque con el multiplicador de la habilidad (lo que de verdad se descuenta). */
    public float realCpPerBlock(float exp) {
        return PenetrateRules.cpPerBlock(exp) * getCpConsumeSpeed();
    }

    /** Distancia que se puede recorrer: la pedida, limitada por el CP (salvo en creativo). */
    public double reachable(Player player, double requested, float exp) {
        if (player.isCreative()) {
            return requested;
        }
        return PenetrateRules.cpLimited(requested, CPData.get(player).getCP(), realCpPerBlock(exp));
    }

    private static final class PenetrateContext extends SkillContext {
        private final float exp;
        private double requested;

        PenetrateContext(ServerPlayer player, PenetrateTeleportSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
            this.requested = PenetrateRules.maxDistance(exp);
        }

        @Override
        protected void onKeyDown() {
            if (!getPlayer().isCreative() && CPData.get(getPlayer()).getCP() <= 0f) {
                terminate();
            }
        }

        @Override
        protected void onClientMessage(String channel, CompoundTag data) {
            if (CHANNEL_DISTANCE.equals(channel)) {
                requested = PenetrateRules.clampRequested(data.getDouble(DISTANCE_KEY), exp);
            }
        }

        @Override
        protected void onKeyUp() {
            execute();
            terminate();
        }

        private void execute() {
            ServerPlayer player = getPlayer();
            ServerLevel level = player.serverLevel();
            PenetrateTeleportSkill skill = (PenetrateTeleportSkill) getSkill();
            double distance = skill.reachable(player, requested, exp);
            if (distance < PenetrateRules.MIN_DISTANCE) {
                return;
            }
            PenetrateRules.Dest dest = findDestination(level, player, distance);
            if (!dest.available()) {
                return;
            }
            Vec3 from = player.position();
            Vec3 point = new Vec3(dest.x(), dest.y(), dest.z());
            // Al otro lado no se retrocede hasta dentro del muro.
            double minDistance = dest.stage() == PenetrateRules.Stage.AFTER
                    ? dest.exitDistance()
                    : Math.min(PenetrateRules.MIN_DISTANCE, dest.distance());
            Optional<Vec3> safe = SafeTeleport.findSafe(level, player, from, point, minDistance);
            if (safe.isEmpty()) {
                return;
            }
            Vec3 to = safe.get();
            double real = from.distanceTo(to);
            float overload = PenetrateRules.overload(exp);
            float cp = (float) (real * PenetrateRules.cpPerBlock(exp));
            if (!canConsume(overload, cp)) {
                // Posarse en el suelo puede alargar el recorrido: se cobra como mucho el CP que queda.
                cp = Math.min(cp, CPData.get(player).getCP() / skill.getCpConsumeSpeed() * 0.9999f);
            }
            if (!consume(overload, cp)) {
                return;
            }
            addSkillExp((float) (PenetrateRules.EXP_PER_BLOCK * real));
            setCooldown(PenetrateRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            MagMovementSkill.writeVec(data, FROM_KEY, from);
            MagMovementSkill.writeVec(data, TO_KEY, to);
            sendEffect(CHANNEL_TELEPORT, data);
            SafeTeleport.teleport(player, to);
        }
    }
}
