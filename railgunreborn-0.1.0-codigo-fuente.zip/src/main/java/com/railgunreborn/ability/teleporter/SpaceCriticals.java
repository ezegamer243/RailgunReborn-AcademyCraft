package com.railgunreborn.ability.teleporter;

import java.util.Locale;
import java.util.function.DoubleSupplier;

import net.minecraft.util.RandomSource;

/**
 * Reglas puras de los críticos de espacio ({@code docs/spec/space-criticals.md}, mandan sus decisiones). Las exp de
 * las pasivas van en [0, 1]; {@link #NOT_LEARNED} = pasiva no aprendida (su término vale 0, ni siquiera la base).
 *
 * <p>Niveles ("tier") 0, 1, 2 = ×1.3, ×1.6, ×2.6; {@link #NONE} = sin crítico.
 */
public final class SpaceCriticals {
    public static final float NOT_LEARNED = -1f;
    public static final int NONE = -1;
    public static final int TIERS = 3;

    private static final float[] RATES = {1.3f, 1.6f, 2.6f};

    /** Exp de Space Fluctuation por crítico. Decisión del usuario: 0.001 (el original daba 0.0001 y nunca subía). */
    public static final float SPACE_FLUCT_EXP_GAIN = 0.001f;

    private SpaceCriticals() {
    }

    /** {@code lerp(a, b, exp)}, o 0 si la pasiva no está aprendida. */
    static float tryLerp(float a, float b, float exp) {
        return exp < 0f ? 0f : a + (b - a) * exp;
    }

    /** Probabilidad nominal del nivel {@code tier} (antes del corte por orden). */
    public static float probability(int tier, float dimFoldingExp, float spaceFluctExp) {
        return switch (tier) {
            case 0 -> tryLerp(0.10f, 0.20f, dimFoldingExp) + tryLerp(0.18f, 0.25f, spaceFluctExp);
            case 1 -> tryLerp(0.10f, 0.15f, spaceFluctExp);
            case 2 -> tryLerp(0.01f, 0.03f, spaceFluctExp);
            default -> throw new IllegalArgumentException("Critical tier out of range: " + tier);
        };
    }

    /**
     * Las tres tiradas en orden con corte: gana la primera cuyo número uniforme [0, 1) sea menor que su probabilidad.
     * Sin ninguna pasiva aprendida no se consume ningún número.
     *
     * @return el nivel (0..2) o {@link #NONE}
     */
    public static int roll(DoubleSupplier uniform, float dimFoldingExp, float spaceFluctExp) {
        if (dimFoldingExp < 0f && spaceFluctExp < 0f) {
            return NONE;
        }
        for (int tier = 0; tier < TIERS; tier++) {
            if (uniform.getAsDouble() < probability(tier, dimFoldingExp, spaceFluctExp)) {
                return tier;
            }
        }
        return NONE;
    }

    public static int roll(RandomSource random, float dimFoldingExp, float spaceFluctExp) {
        return roll(random::nextDouble, dimFoldingExp, spaceFluctExp);
    }

    /** Multiplicador del nivel; 1 sin crítico. */
    public static float rate(int tier) {
        return tier == NONE ? 1f : RATES[tier];
    }

    /** Cifra limpia para el aviso ("1.3"). */
    public static String formatRate(int tier) {
        return String.format(Locale.ROOT, "%.1f", rate(tier));
    }

    /** Exp de Dim Folding por un crítico de nivel {@code tier}: {@code (tier + 1) * 0.005}. */
    public static float dimFoldingExpGain(int tier) {
        return (tier + 1) * 0.005f;
    }

    /** Probabilidad real de cada nivel tras el corte por orden: P1 = p1, P2 = (1-p1)p2, P3 = (1-p1)(1-p2)p3. */
    public static float effectiveProbability(int tier, float dimFoldingExp, float spaceFluctExp) {
        float miss = 1f;
        for (int t = 0; t < tier; t++) {
            miss *= 1f - probability(t, dimFoldingExp, spaceFluctExp);
        }
        return miss * probability(tier, dimFoldingExp, spaceFluctExp);
    }

    /** Probabilidad de que un golpe salga crítico. */
    public static float totalProbability(float dimFoldingExp, float spaceFluctExp) {
        float sum = 0f;
        for (int tier = 0; tier < TIERS; tier++) {
            sum += effectiveProbability(tier, dimFoldingExp, spaceFluctExp);
        }
        return sum;
    }

    /** Multiplicador de daño esperado por golpe. */
    public static float expectedMultiplier(float dimFoldingExp, float spaceFluctExp) {
        float expected = 1f - totalProbability(dimFoldingExp, spaceFluctExp);
        for (int tier = 0; tier < TIERS; tier++) {
            expected += effectiveProbability(tier, dimFoldingExp, spaceFluctExp) * RATES[tier];
        }
        return expected;
    }
}
