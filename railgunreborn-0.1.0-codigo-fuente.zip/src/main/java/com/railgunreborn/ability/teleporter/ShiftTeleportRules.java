package com.railgunreborn.ability.teleporter;

/**
 * Reglas puras de Shift Teleport ({@code docs/spec/shift-teleport.md}, mandan las decisiones del final): fórmulas, exp
 * y la prueba línea-caja de los objetivos. Sin Minecraft, para probarlas con JUnit. {@code exp} es la exp de la
 * habilidad en [0, 1] leída al pulsar.
 */
public final class ShiftTeleportRules {
    /** Exp por colocar el bloque con éxito (decisión: no si cae como ítem). */
    public static final float BASE_EXP = 0.002f;
    /** Exp por cada ser vivo realmente dañado. */
    public static final float PER_TARGET_EXP = 0.002f;
    /** Los marcadores de objetivos se recalculan cada tantos ticks. */
    public static final int MARKER_REFRESH_TICKS = 3;
    /** Volumen de {@code teleporter.tp_shift} (0.5 en el original; moderado, como el resto de Teleporter). */
    public static final float SOUND_VOLUME = 0.4f;
    /** Paso aleatorio entre partículas de la línea: [MIN, MIN + SPREAD). */
    public static final double PARTICLE_STEP_MIN = 0.6;
    public static final double PARTICLE_STEP_SPREAD = 0.4;

    private ShiftTeleportRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cpCost(float exp) {
        return lerp(260f, 320f, exp);
    }

    public static float overload(float exp) {
        return lerp(40f, 30f, exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(100f, 60f, exp);
    }

    /** Daño base por objetivo, antes del crítico y de {@code damage_scale}. */
    public static float damage(float exp) {
        return lerp(15f, 35f, exp);
    }

    public static float range(float exp) {
        return lerp(25f, 35f, exp);
    }

    public static float expGain(boolean placed, int hurtCount) {
        return (placed ? BASE_EXP : 0f) + PER_TARGET_EXP * Math.max(0, hurtCount);
    }

    /** Celda (redondeo hacia abajo, correcto con negativos) que contiene la coordenada. */
    public static int cell(double coord) {
        return (int) Math.floor(coord);
    }

    /**
     * Si el segmento {@code a → b} cruza la caja {@code [min, max]} (método de las franjas; sin margen). Un segmento
     * de longitud 0 cuenta si su punto está dentro.
     */
    public static boolean lineHits(double ax, double ay, double az, double bx, double by, double bz,
            double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        double[] t = {0.0, 1.0};
        return slab(ax, bx - ax, minX, maxX, t)
                && slab(ay, by - ay, minY, maxY, t)
                && slab(az, bz - az, minZ, maxZ, t);
    }

    /** Recorta {@code t = [entrada, salida]} con la franja de un eje; false si queda vacío. */
    private static boolean slab(double start, double delta, double min, double max, double[] t) {
        if (Math.abs(delta) < 1e-12) {
            return start >= min && start <= max;
        }
        double t1 = (min - start) / delta;
        double t2 = (max - start) / delta;
        if (t1 > t2) {
            double tmp = t1;
            t1 = t2;
            t2 = tmp;
        }
        t[0] = Math.max(t[0], t1);
        t[1] = Math.min(t[1], t2);
        return t[0] <= t[1];
    }
}
