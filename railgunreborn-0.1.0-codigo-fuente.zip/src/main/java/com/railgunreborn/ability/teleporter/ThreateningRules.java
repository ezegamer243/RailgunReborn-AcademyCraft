package com.railgunreborn.ability.teleporter;

/**
 * Números de Threatening Teleport ({@code docs/spec/threatening-teleport.md}, §11), en Java puro para probarlos con
 * JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class ThreateningRules {
    /** Margen añadido a la caja de cada ser vivo al trazar. */
    public static final double HITBOX_INFLATE = 0.3;
    public static final float NEEDLE_MULTIPLIER = 1.5f;
    /** Exp por impacto efectivo (el original daba 0.0006 por fallo: descartado). */
    public static final float EXP_HIT = 0.003f;
    /** Volumen de {@code teleporter.tp} (0.5 en el original; decisión: 0.4). */
    public static final float SOUND_VOLUME = 0.4f;
    /** El ítem cae este tanto hacia el tirador, para no quedar incrustado en el objetivo. */
    public static final double DROP_OFFSET = 0.2;

    private ThreateningRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cp(float exp) {
        return lerp(35f, 100f, exp);
    }

    public static float overload(float exp) {
        return lerp(18f, 10f, exp);
    }

    public static float range(float exp) {
        return lerp(8f, 15f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(30f, 15f, exp);
    }

    /** Daño base antes del crítico y de {@code damage_scale}. */
    public static float baseDamage(float exp, boolean needle) {
        float damage = lerp(3f, 6f, exp);
        return needle ? damage * NEEDLE_MULTIPLIER : damage;
    }
}
