package com.railgunreborn.ability.teleporter;

/**
 * Reglas puras de Penetrate Teleport ({@code docs/spec/penetrate-teleport.md}): fórmulas, recorte de la distancia y la
 * marcha por pasos con la máquina de 3 etapas. Sin Minecraft, para probarlas con JUnit.
 */
public final class PenetrateRules {
    /** Paso de la marcha por el rayo, en bloques. */
    public static final double STEP = 0.8;
    /** Distancia mínima que se puede pedir. */
    public static final double MIN_DISTANCE = 0.5;
    /** Pasos extra por el espacio libre tras salir del muro (≈ 4 bloques). */
    public static final int EXTRA_STEPS = 5;
    public static final float EXP_PER_BLOCK = 0.00014f;
    /** Bloques por muesca de la rueda. */
    public static final double WHEEL_STEP = 1.0;
    public static final float SOUND_VOLUME = 0.4f;
    private static final double EPS = 1e-9;

    public enum Stage {
        /** Antes del muro (o no había muro). */
        BEFORE,
        /** Dentro del muro: el destino no vale. */
        INSIDE,
        /** Al otro lado del muro. */
        AFTER
    }

    /** Si los 2 bloques (pies y cabeza) con los pies en el bloque {@code (x, y, z)} están libres. */
    @FunctionalInterface
    public interface FreeCheck {
        boolean isFree(int x, int y, int z);
    }

    /**
     * Punto final de la marcha (pies). {@code distance}: a lo largo del rayo; {@code exitDistance}: donde se salió del
     * muro (solo en {@link Stage#AFTER}; 0 si no).
     */
    public record Dest(double x, double y, double z, Stage stage, double distance, double exitDistance) {
        public boolean available() {
            return stage != Stage.INSIDE && distance >= MIN_DISTANCE - 1e-6;
        }
    }

    private PenetrateRules() {
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float maxDistance(float exp) {
        return lerp(10f, 35f, exp);
    }

    public static float cpPerBlock(float exp) {
        return lerp(14f, 9f, exp);
    }

    public static float overload(float exp) {
        return lerp(80f, 50f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(50f, 30f, exp);
    }

    /** Distancia pedida recortada a {@code [MIN_DISTANCE, maxDistance(exp)]} (lo que mande el cliente). */
    public static double clampRequested(double requested, float exp) {
        double max = maxDistance(exp);
        if (!Double.isFinite(requested)) {
            return max;
        }
        return Math.max(MIN_DISTANCE, Math.min(max, requested));
    }

    /** Ajuste con la rueda: {@code notches} muescas (±), recortado. */
    public static double wheel(double current, double notches, float exp) {
        return clampRequested(current + notches * WHEEL_STEP, exp);
    }

    /** El CP disponible limita el alcance: {@code min(distancia, cp / cpPorBloque)}; 0 sin CP. */
    public static double cpLimited(double distance, float cp, float cpPerBlock) {
        if (cp <= 0f || cpPerBlock <= 0f) {
            return cpPerBlock <= 0f ? distance : 0;
        }
        return Math.min(distance, cp / (double) cpPerBlock);
    }

    /**
     * Marcha desde los pies {@code (fx, fy, fz)} por la dirección unitaria {@code (dx, dy, dz)} de {@link #STEP} en
     * {@code STEP}, sin pasar de {@code distance} (el último punto es exactamente {@code distance}). Etapas: antes del
     * muro sigue mientras esté libre; dentro, hasta el primer punto libre (la salida); al otro lado avanza hasta
     * {@link #EXTRA_STEPS} pasos más y, si topa con otro muro, se queda en el último punto libre (no dentro).
     * Coordenadas de bloque con {@code floor}.
     */
    public static Dest findDestination(double fx, double fy, double fz, double dx, double dy, double dz,
            double distance, FreeCheck free) {
        Stage stage = Stage.BEFORE;
        double px = fx;
        double py = fy;
        double pz = fz;
        double reached = 0;
        double exit = 0;
        int extra = 0;
        if (!(distance > 0)) {
            return new Dest(px, py, pz, stage, 0, 0);
        }
        for (int n = 1;; n++) {
            double d = Math.min(n * STEP, distance);
            double x = fx + dx * d;
            double y = fy + dy * d;
            double z = fz + dz * d;
            boolean isFree = free.isFree((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
            if (stage == Stage.AFTER && !isFree) {
                break;
            }
            switch (stage) {
                case BEFORE -> {
                    if (!isFree) {
                        stage = Stage.INSIDE;
                    }
                }
                case INSIDE -> {
                    if (isFree) {
                        stage = Stage.AFTER;
                        exit = d;
                    }
                }
                case AFTER -> extra++;
            }
            px = x;
            py = y;
            pz = z;
            reached = d;
            if (d >= distance - EPS || (stage == Stage.AFTER && extra >= EXTRA_STEPS)) {
                break;
            }
        }
        return new Dest(px, py, pz, stage, reached, exit);
    }
}
