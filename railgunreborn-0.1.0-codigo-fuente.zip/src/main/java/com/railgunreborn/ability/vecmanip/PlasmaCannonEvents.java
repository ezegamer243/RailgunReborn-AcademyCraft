package com.railgunreborn.ability.vecmanip;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Explosión de Plasma Cannon (bus del juego). Es la vanilla de radio 12-15, pero:
 * <ul>
 * <li>no daña a nadie (el daño es el directo de la habilidad), solo empuja; ni ítems ni orbes ni el lanzador ni los
 * jugadores protegidos por PvP se ven afectados;</li>
 * <li>solo rompe bloques con {@link BlockPermissions#mayModifyWorld}, y cada casilla pasa
 * {@link BlockPermissions#mayBreakAt} (se filtra en {@link ExplosionEvent.Detonate}, que también escuchan los mods de
 * protección);</li>
 * <li>rompe como mucho {@link PlasmaCannonRules#MAX_BLOCKS_PER_TICK} bloques en el tick: el resto (los más lejanos)
 * se rompen en los siguientes ticks;</li>
 * <li>sonido de explosión moderado (el vanilla va siempre a volumen 4).</li>
 * </ul>
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class PlasmaCannonEvents {
    /** Solo empuja: el daño de la explosión vanilla queda fuera (decisión: solo el daño directo). */
    private static final ExplosionDamageCalculator NO_DAMAGE = new ExplosionDamageCalculator() {
        @Override
        public boolean shouldDamageEntity(Explosion explosion, Entity entity) {
            return false;
        }
    };

    /** Explosión de esta habilidad en curso en este hilo (el evento llega dentro de {@code explode}). */
    private static final ThreadLocal<Detonation> CURRENT = new ThreadLocal<>();
    private static final List<Pending> PENDING = new ArrayList<>();

    private static final class Detonation {
        final ServerPlayer player;
        int broken;

        Detonation(ServerPlayer player) {
            this.player = player;
        }
    }

    /** Bloques aplazados de una explosión (ya filtrados por permisos). */
    private record Pending(ServerLevel level, Explosion explosion, Deque<BlockPos> blocks) {
    }

    private PlasmaCannonEvents() {
    }

    /**
     * Explota en {@code at} con {@code radius}. @return bloques que rompe (los del tick más los aplazados).
     */
    public static int detonate(ServerPlayer player, Skill skill, ServerLevel level, Vec3 at, float radius) {
        boolean modify = BlockPermissions.mayModifyWorld(player, skill);
        Detonation detonation = new Detonation(player);
        CURRENT.set(detonation);
        try {
            level.explode(player, ModDamageTypes.source(player, ModDamageTypes.PLASMA_CANNON), NO_DAMAGE, at.x, at.y,
                    at.z, radius, false, modify ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE,
                    ParticleTypes.EXPLOSION, ParticleTypes.EXPLOSION_EMITTER, silent());
        } finally {
            CURRENT.remove();
        }
        level.playSound(null, at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS,
                PlasmaCannonRules.EXPLOSION_VOLUME, 0.7f);
        return detonation.broken;
    }

    private static Holder<SoundEvent> silent() {
        return BuiltInRegistries.SOUND_EVENT.wrapAsHolder(SoundEvents.EMPTY);
    }

    @SubscribeEvent
    public static void onDetonate(ExplosionEvent.Detonate event) {
        Detonation detonation = CURRENT.get();
        if (detonation == null || event.getExplosion().getDirectSourceEntity() != detonation.player
                || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        ServerPlayer player = detonation.player;
        event.getAffectedEntities().removeIf(e -> e == player || e instanceof ItemEntity
                || e instanceof ExperienceOrb
                || e instanceof Player other && !SkillTargets.mayHarm(player, other, VecDamage.ATTACK_PLAYER));

        List<BlockPos> blocks = event.getAffectedBlocks();
        blocks.removeIf(pos -> {
            BlockState state = level.getBlockState(pos);
            return state.isAir() || !BlockPermissions.mayBreakAt(player, pos, state);
        });
        detonation.broken = blocks.size();
        if (blocks.size() > PlasmaCannonRules.MAX_BLOCKS_PER_TICK) {
            Vec3 center = event.getExplosion().center();
            blocks.sort(Comparator.comparingDouble(pos -> pos.distToCenterSqr(center)));
            List<BlockPos> later = blocks.subList(PlasmaCannonRules.MAX_BLOCKS_PER_TICK, blocks.size());
            PENDING.add(new Pending(level, event.getExplosion(), new ArrayDeque<>(later)));
            later.clear();
        }
    }

    /** Rompe los bloques aplazados, con el mismo tope por tick entre todas las explosiones. */
    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (PENDING.isEmpty()) {
            return;
        }
        int budget = PlasmaCannonRules.MAX_BLOCKS_PER_TICK;
        for (Iterator<Pending> it = PENDING.iterator(); it.hasNext() && budget > 0; ) {
            Pending pending = it.next();
            ServerLevel level = pending.level();
            while (budget > 0 && !pending.blocks().isEmpty()) {
                BlockPos pos = pending.blocks().poll();
                budget--;
                if (!level.isLoaded(pos)) {
                    continue;
                }
                BlockState state = level.getBlockState(pos);
                if (!state.isAir()) {
                    state.onExplosionHit(level, pos, pending.explosion(),
                            (stack, at) -> Block.popResource(level, at, stack));
                }
            }
            if (pending.blocks().isEmpty()) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        PENDING.clear();
    }
}
