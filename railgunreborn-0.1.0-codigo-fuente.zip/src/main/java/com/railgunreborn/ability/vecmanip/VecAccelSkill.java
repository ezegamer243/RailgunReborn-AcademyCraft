package com.railgunreborn.ability.vecmanip;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Vector Acceleration: mantener hasta 20 ticks y soltar para lanzarse en la dirección de la mirada (10 grados más
 * arriba). El impulso lo aplica el servidor (decisión de la ficha) y la caída queda protegida hasta aterrizar. Ficha:
 * {@code docs/spec/vec-accel.md}.
 */
public class VecAccelSkill extends Skill {
    public VecAccelSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new VecAccelContext(player, this);
    }

    /** Si hay un bloque (o líquido) no-aire a ≤ 2 bloques bajo los pies. Sirve en ambos lados. */
    public static boolean blockBelow(Player player) {
        Vec3 feet = player.position();
        Vec3 end = feet.add(0, -VecAccelRules.GROUND_REACH, 0);
        return player.level().clip(new ClipContext(feet, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY,
                player)).getType() != HitResult.Type.MISS;
    }

    private static final class VecAccelContext extends SkillContext {
        private final float exp;

        VecAccelContext(ServerPlayer player, VecAccelSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyUp() {
            launch();
            terminate();
        }

        private void launch() {
            ServerPlayer player = getPlayer();
            if (!VecAccelRules.canUse(exp, blockBelow(player))) {
                return;
            }
            if (!consume(VecAccelRules.overload(exp), VecAccelRules.cp(exp))) {
                return;
            }
            // El servidor cuenta su propia carga (el cliente no es de fiar).
            double speed = VecAccelRules.speed(getTicksAlive());
            double[] dir = VecAccelRules.direction(player.getYRot(), player.getXRot());
            player.stopRiding();
            player.setDeltaMovement(dir[0] * speed, dir[1] * speed, dir[2] * speed);
            player.hurtMarked = true;
            player.resetFallDistance();
            SafeTeleport.guardFall(player, VecAccelRules.FALL_GUARD_TICKS);
            MagMovementSkill.resetFlying(player);
            addSkillExp(VecAccelRules.EXP);
            setCooldown(VecAccelRules.cooldownTicks(exp));
            // Sonido desde el servidor: lo oyen todos los cercanos, incluido el propio jugador.
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.VM_VEC_ACCEL.get(), SoundSource.PLAYERS, VecAccelRules.SOUND_VOLUME, 1.0f);
        }
    }
}
