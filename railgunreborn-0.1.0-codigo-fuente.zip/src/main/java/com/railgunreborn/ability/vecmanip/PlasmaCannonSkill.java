package com.railgunreborn.ability.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Plasma Cannon: nivel 5 de Vector Manipulation. Se mantiene para formar una bola de plasma sobre la cabeza (hasta 15
 * bloques); cargada, al soltar sale hacia el punto apuntado (≤ 100 bloques) a 1 bloque/tick y explota donde choca.
 * Ficha: {@code docs/spec/plasma-cannon.md} (mandan las decisiones del final). Números en {@link PlasmaCannonRules}.
 *
 * <p>Decisiones: el único daño es el directo (esfera de 10, plano, respeta PvP; ni al lanzador ni a ítems ni orbes);
 * la explosión vanilla (radio 12-15) solo rompe bloques y empuja, con {@code mobGriefing}/{@code destroy_blocks} y
 * los permisos por casilla ({@link PlasmaCannonEvents}); se rechaza al pulsar si el overload fijo no cabe; exp solo
 * si dañó a algo vivo o rompió bloques. No hay entidad: la bola vive en el contexto.
 */
public class PlasmaCannonSkill extends Skill {
    /** Empieza la carga: {@link #POS_KEY} = bola, {@link #CHARGE_KEY} = ticks de carga (local y cercanos). */
    public static final String CHANNEL_START = "start";
    /** Carga completa (solo al jugador local). */
    public static final String CHANNEL_READY = "ready";
    /** Disparo: {@link #POS_KEY} = bola, {@link #DEST_KEY} = destino. */
    public static final String CHANNEL_FIRE = "fire";
    /** Posición de la bola en vuelo cada {@link PlasmaCannonRules#SYNC_INTERVAL} ticks. */
    public static final String CHANNEL_SYNC = "sync";
    /** Explotó en {@link #POS_KEY} (el estallido lo pinta la explosión vanilla). */
    public static final String CHANNEL_EXPLODE = "explode";
    /** Terminó (con o sin explosión). */
    public static final String CHANNEL_STOP = "stop";
    public static final String POS_KEY = "pos";
    public static final String DEST_KEY = "dest";
    public static final String CHARGE_KEY = "charge";

    /** Radios reducidos solo para GameTests (las plantillas son de 9×9: un radio de 12 rompería las vecinas). */
    public record TestRadii(float explosion, double damage) {
    }

    /** Solo para GameTests ({@code null} = los de la ficha). */
    @Nullable
    public static volatile TestRadii testRadii;

    public PlasmaCannonSkill(Properties props) {
        super(props);
    }

    /** Decisión: si el overload fijo no cabe, se rechaza al pulsar (sonido de denegado, sin gastar nada). */
    @Override
    @Nullable
    public SkillContext createContext(ServerPlayer player) {
        float exp = AbilityData.get(player).getSkillExp(getId());
        CPData cp = CPData.get(player);
        if (!player.isCreative() && !PlasmaCannonRules.overloadFits(cp.getOverload(),
                PlasmaCannonRules.overload(exp) * getOverloadConsumeSpeed(), cp.getMaxOverload())) {
            return null;
        }
        return new PlasmaCannonContext(player, this);
    }

    /** Contexto vivo del jugador, o null. */
    @Nullable
    public static PlasmaCannonContext active(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof PlasmaCannonContext plasma && !plasma.isTerminated()) {
                return plasma;
            }
        }
        return null;
    }

    public enum Phase {
        CHARGING,
        CHARGED,
        FLYING
    }

    public static final class PlasmaCannonContext extends SkillContext {
        private final float exp;
        private final int chargeTicks;
        private final ServerLevel level;
        private Phase phase = Phase.CHARGING;
        private int charged;
        private float overloadFloor;
        private Vec3 ball = Vec3.ZERO;
        private Vec3 dest = Vec3.ZERO;
        private int flightTicks;
        private boolean exploded;
        private boolean hurtSomething;
        private int brokenBlocks;

        PlasmaCannonContext(ServerPlayer player, PlasmaCannonSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
            this.chargeTicks = PlasmaCannonRules.chargeTicks(exp);
            this.level = player.serverLevel();
        }

        public Phase phase() {
            return phase;
        }

        public int chargeTicks() {
            return chargeTicks;
        }

        public Vec3 ball() {
            return ball;
        }

        public Vec3 destination() {
            return dest;
        }

        public boolean hasExploded() {
            return exploded;
        }

        public boolean hurtSomething() {
            return hurtSomething;
        }

        public int brokenBlocks() {
            return brokenBlocks;
        }

        @Override
        protected void onKeyDown() {
            ServerPlayer player = getPlayer();
            if (!consume(PlasmaCannonRules.overload(exp), 0f)) {
                terminate();
                return;
            }
            overloadFloor = CPData.get(player).getOverload();
            ball = formBall(player);
            CompoundTag data = new CompoundTag();
            data.put(POS_KEY, vec(ball));
            data.putInt(CHARGE_KEY, chargeTicks);
            sendToLocal(CHANNEL_START, data);
            sendEffect(CHANNEL_START, data);
        }

        /** Hasta 15 bloques sobre los pies; con techo, justo por debajo (decisión: nada de estallar en el techo). */
        private static Vec3 formBall(ServerPlayer player) {
            Vec3 feet = player.position();
            Vec3 eye = player.getEyePosition();
            Vec3 top = feet.add(0, PlasmaCannonRules.HEIGHT, 0);
            BlockHitResult hit = player.level().clip(new ClipContext(eye, top, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player));
            Double ceiling = hit.getType() == HitResult.Type.MISS ? null : hit.getLocation().y - feet.y;
            double height = Math.max(PlasmaCannonRules.ballHeight(ceiling), Math.min(eye.y - feet.y,
                    PlasmaCannonRules.HEIGHT));
            return feet.add(0, height, 0);
        }

        @Override
        protected void tick() {
            ServerPlayer player = getPlayer();
            if (player.serverLevel() != level) {
                terminate();
                return;
            }
            // El overload no se recupera mientras dure (como el original).
            CPData.get(player).raiseOverloadTo(overloadFloor);
            switch (phase) {
                case CHARGING -> {
                    if (!consume(0f, PlasmaCannonRules.cpPerTick(exp))) {
                        terminate();
                        return;
                    }
                    if (++charged >= chargeTicks) {
                        phase = Phase.CHARGED;
                        sendToLocal(CHANNEL_READY, new CompoundTag());
                    }
                }
                case CHARGED -> {
                }
                case FLYING -> fly();
            }
        }

        @Override
        protected void onKeyUp() {
            switch (phase) {
                // Soltar antes de cargar: se pierde lo gastado, sin cooldown ni exp.
                case CHARGING -> terminate();
                case CHARGED -> fire();
                case FLYING -> {
                }
            }
        }

        /** Sin poder usar habilidades: la carga se pierde, pero una bola ya disparada sigue su vuelo. */
        @Override
        protected void onKeyAbort() {
            if (phase != Phase.FLYING) {
                terminate();
            }
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0f).scale(PlasmaCannonRules.RANGE));
            ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, eye, end);
            LivingEntity target = hit.entity();
            dest = target != null
                    ? target.position().add(0, target.getEyeHeight() * PlasmaCannonRules.TARGET_EYE_FRACTION, 0)
                    : hit.end();
            phase = Phase.FLYING;
            setCooldown(PlasmaCannonRules.cooldown(exp));
            CompoundTag data = new CompoundTag();
            data.put(POS_KEY, vec(ball));
            data.put(DEST_KEY, vec(dest));
            sendEffect(CHANNEL_FIRE, data);
        }

        private void fly() {
            flightTicks++;
            double[] next = PlasmaCannonRules.step(new double[] {ball.x, ball.y, ball.z},
                    new double[] {dest.x, dest.y, dest.z});
            Vec3 to = new Vec3(next[0], next[1], next[2]);
            if (!level.isLoaded(BlockPos.containing(to))) {
                // Decisión: no se carga nada; estalla al borde de lo cargado.
                explode(ball);
                return;
            }
            Vec3 hit = collide(ball, to);
            if (hit != null) {
                explode(hit);
                return;
            }
            ball = to;
            double left = ball.distanceTo(dest);
            if (PlasmaCannonRules.arrived(left, flightTicks)) {
                explode(left < PlasmaCannonRules.ARRIVE_DIST ? dest : ball);
                return;
            }
            if (flightTicks % PlasmaCannonRules.SYNC_INTERVAL == 0) {
                CompoundTag data = new CompoundTag();
                data.put(POS_KEY, vec(ball));
                sendEffect(CHANNEL_SYNC, data);
            }
        }

        /** Primer choque del tramo con un bloque o un ser vivo (nunca el lanzador), o null. */
        @Nullable
        private Vec3 collide(Vec3 from, Vec3 to) {
            ServerPlayer player = getPlayer();
            BlockHitResult blockHit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player));
            Vec3 best = blockHit.getType() == HitResult.Type.MISS ? null : blockHit.getLocation();
            double bestDist = best == null ? Double.MAX_VALUE : from.distanceToSqr(best);
            for (Entity entity : level.getEntities(player, new AABB(from, to).inflate(1.0),
                    SkillTargets::isTargetable)) {
                AABB box = entity.getBoundingBox();
                Vec3 point = box.contains(from) ? from : box.clip(from, to).orElse(null);
                if (point != null && from.distanceToSqr(point) < bestDist) {
                    best = point;
                    bestDist = from.distanceToSqr(point);
                }
            }
            return best;
        }

        /** Una sola explosión por disparo. Público para las pruebas. */
        public void explode(Vec3 at) {
            if (exploded || isTerminated()) {
                return;
            }
            exploded = true;
            TestRadii radii = testRadii;
            double damageRadius = radii != null ? radii.damage() : PlasmaCannonRules.DAMAGE_RADIUS;
            float radius = radii != null ? radii.explosion() : PlasmaCannonRules.radius(exp);
            hurtSomething = damageAround(at, damageRadius);
            brokenBlocks = PlasmaCannonEvents.detonate(getPlayer(), getSkill(), level, at, radius);
            float gain = PlasmaCannonRules.expGain(hurtSomething, brokenBlocks > 0);
            if (gain > 0f) {
                addSkillExp(gain);
            }
            CompoundTag data = new CompoundTag();
            data.put(POS_KEY, vec(at));
            sendEffect(CHANNEL_EXPLODE, data);
            terminate();
        }

        /** Daño directo plano a los seres vivos de la esfera (el lanzador y los protegidos por PvP, no). */
        private boolean damageAround(Vec3 at, double radius) {
            ServerPlayer player = getPlayer();
            boolean hurt = false;
            for (Entity entity : level.getEntities(player, new AABB(at, at).inflate(radius),
                    e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator())) {
                if (nearestDistanceSq(entity.getBoundingBox(), at) > radius * radius) {
                    continue;
                }
                if (VecDamage.attack(player, getSkill(), ModDamageTypes.PLASMA_CANNON, entity,
                        PlasmaCannonRules.damage(exp))) {
                    hurt = true;
                }
            }
            return hurt;
        }

        private static double nearestDistanceSq(AABB box, Vec3 p) {
            double x = Mth.clamp(p.x, box.minX, box.maxX);
            double y = Mth.clamp(p.y, box.minY, box.maxY);
            double z = Mth.clamp(p.z, box.minZ, box.maxZ);
            return p.distanceToSqr(x, y, z);
        }

        /** La bola puede estar lejos del lanzador: los efectos llegan a todo el recorrido. */
        @Override
        protected double getEffectRange() {
            return PlasmaCannonRules.RANGE + 20.0;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            sendEffect(CHANNEL_STOP, new CompoundTag());
        }

        private static CompoundTag vec(Vec3 v) {
            CompoundTag tag = new CompoundTag();
            tag.putDouble("x", v.x);
            tag.putDouble("y", v.y);
            tag.putDouble("z", v.z);
            return tag;
        }
    }
}
