package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Directed Shock ({@code docs/spec/dir-shock.md}) en Java puro, para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class DirShockRules {
    /** Se acepta mantener más de {@code MIN_TICKS} y menos de {@code MAX_TICKS} (es decir 7..49). */
    public static final int MIN_TICKS = 6;
    public static final int MAX_TICKS = 50;
    /** Tolerancia del servidor sobre la cuenta del cliente (la ficha: 2 ticks). */
    public static final int TOLERANCE_TICKS = 2;
    /** Sin soltar, el contexto termina solo. */
    public static final int TIMEOUT_TICKS = 200;
    public static final double REACH = 3.0;
    public static final float EXP_HIT = 0.0035f;
    public static final double PUSH = 0.24;
    public static final double STRONG_PUSH = 0.7;
    public static final double LOFT = 0.6;
    /** Subida inmediata de la entidad al recibir el empuje fuerte. */
    public static final double LIFT = 0.1;
    public static final float STRONG_EXP = 0.25f;
    public static final float SOUND_VOLUME = 0.5f;

    private DirShockRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static float cp(float exp) {
        return lerp(50f, 100f, exp);
    }

    public static float overload(float exp) {
        return lerp(18f, 12f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(60f, 20f, exp);
    }

    /** Daño base, antes de {@code damage_scale}. */
    public static float damage(float exp) {
        return lerp(7f, 15f, exp);
    }

    public static boolean knockbackEnabled(float exp) {
        return exp >= STRONG_EXP;
    }

    /** Ventana exacta del cliente: 7 a 49 ticks. */
    public static boolean holdAccepted(int ticks) {
        return ticks > MIN_TICKS && ticks < MAX_TICKS;
    }

    /** Ventana del servidor: la del cliente ampliada por la tolerancia. */
    public static boolean serverHoldAccepted(int ticks) {
        return ticks > MIN_TICKS - TOLERANCE_TICKS && ticks < MAX_TICKS + TOLERANCE_TICKS;
    }

    /**
     * Velocidad resultante del objetivo: empujón básico (pies con pies, siempre, se suma) y, con exp suficiente, el
     * empuje fuerte que <b>sustituye</b> antes la velocidad actual (cabeza con cabeza más una subida). El original
     * usaba la componente Y de la dirección en Z; aquí sale hacia fuera de verdad.
     *
     * @param currentVelocity velocidad actual del objetivo, tras el daño
     * @return la nueva velocidad {x, y, z}
     */
    public static double[] knockbackVelocity(double[] playerHead, double[] targetHead, double[] playerFeet,
            double[] targetFeet, double[] currentVelocity, float exp) {
        double[] velocity = currentVelocity.clone();
        if (knockbackEnabled(exp)) {
            double[] strong = normalized(targetHead[0] - playerHead[0], targetHead[1] - playerHead[1] + LOFT,
                    targetHead[2] - playerHead[2]);
            for (int i = 0; i < 3; i++) {
                velocity[i] = strong[i] * STRONG_PUSH;
            }
        }
        double[] basic = normalized(targetFeet[0] - playerFeet[0], targetFeet[1] - playerFeet[1],
                targetFeet[2] - playerFeet[2]);
        for (int i = 0; i < 3; i++) {
            velocity[i] += basic[i] * PUSH;
        }
        return velocity;
    }

    private static double[] normalized(double x, double y, double z) {
        double length = Math.sqrt(x * x + y * y + z * z);
        if (length < 1.0e-6) {
            return new double[] {0, 0, 0};
        }
        return new double[] {x / length, y / length, z / length};
    }
}
