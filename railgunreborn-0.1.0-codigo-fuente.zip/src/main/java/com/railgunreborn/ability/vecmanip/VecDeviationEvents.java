package com.railgunreborn.ability.vecmanip;

import com.railgunreborn.RailgunReborn;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/**
 * Reducción de daño de Vector Deviation (bus del juego, solo servidor). {@code LivingDamageEvent.Pre} va después de
 * armadura y pociones, como el {@code LivingHurtEvent} del original. Solo cuenta el campo del propio jugador herido
 * (el original usaba el de cualquiera). Prioridad baja, como Light Shield: reduce el daño final.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class VecDeviationEvents {
    private VecDeviationEvents() {
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onLivingDamage(LivingDamageEvent.Pre event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        VecDeviationSkill.VecDeviationContext field = VecDeviationSkill.activeField(player);
        if (field != null) {
            event.setNewDamage(field.handleDamage(event.getSource(), event.getNewDamage()));
        }
    }
}
