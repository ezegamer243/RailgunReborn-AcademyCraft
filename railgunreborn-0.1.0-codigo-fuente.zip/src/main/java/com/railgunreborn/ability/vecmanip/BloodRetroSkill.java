package com.railgunreborn.ability.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Blood Retrograde: mantener (el jugador se ralentiza casi del todo) y soltar, o se suelta sola a los 30 ticks. El
 * servidor traza al soltar (alcance ~2.3, con línea de visión) y revienta la sangre del primer ser vivo: daño muy alto.
 * Sin objetivo, o sin daño aplicado (PvP), no se cobra ni hay cooldown ni exp. Ficha: {@code docs/spec/blood-retro.md}.
 */
public class BloodRetroSkill extends Skill {
    /** Canal {@code burst}: caja del objetivo (x, y, z de los pies, ancho y alto) para la sangre y el sonido. */
    public static final String CHANNEL_BURST = "burst";

    /** Modificador temporal de velocidad mientras se mantiene (siempre se quita al terminar). */
    public static final ResourceLocation SLOW_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "blood_retro_charge");

    public BloodRetroSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new BloodRetroContext(player, this);
    }

    /**
     * Primer objetivo en la mirada: bloques con colisión cortan el trazado; cuentan los seres vivos y las partes del
     * dragón (caja +0.3). {@code null} si no hay ninguno al alcance.
     */
    @Nullable
    public static Entity findTarget(Player player) {
        Vec3 from = player.getEyePosition();
        Vec3 to = from.add(player.getViewVector(1.0f).scale(BloodRetroRules.REACH));
        var level = player.level();
        var blockHit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 limit = blockHit.getType() == HitResult.Type.MISS ? to : blockHit.getLocation();
        double bestDist = from.distanceToSqr(limit);
        Entity best = null;
        AABB search = new AABB(from, limit).inflate(1.0 + BloodRetroRules.HITBOX_INFLATE);
        for (Entity entity : level.getEntities(player, search, BloodRetroSkill::isTarget)) {
            AABB box = entity.getBoundingBox().inflate(BloodRetroRules.HITBOX_INFLATE);
            Vec3 point = box.contains(from) ? from : box.clip(from, limit).orElse(null);
            if (point != null && from.distanceToSqr(point) <= bestDist) {
                bestDist = from.distanceToSqr(point);
                best = entity;
            }
        }
        return best;
    }

    private static boolean isTarget(Entity entity) {
        return SkillTargets.isTargetable(entity)
                || (entity instanceof EnderDragonPart && entity.isAlive() && !entity.isSpectator());
    }

    /** Quita la ralentización (no hace nada si no estaba). */
    public static void removeSlowness(ServerPlayer player) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SLOW_MODIFIER_ID);
        }
    }

    private static final class BloodRetroContext extends SkillContext {
        private final float exp;
        private int held;

        BloodRetroContext(ServerPlayer player, BloodRetroSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            if (!canConsume(BloodRetroRules.overload(exp), BloodRetroRules.cp(exp))) {
                getPlayer().playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
                return;
            }
            updateSlowness();
        }

        @Override
        protected void onKeyTick() {
            held++;
            updateSlowness();
            if (BloodRetroRules.autoReleases(held)) {
                release();
            }
        }

        @Override
        protected void onKeyUp() {
            release();
        }

        private void updateSlowness() {
            AttributeInstance speed = getPlayer().getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                speed.addOrUpdateTransientModifier(new AttributeModifier(SLOW_MODIFIER_ID,
                        BloodRetroRules.slowAmount(held), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            }
        }

        private void release() {
            if (getPlayer().isAlive()) {
                fire();
            }
            terminate();
        }

        private void fire() {
            ServerPlayer player = getPlayer();
            Entity target = findTarget(player);
            if (target == null) {
                return;
            }
            float cp = BloodRetroRules.cp(exp);
            float overload = BloodRetroRules.overload(exp);
            if (!canConsume(overload, cp)) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return;
            }
            if (!VecDamage.attack(player, getSkill(), ModDamageTypes.BLOOD_RETRO, target,
                    BloodRetroRules.damage(exp))) {
                return;
            }
            consume(overload, cp);
            addSkillExp(BloodRetroRules.EXP);
            setCooldown(BloodRetroRules.cooldownTicks(exp));

            CompoundTag data = new CompoundTag();
            data.putDouble("x", target.getX());
            data.putDouble("y", target.getY());
            data.putDouble("z", target.getZ());
            data.putFloat("w", target.getBbWidth());
            data.putFloat("h", target.getBbHeight());
            sendEffect(CHANNEL_BURST, data);
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            removeSlowness(getPlayer());
        }
    }
}
