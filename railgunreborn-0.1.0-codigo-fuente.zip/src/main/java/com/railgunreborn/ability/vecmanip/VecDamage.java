package com.railgunreborn.ability.vecmanip;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.registry.ModDamageTypes;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;

/**
 * Daño común de las habilidades de Vector Manipulation: respeta el PvP del servidor, aplica {@code damage_scale} de
 * la habilidad y daña con su {@link DamageType} (con armadura). Sin marca ni efectos extra.
 */
public final class VecDamage {
    // TODO(config): attackPlayer de la ficha, como en Arc Gen y MdDamage.
    public static final boolean ATTACK_PLAYER = true;

    private VecDamage() {
    }

    /**
     * @param damage daño antes de {@code damage_scale}
     * @return si el daño se aplicó (un jugador protegido por PvP, un objetivo invulnerable... devuelven false)
     */
    public static boolean attack(ServerPlayer player, Skill skill, ResourceKey<DamageType> type, Entity target,
            float damage) {
        if (target == player || !SkillTargets.mayHarm(player, target, ATTACK_PLAYER)) {
            return false;
        }
        return target.hurt(ModDamageTypes.source(player, type), damage * skill.getDamageScale());
    }
}
