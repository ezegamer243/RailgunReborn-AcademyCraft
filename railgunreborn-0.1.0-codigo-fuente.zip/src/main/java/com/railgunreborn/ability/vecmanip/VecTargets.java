package com.railgunreborn.ability.vecmanip;

import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.registry.ModDataMaps;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Qué entidades pueden detener (Vector Deviation) o devolver (Vector Reflection) los campos de Vector Manipulation y
 * cuánto cuestan ({@code docs/spec/vecmanip-targets.md}, decisión: solo proyectiles). La regla está en
 * {@link VecTargetsRules}; aquí se leen los hechos de la entidad, las etiquetas, el data map de dificultad y la marca
 * de "ya procesada". Solo servidor.
 */
public final class VecTargets {
    /** Tipos que nunca se afectan ({@code data/railgunreborn/tags/entity_type/vecmanip/excluded.json}). */
    public static final TagKey<EntityType<?>> EXCLUDED = TagKey.create(Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "vecmanip/excluded"));
    /** Tipos no proyectil que también se afectan si se mueven (vacía por defecto). */
    public static final TagKey<EntityType<?>> AFFECTED_EXTRA = TagKey.create(Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "vecmanip/affected_extra"));

    private VecTargets() {
    }

    /** Veredicto y dificultad de una entidad; la dificultad solo tiene sentido si {@code affected()}. */
    public record Affection(VecTargetsRules.Verdict verdict, float difficulty) {
        public boolean affected() {
            return verdict.affected();
        }
    }

    /**
     * Aplica la regla a {@code entity} para el campo de {@code owner} (null = sin dueño: no hay "proyectil propio").
     */
    public static Affection classify(Entity entity, @Nullable Player owner) {
        boolean own = owner != null && entity instanceof Projectile projectile && projectile.getOwner() == owner;
        VecTargetsRules.Verdict verdict = VecTargetsRules.classify(new VecTargetsRules.Facts(
                entity instanceof LivingEntity,
                entity.getType().is(EXCLUDED),
                own,
                isMarked(entity),
                entity.getDeltaMovement().lengthSqr(),
                entity instanceof Projectile,
                entity.getType().is(AFFECTED_EXTRA)));
        return new Affection(verdict, verdict.affected() ? difficulty(entity.getType()) : 0f);
    }

    /** Dificultad del tipo según el data map {@link ModDataMaps#VECMANIP_DIFFICULTY}; 1.0 si no aparece. */
    public static float difficulty(EntityType<?> type) {
        ModDataMaps.VecDifficulty value = type.builtInRegistryHolder().getData(ModDataMaps.VECMANIP_DIFFICULTY);
        return VecTargetsRules.clampDifficulty(value == null ? null : value.difficulty());
    }

    public static boolean isMarked(Entity entity) {
        return entity.getExistingData(ModAttachments.VM_PROCESSED).orElse(false);
    }

    /** Una entidad marcada no vuelve a ser afectada por ningún campo (de nadie). */
    public static void mark(Entity entity) {
        entity.setData(ModAttachments.VM_PROCESSED, true);
    }

    /**
     * Entidades afectadas a ≤ {@code radius} bloques de los <b>pies</b> del jugador (esfera sobre la posición de cada
     * entidad, como el original), sin el jugador. Orden del mundo (sin ordenar por distancia).
     */
    public static List<Entity> inRange(Player player, double radius) {
        Vec3 center = player.position();
        double r2 = radius * radius;
        return player.level().getEntities(player, new AABB(center, center).inflate(radius),
                e -> e.position().distanceToSqr(center) <= r2 && classify(e, player).affected());
    }
}
