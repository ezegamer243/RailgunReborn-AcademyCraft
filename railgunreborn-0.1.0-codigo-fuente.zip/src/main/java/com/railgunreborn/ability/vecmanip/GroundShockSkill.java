package com.railgunreborn.ability.vecmanip;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.DoubleSupplier;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.vecmanip.GroundShockRules.Ground;
import com.railgunreborn.ability.vecmanip.GroundShockRules.Offset;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Ground Shock: mantener (5 ticks o más) y soltar con los pies en el suelo. Una onda avanza en línea recta por el
 * suelo a altura constante: transforma piedra en adoquín y césped en tierra, despeja la columna central y lanza al
 * aire (con daño) a los seres vivos; a exp 1 barre además el suelo blando de 10×10. Ficha:
 * {@code docs/spec/ground-shock.md} (mandan las decisiones del final). Números en {@link GroundShockRules}.
 *
 * <p>Los bloques solo cambian con {@link BlockPermissions#mayModifyWorld} y permiso por casilla; nunca se tocan
 * bloques con inventario u otra {@code BlockEntity}, cultivos, tierra de cultivo, líquidos ni los bloques que pisa
 * el jugador.
 */
public class GroundShockSkill extends Skill {
    /** Canal {@code perform}: {@link #CELLS_KEY} = casillas procesadas ({@link BlockPos#asLong}), como mucho 150. */
    public static final String CHANNEL_PERFORM = "perform";
    public static final String CELLS_KEY = "cells";

    /** Solo para GameTests: sustituye a todas las tiradas al azar ({@code null} = aleatorio del jugador). */
    @Nullable
    public static volatile DoubleSupplier rollOverride;

    public GroundShockSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new GroundShockContext(player, this);
    }

    /** Si la onda puede quitar este bloque (además de dureza, energía y permisos). */
    static boolean removable(BlockState state) {
        return !state.isAir()
                && !state.hasBlockEntity()
                && !(state.getBlock() instanceof FarmBlock)
                && !state.is(BlockTags.CROPS)
                && !state.liquid()
                && state.getFluidState().isEmpty();
    }

    /** Clasificación del suelo y bloque en el que se convierte (null = no cambia). */
    static Ground classify(BlockState state) {
        if (state.is(Blocks.STONE) || state.is(Blocks.GRANITE) || state.is(Blocks.DIORITE)
                || state.is(Blocks.ANDESITE) || state.is(Blocks.DEEPSLATE)) {
            return Ground.STONE;
        }
        if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.PODZOL) || state.is(Blocks.MYCELIUM)) {
            return Ground.GRASS;
        }
        if (state.getBlock() instanceof FarmBlock) {
            return Ground.FARMLAND;
        }
        return Ground.OTHER;
    }

    @Nullable
    static BlockState transformed(BlockState state) {
        if (state.is(Blocks.DEEPSLATE)) {
            return Blocks.COBBLED_DEEPSLATE.defaultBlockState();
        }
        return switch (classify(state)) {
            case STONE -> Blocks.COBBLESTONE.defaultBlockState();
            case GRASS -> Blocks.DIRT.defaultBlockState();
            default -> null;
        };
    }

    private static final class GroundShockContext extends SkillContext {
        private final float exp;
        private ServerLevel level;
        private boolean mayModify;
        private int groundY;
        private AABB feet;
        private double energy;

        GroundShockContext(ServerPlayer player, GroundShockSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        private double roll() {
            DoubleSupplier override = rollOverride;
            return override != null ? override.getAsDouble() : getPlayer().getRandom().nextDouble();
        }

        @Override
        protected void onKeyUp() {
            if (GroundShockRules.holdLongEnough(getTicksAlive())) {
                perform();
            }
            terminate();
        }

        private void perform() {
            ServerPlayer player = getPlayer();
            // En el aire no pasa nada: ni coste ni cooldown.
            if (!player.onGround()) {
                return;
            }
            Vec3 look = player.getViewVector(1.0f);
            double dx = look.x;
            double dz = look.z;
            List<Offset> path = GroundShockRules.line(dx, dz, GroundShockRules.maxSteps(exp));
            if (path.isEmpty()) {
                return;
            }
            if (!consume(GroundShockRules.overload(exp), GroundShockRules.cp(exp))) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return;
            }
            level = player.serverLevel();
            mayModify = BlockPermissions.mayModifyWorld(player, getSkill());
            groundY = Mth.floor(player.getY()) - 1;
            feet = player.getBoundingBox();
            energy = GroundShockRules.initialEnergy(exp);
            double ySpeed = GroundShockRules.launchSpeed(exp, roll());
            BlockPos origin = new BlockPos(Mth.floor(player.getX()), groundY, Mth.floor(player.getZ()));

            Set<BlockPos> processed = new HashSet<>();
            List<BlockPos> cells = new ArrayList<>();
            Set<Integer> hit = new HashSet<>();
            int hurt = 0;
            wave:
            for (Offset step : path) {
                BlockPos center = origin.offset(step.x(), 0, step.z());
                for (int i = 0; i < GroundShockRules.LATERAL_OFFSETS.length; i++) {
                    if (energy <= 0) {
                        break wave;
                    }
                    Offset lateral = GroundShockRules.lateral(dx, dz, GroundShockRules.LATERAL_OFFSETS[i]);
                    BlockPos cell = center.offset(lateral.x(), 0, lateral.z());
                    if (processed.contains(cell) || roll() >= GroundShockRules.LATERAL_PROBS[i]) {
                        continue;
                    }
                    BlockState state = level.getBlockState(cell);
                    if (state.isAir()) {
                        continue;
                    }
                    processed.add(cell);
                    if (cells.size() < GroundShockRules.MAX_EFFECT_CELLS) {
                        cells.add(cell);
                    }
                    transform(cell, state);
                    // La zanja va por la casilla central del paso (el original apuntaba aquí; ver ficha §5).
                    if (roll() < GroundShockRules.GROUND_BREAK_PROB) {
                        breakWithForce(center);
                    }
                    hurt += hitEntities(cell, hit, ySpeed);
                    for (int h = 1; h <= GroundShockRules.COLUMN_HEIGHT; h++) {
                        breakWithForce(center.above(h));
                    }
                }
            }
            if (GroundShockRules.sweepActive(exp)) {
                sweep(origin);
            }

            addSkillExp(GroundShockRules.EXP_USE + GroundShockRules.EXP_PER_HIT * hurt);
            setCooldown(GroundShockRules.cooldownTicks(exp));
            CompoundTag data = new CompoundTag();
            data.putLongArray(CELLS_KEY, cells.stream().mapToLong(BlockPos::asLong).toArray());
            sendEffect(CHANNEL_PERFORM, data);
        }

        private boolean underFeet(BlockPos pos) {
            return GroundShockRules.underFeet(pos.getX(), pos.getY(), pos.getZ(), groundY, feet.minX, feet.maxX,
                    feet.minZ, feet.maxZ);
        }

        /** Piedra → adoquín, césped → tierra; la energía se gasta aunque el bloque no pueda cambiar. */
        private void transform(BlockPos pos, BlockState state) {
            energy -= classify(state).energyCost;
            BlockState result = transformed(state);
            if (result != null && mayModify && BlockPermissions.mayBreakAt(getPlayer(), pos, state)) {
                level.setBlock(pos, result, Block.UPDATE_ALL);
            }
        }

        /** Rompe el bloque si hay energía para su dureza, con drops; cuesta su dureza. */
        private void breakWithForce(BlockPos pos) {
            if (!mayModify || underFeet(pos)) {
                return;
            }
            BlockState state = level.getBlockState(pos);
            if (!removable(state)) {
                return;
            }
            float hardness = state.getDestroySpeed(level, pos);
            if (!GroundShockRules.canBreak(energy, hardness)
                    || !BlockPermissions.mayBreakAt(getPlayer(), pos, state)) {
                return;
            }
            Block.dropResources(state, level, pos, null, getPlayer(), ItemStack.EMPTY);
            level.destroyBlock(pos, false, getPlayer());
            energy -= hardness;
        }

        /** @return seres vivos dañados de verdad (para la exp) */
        private int hitEntities(BlockPos cell, Set<Integer> hit, double ySpeed) {
            ServerPlayer player = getPlayer();
            AABB box = new AABB(cell.getX() - 0.2, cell.getY() - 0.2, cell.getZ() - 0.2,
                    cell.getX() + 1.4, cell.getY() + 2.2, cell.getZ() + 1.4);
            int hurt = 0;
            for (Entity entity : level.getEntities(player, box, SkillTargets::isTargetable)) {
                if (isOwnPet(entity) || !hit.add(entity.getId())) {
                    continue;
                }
                energy -= GroundShockRules.ENTITY_ENERGY;
                if (!SkillTargets.mayHarm(player, entity, VecDamage.ATTACK_PLAYER)) {
                    continue;
                }
                if (VecDamage.attack(player, getSkill(), ModDamageTypes.GROUND_SHOCK, entity,
                        GroundShockRules.damage(exp))) {
                    hurt++;
                }
                // Tras el daño (que aplica su propio retroceso): solo se fija la vertical.
                Vec3 motion = entity.getDeltaMovement();
                entity.setDeltaMovement(motion.x, ySpeed, motion.z);
                entity.hurtMarked = true;
            }
            return hurt;
        }

        private boolean isOwnPet(Entity entity) {
            return entity instanceof OwnableEntity pet && getPlayer().getUUID().equals(pet.getOwnerUUID());
        }

        /** Barrido de exp 1: suelo blando 10×10 (dureza ≤ 0.6) con drops, sin los bloques que pisa el jugador. */
        private void sweep(BlockPos origin) {
            if (!mayModify) {
                return;
            }
            ServerPlayer player = getPlayer();
            for (int x = GroundShockRules.SWEEP_MIN; x <= GroundShockRules.SWEEP_MAX; x++) {
                for (int z = GroundShockRules.SWEEP_MIN; z <= GroundShockRules.SWEEP_MAX; z++) {
                    for (int y = 0; y <= 1; y++) {
                        BlockPos pos = origin.offset(x, y, z);
                        if (underFeet(pos)) {
                            continue;
                        }
                        BlockState state = level.getBlockState(pos);
                        if (!removable(state)) {
                            continue;
                        }
                        float hardness = state.getDestroySpeed(level, pos);
                        if (hardness < 0f || hardness > GroundShockRules.SWEEP_MAX_HARDNESS
                                || !BlockPermissions.mayBreakAt(player, pos, state)) {
                            continue;
                        }
                        Block.dropResources(state, level, pos, null, player, ItemStack.EMPTY);
                        // Sin partículas ni sonido por bloque: ya los pone el efecto de la onda.
                        level.removeBlock(pos, false);
                    }
                }
            }
        }
    }
}
