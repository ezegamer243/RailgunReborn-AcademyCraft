package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Vector Deviation ({@code docs/spec/vec-deviation.md}) en Java puro, para probarlos con
 * JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al activar.
 */
public final class VecDeviationRules {
    /** Radio del campo en bloques, medido desde los pies. */
    public static final double RADIUS = 5.0;
    public static final float EXP_ENTITY = 0.001f;
    public static final float EXP_DAMAGE = 0.0006f;
    /** Por encima de esto el golpe no se reduce (vacío, /kill), como el original. */
    public static final float MAX_REDUCIBLE_DAMAGE = 9999f;
    /** Volumen del sonido al reducir un golpe (el original: 0.5). */
    public static final float HIT_SOUND_VOLUME = 0.5f;
    /** Volumen del sonido en cada proyectil detenido (más bajo: pueden ser muchos). */
    public static final float STOP_SOUND_VOLUME = 0.4f;

    private VecDeviationRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Overload que se suma una vez al activar. */
    public static float initialOverload(float exp) {
        return lerp(80f, 50f, exp);
    }

    /** CP de mantenimiento por tick ("A" de la ficha). */
    public static float cpHold(float exp) {
        return lerp(13f, 5f, exp);
    }

    /** CP base por tick ("B" de la ficha), que va junto con {@link #overloadPerTick}. */
    public static float cpBase(float exp) {
        return lerp(5f, 2.5f, exp);
    }

    /** CP total por tick: 18 a exp 0 y 7.5 a exp 1. */
    public static float cpPerTick(float exp) {
        return cpHold(exp) + cpBase(exp);
    }

    /** Overload que sube cada tick: el campo acaba sobrecargando y se apaga solo. */
    public static float overloadPerTick(float exp) {
        return lerp(0.5f, 0.2f, exp);
    }

    /** CP (forzado) por entidad detenida; decisión: multiplicado por la dificultad del data map. */
    public static float entityCost(float exp, float difficulty) {
        return lerp(15f, 12f, exp) * difficulty;
    }

    /** CP (forzado, como mucho el que quede) por golpe reducido. */
    public static float hitCost(float exp) {
        return lerp(15f, 12f, exp);
    }

    /** Fracción del daño que se elimina: 40 % a exp 0, 90 % a exp 1. */
    public static float damageCut(float exp) {
        return lerp(0.4f, 0.9f, exp);
    }

    /** Si un golpe pasa por el campo: positivo, que no ignore la invulnerabilidad y no desmesurado. */
    public static boolean reduces(float damage, boolean bypassesInvulnerability) {
        return damage > 0f && !bypassesInvulnerability && damage <= MAX_REDUCIBLE_DAMAGE;
    }

    /** Daño que queda tras el campo. */
    public static float reducedDamage(float damage, float exp) {
        return damage * (1f - damageCut(exp));
    }

    public static float entityExp(float difficulty) {
        return EXP_ENTITY * difficulty;
    }

    public static float damageExp(float damage) {
        return EXP_DAMAGE * damage;
    }
}
