package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Vector Reflection ({@code docs/spec/vec-reflection.md}, mandan las "Decisiones para el
 * port") en Java puro, para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1], leída en cada uso.
 */
public final class VecReflectionRules {
    /** Radio del campo para proyectiles, medido desde los pies. */
    public static final double RANGE = 4.0;
    /** Alcance del trazado de la mirada que decide hacia dónde sale lo reflejado. */
    public static final double AIM_RANGE = 20.0;
    /** Tope de proyectiles reflejados por tick (lluvias de flechas). */
    public static final int SCAN_LIMIT = 16;
    public static final float EXP_ENTITY = 0.0008f;
    public static final float EXP_DAMAGE = 0.0004f;
    /** Por encima de esto el golpe no se refleja (vacío, /kill), como el original. */
    public static final float MAX_REFLECTABLE_DAMAGE = 9999f;
    /** Volumen del sonido de reflejo (original 0.5; decisión: sonidos moderados). */
    public static final float SOUND_VOLUME = 0.5f;
    /** Cada cuántos ticks se manda el pulso visual del campo activo (efecto en el mundo, no en pantalla). */
    public static final int PULSE_TICKS = 20;

    private VecReflectionRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Overload fijo que se suma al activar y se mantiene mientras dura. */
    public static float overloadKeep(float exp) {
        return lerp(350f, 250f, exp);
    }

    /** CP de mantenimiento por tick. */
    public static float cpPerTick(float exp) {
        return lerp(15f, 11f, exp);
    }

    /** CP por proyectil reflejado. */
    public static float cpPerEntity(float exp, float difficulty) {
        return difficulty * lerp(300f, 160f, exp);
    }

    /** CP por golpe o rayo reflejado (decisión: se cobra; el original lo tenía como código muerto). */
    public static float cpPerDamage(float exp, float damage) {
        return lerp(20f, 15f, exp) * damage;
    }

    /** Fracción del golpe que se devuelve al atacante: 60 % a exp 0, 120 % a exp 1. */
    public static float reflectRatio(float exp) {
        return lerp(0.6f, 1.2f, exp);
    }

    /** Daño que vuelve al atacante de un golpe de {@code damage}. */
    public static float reflectedDamage(float exp, float damage) {
        return reflectRatio(exp) * damage;
    }

    public static float expPerEntity(float difficulty) {
        return EXP_ENTITY * difficulty;
    }

    public static float expPerDamage(float damage) {
        return EXP_DAMAGE * damage;
    }

    /**
     * Rechazo al pulsar (decisión): el overload fijo tiene que caber sin llenar la barra. Con el máximo base del
     * nivel 4 (350) a exp 0 solo cabe si el jugador ya ganó bonus de overload.
     */
    public static boolean overloadFits(float overload, float keep, float maxOverload) {
        return overload + keep < maxOverload;
    }

    /** Lo que importa de un golpe para decidir si se refleja. */
    public record Hit(float damage, boolean hasAttacker, boolean attackerIsSelf, boolean bypassesInvulnerability,
            boolean alreadyReflected) {
    }

    /**
     * Decisión del usuario: solo ataques. Se refleja el daño causado por otra entidad (golpe, proyectil, explosión
     * de un mob...); caída, fuego, lava, vacío, ahogo y el resto sin atacante entran normal. Tampoco se refleja el
     * daño ya reflejado (dos reflectores no se devuelven el golpe en bucle) ni lo que ignora la invulnerabilidad.
     */
    public static boolean isReflectable(Hit hit) {
        return hit.damage() > 0f
                && hit.damage() <= MAX_REFLECTABLE_DAMAGE
                && hit.hasAttacker()
                && !hit.attackerIsSelf()
                && !hit.bypassesInvulnerability()
                && !hit.alreadyReflected();
    }
}
