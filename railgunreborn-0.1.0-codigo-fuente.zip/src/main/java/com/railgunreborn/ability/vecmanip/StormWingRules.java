package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Storm Wing ({@code docs/spec/storm-wing.md}, mandan las "Decisiones para el port") en Java
 * puro, para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al activar (salvo la rotura de
 * bloques, que mira la exp en vivo).
 */
public final class StormWingRules {
    /** Lo que cada eje de la velocidad se acerca como mucho a la velocidad objetivo por tick (bloques/tick). */
    public static final double ACCEL = 0.16;
    public static final float EXP_PER_TICK = 0.00005f;
    /** Por debajo de esta exp (en vivo) se rompen bloques débiles cercanos. */
    public static final float BREAK_EXP_LIMIT = 0.15f;
    public static final float BREAK_HARDNESS = 0.3f;
    public static final int BREAK_ATTEMPTS = 40;
    public static final int BREAK_RANGE = 10;
    /** Volumen del sonido de rotura (como mucho uno por tick). */
    public static final float BREAK_SOUND_VOLUME = 0.5f;
    /** Flotando en el aire: casi cancela la gravedad (0.08), queda una caída muy lenta. */
    public static final double HOVER_LIFT = 0.078;
    /** Flotando pegado al suelo: velocidad vertical fija para despegarse. */
    public static final double HOVER_GROUND = 0.1;
    public static final double GUST_RADIUS = 6.0;
    public static final double GUST_MIN_SPEED = 0.5;
    public static final double GUST_MAX_SPEED = 1.0;
    /** Decisión: inmunidad de caída tras terminar (~3 s), aunque se termine por sobrecarga en el aire. */
    public static final int FALL_GUARD_TICKS = 60;
    /** Decisión: bucle moderado (el original: 1.0). */
    public static final float LOOP_VOLUME = 0.45f;
    /** Decisión: menos polvo que el original (12 por tick). */
    public static final int PARTICLES_PER_TICK = 5;

    private StormWingRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Ticks de carga (gratis, flotando) antes de poder volar: 70 a exp 0, 30 a exp 1. */
    public static int chargeTicks(float exp) {
        return (int) Math.ceil(lerp(70f, 30f, exp) - 1e-4f);
    }

    /** CP por tick de vuelo (como el original). */
    public static float cpPerTick(float exp) {
        return lerp(40f, 25f, exp);
    }

    /**
     * Overload por tick de vuelo. Decisión del usuario: vuelo de ~5-6 s con el overload máximo de nivel 3 (240 sin
     * bonus): 2.4 a exp 0 (100 ticks) y 2.0 a exp 1 (120 ticks). El original: 10 a 7 (1.2-2.3 s).
     */
    public static float overloadPerTick(float exp) {
        return lerp(2.4f, 2.0f, exp);
    }

    /** Ticks de vuelo hasta llenar {@code maxOverload} empezando en {@code overload} (no se recupera mientras vuela). */
    public static int flightTicksByOverload(float maxOverload, float overload, float exp) {
        return (int) Math.ceil((maxOverload - overload) / overloadPerTick(exp) - 1e-4f);
    }

    /** Velocidad máxima en bloques/tick, con el escalón del original en exp 0.45 (1.4 a exp 0, 3.6 a exp 1). */
    public static double speed(float exp) {
        return (exp < 0.45f ? 0.7 : 1.2) * lerp(2f, 3f, exp);
    }

    public static int cooldown(float exp) {
        return (int) lerp(30f, 10f, exp);
    }

    public static boolean breaksBlocks(float liveExp) {
        return liveExp < BREAK_EXP_LIMIT;
    }

    public static boolean breakableHardness(float hardness) {
        return hardness >= 0f && hardness <= BREAK_HARDNESS;
    }

    /** La ráfaga al empezar a volar solo con la exp al máximo. */
    public static boolean gust(float exp) {
        return exp >= 1f;
    }

    /** Un eje de la velocidad acercándose a {@code target} como mucho {@link #ACCEL}. */
    public static double approach(double current, double target) {
        double delta = target - current;
        if (Math.abs(delta) <= ACCEL) {
            return target;
        }
        return current + Math.copySign(ACCEL, delta);
    }

    /** Siguiente velocidad (límite de aceleración por eje, como el original). */
    public static double[] nextVelocity(double[] current, double[] desired) {
        return new double[] {approach(current[0], desired[0]), approach(current[1], desired[1]),
                approach(current[2], desired[2])};
    }

    /**
     * Dirección de vuelo unitaria según las teclas pulsadas, o {0,0,0} si no hay ninguna (o se anulan). Decisión:
     * diagonales (se suman). W/S siguen la mirada (con inclinación); A/D son laterales horizontales.
     *
     * @param yawDeg   yaw de la cabeza en grados (convención de Minecraft: 0 = +Z)
     * @param pitchDeg pitch en grados (positivo = mirando abajo)
     */
    public static double[] direction(boolean forward, boolean back, boolean left, boolean right, float yawDeg,
            float pitchDeg) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double lookX = -Math.sin(yaw) * Math.cos(pitch);
        double lookY = -Math.sin(pitch);
        double lookZ = Math.cos(yaw) * Math.cos(pitch);
        // Izquierda horizontal: mirando a +Z, la izquierda es +X.
        double leftX = Math.cos(yaw);
        double leftZ = Math.sin(yaw);
        double x = 0;
        double y = 0;
        double z = 0;
        if (forward) {
            x += lookX;
            y += lookY;
            z += lookZ;
        }
        if (back) {
            x -= lookX;
            y -= lookY;
            z -= lookZ;
        }
        if (left) {
            x += leftX;
            z += leftZ;
        }
        if (right) {
            x -= leftX;
            z -= leftZ;
        }
        double len = Math.sqrt(x * x + y * y + z * z);
        if (len < 1e-6) {
            return new double[] {0, 0, 0};
        }
        return new double[] {x / len, y / len, z / len};
    }

    /** Velocidad vertical al flotar (sin tecla o durante la carga). */
    public static double hoverVertical(double currentY, boolean nearGround) {
        return nearGround ? HOVER_GROUND : currentY + HOVER_LIFT;
    }
}
