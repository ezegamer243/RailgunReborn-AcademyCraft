package com.railgunreborn.ability.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.world.phys.Vec3;

/**
 * Vector Deviation: nivel 2 de Vector Manipulation. Interruptor: mientras está activo detiene los proyectiles ajenos a
 * ≤ 5 bloques y reduce el daño que recibe su dueño. Ficha: {@code docs/spec/vec-deviation.md} (mandan las decisiones
 * del final); entidades afectadas en {@link VecTargets}. Números en {@link VecDeviationRules}.
 *
 * <p>El overload sube cada tick (como el original): el campo acaba sobrecargando y se apaga solo.
 */
public class VecDeviationSkill extends Skill {
    /** Proyectil detenido o eliminado: {@link #ENTITY_KEY} y {@link #POS_KEY} (anillo y sonido en los cercanos). */
    public static final String CHANNEL_STOP = "stop";
    /** Golpe reducido: sonido en el jugador. */
    public static final String CHANNEL_HIT = "hit";
    public static final String ENTITY_KEY = "id";
    public static final String POS_KEY = "pos";

    public VecDeviationSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new VecDeviationContext(player, this);
    }

    /** Se activa con la tecla y se apaga con la misma tecla o V. */
    @Override
    public boolean isToggle() {
        return true;
    }

    /** Campo activo del propio jugador, o null (nunca el de otro). */
    @Nullable
    public static VecDeviationContext activeField(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof VecDeviationContext field && !field.isTerminated() && field.started) {
                return field;
            }
        }
        return null;
    }

    /**
     * Proyectiles que se impulsan solos cada tick (bolas de fuego, calaveras del Wither, bolas del dragón, cargas de
     * viento, balas de Shulker): con velocidad 0 se reanudarían, así que se eliminan (sin explosión).
     */
    public static boolean isSelfPropelled(Entity entity) {
        return entity instanceof AbstractHurtingProjectile || entity instanceof ShulkerBullet;
    }

    public static final class VecDeviationContext extends SkillContext {
        private final float exp;
        private boolean started;
        /** Overload tras el arranque: no se deja bajar mientras el campo esté activo. */
        private float overloadFloor;
        private int stopped;

        VecDeviationContext(ServerPlayer player, VecDeviationSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        public boolean isStarted() {
            return started;
        }

        /** Entidades detenidas o eliminadas (para pruebas). */
        public int stoppedCount() {
            return stopped;
        }

        @Override
        protected void onKeyDown() {
            // Sin CP para el primer tick no se cobra el overload inicial.
            if (!canConsume(0f, VecDeviationRules.cpPerTick(exp))
                    || !consume(VecDeviationRules.initialOverload(exp), 0f)) {
                getPlayer().playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
                return;
            }
            started = true;
            overloadFloor = CPData.get(getPlayer()).getOverload();
        }

        @Override
        protected void tick() {
            if (!started) {
                return;
            }
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadFloor);
            if (!consume(VecDeviationRules.overloadPerTick(exp), VecDeviationRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            for (Entity entity : VecTargets.inRange(player, VecDeviationRules.RADIUS)) {
                deviate(entity);
            }
        }

        private void deviate(Entity entity) {
            ServerPlayer player = getPlayer();
            float difficulty = VecTargets.difficulty(entity.getType());
            // Forzado: se cobra aunque no alcance (el CP baja a 0 y el tick siguiente termina).
            CPData.get(player).consumeWithForce(player, 0f,
                    VecDeviationRules.entityCost(exp, difficulty) * getSkill().getCpConsumeSpeed());
            Vec3 pos = entity.position().add(0, entity.getBbHeight() * 0.5, 0);
            if (isSelfPropelled(entity)) {
                // Decisión: la bola de fuego grande desaparece sin explotar (igual que el resto que se impulsa sola).
                entity.discard();
                player.serverLevel().sendParticles(ParticleTypes.POOF, pos.x, pos.y, pos.z, 6, 0.15, 0.15, 0.15,
                        0.01);
            } else {
                entity.setDeltaMovement(Vec3.ZERO);
                // Fuerza el paquete de velocidad a los clientes en este mismo tick.
                entity.hurtMarked = true;
                entity.hasImpulse = true;
                if (entity instanceof AbstractArrow arrow) {
                    arrow.setBaseDamage(0.0);
                }
                VecTargets.mark(entity);
            }
            addSkillExp(VecDeviationRules.entityExp(difficulty));
            stopped++;
            CompoundTag data = new CompoundTag();
            data.putInt(ENTITY_KEY, entity.getId());
            MagMovementSkill.writeVec(data, POS_KEY, pos);
            sendEffect(CHANNEL_STOP, data);
        }

        /** Daño que le queda al dueño del campo tras la reducción (cualquier fuente salvo la que ignora todo). */
        public float handleDamage(DamageSource source, float damage) {
            if (!VecDeviationRules.reduces(damage, source.is(DamageTypeTags.BYPASSES_INVULNERABILITY))) {
                return damage;
            }
            ServerPlayer player = getPlayer();
            // Como el original: cobra lo que pueda (sin exigir CP) y reduce igual.
            CPData.get(player).consumeWithForce(player, 0f,
                    VecDeviationRules.hitCost(exp) * getSkill().getCpConsumeSpeed());
            addSkillExp(VecDeviationRules.damageExp(damage));
            sendEffect(CHANNEL_HIT, new CompoundTag());
            return VecDeviationRules.reducedDamage(damage, exp);
        }
    }
}
