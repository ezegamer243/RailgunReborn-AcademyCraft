package com.railgunreborn.ability.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Storm Wing: nivel 3 de Vector Manipulation. Interruptor: tras una carga gratis en la que se flota, se vuela a gran
 * velocidad con las teclas de movimiento hasta apagarla o quedarse sin CP/overload. Ficha:
 * {@code docs/spec/storm-wing.md} (mandan las decisiones del final). Números en {@link StormWingRules}.
 *
 * <p>Como Magnet Movement, el movimiento lo decide el cliente local; el servidor cuenta la carga (decisión: no se fía
 * del cliente), avisa al pasar a vuelo ({@link #CHANNEL_ACTIVE}), cobra, anula la caída y el anti-kick por "volar",
 * rompe bloques débiles con exp baja y, al terminar, deja una inmunidad de caída corta.
 */
public class StormWingSkill extends Skill {
    /** Empieza la carga: {@link #CHARGE_KEY} (al jugador local y a los cercanos). */
    public static final String CHANNEL_START = "start";
    /** Fin de la carga: empieza el vuelo (al jugador local y a los cercanos). */
    public static final String CHANNEL_ACTIVE = "active";
    /** Terminó (efecto para los cercanos). */
    public static final String CHANNEL_STOP = "stop";
    public static final String CHARGE_KEY = "charge";

    public StormWingSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new StormWingContext(player, this);
    }

    /** Se activa con la tecla y se apaga con la misma tecla o V. */
    @Override
    public boolean isToggle() {
        return true;
    }

    /** Contexto vivo del jugador, o null. */
    @Nullable
    public static StormWingContext activeWing(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof StormWingContext wing && !wing.isTerminated()) {
                return wing;
            }
        }
        return null;
    }

    public static final class StormWingContext extends SkillContext {
        private final float exp;
        private final int chargeTicks;
        private int charged;
        private boolean flying;
        private int flightTicks;
        private int broken;

        StormWingContext(ServerPlayer player, StormWingSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
            this.chargeTicks = StormWingRules.chargeTicks(exp);
        }

        public boolean isFlying() {
            return flying;
        }

        public int chargeTicks() {
            return chargeTicks;
        }

        /** Ticks cobrados en vuelo (para pruebas). */
        public int flightTicks() {
            return flightTicks;
        }

        /** Bloques rotos por la exp baja (para pruebas). */
        public int brokenBlocks() {
            return broken;
        }

        @Override
        protected void onKeyDown() {
            CompoundTag data = new CompoundTag();
            data.putInt(CHARGE_KEY, chargeTicks);
            sendToLocal(CHANNEL_START, data);
            sendEffect(CHANNEL_START, data);
        }

        @Override
        protected void tick() {
            ServerPlayer player = getPlayer();
            player.resetFallDistance();
            MagMovementSkill.resetFlying(player);
            breakBlocks();
            if (!flying) {
                if (++charged >= chargeTicks) {
                    activate();
                }
                return;
            }
            if (!consume(StormWingRules.overloadPerTick(exp), StormWingRules.cpPerTick(exp))) {
                terminate();
                return;
            }
            flightTicks++;
            addSkillExp(StormWingRules.EXP_PER_TICK);
            if (player.isPassenger()) {
                player.stopRiding();
            }
        }

        private void activate() {
            flying = true;
            sendToLocal(CHANNEL_ACTIVE, new CompoundTag());
            sendEffect(CHANNEL_ACTIVE, new CompoundTag());
            if (StormWingRules.gust(exp)) {
                gust();
            }
        }

        /** Decisión: la ráfaga solo empuja seres vivos y proyectiles (ni ítems ni el propio jugador). Sin daño. */
        private void gust() {
            ServerPlayer player = getPlayer();
            Vec3 feet = player.position();
            double r = StormWingRules.GUST_RADIUS;
            RandomSource random = player.getRandom();
            for (Entity entity : player.level().getEntities(player, new AABB(feet, feet).inflate(r),
                    e -> (e instanceof LivingEntity || e instanceof Projectile) && e.isAlive() && !e.isSpectator()
                            && e.position().distanceToSqr(feet) <= r * r)) {
                Vec3 away = entity.getEyePosition().subtract(feet);
                if (away.lengthSqr() < 1e-6) {
                    away = new Vec3(0, 1, 0);
                }
                double speed = Mth.nextDouble(random, StormWingRules.GUST_MIN_SPEED, StormWingRules.GUST_MAX_SPEED);
                entity.setDeltaMovement(away.normalize().scale(speed));
                entity.hurtMarked = true;
                entity.hasImpulse = true;
            }
        }

        /**
         * Con exp baja (en vivo) se rompen bloques débiles al azar alrededor. Decisión: sueltan su botín, respetan
         * permisos/protecciones y como mucho suena una rotura por tick.
         */
        private void breakBlocks() {
            if (!breaksBlocksNow()) {
                return;
            }
            RandomSource random = getPlayer().getRandom();
            BlockPos center = getPlayer().blockPosition();
            int range = StormWingRules.BREAK_RANGE;
            boolean soundPlayed = false;
            for (int i = 0; i < StormWingRules.BREAK_ATTEMPTS; i++) {
                BlockPos pos = center.offset(random.nextIntBetweenInclusive(-range, range),
                        random.nextIntBetweenInclusive(-range, range), random.nextIntBetweenInclusive(-range, range));
                if (tryBreak(pos, !soundPlayed)) {
                    soundPlayed = true;
                }
            }
        }

        /** Exp en vivo por debajo del límite, y la habilidad y el mundo permiten romper. */
        public boolean breaksBlocksNow() {
            ServerPlayer player = getPlayer();
            float liveExp = AbilityData.get(player).getSkillExp(getSkill().getId());
            return StormWingRules.breaksBlocks(liveExp) && BlockPermissions.mayModifyWorld(player, getSkill());
        }

        /**
         * Rompe {@code pos} si es débil y hay permiso en esa casilla, soltando su botín (lo usa el sorteo de cada
         * tick; público para las pruebas, que no pueden depender del azar). true = se rompió.
         */
        public boolean tryBreak(BlockPos pos, boolean playSound) {
            ServerPlayer player = getPlayer();
            ServerLevel level = player.serverLevel();
            if (!level.isLoaded(pos)) {
                return false;
            }
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || !StormWingRules.breakableHardness(state.getDestroySpeed(level, pos))
                    || !BlockPermissions.mayBreakAt(player, pos, state)) {
                return false;
            }
            Block.dropResources(state, level, pos, level.getBlockEntity(pos), player, ItemStack.EMPTY);
            // Lo que quede (p. ej. el agua de un bloque anegado) sustituye al bloque.
            level.setBlock(pos, state.getFluidState().createLegacyBlock(), Block.UPDATE_ALL);
            level.gameEvent(GameEvent.BLOCK_DESTROY, pos, GameEvent.Context.of(player, state));
            broken++;
            if (playSound) {
                SoundType sound = state.getSoundType(level, pos, player);
                level.playSound(null, pos, sound.getBreakSound(), SoundSource.BLOCKS,
                        StormWingRules.BREAK_SOUND_VOLUME, sound.getPitch() * 0.8f);
            }
            return true;
        }

        @Override
        protected void onTerminated(TerminationReason reason) {
            ServerPlayer player = getPlayer();
            setCooldown(StormWingRules.cooldown(exp));
            player.resetFallDistance();
            MagMovementSkill.resetFlying(player);
            // Decisión: ~3 s sin daño de caída tras terminar (se quita sola al aterrizar).
            if (player.isAlive()) {
                SafeTeleport.guardFall(player, StormWingRules.FALL_GUARD_TICKS);
            }
            sendEffect(CHANNEL_STOP, new CompoundTag());
        }
    }
}
