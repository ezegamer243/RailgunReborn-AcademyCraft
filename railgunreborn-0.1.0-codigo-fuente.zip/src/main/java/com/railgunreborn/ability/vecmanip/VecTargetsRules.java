package com.railgunreborn.ability.vecmanip;

/**
 * Regla pura de "entidades afectadas" por Vector Deviation y Vector Reflection ({@code docs/spec/vecmanip-targets.md}
 * §3.1 y decisiones). Sin clases de Minecraft para poder probarla con JUnit; {@link VecTargets} le pasa los hechos.
 */
public final class VecTargetsRules {
    /** Velocidad² mínima (≈ 0.05 bloques/tick) para contar como "en vuelo": flechas clavadas y cosas quietas no. */
    public static final double MIN_SPEED_SQR = 0.0025;
    public static final float DEFAULT_DIFFICULTY = 1.0f;
    public static final float MIN_DIFFICULTY = 0.05f;
    public static final float MAX_DIFFICULTY = 10.0f;

    private VecTargetsRules() {
    }

    /** Resultado en el orden en que se comprueban las reglas: el primero que aplica gana. */
    public enum Verdict {
        /** Ser vivo (jugadores, mobs, armor stands): nunca, no se cambia por datos. */
        LIVING,
        /** Tipo en la etiqueta {@code railgunreborn:vecmanip/excluded}. */
        EXCLUDED,
        /** Proyectil del propio jugador del campo. */
        OWN,
        /** Ya procesada por un campo (marca). */
        MARKED,
        /** Casi quieta. */
        STILL,
        /** Ni {@code Projectile} ni en la etiqueta {@code railgunreborn:vecmanip/affected_extra}. */
        NOT_PROJECTILE,
        AFFECTED;

        public boolean affected() {
            return this == AFFECTED;
        }
    }

    /** Lo que {@link #classify} necesita saber de una entidad. */
    public record Facts(boolean living, boolean excluded, boolean ownProjectile, boolean marked, double speedSqr,
            boolean projectile, boolean affectedExtra) {
    }

    public static Verdict classify(Facts f) {
        if (f.living()) {
            return Verdict.LIVING;
        }
        if (f.excluded()) {
            return Verdict.EXCLUDED;
        }
        if (f.ownProjectile()) {
            return Verdict.OWN;
        }
        if (f.marked()) {
            return Verdict.MARKED;
        }
        if (f.speedSqr() < MIN_SPEED_SQR) {
            return Verdict.STILL;
        }
        if (!f.projectile() && !f.affectedExtra()) {
            return Verdict.NOT_PROJECTILE;
        }
        return Verdict.AFFECTED;
    }

    /** Dificultad del data map limitada a [{@value #MIN_DIFFICULTY}, {@value #MAX_DIFFICULTY}]; sin valor, 1.0. */
    public static float clampDifficulty(Float value) {
        if (value == null || value.isNaN()) {
            return DEFAULT_DIFFICULTY;
        }
        return Math.clamp(value, MIN_DIFFICULTY, MAX_DIFFICULTY);
    }
}
