package com.railgunreborn.ability.vecmanip;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BeamReflect;
import com.railgunreborn.ability.common.BeamReflectEvent;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Vector Reflection: nivel 4 de Vector Manipulation. Interruptor: mientras está activo devuelve hacia donde mira el
 * jugador los proyectiles a ≤ 4 bloques, anula los golpes de otras entidades devolviendo parte del daño al atacante y
 * refleja los rayos de Railgun y Meltdowner ({@link BeamReflectEvent}). Todo cobra CP; sin CP el ataque entra normal y
 * el campo se apaga. Caída, fuego, lava, vacío y daño sin atacante no se reflejan. Ficha:
 * {@code docs/spec/vec-reflection.md} (mandan las decisiones del final). Números en {@link VecReflectionRules}.
 */
public class VecReflectionSkill extends Skill {
    /** Algo reflejado: {@link #POS_KEY} (dónde) y {@link #DIR_KEY} (hacia dónde sale): onda y sonido. */
    public static final String CHANNEL_REFLECT = "reflect";
    /** Rayo reflejado: además del reflejo, el rayo de vuelta ({@link #LENGTH_KEY}, {@link #BEAM_KEY}). */
    public static final String CHANNEL_BEAM = "beam";
    /** Campo activo (cada {@link VecReflectionRules#PULSE_TICKS}): brillo tenue alrededor del jugador. */
    public static final String CHANNEL_PULSE = "pulse";
    public static final String POS_KEY = "pos";
    public static final String DIR_KEY = "dir";
    public static final String LENGTH_KEY = "len";
    /** Id de la habilidad atacante (el cliente elige el estilo del rayo de vuelta). */
    public static final String BEAM_KEY = "skill";

    /** Jugadores que están devolviendo un golpe ahora mismo (espinas o dos reflectores no entran en bucle). */
    private static final Set<UUID> REFLECTING = new HashSet<>();

    public VecReflectionSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new VecReflectionContext(player, this);
    }

    /** Se activa con la tecla y se apaga con la misma tecla o V. */
    @Override
    public boolean isToggle() {
        return true;
    }

    /** Campo activo del propio jugador, o null. */
    @Nullable
    public static VecReflectionContext activeField(Player player) {
        for (SkillContext ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof VecReflectionContext field && !field.isTerminated() && field.started) {
                return field;
            }
        }
        return null;
    }

    /** Punto al que apunta el jugador: lo primero que toca un trazado de 20 bloques desde sus ojos. */
    static Vec3 aimPoint(ServerPlayer player, @Nullable Entity ignore) {
        Vec3 eye = player.getEyePosition();
        Vec3 far = eye.add(player.getViewVector(1.0f).scale(VecReflectionRules.AIM_RANGE));
        HitResult block = player.level().clip(
                new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = block.getType() == HitResult.Type.MISS ? far : block.getLocation();
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player.level(), player, eye, end,
                new AABB(eye, end).inflate(1.0), e -> e != ignore && SkillTargets.isTargetable(e));
        return hit == null ? end : hit.getEntity().getBoundingBox().getCenter();
    }

    public static final class VecReflectionContext extends SkillContext {
        private boolean started;
        /** Overload tras el arranque: no se deja bajar mientras el campo esté activo. */
        private float overloadFloor;
        private int reflected;

        VecReflectionContext(ServerPlayer player, VecReflectionSkill skill) {
            super(player, skill);
        }

        public boolean isStarted() {
            return started;
        }

        /** Proyectiles, golpes y rayos reflejados en esta activación (para pruebas). */
        public int reflectedCount() {
            return reflected;
        }

        private float exp() {
            return getSkillExp();
        }

        @Override
        protected void onKeyDown() {
            ServerPlayer player = getPlayer();
            CPData cp = CPData.get(player);
            float keep = VecReflectionRules.overloadKeep(exp()) * getSkill().getOverloadConsumeSpeed();
            // Decisión: rechazar si el overload fijo no cabe (el original activaba y se apagaba al instante).
            if (!canConsume(0f, VecReflectionRules.cpPerTick(exp()))
                    || (!player.isCreative()
                            && !VecReflectionRules.overloadFits(cp.getOverload(), keep, cp.getMaxOverload()))
                    || !consume(VecReflectionRules.overloadKeep(exp()), 0f)) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                terminate();
                return;
            }
            started = true;
            overloadFloor = cp.getOverload();
        }

        @Override
        protected void tick() {
            if (!started) {
                return;
            }
            ServerPlayer player = getPlayer();
            CPData.get(player).raiseOverloadTo(overloadFloor);
            if (!consume(0f, VecReflectionRules.cpPerTick(exp()))) {
                terminate();
                return;
            }
            List<Entity> targets = VecTargets.inRange(player, VecReflectionRules.RANGE);
            int done = 0;
            for (Entity entity : targets) {
                if (done++ >= VecReflectionRules.SCAN_LIMIT || isTerminated()) {
                    break;
                }
                reflectEntity(entity);
            }
            if (!isTerminated() && getTicksAlive() % VecReflectionRules.PULSE_TICKS == 0) {
                sendEffect(CHANNEL_PULSE, new CompoundTag());
            }
        }

        private void reflectEntity(Entity entity) {
            ServerPlayer player = getPlayer();
            float difficulty = VecTargets.difficulty(entity.getType());
            if (!consume(0f, VecReflectionRules.cpPerEntity(exp(), difficulty))) {
                // Sin CP no hay escudo: el proyectil sigue y el campo se apaga.
                terminate();
                return;
            }
            Vec3 pos = entity.position().add(0, entity.getBbHeight() * 0.5, 0);
            Vec3 dir = aimPoint(player, entity).subtract(pos);
            if (dir.lengthSqr() < 1e-6) {
                dir = player.getViewVector(1.0f);
            }
            dir = dir.normalize();
            if (entity instanceof ShulkerBullet) {
                // Persigue a su objetivo: devuelta volvería; se deshace sin daño.
                entity.discard();
                player.serverLevel().sendParticles(ParticleTypes.POOF, pos.x, pos.y, pos.z, 6, 0.15, 0.15, 0.15,
                        0.01);
            } else {
                double speed = entity.getDeltaMovement().length();
                if (entity instanceof Projectile projectile) {
                    projectile.shoot(dir.x, dir.y, dir.z, (float) speed, 0f);
                    // El daño pasa a ser del reflector (y no vuelve a afectarle). El tridente no: se lo quedaría.
                    if (!(projectile instanceof ThrownTrident)) {
                        projectile.setOwner(player);
                    }
                } else {
                    entity.setDeltaMovement(dir.scale(speed));
                }
                entity.hurtMarked = true;
                entity.hasImpulse = true;
                VecTargets.mark(entity);
            }
            addSkillExp(VecReflectionRules.expPerEntity(difficulty));
            reflected++;
            sendReflect(CHANNEL_REFLECT, pos, dir, new CompoundTag());
        }

        /**
         * Golpe entrante al dueño del campo. @return true si se refleja (el llamador cancela el daño entero); false
         * si entra normal (no reflejable, o sin CP: entonces el campo se apaga).
         */
        public boolean handleHit(DamageSource source, float damage) {
            ServerPlayer player = getPlayer();
            Entity attacker = source.getEntity() != null ? source.getEntity() : source.getDirectEntity();
            boolean reentrant = REFLECTING.contains(player.getUUID());
            if (reentrant || !VecReflectionRules.isReflectable(new VecReflectionRules.Hit(damage, attacker != null,
                    attacker == player, source.is(DamageTypeTags.BYPASSES_INVULNERABILITY),
                    source.is(ModDamageTypes.VEC_REFLECTION)))) {
                return false;
            }
            float exp = exp();
            if (!consume(0f, VecReflectionRules.cpPerDamage(exp, damage))) {
                terminate();
                return false;
            }
            addSkillExp(VecReflectionRules.expPerDamage(damage));
            reflected++;
            if (attacker instanceof LivingEntity living && living.isAlive()) {
                REFLECTING.add(player.getUUID());
                try {
                    VecDamage.attack(player, getSkill(), ModDamageTypes.VEC_REFLECTION, living,
                            VecReflectionRules.reflectedDamage(exp, damage));
                } finally {
                    REFLECTING.remove(player.getUUID());
                }
            }
            Vec3 at = attacker != null ? attacker.getBoundingBox().getCenter() : player.getEyePosition();
            Vec3 toAttacker = at.subtract(player.getEyePosition());
            Vec3 dir = toAttacker.lengthSqr() < 1e-6 ? player.getViewVector(1.0f) : toAttacker.normalize();
            // Onda entre el jugador y el atacante, a media altura (como el original: cerca del jugador).
            Vec3 pos = player.position().add(0, player.getBbHeight() * 0.6, 0).add(dir.scale(0.5));
            sendReflect(CHANNEL_REFLECT, pos, dir, new CompoundTag());
            return true;
        }

        /**
         * Rayo reflejable contra el dueño del campo. @return true si se refleja (el llamador cancela el evento); sin
         * CP no se refleja y el campo se apaga.
         */
        public boolean handleBeam(BeamReflectEvent event) {
            ServerPlayer player = getPlayer();
            if (!consume(0f, VecReflectionRules.cpPerDamage(exp(), event.getDamage()))) {
                terminate();
                return false;
            }
            addSkillExp(VecReflectionRules.expPerDamage(event.getDamage()));
            reflected++;
            // Contragolpe fijo del original, a nombre del reflector (respeta PvP).
            BeamReflect.Counter counter = BeamReflect.counterAttack(player, event.getCounterDamage(),
                    ModDamageTypes.VEC_REFLECTION);
            Vec3 eye = player.getEyePosition();
            Vec3 view = player.getViewVector(1.0f);
            CompoundTag extra = new CompoundTag();
            extra.putFloat(LENGTH_KEY, (float) counter.end().distanceTo(eye));
            extra.putString(BEAM_KEY, event.getSkill().getId().toString());
            Vec3 toCaster = event.getOrigin().subtract(eye);
            Vec3 pos = player.position().add(0, player.getBbHeight() * 0.6, 0)
                    .add(toCaster.lengthSqr() < 1e-6 ? Vec3.ZERO : toCaster.normalize().scale(0.5));
            sendReflect(CHANNEL_BEAM, pos, view, extra);
            return true;
        }

        private void sendReflect(String channel, Vec3 pos, Vec3 dir, CompoundTag data) {
            MagMovementSkill.writeVec(data, POS_KEY, pos);
            MagMovementSkill.writeVec(data, DIR_KEY, dir);
            sendEffect(channel, data);
        }
    }
}
