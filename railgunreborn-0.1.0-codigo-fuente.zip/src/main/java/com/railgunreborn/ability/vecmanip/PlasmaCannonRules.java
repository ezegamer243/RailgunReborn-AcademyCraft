package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Plasma Cannon ({@code docs/spec/plasma-cannon.md}; mandan las "Decisiones para el port") en
 * Java puro, para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class PlasmaCannonRules {
    /** La bola se forma hasta 15 bloques sobre los pies (menos si hay techo). */
    public static final double HEIGHT = 15.0;
    /** Alcance del trazado del destino, desde los ojos. */
    public static final double RANGE = 100.0;
    /** Bloques que avanza la bola por tick de vuelo. */
    public static final double SPEED = 1.0;
    public static final int MAX_FLIGHT_TICKS = 240;
    /** A menos de esto del destino, explota. */
    public static final double ARRIVE_DIST = 1.5;
    /** Esfera del daño directo (el único daño: la explosión vanilla no daña entidades). */
    public static final double DAMAGE_RADIUS = 10.0;
    public static final float EXP = 0.008f;
    /** Posición de la bola a los clientes cada tantos ticks de vuelo. */
    public static final int SYNC_INTERVAL = 5;
    /** Margen bajo el techo cuando la bola no cabe a la altura completa. */
    public static final double CEILING_MARGIN = 1.0;
    /** En el ser vivo apuntado, el destino es su 60 % de altura de ojos. */
    public static final double TARGET_EYE_FRACTION = 0.6;
    /** Tope de bloques que rompe la explosión en un tick; el resto se reparte en los siguientes (rendimiento). */
    public static final int MAX_BLOCKS_PER_TICK = 2048;
    /** Sonidos moderados (decisión del usuario). */
    public static final float LOOP_VOLUME = 0.45f;
    public static final float READY_VOLUME = 0.4f;
    public static final float EXPLOSION_VOLUME = 0.5f;

    private PlasmaCannonRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    /** Ticks de carga antes de poder disparar: 60 a exp 0, 30 a exp 1. */
    public static int chargeTicks(float exp) {
        return (int) Math.ceil(lerp(60f, 30f, exp) - 1e-4f);
    }

    /** CP por tick, solo durante la carga. */
    public static float cpPerTick(float exp) {
        return lerp(18f, 25f, exp);
    }

    /** Overload fijo que se suma al pulsar y se mantiene mientras dure. */
    public static float overload(float exp) {
        return lerp(500f, 400f, exp);
    }

    /** Se fija al disparar. */
    public static int cooldown(float exp) {
        return (int) lerp(1000f, 600f, exp);
    }

    /** Daño directo plano a los seres vivos de la esfera de {@link #DAMAGE_RADIUS}. */
    public static float damage(float exp) {
        return lerp(80f, 150f, exp);
    }

    /** Radio de la explosión (rompe bloques como el original). */
    public static float radius(float exp) {
        return lerp(12f, 15f, exp);
    }

    /**
     * Decisión: se rechaza al pulsar si el overload fijo no cabe (el original lo aceptaba y se apagaba solo, con el CP
     * perdido). Sobrecarga = llegar al máximo, así que tiene que quedar estrictamente por debajo.
     */
    public static boolean overloadFits(float current, float added, float max) {
        return current + added < max;
    }

    /** Decisión del usuario: exp solo si daña a algún ser vivo o rompe bloques. */
    public static float expGain(boolean hurt, boolean broke) {
        return hurt || broke ? EXP : 0f;
    }

    /** Altura de la bola sobre los pies: la completa, o bajo el techo si lo hay ({@code ceiling} = null: no hay). */
    public static double ballHeight(Double ceilingAboveFeet) {
        if (ceilingAboveFeet == null) {
            return HEIGHT;
        }
        return Math.max(0.0, Math.min(HEIGHT, ceilingAboveFeet - CEILING_MARGIN));
    }

    /** Siguiente posición: {@link #SPEED} bloques hacia {@code dest}, sin pasarse. */
    public static double[] step(double[] pos, double[] dest) {
        double dx = dest[0] - pos[0];
        double dy = dest[1] - pos[1];
        double dz = dest[2] - pos[2];
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len <= SPEED) {
            return dest.clone();
        }
        double k = SPEED / len;
        return new double[] {pos[0] + dx * k, pos[1] + dy * k, pos[2] + dz * k};
    }

    /** Si la bola ya debe explotar sin choque: cerca del destino o demasiado tiempo volando. */
    public static boolean arrived(double distanceToDest, int flightTicks) {
        return distanceToDest < ARRIVE_DIST || flightTicks >= MAX_FLIGHT_TICKS;
    }
}
