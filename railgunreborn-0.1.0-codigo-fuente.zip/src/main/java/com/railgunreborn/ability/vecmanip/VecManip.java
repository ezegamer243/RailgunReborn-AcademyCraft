package com.railgunreborn.ability.vecmanip;

import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.generic.GenericSkill;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

/**
 * Categoría Vector Manipulation y sus habilidades ({@code docs/spec/vecmanip.md}: niveles, padres y posiciones del
 * árbol).
 *
 * <p>Por ahora solo las genéricas; cada habilidad se añade en su tarea (T69-T77) respetando el orden del original:
 * dir_shock, ground_shock, vec_accel, vec_deviation, dir_blast, storm_wing, blood_retro, vec_reflection,
 * plasma_cannon; luego las genéricas. Los padres se declaran por id: mientras la habilidad padre no exista en el
 * registro, {@link Skill.Dependency#isMet} la ignora.
 */
public final class VecManip {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "vecmanip");

    /**
     * El original llama {@code setColorStyle(0, 0, 0)}, que deja el alfa en 0 (invisible). Se mantiene el tono
     * oscuro con un gris y el alfa de Teleporter (145) para que se vea: RGBA 64, 64, 64, 145.
     */
    public static final int COLOR = 0x91404040;

    public static final DeferredHolder<Category, Category> CATEGORY =
            AbilityRegistries.CATEGORIES.register(ID.getPath(), () -> new Category(COLOR, 1.0f));

    public static final DeferredHolder<Skill, DirShockSkill> DIR_SHOCK =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/dir_shock",
                    () -> new DirShockSkill(new Skill.Properties(ID, 1).guiPos(16, 45)));

    public static final ResourceLocation GROUND_SHOCK_ID = skillId("ground_shock");
    public static final DeferredHolder<Skill, GroundShockSkill> GROUND_SHOCK =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/ground_shock",
                    () -> new GroundShockSkill(new Skill.Properties(ID, 1)
                            .parent(skillId("dir_shock"), 0.0f)
                            .guiPos(64, 85)));

    public static final DeferredHolder<Skill, VecAccelSkill> VEC_ACCEL =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/vec_accel",
                    () -> new VecAccelSkill(new Skill.Properties(ID, 2).guiPos(76, 40)
                            .parent(skillId("dir_shock"), 0.0f)));

    public static final DeferredHolder<Skill, VecDeviationSkill> VEC_DEVIATION =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/vec_deviation",
                    () -> new VecDeviationSkill(new Skill.Properties(ID, 2).guiPos(145, 53)
                            .parent(skillId("vec_accel"), 0.0f)));

    // T73: Directed Blastwave (en el orden del original va tras vec_deviation).
    public static final DeferredHolder<Skill, DirBlastSkill> DIR_BLAST =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/dir_blast",
                    () -> new DirBlastSkill(new Skill.Properties(ID, 3).guiPos(136, 80)
                            .parent(skillId("ground_shock"), 0.0f)));

    // T74: Storm Wing (tras dir_blast en el orden del original).
    public static final DeferredHolder<Skill, StormWingSkill> STORM_WING =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/storm_wing",
                    () -> new StormWingSkill(new Skill.Properties(ID, 3).guiPos(130, 20)
                            .parent(skillId("vec_accel"), 0.0f)));

    // T75: Blood Retrograde (al final de las habilidades propias, justo antes de las genéricas).
    public static final DeferredHolder<Skill, BloodRetroSkill> BLOOD_RETRO =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/blood_retro",
                    () -> new BloodRetroSkill(new Skill.Properties(ID, 4).guiPos(204, 83)
                            .parent(skillId("dir_blast"), 0.0f)));

    // T76: Vector Reflection (tras blood_retro, antes de las genéricas).
    public static final DeferredHolder<Skill, VecReflectionSkill> VEC_REFLECTION =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/vec_reflection",
                    () -> new VecReflectionSkill(new Skill.Properties(ID, 4).guiPos(210, 50)
                            .parent(skillId("vec_deviation"), 0.0f)));

    // T77: Plasma Cannon (la última propia del original, justo antes de las genéricas).
    public static final DeferredHolder<Skill, PlasmaCannonSkill> PLASMA_CANNON =
            AbilityRegistries.SKILLS.register(ID.getPath() + "/plasma_cannon",
                    () -> new PlasmaCannonSkill(new Skill.Properties(ID, 5).guiPos(175, 14)
                            .parent(skillId("storm_wing"), 0.0f)));

    // Siempre después de las habilidades propias (orden estable del registro).
    public static final Map<GenericRules.Kind, DeferredHolder<Skill, GenericSkill>> GENERICS =
            GenericSkill.registerFor(AbilityRegistries.SKILLS, ID);

    private VecManip() {
    }

    public static ResourceLocation skillId(String name) {
        return ID.withPath(p -> p + "/" + name);
    }

    /** Solo fuerza la carga de la clase (y con ella el registro de las entradas de arriba). */
    public static void init() {
    }
}
