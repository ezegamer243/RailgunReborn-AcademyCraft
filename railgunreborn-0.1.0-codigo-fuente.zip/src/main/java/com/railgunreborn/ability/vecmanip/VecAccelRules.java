package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Vector Acceleration ({@code docs/spec/vec-accel.md}) en Java puro, para probarlos con JUnit.
 * {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class VecAccelRules {
    public static final int MAX_CHARGE = 20;
    /** Factor del seno: el máximo real es {@code sin(1) * 2.5 = 2.10} bloques por tick. */
    public static final double MAX_VELOCITY = 2.5;
    /** Grados extra hacia arriba sobre la mirada. */
    public static final float PITCH_BIAS = 10f;
    /** Bloques bajo los pies en los que debe haber un bloque no-aire (con exp baja). */
    public static final double GROUND_REACH = 2.0;
    public static final float EXP = 0.002f;
    /** Por encima de esta exp se puede usar en el aire. */
    public static final float AIR_EXP = 0.5f;
    /** Ventana máxima de protección de caída tras el impulso. */
    public static final int FALL_GUARD_TICKS = 100;
    public static final float SOUND_VOLUME = 0.5f;

    private VecAccelRules() {
    }

    static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static float cp(float exp) {
        return lerp(120f, 80f, exp);
    }

    public static float overload(float exp) {
        return lerp(30f, 15f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(80f, 50f, exp);
    }

    /** Carga válida: los ticks mantenidos, limitados a {@link #MAX_CHARGE}. */
    public static int charge(int heldTicks) {
        return Math.clamp(heldTicks, 0, MAX_CHARGE);
    }

    /** Velocidad del impulso en bloques por tick para una carga en ticks. */
    public static double speed(int charge) {
        double t = charge(charge) / (double) MAX_CHARGE;
        return Math.sin(0.4 + (1.0 - 0.4) * t) * MAX_VELOCITY;
    }

    public static boolean canUseInAir(float exp) {
        return exp > AIR_EXP;
    }

    /** Con exp alta siempre; con exp baja solo con bloque a ≤ 2 bajo los pies. */
    public static boolean canUse(float exp, boolean blockBelow) {
        return canUseInAir(exp) || blockBelow;
    }

    /**
     * Dirección unitaria de la mirada con el pitch {@link #PITCH_BIAS} grados más arriba (convención de Minecraft:
     * pitch negativo = arriba).
     */
    public static double[] direction(float yawDeg, float pitchDeg) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg - PITCH_BIAS);
        double cos = Math.cos(pitch);
        return new double[] {-Math.sin(yaw) * cos, -Math.sin(pitch), Math.cos(yaw) * cos};
    }
}
