package com.railgunreborn.ability.vecmanip;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.common.BeamReflectEvent;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * Vector Reflection en el bus del juego (solo servidor). Solo actúa sobre jugadores con su propio campo activo, así
 * que no choca con otros escuchas de {@link BeamReflectEvent} (los eventos ya cancelados no le llegan).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class VecReflectionEvents {
    /** Ticks de invulnerabilidad tras un golpe: en la primera mitad el juego ignora golpes iguales o menores. */
    private static final int INVULNERABLE_HALF = 10;

    private VecReflectionEvents() {
    }

    /**
     * Antes de armadura, escudo e invulnerabilidad (el {@code LivingAttackEvent} del original): un golpe reflejado se
     * cancela entero, sin daño ni empuje.
     */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        VecReflectionSkill.VecReflectionContext field = VecReflectionSkill.activeField(player);
        if (field == null) {
            return;
        }
        // Este evento llega antes de la comprobación de invulnerabilidad: no cobrar golpes que el juego ignoraría.
        if (player.invulnerableTime > INVULNERABLE_HALF && !event.getSource().is(DamageTypeTags.BYPASSES_COOLDOWN)) {
            return;
        }
        if (field.handleHit(event.getSource(), event.getAmount())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onBeamReflect(BeamReflectEvent event) {
        VecReflectionSkill.VecReflectionContext field = VecReflectionSkill.activeField(event.getTarget());
        if (field != null && field.handleBeam(event)) {
            event.setCanceled(true);
        }
    }
}
