package com.railgunreborn.ability.vecmanip;

import java.util.ArrayList;
import java.util.List;

/**
 * Números y decisiones de Directed Blastwave ({@code docs/spec/dir-blast.md}, decisiones del 2026-10-09) en Java
 * puro, para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class DirBlastRules {
    /** Se acepta mantener más de {@code MIN_TICKS} y menos de {@code MAX_TICKS} (7..49), igual que Directed Shock. */
    public static final int MIN_TICKS = 6;
    public static final int MAX_TICKS = 50;
    /** Tolerancia del servidor sobre la cuenta del cliente (la misma que Directed Shock). */
    public static final int TOLERANCE_TICKS = DirShockRules.TOLERANCE_TICKS;
    /** Sin soltar, el contexto termina solo. */
    public static final int TIMEOUT_TICKS = 200;
    /** Alcance del trazado desde los ojos. */
    public static final double TARGET_RANGE = 4.0;
    /** Radio de la esfera de daño alrededor del punto de impacto. */
    public static final double DAMAGE_RADIUS = 3.0;
    /** Casillas a distancia² ≤ 6 del bloque central (81 casillas). */
    public static final int CELL_DIST_SQ = 6;
    /** Empuje fuerte (decisión del usuario) y elevación de la dirección antes de normalizar. */
    public static final double PUSH = 1.2;
    public static final double LOFT = 0.4;
    /** Subida inmediata de la entidad para que el empuje no se pierda contra el suelo. */
    public static final double LIFT = 0.1;
    public static final float EXP_HIT = 0.0025f;
    public static final float EXP_BLOCKS_ONLY = 0.0012f;
    public static final float SOUND_VOLUME = 0.5f;
    /** Casillas rotas con partículas (además de la central, que lleva sonido): pocas, para no saturar. */
    public static final int MAX_PARTICLE_CELLS = 6;

    private DirBlastRules() {
    }

    public static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static float cp(float exp) {
        return lerp(160f, 200f, exp);
    }

    public static float overload(float exp) {
        return lerp(50f, 30f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(80f, 50f, exp);
    }

    /** Daño base, antes de {@code damage_scale}. */
    public static float damage(float exp) {
        return lerp(10f, 25f, exp);
    }

    /** Probabilidad de evaluar cada casilla que no es la central (la central siempre). */
    public static double breakProb(float exp) {
        return lerp(0.5f, 0.8f, exp);
    }

    /** Dureza máxima que rompe, por tramos de exp. */
    public static float hardnessLimit(float exp) {
        if (exp < 0.25f) {
            return 2.9f;
        }
        return exp < 0.5f ? 25f : 55f;
    }

    /** Irrompibles (dureza negativa) nunca; el resto hasta el umbral. */
    public static boolean canBreak(float hardness, float exp) {
        return hardness >= 0f && hardness <= hardnessLimit(exp);
    }

    /** A exp 1 suelta el bloque en sí (como con toque de seda); antes, su botín normal (siempre, sin tirada). */
    public static boolean dropsBlockItself(float exp) {
        return exp >= 1f;
    }

    /** Ventana exacta del cliente: 7 a 49 ticks. */
    public static boolean holdAccepted(int ticks) {
        return ticks > MIN_TICKS && ticks < MAX_TICKS;
    }

    /** Ventana del servidor: la del cliente ampliada por la tolerancia. */
    public static boolean serverHoldAccepted(int ticks) {
        return ticks > MIN_TICKS - TOLERANCE_TICKS && ticks < MAX_TICKS + TOLERANCE_TICKS;
    }

    /** Exp: con daño efectivo a un ser vivo, 0.0025; si solo rompió bloques, 0.0012; al aire, nada. */
    public static float expGain(boolean hurtSomething, boolean brokeBlocks) {
        if (hurtSomething) {
            return EXP_HIT;
        }
        return brokeBlocks ? EXP_BLOCKS_ONLY : 0f;
    }

    /** Desplazamientos {x, y, z} de las 81 casillas a distancia² ≤ 6; la central (0, 0, 0) es la primera. */
    public static List<int[]> cells() {
        List<int[]> cells = new ArrayList<>();
        cells.add(new int[] {0, 0, 0});
        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    if ((x != 0 || y != 0 || z != 0) && x * x + y * y + z * z <= CELL_DIST_SQ) {
                        cells.add(new int[] {x, y, z});
                    }
                }
            }
        }
        return cells;
    }

    /**
     * Velocidad del empuje fuerte: hacia fuera del centro de impacto en horizontal, algo hacia arriba, módulo
     * {@link #PUSH}. Si la entidad está justo en el centro (la golpeada directamente), sale en la dirección horizontal
     * de la mirada. Sustituye a la velocidad que tuviera (una sola escritura: no se pisa con otro empuje).
     *
     * @return la nueva velocidad {x, y, z}
     */
    public static double[] knockback(double centerX, double centerZ, double entityX, double entityZ, double lookX,
            double lookZ) {
        double hx = entityX - centerX;
        double hz = entityZ - centerZ;
        double h = Math.sqrt(hx * hx + hz * hz);
        if (h < 0.5) {
            hx = lookX;
            hz = lookZ;
            h = Math.sqrt(hx * hx + hz * hz);
        }
        if (h < 1.0e-6) {
            return new double[] {0, PUSH, 0};
        }
        hx /= h;
        hz /= h;
        double length = Math.sqrt(1 + LOFT * LOFT);
        return new double[] {hx / length * PUSH, LOFT / length * PUSH, hz / length * PUSH};
    }
}
