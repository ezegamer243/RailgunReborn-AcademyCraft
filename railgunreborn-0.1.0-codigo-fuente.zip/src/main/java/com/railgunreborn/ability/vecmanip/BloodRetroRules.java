package com.railgunreborn.ability.vecmanip;

/**
 * Números y decisiones de Blood Retrograde ({@code docs/spec/blood-retro.md}, decisiones del 2026-10-09) en Java puro,
 * para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class BloodRetroRules {
    /** Alcance del trazado desde los ojos (la caja del objetivo se agranda {@link #HITBOX_INFLATE}: ~2.3 reales). */
    public static final double REACH = 2.0;
    public static final double HITBOX_INFLATE = 0.3;
    /** A los 30 ticks (1.5 s) se suelta sola. */
    public static final int AUTO_RELEASE_TICKS = 30;
    /** La ralentización llega a su máximo en 20 ticks. */
    public static final int SLOW_TICKS = 20;
    /** Velocidad que queda al final de la ralentización (0.007 de 0.1 en el original). */
    public static final double MIN_SPEED_RATIO = 0.07;
    public static final float EXP = 0.002f;
    public static final float SOUND_VOLUME = 0.5f;
    /** Salpicaduras de sangre (decisión: 4-6 de 0.7-1.1 en vez de 6-9 de 1.4-1.8). */
    public static final int BLOOD_MIN = 4;
    public static final int BLOOD_MAX = 6;
    public static final float BLOOD_SIZE_MIN = 0.7f;
    public static final float BLOOD_SIZE_MAX = 1.1f;

    private BloodRetroRules() {
    }

    public static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static float cp(float exp) {
        return lerp(280f, 350f, exp);
    }

    public static float overload(float exp) {
        return lerp(55f, 40f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(90f, 40f, exp);
    }

    /** Daño base, antes de {@code damage_scale}. */
    public static float damage(float exp) {
        return lerp(30f, 60f, exp);
    }

    /** Importe del modificador {@code ADD_MULTIPLIED_TOTAL} tras {@code ticks} ticks de mantener: de 0 a -0.93. */
    public static double slowAmount(int ticks) {
        double t = Math.min(Math.max(ticks, 0), SLOW_TICKS) / (double) SLOW_TICKS;
        return -(1.0 - MIN_SPEED_RATIO) * t;
    }

    /** Si el servidor suelta solo con esta cuenta de ticks mantenidos. */
    public static boolean autoReleases(int heldTicks) {
        return heldTicks >= AUTO_RELEASE_TICKS;
    }
}
