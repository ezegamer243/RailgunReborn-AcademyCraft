package com.railgunreborn.ability.vecmanip;

import java.util.function.DoubleSupplier;

import javax.annotation.Nullable;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BlockPermissions;
import com.railgunreborn.ability.common.SkillTargets;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Directed Blastwave: mantener entre 7 y 49 ticks y soltar para golpear un punto a ≤ 4 bloques en la mirada. Daña
 * y empuja con fuerza a los seres vivos en una esfera de 3 bloques y rompe bloques en una esfera pequeña (con su
 * botín, siempre). Ficha: {@code docs/spec/dir-blast.md} (mandan las decisiones del final). Números en
 * {@link DirBlastRules}.
 *
 * <p>Los bloques solo se rompen con {@link BlockPermissions#mayModifyWorld} y permiso por casilla; nunca bloques con
 * inventario u otra {@code BlockEntity}, líquidos, irrompibles ni los que pisa el jugador.
 */
public class DirBlastSkill extends Skill {
    /** Canal {@code blast}: {@link #POINT_KEY} = punto de impacto, {@link #DIR_KEY} = mirada del lanzador. */
    public static final String CHANNEL_BLAST = "blast";
    public static final String POINT_KEY = "point";
    public static final String DIR_KEY = "dir";

    /** Solo para GameTests: sustituye a las tiradas de rotura ({@code null} = aleatorio del jugador). */
    @Nullable
    public static volatile DoubleSupplier rollOverride;

    public DirBlastSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new DirBlastContext(player, this);
    }

    /** Si la onda puede quitar este bloque (además de dureza y permisos). */
    static boolean removable(BlockState state) {
        return !state.isAir() && !state.hasBlockEntity() && !state.liquid() && state.getFluidState().isEmpty();
    }

    private static final class DirBlastContext extends SkillContext {
        private final float exp;

        DirBlastContext(ServerPlayer player, DirBlastSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        private double roll() {
            DoubleSupplier override = rollOverride;
            return override != null ? override.getAsDouble() : getPlayer().getRandom().nextDouble();
        }

        @Override
        protected void tick() {
            if (getTicksAlive() >= DirBlastRules.TIMEOUT_TICKS) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            // El servidor cuenta sus propios ticks (el cliente no es de fiar).
            if (DirBlastRules.serverHoldAccepted(getTicksAlive())) {
                blast();
            }
            terminate();
        }

        private void blast() {
            ServerPlayer player = getPlayer();
            if (!consume(DirBlastRules.overload(exp), DirBlastRules.cp(exp))) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return;
            }
            setCooldown(DirBlastRules.cooldownTicks(exp));
            player.swing(InteractionHand.MAIN_HAND, true);

            ServerLevel level = player.serverLevel();
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getViewVector(1.0f);
            Vec3 end = eye.add(look.scale(DirBlastRules.TARGET_RANGE));
            Entity target = ElectronBombSkill.traceRay(player, eye, end).entity();
            BlockHitResult blockHit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player));
            Vec3 point;
            BlockPos center;
            if (target != null) {
                point = target.getEyePosition();
                center = BlockPos.containing(point);
            } else if (blockHit.getType() == HitResult.Type.BLOCK) {
                center = blockHit.getBlockPos();
                point = Vec3.atCenterOf(center);
            } else {
                point = end;
                center = BlockPos.containing(point);
            }

            boolean hurt = hitEntities(player, level, point, look);
            boolean broke = breakBlocks(player, level, center);
            float gain = DirBlastRules.expGain(hurt, broke);
            if (gain > 0f) {
                addSkillExp(gain);
            }

            CompoundTag data = new CompoundTag();
            data.put(POINT_KEY, vec(point));
            data.put(DIR_KEY, vec(look));
            sendEffect(CHANNEL_BLAST, data);
        }

        /** @return si algún ser vivo recibió daño de verdad */
        private boolean hitEntities(ServerPlayer player, ServerLevel level, Vec3 point, Vec3 look) {
            double radius = DirBlastRules.DAMAGE_RADIUS;
            AABB search = new AABB(point, point).inflate(radius);
            boolean hurt = false;
            for (Entity entity : level.getEntities(player, search, SkillTargets::isTargetable)) {
                if (!SkillTargets.mayHarm(player, entity, VecDamage.ATTACK_PLAYER)
                        || nearestDistanceSq(entity.getBoundingBox(), point) > radius * radius) {
                    continue;
                }
                if (VecDamage.attack(player, getSkill(), ModDamageTypes.DIR_BLAST, entity,
                        DirBlastRules.damage(exp))) {
                    hurt = true;
                }
                // Tras el daño (que mete su propio retroceso): una sola escritura de la velocidad.
                double[] v = DirBlastRules.knockback(point.x, point.z, entity.getX(), entity.getZ(), look.x, look.z);
                entity.setPos(entity.getX(), entity.getY() + DirBlastRules.LIFT, entity.getZ());
                entity.setDeltaMovement(v[0], v[1], v[2]);
                entity.hurtMarked = true;
            }
            return hurt;
        }

        private static double nearestDistanceSq(AABB box, Vec3 p) {
            double x = Mth.clamp(p.x, box.minX, box.maxX);
            double y = Mth.clamp(p.y, box.minY, box.maxY);
            double z = Mth.clamp(p.z, box.minZ, box.maxZ);
            return p.distanceToSqr(x, y, z);
        }

        /** @return si se rompió al menos un bloque */
        private boolean breakBlocks(ServerPlayer player, ServerLevel level, BlockPos center) {
            if (!BlockPermissions.mayModifyWorld(player, getSkill())) {
                return false;
            }
            double prob = DirBlastRules.breakProb(exp);
            AABB feet = player.getBoundingBox();
            int broken = 0;
            boolean first = true;
            for (int[] offset : DirBlastRules.cells()) {
                boolean isCenter = first;
                first = false;
                if (!isCenter && roll() >= prob) {
                    continue;
                }
                BlockPos pos = center.offset(offset[0], offset[1], offset[2]);
                if (underFeet(feet, pos)) {
                    continue;
                }
                BlockState state = level.getBlockState(pos);
                if (!removable(state) || !DirBlastRules.canBreak(state.getDestroySpeed(level, pos), exp)
                        || !BlockPermissions.mayBreakAt(player, pos, state)) {
                    continue;
                }
                drop(level, pos, state, player);
                if (broken == 0) {
                    // Un solo sonido de rotura (con sus partículas) por golpe: sonidos moderados.
                    level.levelEvent(LevelEvent.PARTICLES_DESTROY_BLOCK, pos, Block.getId(state));
                } else if (broken <= DirBlastRules.MAX_PARTICLE_CELLS) {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), pos.getX() + 0.5,
                            pos.getY() + 0.5, pos.getZ() + 0.5, 12, 0.3, 0.3, 0.3, 0.05);
                }
                level.removeBlock(pos, false);
                broken++;
            }
            return broken > 0;
        }

        private void drop(ServerLevel level, BlockPos pos, BlockState state, ServerPlayer player) {
            if (DirBlastRules.dropsBlockItself(exp)) {
                ItemStack self = new ItemStack(state.getBlock().asItem());
                if (!self.isEmpty()) {
                    Block.popResource(level, pos, self);
                    return;
                }
            }
            Block.dropResources(state, level, pos, null, player, ItemStack.EMPTY);
        }

        /** Las casillas que sostienen al jugador (la fila de debajo de sus pies) no se rompen. */
        private static boolean underFeet(AABB feet, BlockPos pos) {
            int below = Mth.floor(feet.minY - 1.0e-3);
            return pos.getY() == below
                    && pos.getX() >= Mth.floor(feet.minX) && pos.getX() <= Mth.floor(feet.maxX - 1.0e-7)
                    && pos.getZ() >= Mth.floor(feet.minZ) && pos.getZ() <= Mth.floor(feet.maxZ - 1.0e-7);
        }

        private static CompoundTag vec(Vec3 v) {
            CompoundTag tag = new CompoundTag();
            tag.putDouble("x", v.x);
            tag.putDouble("y", v.y);
            tag.putDouble("z", v.z);
            return tag;
        }
    }
}
