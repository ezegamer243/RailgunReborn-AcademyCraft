package com.railgunreborn.ability.vecmanip;

import java.util.ArrayList;
import java.util.List;

/**
 * Números y geometría de Ground Shock ({@code docs/spec/ground-shock.md}, §2-§8 y decisiones del 2026-10-09), en
 * Java puro para probarlos con JUnit. {@code exp} es la exp de la habilidad en [0, 1] leída al pulsar.
 */
public final class GroundShockRules {
    /** Ticks mínimos mantenidos; con menos, soltar no hace nada ni cobra. */
    public static final int MIN_HOLD_TICKS = 5;
    /** Desplazamientos laterales de las 5 casillas de cada paso y su probabilidad (central, ±1, ±2). */
    public static final int[] LATERAL_OFFSETS = {0, -1, 1, -2, 2};
    public static final double[] LATERAL_PROBS = {1.0, 0.7, 0.7, 0.3, 0.3};
    /** Probabilidad, por casilla procesada, de romper el suelo de la casilla central del paso. */
    public static final double GROUND_BREAK_PROB = 0.3;
    /** Energía gastada por cada ser vivo alcanzado. */
    public static final double ENTITY_ENERGY = 1.0;
    /** Alturas (sobre el suelo central) de la columna que la onda intenta despejar. */
    public static final int COLUMN_HEIGHT = 3;
    public static final float EXP_USE = 0.001f;
    public static final float EXP_PER_HIT = 0.002f;
    /** Barrido de exp 1: dureza máxima y caja (x, z de -5 a +4; y del suelo a los pies). */
    public static final float SWEEP_MAX_HARDNESS = 0.6f;
    public static final int SWEEP_MIN = -5;
    public static final int SWEEP_MAX = 4;
    /** Volumen de {@code vecmanip.groundshock} (2.0 en el original; decisión: 0.7). */
    public static final float SOUND_VOLUME = 0.7f;
    /** Tope de casillas que se mandan al cliente para los efectos. */
    public static final int MAX_EFFECT_CELLS = 150;
    /** Tope de bocanadas de humo por disparo (decisión: humo reducido) y su probabilidad por casilla. */
    public static final int MAX_SMOKE = 40;
    public static final double SMOKE_PROB = 0.5;
    /** Debajo de esto la mirada es (casi) vertical y no hay dirección horizontal: no se dispara. */
    public static final double MIN_HORIZONTAL = 1e-3;

    private GroundShockRules() {
    }

    /** Lo que pasa con una casilla de suelo procesada. */
    public enum Ground {
        /** Piedra y variantes → adoquín. */
        STONE(0.4),
        /** Césped, podzol, micelio → tierra. */
        GRASS(0.2),
        /** Tierra de cultivo: no cambia. */
        FARMLAND(0.1),
        /** Cualquier otro: no cambia. */
        OTHER(0.5);

        public final double energyCost;

        Ground(double energyCost) {
            this.energyCost = energyCost;
        }
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float cp(float exp) {
        return lerp(80f, 150f, exp);
    }

    public static float overload(float exp) {
        return lerp(15f, 10f, exp);
    }

    public static int cooldownTicks(float exp) {
        return (int) lerp(80f, 40f, exp);
    }

    public static int maxSteps(float exp) {
        return (int) lerp(10f, 25f, exp);
    }

    public static double initialEnergy(float exp) {
        return lerp(60f, 120f, exp);
    }

    public static float damage(float exp) {
        return lerp(4f, 6f, exp);
    }

    /** Velocidad vertical común a todos los alcanzados; {@code roll} en [0, 1). */
    public static double launchSpeed(float exp, double roll) {
        return (0.6 + 0.3 * roll) * lerp(0.8f, 1.3f, exp);
    }

    /** El barrido 10×10 solo existe con la exp al máximo. */
    public static boolean sweepActive(float exp) {
        return exp >= 1.0f;
    }

    public static boolean holdLongEnough(int ticksHeld) {
        return ticksHeld >= MIN_HOLD_TICKS;
    }

    /** Si la columna se puede romper con la energía que queda (dureza negativa = irrompible). */
    public static boolean canBreak(double energy, float hardness) {
        return hardness >= 0f && energy >= hardness;
    }

    /** Desplazamiento horizontal (x, z) en bloques. */
    public record Offset(int x, int z) {
    }

    /**
     * Línea por la rejilla a altura constante (el {@code Plotter} del original): un paso por casilla sobre el eje
     * dominante de {@code (dx, dz)}, el otro redondeado. Devuelve los pasos 1..{@code steps} (el 0 es la casilla de
     * los pies). Vacía si la dirección es (casi) vertical.
     */
    public static List<Offset> line(double dx, double dz, int steps) {
        List<Offset> out = new ArrayList<>(Math.max(steps, 0));
        double ax = Math.abs(dx);
        double az = Math.abs(dz);
        if (Math.max(ax, az) < MIN_HORIZONTAL) {
            return out;
        }
        for (int i = 1; i <= steps; i++) {
            if (ax >= az) {
                out.add(new Offset((int) Math.signum(dx) * i, (int) Math.round(i * dz / ax)));
            } else {
                out.add(new Offset((int) Math.round(i * dx / az), (int) Math.signum(dz) * i));
            }
        }
        return out;
    }

    /** Desplazamiento de la casilla lateral {@code k} (perpendicular a la dirección horizontal). */
    public static Offset lateral(double dx, double dz, int k) {
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < MIN_HORIZONTAL || k == 0) {
            return new Offset(0, 0);
        }
        double px = -dz / len;
        double pz = dx / len;
        return new Offset((int) Math.round(k * px), (int) Math.round(k * pz));
    }

    /**
     * Si la casilla es uno de los bloques sobre los que pisa el jugador (fila bajo los pies y dentro de su huella
     * horizontal): la decisión del usuario es no quitarlos nunca.
     */
    public static boolean underFeet(int x, int y, int z, int groundY, double minX, double maxX, double minZ,
            double maxZ) {
        return y == groundY
                && x >= (int) Math.floor(minX) && x <= (int) Math.floor(maxX - 1e-6)
                && z >= (int) Math.floor(minZ) && z <= (int) Math.floor(maxZ - 1e-6);
    }
}
