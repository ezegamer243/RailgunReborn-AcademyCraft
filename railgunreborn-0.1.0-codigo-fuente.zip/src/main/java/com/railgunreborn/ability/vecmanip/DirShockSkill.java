package com.railgunreborn.ability.vecmanip;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Directed Shock: mantener entre 7 y 49 ticks y soltar para dar un puñetazo potenciado al ser vivo mirado a ≤ 3
 * bloques. Se cobra al soltar aunque no haya objetivo y el cooldown se pone siempre; la exp y el empuje solo con
 * impacto efectivo. Ficha: {@code docs/spec/dir-shock.md}.
 */
public class DirShockSkill extends Skill {
    /** Canal {@code hit}: {@link #TARGET_KEY} = id de entidad del golpeado. */
    public static final String CHANNEL_HIT = "hit";
    public static final String TARGET_KEY = "target";

    public DirShockSkill(Properties props) {
        super(props);
    }

    @Override
    public SkillContext createContext(ServerPlayer player) {
        return new DirShockContext(player, this);
    }

    private static final class DirShockContext extends SkillContext {
        private final float exp;

        DirShockContext(ServerPlayer player, DirShockSkill skill) {
            super(player, skill);
            this.exp = getSkillExp();
        }

        @Override
        protected void tick() {
            if (getTicksAlive() >= DirShockRules.TIMEOUT_TICKS) {
                terminate();
            }
        }

        @Override
        protected void onKeyUp() {
            // El servidor cuenta sus propios ticks (el cliente no es de fiar).
            if (DirShockRules.serverHoldAccepted(getTicksAlive())) {
                punch();
            }
            terminate();
        }

        private void punch() {
            ServerPlayer player = getPlayer();
            float cp = DirShockRules.cp(exp);
            float overload = DirShockRules.overload(exp);
            if (!consume(overload, cp)) {
                player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
                return;
            }
            setCooldown(DirShockRules.cooldownTicks(exp));
            player.swing(InteractionHand.MAIN_HAND, true);

            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0f).scale(DirShockRules.REACH));
            Entity target = ElectronBombSkill.traceRay(player, eye, end).entity();
            if (target == null || !VecDamage.attack(player, getSkill(), ModDamageTypes.DIR_SHOCK, target,
                    DirShockRules.damage(exp))) {
                return;
            }
            push(player, target);
            addSkillExp(DirShockRules.EXP_HIT);

            CompoundTag data = new CompoundTag();
            data.putInt(TARGET_KEY, target.getId());
            sendEffect(CHANNEL_HIT, data);
        }

        private void push(ServerPlayer player, Entity target) {
            Vec3 current = target.getDeltaMovement();
            double[] velocity = DirShockRules.knockbackVelocity(vec(player.getEyePosition()),
                    vec(target.getEyePosition()), vec(player.position()), vec(target.position()),
                    new double[] {current.x, current.y, current.z}, exp);
            if (DirShockRules.knockbackEnabled(exp)) {
                target.setPos(target.getX(), target.getY() + DirShockRules.LIFT, target.getZ());
            }
            target.setDeltaMovement(velocity[0], velocity[1], velocity[2]);
            target.hurtMarked = true;
        }

        private static double[] vec(Vec3 v) {
            return new double[] {v.x, v.y, v.z};
        }
    }
}
