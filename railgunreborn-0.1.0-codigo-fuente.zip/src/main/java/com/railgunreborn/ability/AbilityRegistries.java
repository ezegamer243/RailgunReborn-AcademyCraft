package com.railgunreborn.ability;

import java.util.Optional;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.vecmanip.VecManip;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registros propios de categorías ({@code railgunreborn:category}) y habilidades ({@code railgunreborn:skill}).
 *
 * <p>Se crean con {@link DeferredRegister#makeRegistry}: es la forma idiomática en NeoForge 1.21.1 cuando el mismo
 * mod crea el registro y registra entradas en él (por dentro añade el registro en {@code NewRegistryEvent}).
 * {@code sync(true)}: el cliente recibe los ids del servidor, así T10 puede mandar habilidades por red con
 * {@code ByteBufCodecs.registry(SKILL_KEY)} sin depender del orden de carga.
 *
 * <p>Ids: categorías {@code railgunreborn:<categoría>}, habilidades {@code railgunreborn:<categoría>/<habilidad>}
 * (la convención que ya usan los comandos y {@code AbilityData}).
 */
public final class AbilityRegistries {
    public static final ResourceKey<Registry<Category>> CATEGORY_KEY =
            ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "category"));
    public static final ResourceKey<Registry<Skill>> SKILL_KEY =
            ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "skill"));

    public static final DeferredRegister<Category> CATEGORIES =
            DeferredRegister.create(CATEGORY_KEY, RailgunReborn.MODID);
    public static final DeferredRegister<Skill> SKILLS = DeferredRegister.create(SKILL_KEY, RailgunReborn.MODID);

    public static final Registry<Category> CATEGORY_REGISTRY = CATEGORIES.makeRegistry(builder -> builder.sync(true));
    public static final Registry<Skill> SKILL_REGISTRY = SKILLS.makeRegistry(builder -> builder.sync(true));

    private AbilityRegistries() {
    }

    public static void register(IEventBus modEventBus) {
        // Carga las clases que llaman a CATEGORIES/SKILLS.register antes de enganchar los DeferredRegister.
        Electromaster.init();
        Meltdowner.init();
        Teleporter.init();
        VecManip.init();
        CATEGORIES.register(modEventBus);
        SKILLS.register(modEventBus);
    }

    public static Optional<Category> category(@Nullable ResourceLocation id) {
        return id == null ? Optional.empty() : Optional.ofNullable(CATEGORY_REGISTRY.get(id));
    }

    public static Optional<Skill> skill(@Nullable ResourceLocation id) {
        return id == null ? Optional.empty() : Optional.ofNullable(SKILL_REGISTRY.get(id));
    }
}
