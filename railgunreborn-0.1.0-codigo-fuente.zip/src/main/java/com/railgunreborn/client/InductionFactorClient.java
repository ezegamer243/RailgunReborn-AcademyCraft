package com.railgunreborn.client;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.registry.ModItems;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Textura del Induction Factor por categoría: el modelo {@code induction_factor} elige con el predicado
 * {@code railgunreborn:factor_category} (1..4 según esta lista; 0 = sin categoría o desconocida).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class InductionFactorClient {
    private static final List<String> TEXTURED = List.of("electromaster", "meltdowner", "teleporter", "vecmanip");

    private InductionFactorClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> ItemProperties.register(ModItems.INDUCTION_FACTOR.get(),
                ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "factor_category"),
                (stack, level, entity, seed) -> InductionFactorItem.categoryOf(stack)
                        .map(c -> TEXTURED.indexOf(c.getPath()) + 1).orElse(0)));
    }
}
