package com.railgunreborn.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.screen.wireless.MatrixScreen;
import com.railgunreborn.client.screen.wireless.NodeLinkScreen;
import com.railgunreborn.client.screen.wireless.NodeScreen;
import com.railgunreborn.wireless.WirelessRegistry;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Cliente de la red inalámbrica (bus del MOD): pantallas de matriz, nodo y "Current Node", y escudos de la matriz. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class WirelessClient {
    private WirelessClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(WirelessRegistry.MATRIX_MENU.get(), MatrixScreen::new);
        event.register(WirelessRegistry.NODE_MENU.get(), NodeScreen::new);
        event.register(WirelessRegistry.NODE_LINK_MENU.get(), NodeLinkScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(WirelessRegistry.MATRIX_BE.get(), MatrixRenderer::new);
    }

    @SubscribeEvent
    public static void registerModels(ModelEvent.RegisterAdditional event) {
        event.register(MatrixRenderer.SHIELD_MODEL);
    }
}
