package com.railgunreborn.client.entity;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.entity.CoinEntity;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Dibuja la moneda girando junto a la mano derecha del dueño: una cara con {@code coin.png} y la otra con
 * {@code coin_back.png}. Sin animación del pulgar en primera persona (el original tampoco la tiene).
 */
public class CoinRenderer extends EntityRenderer<CoinEntity> {
    private static final ResourceLocation FRONT = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/item/coin.png");
    private static final ResourceLocation BACK = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/item/coin_back.png");
    private static final float HALF = 0.2f;

    public CoinRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(CoinEntity coin, Frustum frustum, double x, double y, double z) {
        return coin.isFlying();
    }

    @Override
    public void render(CoinEntity coin, float yaw, float partialTick, PoseStack poseStack,
            MultiBufferSource buffer, int packedLight) {
        if (!coin.isFlying()) {
            return;
        }
        poseStack.pushPose();
        Player owner = coin.getOwner();
        if (owner != null) {
            // X/Z del dueño interpolada (evita tirones con el jugador local) y desplazada hacia su mano derecha.
            Vec3 ownerPos = owner.getPosition(partialTick);
            Vec3 coinPos = coin.getPosition(partialTick);
            float yawRad = Mth.rotLerp(partialTick, owner.yRotO, owner.getYRot()) * Mth.DEG_TO_RAD;
            double forwardX = -Mth.sin(yawRad);
            double forwardZ = Mth.cos(yawRad);
            double rightX = -forwardZ;
            double rightZ = forwardX;
            poseStack.translate(ownerPos.x - coinPos.x + rightX * 0.4 + forwardX * 0.35, 0,
                    ownerPos.z - coinPos.z + rightZ * 0.4 + forwardZ * 0.35);
        }
        RandomSource random = RandomSource.create(coin.getId());
        float ax = 0.1f + random.nextFloat();
        float ay = random.nextFloat();
        float az = random.nextFloat();
        // Media vuelta cada 150 ms (3 ticks) como el original: 60 grados por tick.
        float angle = (coin.getAge() + partialTick) * 60f * Mth.DEG_TO_RAD;
        poseStack.mulPose(new Quaternionf().rotationAxis(angle, ax, ay, az));

        PoseStack.Pose pose = poseStack.last();
        quad(buffer.getBuffer(RenderType.entityCutoutNoCull(FRONT)), pose, packedLight, 0.01f, false);
        quad(buffer.getBuffer(RenderType.entityCutoutNoCull(BACK)), pose, packedLight, -0.01f, true);
        poseStack.popPose();
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light, float z, boolean flip) {
        float nz = flip ? -1f : 1f;
        float u0 = flip ? 1f : 0f;
        float u1 = flip ? 0f : 1f;
        vertex(vc, pose, -HALF, -HALF, z, u0, 1f, nz, light);
        vertex(vc, pose, HALF, -HALF, z, u1, 1f, nz, light);
        vertex(vc, pose, HALF, HALF, z, u1, 0f, nz, light);
        vertex(vc, pose, -HALF, HALF, z, u0, 0f, nz, light);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v,
            float nz, int light) {
        vc.addVertex(pose, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, 0f, 0f, nz);
    }

    @Override
    public ResourceLocation getTextureLocation(CoinEntity coin) {
        return FRONT;
    }
}
