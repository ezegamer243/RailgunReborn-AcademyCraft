package com.railgunreborn.client.entity;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModEntities;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class EntityRenderers {
    private EntityRenderers() {
    }

    @SubscribeEvent
    public static void register(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.COIN.get(), CoinRenderer::new);
        event.registerEntityRenderer(ModEntities.SILBARN.get(), SilbarnRenderer::new);
        event.registerEntityRenderer(ModEntities.MAGNETIC_BLOCK.get(), MagneticBlockRenderer::new);
    }
}
