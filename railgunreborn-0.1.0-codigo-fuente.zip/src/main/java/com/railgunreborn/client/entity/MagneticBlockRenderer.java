package com.railgunreborn.client.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.railgunreborn.entity.MagneticBlockEntity;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;

/**
 * Dibuja el bloque de Magnet Manipulation con el modelo de su {@code BlockState}, girando sobre dos ejes a 1-3 grados
 * por tick (velocidades fijas por entidad) y sin luz del mundo (aspecto brillante, como el original). El aura de
 * arcos la pone {@code MagManipClient}.
 */
public class MagneticBlockRenderer extends EntityRenderer<MagneticBlockEntity> {
    private final BlockRenderDispatcher blocks;

    public MagneticBlockRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.blocks = context.getBlockRenderDispatcher();
        this.shadowRadius = 0f;
    }

    @Override
    public void render(MagneticBlockEntity entity, float yaw, float partialTick, PoseStack poseStack,
            MultiBufferSource buffer, int packedLight) {
        BlockState state = entity.getBlockState();
        if (state.getRenderShape() != RenderShape.MODEL) {
            return;
        }
        RandomSource random = RandomSource.create(entity.getId());
        float yawSpeed = 1f + random.nextFloat() * 2f;
        float pitchSpeed = 1f + random.nextFloat() * 2f;
        float time = entity.tickCount + partialTick;

        poseStack.pushPose();
        poseStack.translate(0, 0.5, 0);
        poseStack.mulPose(Axis.YP.rotationDegrees(time * yawSpeed));
        poseStack.mulPose(Axis.XP.rotationDegrees(time * pitchSpeed));
        poseStack.translate(-0.5, -0.5, -0.5);
        blocks.renderSingleBlock(state, poseStack, buffer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                ModelData.EMPTY, null);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    @SuppressWarnings("deprecation")
    @Override
    public ResourceLocation getTextureLocation(MagneticBlockEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
