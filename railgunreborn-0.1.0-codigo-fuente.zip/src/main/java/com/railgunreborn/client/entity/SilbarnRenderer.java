package com.railgunreborn.client.entity;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.entity.SilbarnEntity;
import com.railgunreborn.registry.ModItems;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Dibuja el barn como su ítem plano girando a 30 grados por segundo sobre un eje fijo aleatorio. No dibuja si ya chocó. */
public class SilbarnRenderer extends EntityRenderer<SilbarnEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/item/silbarn.png");
    private ItemStack stack;

    public SilbarnRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(SilbarnEntity barn, float yaw, float partialTick, PoseStack poseStack,
            MultiBufferSource buffer, int packedLight) {
        if (barn.isHit()) {
            return;
        }
        if (stack == null) {
            stack = new ItemStack(ModItems.SILBARN.get());
        }
        poseStack.pushPose();
        poseStack.translate(0, barn.getBbHeight() / 2, 0);
        RandomSource random = RandomSource.create(barn.getId());
        float angle = (barn.tickCount + partialTick) * 1.5f * Mth.DEG_TO_RAD;
        poseStack.mulPose(new Quaternionf().rotationAxis(angle, 0.2f + random.nextFloat(), random.nextFloat(),
                random.nextFloat()));
        poseStack.scale(1.4f, 1.4f, 1.4f);
        Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.FIXED, packedLight,
                OverlayTexture.NO_OVERLAY, poseStack, buffer, barn.level(), barn.getId());
        poseStack.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(SilbarnEntity barn) {
        return TEXTURE;
    }
}
