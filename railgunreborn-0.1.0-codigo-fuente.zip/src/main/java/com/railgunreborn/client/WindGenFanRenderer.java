package com.railgunreborn.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.WindGenMainBlock;
import com.railgunreborn.block.WindGenMainBlockEntity;
import com.railgunreborn.block.WindGenRules;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.client.model.data.ModelData;

/**
 * Rotor del generador eólico (como {@code RenderWindGenMain} del original): el OBJ de las aspas (~7 bloques de
 * radio) delante del cuerpo, girando en el plano vertical. Se dibuja si hay aspas y el cuadro del rotor está libre;
 * gira solo cuando el generador funciona, más rápido cuanto más alta está la cabeza (como la producción).
 */
public final class WindGenFanRenderer implements BlockEntityRenderer<WindGenMainBlockEntity> {
    public static final ModelResourceLocation FAN_MODEL = ModelResourceLocation.standalone(
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "block/windgen_fan"));
    /** Centro del rotor respecto al centro del bloque de la cabeza (valores del original). */
    private static final double HUB_Y = 0.5;
    private static final double HUB_Z = 0.82;

    public WindGenFanRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(WindGenMainBlockEntity be, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
            int packedLight, int packedOverlay) {
        Level level = be.getLevel();
        if (level == null || !be.hasFan() || !be.isAreaClear()
                || !be.getBlockState().hasProperty(WindGenMainBlock.FACING)) {
            return;
        }
        float now = level.getGameTime() + partialTick;
        if (be.spinLastTime >= 0f && now > be.spinLastTime && be.getStatus() == WindGenRules.Status.WORKING) {
            double degrees = (now - be.spinLastTime) / 20.0 * WindGenRules.spinDegreesPerSecond(be.getBlockPos().getY());
            be.spinAngle = (float) ((be.spinAngle + degrees) % 360.0);
        }
        be.spinLastTime = now;

        Direction facing = be.getFacing();
        // La parte delantera es sólida (sin luz propia): se usa la luz del aire de encima, que está libre.
        BlockPos lightPos = be.getBlockPos().relative(facing).above();
        int light = LevelRenderer.getLightColor(level, lightPos);
        BakedModel model = Minecraft.getInstance().getModelManager().getModel(FAN_MODEL);

        poseStack.pushPose();
        poseStack.translate(0.5, 0.0, 0.5);
        // El modelo mira al sur (+Z); igual que la rotación "y" del blockstate de la cabeza.
        poseStack.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
        poseStack.translate(0.0, HUB_Y, HUB_Z);
        poseStack.mulPose(Axis.ZN.rotationDegrees(be.spinAngle));
        Minecraft.getInstance().getBlockRenderer().getModelRenderer().renderModel(poseStack.last(),
                buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS)), null, model, 1f, 1f, 1f,
                light, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
        poseStack.popPose();
    }

    /** Las aspas salen ~7 bloques del bloque: sin esto desaparecerían al no ver la cabeza. */
    @Override
    public AABB getRenderBoundingBox(WindGenMainBlockEntity be) {
        return new AABB(be.getBlockPos()).inflate(WindGenRules.CLEAR_RADIUS + 1);
    }

    @Override
    public int getViewDistance() {
        return 128;
    }
}
