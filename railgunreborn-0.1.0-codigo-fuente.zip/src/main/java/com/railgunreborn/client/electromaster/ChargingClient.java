package com.railgunreborn.client.electromaster;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.ArcGenSkill;
import com.railgunreborn.ability.electromaster.ChargingRules;
import com.railgunreborn.ability.electromaster.ChargingSkill;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.ArcPatterns;
import com.railgunreborn.client.effect.ContinuousArcEffect;
import com.railgunreborn.client.effect.SurroundArcEffect;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Efectos de Current Charging en cada cliente cercano (ficha 7 y 8): sonido en bucle, rayo continuo hacia donde mira
 * (modo bloque) con mini-arcos sobre el bloque que se está cargando, o un aura de mini-arcos (modo ítem). El rayo se
 * recalcula aquí a partir del jugador; el servidor solo dice el modo y el bloque cargable.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ChargingClient {
    /** Altura del origen del rayo sobre los pies (el original no usa desplazamiento de mano). */
    private static final double ARC_ORIGIN_HEIGHT = 1.6;
    private static final float LOOP_VOLUME = 0.3f;
    /** Sin "state" del servidor durante este tiempo (p. ej. salió del rango de efectos), se corta. */
    private static final int STATE_TIMEOUT = ChargingSkill.STATE_INTERVAL * 4;

    /** Un efecto por jugador que carga (por id de entidad). */
    private static final Map<Integer, Visual> ACTIVE = new HashMap<>();

    private ChargingClient() {
    }

    static void handle(Player caster, int contextId, String channel, CompoundTag data) {
        if (ChargingSkill.STATE_CHANNEL.equals(channel)) {
            boolean itemMode = data.getBoolean(ChargingSkill.ITEM_MODE_KEY);
            Visual visual = ACTIVE.get(caster.getId());
            if (visual == null || visual.contextId != contextId || visual.itemMode != itemMode
                    || visual.caster != caster) {
                if (visual != null) {
                    visual.stop();
                }
                visual = new Visual(caster, contextId, itemMode);
                ACTIVE.put(caster.getId(), visual);
            }
            visual.sinceUpdate = 0;
            visual.setTarget(data.contains(ChargingSkill.TARGET_KEY)
                    ? BlockPos.of(data.getLong(ChargingSkill.TARGET_KEY)) : null);
        } else if (ChargingSkill.STOP_CHANNEL.equals(channel)) {
            Visual visual = ACTIVE.get(caster.getId());
            if (visual != null && visual.contextId == contextId) {
                ACTIVE.remove(caster.getId());
                visual.stop();
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (ACTIVE.isEmpty() || mc.isPaused()) {
            return;
        }
        for (Iterator<Visual> it = ACTIVE.values().iterator(); it.hasNext(); ) {
            Visual visual = it.next();
            if (++visual.sinceUpdate > STATE_TIMEOUT || visual.caster.isRemoved() || visual.caster.level() != mc.level) {
                visual.stop();
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ACTIVE.values().forEach(Visual::stop);
        ACTIVE.clear();
    }

    /** Punto final del rayo: lo que golpea el trazado de 15 bloques, o 15 bloques al frente. */
    private static Vec3 arcEnd(Entity owner) {
        Player player = (Player) owner;
        HitResult hit = ArcGenSkill.trace(player, ChargingRules.RANGE);
        if (hit instanceof EntityHitResult entityHit) {
            return entityHit.getEntity().getEyePosition();
        }
        if (hit.getType() == HitResult.Type.BLOCK) {
            return hit.getLocation();
        }
        return player.getEyePosition().add(player.getViewVector(1f).scale(ChargingRules.RANGE));
    }

    private static final class Visual {
        final Player caster;
        final int contextId;
        final boolean itemMode;
        final EntityLoopSound sound;
        @Nullable
        final ContinuousArcEffect arc;
        final SurroundArcEffect surround;
        int sinceUpdate;

        Visual(Player caster, int contextId, boolean itemMode) {
            this.caster = caster;
            this.contextId = contextId;
            this.itemMode = itemMode;
            this.sound = new EntityLoopSound(ModSounds.CHARGE_LOOP.get(), SoundSource.PLAYERS, caster, LOOP_VOLUME);
            Minecraft.getInstance().getSoundManager().play(sound);
            if (itemMode) {
                arc = null;
                surround = ArcEffects.spawn(SurroundArcEffect.aroundEntity(caster));
            } else {
                arc = ArcEffects.spawn(new ContinuousArcEffect(caster, ArcPatterns.chargingArc(), ARC_ORIGIN_HEIGHT,
                        ChargingClient::arcEnd).wiggle(0.8, 0.2, 0.8));
                surround = ArcEffects.spawn(SurroundArcEffect.onBlock(caster.level(), caster.position()));
                surround.setDraw(false);
            }
        }

        void setTarget(@Nullable BlockPos pos) {
            if (itemMode) {
                return;
            }
            if (pos == null) {
                surround.setDraw(false);
            } else {
                surround.moveTo(Vec3.atBottomCenterOf(pos));
                surround.setDraw(true);
            }
        }

        void stop() {
            sound.finish();
            if (arc != null) {
                arc.stop();
            }
            surround.stop();
        }
    }
}
