package com.railgunreborn.client.electromaster;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * Anillos de la marca de Thunderclap y de Jet Engine ({@code RippleMarkRender} del original). Hereda de
 * {@link RenderType} solo para acceder a los "shards" protegidos; nunca se instancia.
 *
 * <p>Textura × color sin iluminación (brillo pleno), mezcla alfa, sin culling, <b>sin test de profundidad</b> (se ve a
 * través de bloques) y sin escribir profundidad. Se dibuja al final del mundo ({@code AFTER_LEVEL}).
 */
public final class RippleRenderType extends RenderType {
    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/ripple.png");

    private static final ShaderStateShard POSITION_TEX_COLOR_SHADER =
            new ShaderStateShard(GameRenderer::getPositionTexColorShader);

    public static final RenderType RIPPLE = create(
            "railgunreborn_ripple",
            DefaultVertexFormat.POSITION_TEX_COLOR,
            VertexFormat.Mode.QUADS,
            256,
            false,
            false,
            CompositeState.builder()
                    .setShaderState(POSITION_TEX_COLOR_SHADER)
                    .setTextureState(new TextureStateShard(TEXTURE, false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setDepthTestState(NO_DEPTH_TEST)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));

    private RippleRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
