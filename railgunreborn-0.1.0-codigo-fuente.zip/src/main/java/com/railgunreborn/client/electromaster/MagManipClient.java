package com.railgunreborn.client.electromaster;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagManipSkill;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.SurroundArcEffect;
import com.railgunreborn.entity.MagneticBlockEntity;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.EntityBoundSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * Cliente de Magnet Manipulation (ficha §7-8). Lo que dura lo lleva la propia entidad del bloque, así lo ve cualquier
 * cliente que la tenga cargada sin mensajes extra: aura de arcos mientras exista y bucle {@code lf_loop} mientras se
 * sostenga. El lanzamiento llega como efecto de la habilidad y suena {@code mag_manip} en el lanzador.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MagManipClient {
    private static final float LOOP_VOLUME = 1.0f;

    private MagManipClient() {
    }

    /** Llamar en {@code FMLClientSetupEvent}. */
    static void setup() {
        SkillEffects.register(Electromaster.MAG_MANIP.getId(), MagManipClient::handleEffect);
    }

    private static void handleEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!MagManipSkill.THROW_CHANNEL.equals(channel)) {
            return;
        }
        Minecraft.getInstance().getSoundManager().play(new EntityBoundSoundInstance(ModSounds.MAG_MANIP.get(),
                SoundSource.PLAYERS, 1.0f, 1.0f, caster, caster.getRandom().nextLong()));
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide() || !(event.getEntity() instanceof MagneticBlockEntity block)) {
            return;
        }
        // El aura se apaga sola cuando la entidad desaparece.
        ArcEffects.spawn(SurroundArcEffect.centeredOn(block));
        Minecraft.getInstance().getSoundManager().play(new HeldLoopSound(block));
    }

    /** {@code lf_loop} pegado al bloque mientras esté sostenido; se corta al lanzarlo, soltarlo o desaparecer. */
    private static final class HeldLoopSound extends AbstractTickableSoundInstance {
        private final MagneticBlockEntity block;
        /** El modo llega justo después de crear la entidad: unos ticks de margen antes de fiarse de él. */
        private int age;

        HeldLoopSound(MagneticBlockEntity block) {
            super(ModSounds.LF_LOOP.get(), SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
            this.block = block;
            this.looping = true;
            this.delay = 0;
            this.volume = LOOP_VOLUME;
            this.x = block.getX();
            this.y = block.getY() + 0.5;
            this.z = block.getZ();
        }

        @Override
        public boolean canStartSilent() {
            return true;
        }

        @Override
        public void tick() {
            age++;
            if (block.isRemoved() || (age > 1 && !block.isHeld())) {
                stop();
                return;
            }
            x = block.getX();
            y = block.getY() + 0.5;
            z = block.getZ();
        }
    }
}
