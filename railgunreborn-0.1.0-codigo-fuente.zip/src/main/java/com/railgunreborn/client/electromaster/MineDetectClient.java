package com.railgunreborn.client.electromaster;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MineDetectRules;
import com.railgunreborn.ability.electromaster.MineDetectSkill;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.resources.sounds.EntityBoundSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Mine Detection (ficha §5-7). Solo existe en el cliente del que la usa: el servidor manda el efecto por
 * {@code sendToLocal} a la mitad cliente local del contexto, así ningún otro jugador recibe nada.
 *
 * <p>Detección en el cliente, como el original: se escanean los bloques ya cargados dentro de una esfera alrededor de
 * los pies al empezar y cada {@link MineDetectRules#RESCAN_INTERVAL} ticks (nunca por frame). Se recorre por secciones
 * de chunk y se salta cualquier sección cuya paleta no contenga ningún mineral, que es lo normal fuera de la roca.
 * Dibujo en {@code AFTER_LEVEL}: cubos sin test de profundidad ni niebla (ver {@link MineDetectRenderType}).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MineDetectClient {
    private static final float SOUND_VOLUME = 0.5f;
    /** Cubo inscrito en el bloque, de 0.05 a 0.95 (ficha §6.2). */
    private static final float BOX_MIN = 0.05f;
    private static final float BOX_MAX = 0.95f;

    private record Ore(BlockPos pos, int color, double distanceSqr) {
    }

    private static ClientLevel level;
    private static int ticksLeft;
    private static float range;
    private static boolean advanced;
    private static int ticksSinceScan;
    private static List<Ore> ores = List.of();

    private MineDetectClient() {
    }

    /** Llamar en {@code FMLClientSetupEvent}. */
    static void setup() {
        ClientSkillContexts.registerFactory(Electromaster.MINE_DETECT.getId(), MineDetectContext::new);
    }

    /** Mitad cliente local: solo espera el mensaje del servidor (llega antes del aviso de fin del contexto). */
    private static final class MineDetectContext extends ClientSkillContext {
        MineDetectContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (MineDetectSkill.EFFECT_CHANNEL.equals(channel)) {
                start(data.getFloat(MineDetectSkill.RANGE_KEY), data.getBoolean(MineDetectSkill.ADVANCED_KEY));
            }
        }
    }

    private static void start(float serverRange, boolean advancedMode) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }
        level = mc.level;
        range = MineDetectRules.clientRange(serverRange);
        advanced = advancedMode;
        ticksLeft = MineDetectRules.EFFECT_TICKS;
        ticksSinceScan = 0;
        scan(player.position());
        mc.getSoundManager().play(new EntityBoundSoundInstance(ModSounds.MINE_DETECT.get(), SoundSource.PLAYERS,
                SOUND_VOLUME, 1.0f, player, player.getRandom().nextLong()));
    }

    private static void stop() {
        level = null;
        ticksLeft = 0;
        ores = List.of();
    }

    private static boolean isActive() {
        return level != null && ticksLeft > 0;
    }

    private static void scan(Vec3 origin) {
        double r2 = (double) range * range;
        int minX = Mth.floor(origin.x - range);
        int maxX = Mth.floor(origin.x + range);
        int minY = Math.max(level.getMinBuildHeight(), Mth.floor(origin.y - range));
        int maxY = Math.min(level.getMaxBuildHeight() - 1, Mth.floor(origin.y + range));
        int minZ = Mth.floor(origin.z - range);
        int maxZ = Mth.floor(origin.z + range);

        List<Ore> found = new ArrayList<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunk(cx, cz, false);
                if (chunk == null) {
                    continue;
                }
                LevelChunkSection[] sections = chunk.getSections();
                for (int sy = minY >> 4; sy <= maxY >> 4; sy++) {
                    int index = level.getSectionIndexFromSectionY(sy);
                    if (index < 0 || index >= sections.length) {
                        continue;
                    }
                    LevelChunkSection section = sections[index];
                    if (section.hasOnlyAir() || !section.maybeHas(MineDetectSkill::isDetectable)) {
                        continue;
                    }
                    scanSection(section, origin, r2,
                            Math.max(minX, cx << 4), Math.min(maxX, (cx << 4) + 15),
                            Math.max(minY, sy << 4), Math.min(maxY, (sy << 4) + 15),
                            Math.max(minZ, cz << 4), Math.min(maxZ, (cz << 4) + 15), found);
                }
            }
        }
        if (found.size() > MineDetectRules.MAX_RESULTS) {
            // Ficha [DUDA] 6: si sobran, se quedan los más cercanos (no los de menor x como en el original).
            found.sort(Comparator.comparingDouble(Ore::distanceSqr));
            found = found.subList(0, MineDetectRules.MAX_RESULTS);
        }
        ores = List.copyOf(found);
    }

    private static void scanSection(LevelChunkSection section, Vec3 origin, double r2, int x0, int x1, int y0, int y1,
            int z0, int z1, List<Ore> out) {
        for (int x = x0; x <= x1; x++) {
            double dx = x + 0.5 - origin.x;
            for (int y = y0; y <= y1; y++) {
                double dy = y + 0.5 - origin.y;
                for (int z = z0; z <= z1; z++) {
                    double dz = z + 0.5 - origin.z;
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) {
                        continue;
                    }
                    BlockState state = section.getBlockState(x & 15, y & 15, z & 15);
                    if (!MineDetectSkill.isDetectable(state)) {
                        continue;
                    }
                    int index = MineDetectRules.colorIndex(advanced, MineDetectSkill.toolTier(state));
                    out.add(new Ore(new BlockPos(x, y, z), MineDetectRules.color(index), d2));
                }
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (level == null) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level != level) {
            stop();
            return;
        }
        if (mc.isPaused()) {
            return;
        }
        if (--ticksLeft <= 0) {
            stop();
            return;
        }
        if (++ticksSinceScan >= MineDetectRules.RESCAN_INTERVAL) {
            ticksSinceScan = 0;
            scan(mc.player.position());
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || !isActive() || ores.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level != level) {
            return;
        }
        // En AFTER_LEVEL la vista ya no está en el estado de render: se aplica a mano y se dibuja relativo a la cámara.
        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        Matrix4f pose = poseStack.last().pose();
        Vec3 camera = event.getCamera().getPosition();
        Vec3 feet = mc.player.getPosition(event.getPartialTick().getGameTimeDeltaPartialTick(false));

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(MineDetectRenderType.ORE_BOX);
        for (Ore ore : ores) {
            BlockPos pos = ore.pos();
            double distance = Math.sqrt(feet.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5));
            int alpha = (int) (MineDetectRules.alpha(distance, range) * 255f);
            renderBox(consumer, pose, (float) (pos.getX() - camera.x), (float) (pos.getY() - camera.y),
                    (float) (pos.getZ() - camera.z), ore.color(), alpha);
        }
        buffers.endBatch(MineDetectRenderType.ORE_BOX);
    }

    private static void renderBox(VertexConsumer c, Matrix4f pose, float x, float y, float z, int rgb, int alpha) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        float x0 = x + BOX_MIN;
        float x1 = x + BOX_MAX;
        float y0 = y + BOX_MIN;
        float y1 = y + BOX_MAX;
        float z0 = z + BOX_MIN;
        float z1 = z + BOX_MAX;
        // Abajo, arriba, norte, sur, oeste, este; UV completos en cada cara.
        quad(c, pose, r, g, b, alpha, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
        quad(c, pose, r, g, b, alpha, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
        quad(c, pose, r, g, b, alpha, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0);
        quad(c, pose, r, g, b, alpha, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        quad(c, pose, r, g, b, alpha, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        quad(c, pose, r, g, b, alpha, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);
    }

    private static void quad(VertexConsumer c, Matrix4f pose, int r, int g, int b, int a, float ax, float ay, float az,
            float bx, float by, float bz, float cx, float cy, float cz, float dx, float dy, float dz) {
        c.addVertex(pose, ax, ay, az).setUv(0f, 0f).setColor(r, g, b, a);
        c.addVertex(pose, bx, by, bz).setUv(1f, 0f).setColor(r, g, b, a);
        c.addVertex(pose, cx, cy, cz).setUv(1f, 1f).setColor(r, g, b, a);
        c.addVertex(pose, dx, dy, dz).setUv(0f, 1f).setColor(r, g, b, a);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        stop();
    }

    /** Morir o cambiar de dimensión recrea el jugador local: la visión se corta. */
    @SubscribeEvent
    public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
        stop();
    }
}
