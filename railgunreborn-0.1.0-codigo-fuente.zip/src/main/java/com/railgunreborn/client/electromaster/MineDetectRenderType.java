package com.railgunreborn.client.electromaster;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * Cubos de Mine Detection. Hereda de {@link RenderType} solo para acceder a los "shards" protegidos; nunca se
 * instancia.
 *
 * <p>Shader {@code position_tex_color}: textura × color, sin iluminación y <b>sin niebla</b> (la Ceguera pone una
 * niebla cerradísima que taparía todo lo demás). Mezcla alfa estándar, sin culling (se ven las 6 caras), <b>sin test
 * de profundidad</b> (a través de las paredes) y sin escribir profundidad. Ordenado al subir para que los cubos
 * superpuestos se mezclen bien. Se dibuja en el destino principal al final del mundo ({@code AFTER_LEVEL}).
 */
final class MineDetectRenderType extends RenderType {
    static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/mine_view.png");

    private static final ShaderStateShard POSITION_TEX_COLOR_SHADER =
            new ShaderStateShard(GameRenderer::getPositionTexColorShader);

    static final RenderType ORE_BOX = create(
            "railgunreborn_mine_detect",
            DefaultVertexFormat.POSITION_TEX_COLOR,
            VertexFormat.Mode.QUADS,
            1536,
            false,
            true,
            CompositeState.builder()
                    .setShaderState(POSITION_TEX_COLOR_SHADER)
                    .setTextureState(new TextureStateShard(TEXTURE, false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setDepthTestState(NO_DEPTH_TEST)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));

    private MineDetectRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
