package com.railgunreborn.client.electromaster;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Nullable;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.ThunderclapRules;
import com.railgunreborn.ability.electromaster.ThunderclapSkill;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.SurroundArcEffect;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Efectos de Thunderclap (ficha 9): aura BOLD sobre el que carga en todos los clientes cercanos (se apaga 10 ticks
 * después del fin) y, solo para el que carga, la marca de 3 anillos en el punto apuntado, trazado aquí cada tick con
 * el mismo cálculo que el servidor. Sin sonido propio: el trueno es el del rayo vanilla.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ThunderclapClient {
    private static final int AURA_LINGER_TICKS = 10;
    /** Si no llega el "stop" (p. ej. fuera de rango), se corta solo: la carga nunca pasa de 60 ticks. */
    private static final int SAFETY_TICKS = ThunderclapRules.MAX_TICKS + 40;
    private static final int RIPPLE_GRAY = 204;
    private static final float RIPPLE_BASE_ALPHA = 0.7f;

    private static final Map<Integer, Aura> AURAS = new HashMap<>();

    @Nullable
    private static Ripple ripple;

    private ThunderclapClient() {
    }

    static void handle(Player caster, int contextId, String channel, CompoundTag data) {
        boolean local = caster == Minecraft.getInstance().player;
        if (ThunderclapSkill.START_CHANNEL.equals(channel)) {
            Aura old = AURAS.remove(caster.getId());
            if (old != null) {
                old.effect.stop();
            }
            AURAS.put(caster.getId(), new Aura(contextId, ArcEffects.spawn(SurroundArcEffect.boldAround(caster))));
            if (local) {
                ripple = new Ripple(contextId, caster, ThunderclapSkill.aim(caster));
            }
        } else if (ThunderclapSkill.STOP_CHANNEL.equals(channel)) {
            Aura aura = AURAS.get(caster.getId());
            if (aura != null && aura.contextId == contextId) {
                AURAS.remove(caster.getId());
                aura.effect.stopIn(AURA_LINGER_TICKS);
            }
            if (local && ripple != null && ripple.contextId == contextId) {
                ripple = null;
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused()) {
            return;
        }
        for (Iterator<Aura> it = AURAS.values().iterator(); it.hasNext(); ) {
            Aura aura = it.next();
            if (++aura.age > SAFETY_TICKS) {
                aura.effect.stop();
                it.remove();
            }
        }
        Ripple current = ripple;
        if (current != null) {
            if (++current.age > SAFETY_TICKS || current.caster != mc.player || current.caster.level() != mc.level) {
                ripple = null;
            } else {
                current.prevPoint = current.point;
                current.point = ThunderclapSkill.aim(current.caster);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        Ripple current = ripple;
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || current.caster.level() != level) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        // En AFTER_LEVEL la vista ya no está en el estado de render: se aplica a mano, como Mine Detection.
        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        Matrix4f pose = poseStack.last().pose();
        Vec3 camera = event.getCamera().getPosition();
        Vec3 at = current.prevPoint.lerp(current.point, partialTick).subtract(camera);
        double seconds = (current.age + partialTick) / 20.0;

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(RippleRenderType.RIPPLE);
        for (int ring = 0; ring < ThunderclapRules.RIPPLE_OFFSETS.length; ring++) {
            double phase = ThunderclapRules.ripplePhase(seconds, ring);
            int alpha = (int) (ThunderclapRules.rippleAlpha(phase) * RIPPLE_BASE_ALPHA * 255f);
            if (alpha <= 0) {
                continue;
            }
            float half = (float) (ThunderclapRules.rippleSize(phase) / 2);
            float x = (float) at.x;
            float y = (float) (at.y + ThunderclapRules.rippleHeight(phase));
            float z = (float) at.z;
            vertex(consumer, pose, x - half, y, z - half, 0f, 0f, alpha);
            vertex(consumer, pose, x - half, y, z + half, 0f, 1f, alpha);
            vertex(consumer, pose, x + half, y, z + half, 1f, 1f, alpha);
            vertex(consumer, pose, x + half, y, z - half, 1f, 0f, alpha);
        }
        buffers.endBatch(RippleRenderType.RIPPLE);
    }

    private static void vertex(VertexConsumer c, Matrix4f pose, float x, float y, float z, float u, float v,
            int alpha) {
        c.addVertex(pose, x, y, z).setUv(u, v).setColor(RIPPLE_GRAY, RIPPLE_GRAY, RIPPLE_GRAY, alpha);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        AURAS.values().forEach(aura -> aura.effect.stop());
        AURAS.clear();
        ripple = null;
    }

    /** Morir o cambiar de dimensión recrea el jugador local: la marca se corta. */
    @SubscribeEvent
    public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
        ripple = null;
    }

    private static final class Aura {
        final int contextId;
        final SurroundArcEffect effect;
        int age;

        Aura(int contextId, SurroundArcEffect effect) {
            this.contextId = contextId;
            this.effect = effect;
        }
    }

    private static final class Ripple {
        final int contextId;
        final Player caster;
        Vec3 prevPoint;
        Vec3 point;
        int age;

        Ripple(int contextId, Player caster, Vec3 point) {
            this.contextId = contextId;
            this.caster = caster;
            this.prevPoint = point;
            this.point = point;
        }
    }
}
