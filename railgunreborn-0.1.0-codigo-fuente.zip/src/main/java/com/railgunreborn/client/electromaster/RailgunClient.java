package com.railgunreborn.client.electromaster;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.RailgunRules;
import com.railgunreborn.ability.electromaster.RailgunSkill;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.RailgunEffects;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Cliente del Railgun: efectos que manda el servidor ({@code perform}: sonido + rayo; {@code charge}: chispas en la
 * mano al lanzar la moneda), la mitad local del contexto (chispas al empezar la carga con hierro, solo para uno mismo)
 * y el estado del aviso de teclas (CARGA naranja / ACTIVO azul, ficha §9.4).
 */
public final class RailgunClient {
    /** Margen para no dibujar rayos absurdos si llegara un valor raro. */
    private static final double MAX_LENGTH = RailgunRules.RANGE;
    /** Origen del rayo a más distancia que esto del lanzador = dato raro, se ignora. */
    private static final double MAX_ORIGIN_DISTANCE = 8.0;

    /** Carga con hierro en curso en el cliente local (para el aviso de teclas). */
    private static boolean ironCharging;

    private RailgunClient() {
    }

    /** Llamar en {@code FMLClientSetupEvent}. */
    static void setup() {
        SkillEffects.register(Electromaster.RAILGUN.getId(), RailgunClient::handleEffect);
        ClientSkillContexts.registerFactory(Electromaster.RAILGUN.getId(), RailgunClientContext::new);
        KeyHintHud.registerStateProvider(Electromaster.RAILGUN.getId(), RailgunClient::hintState);
    }

    private static void handleEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (RailgunSkill.CHARGE_CHANNEL.equals(channel)) {
            RailgunEffects.startHandSparks(caster);
            return;
        }
        if (!RailgunSkill.PERFORM_CHANNEL.equals(channel)) {
            return;
        }
        Vec3 origin = RailgunSkill.readVec(data, RailgunSkill.ORIGIN_KEY);
        Vec3 dir = RailgunSkill.readVec(data, RailgunSkill.DIR_KEY);
        if (origin == null || dir == null || dir.lengthSqr() < 1.0e-6
                || origin.distanceTo(caster.getEyePosition()) > MAX_ORIGIN_DISTANCE) {
            origin = caster.getEyePosition();
            dir = caster.getViewVector(1.0f);
        }
        double length = Mth.clamp(data.getFloat(RailgunSkill.LENGTH_KEY), 0f, (float) MAX_LENGTH);
        RailgunEffects.spawnBeam(caster, origin, dir, length);
        caster.level().playLocalSound(origin.x, origin.y, origin.z, ModSounds.RAILGUN.get(), SoundSource.PLAYERS,
                0.5f, 1.0f, false);
    }

    private static KeyHintHud.HintState hintState(LocalPlayer player) {
        if (ironCharging) {
            return KeyHintHud.HintState.CHARGE;
        }
        CoinEntity coin = CoinEntity.findActive(player);
        if (coin == null || !coin.isFlying()) {
            return KeyHintHud.HintState.IDLE;
        }
        // Aviso en la ventana estricta (sin la tolerancia del servidor): es el momento de pulsar.
        return coin.isInQteWindow() ? KeyHintHud.HintState.ACTIVE : KeyHintHud.HintState.CHARGE;
    }

    /** Mitad local: si se empieza a cargar con hierro (sin moneda en el aire), chispas en la propia mano. */
    private static final class RailgunClientContext extends ClientSkillContext {
        private boolean charging;

        RailgunClientContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null && CoinEntity.findActive(player) == null
                    && RailgunSkill.canUseIronMode(player)) {
                charging = true;
                ironCharging = true;
                RailgunEffects.startHandSparks(player);
            }
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            // Una moneda lanzada durante la carga la cancela (el servidor termina el contexto): el aviso cambia ya.
            if (charging && player != null && CoinEntity.findActive(player) != null) {
                stopCharging();
            }
        }

        @Override
        protected void onKeyUp() {
            stopCharging();
        }

        @Override
        protected void onKeyAbort() {
            stopCharging();
        }

        @Override
        protected void onTerminated() {
            stopCharging();
        }

        private void stopCharging() {
            if (charging) {
                charging = false;
                ironCharging = false;
            }
        }
    }
}
