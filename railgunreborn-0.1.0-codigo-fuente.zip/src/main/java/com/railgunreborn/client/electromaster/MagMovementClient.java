package com.railgunreborn.client.electromaster;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagMovementRules;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.ArcPatterns;
import com.railgunreborn.client.effect.ContinuousArcEffect;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Cliente de Magnet Movement: la mitad local que mueve al jugador hacia el objetivo (ficha §5) y los efectos que ven
 * todos los cercanos (bucle {@code move_loop} y arco fino del pecho al objetivo, §7-8).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MagMovementClient {
    /** Altura del origen del arco sobre los pies (el original no usa desplazamiento de mano). */
    private static final double ARC_ORIGIN_HEIGHT = 1.6;
    private static final float LOOP_VOLUME = 1.0f;
    /** Sin "state" del servidor durante este tiempo (p. ej. salió del rango de efectos), se corta. */
    private static final int STATE_TIMEOUT = MagMovementSkill.STATE_INTERVAL * 4;
    /** Un objetivo más lejos que esto del lanzador no viene de un uso legítimo: no se dibuja el arco. */
    private static final double MAX_ARC_LENGTH = ArcPatterns.THIN_CONTINUOUS_LENGTH;

    private static final Map<Integer, Visual> ACTIVE = new HashMap<>();

    private MagMovementClient() {
    }

    /** Llamar en {@code FMLClientSetupEvent}. */
    static void setup() {
        SkillEffects.register(Electromaster.MAG_MOVEMENT.getId(), MagMovementClient::handleEffect);
        ClientSkillContexts.registerFactory(Electromaster.MAG_MOVEMENT.getId(), MoveContext::new);
    }

    /** Destino vivo: ojos de la entidad si el cliente la conoce; si no, el punto de impacto. */
    private record Destination(int entityId, Vec3 point) {
        @Nullable
        static Destination read(CompoundTag data) {
            Vec3 point = MagMovementSkill.readVec(data, MagMovementSkill.POINT_KEY);
            if (point == null) {
                return null;
            }
            int id = data.contains(MagMovementSkill.ENTITY_KEY) ? data.getInt(MagMovementSkill.ENTITY_KEY) : -1;
            return new Destination(id, point);
        }

        Vec3 resolve(Level level) {
            if (entityId >= 0) {
                Entity entity = level.getEntity(entityId);
                if (entity != null) {
                    return entity.getEyePosition();
                }
            }
            return point;
        }
    }

    // --- Efectos (todos los cercanos) ---

    private static void handleEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (MagMovementSkill.STATE_CHANNEL.equals(channel)) {
            Destination dest = Destination.read(data);
            if (dest == null) {
                return;
            }
            Visual visual = ACTIVE.get(caster.getId());
            if (visual == null || visual.contextId != contextId || visual.caster != caster) {
                if (visual != null) {
                    visual.stop();
                }
                visual = new Visual(caster, contextId, dest);
                ACTIVE.put(caster.getId(), visual);
            }
            visual.dest = dest;
            visual.sinceUpdate = 0;
        } else if (MagMovementSkill.STOP_CHANNEL.equals(channel)) {
            Visual visual = ACTIVE.get(caster.getId());
            if (visual != null && visual.contextId == contextId) {
                ACTIVE.remove(caster.getId());
                visual.stop();
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (ACTIVE.isEmpty() || mc.isPaused()) {
            return;
        }
        for (Iterator<Visual> it = ACTIVE.values().iterator(); it.hasNext(); ) {
            Visual visual = it.next();
            if (++visual.sinceUpdate > STATE_TIMEOUT || visual.caster.isRemoved() || visual.caster.level() != mc.level) {
                visual.stop();
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ACTIVE.values().forEach(Visual::stop);
        ACTIVE.clear();
    }

    private static final class Visual {
        final Player caster;
        final int contextId;
        final EntityLoopSound sound;
        final ContinuousArcEffect arc;
        Destination dest;
        int sinceUpdate;

        Visual(Player caster, int contextId, Destination dest) {
            this.caster = caster;
            this.contextId = contextId;
            this.dest = dest;
            this.sound = new EntityLoopSound(ModSounds.MOVE_LOOP.get(), SoundSource.PLAYERS, caster, LOOP_VOLUME);
            Minecraft.getInstance().getSoundManager().play(sound);
            // Cambia de patrón cada tick; visible → oculto con 0.1, oculto → visible con 0.6 (ficha §8).
            this.arc = ArcEffects.spawn(new ContinuousArcEffect(caster, ArcPatterns.thinContinuousArc(),
                    ARC_ORIGIN_HEIGHT, this::arcEnd).wiggle(1.0, 0.1, 0.6));
        }

        private Vec3 arcEnd(Entity owner) {
            Vec3 end = dest.resolve(owner.level());
            Vec3 from = owner.position().add(0, ARC_ORIGIN_HEIGHT, 0);
            // Un destino absurdo se queda en el origen (arco de longitud 0, no se dibuja).
            return end.distanceTo(from) > MAX_ARC_LENGTH + 10 ? from : end;
        }

        void stop() {
            sound.finish();
            arc.stop();
        }
    }

    // --- Mitad local: el movimiento ---

    /**
     * Mueve al jugador local cada tick hacia el destino: velocidad objetivo 1 bloque/tick con aceleración limitada por
     * eje, que sobrescribe la del juego (sin gravedad ni rozamiento acumulados). Como en el original, el movimiento lo
     * decide el cliente; el servidor solo cobra y evita la expulsión por "volar" y el daño de caída.
     */
    private static final class MoveContext extends ClientSkillContext {
        @Nullable
        private Destination dest;
        private Vec3 velocity = Vec3.ZERO;

        MoveContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (MagMovementSkill.TARGET_CHANNEL.equals(channel)) {
                dest = Destination.read(data);
                LocalPlayer player = Minecraft.getInstance().player;
                if (player != null) {
                    velocity = player.getDeltaMovement();
                }
            }
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (dest == null || player == null || getState() != State.ALIVE || player.isPassenger()) {
                return;
            }
            // Velocidad "real": lo que se movió de verdad este tick (tras colisiones), no el delta del juego, que ya
            // lleva restados gravedad y rozamiento.
            Vec3 actual = player.position().subtract(player.xo, player.yo, player.zo);
            velocity = MagMovementRules.step(velocity, actual, player.position(), dest.resolve(player.level()));
            player.setDeltaMovement(velocity);
            player.resetFallDistance();
        }
    }
}
