package com.railgunreborn.client.electromaster;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.ArcGenSkill;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.ThunderBoltRules;
import com.railgunreborn.ability.electromaster.ThunderBoltSkill;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.ArcEffect;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.ArcPatterns;
import com.railgunreborn.client.effect.PointArcEffect;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.EntityBoundSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/** Efectos de cliente de las habilidades de Electromaster. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ElectromasterClient {
    /** El patrón del arco mide 20; más largo no se dibujaría entero. */
    private static final float MAX_ARC_LENGTH = 20f;
    /** Arcos de área más largos que esto no vienen de un disparo legítimo (radio 8 + altura de ojos). */
    private static final double MAX_AOE_ARC_LENGTH = 12.0;

    private ElectromasterClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Electromaster.ARC_GEN.getId(), ElectromasterClient::arcGenEffect);
        SkillEffects.register(Electromaster.CHARGING.getId(), ChargingClient::handle);
        SkillEffects.register(Electromaster.BODY_INTENSIFY.getId(), BodyIntensifyClient::handle);
        SkillEffects.register(Electromaster.THUNDER_BOLT.getId(), ElectromasterClient::thunderBoltEffect);
        SkillEffects.register(Electromaster.THUNDER_CLAP.getId(), ThunderclapClient::handle);
        RailgunClient.setup();
        MagMovementClient.setup();
        MagManipClient.setup();
        MineDetectClient.setup();
    }

    private static void arcGenEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!ArcGenSkill.EFFECT_CHANNEL.equals(channel)) {
            return;
        }
        float range = Mth.clamp(data.getFloat(ArcGenSkill.EFFECT_RANGE_KEY), 0f, MAX_ARC_LENGTH);
        ArcEffects.spawnWeakArc(caster, range);
        caster.level().playLocalSound(caster.getX(), caster.getY(), caster.getZ(), ModSounds.ARC_WEAK.get(),
                SoundSource.PLAYERS, 0.5f, 1.0f, false);
    }

    /** Ficha thunder-bolt §8-9: 3 rayos gruesos de 20 bloques (1 s), un arco por afectado y {@code arc_strong}. */
    private static void thunderBoltEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!ThunderBoltSkill.EFFECT_CHANNEL.equals(channel)) {
            return;
        }
        // Tres arcos independientes con el parpadeo por defecto: casi siempre se ve alguno.
        for (int i = 0; i < 3; i++) {
            ArcEffects.spawn(new ArcEffect(caster, ArcPatterns.strongArc(), ThunderBoltRules.RANGE)
                    .life(20)
                    .wiggle(0.5, 0.2, 0.2));
        }

        CompoundTag pointTag = data.getCompound(ThunderBoltSkill.EFFECT_POINT_KEY);
        Vec3 point = new Vec3(pointTag.getDouble("x"), pointTag.getDouble("y"), pointTag.getDouble("z"));
        var random = caster.getRandom();
        for (int id : data.getIntArray(ThunderBoltSkill.EFFECT_AFFECTED_KEY)) {
            Entity entity = caster.level().getEntity(id);
            if (entity == null) {
                continue;
            }
            Vec3 eyes = entity.getEyePosition();
            if (eyes.distanceTo(point) > MAX_AOE_ARC_LENGTH) {
                continue;
            }
            ArcEffects.spawn(new PointArcEffect(caster.level(), ArcPatterns.aoeArc(), point, eyes)
                    .life(15 + random.nextInt(10)));
        }

        Minecraft.getInstance().getSoundManager().play(new EntityBoundSoundInstance(ModSounds.ARC_STRONG.get(),
                SoundSource.PLAYERS, 0.6f, 1.0f, caster, random.nextLong()));
    }
}
