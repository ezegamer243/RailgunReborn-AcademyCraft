package com.railgunreborn.client.electromaster;

import java.util.HashMap;
import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.BodyIntensifySkill;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.SurroundArcEffect;
import com.railgunreborn.client.hud.IntensifyChargeState;
import com.railgunreborn.client.hud.IntensifyOverlayHud;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;

/**
 * Efectos de Body Intensify (ficha 7 y 8): el bucle de sonido y la capa de pantalla son solo del jugador local; al
 * activar con exito suena {@code intensify_activate} y el aura de barrido se ve en todos los clientes cercanos.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class BodyIntensifyClient {
    private static final float ACTIVATE_VOLUME = 0.5f;

    private static final Map<Integer, EntityLoopSound> LOOPS = new HashMap<>();

    private BodyIntensifyClient() {
    }

    static void handle(Player caster, int contextId, String channel, CompoundTag data) {
        boolean local = caster == Minecraft.getInstance().player;
        if (BodyIntensifySkill.START_CHANNEL.equals(channel)) {
            if (local) {
                stopLoop(caster);
                EntityLoopSound loop = new EntityLoopSound(ModSounds.INTENSIFY_LOOP.get(), SoundSource.PLAYERS,
                        caster, 1.0f);
                LOOPS.put(caster.getId(), loop);
                Minecraft.getInstance().getSoundManager().play(loop);
                IntensifyOverlayHud.start();
                IntensifyChargeState.start();
            }
        } else if (BodyIntensifySkill.END_CHANNEL.equals(channel)) {
            boolean performed = data.getBoolean(BodyIntensifySkill.PERFORMED_KEY);
            if (local) {
                stopLoop(caster);
                IntensifyOverlayHud.end(performed);
                IntensifyChargeState.end();
            }
            if (performed) {
                caster.level().playLocalSound(caster.getX(), caster.getY(), caster.getZ(),
                        ModSounds.INTENSIFY_ACTIVATE.get(), SoundSource.PLAYERS, ACTIVATE_VOLUME, 1.0f, false);
                ArcEffects.spawn(SurroundArcEffect.sweepAround(caster));
            }
        }
    }

    private static void stopLoop(Player caster) {
        EntityLoopSound loop = LOOPS.remove(caster.getId());
        if (loop != null) {
            loop.finish();
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        LOOPS.values().forEach(EntityLoopSound::finish);
        LOOPS.clear();
        IntensifyOverlayHud.reset();
        IntensifyChargeState.reset();
    }
}
