package com.railgunreborn.client.teleporter;

import java.util.function.Function;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.railgunreborn.RailgunReborn;

import net.minecraft.Util;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * Silueta del destino de teletransporte ({@code MarkRender} del original): modelo de entidad translúcido con una de las
 * 7 texturas {@code textures/effect/tp_mark/0..6.png}, <b>sin test de profundidad</b> (se ve a través de bloques) y sin
 * escribir profundidad. Hereda de {@link RenderType} solo para acceder a los "shards"; nunca se instancia. Pensada
 * para compartirse con Penetrate Teleport.
 */
public final class TpMarkRenderType extends RenderType {
    public static final int FRAMES = 7;

    private static final Function<Integer, RenderType> MARK = Util.memoize(frame -> create(
            "railgunreborn_tp_mark_" + frame,
            DefaultVertexFormat.NEW_ENTITY,
            VertexFormat.Mode.QUADS,
            1536,
            true,
            true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_SHADER)
                    .setTextureState(new TextureStateShard(texture(frame), false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setLightmapState(LIGHTMAP)
                    .setOverlayState(OVERLAY)
                    .setDepthTestState(NO_DEPTH_TEST)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false)));

    private TpMarkRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }

    public static ResourceLocation texture(int frame) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/tp_mark/" + frame + ".png");
    }

    /** Render type del fotograma {@code frame} (0..6). */
    public static RenderType mark(int frame) {
        return MARK.apply(Math.floorMod(frame, FRAMES));
    }
}
