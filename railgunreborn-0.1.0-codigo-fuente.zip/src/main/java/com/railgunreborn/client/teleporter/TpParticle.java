package com.railgunreborn.client.teleporter;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/**
 * Mota de teletransporte ({@code TPParticleFactory} del original, {@code threatening-teleport.md} §9.2): tamaño
 * 0.1-0.2, alfa 153-204 sobre 255 sin fundido de entrada, se mantiene 20 ticks y se desvanece otros 20. Sin gravedad
 * ni colisión, a plena luz. La velocidad inicial la pone quien la crea.
 */
public final class TpParticle extends TextureSheetParticle {
    private static final int HOLD_TICKS = 20;
    private static final int FADE_TICKS = 20;

    private final float baseAlpha;

    private TpParticle(ClientLevel level, double x, double y, double z, double xd, double yd, double zd) {
        super(level, x, y, z);
        this.xd = xd;
        this.yd = yd;
        this.zd = zd;
        this.gravity = 0f;
        this.friction = 1f;
        this.hasPhysics = false;
        this.lifetime = HOLD_TICKS + FADE_TICKS;
        this.baseAlpha = (153 + random.nextInt(52)) / 255f;
        this.alpha = baseAlpha;
        this.quadSize = 0.1f + random.nextFloat() * 0.1f;
    }

    @Override
    public void tick() {
        super.tick();
        alpha = baseAlpha * Mth.clamp((lifetime - age) / (float) FADE_TICKS, 0f, 1f);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    /** Registro del proveedor (bus del MOD, solo cliente). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        private Registration() {
        }

        @SubscribeEvent
        public static void register(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.TP.get(), Provider::new);
        }
    }

    private record Provider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                double xd, double yd, double zd) {
            TpParticle particle = new TpParticle(level, x, y, z, xd, yd, zd);
            particle.pickSprite(sprites);
            return particle;
        }
    }
}
