package com.railgunreborn.client.teleporter;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.effect.TargetMarkerRenderer;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.teleporter.ThreateningRules;
import com.railgunreborn.ability.teleporter.ThreateningTeleportSkill;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Efectos de cliente de Threatening Teleport: sonido y hilera de motas desde el pecho del lanzador hasta donde cae el
 * ítem (el servidor manda el punto exacto: sin los desfases del original).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ThreateningClient {
    /** El servidor manda puntos reales; más lejos que esto no viene de un disparo legítimo. */
    private static final double MAX_DISTANCE = 40.0;

    private ThreateningClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Teleporter.THREATENING_TELEPORT.getId(), ThreateningClient::effect);
        ClientSkillContexts.registerFactory(Teleporter.THREATENING_TELEPORT.getId(), AimContext::new);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!ThreateningTeleportSkill.CHANNEL_EXECUTE.equals(channel)) {
            return;
        }
        Vec3 to = ElectronBombSkill.readVec(data.getCompound(ThreateningTeleportSkill.POS_KEY));
        Vec3 from = caster.getEyePosition().subtract(0, 0.4, 0);
        if (from.distanceTo(to) > MAX_DISTANCE) {
            return;
        }
        var level = caster.level();
        level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(), ModSounds.TP.get(), SoundSource.PLAYERS,
                ThreateningRules.SOUND_VOLUME, 1.0f, false);

        // Una mota cada 1-2 bloques, la primera a 1.
        var random = caster.getRandom();
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < 1.0e-3) {
            return;
        }
        Vec3 dir = delta.scale(1.0 / length);
        for (double d = 1.0; d <= length; d += 1.0 + random.nextDouble()) {
            Vec3 p = from.add(dir.scale(d));
            level.addParticle(ModParticles.TP.get(), p.x, p.y, p.z,
                    (random.nextDouble() * 2 - 1) * 0.02, -0.02 + random.nextDouble() * 0.07,
                    (random.nextDouble() * 2 - 1) * 0.02);
        }
    }

    /** Mitad local: mientras se mantiene, marca el objetivo apuntado con el mismo trazado que usa el servidor. */
    private static final class AimContext extends ClientSkillContext {
        private float exp;

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            TargetMarkerRenderer.show(this, this::marker);
        }

        @Nullable
        private TargetMarkerRenderer.Marker marker(float partialTick) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null || isTerminated()) {
                return null;
            }
            ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
            if (held.isEmpty()
                    || AbilityData.get(player).isNeedleOnly() && !held.is(ModItems.NEEDLE.get())) {
                return null;
            }
            Vec3 eye = player.getEyePosition(partialTick);
            Vec3 end = eye.add(player.getViewVector(partialTick).scale(ThreateningRules.range(exp)));
            ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, eye, end);
            return TargetMarkerRenderer.forTarget(player, hit.entity(), hit.end(), partialTick);
        }

        @Override
        protected void onKeyUp() {
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onKeyAbort() {
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onTerminated() {
            TargetMarkerRenderer.hide(this);
        }
    }
}
