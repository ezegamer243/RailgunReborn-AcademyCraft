package com.railgunreborn.client.teleporter;

import java.util.Locale;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.teleporter.PenetrateRules;
import com.railgunreborn.ability.teleporter.PenetrateTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Penetrate Teleport: mientras se mantiene la tecla, la rueda ajusta la distancia (sin cambiar la ranura de
 * la barra) y se ve la silueta del destino con la distancia encima, solo para el que la usa. Al teletransportarse,
 * sonido y motas en el origen y el destino para todos los cercanos. Bus del juego; el registro va en {@link Setup}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class PenetrateClient {
    /** Más lejos que esto no viene de un teletransporte legítimo (35 + posarse en el suelo). */
    private static final double MAX_EFFECT_DISTANCE = 45.0;
    private static final float MARK_PARTICLE_CHANCE = 0.4f;
    private static final int BURST_PARTICLES = 12;
    private static final int LABEL_COLOR = 0xFFFFFFFF;
    private static final int LABEL_COLOR_BAD = 0xFFFF3333;

    @Nullable
    private static AimContext aiming;

    private PenetrateClient() {
    }

    /** Registro (bus del MOD). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class Setup {
        private Setup() {
        }

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            SkillEffects.register(Teleporter.PENETRATE_TELEPORT.getId(), PenetrateClient::effect);
            ClientSkillContexts.registerFactory(Teleporter.PENETRATE_TELEPORT.getId(), AimContext::new);
        }
    }

    // --- Efecto para todos ---

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!PenetrateTeleportSkill.CHANNEL_TELEPORT.equals(channel)) {
            return;
        }
        Vec3 from = MagMovementSkill.readVec(data, PenetrateTeleportSkill.FROM_KEY);
        Vec3 to = MagMovementSkill.readVec(data, PenetrateTeleportSkill.TO_KEY);
        if (from == null || to == null || from.distanceTo(to) > MAX_EFFECT_DISTANCE) {
            return;
        }
        Level level = caster.level();
        for (Vec3 at : new Vec3[] {from, to}) {
            level.playLocalSound(at.x, at.y, at.z, ModSounds.TP.get(), SoundSource.PLAYERS,
                    PenetrateRules.SOUND_VOLUME, 1.0f, false);
            for (int i = 0; i < BURST_PARTICLES; i++) {
                bodyParticle(level, caster.getRandom(), at);
            }
        }
    }

    /** Mota en una caja de ±1 en horizontal y 0.2-1.6 de alto sobre los pies, subiendo despacio. */
    private static void bodyParticle(Level level, RandomSource random, Vec3 feet) {
        level.addParticle(ModParticles.TP.get(),
                feet.x + (random.nextDouble() * 2 - 1), feet.y + 0.2 + random.nextDouble() * 1.4,
                feet.z + (random.nextDouble() * 2 - 1),
                (random.nextDouble() * 2 - 1) * 0.03, random.nextDouble() * 0.05,
                (random.nextDouble() * 2 - 1) * 0.03);
    }

    // --- Mitad local: distancia y silueta ---

    private static final class AimContext extends ClientSkillContext {
        float exp;
        double requested;
        double wheelRemainder;
        Vec3 point = Vec3.ZERO;
        Vec3 prevPoint = Vec3.ZERO;
        boolean available;
        int age;

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            requested = PenetrateRules.maxDistance(exp);
            update(player);
            prevPoint = point;
            aiming = this;
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (aiming != this || player == null) {
                return;
            }
            if (!isKeyHeld()) {
                aiming = null;
                return;
            }
            age++;
            prevPoint = point;
            update(player);
            if (available && player.getRandom().nextFloat() < MARK_PARTICLE_CHANCE) {
                bodyParticle(player.level(), player.getRandom(), point);
            }
        }

        private void update(LocalPlayer player) {
            PenetrateTeleportSkill skill = (PenetrateTeleportSkill) getSkill();
            double distance = skill.reachable(player, requested, exp);
            if (distance < PenetrateRules.MIN_DISTANCE) {
                point = player.position();
                available = false;
                return;
            }
            PenetrateRules.Dest dest = PenetrateTeleportSkill.findDestination(player.level(), player, distance);
            point = new Vec3(dest.x(), dest.y(), dest.z());
            // Aproximación del cliente: el servidor además puede retroceder un poco o posar en el suelo.
            available = dest.available()
                    && player.level().noCollision(player, SafeTeleport.boxAt(player, point));
        }

        void scroll(double delta) {
            wheelRemainder += delta;
            int notches = (int) wheelRemainder;
            if (notches == 0) {
                return;
            }
            wheelRemainder -= notches;
            double next = PenetrateRules.wheel(requested, notches, exp);
            if (next != requested) {
                requested = next;
                CompoundTag data = new CompoundTag();
                data.putDouble(PenetrateTeleportSkill.DISTANCE_KEY, requested);
                sendToServer(PenetrateTeleportSkill.CHANNEL_DISTANCE, data);
            }
        }

        @Override
        protected void onKeyUp() {
            stopAiming();
        }

        @Override
        protected void onKeyAbort() {
            stopAiming();
        }

        @Override
        protected void onTerminated() {
            stopAiming();
        }

        private void stopAiming() {
            if (aiming == this) {
                aiming = null;
            }
        }
    }

    /** La rueda es de la habilidad mientras se mantiene la tecla: no cambia la ranura de la barra de objetos. */
    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        AimContext current = aiming;
        if (current == null || current.isTerminated() || !current.isKeyHeld()) {
            return;
        }
        event.setCanceled(true);
        current.scroll(event.getScrollDeltaY());
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        AimContext current = aiming;
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null
                || current.isTerminated()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.level == null || player == null) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 at = current.prevPoint.lerp(current.point, partialTick).subtract(event.getCamera().getPosition());
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();

        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        poseStack.translate(at.x, at.y, at.z);
        PenetrateSilhouette.render(poseStack, buffers, current.age + partialTick, player.getViewYRot(partialTick),
                player.getViewXRot(partialTick), current.available);

        // Distancia pedida encima de la silueta, siempre de cara a la cámara.
        poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        poseStack.translate(at.x, at.y + 2.3, at.z);
        poseStack.mulPose(event.getCamera().rotation());
        poseStack.scale(0.025f, -0.025f, 0.025f);
        Component label = Component.translatable("railgunreborn.teleporter.distance",
                String.format(Locale.ROOT, "%.1f", current.requested));
        Font font = mc.font;
        font.drawInBatch(label, -font.width(label) / 2f, 0, current.available ? LABEL_COLOR : LABEL_COLOR_BAD, false,
                poseStack.last().pose(), buffers, Font.DisplayMode.SEE_THROUGH, 0x40000000, 0xF000F0);
        buffers.endBatch();
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        aiming = null;
    }

    @SubscribeEvent
    public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
        aiming = null;
    }
}
