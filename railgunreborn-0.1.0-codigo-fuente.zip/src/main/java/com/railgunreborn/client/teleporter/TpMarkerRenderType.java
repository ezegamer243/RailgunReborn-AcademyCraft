package com.railgunreborn.client.teleporter;

import java.util.OptionalDouble;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.RenderType;

/**
 * Líneas de los marcadores de Teleporter ({@code RenderMarker} del original): grosor 3, mezcla alfa, <b>sin test de
 * profundidad</b> (se ven a través de las paredes) y sin escribir profundidad. Shader de líneas de vanilla: cada
 * vértice lleva como normal la dirección del segmento. Hereda de {@link RenderType} solo para acceder a los "shards";
 * nunca se instancia.
 */
public final class TpMarkerRenderType extends RenderType {
    public static final RenderType LINES = create(
            "railgunreborn_tp_marker",
            DefaultVertexFormat.POSITION_COLOR_NORMAL,
            VertexFormat.Mode.LINES,
            1536,
            false,
            false,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_LINES_SHADER)
                    .setLineState(new LineStateShard(OptionalDouble.of(3.0)))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setDepthTestState(NO_DEPTH_TEST)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));

    private TpMarkerRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
