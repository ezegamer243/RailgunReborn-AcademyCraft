package com.railgunreborn.client.teleporter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.teleporter.MarkTeleportRules;
import com.railgunreborn.ability.teleporter.MarkTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Mark Teleport ({@code mark-teleport.md} §9 con las decisiones): mientras se mantiene, silueta translúcida
 * en el destino real (pies en el punto de llegada, roja si no hay hueco seguro) con motas alrededor, solo para el
 * jugador local; el contorno del icono muestra cuánto falta para el alcance máximo. Al teletransportar, sonido y motas
 * en el origen y el destino para los cercanos. Este bloque es del bus del MOD (registro); el dibujo va en
 * {@link Render} (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class MarkTeleportClient {
    /** El servidor manda puntos reales; más lejos que esto no viene de un uso legítimo. */
    private static final double MAX_DISTANCE = 70.0;
    private static final int BURST_PARTICLES = 16;
    private static final float MARK_ALPHA = 0.75f;
    private static final int OUTLINE_COLOR = 0xFF8FD8F0;
    /** Ticks de fotograma de la silueta. */
    private static final float FRAME_TICKS = 2.5f;

    /** Se mantiene lleno mientras se siga pulsando: el tope solo evita que se quede colgado. */
    private static final ChargeTracker TRACKER = new ChargeTracker(20 * 60);
    /** El tiempo hasta el alcance máximo depende de la exp: un contorno por duración, reemplazado al pulsar. */
    private static final Map<Integer, ChargeOutline> OUTLINES = new ConcurrentHashMap<>();

    /** Contexto local que está apuntando, o null. */
    @Nullable
    private static AimContext aiming;
    @Nullable
    private static HumanoidModel<LivingEntity> model;

    private MarkTeleportClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Teleporter.MARK_TELEPORT.getId(), MarkTeleportClient::effect);
        ClientSkillContexts.registerFactory(Teleporter.MARK_TELEPORT.getId(), AimContext::new);
        KeyHintHud.registerChargeOutline(Teleporter.MARK_TELEPORT.getId(), TRACKER,
                outline(MarkTeleportRules.ticksToMaxRange(0f)));
    }

    static ChargeOutline outline(int ticksToMax) {
        int total = Math.max(1, ticksToMax);
        return OUTLINES.computeIfAbsent(total, t -> ChargeOutline.builder(t).band(t, OUTLINE_COLOR).build());
    }

    // --- Efecto para los cercanos ---

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!MarkTeleportSkill.CHANNEL_TELEPORT.equals(channel)) {
            return;
        }
        Vec3 from = MagMovementSkill.readVec(data, MarkTeleportSkill.FROM_KEY);
        Vec3 to = MagMovementSkill.readVec(data, MarkTeleportSkill.TO_KEY);
        if (from == null || to == null || from.distanceTo(to) > MAX_DISTANCE) {
            return;
        }
        Level level = caster.level();
        for (Vec3 at : new Vec3[] {from, to}) {
            level.playLocalSound(at.x, at.y, at.z, ModSounds.TP.get(), SoundSource.PLAYERS,
                    MarkTeleportRules.SOUND_VOLUME, 1.0f, false);
            burst(level, caster.getRandom(), at);
        }
    }

    /** Motas en el volumen del cuerpo, subiendo despacio. */
    private static void burst(Level level, RandomSource random, Vec3 feet) {
        for (int i = 0; i < BURST_PARTICLES; i++) {
            level.addParticle(ModParticles.TP.get(),
                    feet.x + (random.nextDouble() - 0.5), feet.y + random.nextDouble() * 1.8,
                    feet.z + (random.nextDouble() - 0.5),
                    (random.nextDouble() * 2 - 1) * 0.03, random.nextDouble() * 0.05,
                    (random.nextDouble() * 2 - 1) * 0.03);
        }
    }

    // --- Apuntado local ---

    private static final class AimContext extends ClientSkillContext {
        float exp;
        int heldTicks;
        int age;
        MarkTeleportSkill.Aim aim;
        Vec3 prevFeet = Vec3.ZERO;

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            update(player);
            prevFeet = aim.feet();
            aiming = this;
            KeyHintHud.registerChargeOutline(Teleporter.MARK_TELEPORT.getId(), TRACKER,
                    outline(MarkTeleportRules.ticksToMaxRange(exp)));
            TRACKER.start();
        }

        private void update(LocalPlayer player) {
            aim = MarkTeleportSkill.aim(player, MarkTeleportRules.rangeNow(exp, heldTicks,
                    MarkTeleportSkill.cpBudget(player, getSkill())));
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (aiming != this || player == null) {
                return;
            }
            if (!isKeyHeld()) {
                stopAiming();
                return;
            }
            heldTicks++;
            age++;
            prevFeet = aim.feet();
            update(player);
            // Motas alrededor de la silueta (40 % por tick, como el original), solo si el destino vale.
            RandomSource random = player.getRandom();
            if (aim.status() == MarkTeleportSkill.Status.OK && random.nextFloat() < 0.4f) {
                Vec3 feet = aim.feet();
                player.level().addParticle(ModParticles.TP.get(),
                        feet.x + (random.nextDouble() * 2 - 1), feet.y + 0.2 + random.nextDouble() * 1.4,
                        feet.z + (random.nextDouble() * 2 - 1),
                        (random.nextDouble() * 2 - 1) * 0.03, random.nextDouble() * 0.05,
                        (random.nextDouble() * 2 - 1) * 0.03);
            }
        }

        @Override
        protected void onKeyUp() {
            stopAiming();
        }

        @Override
        protected void onKeyAbort() {
            stopAiming();
        }

        @Override
        protected void onTerminated() {
            stopAiming();
        }

        private void stopAiming() {
            if (aiming == this) {
                aiming = null;
                TRACKER.end();
            }
        }
    }

    // --- Silueta ---

    private static HumanoidModel<LivingEntity> model() {
        if (model == null) {
            // Las texturas tp_mark tienen el formato de piel antiguo (64x32, a 4x).
            model = new HumanoidModel<>(LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0f), 64,
                    32).bakeRoot());
        }
        return model;
    }

    /** Dibujo y limpieza (bus del juego). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
    public static final class Render {
        private Render() {
        }

        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            AimContext current = aiming;
            if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null
                    || current.isTerminated() || current.aim == null
                    || current.aim.status() == MarkTeleportSkill.Status.TOO_SHORT) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (mc.level == null || player == null) {
                return;
            }
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            Vec3 feet = current.prevFeet.lerp(current.aim.feet(), partialTick);
            Vec3 at = feet.subtract(event.getCamera().getPosition());

            // En AFTER_LEVEL la vista no está en el estado de render: se aplica a mano, como Jet Engine.
            PoseStack poseStack = new PoseStack();
            poseStack.mulPose(event.getModelViewMatrix());
            poseStack.translate(at.x, at.y, at.z);
            poseStack.mulPose(Axis.YP.rotationDegrees(180f - player.getViewYRot(partialTick)));
            // Mismo cambio de ejes que LivingEntityRenderer.
            poseStack.scale(-1f, -1f, 1f);
            poseStack.translate(0f, -1.501f, 0f);

            HumanoidModel<LivingEntity> humanoid = model();
            humanoid.head.xRot = player.getViewXRot(partialTick) * Mth.DEG_TO_RAD;
            humanoid.hat.xRot = humanoid.head.xRot;

            boolean valid = current.aim.status() == MarkTeleportSkill.Status.OK;
            int alpha = (int) (MARK_ALPHA * 255f);
            int color = (alpha << 24) | (valid ? 0xFFFFFF : 0xFF5050);
            int frame = (int) ((current.age + partialTick) / FRAME_TICKS);
            RenderType type = TpMarkRenderType.mark(frame);
            MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
            humanoid.renderToBuffer(poseStack, buffers.getBuffer(type), 0xF000F0, OverlayTexture.NO_OVERLAY, color);
            buffers.endBatch(type);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            aiming = null;
        }

        /** Morir o cambiar de dimensión recrea el jugador local: la silueta se corta. */
        @SubscribeEvent
        public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
            aiming = null;
        }
    }
}
