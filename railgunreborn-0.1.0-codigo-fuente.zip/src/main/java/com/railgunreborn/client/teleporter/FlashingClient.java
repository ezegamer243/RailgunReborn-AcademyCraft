package com.railgunreborn.client.teleporter;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.teleporter.FlashingRules;
import com.railgunreborn.ability.teleporter.FlashingSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Flashing ({@code flashing.md} con las decisiones): mientras vive el modo, mantener W/A/S/D (las teclas de
 * movimiento configuradas) muestra la silueta del destino y soltarla pide el salto al servidor; gana la última
 * dirección pulsada. Volver a pulsar la tecla de la habilidad o V termina el modo. El contorno del icono se llena con
 * el tiempo gastado (rojo parpadeante al final). Tras cada salto, ~2 s de casi-flotación. Este bloque es del bus del
 * MOD (registro); tick y dibujo van en {@link Game} (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class FlashingClient {
    private static final int LONGEST = FlashingRules.maxTicks(1f);
    private static final int WARNING_TICKS = 20;
    private static final int OUTLINE_COLOR = 0xFF8FD8F0;
    private static final int WARNING_COLOR = 0xFFFF4A3A;
    /** El servidor manda puntos reales; más lejos que esto no viene de un uso legítimo. */
    private static final double MAX_DISTANCE = 25.0;
    private static final int BURST_PARTICLES = 12;
    private static final float MARK_ALPHA = 0.75f;
    private static final float FRAME_TICKS = 2.5f;

    private static final ChargeTracker TRACKER = new ChargeTracker(LONGEST + 1);
    /** El tiempo máximo depende de la exp: un contorno por duración, reemplazado al arrancar. */
    private static final Map<Integer, ChargeOutline> OUTLINES = new ConcurrentHashMap<>();

    /** Modo vivo del jugador local, o null. */
    @Nullable
    private static FlashContext current;
    /** Ticks de flotación que quedan; siguen aunque el modo termine. */
    private static int hoverTicks;
    @Nullable
    private static HumanoidModel<LivingEntity> model;

    private FlashingClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Teleporter.FLASHING.getId(), FlashingClient::effect);
        ClientSkillContexts.registerFactory(Teleporter.FLASHING.getId(), FlashContext::new);
        KeyHintHud.registerChargeOutline(Teleporter.FLASHING.getId(), TRACKER, outline(FlashingRules.maxTicks(0f)));
    }

    static ChargeOutline outline(int maxTicks) {
        int total = Math.max(maxTicks + 1, WARNING_TICKS + 1);
        return OUTLINES.computeIfAbsent(total, t -> ChargeOutline.builder(t)
                .band(t - WARNING_TICKS, OUTLINE_COLOR)
                .band(t, WARNING_COLOR)
                .warningFrom(t - WARNING_TICKS)
                .build());
    }

    // --- Efecto para los cercanos ---

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!FlashingSkill.CHANNEL_PERFORM.equals(channel)) {
            return;
        }
        Vec3 from = MagMovementSkill.readVec(data, FlashingSkill.FROM_KEY);
        Vec3 to = MagMovementSkill.readVec(data, FlashingSkill.TO_KEY);
        if (from == null || to == null || from.distanceTo(to) > MAX_DISTANCE) {
            return;
        }
        Level level = caster.level();
        level.playLocalSound(to.x, to.y, to.z, ModSounds.TP_FLASHING.get(), SoundSource.PLAYERS,
                FlashingRules.SOUND_VOLUME, 1.0f, false);
        burst(level, caster.getRandom(), from);
        burst(level, caster.getRandom(), to);
    }

    private static void burst(Level level, RandomSource random, Vec3 feet) {
        for (int i = 0; i < BURST_PARTICLES; i++) {
            level.addParticle(ModParticles.TP.get(),
                    feet.x + (random.nextDouble() - 0.5), feet.y + random.nextDouble() * 1.8,
                    feet.z + (random.nextDouble() - 0.5),
                    (random.nextDouble() * 2 - 1) * 0.03, random.nextDouble() * 0.05,
                    (random.nextDouble() * 2 - 1) * 0.03);
        }
    }

    // --- Modo local ---

    private static final class FlashContext extends ClientSkillContext {
        private float exp;
        private boolean started;
        /** Estado de W/A/S/D el tick anterior, en el orden de {@link FlashingRules.Dir}. */
        private final boolean[] wasDown = new boolean[4];
        /** Dirección que saltará al soltarse (la última pulsada), o null. */
        @Nullable
        private FlashingRules.Dir performing;
        @Nullable
        private Vec3 aim;
        private Vec3 prevAim = Vec3.ZERO;
        private int age;

        FlashContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null) {
                exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            }
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (FlashingSkill.CHANNEL_START.equals(channel)) {
                started = true;
                current = this;
                int maxTicks = Math.clamp(data.getInt(FlashingSkill.MAX_TICKS_KEY), 1, LONGEST);
                KeyHintHud.registerChargeOutline(Teleporter.FLASHING.getId(), TRACKER, outline(maxTicks));
                TRACKER.start();
                // Lo que ya estuviera pulsado al arrancar no cuenta como pulsación nueva.
                readKeys(wasDown);
            } else if (FlashingSkill.CHANNEL_JUMP.equals(channel)) {
                hoverTicks = FlashingRules.HOVER_TICKS;
                LocalPlayer player = Minecraft.getInstance().player;
                if (player != null && player.getDeltaMovement().y < 0) {
                    Vec3 dm = player.getDeltaMovement();
                    player.setDeltaMovement(dm.x, 0, dm.z);
                }
            }
        }

        // Volver a pulsar la tecla o V cierra el modo: lo hace ClientSkillContext por ser interruptor (isToggle).

        @Override
        protected void tick() {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (!started || player == null) {
                return;
            }
            age++;
            boolean[] down = new boolean[4];
            readKeys(down);
            if (mc.screen != null) {
                // Abrir una pantalla suelta las teclas: cancela el salto pendiente en vez de hacerlo.
                performing = null;
            } else {
                for (FlashingRules.Dir dir : FlashingRules.Dir.values()) {
                    int i = dir.id();
                    if (down[i] && !wasDown[i]) {
                        performing = dir;
                    } else if (!down[i] && wasDown[i] && performing == dir) {
                        performing = null;
                        if (canPay(player)) {
                            CompoundTag data = new CompoundTag();
                            data.putInt(FlashingSkill.DIR_KEY, dir.id());
                            sendToServer(FlashingSkill.CHANNEL_JUMP, data);
                        }
                    }
                }
            }
            System.arraycopy(down, 0, wasDown, 0, down.length);
            if (performing != null && !canPay(player)) {
                performing = null;
            }
            updateAim(player);
        }

        private boolean canPay(LocalPlayer player) {
            return CPData.get(player).canConsume(player, 0f,
                    FlashingRules.jumpCp(exp) * getSkill().getCpConsumeSpeed());
        }

        private void updateAim(LocalPlayer player) {
            if (performing == null) {
                aim = null;
                return;
            }
            Optional<Vec3> dest = FlashingSkill.destination(player, performing, FlashingRules.distance(exp));
            Vec3 next = dest.orElse(null);
            prevAim = aim != null ? aim : next != null ? next : Vec3.ZERO;
            aim = next;
            RandomSource random = player.getRandom();
            if (aim != null && random.nextFloat() < 0.4f) {
                player.level().addParticle(ModParticles.TP.get(),
                        aim.x + (random.nextDouble() * 2 - 1), aim.y + 0.2 + random.nextDouble() * 1.4,
                        aim.z + (random.nextDouble() * 2 - 1),
                        (random.nextDouble() * 2 - 1) * 0.03, random.nextDouble() * 0.05,
                        (random.nextDouble() * 2 - 1) * 0.03);
            }
        }

        @Override
        protected void onTerminated() {
            performing = null;
            aim = null;
            if (current == this) {
                current = null;
            }
            if (started) {
                TRACKER.end();
            }
        }
    }

    private static void readKeys(boolean[] out) {
        var options = Minecraft.getInstance().options;
        KeyMapping[] keys = new KeyMapping[4];
        keys[FlashingRules.Dir.LEFT.id()] = options.keyLeft;
        keys[FlashingRules.Dir.RIGHT.id()] = options.keyRight;
        keys[FlashingRules.Dir.FORWARD.id()] = options.keyUp;
        keys[FlashingRules.Dir.BACK.id()] = options.keyDown;
        for (int i = 0; i < keys.length; i++) {
            out[i] = keys[i].isDown();
        }
    }

    private static HumanoidModel<LivingEntity> model() {
        if (model == null) {
            // Las texturas tp_mark tienen el formato de piel antiguo (64x32).
            model = new HumanoidModel<>(LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0f), 64,
                    32).bakeRoot());
        }
        return model;
    }

    /** Flotación, silueta y limpieza (bus del juego). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
    public static final class Game {
        private Game() {
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (player == null) {
                hoverTicks = 0;
                return;
            }
            if (mc.isPaused() || hoverTicks <= 0) {
                return;
            }
            hoverTicks--;
            if (!player.getAbilities().flying && !player.onGround()) {
                Vec3 dm = player.getDeltaMovement();
                player.setDeltaMovement(dm.x, dm.y + FlashingRules.HOVER_BOOST, dm.z);
            }
        }

        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            FlashContext ctx = current;
            if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || ctx == null || ctx.isTerminated()
                    || ctx.aim == null) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (mc.level == null || player == null) {
                return;
            }
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            Vec3 feet = ctx.prevAim.lerp(ctx.aim, partialTick);
            Vec3 at = feet.subtract(event.getCamera().getPosition());

            // Igual que la silueta de Mark Teleport: la vista se aplica a mano en AFTER_LEVEL.
            PoseStack poseStack = new PoseStack();
            poseStack.mulPose(event.getModelViewMatrix());
            poseStack.translate(at.x, at.y, at.z);
            poseStack.mulPose(Axis.YP.rotationDegrees(180f - player.getViewYRot(partialTick)));
            poseStack.scale(-1f, -1f, 1f);
            poseStack.translate(0f, -1.501f, 0f);

            HumanoidModel<LivingEntity> humanoid = model();
            humanoid.head.xRot = player.getViewXRot(partialTick) * Mth.DEG_TO_RAD;
            humanoid.hat.xRot = humanoid.head.xRot;

            int color = ((int) (MARK_ALPHA * 255f) << 24) | 0xFFFFFF;
            int frame = (int) ((ctx.age + partialTick) / FRAME_TICKS);
            RenderType type = TpMarkRenderType.mark(frame);
            MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
            humanoid.renderToBuffer(poseStack, buffers.getBuffer(type), 0xF000F0, OverlayTexture.NO_OVERLAY, color);
            buffers.endBatch(type);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            current = null;
            hoverTicks = 0;
        }

        /** Morir o cambiar de dimensión recrea el jugador local: se corta la flotación. */
        @SubscribeEvent
        public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
            current = null;
            hoverTicks = 0;
        }
    }
}
