package com.railgunreborn.client.teleporter;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/**
 * Fórmula del crítico de espacio ({@code FormulaParticleFactory} del original, {@code space-criticals.md} §5) con el
 * tamaño de la decisión: 0.4-0.7 bloques de lado (el original medía 1-1.7 y tapaba), alfa 130-230, gris claro, a plena
 * luz. Aparece en 2 ticks, vive 10-15 y se desvanece en 20 más. Textura al azar entre las 10 del {@code SpriteSet}.
 */
public final class FormulaParticle extends TextureSheetParticle {
    private static final int FADE_IN = 2;
    private static final int FADE_OUT = 20;

    private final float baseAlpha;
    private final int visibleTicks;

    private FormulaParticle(ClientLevel level, double x, double y, double z, double xd, double yd, double zd) {
        super(level, x, y, z);
        this.xd = xd;
        this.yd = yd;
        this.zd = zd;
        this.gravity = 0f;
        this.friction = 1f;
        this.hasPhysics = false;
        this.visibleTicks = 10 + random.nextInt(6);
        this.lifetime = visibleTicks + FADE_OUT;
        this.baseAlpha = (130 + random.nextInt(101)) / 255f;
        this.alpha = 0f;
        // quadSize es la mitad del lado.
        this.quadSize = (0.4f + random.nextFloat() * 0.3f) / 2f;
        float gray = 220f / 255f;
        setColor(gray, gray, gray);
    }

    @Override
    public void tick() {
        super.tick();
        float fade;
        if (age < FADE_IN) {
            fade = age / (float) FADE_IN;
        } else if (age <= visibleTicks) {
            fade = 1f;
        } else {
            fade = 1f - (age - visibleTicks) / (float) FADE_OUT;
        }
        alpha = baseAlpha * Mth.clamp(fade, 0f, 1f);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    /** Registro del proveedor (bus del MOD, solo cliente). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        private Registration() {
        }

        @SubscribeEvent
        public static void register(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.FORMULA.get(), Provider::new);
        }
    }

    private record Provider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                double xd, double yd, double zd) {
            FormulaParticle particle = new FormulaParticle(level, x, y, z, xd, yd, zd);
            particle.pickSprite(sprites);
            return particle;
        }
    }
}
