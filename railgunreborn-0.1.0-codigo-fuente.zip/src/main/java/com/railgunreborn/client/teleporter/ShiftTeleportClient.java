package com.railgunreborn.client.teleporter;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.teleporter.ShiftTeleportRules;
import com.railgunreborn.ability.teleporter.ShiftTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.TargetMarkerRenderer;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Shift Teleport ({@code shift-teleport.md} §8): mientras se mantiene, solo el jugador local ve las esquinas
 * grises de la celda destino y las rojas de cada ser vivo de la línea (sin profundidad, con vaivén), con el mismo
 * cálculo que el servidor. Al ejecutar, los cercanos ven motas a lo largo de la línea (el sonido lo pone el
 * servidor). Este bloque es del bus del MOD (registro); el dibujo va en {@link Render} (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ShiftTeleportClient {
    /** El servidor manda puntos reales; más lejos que esto no viene de un uso legítimo. */
    private static final double MAX_DISTANCE = 40.0;
    private static final double BLOCK_MARKER_SIZE = 1.2;

    /** Contexto local que está apuntando, o null. */
    @Nullable
    private static AimContext aiming;

    private ShiftTeleportClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Teleporter.SHIFT_TP.getId(), ShiftTeleportClient::effect);
        ClientSkillContexts.registerFactory(Teleporter.SHIFT_TP.getId(), AimContext::new);
    }

    // --- Efecto para los cercanos ---

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!ShiftTeleportSkill.CHANNEL_EXECUTE.equals(channel)) {
            return;
        }
        Vec3 from = MagMovementSkill.readVec(data, ShiftTeleportSkill.FROM_KEY);
        Vec3 to = MagMovementSkill.readVec(data, ShiftTeleportSkill.TO_KEY);
        if (from == null || to == null || from.distanceTo(to) > MAX_DISTANCE) {
            return;
        }
        Level level = caster.level();
        RandomSource random = caster.getRandom();
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < 1.0e-3) {
            return;
        }
        Vec3 dir = delta.scale(1.0 / length);
        for (double d = 0.0; d <= length; d += ShiftTeleportRules.PARTICLE_STEP_MIN
                + random.nextDouble() * ShiftTeleportRules.PARTICLE_STEP_SPREAD) {
            Vec3 p = from.add(dir.scale(d));
            level.addParticle(ModParticles.TP.get(), p.x, p.y, p.z,
                    (random.nextDouble() * 2 - 1) * 0.05, -0.02 + random.nextDouble() * 0.07,
                    (random.nextDouble() * 2 - 1) * 0.05);
        }
    }

    // --- Apuntado local ---

    private static final class AimContext extends ClientSkillContext {
        float exp;
        int age;
        @Nullable
        ShiftTeleportSkill.Aim aim;
        List<LivingEntity> targets = List.of();

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            aiming = this;
            update(player, true);
        }

        private void update(LocalPlayer player, boolean refreshTargets) {
            ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
            if (!ShiftTeleportSkill.isValidBlock(held)) {
                aim = null;
                targets = List.of();
                return;
            }
            aim = ShiftTeleportSkill.aim(player, held, ShiftTeleportRules.range(exp));
            if (refreshTargets) {
                targets = ShiftTeleportSkill.lineTargets(player, player.getEyePosition(), aim.center());
            }
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (aiming != this || player == null) {
                return;
            }
            if (!isKeyHeld()) {
                stopAiming();
                return;
            }
            age++;
            update(player, age % ShiftTeleportRules.MARKER_REFRESH_TICKS == 0);
        }

        @Override
        protected void onKeyUp() {
            stopAiming();
        }

        @Override
        protected void onKeyAbort() {
            stopAiming();
        }

        @Override
        protected void onTerminated() {
            stopAiming();
        }

        private void stopAiming() {
            if (aiming == this) {
                aiming = null;
            }
        }
    }

    // --- Marcadores ---

    /** Dibujo y limpieza (bus del juego). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
    public static final class Render {
        private Render() {
        }

        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            AimContext current = aiming;
            if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null
                    || current.isTerminated() || current.aim == null) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null) {
                return;
            }
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            List<TargetMarkerRenderer.Marker> markers = new ArrayList<>();
            Vec3 center = current.aim.center();
            double half = BLOCK_MARKER_SIZE / 2.0;
            markers.add(new TargetMarkerRenderer.Marker(new AABB(center.x - half, center.y - half, center.z - half,
                    center.x + half, center.y + half, center.z + half), TargetMarkerRenderer.GRAY_BLOCK));
            for (LivingEntity target : current.targets) {
                if (!target.isAlive()) {
                    continue;
                }
                Vec3 offset = target.getPosition(partialTick).subtract(target.position());
                markers.add(new TargetMarkerRenderer.Marker(target.getBoundingBox().move(offset),
                        TargetMarkerRenderer.RED));
            }
            TargetMarkerRenderer.draw(event, markers.toArray(new TargetMarkerRenderer.Marker[0]));
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            aiming = null;
        }

        /** Morir o cambiar de dimensión recrea el jugador local: los marcadores se quitan. */
        @SubscribeEvent
        public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
            aiming = null;
        }
    }
}
