package com.railgunreborn.client.teleporter;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.world.entity.LivingEntity;

/**
 * Silueta fantasma del destino ({@code EntityTPMarking} + {@code MarkRender} del original, ficha §8): modelo humanoide
 * básico con la textura animada {@code tp_mark/0..6} (cambia cada 2.5 ticks), girado como el jugador, translúcido, sin
 * culling y <b>sin test de profundidad</b> (se ve a través de los muros). Blanca si el destino vale, roja si no.
 * Hereda de {@link RenderType} solo para acceder a los "shards" protegidos; nunca se instancia.
 */
public final class PenetrateSilhouette extends RenderType {
    private static final int FRAMES = 7;
    private static final float TICKS_PER_FRAME = 2.5f;
    private static final int COLOR_OK = FastColor.ARGB32.colorFromFloat(1f, 1f, 1f, 1f);
    private static final int COLOR_BAD = FastColor.ARGB32.colorFromFloat(1f, 1f, 0.2f, 0.2f);

    private static final RenderType[] TYPES = new RenderType[FRAMES];
    private static HumanoidModel<LivingEntity> model;

    static {
        for (int i = 0; i < FRAMES; i++) {
            ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                    "textures/effect/tp_mark/" + i + ".png");
            TYPES[i] = create("railgunreborn_tp_silhouette_" + i, DefaultVertexFormat.NEW_ENTITY,
                    VertexFormat.Mode.QUADS, 1536, false, true,
                    CompositeState.builder()
                            .setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE_SHADER)
                            .setTextureState(new TextureStateShard(texture, false, false))
                            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                            .setCullState(NO_CULL)
                            .setDepthTestState(NO_DEPTH_TEST)
                            .setWriteMaskState(COLOR_WRITE)
                            .setOverlayState(OVERLAY)
                            .createCompositeState(false));
        }
    }

    private PenetrateSilhouette(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }

    /** Las texturas del original son 256x128: el formato antiguo de piel 64x32 a escala ×4. */
    private static HumanoidModel<LivingEntity> model() {
        if (model == null) {
            model = new HumanoidModel<>(
                    LayerDefinition.create(HumanoidModel.createMesh(CubeDeformation.NONE, 0f), 64, 32).bakeRoot());
        }
        return model;
    }

    /**
     * Dibuja la silueta con los pies en el origen de {@code poseStack} (ya relativo a la cámara) y termina su lote.
     *
     * @param ticks edad en ticks (con fracción) para la animación
     */
    public static void render(PoseStack poseStack, MultiBufferSource.BufferSource buffers, float ticks, float yaw,
            float pitch, boolean available) {
        HumanoidModel<LivingEntity> m = model();
        RenderType type = TYPES[Math.floorMod((int) (ticks / TICKS_PER_FRAME), FRAMES)];
        poseStack.pushPose();
        // Como LivingEntityRenderer: modelo colgando, invertido y girado como el jugador.
        poseStack.mulPose(Axis.YP.rotationDegrees(180f - yaw));
        poseStack.scale(-1f, -1f, 1f);
        poseStack.translate(0f, -1.501f, 0f);
        m.head.xRot = pitch * ((float) Math.PI / 180f);
        m.head.yRot = 0f;
        m.hat.copyFrom(m.head);
        m.renderToBuffer(poseStack, buffers.getBuffer(type), 0xF000F0, OverlayTexture.NO_OVERLAY,
                available ? COLOR_OK : COLOR_BAD);
        poseStack.popPose();
        buffers.endBatch(type);
    }
}
