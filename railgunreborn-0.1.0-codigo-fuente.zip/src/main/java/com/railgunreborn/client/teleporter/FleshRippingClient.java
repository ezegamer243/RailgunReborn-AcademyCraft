package com.railgunreborn.client.teleporter;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.effect.TargetMarkerRenderer;
import com.railgunreborn.ability.teleporter.FleshRippingRules;
import com.railgunreborn.ability.teleporter.FleshRippingSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.BloodSplashEffects;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/** Efectos de Flesh Ripping para los jugadores cercanos: sangre sobre el objetivo y sonido {@code guts}. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class FleshRippingClient {
    private FleshRippingClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Teleporter.FLESH_RIPPING.getId(), FleshRippingClient::effect);
        ClientSkillContexts.registerFactory(Teleporter.FLESH_RIPPING.getId(), AimContext::new);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!FleshRippingSkill.CHANNEL_RIP.equals(channel)) {
            return;
        }
        Entity target = caster.level().getEntity(data.getInt(FleshRippingSkill.TARGET_KEY));
        if (target == null) {
            return;
        }
        caster.level().playLocalSound(target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
                ModSounds.GUTS.get(), SoundSource.PLAYERS, FleshRippingRules.SOUND_VOLUME, 1.0f, false);
        BloodSplashEffects.spawn(target, caster.getRandom());
    }

    /** Mitad local: mientras se mantiene, marca el objetivo apuntado con el mismo trazado que usa el servidor. */
    private static final class AimContext extends ClientSkillContext {
        private float exp;

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null) {
                return;
            }
            exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            TargetMarkerRenderer.show(this, this::marker);
        }

        @Nullable
        private TargetMarkerRenderer.Marker marker(float partialTick) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null || isTerminated()) {
                return null;
            }
            Vec3 eye = player.getEyePosition(partialTick);
            Vec3 end = eye.add(player.getViewVector(partialTick).scale(FleshRippingRules.range(exp)));
            ElectronBombSkill.RayHit hit = ElectronBombSkill.traceRay(player, eye, end);
            return TargetMarkerRenderer.forTarget(player, hit.entity(), hit.end(), partialTick);
        }

        @Override
        protected void onKeyUp() {
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onKeyAbort() {
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onTerminated() {
            TargetMarkerRenderer.hide(this);
        }
    }
}
