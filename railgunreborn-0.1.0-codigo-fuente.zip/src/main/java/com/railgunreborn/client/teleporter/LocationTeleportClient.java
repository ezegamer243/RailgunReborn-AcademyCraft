package com.railgunreborn.client.teleporter;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.teleporter.LocationTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.screen.LocationTeleportScreen;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Location Teleport: pulsar la tecla abre {@link LocationTeleportScreen}; la pantalla vive lo que vive el
 * contexto (cerrarla lo termina y, si el servidor lo termina, se cierra). Bus del MOD solo para el registro.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class LocationTeleportClient {
    private LocationTeleportClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        ClientSkillContexts.registerFactory(Teleporter.LOCATION_TELEPORT.getId(), ScreenContext::new);
    }

    /** Mitad local: abre la pantalla y le da los mensajes {@code add}/{@code remove}/{@code teleport}. */
    public static final class ScreenContext extends ClientSkillContext {
        ScreenContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            Minecraft.getInstance().setScreen(new LocationTeleportScreen(this));
        }

        @Override
        protected void onTerminated() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen instanceof LocationTeleportScreen screen && screen.isFor(this) && !screen.isClosing()) {
                mc.setScreen(null);
            }
        }

        public void requestAdd(String name) {
            CompoundTag tag = new CompoundTag();
            tag.putString(LocationTeleportSkill.NAME_KEY, name);
            sendToServer(LocationTeleportSkill.CHANNEL_ADD, tag);
        }

        public void requestRemove(int index) {
            sendToServer(LocationTeleportSkill.CHANNEL_REMOVE, indexTag(index));
        }

        public void requestTeleport(int index) {
            sendToServer(LocationTeleportSkill.CHANNEL_TELEPORT, indexTag(index));
        }

        private static CompoundTag indexTag(int index) {
            CompoundTag tag = new CompoundTag();
            tag.putInt(LocationTeleportSkill.INDEX_KEY, index);
            return tag;
        }
    }
}
