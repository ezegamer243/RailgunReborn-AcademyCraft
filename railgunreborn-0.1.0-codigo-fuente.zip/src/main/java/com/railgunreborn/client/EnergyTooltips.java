package com.railgunreborn.client;

import java.util.Locale;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.PhaseGenBlockEntity;
import com.railgunreborn.block.SolarGenBlockEntity;
import com.railgunreborn.block.WindGenRules;
import com.railgunreborn.crafting.ImagFusorRecipe;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.metalformer.MetalFormerRecipe;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.NodeType;
import com.railgunreborn.wireless.WirelessRegistry;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/**
 * Línea gris de energía en el tooltip de generadores, consumidores, nodos y reactor (T107). Todo en un sitio y con las
 * constantes del código, para que cambiar un número cambie también el tooltip. La Energy Unit, el Developer portátil y
 * el núcleo de matriz ya traen su propio tooltip.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class EnergyTooltips {
    private EnergyTooltips() {
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent event) {
        Component line = lineFor(event.getItemStack().getItem());
        if (line != null) {
            event.getToolTip().add(line.copy().withStyle(ChatFormatting.GRAY));
        }
    }

    /** La línea de energía de un ítem, o {@code null} si no tiene papel en la energía. */
    static Component lineFor(Item item) {
        if (item == ModItems.SOLAR_GEN.get()) {
            return produces(SolarGenBlockEntity.BASE_OUTPUT);
        }
        if (item == ModItems.PHASE_GEN.get()) {
            return produces(PhaseGenBlockEntity.MAX_BURN_PER_TICK * PhaseGenBlockEntity.IF_PER_MB);
        }
        if (item == ModItems.WINDGEN_MAIN.get()) {
            return Component.translatable("tooltip.railgunreborn.energy.produces_range",
                    number(WindGenRules.MAX_OUTPUT * WindGenRules.LOW_FACTOR), number(WindGenRules.MAX_OUTPUT));
        }
        if (item == ModItems.CAT_ENGINE.get()) {
            return produces(CatEngineBlockEntity.OUTPUT);
        }
        if (item == ModItems.IMAG_FUSOR.get()) {
            return consumes(ImagFusorRecipe.DEFAULT_ENERGY_PER_TICK);
        }
        if (item == MetalFormerRegistry.METAL_FORMER_ITEM.get()) {
            // El total de la receta por defecto repartido en sus ticks (13,3 IF/t).
            return consumes((double) MetalFormerRecipe.DEFAULT_ENERGY / MetalFormerRecipe.DEFAULT_TIME);
        }
        if (item == ModItems.DEVELOPER_NORMAL.get()) {
            return perStim(DeveloperType.NORMAL);
        }
        if (item == ModItems.DEVELOPER_ADVANCED.get()) {
            return perStim(DeveloperType.ADVANCED);
        }
        if (item == WirelessRegistry.NODE_BASIC_ITEM.get()) {
            return node(NodeType.BASIC);
        }
        if (item == WirelessRegistry.NODE_STANDARD_ITEM.get()) {
            return node(NodeType.STANDARD);
        }
        if (item == WirelessRegistry.NODE_ADVANCED_ITEM.get()) {
            return node(NodeType.ADVANCED);
        }
        if (item == CategoryReactorRegistry.ITEM.get()) {
            return Component.translatable("tooltip.railgunreborn.energy.needs",
                    EnergyFormat.number(CategoryReactorBlockEntity.ENERGY_CAPACITY));
        }
        return null;
    }

    private static Component produces(double perTick) {
        return Component.translatable("tooltip.railgunreborn.energy.produces", number(perTick));
    }

    private static Component consumes(double perTick) {
        return Component.translatable("tooltip.railgunreborn.energy.consumes", number(perTick));
    }

    private static Component perStim(DeveloperType type) {
        return Component.translatable("tooltip.railgunreborn.energy.per_stim",
                EnergyFormat.number(type.energyPerStim()));
    }

    private static Component node(NodeType type) {
        return Component.translatable("tooltip.railgunreborn.energy.node", EnergyFormat.number(type.capacity),
                number(type.range));
    }

    /** Entero con separador de miles, o un decimal ("7,5" se muestra con punto en todos los idiomas). */
    static String number(double value) {
        if (value == Math.rint(value)) {
            return EnergyFormat.number((long) value);
        }
        return String.format(Locale.ROOT, "%.1f", value);
    }
}
