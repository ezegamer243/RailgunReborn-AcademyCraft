package com.railgunreborn.client.context;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.network.SkillContextActionPayload.Action;
import com.railgunreborn.network.SkillContextStatePayload;
import com.railgunreborn.network.StartSkillPayload;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Contextos del jugador local (el ClientRuntime del original, reducido): crea el contexto al pulsar una ranura,
 * manda soltar/abortar/keep-alive, recibe el estado del servidor y descuenta los cooldowns locales.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ClientSkillContexts {
    @FunctionalInterface
    public interface Factory {
        ClientSkillContext create(int id, Skill skill, int slot);
    }

    private static final Map<ResourceLocation, Factory> FACTORIES = new ConcurrentHashMap<>();
    private static final Map<Integer, ClientSkillContext> ACTIVE = new LinkedHashMap<>();
    private static int nextId = 1;

    private ClientSkillContexts() {
    }

    /** Mitad cliente propia de una habilidad (llamar en {@code FMLClientSetupEvent}). Sin registro: la básica. */
    public static void registerFactory(ResourceLocation skill, Factory factory) {
        FACTORIES.put(skill, factory);
    }

    /** Contextos vivos (para el HUD: estado de los iconos). */
    public static List<ClientSkillContext> getActive() {
        return List.copyOf(ACTIVE.values());
    }

    /**
     * Comprobación previa del cliente, como el original: si ya se sabe que el servidor lo rechazará (modo apagado,
     * overload, cooldown, o la misma habilidad aún en curso) no se manda nada. Sin sonido: es lo esperado al
     * hacer clic rápido.
     */
    public static boolean canStart(Player player, Skill skill) {
        if (!CPData.get(player).canUseAbility() || CooldownData.get(player).isInCooldown(skill.getId())) {
            return false;
        }
        return ACTIVE.values().stream().noneMatch(ctx -> ctx.getSkill() == skill);
    }

    // --- Entrada (desde client.SlotInput) ---

    public static void keyDown(int slot, ResourceLocation skillId) {
        Player player = Minecraft.getInstance().player;
        Optional<Skill> skill = AbilityRegistries.skill(skillId);
        if (skill.isPresent()) {
            for (ClientSkillContext alive : getActive()) {
                if (alive.getSkill() == skill.get() && !alive.isTerminated()) {
                    alive.onKeyDownWhileAlive();
                    return;
                }
            }
        }
        if (player == null || skill.isEmpty() || !canStart(player, skill.get())) {
            return;
        }
        int id = nextId;
        nextId = nextId == Integer.MAX_VALUE ? 1 : nextId + 1;
        ClientSkillContext ctx = FACTORIES.getOrDefault(skillId, ClientSkillContext::new).create(id, skill.get(), slot);
        ACTIVE.put(id, ctx);
        PacketDistributor.sendToServer(new StartSkillPayload(id, skill.get()));
        ctx.onKeyDown();
    }

    public static void keyUp(int slot, ResourceLocation skillId) {
        for (ClientSkillContext ctx : getActive()) {
            if (ctx.getSlot() == slot && ctx.keyHeld && ctx.getSkill().getId().equals(skillId)) {
                ctx.keyHeld = false;
                PacketDistributor.sendToServer(new SkillContextActionPayload(ctx.getId(), Action.KEY_UP));
                ctx.onKeyUp();
            }
        }
    }

    /** Pulsación de V: true si algún contexto vivo la consume (entonces no se alterna el modo habilidad). */
    public static boolean handleActivateKey() {
        boolean consumed = false;
        for (ClientSkillContext ctx : getActive()) {
            if (!ctx.isTerminated() && ctx.onActivateKey()) {
                consumed = true;
            }
        }
        return consumed;
    }

    // --- Tick ---

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) {
            clear();
            return;
        }
        // En pausa (un jugador) el servidor integrado no avanza: ni cooldowns ni timeouts deben contar.
        if (mc.isPaused()) {
            return;
        }
        CooldownData.get(player).tick();
        if (ACTIVE.isEmpty()) {
            return;
        }
        boolean canUse = CPData.get(player).canUseAbility();
        for (ClientSkillContext ctx : getActive()) {
            if (ctx.isTerminated()) {
                continue;
            }
            if (!canUse && ctx.keyHeld) {
                ctx.keyHeld = false;
                PacketDistributor.sendToServer(new SkillContextActionPayload(ctx.getId(), Action.KEY_ABORT));
                ctx.onKeyAbort();
            }
            if (++ctx.ticksSinceServerPing > SkillContexts.KEEP_ALIVE_TIMEOUT) {
                RailgunReborn.LOGGER.debug("Client skill context {} timed out", ctx.getId());
                terminateLocal(ctx, true);
                continue;
            }
            if (!ctx.isTerminated()) {
                ctx.tick();
            }
            if (!ctx.isTerminated() && ++ctx.ticksAlive % SkillContexts.KEEP_ALIVE_INTERVAL == 0) {
                PacketDistributor.sendToServer(new SkillContextActionPayload(ctx.getId(), Action.KEEP_ALIVE));
            }
        }
    }

    // --- Red (desde los payloads) ---

    public static void handleState(int id, SkillContextStatePayload.State state) {
        ClientSkillContext ctx = ACTIVE.get(id);
        if (ctx == null || ctx.isTerminated()) {
            return;
        }
        ctx.ticksSinceServerPing = 0;
        switch (state) {
            case ALIVE -> {
                if (ctx.state == ClientSkillContext.State.PENDING) {
                    ctx.state = ClientSkillContext.State.ALIVE;
                    ctx.onAlive();
                }
            }
            case REJECTED, TERMINATED -> terminateLocal(ctx, false);
            case KEEP_ALIVE -> {
            }
        }
    }

    public static void handleMessage(int id, String channel, CompoundTag data) {
        ClientSkillContext ctx = ACTIVE.get(id);
        if (ctx != null && !ctx.isTerminated()) {
            ctx.ticksSinceServerPing = 0;
            ctx.onMessage(channel, data);
        }
    }

    // --- Terminación ---

    static void terminateLocal(ClientSkillContext ctx, boolean notifyServer) {
        if (ctx.isTerminated()) {
            return;
        }
        ctx.state = ClientSkillContext.State.TERMINATED;
        ACTIVE.remove(ctx.getId(), ctx);
        if (notifyServer) {
            PacketDistributor.sendToServer(new SkillContextActionPayload(ctx.getId(), Action.TERMINATE));
        }
        ctx.onTerminated();
    }

    /** Sin avisar al servidor: él ya los terminó (muerte, dimensión) o no hay conexión. */
    private static void clear() {
        for (ClientSkillContext ctx : getActive()) {
            ctx.state = ClientSkillContext.State.TERMINATED;
            ctx.onTerminated();
        }
        ACTIVE.clear();
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        clear();
    }

    /** Morir o cambiar de dimensión recrea el jugador local; el servidor ya terminó sus contextos. */
    @SubscribeEvent
    public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
        clear();
    }
}
