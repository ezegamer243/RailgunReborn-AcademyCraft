package com.railgunreborn.client.context;

import com.railgunreborn.ability.Skill;
import com.railgunreborn.network.SkillContextMessagePayload;

import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Mitad cliente <b>local</b> de un contexto (solo existe en el cliente del jugador que pulsó la tecla). Por defecto
 * no hace nada más que existir: {@link ClientSkillContexts} se encarga de mandar teclas y keep-alive. Una habilidad
 * que necesite lógica local (p. ej. una barra de carga, apuntado) registra una subclase con
 * {@link ClientSkillContexts#registerFactory}. Los efectos que deben ver todos van por {@link SkillEffects}.
 */
public class ClientSkillContext {
    public enum State {
        /** Enviado el inicio, sin respuesta del servidor todavía. */
        PENDING,
        ALIVE,
        TERMINATED
    }

    private final int id;
    private final Skill skill;
    private final int slot;
    State state = State.PENDING;
    boolean keyHeld = true;
    int ticksSinceServerPing;
    int ticksAlive;

    public ClientSkillContext(int id, Skill skill, int slot) {
        this.id = id;
        this.skill = skill;
        this.slot = slot;
    }

    // --- Ganchos ---

    /** Justo después de mandar el inicio al servidor (sin esperar respuesta). */
    protected void onKeyDown() {
    }

    protected void onKeyUp() {
    }

    protected void onKeyAbort() {
    }

    /** El servidor aceptó el inicio. */
    protected void onAlive() {
    }

    /** Cada tick de cliente mientras viva (pendiente o aceptado). */
    protected void tick() {
    }

    /** Mensaje de la mitad servidor ({@code SkillContext#sendToLocal}). */
    protected void onMessage(String channel, CompoundTag data) {
    }

    /**
     * Se volvió a pulsar la tecla de esta habilidad mientras el contexto vive (no se crea otro). En un interruptor
     * ({@link Skill#isToggle()}) lo cierra.
     */
    protected void onKeyDownWhileAlive() {
        if (skill.isToggle()) {
            terminate();
        }
    }

    /**
     * Se pulsó la tecla de alternar el modo habilidad (V) mientras el contexto vive. true = la consume: el modo
     * habilidad no se alterna. Un interruptor ({@link Skill#isToggle()}) se cierra con ella.
     */
    protected boolean onActivateKey() {
        if (skill.isToggle()) {
            terminate();
            return true;
        }
        return false;
    }

    /** Una sola vez: terminado por el servidor, rechazado, por timeout o localmente. */
    protected void onTerminated() {
    }

    // --- Utilidades ---

    public final int getId() {
        return id;
    }

    public final Skill getSkill() {
        return skill;
    }

    /** Ranura 0-based que lo inició. */
    public final int getSlot() {
        return slot;
    }

    public final State getState() {
        return state;
    }

    public final boolean isKeyHeld() {
        return keyHeld;
    }

    public final boolean isTerminated() {
        return state == State.TERMINATED;
    }

    protected final void sendToServer(String channel, CompoundTag data) {
        if (!isTerminated()) {
            PacketDistributor.sendToServer(new SkillContextMessagePayload(id, channel, data.copy()));
        }
    }

    /** Termina el contexto aquí y avisa al servidor. */
    public final void terminate() {
        ClientSkillContexts.terminateLocal(this, true);
    }
}
