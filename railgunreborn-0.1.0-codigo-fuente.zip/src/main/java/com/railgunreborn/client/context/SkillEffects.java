package com.railgunreborn.client.context;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.network.SkillEffectPayload;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Efectos visuales/sonoros de habilidades en el cliente (los ClientContext del original, sin estado). Llegan a
 * todos los jugadores cercanos al que la usa, incluido él mismo. Cada habilidad registra su manejador en
 * {@code FMLClientSetupEvent} (p. ej. Arc Gen en {@code client.electromaster.ElectromasterClient}).
 */
public final class SkillEffects {
    @FunctionalInterface
    public interface Handler {
        /**
         * @param caster    el jugador que usó la habilidad (puede ser el local u otro)
         * @param contextId id del contexto en el cliente del que la usó (para emparejar varios mensajes)
         */
        void handle(Player caster, int contextId, String channel, CompoundTag data);
    }

    private static final Map<ResourceLocation, Handler> HANDLERS = new ConcurrentHashMap<>();

    private SkillEffects() {
    }

    public static void register(ResourceLocation skill, Handler handler) {
        HANDLERS.put(skill, handler);
    }

    public static void dispatch(SkillEffectPayload payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        Entity entity = mc.level.getEntity(payload.casterId());
        ResourceLocation skillId = payload.skill().getId();
        Handler handler = HANDLERS.get(skillId);
        if (!(entity instanceof Player caster)) {
            return;
        }
        if (handler == null) {
            RailgunReborn.LOGGER.debug("No effect handler for {} ({})", skillId, payload.channel());
            return;
        }
        handler.handle(caster, payload.contextId(), payload.channel(), payload.data());
    }
}
