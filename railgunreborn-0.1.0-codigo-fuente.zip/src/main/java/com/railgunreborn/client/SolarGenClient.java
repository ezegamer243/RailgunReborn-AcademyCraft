package com.railgunreborn.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.screen.SolarGenScreen;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModMenus;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Cliente de los generadores de T100 (bus del MOD): pantalla del solar y renderizador del Cat Engine. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class SolarGenClient {
    private SolarGenClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.SOLAR_GEN.get(), SolarGenScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.CAT_ENGINE.get(), CatEngineRenderer::new);
    }
}
