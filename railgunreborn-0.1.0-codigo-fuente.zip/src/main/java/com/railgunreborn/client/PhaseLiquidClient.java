package com.railgunreborn.client;

import org.joml.Vector3f;

import com.mojang.blaze3d.shaders.FogShape;
import com.mojang.blaze3d.systems.RenderSystem;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModFluids;

import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

/** Aspecto del líquido de fase: textura animada del original (32 fotogramas) y niebla negro-azulada al sumergirse. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class PhaseLiquidClient {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "block/phase_liquid");

    private PhaseLiquidClient() {
    }

    @SubscribeEvent
    public static void onRegisterClientExtensions(RegisterClientExtensionsEvent event) {
        event.registerFluidType(new IClientFluidTypeExtensions() {
            @Override
            public ResourceLocation getStillTexture() {
                return TEXTURE;
            }

            @Override
            public ResourceLocation getFlowingTexture() {
                return TEXTURE;
            }

            @Override
            public Vector3f modifyFogColor(Camera camera, float partialTick, ClientLevel level, int renderDistance,
                    float darkenWorldAmount, Vector3f fluidFogColor) {
                return new Vector3f(0.04f, 0.07f, 0.10f);
            }

            @Override
            public void modifyFogRender(Camera camera, FogRenderer.FogMode mode, float renderDistance, float partialTick,
                    float nearDistance, float farDistance, FogShape shape) {
                // Líquido espeso y oscuro: se ve poco más que en la lava pero bastante menos que en el agua.
                RenderSystem.setShaderFogStart(0.0f);
                RenderSystem.setShaderFogEnd(6.0f);
                RenderSystem.setShaderFogShape(FogShape.SPHERE);
            }
        }, ModFluids.PHASE_LIQUID_TYPE.get());
    }
}
