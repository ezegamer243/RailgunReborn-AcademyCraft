package com.railgunreborn.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.screen.WindGenBaseScreen;
import com.railgunreborn.client.screen.WindGenMainScreen;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModMenus;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Cliente del generador eólico (bus del MOD): pantallas, renderizador del rotor y su modelo OBJ suelto. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class WindGenClient {
    private WindGenClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.WINDGEN_BASE.get(), WindGenBaseScreen::new);
        event.register(ModMenus.WINDGEN_MAIN.get(), WindGenMainScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.WINDGEN_MAIN.get(), WindGenFanRenderer::new);
    }

    @SubscribeEvent
    public static void registerModels(ModelEvent.RegisterAdditional event) {
        event.register(WindGenFanRenderer.FAN_MODEL);
    }
}
