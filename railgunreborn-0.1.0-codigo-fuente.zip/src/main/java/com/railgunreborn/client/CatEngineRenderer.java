package com.railgunreborn.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.CatEngineBlockEntity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Cat Engine como en el original ({@code RenderCatEngine}): el bloque no tiene modelo; se dibuja el gato como una
 * lámina de 1x1 a doble cara que mira al jugador (giro horizontal), da vueltas sobre su eje horizontal y flota
 * subiendo y bajando un poco.
 */
public final class CatEngineRenderer implements BlockEntityRenderer<CatEngineBlockEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "block/cat_engine");
    /** Grados por segundo de la vuelta del gato. */
    private static final double SPIN_SPEED = 90.0;

    public CatEngineRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(CatEngineBlockEntity be, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
            int packedLight, int packedOverlay) {
        Level level = be.getLevel();
        if (level == null) {
            return;
        }
        double time = (level.getGameTime() + partialTick) / 20.0;
        Vec3 camera = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        double dx = be.getBlockPos().getX() + 0.5 - camera.x;
        double dz = be.getBlockPos().getZ() + 0.5 - camera.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dx, dz));

        poseStack.pushPose();
        poseStack.translate(0.5, 0.03 * Math.sin(time * 1.2), 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(yaw + 180f));
        poseStack.translate(0.0, 0.5, 0.0);
        poseStack.mulPose(Axis.XP.rotationDegrees((float) (time * SPIN_SPEED % 360.0)));
        poseStack.translate(-0.5, -0.5, 0.0);

        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(TEXTURE);
        VertexConsumer buffer = buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS));
        PoseStack.Pose pose = poseStack.last();
        vertex(buffer, pose, 0, 0, sprite.getU0(), sprite.getV1(), packedLight);
        vertex(buffer, pose, 1, 0, sprite.getU1(), sprite.getV1(), packedLight);
        vertex(buffer, pose, 1, 1, sprite.getU1(), sprite.getV0(), packedLight);
        vertex(buffer, pose, 0, 1, sprite.getU0(), sprite.getV0(), packedLight);
        poseStack.popPose();
    }

    private static void vertex(VertexConsumer buffer, PoseStack.Pose pose, float x, float y, float u, float v,
            int light) {
        buffer.addVertex(pose, x, y, 0f).setColor(-1).setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light).setNormal(pose, 0f, 0f, 1f);
    }
}
