package com.railgunreborn.client;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.hud.CPBarHud;
import com.railgunreborn.client.screen.PresetEditScreen;
import com.railgunreborn.network.SwitchPresetPayload;
import com.railgunreborn.network.ToggleAbilityModePayload;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Entrada del modo habilidad en el cliente: V (alternar), C (preset), N (editar) y las 4 ranuras.
 * Con el modo activo, las teclas de ranura con habilidad asignada no hacen su acción vanilla; las ranuras vacías y
 * el modo apagado dejan todo como vanilla.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class AbilityInputHandler {
    /** El original alterna el modo solo con pulsación corta (< 0.3 s = 6 ticks). */
    private static final int SHORT_PRESS_TICKS = 6;

    private static int activateHeldTicks = -1;
    /** Habilidad con la que se pulsó cada ranura (null = no pulsada), para soltar con la misma. */
    private static final ResourceLocation[] heldSkills = new ResourceLocation[ModKeys.SLOTS.length];

    private AbilityInputHandler() {
    }

    /** true mientras se mantiene V (el HUD puede mostrar los números CP/OL, como el original). */
    public static boolean isActivateHeld() {
        return activateHeldTicks >= 0;
    }

    @SubscribeEvent
    public static void onClientTickPre(ClientTickEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || !CPData.get(player).isActivated()) {
            return;
        }
        // Antes de que Minecraft procese las teclas de este tick: las teclas de ranura no deben llegar a las
        // acciones vanilla (atacar/usar/romper bloques por mantener el clic, cambiar mano con F...).
        for (KeyMapping vanilla : mc.options.keyMappings) {
            if (!sharesSlotKey(player, vanilla)) {
                continue;
            }
            while (vanilla.consumeClick()) {
                // descartar pulsaciones pendientes
            }
            vanilla.setDown(false);
        }
    }

    @SubscribeEvent
    public static void onClientTickPost(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) {
            releaseAll();
            if (activateHeldTicks >= 0) {
                activateHeldTicks = -1;
                CPBarHud.stopDisplayNumbers();
            }
            return;
        }
        boolean modeOn = CPData.get(player).isActivated();

        tickActivateKey();
        while (ModKeys.SWITCH_PRESET.consumeClick()) {
            if (modeOn) {
                PacketDistributor.sendToServer(SwitchPresetPayload.INSTANCE);
            }
        }
        while (ModKeys.EDIT_PRESET.consumeClick()) {
            // Como el original: solo con categoría, sin aviso; no exige el modo habilidad activo.
            if (mc.screen == null && AbilityData.get(player).hasCategory()) {
                mc.setScreen(new PresetEditScreen(PresetData.get(player).getActive()));
            }
        }

        if (!modeOn) {
            releaseAll();
            return;
        }
        PresetData presets = PresetData.get(player);
        for (int slot = 0; slot < ModKeys.SLOTS.length; slot++) {
            boolean down = ModKeys.SLOTS[slot].isDown();
            ResourceLocation held = heldSkills[slot];
            if (down && held == null) {
                ResourceLocation skill = presets.getSlot(presets.getActive(), slot);
                if (skill != null) {
                    heldSkills[slot] = skill;
                    SlotInput.onSlotDown(slot, skill);
                }
            } else if (!down && held != null) {
                heldSkills[slot] = null;
                SlotInput.onSlotUp(slot, held);
            }
        }
    }

    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
        Player player = Minecraft.getInstance().player;
        if (player != null && CPData.get(player).isActivated() && sharesSlotKey(player, event.getKeyMapping())) {
            event.setSwingHand(false);
            event.setCanceled(true);
        }
    }

    private static void tickActivateKey() {
        if (ModKeys.ACTIVATE.isDown()) {
            if (activateHeldTicks < 0) {
                activateHeldTicks = 0;
                CPBarHud.startDisplayNumbers();
            } else {
                activateHeldTicks++;
            }
        } else if (activateHeldTicks >= 0) {
            if (activateHeldTicks < SHORT_PRESS_TICKS && !ClientSkillContexts.handleActivateKey()) {
                PacketDistributor.sendToServer(ToggleAbilityModePayload.INSTANCE);
            }
            activateHeldTicks = -1;
            CPBarHud.stopDisplayNumbers();
        }
    }

    /** Suelta las ranuras que seguían pulsadas (modo apagado, salir del mundo...). */
    private static void releaseAll() {
        for (int slot = 0; slot < heldSkills.length; slot++) {
            ResourceLocation held = heldSkills[slot];
            if (held != null) {
                heldSkills[slot] = null;
                SlotInput.onSlotUp(slot, held);
            }
        }
    }

    private static boolean isOurs(KeyMapping mapping) {
        return ModKeys.CATEGORY.equals(mapping.getCategory());
    }

    /**
     * Si la acción vanilla comparte tecla con una ranura que tiene habilidad en el preset activo. Las ranuras
     * vacías no bloquean nada: así el clic izquierdo/derecho sigue funcionando si no tienen habilidad asignada.
     */
    private static boolean sharesSlotKey(Player player, @Nullable KeyMapping mapping) {
        if (mapping == null || isOurs(mapping)) {
            return false;
        }
        PresetData presets = PresetData.get(player);
        for (int slot = 0; slot < ModKeys.SLOTS.length; slot++) {
            if (ModKeys.SLOTS[slot].same(mapping) && presets.getSlot(presets.getActive(), slot) != null) {
                return true;
            }
        }
        return false;
    }
}
