package com.railgunreborn.client;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.InputConstants;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.PresetData;

import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

/** Teclas del modo habilidad (solo cliente). Textos en {@code lang}: {@code key.railgunreborn.*}. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ModKeys {
    public static final String CATEGORY = "key.categories." + RailgunReborn.MODID;

    public static final KeyMapping ACTIVATE = new KeyMapping("key.railgunreborn.activate_ability",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping SWITCH_PRESET = new KeyMapping("key.railgunreborn.switch_preset",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY);
    public static final KeyMapping EDIT_PRESET = new KeyMapping("key.railgunreborn.edit_preset",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, CATEGORY);
    /** Abre/cierra el Terminal de datos; Alt izquierdo como en el original ({@code terminal.md} 2). */
    public static final KeyMapping OPEN_TERMINAL = new KeyMapping("key.railgunreborn.open_terminal",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, CATEGORY);

    /** Ranuras 1..4: clic izquierdo, clic derecho, R, F. Índice del array = ranura 0-based. */
    public static final KeyMapping[] SLOTS = {
            slot(1, InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_LEFT),
            slot(2, InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_RIGHT),
            slot(3, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R),
            slot(4, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F),
    };

    static {
        if (SLOTS.length != PresetData.MAX_SLOTS) {
            throw new IllegalStateException("Slot key count must match PresetData.MAX_SLOTS");
        }
    }

    private ModKeys() {
    }

    private static KeyMapping slot(int number, InputConstants.Type type, int code) {
        return new KeyMapping("key.railgunreborn.ability_slot_" + number, KeyConflictContext.IN_GAME, type, code,
                CATEGORY);
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(ACTIVATE);
        event.register(SWITCH_PRESET);
        event.register(EDIT_PRESET);
        event.register(OPEN_TERMINAL);
        for (KeyMapping slot : SLOTS) {
            event.register(slot);
        }
    }
}
