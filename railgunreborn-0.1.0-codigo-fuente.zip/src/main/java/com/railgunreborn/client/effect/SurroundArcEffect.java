package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.random.RandomGenerator;

import javax.annotation.Nullable;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Mini-arcos que chisporrotean sobre la superficie de una caja ({@code EntitySurroundArc} + {@code SubArcHandler} del
 * original). La caja está centrada en x/z sobre su base; puede seguir a una entidad (aura, gira con su cabeza) o
 * quedarse en un punto que se mueve a mano (p. ej. el bloque al que se apunta). Dura hasta {@link #stop()}.
 */
public final class SurroundArcEffect implements LiveArc {
    /** Escala de las plantillas al dibujarlas (como el original: ≈1 bloque para las de longitud 3-4). */
    private static final float SCALE = 0.3f;
    private static final double FRAME_RATE = 0.6;
    private static final double SWITCH_RATE = 0.7;
    private static final int SUB_LIFE = 30;
    /** Barrido de Body Intensify: ticks en que nace un mini-arco, su altura sobre los pies y la vida del aura. */
    private static final int[] SWEEP_TICKS = {0, 1, 3, 4, 6, 7, 8};
    private static final double[] SWEEP_HEIGHTS = {2.0, 1.8, 1.5, 1.0, 0.5, 0.0, -0.1};
    private static final int SWEEP_LIFE = 15;
    private static final int SWEEP_SUB_LIFE = 3;

    private final Level level;
    @Nullable
    private final Entity follow;
    private final ArcPattern[] templates;
    private final int count;
    private final double width;
    private final double height;
    private final List<SubArc> arcs = new ArrayList<>();

    private Vec3 base;
    /** Desplazamiento vertical de la caja respecto a los pies de la entidad seguida. */
    private double followYOffset;
    private boolean draw = true;
    private boolean stopped;
    private boolean sweep;
    private int sweepAge;
    /** Ticks hasta apagarse solo; -1 = sin cuenta atrás. */
    private int stopCountdown = -1;

    private SurroundArcEffect(Level level, @Nullable Entity follow, Vec3 base, ArcPattern[] templates, int count,
            double width, double height) {
        this.level = level;
        this.follow = follow;
        this.base = base;
        this.templates = templates;
        this.count = count;
        this.width = width;
        this.height = height;
    }

    /** Aura THIN alrededor de una entidad: caja = su caja × 1.3, 4 mini-arcos finos. */
    public static SurroundArcEffect aroundEntity(Entity entity) {
        return new SurroundArcEffect(entity.level(), entity, entity.position(), ArcPatterns.surroundThin(), 4,
                entity.getBbWidth() * 1.3, entity.getBbHeight() * 1.3);
    }

    /** Aura BOLD alrededor de una entidad (Thunderclap): caja = su caja × 1.3, 5 mini-arcos gruesos. */
    public static SurroundArcEffect boldAround(Entity entity) {
        return new SurroundArcEffect(entity.level(), entity, entity.position(), ArcPatterns.surroundBold(), 5,
                entity.getBbWidth() * 1.3, entity.getBbHeight() * 1.3);
    }

    /** Aura THIN (factor 1.3) centrada en la caja de la entidad, sin agrandar hacia arriba (bloque de Mag Manip). */
    public static SurroundArcEffect centeredOn(Entity entity) {
        SurroundArcEffect effect = aroundEntity(entity);
        effect.followYOffset = -entity.getBbHeight() * 0.15;
        return effect;
    }

    /** Tipo NORMAL en un cubo de 1×1×1 con base en {@code base} (centro de la cara de abajo del bloque). */
    public static SurroundArcEffect onBlock(Level level, Vec3 base) {
        return new SurroundArcEffect(level, null, base, ArcPatterns.surroundNormal(), 6, 1.0, 1.0);
    }

    /**
     * Barrido de Body Intensify: aura THIN que dura 15 ticks y no genera arcos sola; saca mini-arcos en un anillo de
     * radio 0.5-0.6 a alturas que bajan de la cabeza a los pies.
     */
    public static SurroundArcEffect sweepAround(Entity entity) {
        SurroundArcEffect effect = new SurroundArcEffect(entity.level(), entity, entity.position(),
                ArcPatterns.surroundThin(), 0, entity.getBbWidth(), entity.getBbHeight());
        effect.sweep = true;
        return effect;
    }

    public void moveTo(Vec3 newBase) {
        this.base = newBase;
    }

    /** Oculto sigue avanzando (como {@code draw = false} del original), solo no se dibuja. */
    public void setDraw(boolean draw) {
        this.draw = draw;
    }

    public void stop() {
        stopped = true;
    }

    /** Se apaga dentro de {@code ticks} ticks (si ya había una cuenta más corta, se queda la corta). */
    public void stopIn(int ticks) {
        if (stopCountdown < 0 || ticks < stopCountdown) {
            stopCountdown = ticks;
        }
    }

    @Override
    public boolean tick(RandomGenerator rand) {
        if (stopCountdown >= 0 && stopCountdown-- == 0) {
            stopped = true;
        }
        if (stopped || (follow != null && follow.isRemoved())) {
            stopped = true;
            return false;
        }
        if (sweep) {
            for (int i = 0; i < SWEEP_TICKS.length; i++) {
                if (SWEEP_TICKS[i] == sweepAge) {
                    double angle = rand.nextDouble() * Math.PI * 2;
                    double radius = 0.5 + rand.nextDouble() * 0.1;
                    arcs.add(new SubArc(new Vec3(Math.cos(angle) * radius, SWEEP_HEIGHTS[i], Math.sin(angle) * radius),
                            rand, SWEEP_SUB_LIFE));
                }
            }
            if (++sweepAge >= SWEEP_LIFE) {
                stopped = true;
                return false;
            }
        } else if (arcs.isEmpty()) {
            for (int i = 0; i < count; i++) {
                arcs.add(new SubArc(randomSurfacePoint(rand), rand, SUB_LIFE));
            }
        }
        for (Iterator<SubArc> it = arcs.iterator(); it.hasNext(); ) {
            if (!it.next().tick(rand)) {
                it.remove();
            }
        }
        return true;
    }

    /** Punto uniforme sobre la superficie de la caja (caras elegidas según su área). */
    private Vec3 randomSurfacePoint(RandomGenerator rand) {
        double w = width;
        double h = height;
        double top = w * w;
        double side = w * h;
        double pick = rand.nextDouble() * (2 * top + 4 * side);
        double u = (rand.nextDouble() - 0.5) * w;
        double v = (rand.nextDouble() - 0.5) * w;
        double y = rand.nextDouble() * h;
        if (pick < top) {
            return new Vec3(u, 0, v);
        }
        if (pick < 2 * top) {
            return new Vec3(u, h, v);
        }
        double rest = pick - 2 * top;
        double faceSide = rest < 2 * side ? 1 : -1;
        if (rest % (2 * side) < side) {
            return new Vec3(faceSide * w / 2, y, u);
        }
        return new Vec3(u, y, faceSide * w / 2);
    }

    @Override
    public Level level() {
        return level;
    }

    @Override
    public void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        if (!draw || stopped) {
            return;
        }
        Vec3 at = follow != null ? follow.getPosition(partialTick).add(0, followYOffset, 0) : base;
        poseStack.pushPose();
        poseStack.translate(at.x - camera.x, at.y - camera.y, at.z - camera.z);
        if (follow != null) {
            poseStack.mulPose(Axis.YP.rotationDegrees(-follow.getYHeadRot()));
        }
        for (SubArc arc : arcs) {
            if (!arc.visible) {
                continue;
            }
            ArcPattern pattern = templates[arc.patternIndex];
            poseStack.pushPose();
            poseStack.translate(arc.pos.x, arc.pos.y, arc.pos.z);
            poseStack.mulPose(Axis.ZP.rotationDegrees(arc.rotZ));
            poseStack.mulPose(Axis.YP.rotationDegrees(arc.rotY));
            poseStack.mulPose(Axis.XP.rotationDegrees(arc.rotX));
            poseStack.scale(SCALE, SCALE, SCALE);
            // Centrado en el punto: el patrón va de x=0 a x=length.
            poseStack.translate(-pattern.length() / 2, 0, 0);
            LiveArc.drawPattern(pattern, Double.MAX_VALUE, poseStack, consumer, rand);
            poseStack.popPose();
        }
        poseStack.popPose();
    }

    /** Un mini-arco ({@code SubArc} del original). */
    private final class SubArc {
        final Vec3 pos;
        final float rotX;
        final float rotY;
        final float rotZ;
        int patternIndex;
        boolean visible = true;
        int age;
        final int maxAge;

        SubArc(Vec3 pos, RandomGenerator rand, int maxAge) {
            this.maxAge = maxAge;
            this.pos = pos;
            this.rotX = rand.nextFloat() * 360f;
            this.rotY = rand.nextFloat() * 360f;
            this.rotZ = rand.nextFloat() * 360f;
            this.patternIndex = rand.nextInt(templates.length);
        }

        /** false = muerto. */
        boolean tick(RandomGenerator rand) {
            if (rand.nextDouble() < 0.5 * FRAME_RATE) {
                patternIndex = rand.nextInt(templates.length);
            }
            double flip = visible ? 0.4 * SWITCH_RATE : 0.3 * SWITCH_RATE;
            if (rand.nextDouble() < flip) {
                visible = !visible;
            }
            // La vida avanza con prob. 0.9 por tick, así no mueren todos a la vez.
            if (rand.nextDouble() < 0.9) {
                age++;
            }
            return age < maxAge;
        }
    }
}
