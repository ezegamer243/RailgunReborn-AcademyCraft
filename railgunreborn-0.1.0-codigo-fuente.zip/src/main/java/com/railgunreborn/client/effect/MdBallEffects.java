package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Bolas de electrones de Meltdowner ({@code EntityMdBall} del original, ficha {@code electron-bomb.md} §7.1): billboard
 * de dos capas (halo y anillo verde que tiembla entre 5 texturas) pegado al lanzador con un desplazamiento fijo en
 * el mundo. Nace pequeña y crece mientras se ilumina. Lista y dibujo propios, como {@link RayEffects}. Solo cliente.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MdBallEffects {
    private static final int CORE_VARIANTS = 5;
    private static final ResourceLocation GLOW = texture("glow");
    private static final ResourceLocation[] CORES = new ResourceLocation[CORE_VARIANTS];

    static {
        for (int i = 0; i < CORE_VARIANTS; i++) {
            CORES[i] = texture(Integer.toString(i));
        }
    }

    private static final double GLOW_SIZE = 0.7;
    private static final double CORE_SIZE = 0.5;
    private static final int HELD_MAX_AGE = 230;
    private static final List<Ball> BALLS = new ArrayList<>();
    private static final Random RANDOM = new Random();

    private MdBallEffects() {
    }

    private static ResourceLocation texture(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/mdball/" + name + ".png");
    }

    /** @param offset desplazamiento en el mundo respecto a los pies del lanzador */
    public static void spawn(Entity owner, Vec3 offset, int lifeTicks) {
        BALLS.add(new Ball(owner, offset, lifeTicks, false, -1));
    }

    /** Bola de vida indefinida (Scatter Bomb): estable hasta {@link #releaseHeld}; por seguridad caduca sola. */
    public static void spawnHeld(Entity owner, Vec3 offset) {
        spawnHeld(owner, offset, -1);
    }

    /** Bola sostenida con id (Electron Missile): se quita sola con {@link #removeHeld} al dispararse. */
    public static void spawnHeld(Entity owner, Vec3 offset, int id) {
        BALLS.add(new Ball(owner, offset, HELD_MAX_AGE, true, id));
    }

    /** Quita la bola sostenida {@code id} de {@code owner}. */
    public static void removeHeld(Entity owner, int id) {
        BALLS.removeIf(ball -> ball.held && ball.owner == owner && ball.id == id);
    }

    /** Quita las bolas sostenidas de {@code owner} (al soltar salen los rayos y la bola desaparece). */
    public static void releaseHeld(Entity owner) {
        BALLS.removeIf(ball -> ball.held && ball.owner == owner);
    }

    private static final class Ball {
        final Entity owner;
        final Vec3 offset;
        final int life;
        final boolean held;
        final int id;
        int age;
        int core;
        double flicker = 0.5;
        double flickerSpeed;

        Ball(Entity owner, Vec3 offset, int life, boolean held, int id) {
            this.id = id;
            this.owner = owner;
            this.offset = offset;
            this.held = held;
            this.life = Math.max(life, 1);
        }

        /** false = terminada. */
        boolean tick() {
            if (owner.isRemoved() || ++age >= life) {
                return false;
            }
            if (RANDOM.nextInt(8) < 2) {
                core = RANDOM.nextInt(CORE_VARIANTS);
            }
            if (RANDOM.nextInt(8) < 3) {
                flickerSpeed = (RANDOM.nextDouble() * 2 - 1) * 4.0;
            }
            flicker = Mth.clamp(flicker + flickerSpeed * 0.05, 0.0, 1.0);
            return true;
        }

        /** Alfa base: sube a 0.6 en 0.3 s, a 1.0 en los últimos 0.4 s y se apaga en los últimos 0.15 s. */
        float baseAlpha(float partialTick) {
            double t = (age + partialTick) * 0.05;
            if (held) {
                return (float) (Math.min(t / 0.3, 1.0) * 0.6);
            }
            double total = life * 0.05;
            double remaining = total - t;
            double a = Math.min(t / 0.3, 1.0) * 0.6;
            if (remaining < 0.4) {
                a = Math.max(a, 0.6 + 0.4 * (1.0 - remaining / 0.4));
            }
            if (remaining < 0.15) {
                a = Math.min(a, Math.max(remaining / 0.15, 0.0));
            }
            return (float) Mth.clamp(a, 0.0, 1.0);
        }

        /** Crece de la mitad al tamaño completo durante el primer tercio de vida. */
        double scale(float partialTick) {
            return 0.5 + 0.5 * Math.min((age + partialTick) / (held ? 6.0 : life / 3.0), 1.0);
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || BALLS.isEmpty()) {
            return;
        }
        for (Iterator<Ball> it = BALLS.iterator(); it.hasNext(); ) {
            Ball ball = it.next();
            if (ball.owner.level() != mc.level || !ball.tick()) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || BALLS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Camera camera = event.getCamera();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();

        // Primero todos los halos y luego los anillos (cada textura es un tipo de render).
        RenderType glowType = ArcRenderType.arc(GLOW);
        VertexConsumer glow = buffers.getBuffer(glowType);
        for (Ball ball : BALLS) {
            draw(ball, glow, pose, camera, partial, GLOW_SIZE,
                    ball.baseAlpha(partial) * (0.3f + 0.7f * (float) ball.flicker));
        }
        buffers.endBatch(glowType);

        for (int i = 0; i < CORE_VARIANTS; i++) {
            RenderType type = null;
            for (Ball ball : BALLS) {
                if (ball.core == i) {
                    if (type == null) {
                        type = ArcRenderType.arc(CORES[i]);
                    }
                    draw(ball, buffers.getBuffer(type), pose, camera, partial, CORE_SIZE,
                            ball.baseAlpha(partial) * (0.8f + 0.2f * (float) ball.flicker));
                }
            }
            if (type != null) {
                buffers.endBatch(type);
            }
        }
    }

    private static void draw(Ball ball, VertexConsumer consumer, PoseStack.Pose pose, Camera camera, float partial,
            double size, float alpha) {
        Entity owner = ball.owner;
        Vec3 center = new Vec3(Mth.lerp(partial, owner.xo, owner.getX()), Mth.lerp(partial, owner.yo, owner.getY()),
                Mth.lerp(partial, owner.zo, owner.getZ())).add(ball.offset).subtract(camera.getPosition());
        double half = size / 2 * ball.scale(partial);
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        Vec3 l = new Vec3(left.x, left.y, left.z).scale(half);
        Vec3 u = new Vec3(up.x, up.y, up.z).scale(half);
        vertex(consumer, pose, center.add(l).add(u), 0f, 0f, alpha);
        vertex(consumer, pose, center.add(l).subtract(u), 0f, 1f, alpha);
        vertex(consumer, pose, center.subtract(l).subtract(u), 1f, 1f, alpha);
        vertex(consumer, pose, center.subtract(l).add(u), 1f, 0f, alpha);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, float u, float v, float alpha) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(1f, 1f, 1f, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        BALLS.clear();
    }
}
