package com.railgunreborn.client.effect;

import java.util.random.RandomGenerator;

/** Vector inmutable mínimo para el generador de arcos (Java puro, sin clases de Minecraft, para poder testearlo). */
public record ArcVec(double x, double y, double z) {
    static final ArcVec ZERO = new ArcVec(0, 0, 0);

    ArcVec add(ArcVec o) {
        return new ArcVec(x + o.x, y + o.y, z + o.z);
    }

    ArcVec sub(ArcVec o) {
        return new ArcVec(x - o.x, y - o.y, z - o.z);
    }

    ArcVec scale(double k) {
        return new ArcVec(x * k, y * k, z * k);
    }

    ArcVec cross(ArcVec o) {
        return new ArcVec(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);
    }

    double length() {
        return Math.sqrt(x * x + y * y + z * z);
    }

    ArcVec normalize() {
        double len = length();
        return len < 1e-12 ? ZERO : scale(1 / len);
    }

    ArcVec midpoint(ArcVec o) {
        return new ArcVec((x + o.x) / 2, (y + o.y) / 2, (z + o.z) / 2);
    }

    ArcVec rotateX(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new ArcVec(x, y * c + z * s, z * c - y * s);
    }

    ArcVec rotateY(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new ArcVec(x * c + z * s, y, z * c - x * s);
    }

    ArcVec rotateZ(double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new ArcVec(x * c - y * s, x * s + y * c, z);
    }

    /**
     * Giro aleatorio pequeño como el del original: se elige un ángulo límite en ±{@code rangeDeg} y luego se gira
     * sobre X, Y y Z con ángulos independientes dentro de ese límite (por eso el giro típico es menor que el rango).
     */
    ArcVec randomRotate(double rangeDeg, RandomGenerator rand) {
        double limit = Math.toRadians(range(rand, -rangeDeg, rangeDeg));
        return rotateX(range(rand, -limit, limit))
                .rotateY(range(rand, -limit, limit))
                .rotateZ(range(rand, -limit, limit));
    }

    private static double range(RandomGenerator rand, double a, double b) {
        return a + (b - a) * rand.nextDouble();
    }
}
