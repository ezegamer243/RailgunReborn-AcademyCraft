package com.railgunreborn.client.effect;

import com.railgunreborn.RailgunReborn;

import net.minecraft.resources.ResourceLocation;

/**
 * Parámetros de un rayo dibujado por {@link RayRenderer} ({@code RendererRayComposite} del original): resplandor en
 * cinta orientada a la cámara con tres texturas (entrada, cuerpo, salida), halo y núcleo como cilindros de color plano,
 * y la animación (crecer, desvanecer, estrecharse, temblor del ancho). Colores ARGB. Se crea con {@link #builder}.
 */
public final class RayStyle {
    final ResourceLocation[] glowTextures;
    final double glowWidth;
    final double glowStart;
    final double glowEndExtra;
    final double glowCap;
    final int glowColor;
    final double glowFlicker;
    final boolean repeatTile;
    final double outerRadius;
    final int outerColor;
    final double innerRadius;
    final int innerColor;
    final int lifeTicks;
    final double blendInMs;
    final double blendOutMs;
    final double shrinkMs;
    final double maxWiggle;
    final double wiggleSpeed;
    final boolean fromHand;

    private RayStyle(Builder b) {
        this.glowTextures = b.glowTextures;
        this.glowWidth = b.glowWidth;
        this.glowStart = b.glowStart;
        this.glowEndExtra = b.glowEndExtra;
        this.glowCap = b.glowCap < 0 ? b.glowWidth : b.glowCap;
        this.glowColor = b.glowColor;
        this.glowFlicker = b.glowFlicker;
        this.repeatTile = b.repeatTile;
        this.outerRadius = b.outerRadius;
        this.outerColor = b.outerColor;
        this.innerRadius = b.innerRadius;
        this.innerColor = b.innerColor;
        this.lifeTicks = b.lifeTicks;
        this.blendInMs = b.blendInMs;
        this.blendOutMs = b.blendOutMs;
        this.shrinkMs = b.shrinkMs;
        this.maxWiggle = b.maxWiggle;
        this.wiggleSpeed = b.wiggleSpeed;
        this.fromHand = b.fromHand;
    }

    public int lifeTicks() {
        return lifeTicks;
    }

    /** Las tres texturas {@code blend_in}, {@code tile} y {@code blend_out} de {@code textures/effect/<dir>/}. */
    public static ResourceLocation[] glowTextures(String dir) {
        return new ResourceLocation[] {tex(dir, "blend_in"), tex(dir, "tile"), tex(dir, "blend_out")};
    }

    private static ResourceLocation tex(String dir, String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                "textures/effect/" + dir + "/" + name + ".png");
    }

    /** ARGB a partir de RGBA 0-255 (como vienen en las fichas). */
    public static int rgba(int r, int g, int b, int a) {
        return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | (b & 0xFF);
    }

    public static Builder builder(String textureDir) {
        return new Builder(glowTextures(textureDir));
    }

    public static final class Builder {
        private final ResourceLocation[] glowTextures;
        private double glowWidth = 1.0;
        private double glowStart;
        private double glowEndExtra;
        private double glowCap = -1;
        private int glowColor = 0xFFFFFFFF;
        private double glowFlicker;
        private boolean repeatTile;
        private double outerRadius = 0.1;
        private int outerColor = 0x3CFFFFFF;
        private double innerRadius = 0.05;
        private int innerColor = 0xC8FFFFFF;
        private int lifeTicks = 20;
        private double blendInMs = 150;
        private double blendOutMs = 500;
        private double shrinkMs = 500;
        private double maxWiggle;
        private double wiggleSpeed;
        private boolean fromHand;

        private Builder(ResourceLocation[] glowTextures) {
            this.glowTextures = glowTextures;
        }

        /**
         * Cinta: ancho total, inicio (respecto al origen, negativo = detrás), cuánto se alarga tras el final y
         * longitud de los tramos de entrada/salida (por defecto, el ancho).
         */
        public Builder glow(double width, double start, double endExtra, double cap) {
            this.glowWidth = width;
            this.glowStart = start;
            this.glowEndExtra = endExtra;
            this.glowCap = cap;
            return this;
        }

        public Builder glow(double width) {
            return glow(width, 0, 0, -1);
        }

        /** Tinte (ARGB; el alfa multiplica la opacidad de la cinta) y parpadeo del brillo (amplitud total, 0.2 = ±10 %). */
        public Builder glowColor(int argb, double flicker) {
            this.glowColor = argb;
            this.glowFlicker = flicker;
            return this;
        }

        /** Repetir la textura del cuerpo cada {@code ancho} bloques en vez de estirarla (Meltdowner). */
        public Builder repeatTile(boolean value) {
            this.repeatTile = value;
            return this;
        }

        /** Halo (exterior) y núcleo (interior): radio y color ARGB. */
        public Builder cylinders(double outerRadius, int outerColor, double innerRadius, int innerColor) {
            this.outerRadius = outerRadius;
            this.outerColor = outerColor;
            this.innerRadius = innerRadius;
            this.innerColor = innerColor;
            return this;
        }

        /** Vida, crecimiento inicial, desvanecido final y estrechamiento final (los tres en ms). */
        public Builder timing(int lifeTicks, double blendInMs, double blendOutMs, double shrinkMs) {
            this.lifeTicks = lifeTicks;
            this.blendInMs = blendInMs;
            this.blendOutMs = blendOutMs;
            this.shrinkMs = shrinkMs;
            return this;
        }

        /** Temblor del ancho: máximo (fracción extra) y velocidad por segundo. */
        public Builder wiggle(double max, double perSecond) {
            this.maxWiggle = max;
            this.wiggleSpeed = perSecond / 20.0;
            return this;
        }

        /** Desplazar el origen visual a la mano del lanzador (Railgun); si no, sale del origen exacto. */
        public Builder fromHand(boolean value) {
            this.fromHand = value;
            return this;
        }

        public RayStyle build() {
            return new RayStyle(this);
        }
    }
}
