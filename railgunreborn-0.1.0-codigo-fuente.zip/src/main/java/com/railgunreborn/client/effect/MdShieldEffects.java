package com.railgunreborn.client.effect;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.LightShieldRules;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Escudo de Light Shield ({@code EntityMdShield} + {@code RenderMdShield} del original, ficha §7-8): disco translúcido
 * de 1.8 bloques a 1 bloque delante del jugador (a 1.1 de altura), perpendicular a su mirada, que crece en 15 ticks,
 * aparece en 6 y gira despacio; suelta partículas Md y lleva el zumbido en bucle. Uno por jugador, en todos los
 * clientes cercanos. Solo cliente (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MdShieldEffects {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/mdshield.png");
    private static final double SIZE = 1.8;
    private static final double DISTANCE = 1.0;
    private static final double HEIGHT = 1.1;
    private static final float STARTUP_VOLUME = 0.3f; // -40 % a pedido del usuario (era 0.5)
    private static final float LOOP_VOLUME = 0.3f; // -40 % a pedido del usuario (era 0.5)
    private static final float PARTICLE_CHANCE = 0.3f;
    /** Giro del original en grados por segundo: casi imperceptible (ficha [DUDA] 5, se replica). */
    private static final float SPIN_MIN = 0.8f;
    private static final float SPIN_MAX = 2.0f;
    /** Si no llega el "stop" (fuera de rango), se corta solo: el escudo nunca pasa de 180 ticks. */
    private static final int SAFETY_TICKS = LightShieldRules.maxTicks(1f) + 40;

    private static final Map<Integer, Shield> SHIELDS = new HashMap<>();

    private MdShieldEffects() {
    }

    public static void start(Player caster, int contextId) {
        stop(caster, -1);
        EntityLoopSound loop = new EntityLoopSound(ModSounds.SHIELD_LOOP.get(), SoundSource.PLAYERS, caster,
                LOOP_VOLUME);
        Minecraft.getInstance().getSoundManager().play(loop);
        caster.level().playLocalSound(caster.getX(), caster.getY(), caster.getZ(), ModSounds.SHIELD_STARTUP.get(),
                SoundSource.PLAYERS, STARTUP_VOLUME, 1.0f, false);
        SHIELDS.put(caster.getId(), new Shield(caster, contextId, loop));
    }

    /** @param contextId el del "stop"; -1 quita cualquier escudo del jugador */
    public static void stop(Player caster, int contextId) {
        Shield shield = SHIELDS.get(caster.getId());
        if (shield != null && (contextId < 0 || shield.contextId == contextId)) {
            SHIELDS.remove(caster.getId());
            shield.loop.finish();
        }
    }

    private static final class Shield {
        final Player caster;
        final int contextId;
        final EntityLoopSound loop;
        int age;
        float angle;
        float prevAngle;

        Shield(Player caster, int contextId, EntityLoopSound loop) {
            this.caster = caster;
            this.contextId = contextId;
            this.loop = loop;
        }

        /** false = terminado. */
        boolean tick() {
            if (caster.isRemoved() || ++age > SAFETY_TICKS) {
                return false;
            }
            prevAngle = angle;
            angle += Mth.lerp(Math.min(age / 30f, 1f), SPIN_MIN, SPIN_MAX) / 20f;
            RandomSource random = caster.getRandom();
            if (random.nextFloat() < PARTICLE_CHANCE) {
                Vec3 p = center(caster, 1f).add(random.nextDouble() - 0.5, random.nextDouble() - 0.5,
                        random.nextDouble() - 0.5);
                caster.level().addParticle(ModParticles.MD.get(), p.x, p.y, p.z, (random.nextDouble() * 2 - 1) * 0.02,
                        -0.01 + random.nextDouble() * 0.06, (random.nextDouble() * 2 - 1) * 0.02);
            }
            return true;
        }
    }

    private static Vec3 center(Player caster, float partial) {
        Vec3 feet = new Vec3(Mth.lerp(partial, caster.xo, caster.getX()), Mth.lerp(partial, caster.yo, caster.getY()),
                Mth.lerp(partial, caster.zo, caster.getZ()));
        return feet.add(0, HEIGHT, 0).add(caster.getViewVector(partial).scale(DISTANCE));
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || SHIELDS.isEmpty()) {
            return;
        }
        for (Iterator<Shield> it = SHIELDS.values().iterator(); it.hasNext(); ) {
            Shield shield = it.next();
            if (shield.caster.level() != mc.level || !shield.tick()) {
                shield.loop.finish();
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || SHIELDS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 camera = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        RenderType type = ArcRenderType.arc(TEXTURE);
        VertexConsumer consumer = buffers.getBuffer(type);
        for (Shield shield : SHIELDS.values()) {
            draw(shield, consumer, pose, camera, partial);
        }
        buffers.endBatch(type);
    }

    private static void draw(Shield shield, VertexConsumer consumer, PoseStack.Pose pose, Vec3 camera,
            float partial) {
        Player caster = shield.caster;
        float age = shield.age + partial;
        float alpha = Math.min(age / 6f, 1f);
        double half = SIZE / 2 * Mth.lerp(Math.min(age / 15f, 1f), 0.2, 1.0);
        Vec3 center = center(caster, partial).subtract(camera);

        // Base del plano perpendicular a la mirada; "right" sale del yaw para no degenerar mirando arriba/abajo.
        Vec3 forward = caster.getViewVector(partial);
        double yaw = Math.toRadians(caster.getViewYRot(partial));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(forward).normalize();
        double spin = Math.toRadians(Mth.lerp(partial, shield.prevAngle, shield.angle));
        double cos = Math.cos(spin);
        double sin = Math.sin(spin);
        Vec3 a = right.scale(cos).add(up.scale(sin)).scale(half);
        Vec3 b = up.scale(cos).subtract(right.scale(sin)).scale(half);

        vertex(consumer, pose, center.add(a).add(b), 0f, 0f, alpha);
        vertex(consumer, pose, center.add(a).subtract(b), 0f, 1f, alpha);
        vertex(consumer, pose, center.subtract(a).subtract(b), 1f, 1f, alpha);
        vertex(consumer, pose, center.subtract(a).add(b), 1f, 0f, alpha);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, float u, float v, float alpha) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(1f, 1f, 1f, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        SHIELDS.values().forEach(shield -> shield.loop.finish());
        SHIELDS.clear();
    }
}
