package com.railgunreborn.client.effect;

import java.util.function.Function;
import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Rayo que dura hasta {@link #stop()} y une cada frame un origen pegado a una entidad con un destino que se recalcula
 * cada tick ({@code EntityArc} con {@code lengthFixed = false} del original). El patrón se recorta a la distancia.
 */
public final class ContinuousArcEffect implements LiveArc {
    private final Entity owner;
    private final ArcPattern[] patterns;
    /** Altura del origen sobre los pies del dueño. */
    private final double originHeight;
    /** Dónde acaba el rayo, dado el dueño; se llama una vez por tick. */
    private final Function<Entity, Vec3> target;

    private double texWiggle = 0.8;
    private double showWiggle = 0.2;
    private double hideWiggle = 0.8;

    private Vec3 to;
    private int patternIndex;
    private boolean visible = true;
    private boolean stopped;

    public ContinuousArcEffect(Entity owner, ArcPattern[] patterns, double originHeight,
            Function<Entity, Vec3> target) {
        this.owner = owner;
        this.patterns = patterns;
        this.originHeight = originHeight;
        this.target = target;
        this.to = target.apply(owner);
    }

    public ContinuousArcEffect wiggle(double texWiggle, double showWiggle, double hideWiggle) {
        this.texWiggle = texWiggle;
        this.showWiggle = showWiggle;
        this.hideWiggle = hideWiggle;
        return this;
    }

    /** Se quita en el siguiente tick. */
    public void stop() {
        stopped = true;
    }

    public boolean isStopped() {
        return stopped;
    }

    @Override
    public boolean tick(RandomGenerator rand) {
        if (stopped || owner.isRemoved()) {
            stopped = true;
            return false;
        }
        to = target.apply(owner);
        if (rand.nextDouble() < texWiggle) {
            patternIndex = rand.nextInt(patterns.length);
        }
        if (visible ? rand.nextDouble() < showWiggle : rand.nextDouble() < hideWiggle) {
            visible = !visible;
        }
        return true;
    }

    @Override
    public Level level() {
        return owner.level();
    }

    @Override
    public void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        if (!visible || stopped) {
            return;
        }
        Vec3 from = owner.getPosition(partialTick).add(0, originHeight, 0);
        Vec3 dir = to.subtract(from);
        double length = dir.length();
        if (length < 1.0e-3) {
            return;
        }
        // Mismo giro que ArcEffect: yaw/pitch de Minecraft que apuntan +X local hacia el destino.
        float yaw = (float) Math.toDegrees(Mth.atan2(-dir.x, dir.z));
        float pitch = (float) -Math.toDegrees(Math.asin(Mth.clamp(dir.y / length, -1.0, 1.0)));
        poseStack.pushPose();
        poseStack.translate(from.x - camera.x, from.y - camera.y, from.z - camera.z);
        poseStack.mulPose(Axis.YP.rotationDegrees(-(yaw + 90f)));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-pitch));
        LiveArc.drawPattern(patterns[patternIndex], length, poseStack, consumer, rand);
        poseStack.popPose();
    }
}
