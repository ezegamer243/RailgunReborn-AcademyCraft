package com.railgunreborn.client.effect;

import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Un rayo vivo en el mundo (equivale a {@code EntityArc} del original, pero sin entidad). Queda fijo en la posición
 * de los ojos y la orientación que tenía el lanzador al crearse; solo la mano (el desplazamiento) depende de la vista
 * actual. Se crea con {@link ArcEffects}.
 */
public final class ArcEffect implements LiveArc {
    // Desplazamientos a la mano en espacio local del rayo (X adelante, Y arriba, Z derecha), ficha §9.1.
    private static final Vec3 HAND_FIRST_PERSON = new Vec3(-0.05, -0.25, 0.2);
    private static final Vec3 HAND_THIRD_PERSON = new Vec3(0.15, -0.8, 0.23);

    private final Player shooter;
    private final ArcPattern[] patterns;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;

    private double length;
    private int life = 10;
    /** Probabilidad por tick de cambiar de patrón. */
    private double texWiggle = 0.7;
    /** Probabilidad por tick de ocultarse estando visible. */
    private double showWiggle = 0.1;
    /** Probabilidad por tick de reaparecer estando oculto. */
    private double hideWiggle = 0.4;

    private int age;
    private int patternIndex;
    private boolean visible = true;

    public ArcEffect(Player shooter, ArcPattern[] patterns, double length) {
        this.shooter = shooter;
        this.patterns = patterns;
        this.length = length;
        Vec3 eyes = shooter.getEyePosition();
        this.x = eyes.x;
        this.y = eyes.y;
        this.z = eyes.z;
        this.yaw = shooter.getYHeadRot();
        this.pitch = shooter.getXRot();
    }

    public ArcEffect life(int ticks) {
        this.life = ticks;
        return this;
    }

    public ArcEffect wiggle(double texWiggle, double showWiggle, double hideWiggle) {
        this.texWiggle = texWiggle;
        this.showWiggle = showWiggle;
        this.hideWiggle = hideWiggle;
        return this;
    }

    public ArcEffect length(double length) {
        this.length = length;
        return this;
    }

    public Player shooter() {
        return shooter;
    }

    @Override
    public boolean tick(RandomGenerator rand) {
        if (++age >= life) {
            return false;
        }
        if (rand.nextDouble() < texWiggle) {
            patternIndex = rand.nextInt(patterns.length);
        }
        if (visible ? rand.nextDouble() < showWiggle : rand.nextDouble() < hideWiggle) {
            visible = !visible;
        }
        return true;
    }

    @Override
    public Level level() {
        return shooter.level();
    }

    @Override
    public void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        if (!visible) {
            return;
        }
        poseStack.pushPose();
        poseStack.translate(x - camera.x, y - camera.y, z - camera.z);
        // Lleva +X local a la dirección de la mirada (yaw/pitch de Minecraft).
        poseStack.mulPose(Axis.YP.rotationDegrees(-(yaw + 90f)));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-pitch));
        Vec3 hand = isLocalFirstPerson() ? HAND_FIRST_PERSON : HAND_THIRD_PERSON;
        poseStack.translate(hand.x, hand.y, hand.z);

        LiveArc.drawPattern(patterns[patternIndex], length, poseStack, consumer, rand);
        poseStack.popPose();
    }

    private boolean isLocalFirstPerson() {
        Minecraft mc = Minecraft.getInstance();
        return shooter == mc.player && mc.options.getCameraType().isFirstPerson();
    }
}
