package com.railgunreborn.client.effect;

import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Un efecto de arcos que {@link ArcEffects} avanza cada tick y dibuja con la cinta {@code line_segment}. */
public interface LiveArc {
    /** Avanza un tick. {@code false} = terminado, se quita de la lista. */
    boolean tick(RandomGenerator rand);

    /** Dibuja relativo a la cámara (la vista ya está aplicada en {@code poseStack}). */
    void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick, RandomGenerator rand);

    /** Mundo al que pertenece: si no es el actual del cliente, no se dibuja y se descarta. */
    Level level();

    /** Escribe un vértice de cinta (fullbright, blanco con el alfa del segmento). */
    static void vertex(VertexConsumer consumer, PoseStack.Pose pose, double x, double y, double z, float u, float v,
            float alpha) {
        consumer.addVertex(pose, (float) x, (float) y, (float) z)
                .setColor(1f, 1f, 1f, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    /** Dibuja un patrón en el espacio actual de {@code poseStack}, recortado a {@code length}. */
    static void drawPattern(ArcPattern pattern, double length, PoseStack poseStack, VertexConsumer consumer,
            RandomGenerator rand) {
        PoseStack.Pose pose = poseStack.last();
        pattern.buildRibbons(length, rand,
                (alpha, x1, y1, z1, u1, v1, x2, y2, z2, u2, v2, x3, y3, z3, u3, v3, x4, y4, z4, u4, v4) -> {
                    vertex(consumer, pose, x1, y1, z1, u1, v1, alpha);
                    vertex(consumer, pose, x2, y2, z2, u2, v2, alpha);
                    vertex(consumer, pose, x3, y3, z3, u3, v3, alpha);
                    vertex(consumer, pose, x4, y4, z4, u4, v4, alpha);
                });
    }
}
