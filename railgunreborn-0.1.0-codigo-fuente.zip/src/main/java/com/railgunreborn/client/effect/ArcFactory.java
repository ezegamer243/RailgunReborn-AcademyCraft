package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.List;
import java.util.random.RandomGenerator;

/**
 * Generador de formas de rayo (reimplementación de {@code ArcFactory} de AcademyCraft): zigzag fractal por
 * subdivisión del punto medio, con ramas. Java puro, sin render. Ver {@code docs/spec/arc-gen.md} §9.2.
 *
 * <p>Los valores por defecto son los del original; cada conjunto de patrones ({@link ArcPatterns}) ajusta los suyos.
 */
public final class ArcFactory {
    public double width = 0.1;
    public double lengthShrink = 0.7;
    public double alphaShrink = 0.9;
    public double widthShrink = 0.7;
    public int passes = 6;
    public double maxOffset = 1.5;
    public double branchFactor = 0.4;

    private static final double BRANCH_ROTATE_DEG = 10.0;

    /** {@code count} patrones con longitud al azar en [{@code lengthFrom}, {@code lengthTo}). */
    public ArcPattern[] generateList(int count, double lengthFrom, double lengthTo, RandomGenerator rand) {
        ArcPattern[] result = new ArcPattern[count];
        for (int i = 0; i < count; i++) {
            double len = lengthFrom + (lengthTo - lengthFrom) * rand.nextDouble();
            result[i] = generate(len, rand);
        }
        return result;
    }

    /**
     * Un patrón: parte de un segmento recto (0,0,0)→(length,0,0) con alfa 1 y en cada pasada parte cada segmento por su
     * punto medio, desplazado hasta {@code offset} en una dirección al azar del plano YZ; {@code offset} empieza en
     * {@code maxOffset} y se divide a la mitad por pasada.
     *
     * <p>Ramas: con probabilidad {@code branchFactor} por segmento nace una hebra nueva desde el punto medio. Fiel a
     * un detalle del original (su doble búfer alternado): las ramas que nacen en las pasadas pares (0, 2, 4...) se
     * pierden, y las que nacen en las impares se subdividen ya en esa misma pasada. Se replica porque fija la densidad
     * de ramas que se veía en el juego.
     */
    public ArcPattern generate(double length, RandomGenerator rand) {
        List<List<ArcPattern.Segment>> strands = new ArrayList<>();
        List<ArcPattern.Segment> trunk = new ArrayList<>();
        trunk.add(new ArcPattern.Segment(ArcVec.ZERO, width, new ArcVec(length, 0, 0), width, 1.0));
        strands.add(trunk);

        double offset = maxOffset;
        for (int pass = 0; pass < passes; pass++) {
            boolean keepBranches = (pass & 1) == 1;
            // El tamaño crece dentro del bucle: las ramas nuevas se procesan en esta misma pasada.
            for (int j = 0; j < strands.size(); j++) {
                strands.set(j, subdivide(strands.get(j), offset, keepBranches, strands, rand));
            }
            offset /= 2;
        }
        strands.removeIf(List::isEmpty);
        return new ArcPattern(strands, length);
    }

    private List<ArcPattern.Segment> subdivide(List<ArcPattern.Segment> strand, double offset, boolean keepBranches,
            List<List<ArcPattern.Segment>> strands, RandomGenerator rand) {
        List<ArcPattern.Segment> out = new ArrayList<>(strand.size() * 2);
        for (ArcPattern.Segment s : strand) {
            double theta = rand.nextDouble() * Math.PI * 2;
            double off = rand.nextDouble() * offset;
            ArcVec base = s.start().midpoint(s.end());
            ArcVec mid = new ArcVec(base.x(), base.y() + off * Math.sin(theta), base.z() + off * Math.cos(theta));
            double midWidth = (s.startWidth() + s.endWidth()) / 2;

            out.add(new ArcPattern.Segment(s.start(), s.startWidth(), mid, midWidth, s.alpha()));
            out.add(new ArcPattern.Segment(mid, midWidth, s.end(), s.endWidth(), s.alpha()));

            if (rand.nextDouble() < branchFactor) {
                ArcVec dir = mid.sub(s.start()).scale(lengthShrink).randomRotate(BRANCH_ROTATE_DEG, rand);
                double branchWidth = midWidth * widthShrink;
                if (keepBranches) {
                    List<ArcPattern.Segment> branch = new ArrayList<>();
                    branch.add(new ArcPattern.Segment(mid, branchWidth, mid.add(dir), branchWidth,
                            s.alpha() * alphaShrink));
                    strands.add(branch);
                }
            }
        }
        return out;
    }
}
