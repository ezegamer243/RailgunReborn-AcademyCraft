package com.railgunreborn.client.effect;

import java.util.function.Function;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.Util;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * Tipo de render de los arcos. Hereda de {@link RenderType} solo para acceder a los "shards" protegidos; nunca se
 * instancia.
 *
 * <p>Shader {@code rendertype_eyes}: color × textura sin iluminación ni lightmap (fullbright), sin descartar los
 * píxeles poco opacos (el halo de la textura se conserva) y con niebla. Es lo más parecido al shader "simple" de
 * LambdaLib2. A diferencia de {@code RenderType.eyes} (aditivo y con culling) usa mezcla alfa estándar, sin culling,
 * y no escribe profundidad para que las cintas superpuestas no se tapen entre sí. Se dibuja en el destino de
 * partículas (en "Fabulous!" es el que se compone con el resto de translúcidos).
 */
final class ArcRenderType extends RenderType {
    private static final Function<ResourceLocation, RenderType> ARC = Util.memoize(texture -> create(
            "railgunreborn_arc",
            DefaultVertexFormat.NEW_ENTITY,
            VertexFormat.Mode.QUADS,
            1536,
            false,
            true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_EYES_SHADER)
                    .setTextureState(new TextureStateShard(texture, false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .setOutputState(PARTICLES_TARGET)
                    .createCompositeState(false)));

    private ArcRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }

    static RenderType arc(ResourceLocation texture) {
        return ARC.apply(texture);
    }
}
