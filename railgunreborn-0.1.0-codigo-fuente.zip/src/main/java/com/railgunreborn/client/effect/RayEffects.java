package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Lista general de rayos sueltos (los de Meltdowner): {@link #spawn} y listo; se avanzan en el tick del cliente y se
 * dibujan con {@link RayRenderer}. El Railgun lleva su propia lista en {@link RailgunEffects} (va junto a sus
 * mini-arcos). Bus del juego, solo cliente.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class RayEffects {
    private static final List<RayEffect> RAYS = new ArrayList<>();
    private static final Random RANDOM = new Random();

    private RayEffects() {
    }

    public static void spawn(RayEffect ray) {
        RAYS.add(ray);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isPaused() && !RAYS.isEmpty()) {
            RayRenderer.tick(RAYS, mc.level, RANDOM);
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || RAYS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        RayRenderer.render(RAYS, mc.level, event.getPoseStack().last(), mc.renderBuffers().bufferSource(),
                event.getCamera().getPosition(), event.getPartialTick().getGameTimeDeltaPartialTick(false), RANDOM);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        RAYS.clear();
    }
}
