package com.railgunreborn.client.effect;

import java.util.List;
import java.util.random.RandomGenerator;

/**
 * Forma de un rayo ya generada por {@link ArcFactory}: el rayo va a lo largo de +X desde el origen, en espacio local.
 * Son varias "hebras" (el tronco y cada rama), cada una una lista ordenada de segmentos contiguos.
 * Java puro: no depende de clases de render.
 */
public final class ArcPattern {
    /** Ejes de los que sale el perpendicular de cada cinta (igual que el original: normal fija +Z). */
    private static final ArcVec NORMAL = new ArcVec(0, 0, 1);
    private static final double RIBBON_JITTER_DEG = 15.0;

    private final List<List<Segment>> strands;
    private final double length;

    ArcPattern(List<List<Segment>> strands, double length) {
        this.strands = strands.stream().map(List::copyOf).toList();
        this.length = length;
    }

    /** Longitud con la que se generó (el tronco va de x=0 a x=length). */
    public double length() {
        return length;
    }

    public List<List<Segment>> strands() {
        return strands;
    }

    public int segmentCount() {
        return strands.stream().mapToInt(List::size).sum();
    }

    /**
     * Convierte el patrón en cintas (quads) recortadas a {@code maxLength}: dentro de cada hebra se deja de dibujar
     * en el primer segmento cuyo inicio supera {@code maxLength} en X.
     *
     * <p>Cada cinta es perpendicular al segmento (producto vectorial con +Z) y ese perpendicular se gira al azar
     * hasta ±15°. El borde inicial reutiliza el perpendicular del segmento anterior para que la cinta sea continua.
     * Como en el original con longitud variable, el giro se recalcula en cada llamada (cada frame), lo que añade
     * algo de vibración extra al rayo.
     */
    public void buildRibbons(double maxLength, RandomGenerator rand, QuadSink sink) {
        for (List<Segment> strand : strands) {
            ArcVec lastDir = null;
            for (Segment s : strand) {
                if (s.start().x() > maxLength) {
                    break;
                }
                ArcVec dir = s.end().sub(s.start()).cross(NORMAL).randomRotate(RIBBON_JITTER_DEG, rand).normalize();
                if (lastDir == null) {
                    lastDir = dir;
                }
                ArcVec p1 = s.start().add(lastDir.scale(s.startWidth()));
                ArcVec p2 = s.start().add(lastDir.scale(-s.startWidth()));
                ArcVec p3 = s.end().add(dir.scale(s.endWidth()));
                ArcVec p4 = s.end().add(dir.scale(-s.endWidth()));
                // Orden y UV del original: u a lo largo del segmento, v a lo ancho.
                sink.quad((float) s.alpha(),
                        p1.x(), p1.y(), p1.z(), 0, 0,
                        p2.x(), p2.y(), p2.z(), 0, 1,
                        p4.x(), p4.y(), p4.z(), 1, 1,
                        p3.x(), p3.y(), p3.z(), 1, 0);
                lastDir = dir;
            }
        }
    }

    /** Un tramo recto del rayo. El ancho es la mitad del grosor de la cinta (se extiende ± a cada lado). */
    public record Segment(ArcVec start, double startWidth, ArcVec end, double endWidth, double alpha) {
    }

    /** Recibe cada cinta: alfa y 4 vértices (x, y, z, u, v) en espacio local del patrón. */
    @FunctionalInterface
    public interface QuadSink {
        void quad(float alpha,
                double x1, double y1, double z1, float u1, float v1,
                double x2, double y2, double z2, float u2, float v2,
                double x3, double y3, double z3, float u3, float v3,
                double x4, double y4, double z4, float u4, float v4);
    }
}
