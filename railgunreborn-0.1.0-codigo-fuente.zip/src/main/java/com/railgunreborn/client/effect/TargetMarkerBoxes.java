package com.railgunreborn.client.effect;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Geometría pura de los marcadores de objetivo (Threatening Teleport, Flesh Ripping, Blood Retrograde). */
public final class TargetMarkerBoxes {
    /** Caja de un objetivo: tamaño del objetivo por este factor. */
    public static final double TARGET_SCALE = 1.2;
    /** Lado de la caja pequeña cuando no hay objetivo. */
    public static final double POINT_SIZE = 0.5;

    private TargetMarkerBoxes() {
    }

    /** La caja escalada alrededor de su centro. */
    public static AABB scaled(AABB box, double factor) {
        Vec3 c = box.getCenter();
        double hx = box.getXsize() * factor / 2.0;
        double hy = box.getYsize() * factor / 2.0;
        double hz = box.getZsize() * factor / 2.0;
        return new AABB(c.x - hx, c.y - hy, c.z - hz, c.x + hx, c.y + hy, c.z + hz);
    }

    /** Caja cúbica de lado {@code size} centrada en {@code point}. */
    public static AABB around(Vec3 point, double size) {
        double h = size / 2.0;
        return new AABB(point.x - h, point.y - h, point.z - h, point.x + h, point.y + h, point.z + h);
    }
}
