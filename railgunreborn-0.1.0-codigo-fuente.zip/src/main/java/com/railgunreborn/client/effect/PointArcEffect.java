package com.railgunreborn.client.effect;

import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Rayo fijo entre dos puntos del mundo que dura {@code life} ticks ({@code EntityArc} con {@code setFromTo} y
 * {@code lengthFixed = false} del original). No sigue a nadie: si el destino se mueve, el rayo se queda donde estaba.
 */
public final class PointArcEffect implements LiveArc {
    private final Level level;
    private final ArcPattern[] patterns;
    private final Vec3 from;
    private final double length;
    private final float yaw;
    private final float pitch;

    private int life = 20;
    // Parpadeo por defecto de EntityArc.
    private double texWiggle = 0.5;
    private double showWiggle = 0.2;
    private double hideWiggle = 0.2;
    private double scale = 1.0;

    private int age;
    private int patternIndex;
    private boolean visible = true;

    public PointArcEffect(Level level, ArcPattern[] patterns, Vec3 from, Vec3 to) {
        this.level = level;
        this.patterns = patterns;
        this.from = from;
        Vec3 dir = to.subtract(from);
        this.length = dir.length();
        // Mismo giro que ArcEffect: yaw/pitch de Minecraft que apuntan +X local hacia el destino.
        this.yaw = (float) Math.toDegrees(Mth.atan2(-dir.x, dir.z));
        this.pitch = length < 1.0e-3 ? 0f
                : (float) -Math.toDegrees(Math.asin(Mth.clamp(dir.y / length, -1.0, 1.0)));
    }

    public PointArcEffect life(int ticks) {
        this.life = ticks;
        return this;
    }

    /** Encoge el dibujo (ancho y zigzag) para arcos diminutos, p. ej. dentro del reactor de categoría. */
    public PointArcEffect scale(double scale) {
        this.scale = scale;
        return this;
    }

    public PointArcEffect wiggle(double texWiggle, double showWiggle, double hideWiggle) {
        this.texWiggle = texWiggle;
        this.showWiggle = showWiggle;
        this.hideWiggle = hideWiggle;
        return this;
    }

    @Override
    public boolean tick(RandomGenerator rand) {
        if (++age >= life) {
            return false;
        }
        if (rand.nextDouble() < texWiggle) {
            patternIndex = rand.nextInt(patterns.length);
        }
        if (visible ? rand.nextDouble() < showWiggle : rand.nextDouble() < hideWiggle) {
            visible = !visible;
        }
        return true;
    }

    @Override
    public Level level() {
        return level;
    }

    @Override
    public void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        if (!visible || length < 1.0e-3) {
            return;
        }
        poseStack.pushPose();
        poseStack.translate(from.x - camera.x, from.y - camera.y, from.z - camera.z);
        poseStack.mulPose(Axis.YP.rotationDegrees(-(yaw + 90f)));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-pitch));
        poseStack.scale((float) scale, (float) scale, (float) scale);
        LiveArc.drawPattern(patterns[patternIndex], length / scale, poseStack, consumer, rand);
        poseStack.popPose();
    }
}
