package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * API de cliente para los arcos eléctricos. Solo cliente: no llamar desde código común sin pasar por un handler de
 * payload o un {@code Dist} de cliente.
 *
 * <p>Técnica: lista de efectos de cliente que se avanza en {@code ClientTickEvent} y se dibuja en
 * {@code RenderLevelStageEvent} (AFTER_PARTICLES). El rayo no se mueve, no colisiona y vive medio segundo, así que una
 * entidad (que habría que registrar también en el servidor) o una partícula (render de cara a cámara, atlas propio)
 * no aportan nada; la lista solo existe en el cliente y dibuja todos los arcos en un único lote.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ArcEffects {
    public static final ResourceLocation LINE_SEGMENT_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/arc/line_segment.png");

    private static final List<LiveArc> ACTIVE = new ArrayList<>();
    private static final Random RANDOM = new Random();

    private ArcEffects() {
    }

    /**
     * Arco débil de Arc Gen (ficha §9): sale de la mano de {@code shooter} hacia donde mira en este instante, con
     * longitud {@code length} (el alcance, aunque haya golpeado antes), dura 10 ticks y chisporrotea.
     */
    public static ArcEffect spawnWeakArc(Player shooter, float length) {
        return spawn(new ArcEffect(shooter, ArcPatterns.weakArc(), length)
                .life(10)
                .wiggle(0.7, 0.1, 0.4));
    }

    /** Añade un arco ya configurado (para otras habilidades con otros patrones o tiempos). */
    public static <T extends LiveArc> T spawn(T effect) {
        ACTIVE.add(effect);
        return effect;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (ACTIVE.isEmpty() || mc.isPaused()) {
            return;
        }
        for (Iterator<LiveArc> it = ACTIVE.iterator(); it.hasNext(); ) {
            LiveArc effect = it.next();
            if (effect.level() != mc.level || !effect.tick(RANDOM)) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || ACTIVE.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        // En esta fase la matriz de vista (rotación de cámara) ya está aplicada: se dibuja relativo a la cámara.
        Vec3 camera = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        RenderType type = ArcRenderType.arc(LINE_SEGMENT_TEXTURE);
        VertexConsumer consumer = buffers.getBuffer(type);
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        for (LiveArc effect : ACTIVE) {
            if (effect.level() == mc.level) {
                effect.render(poseStack, consumer, camera, partialTick, RANDOM);
            }
        }
        buffers.endBatch(type);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ACTIVE.clear();
    }
}
