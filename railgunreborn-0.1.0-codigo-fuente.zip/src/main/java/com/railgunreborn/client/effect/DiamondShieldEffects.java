package com.railgunreborn.client.effect;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.JetEngineRules;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Escudo de electrones de Jet Engine ({@code EntityDiamondShield} + {@code RenderDiamondShield} del original, ficha
 * §7.2): pirámide de cuatro caras con la punta hacia delante, a 1 bloque delante del jugador y a 1.1 de altura,
 * orientada con su mirada, más la estela de partículas Md de los pies. Solo visual, sin sonido. Uno por jugador, en
 * todos los clientes cercanos. Solo cliente (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class DiamondShieldEffects {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/diamond_shield.png");
    private static final double SCALE = 1.5;
    private static final double DISTANCE = 1.0;
    private static final double HEIGHT = 1.1;
    private static final int PARTICLES_PER_TICK = 11;
    private static final double PARTICLE_SPREAD = 0.3;
    private static final double PARTICLE_SPEED = 0.02;
    /** Si no llega el "stop" (fuera de rango), se corta solo. */
    private static final int SAFETY_TICKS = JetEngineRules.FLIGHT_TICKS + 20;
    /** Base en cruz y punta delante (coordenadas locales: derecha, arriba, delante). */
    private static final double[][] BASE = {{1, 0, 0}, {0, 1, 0}, {-1, 0, 0}, {0, -1, 0}};
    private static final double[] TIP = {0, 0, 1};

    private static final Map<Integer, Shield> SHIELDS = new HashMap<>();

    private DiamondShieldEffects() {
    }

    public static void start(Player caster, int contextId) {
        SHIELDS.put(caster.getId(), new Shield(caster, contextId));
    }

    /** @param contextId el del "stop"; -1 quita cualquier escudo del jugador */
    public static void stop(Player caster, int contextId) {
        Shield shield = SHIELDS.get(caster.getId());
        if (shield != null && (contextId < 0 || shield.contextId == contextId)) {
            SHIELDS.remove(caster.getId());
        }
    }

    private static final class Shield {
        final Player caster;
        final int contextId;
        int age;

        Shield(Player caster, int contextId) {
            this.caster = caster;
            this.contextId = contextId;
        }

        /** false = terminado. */
        boolean tick() {
            if (caster.isRemoved() || ++age > SAFETY_TICKS) {
                return false;
            }
            RandomSource random = caster.getRandom();
            for (int i = 0; i < PARTICLES_PER_TICK; i++) {
                caster.level().addParticle(ModParticles.MD.get(),
                        caster.getX() + (random.nextDouble() * 2 - 1) * PARTICLE_SPREAD,
                        caster.getY() + (random.nextDouble() * 2 - 1) * PARTICLE_SPREAD,
                        caster.getZ() + (random.nextDouble() * 2 - 1) * PARTICLE_SPREAD,
                        (random.nextDouble() * 2 - 1) * PARTICLE_SPEED, (random.nextDouble() * 2 - 1) * PARTICLE_SPEED,
                        (random.nextDouble() * 2 - 1) * PARTICLE_SPEED);
            }
            return true;
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || SHIELDS.isEmpty()) {
            return;
        }
        for (Iterator<Shield> it = SHIELDS.values().iterator(); it.hasNext(); ) {
            Shield shield = it.next();
            if (shield.caster.level() != mc.level || !shield.tick()) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || SHIELDS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 camera = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        RenderType type = ArcRenderType.arc(TEXTURE);
        VertexConsumer consumer = buffers.getBuffer(type);
        for (Shield shield : SHIELDS.values()) {
            draw(shield.caster, consumer, pose, camera, partial);
        }
        buffers.endBatch(type);
    }

    private static void draw(Player caster, VertexConsumer consumer, PoseStack.Pose pose, Vec3 camera,
            float partial) {
        Vec3 feet = new Vec3(Mth.lerp(partial, caster.xo, caster.getX()), Mth.lerp(partial, caster.yo, caster.getY()),
                Mth.lerp(partial, caster.zo, caster.getZ()));
        Vec3 forward = caster.getViewVector(partial);
        Vec3 center = feet.add(0, HEIGHT, 0).add(forward.scale(DISTANCE)).subtract(camera);
        // "right" sale del yaw para no degenerar mirando arriba/abajo (como el escudo de Light Shield).
        double yaw = Math.toRadians(caster.getViewYRot(partial));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(forward).normalize();
        Vec3 tip = toWorld(center, right, up, forward, TIP);
        for (int i = 0; i < BASE.length; i++) {
            Vec3 a = toWorld(center, right, up, forward, BASE[i]);
            Vec3 b = toWorld(center, right, up, forward, BASE[(i + 1) % BASE.length]);
            // Triángulo como quad con la punta repetida.
            vertex(consumer, pose, a, 0f, 1f);
            vertex(consumer, pose, b, 1f, 1f);
            vertex(consumer, pose, tip, 0.5f, 0f);
            vertex(consumer, pose, tip, 0.5f, 0f);
        }
    }

    private static Vec3 toWorld(Vec3 center, Vec3 right, Vec3 up, Vec3 forward, double[] local) {
        return center.add(right.scale(local[0] * SCALE)).add(up.scale(local[1] * SCALE))
                .add(forward.scale(local[2] * SCALE));
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, float u, float v) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(1f, 1f, 1f, 1f)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        SHIELDS.clear();
    }
}
