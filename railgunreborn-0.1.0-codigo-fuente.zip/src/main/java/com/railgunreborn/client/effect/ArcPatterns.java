package com.railgunreborn.client.effect;

import java.util.Random;

/**
 * Conjuntos de patrones pre-generados (como {@code ArcPatterns} del original). Se generan una vez, de forma perezosa,
 * al primer uso. Otras habilidades de Electromaster añaden aquí sus conjuntos.
 */
public final class ArcPatterns {
    public static final int COUNT = 20;
    public static final double LENGTH = 20.0;

    private ArcPatterns() {
    }

    /** Arco débil de Arc Gen: 20 patrones de longitud 20. */
    public static ArcPattern[] weakArc() {
        return WeakHolder.PATTERNS;
    }

    /** Fábrica con los parámetros de {@code weakArc} (ficha §9.2); pública para poder testear la generación. */
    public static ArcFactory weakArcFactory() {
        ArcFactory fac = new ArcFactory();
        fac.passes = 6;
        fac.branchFactor = 0.15;
        fac.maxOffset = 1.1;
        return fac;
    }

    /** Rayo continuo de Current Charging: más fino y ramificado que el débil (ficha current-charging 8.1). */
    public static ArcPattern[] chargingArc() {
        return ChargingHolder.PATTERNS;
    }

    public static ArcFactory chargingArcFactory() {
        ArcFactory fac = new ArcFactory();
        fac.passes = 5;
        fac.branchFactor = 0.3;
        fac.maxOffset = 1.2;
        fac.width = 0.1;
        return fac;
    }

    /** Plantillas de los mini-arcos de {@link SurroundArcEffect} tipo NORMAL (sobre un bloque): longitud 3-4. */
    public static ArcPattern[] surroundNormal() {
        return SurroundNormalHolder.PATTERNS;
    }

    /** Tipo THIN (aura alrededor de una entidad): más finos y cortos, longitud 1.5-2. */
    public static ArcPattern[] surroundThin() {
        return SurroundThinHolder.PATTERNS;
    }

    /** Tipo BOLD (aura gruesa de Thunderclap, ficha thunderclap 9.1): longitud 3.5-4.5, ancho 0.35. */
    public static ArcPattern[] surroundBold() {
        return SurroundBoldHolder.PATTERNS;
    }

    public static ArcFactory surroundBoldFactory() {
        ArcFactory fac = surroundFactory(0.35);
        fac.maxOffset = 1.2;
        fac.branchFactor = 0.45;
        return fac;
    }

    /** Parámetros comunes de las plantillas de mini-arcos ({@code EntitySurroundArc.ArcType} del original). */
    public static ArcFactory surroundFactory(double width) {
        ArcFactory fac = new ArcFactory();
        fac.widthShrink = 0.9;
        fac.maxOffset = 0.8;
        fac.passes = 3;
        fac.width = width;
        fac.branchFactor = 0.7;
        return fac;
    }

    /** Rayo principal de Thunder Bolt: el triple de ancho que el débil (ficha thunder-bolt 9.1). */
    public static ArcPattern[] strongArc() {
        return StrongHolder.PATTERNS;
    }

    public static ArcFactory strongArcFactory() {
        ArcFactory fac = new ArcFactory();
        fac.passes = 5;
        fac.branchFactor = 0.3;
        fac.width = 0.3;
        fac.maxOffset = 1.4;
        return fac;
    }

    /** Arcos del área de Thunder Bolt, del impacto a cada afectado (ficha thunder-bolt 9.2). */
    public static ArcPattern[] aoeArc() {
        return AoeHolder.PATTERNS;
    }

    public static ArcFactory aoeArcFactory() {
        ArcFactory fac = new ArcFactory();
        fac.passes = 5;
        fac.branchFactor = 0.28;
        fac.width = 0.13;
        fac.maxOffset = 1.2;
        return fac;
    }

    /**
     * Rayo fino de Magnet Movement ({@code thinContiniousArc} del original, ficha mag-movement 8). El original los
     * genera de 20 bloques; aquí miden {@link #THIN_CONTINUOUS_LENGTH} para que lleguen enteros a un objetivo a 25.
     */
    public static ArcPattern[] thinContinuousArc() {
        return ThinContinuousHolder.PATTERNS;
    }

    public static final double THIN_CONTINUOUS_LENGTH = 30.0;

    public static ArcFactory thinContinuousArcFactory() {
        ArcFactory fac = new ArcFactory();
        fac.passes = 5;
        fac.branchFactor = 0.2;
        fac.width = 0.08;
        fac.maxOffset = 1.2;
        return fac;
    }

    private static final class ThinContinuousHolder {
        static final ArcPattern[] PATTERNS = thinContinuousArcFactory().generateList(COUNT, THIN_CONTINUOUS_LENGTH,
                THIN_CONTINUOUS_LENGTH, new Random());
    }

    private static final class StrongHolder {
        static final ArcPattern[] PATTERNS = strongArcFactory().generateList(COUNT, LENGTH, LENGTH, new Random());
    }

    private static final class AoeHolder {
        static final ArcPattern[] PATTERNS = aoeArcFactory().generateList(COUNT, LENGTH, LENGTH, new Random());
    }

    private static final class ChargingHolder {
        static final ArcPattern[] PATTERNS = chargingArcFactory().generateList(COUNT, LENGTH, LENGTH, new Random());
    }

    private static final class SurroundNormalHolder {
        static final ArcPattern[] PATTERNS = surroundFactory(0.3).generateList(10, 3.0, 4.0, new Random());
    }

    private static final class SurroundBoldHolder {
        static final ArcPattern[] PATTERNS = surroundBoldFactory().generateList(10, 3.5, 4.5, new Random());
    }

    private static final class SurroundThinHolder {
        static final ArcPattern[] PATTERNS = surroundFactory(0.2).generateList(10, 1.5, 2.0, new Random());
    }

    private static final class WeakHolder {
        static final ArcPattern[] PATTERNS = weakArcFactory().generateList(COUNT, LENGTH, LENGTH, new Random());
    }
}
