package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.teleporter.FleshRippingRules;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Salpicaduras de sangre de Flesh Ripping ({@code EntityBloodSplash} del original): sprites planos que miran a la
 * cámara, animados con las 10 texturas {@code textures/effect/blood_splash/0..9.png} (un fotograma por tick), teñidos de
 * rojo {@code (213, 29, 29, 200)} y translúcidos. Se dibujan en el pase de partículas, sin iluminación.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class BloodSplashEffects {
    private static final int FRAMES = 10;
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[FRAMES];
    private static final int TINT_R = 213;
    private static final int TINT_G = 29;
    private static final int TINT_B = 29;
    private static final int TINT_A = 200;

    private static final List<Splash> SPLASHES = new ArrayList<>();

    static {
        for (int i = 0; i < FRAMES; i++) {
            TEXTURES[i] = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                    "textures/effect/blood_splash/" + i + ".png");
        }
    }

    private BloodSplashEffects() {
    }

    private static final class Splash {
        final Vec3 center;
        final float size;
        int age;

        Splash(Vec3 center, float size) {
            this.center = center;
            this.size = size;
        }
    }

    /** 3-5 salpicaduras repartidas por el interior de la caja del objetivo. */
    public static void spawn(Entity target, RandomSource random) {
        spawn(target.getX(), target.getY(), target.getZ(), target.getBbWidth(), target.getBbHeight(), random,
                FleshRippingRules.BLOOD_MIN, FleshRippingRules.BLOOD_MAX, FleshRippingRules.BLOOD_SIZE_MIN,
                FleshRippingRules.BLOOD_SIZE_MAX);
    }

    /** Igual, sobre una caja dada (x, y, z de los pies, ancho, alto) y con cuenta y tamaño propios. */
    public static void spawn(double x, double y, double z, float width, float height, RandomSource random,
            int minCount, int maxCount, float minSize, float maxSize) {
        int count = minCount + random.nextInt(maxCount - minCount + 1);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Mth.TWO_PI;
            double radius = 0.5 * width * Mth.nextDouble(random, 0.8, 1.0);
            Vec3 at = new Vec3(x + Math.cos(angle) * radius, y + random.nextDouble() * height,
                    z + Math.sin(angle) * radius);
            float size = Mth.nextFloat(random, minSize, maxSize);
            SPLASHES.add(new Splash(at, size));
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || SPLASHES.isEmpty()) {
            return;
        }
        for (Iterator<Splash> it = SPLASHES.iterator(); it.hasNext(); ) {
            if (++it.next().age >= FRAMES) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || SPLASHES.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        for (int frame = 0; frame < FRAMES; frame++) {
            RenderType type = null;
            VertexConsumer consumer = null;
            for (Splash splash : SPLASHES) {
                if (Math.min(splash.age, FRAMES - 1) != frame) {
                    continue;
                }
                if (consumer == null) {
                    type = ArcRenderType.arc(TEXTURES[frame]);
                    consumer = buffers.getBuffer(type);
                }
                draw(consumer, pose, splash.center.subtract(cam), splash.size * 0.5f, left, up);
            }
            if (type != null) {
                buffers.endBatch(type);
            }
        }
    }

    private static void draw(VertexConsumer consumer, PoseStack.Pose pose, Vec3 c, float half, Vector3f left,
            Vector3f up) {
        vertex(consumer, pose, c, left, up, half, -half, 1f, 1f);
        vertex(consumer, pose, c, left, up, half, half, 1f, 0f);
        vertex(consumer, pose, c, left, up, -half, half, 0f, 0f);
        vertex(consumer, pose, c, left, up, -half, -half, 0f, 1f);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 c, Vector3f left, Vector3f up,
            float dl, float du, float u, float v) {
        consumer.addVertex(pose, (float) c.x + left.x * dl + up.x * du, (float) c.y + left.y * dl + up.y * du,
                        (float) c.z + left.z * dl + up.z * du)
                .setColor(TINT_R, TINT_G, TINT_B, TINT_A)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        SPLASHES.clear();
    }
}
