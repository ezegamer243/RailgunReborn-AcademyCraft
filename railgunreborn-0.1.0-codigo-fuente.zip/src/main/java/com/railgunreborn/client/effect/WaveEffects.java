package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Onda de Vector Manipulation ({@code WaveEffect} del original): 2-3 anillos de halo ({@code glow_circle.png})
 * perpendiculares a una dirección, que avanzan, crecen y se desvanecen. La usa Directed Blastwave; pensada para
 * compartirse con Directed Shock y Vector Reflection. Se dibuja en el pase de partículas, sin iluminación.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class WaveEffects {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/glow_circle.png");
    private static final int LIFE = 15;
    private static final float ALPHA = 0.7f;
    /** Tope de ondas vivas a la vez (por si muchos jugadores golpean juntos). */
    private static final int MAX_WAVES = 32;

    private static final List<Wave> WAVES = new ArrayList<>();

    private WaveEffects() {
    }

    private record Ring(double offset, int life, int delay, float size) {
    }

    private static final class Wave {
        final Vec3 origin;
        final Vec3 forward;
        final Vec3 right;
        final Vec3 up;
        final List<Ring> rings;
        int age;

        Wave(Vec3 origin, Vec3 forward, List<Ring> rings) {
            this.origin = origin;
            this.forward = forward;
            Vec3 side = forward.cross(new Vec3(0, 1, 0));
            if (side.lengthSqr() < 1.0e-6) {
                side = new Vec3(1, 0, 0);
            }
            this.right = side.normalize();
            this.up = right.cross(forward).normalize();
            this.rings = rings;
        }
    }

    /**
     * Onda en {@code origin} hacia {@code direction}, con la dirección desviada al azar (yaw ±20°, pitch ±10°).
     */
    public static void spawn(Vec3 origin, Vec3 direction, RandomSource random) {
        if (WAVES.size() >= MAX_WAVES || direction.lengthSqr() < 1.0e-6) {
            return;
        }
        Vec3 dir = direction.normalize();
        float yaw = (float) Math.atan2(-dir.x, dir.z) + Mth.nextFloat(random, -20f, 20f) * Mth.DEG_TO_RAD;
        float pitch = (float) Math.asin(Mth.clamp(-dir.y, -1.0, 1.0)) + Mth.nextFloat(random, -10f, 10f)
                * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Mth.sin(yaw) * Mth.cos(pitch), -Mth.sin(pitch), Mth.cos(yaw) * Mth.cos(pitch));

        List<Ring> rings = new ArrayList<>();
        int count = 2 + random.nextInt(2);
        double offset = 0;
        for (int i = 0; i < count; i++) {
            rings.add(new Ring(offset, 8 + random.nextInt(4), 2 * i, Mth.nextFloat(random, 0.8f, 1.2f)));
            offset += Mth.nextDouble(random, 1.2, 1.8);
        }
        WAVES.add(new Wave(origin, forward, rings));
    }

    /** Curva de tamaño del original: 0.4 → 0.8 → 1.5 en 1.62 s. */
    static float sizeCurve(float seconds) {
        if (seconds < 0.25f) {
            return Mth.lerp(seconds / 0.25f, 0.4f, 0.8f);
        }
        return Mth.lerp(Math.min(1f, (seconds - 0.25f) / 1.37f), 0.8f, 1.5f);
    }

    /** Aparece en el primer 20 % de la vida del anillo y se apaga en el último 20 %. */
    static float alphaCurve(float progress) {
        if (progress < 0.2f) {
            return progress / 0.2f;
        }
        if (progress > 0.8f) {
            return Math.max(0f, (1f - progress) / 0.2f);
        }
        return 1f;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (Minecraft.getInstance().isPaused() || WAVES.isEmpty()) {
            return;
        }
        for (Iterator<Wave> it = WAVES.iterator(); it.hasNext(); ) {
            if (++it.next().age >= LIFE) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || WAVES.isEmpty()) {
            return;
        }
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = Minecraft.getInstance().renderBuffers().bufferSource();
        RenderType type = ArcRenderType.arc(TEXTURE);
        VertexConsumer consumer = buffers.getBuffer(type);
        for (Wave wave : WAVES) {
            float age = wave.age + partial;
            for (Ring ring : wave.rings) {
                float t = age - ring.delay();
                if (t < 0 || t >= ring.life()) {
                    continue;
                }
                float alpha = alphaCurve(t / ring.life()) * ALPHA;
                float half = 0.5f * ring.size() * sizeCurve(age / 20f);
                Vec3 c = wave.origin.add(wave.forward.scale(ring.offset() + age / 40.0)).subtract(cam);
                quad(consumer, pose, c, wave.right.scale(half), wave.up.scale(half), alpha);
            }
        }
        buffers.endBatch(type);
    }

    private static void quad(VertexConsumer consumer, PoseStack.Pose pose, Vec3 c, Vec3 r, Vec3 u, float alpha) {
        int a = Mth.clamp((int) (alpha * 255), 0, 255);
        vertex(consumer, pose, c.add(r).subtract(u), a, 1f, 1f);
        vertex(consumer, pose, c.add(r).add(u), a, 1f, 0f);
        vertex(consumer, pose, c.subtract(r).add(u), a, 0f, 0f);
        vertex(consumer, pose, c.subtract(r).subtract(u), a, 0f, 1f);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, int alpha, float u, float v) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(255, 255, 255, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        WAVES.clear();
    }
}
