package com.railgunreborn.client.effect;

import javax.annotation.Nullable;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.teleporter.TpMarkerRenderType;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Marcador de esquinas (8 esquinas con tres brazos de 0.2 del lado, vaivén de ±0.05, sin test de profundidad) que
 * comparten Shift Teleport y el apuntado de Threatening Teleport, Flesh Ripping y Blood Retrograde. Solo el jugador
 * local; quien apunta registra una fuente con {@link #show} y la quita con {@link #hide}.
 */
public final class TargetMarkerRenderer {
    public static final int GRAY_BLOCK = 0xB48B8B8B;
    /** Rojo de Shift Teleport, objetivo válido. */
    public static final int RED = 0xB4EB5151;
    /** Gris oscuro de Flesh Ripping, sin objetivo válido (alfa 160 del original). */
    public static final int GRAY_NO_TARGET = 0xA04A4A4A;

    private static final double CORNER_FRACTION = 0.2;
    private static final double BOB_AMPLITUDE = 0.05;
    private static final double BOB_PERIOD_MS = 400.0;

    /** Caja en coordenadas del mundo y su color ARGB. */
    public record Marker(AABB box, int argb) {
    }

    /** Fuente de un marcador, evaluada en cada fotograma. */
    @FunctionalInterface
    public interface Source {
        @Nullable
        Marker at(float partialTick);
    }

    @Nullable
    private static Object owner;
    @Nullable
    private static Source source;

    private TargetMarkerRenderer() {
    }

    public static void show(Object newOwner, Source newSource) {
        owner = newOwner;
        source = newSource;
    }

    /** Quita el marcador solo si lo puso {@code who} (otro contexto pudo tomar el relevo). */
    public static void hide(Object who) {
        if (owner == who) {
            owner = null;
            source = null;
        }
    }

    /**
     * Marcador de un trazado de apuntado: rojo (el de Shift Teleport) sobre la caja del objetivo ×1.2 si es válido;
     * gris oscuro sobre el objetivo si es un jugador al que no se puede dañar; gris pequeño en {@code point} sin
     * objetivo.
     */
    public static Marker forTarget(Player viewer, @Nullable Entity target, Vec3 point, float partialTick) {
        if (target == null) {
            return new Marker(TargetMarkerBoxes.around(point, TargetMarkerBoxes.POINT_SIZE), GRAY_NO_TARGET);
        }
        Vec3 offset = target.getPosition(partialTick).subtract(target.position());
        AABB box = TargetMarkerBoxes.scaled(target.getBoundingBox().move(offset), TargetMarkerBoxes.TARGET_SCALE);
        boolean protectedPlayer = target instanceof Player other && !viewer.canHarmPlayer(other);
        return new Marker(box, protectedPlayer ? GRAY_NO_TARGET : RED);
    }

    /** Dibuja las cajas dadas (coordenadas del mundo); llamar en {@code AFTER_LEVEL}. */
    public static void draw(RenderLevelStageEvent event, Marker... markers) {
        Minecraft mc = Minecraft.getInstance();
        Vec3 camera = event.getCamera().getPosition();
        double bob = BOB_AMPLITUDE * Math.sin(Util.getMillis() / BOB_PERIOD_MS);

        // En AFTER_LEVEL la vista no está en el estado de render: se aplica a mano, como Mine Detection.
        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        PoseStack.Pose pose = poseStack.last();

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(TpMarkerRenderType.LINES);
        for (Marker marker : markers) {
            corners(consumer, pose, marker.box().move(-camera.x, bob - camera.y, -camera.z), marker.argb());
        }
        buffers.endBatch(TpMarkerRenderType.LINES);
    }

    /** Tres brazos hacia dentro desde cada una de las 8 esquinas. */
    private static void corners(VertexConsumer c, PoseStack.Pose pose, AABB box, int argb) {
        double lx = box.getXsize() * CORNER_FRACTION;
        double ly = box.getYsize() * CORNER_FRACTION;
        double lz = box.getZsize() * CORNER_FRACTION;
        for (int i = 0; i < 8; i++) {
            boolean maxX = (i & 1) != 0;
            boolean maxY = (i & 2) != 0;
            boolean maxZ = (i & 4) != 0;
            float x = (float) (maxX ? box.maxX : box.minX);
            float y = (float) (maxY ? box.maxY : box.minY);
            float z = (float) (maxZ ? box.maxZ : box.minZ);
            float sx = maxX ? -1f : 1f;
            float sy = maxY ? -1f : 1f;
            float sz = maxZ ? -1f : 1f;
            line(c, pose, argb, x, y, z, x + sx * (float) lx, y, z, sx, 0f, 0f);
            line(c, pose, argb, x, y, z, x, y + sy * (float) ly, z, 0f, sy, 0f);
            line(c, pose, argb, x, y, z, x, y, z + sz * (float) lz, 0f, 0f, sz);
        }
    }

    private static void line(VertexConsumer c, PoseStack.Pose pose, int argb, float ax, float ay, float az,
            float bx, float by, float bz, float nx, float ny, float nz) {
        Matrix4f m = pose.pose();
        c.addVertex(m, ax, ay, az).setColor(argb).setNormal(pose, nx, ny, nz);
        c.addVertex(m, bx, by, bz).setColor(argb).setNormal(pose, nx, ny, nz);
    }

    /** Dibujo del marcador activo y limpieza (bus del juego). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
    public static final class Render {
        private Render() {
        }

        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            Source current = source;
            Minecraft mc = Minecraft.getInstance();
            if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null || mc.level == null
                    || mc.player == null) {
                return;
            }
            Marker marker = current.at(event.getPartialTick().getGameTimeDeltaPartialTick(false));
            if (marker != null) {
                draw(event, marker);
            }
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            owner = null;
            source = null;
        }

        /** Morir o cambiar de dimensión recrea el jugador local: el marcador se quita. */
        @SubscribeEvent
        public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
            owner = null;
            source = null;
        }
    }
}
