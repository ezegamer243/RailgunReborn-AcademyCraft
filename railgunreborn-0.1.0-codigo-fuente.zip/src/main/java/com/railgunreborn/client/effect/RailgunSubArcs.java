package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Mini-arcos a lo largo del rayo del Railgun (ficha railgun §9.1): chispas cada 1-2 bloques desde 1.0 hasta la
 * longitud, a 0.1-0.25 del eje con ángulo y orientación al azar, escaladas a 0.3. Cambian de forma y parpadean
 * ({@code frameRate}/{@code switchRate} 1.0) y se borran todas en el tick 30. Van en {@link ArcEffects} (textura
 * {@code line_segment}).
 */
public final class RailgunSubArcs implements LiveArc {
    private static final int LIFE = 30;
    private static final float SCALE = 0.3f;

    private final RailgunBeamEffect beam;
    private final List<SubArc> arcs = new ArrayList<>();
    private int age;

    public RailgunSubArcs(RailgunBeamEffect beam, RandomGenerator rand) {
        this.beam = beam;
        ArcPattern[] templates = Templates.PATTERNS;
        for (double s = 1.0; s < beam.length(); s += 1.0 + rand.nextDouble()) {
            double angle = rand.nextDouble() * Math.PI * 2;
            double radius = 0.1 + rand.nextDouble() * 0.15;
            Vec3 offset = beam.right().scale(Math.cos(angle) * radius).add(beam.up().scale(Math.sin(angle) * radius));
            arcs.add(new SubArc(beam.dir().scale(s).add(offset), rand.nextInt(templates.length),
                    rand.nextFloat() * 360f, rand.nextFloat() * 360f, rand.nextFloat() * 360f));
        }
    }

    @Override
    public boolean tick(RandomGenerator rand) {
        if (++age >= LIFE) {
            return false;
        }
        for (SubArc arc : arcs) {
            if (rand.nextDouble() < 0.5) {
                arc.patternIndex = rand.nextInt(Templates.PATTERNS.length);
            }
            if (rand.nextDouble() < (arc.visible ? 0.4 : 0.3)) {
                arc.visible = !arc.visible;
            }
        }
        return true;
    }

    @Override
    public Level level() {
        return beam.level();
    }

    @Override
    public void render(PoseStack poseStack, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        Vec3 start = beam.origin()
                .add(RailgunBeamEffect.handOffset(beam.caster(), beam.dir(), beam.right(), beam.up()))
                .subtract(camera);
        for (SubArc arc : arcs) {
            if (!arc.visible) {
                continue;
            }
            ArcPattern pattern = Templates.PATTERNS[arc.patternIndex];
            poseStack.pushPose();
            poseStack.translate(start.x + arc.pos.x, start.y + arc.pos.y, start.z + arc.pos.z);
            poseStack.mulPose(Axis.ZP.rotationDegrees(arc.rotZ));
            poseStack.mulPose(Axis.YP.rotationDegrees(arc.rotY));
            poseStack.mulPose(Axis.XP.rotationDegrees(arc.rotX));
            poseStack.scale(SCALE, SCALE, SCALE);
            poseStack.translate(-pattern.length() / 2, 0, 0);
            LiveArc.drawPattern(pattern, Double.MAX_VALUE, poseStack, consumer, rand);
            poseStack.popPose();
        }
    }

    private static final class SubArc {
        final Vec3 pos;
        final float rotX;
        final float rotY;
        final float rotZ;
        int patternIndex;
        boolean visible = true;

        SubArc(Vec3 pos, int patternIndex, float rotX, float rotY, float rotZ) {
            this.pos = pos;
            this.patternIndex = patternIndex;
            this.rotX = rotX;
            this.rotY = rotY;
            this.rotZ = rotZ;
        }
    }

    /** 15 plantillas de longitud 2-3 con los parámetros de los mini-arcos (los de {@code surroundFactory(0.3)}). */
    private static final class Templates {
        static final ArcPattern[] PATTERNS = ArcPatterns.surroundFactory(0.3).generateList(15, 2.0, 3.0, new Random());
    }
}
