package com.railgunreborn.client.effect;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.RenderType;

/**
 * Color plano translúcido sin textura (los cilindros del Railgun). Shader del rayo de tormenta (posición + color, con
 * niebla), pero con mezcla alfa estándar en vez de aditiva, sin culling y sin escribir profundidad. Sin ordenar al
 * subir: los cilindros se dibujan en el orden en que se mandan (halo y luego núcleo).
 */
final class BeamRenderType extends RenderType {
    static final RenderType COLOR = create(
            "railgunreborn_beam_color",
            DefaultVertexFormat.POSITION_COLOR,
            VertexFormat.Mode.QUADS,
            1536,
            false,
            false,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .setOutputState(PARTICLES_TARGET)
                    .createCompositeState(false));

    private BeamRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
