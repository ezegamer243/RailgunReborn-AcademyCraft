package com.railgunreborn.client.effect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;

import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;

/**
 * Efectos de cliente del Railgun: rayos ({@link RailgunBeamEffect}, con sus mini-arcos en {@link ArcEffects}) y
 * chispas en la mano ({@code RailgunHandEffect} del original, ficha §9.3: 40 fotogramas de {@code arc_burst} a 25 por
 * segundo). Misma técnica que {@link ArcEffects}: lista propia avanzada en el tick y dibujada en
 * {@code AFTER_PARTICLES}. Solo cliente.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class RailgunEffects {
    private static final int SPARK_FRAMES = 40;
    private static final long SPARK_FRAME_MS = 40L;
    private static final ResourceLocation[] SPARK_TEXTURES = new ResourceLocation[SPARK_FRAMES];

    static {
        for (int i = 0; i < SPARK_FRAMES; i++) {
            SPARK_TEXTURES[i] = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                    "textures/effect/arc_burst/" + i + ".png");
        }
    }

    // Chispas: primera persona (respecto a la cámara: derecha, arriba, adelante) y tercera (sobre los ojos).
    private static final double SPARK_FP_RIGHT = 0.26;
    private static final double SPARK_FP_UP = -0.15;
    private static final double SPARK_FP_FORWARD = 0.6;
    private static final double SPARK_FP_HALF_SIZE = 0.25;
    private static final double SPARK_TP_FORWARD = 1.0;
    private static final double SPARK_TP_UP = 0.18;
    private static final double SPARK_TP_HALF_SIZE = 1.0;

    private static final List<RailgunBeamEffect> BEAMS = new ArrayList<>();
    /** Inicio (ms) de las chispas por jugador (id de entidad). */
    private static final Map<Integer, Spark> SPARKS = new HashMap<>();
    private static final Random RANDOM = new Random();

    private RailgunEffects() {
    }

    private record Spark(Player player, long start) {
    }

    /** Rayo del disparo, fijo en {@code origin} (ojos) hacia {@code dir}, con sus mini-arcos. */
    public static void spawnBeam(Player caster, Vec3 origin, Vec3 dir, double length) {
        RailgunBeamEffect beam = new RailgunBeamEffect(caster, origin, dir, length);
        BEAMS.add(beam);
        ArcEffects.spawn(new RailgunSubArcs(beam, RANDOM));
    }

    /** Chispas en la mano de {@code player} durante 1.6 s (se reinician si ya las tenía). */
    public static void startHandSparks(Player player) {
        SPARKS.put(player.getId(), new Spark(player, Util.getMillis()));
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused()) {
            return;
        }
        RayRenderer.tick(BEAMS, mc.level, RANDOM);
        long now = Util.getMillis();
        SPARKS.values().removeIf(s -> s.player.isRemoved() || s.player.level() != mc.level
                || now - s.start >= SPARK_FRAMES * SPARK_FRAME_MS);
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || (BEAMS.isEmpty() && SPARKS.isEmpty())) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Vec3 camera = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);

        RayRenderer.render(BEAMS, mc.level, pose, buffers, camera, partialTick, RANDOM);

        long now = Util.getMillis();
        for (Spark spark : SPARKS.values()) {
            if (spark.player.level() != mc.level) {
                continue;
            }
            int frame = (int) Math.min(SPARK_FRAMES - 1, Math.max(0, (now - spark.start) / SPARK_FRAME_MS));
            RenderType type = ArcRenderType.arc(SPARK_TEXTURES[frame]);
            renderSpark(spark.player, event.getCamera(), pose, buffers.getBuffer(type), camera, partialTick);
            buffers.endBatch(type);
        }
    }

    /** Cuadrado de cara a la cámara en la mano (primera persona) o delante de la cara (tercera persona / otros). */
    private static void renderSpark(Player player, Camera cam, PoseStack.Pose pose, VertexConsumer consumer,
            Vec3 camera, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        Vector3f leftF = cam.getLeftVector();
        Vector3f upF = cam.getUpVector();
        Vector3f lookF = cam.getLookVector();
        Vec3 left = new Vec3(leftF.x(), leftF.y(), leftF.z());
        Vec3 up = new Vec3(upF.x(), upF.y(), upF.z());
        Vec3 center;
        double half;
        if (player == mc.player && mc.options.getCameraType().isFirstPerson()) {
            Vec3 look = new Vec3(lookF.x(), lookF.y(), lookF.z());
            center = camera.add(look.scale(SPARK_FP_FORWARD)).add(left.scale(-SPARK_FP_RIGHT))
                    .add(up.scale(SPARK_FP_UP));
            half = SPARK_FP_HALF_SIZE;
        } else {
            center = player.getEyePosition(partialTick).add(player.getViewVector(partialTick).scale(SPARK_TP_FORWARD))
                    .add(0, SPARK_TP_UP, 0);
            half = SPARK_TP_HALF_SIZE;
        }
        Vec3 c = center.subtract(camera);
        Vec3 l = left.scale(half);
        Vec3 u = up.scale(half);
        LiveArc.vertex(consumer, pose, c.x + l.x + u.x, c.y + l.y + u.y, c.z + l.z + u.z, 0f, 0f, 1f);
        LiveArc.vertex(consumer, pose, c.x + l.x - u.x, c.y + l.y - u.y, c.z + l.z - u.z, 0f, 1f, 1f);
        LiveArc.vertex(consumer, pose, c.x - l.x - u.x, c.y - l.y - u.y, c.z - l.z - u.z, 1f, 1f, 1f);
        LiveArc.vertex(consumer, pose, c.x - l.x + u.x, c.y - l.y + u.y, c.z - l.z + u.z, 1f, 0f, 1f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        BEAMS.clear();
        SPARKS.clear();
    }
}
