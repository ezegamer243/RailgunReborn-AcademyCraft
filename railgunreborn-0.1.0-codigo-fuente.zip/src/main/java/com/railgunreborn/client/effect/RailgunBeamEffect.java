package com.railgunreborn.client.effect;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * El rayo del Railgun ({@code EntityRailgunFX} del original, ficha railgun §9.1), sin entidad: fijo en el mundo con el
 * origen (ojos) y la dirección del disparo. Tres capas: resplandor naranja (cinta orientada a la cámara con las
 * texturas {@code railgun/blend_in}, {@code tile} y {@code blend_out}), halo naranja (cilindro de radio 0.13) y núcleo
 * crema (cilindro de radio 0.09). Crece en 150 ms, se desvanece el último segundo y se estrecha los últimos 0.8 s.
 * El dibujo es el común ({@link RayEffect}, {@link RayRenderer}) con {@link #STYLE}. Los mini-arcos van aparte
 * ({@link RailgunSubArcs}). Lo maneja {@link RailgunEffects}.
 */
public final class RailgunBeamEffect extends RayEffect {
    public static final int LIFE_TICKS = 50;

    public static final RayStyle STYLE = RayStyle.builder("railgun")
            .glow(1.1, -0.3, 0.3, 1.1)
            .glowColor(0xFFFFFFFF, 0.2)
            // Halo naranja (236, 170, 93, 60) y núcleo crema (241, 240, 222, 200).
            .cylinders(0.13, RayStyle.rgba(236, 170, 93, 60), 0.09, RayStyle.rgba(241, 240, 222, 200))
            .timing(LIFE_TICKS, 150.0, 1000.0, 800.0)
            .wiggle(0.3, 0.8)
            .fromHand(true)
            .build();

    static final ResourceLocation[] GLOW_TEXTURES = STYLE.glowTextures;

    public RailgunBeamEffect(Player caster, Vec3 origin, Vec3 dir, double length) {
        super(STYLE, caster, origin, dir, length);
    }
}
