package com.railgunreborn.client.effect;

import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.ability.common.TunnelRules;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Un rayo fijo en el mundo (origen + dirección + longitud) dibujado con un {@link RayStyle}: cinta de resplandor de tres
 * texturas orientada a la cámara, halo y núcleo cilíndricos. Crece al empezar, se desvanece y estrecha al final, con
 * un temblor del ancho. Lo avanza y dibuja {@link RayRenderer} (o {@link RayEffects}). Solo cliente.
 */
public class RayEffect {
    private static final int CYLINDER_SIDES = 12;

    // Desplazamientos a la mano en el espacio del rayo (X adelante, Y arriba, Z derecha), los mismos que ArcEffect.
    private static final Vec3 HAND_FIRST_PERSON = new Vec3(-0.05, -0.25, 0.2);
    private static final Vec3 HAND_THIRD_PERSON = new Vec3(0.15, -0.8, 0.23);

    private final RayStyle style;
    private final Player caster;
    private final Vec3 origin;
    private final Vec3 dir;
    private final Vec3 right;
    private final Vec3 up;
    private final double length;

    private int age;
    private double wiggle;
    private double wiggleTarget;

    /**
     * @param caster quien lo lanza (para el desplazamiento a la mano y para saber en qué mundo vive)
     */
    public RayEffect(RayStyle style, Player caster, Vec3 origin, Vec3 dir, double length) {
        this.style = style;
        this.caster = caster;
        this.origin = origin;
        this.dir = dir.normalize();
        Vec3[] axes = axes(this.dir);
        this.right = axes[0];
        this.up = axes[1];
        this.length = length;
    }

    /** {@code [derecha, arriba]} perpendiculares a {@code dir}, con la misma regla que la geometría del servidor. */
    public static Vec3[] axes(Vec3 dir) {
        TunnelRules.Vec[] axes = TunnelRules.perpendicularAxes(new TunnelRules.Vec(dir.x, dir.y, dir.z));
        return new Vec3[] {
                new Vec3(axes[0].x(), axes[0].y(), axes[0].z()),
                new Vec3(axes[1].x(), axes[1].y(), axes[1].z())
        };
    }

    /** Desplazamiento (en el mundo) del origen visual a la mano del lanzador, según la vista actual. */
    public static Vec3 handOffset(Player caster, Vec3 dir, Vec3 right, Vec3 up) {
        Minecraft mc = Minecraft.getInstance();
        boolean firstPerson = caster == mc.player && mc.options.getCameraType().isFirstPerson();
        Vec3 local = firstPerson ? HAND_FIRST_PERSON : HAND_THIRD_PERSON;
        return dir.scale(local.x).add(up.scale(local.y)).add(right.scale(local.z));
    }

    public RayStyle style() {
        return style;
    }

    public Player caster() {
        return caster;
    }

    public Level level() {
        return caster.level();
    }

    public Vec3 origin() {
        return origin;
    }

    public Vec3 dir() {
        return dir;
    }

    public Vec3 right() {
        return right;
    }

    public Vec3 up() {
        return up;
    }

    public double length() {
        return length;
    }

    public int age() {
        return age;
    }

    /** Origen visual: el de la mano si el estilo lo pide. */
    public Vec3 visualStart() {
        return style.fromHand ? origin.add(handOffset(caster, dir, right, up)) : origin;
    }

    /** Geometría con la que se dibuja un fotograma: inicio visual, dirección (unitaria), ejes y longitud total. */
    protected record Frame(Vec3 start, Vec3 dir, Vec3 right, Vec3 up, double length) {
        /** Con los ejes calculados a partir de la dirección. */
        public static Frame of(Vec3 start, Vec3 dir, double length) {
            Vec3 d = dir.normalize();
            Vec3[] axes = axes(d);
            return new Frame(start, d, axes[0], axes[1], length);
        }
    }

    /**
     * Geometría de este fotograma. Por defecto la fija del constructor; un rayo que sigue a su lanzador (Mining Ray)
     * la recalcula con el tick parcial.
     */
    protected Frame frame(float partialTick) {
        return new Frame(visualStart(), dir, right, up, length);
    }

    /** false = terminado. */
    public boolean tick(RandomGenerator rand) {
        if (++age >= style.lifeTicks) {
            return false;
        }
        if (Math.abs(wiggleTarget - wiggle) <= style.wiggleSpeed) {
            wiggle = wiggleTarget;
            wiggleTarget = rand.nextDouble() * style.maxWiggle;
        } else {
            wiggle += Math.signum(wiggleTarget - wiggle) * style.wiggleSpeed;
        }
        return true;
    }

    private double ms(float partialTick) {
        return (age + partialTick) * 50.0;
    }

    private double lifeMs() {
        return style.lifeTicks * 50.0;
    }

    private double alpha(double ms) {
        return Mth.clamp((lifeMs() - ms) / style.blendOutMs, 0.0, 1.0);
    }

    private double widthFactor(double ms) {
        return (1.0 + wiggle) * Mth.clamp((lifeMs() - ms) / style.shrinkMs, 0.0, 1.0);
    }

    private double currentLength(double ms, Frame frame) {
        return frame.length() * Mth.clamp(ms / style.blendInMs, 0.0, 1.0);
    }

    /**
     * Un tramo del resplandor ({@code part}: 0 entrada, 1 centro, 2 salida), en la cinta con su textura. El ancho de
     * la cinta se orienta hacia la cámara alrededor del eje.
     */
    void renderGlow(int part, PoseStack.Pose pose, VertexConsumer consumer, Vec3 camera, float partialTick,
            RandomGenerator rand) {
        double ms = ms(partialTick);
        Frame frame = frame(partialTick);
        double len = currentLength(ms, frame);
        Vec3 start = frame.start();
        Vec3 dir = frame.dir();
        double s0 = style.glowStart;
        double s3 = len + style.glowEndExtra;
        double mid = (s0 + s3) / 2;
        double s1 = Math.min(s0 + style.glowCap, mid);
        double s2 = Math.max(s3 - style.glowCap, mid);
        double from = part == 0 ? s0 : part == 1 ? s1 : s2;
        double to = part == 0 ? s1 : part == 1 ? s2 : s3;
        if (to - from < 1.0e-4) {
            return;
        }
        // Lado de la cinta: perpendicular al eje y a la línea hacia la cámara desde el punto más cercano del eje.
        double t = Mth.clamp(camera.subtract(start).dot(dir), 0.0, len);
        Vec3 side = dir.cross(camera.subtract(start.add(dir.scale(t))));
        side = side.lengthSqr() < 1.0e-8 ? frame.right() : side.normalize();
        side = side.scale(style.glowWidth / 2 * widthFactor(ms));
        double flicker = 1.0 + (rand.nextDouble() - 0.5) * style.glowFlicker;
        float a = (float) Mth.clamp(alpha(ms) * flicker * (style.glowColor >>> 24) / 255.0, 0.0, 1.0);
        float u1 = part == 1 && style.repeatTile && style.glowWidth > 0 ? (float) ((to - from) / style.glowWidth) : 1f;

        Vec3 p0 = start.add(dir.scale(from)).subtract(camera);
        Vec3 p1 = start.add(dir.scale(to)).subtract(camera);
        int c = style.glowColor;
        glowVertex(consumer, pose, p0.add(side), 0f, 0f, c, a);
        glowVertex(consumer, pose, p0.subtract(side), 0f, 1f, c, a);
        glowVertex(consumer, pose, p1.subtract(side), u1, 1f, c, a);
        glowVertex(consumer, pose, p1.add(side), u1, 0f, c, a);
    }

    private static void glowVertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, float u, float v, int argb,
            float alpha) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor((argb >> 16 & 0xFF) / 255f, (argb >> 8 & 0xFF) / 255f, (argb & 0xFF) / 255f, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    /** Halo y núcleo, en ese orden. */
    void renderCylinders(PoseStack.Pose pose, VertexConsumer consumer, Vec3 camera, float partialTick) {
        double ms = ms(partialTick);
        Frame frame = frame(partialTick);
        double len = currentLength(ms, frame);
        if (len < 1.0e-3) {
            return;
        }
        double alpha = alpha(ms);
        double width = widthFactor(ms);
        Vec3 start = frame.start().subtract(camera);
        cylinder(pose, consumer, frame, start, len, style.outerRadius * width, style.outerColor, alpha);
        cylinder(pose, consumer, frame, start, len, style.innerRadius * width, style.innerColor, alpha);
    }

    private static void cylinder(PoseStack.Pose pose, VertexConsumer consumer, Frame frame, Vec3 start, double len,
            double radius, int argb, double alpha) {
        Vec3 dir = frame.dir();
        Vec3 right = frame.right();
        Vec3 up = frame.up();
        float a = (float) ((argb >>> 24) / 255.0 * alpha);
        if (radius < 1.0e-4 || a <= 0f) {
            return;
        }
        float r = (argb >> 16 & 0xFF) / 255f;
        float g = (argb >> 8 & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        Vec3 end = start.add(dir.scale(len));
        for (int i = 0; i < CYLINDER_SIDES; i++) {
            double t0 = Math.PI * 2 * i / CYLINDER_SIDES;
            double t1 = Math.PI * 2 * (i + 1) / CYLINDER_SIDES;
            Vec3 o0 = right.scale(Math.cos(t0) * radius).add(up.scale(Math.sin(t0) * radius));
            Vec3 o1 = right.scale(Math.cos(t1) * radius).add(up.scale(Math.sin(t1) * radius));
            colorVertex(consumer, pose, start.add(o0), r, g, b, a);
            colorVertex(consumer, pose, start.add(o1), r, g, b, a);
            colorVertex(consumer, pose, end.add(o1), r, g, b, a);
            colorVertex(consumer, pose, end.add(o0), r, g, b, a);
        }
    }

    private static void colorVertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, float r, float g, float b,
            float a) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z).setColor(r, g, b, a);
    }
}
