package com.railgunreborn.client.effect;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.random.RandomGenerator;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Dibujo compartido de rayos ({@link RayEffect} con su {@link RayStyle}): Railgun y los rayos de Meltdowner. Primero
 * las tres partes del resplandor (agrupadas por textura, en el tipo de render de los arcos) y luego los cilindros en
 * color plano ({@link BeamRenderType#COLOR}). Se llama en {@code RenderLevelStageEvent} {@code AFTER_PARTICLES}.
 */
public final class RayRenderer {
    private RayRenderer() {
    }

    /** Avanza los rayos y quita los terminados o de otro mundo. */
    public static void tick(List<? extends RayEffect> rays, Level currentLevel, RandomGenerator rand) {
        for (Iterator<? extends RayEffect> it = rays.iterator(); it.hasNext(); ) {
            RayEffect ray = it.next();
            if (ray.level() != currentLevel || !ray.tick(rand)) {
                it.remove();
            }
        }
    }

    /** Dibuja los rayos del mundo {@code currentLevel}. */
    public static void render(List<? extends RayEffect> rays, Level currentLevel, PoseStack.Pose pose,
            MultiBufferSource.BufferSource buffers, Vec3 camera, float partialTick, RandomGenerator rand) {
        if (rays.isEmpty()) {
            return;
        }
        for (int part = 0; part < 3; part++) {
            Map<ResourceLocation, List<RayEffect>> byTexture = new LinkedHashMap<>();
            for (RayEffect ray : rays) {
                if (ray.level() == currentLevel) {
                    byTexture.computeIfAbsent(ray.style().glowTextures[part], k -> new java.util.ArrayList<>())
                            .add(ray);
                }
            }
            for (Map.Entry<ResourceLocation, List<RayEffect>> entry : byTexture.entrySet()) {
                RenderType type = ArcRenderType.arc(entry.getKey());
                VertexConsumer consumer = buffers.getBuffer(type);
                for (RayEffect ray : entry.getValue()) {
                    ray.renderGlow(part, pose, consumer, camera, partialTick, rand);
                }
                buffers.endBatch(type);
            }
        }
        VertexConsumer color = buffers.getBuffer(BeamRenderType.COLOR);
        for (RayEffect ray : rays) {
            if (ray.level() == currentLevel) {
                ray.renderCylinders(pose, color, camera, partialTick);
            }
        }
        buffers.endBatch(BeamRenderType.COLOR);
    }
}
