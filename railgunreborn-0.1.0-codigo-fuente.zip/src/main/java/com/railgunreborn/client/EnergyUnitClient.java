package com.railgunreborn.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.energy.EnergyMath;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.registry.ModItems;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/** Textura de las baterías (Energy Unit, High, Mega) según su carga: predicado {@code railgunreborn:energy} (0 vacía, 0.5 media, 1 llena). */
@EventBusSubscriber(modid = RailgunReborn.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class EnergyUnitClient {
    private EnergyUnitClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            for (EnergyUnitItem item : new EnergyUnitItem[] {ModItems.ENERGY_UNIT.get(),
                    ModItems.ENERGY_UNIT_HIGH.get(), ModItems.ENERGY_UNIT_MEGA.get()}) {
                ItemProperties.register(item, ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "energy"),
                        (stack, level, entity, seed) -> EnergyMath.chargeState(EnergyUnitItem.getEnergy(stack),
                                EnergyUnitItem.capacityOf(stack)));
            }
        });
    }
}
