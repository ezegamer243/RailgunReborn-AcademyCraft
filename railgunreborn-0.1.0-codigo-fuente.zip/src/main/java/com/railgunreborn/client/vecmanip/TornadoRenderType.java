package com.railgunreborn.client.vecmanip;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * Anillos de los torbellinos de Storm Wing ({@code TornadoEffect} del original; compartible con Plasma Cannon).
 * Hereda de {@link RenderType} solo para acceder a los "shards" protegidos; nunca se instancia.
 *
 * <p>Como los arcos: color × textura sin iluminación, mezcla alfa, sin culling y sin escribir profundidad (los anillos
 * superpuestos no se tapan entre sí), con test de profundidad. Se dibuja en el destino de partículas.
 */
public final class TornadoRenderType extends RenderType {
    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/tornado_ring.png");

    public static final RenderType TORNADO = create(
            "railgunreborn_tornado",
            DefaultVertexFormat.NEW_ENTITY,
            VertexFormat.Mode.QUADS,
            1536,
            false,
            true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_EYES_SHADER)
                    .setTextureState(new TextureStateShard(TEXTURE, false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .setOutputState(PARTICLES_TARGET)
                    .createCompositeState(false));

    public static final ResourceLocation GLOW_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/effect/glow_circle.png");

    /**
     * Halos del cuerpo de plasma de Plasma Cannon: mezcla aditiva que respeta el alfa de la textura (con la aditiva
     * pura se veía el cuadrado entero).
     */
    public static final RenderType PLASMA_GLOW = create(
            "railgunreborn_plasma_glow",
            DefaultVertexFormat.NEW_ENTITY,
            VertexFormat.Mode.QUADS,
            1536,
            false,
            true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_EYES_SHADER)
                    .setTextureState(new TextureStateShard(GLOW_TEXTURE, false, false))
                    .setTransparencyState(LIGHTNING_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setWriteMaskState(COLOR_WRITE)
                    .setOutputState(PARTICLES_TARGET)
                    .createCompositeState(false));

    private TornadoRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
