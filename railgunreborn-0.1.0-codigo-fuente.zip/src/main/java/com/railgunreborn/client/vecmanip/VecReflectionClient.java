package com.railgunreborn.client.vecmanip;

import org.joml.Vector3f;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.ability.vecmanip.VecReflectionRules;
import com.railgunreborn.ability.vecmanip.VecReflectionSkill;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.RailgunEffects;
import com.railgunreborn.client.effect.RayEffect;
import com.railgunreborn.client.effect.RayEffects;
import com.railgunreborn.client.effect.WaveEffects;
import com.railgunreborn.client.meltdowner.MdRayStyles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Vector Reflection. El brillo del icono mientras el campo está activo lo pone {@code KeyHintHud} solo.
 * Aquí: onda 3D (la de Directed Blastwave) y sonido moderado en cada reflejo; en los rayos, además, el rayo de vuelta
 * con el estilo del atacante; y mientras el campo dura, unas pocas partículas tenues alrededor del jugador. Decisión:
 * nada en pantalla (las ondas de pantalla del original no se portan). Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class VecReflectionClient {
    private static final int PULSE_POINTS = 8;
    private static final double PULSE_RADIUS = 1.4;
    private static final DustParticleOptions PULSE_DUST =
            new DustParticleOptions(new Vector3f(0.8f, 0.88f, 1f), 0.45f);

    private VecReflectionClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.VEC_REFLECTION.getId(), VecReflectionClient::effect);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        Level level = caster.level();
        if (VecReflectionSkill.CHANNEL_PULSE.equals(channel)) {
            pulse(level, caster);
            return;
        }
        if (!VecReflectionSkill.CHANNEL_REFLECT.equals(channel) && !VecReflectionSkill.CHANNEL_BEAM.equals(channel)) {
            return;
        }
        Vec3 pos = MagMovementSkill.readVec(data, VecReflectionSkill.POS_KEY);
        Vec3 dir = MagMovementSkill.readVec(data, VecReflectionSkill.DIR_KEY);
        WaveEffects.spawn(pos, dir, caster.getRandom());
        level.playLocalSound(pos.x, pos.y, pos.z, ModSounds.VM_VEC_REFLECTION.get(), SoundSource.PLAYERS,
                VecReflectionRules.SOUND_VOLUME, 1f, false);
        if (VecReflectionSkill.CHANNEL_BEAM.equals(channel)) {
            beam(caster, dir, data);
        }
    }

    /** Rayo de vuelta desde los ojos del reflector, con el estilo de la habilidad que disparó. */
    private static void beam(Player caster, Vec3 dir, CompoundTag data) {
        double length = Math.min(data.getFloat(VecReflectionSkill.LENGTH_KEY), 10.0);
        if (length < 1.0e-3 || dir.lengthSqr() < 1.0e-6) {
            return;
        }
        String skill = data.getString(VecReflectionSkill.BEAM_KEY);
        Vec3 eye = caster.getEyePosition();
        if (skill.equals(Electromaster.RAILGUN.getId().toString())) {
            RailgunEffects.spawnBeam(caster, eye, dir, length);
        } else if (skill.equals(Meltdowner.MELTDOWNER.getId().toString())) {
            RayEffects.spawn(new RayEffect(MdRayStyles.LARGE, caster, eye, dir, length));
        }
    }

    /** Anillo tenue de partículas a la altura de la cintura: se ve que el campo está activo sin tapar nada. */
    private static void pulse(Level level, Player caster) {
        double y = caster.getY() + caster.getBbHeight() * 0.35;
        double phase = caster.getRandom().nextDouble() * Math.PI * 2;
        for (int i = 0; i < PULSE_POINTS; i++) {
            double a = phase + Math.PI * 2 * i / PULSE_POINTS;
            level.addParticle(PULSE_DUST, caster.getX() + Math.cos(a) * PULSE_RADIUS, y,
                    caster.getZ() + Math.sin(a) * PULSE_RADIUS, 0, 0.01, 0);
        }
    }
}
