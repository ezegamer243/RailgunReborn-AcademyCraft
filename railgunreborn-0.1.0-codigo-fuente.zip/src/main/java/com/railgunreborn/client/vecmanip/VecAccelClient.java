package com.railgunreborn.client.vecmanip;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Vector Acceleration: contorno de carga en el icono (20 ticks, azul que se vuelve blanco al llegar al
 * máximo) y línea de previsión ({@link VecAccelPreview}). El sonido lo manda el servidor. Bus del mod (solo el
 * registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class VecAccelClient {
    private static final int BLUE = 0xFF4AA3FF;
    private static final int FULL = 0xFFFFFFFF;

    /** Un tick más que la carga máxima para que el tracker no se corte (y se funda) justo al llegar a 20. */
    public static final ChargeOutline OUTLINE = ChargeOutline.builder(21)
            .band(20, BLUE)
            .band(21, FULL)
            .build();

    static final ChargeTracker TRACKER = new ChargeTracker(OUTLINE.totalTicks());

    private VecAccelClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        ClientSkillContexts.registerFactory(VecManip.VEC_ACCEL.getId(), VecAccelClientContext::new);
        KeyHintHud.registerChargeOutline(VecManip.VEC_ACCEL.getId(), TRACKER, OUTLINE);
    }

    /** Mitad local: cuenta los ticks de carga para el contorno y la previsión. */
    private static final class VecAccelClientContext extends ClientSkillContext {
        VecAccelClientContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            TRACKER.start();
            VecAccelPreview.setActive(true);
        }

        @Override
        protected void onKeyUp() {
            TRACKER.end();
            VecAccelPreview.setActive(false);
        }

        @Override
        protected void onKeyAbort() {
            TRACKER.end();
            VecAccelPreview.setActive(false);
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
            VecAccelPreview.setActive(false);
        }
    }
}
