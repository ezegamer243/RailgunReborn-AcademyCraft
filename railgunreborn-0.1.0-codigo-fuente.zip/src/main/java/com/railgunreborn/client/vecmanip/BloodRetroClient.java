package com.railgunreborn.client.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.vecmanip.BloodRetroRules;
import com.railgunreborn.ability.vecmanip.BloodRetroSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.BloodSplashEffects;
import com.railgunreborn.client.effect.TargetMarkerRenderer;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Blood Retrograde: contorno de carga en el icono (rojo, parpadea al acercarse a la suelta automática a
 * los 30 ticks) y, para los jugadores cercanos, el reventón: sangre sobre el objetivo y sonido moderado. Bus del mod
 * (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class BloodRetroClient {
    private static final int RED = 0xFFD51D1D;
    private static final int WARNING_FROM = 24;

    public static final ChargeOutline OUTLINE = ChargeOutline.builder(BloodRetroRules.AUTO_RELEASE_TICKS)
            .band(BloodRetroRules.AUTO_RELEASE_TICKS, RED)
            .warningFrom(WARNING_FROM)
            .build();

    private static final ChargeTracker TRACKER = new ChargeTracker(OUTLINE.totalTicks());

    private BloodRetroClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.BLOOD_RETRO.getId(), BloodRetroClient::effect);
        ClientSkillContexts.registerFactory(VecManip.BLOOD_RETRO.getId(), BloodRetroClientContext::new);
        KeyHintHud.registerChargeOutline(VecManip.BLOOD_RETRO.getId(), TRACKER, OUTLINE);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!BloodRetroSkill.CHANNEL_BURST.equals(channel)) {
            return;
        }
        double x = data.getDouble("x");
        double y = data.getDouble("y");
        double z = data.getDouble("z");
        float width = data.getFloat("w");
        float height = data.getFloat("h");
        caster.level().playLocalSound(x, y + height * 0.5, z, ModSounds.VM_BLOOD_RETRO.get(), SoundSource.PLAYERS,
                BloodRetroRules.SOUND_VOLUME, 1.0f, false);
        BloodSplashEffects.spawn(x, y, z, width, height, caster.getRandom(), BloodRetroRules.BLOOD_MIN,
                BloodRetroRules.BLOOD_MAX, BloodRetroRules.BLOOD_SIZE_MIN, BloodRetroRules.BLOOD_SIZE_MAX);
    }

    /** Mitad local: cuenta los ticks de carga para el contorno. */
    private static final class BloodRetroClientContext extends ClientSkillContext {
        BloodRetroClientContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            TRACKER.start();
            TargetMarkerRenderer.show(this, this::marker);
        }

        /** Mismo trazado que el servidor al soltar ({@link BloodRetroSkill#findTarget}). */
        @Nullable
        private TargetMarkerRenderer.Marker marker(float partialTick) {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null || isTerminated()) {
                return null;
            }
            Entity target = BloodRetroSkill.findTarget(player);
            Vec3 reachEnd = player.getEyePosition().add(player.getViewVector(1.0f).scale(BloodRetroRules.REACH));
            return TargetMarkerRenderer.forTarget(player, target, reachEnd, partialTick);
        }

        @Override
        protected void onKeyUp() {
            TRACKER.end();
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onKeyAbort() {
            TRACKER.end();
            TargetMarkerRenderer.hide(this);
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
            TargetMarkerRenderer.hide(this);
        }
    }
}
