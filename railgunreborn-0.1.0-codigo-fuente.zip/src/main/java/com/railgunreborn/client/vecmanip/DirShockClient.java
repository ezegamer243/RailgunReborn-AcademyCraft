package com.railgunreborn.client.vecmanip;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.vecmanip.DirShockRules;
import com.railgunreborn.ability.vecmanip.DirShockSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Directed Shock: contorno de carga en el icono (gris hasta el tick 6, azul de 7 a 49, parpadeo desde 45,
 * gris de nuevo al pasarse) y sonido del golpe para los jugadores cercanos. Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class DirShockClient {
    private static final int GRAY = 0xFF8A8F98;
    private static final int BLUE = 0xFF4AA3FF;
    private static final int WARNING_FROM = 45;

    public static final ChargeOutline OUTLINE = ChargeOutline.builder(DirShockRules.MAX_TICKS + 1)
            .band(DirShockRules.MIN_TICKS + 1, GRAY)
            .band(DirShockRules.MAX_TICKS, BLUE)
            .band(DirShockRules.MAX_TICKS + 1, GRAY)
            .warningFrom(WARNING_FROM)
            .build();

    private static final ChargeTracker TRACKER = new ChargeTracker(OUTLINE.totalTicks());

    private DirShockClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.DIR_SHOCK.getId(), DirShockClient::effect);
        ClientSkillContexts.registerFactory(VecManip.DIR_SHOCK.getId(), DirShockClientContext::new);
        KeyHintHud.registerChargeOutline(VecManip.DIR_SHOCK.getId(), TRACKER, OUTLINE);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!DirShockSkill.CHANNEL_HIT.equals(channel)) {
            return;
        }
        Entity target = caster.level().getEntity(data.getInt(DirShockSkill.TARGET_KEY));
        if (target == null) {
            return;
        }
        caster.level().playLocalSound(target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
                ModSounds.VM_DIRECTED_SHOCK.get(), SoundSource.PLAYERS, DirShockRules.SOUND_VOLUME, 1.0f, false);
    }

    /** Mitad local: cuenta los ticks de carga para el contorno. */
    private static final class DirShockClientContext extends ClientSkillContext {
        DirShockClientContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            TRACKER.start();
        }

        @Override
        protected void onKeyUp() {
            TRACKER.end();
        }

        @Override
        protected void onKeyAbort() {
            TRACKER.end();
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
        }
    }
}
