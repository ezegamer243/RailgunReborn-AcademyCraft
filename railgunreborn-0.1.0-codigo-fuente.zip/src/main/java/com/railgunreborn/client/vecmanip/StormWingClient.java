package com.railgunreborn.client.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.vecmanip.StormWingRules;
import com.railgunreborn.ability.vecmanip.StormWingSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Storm Wing: la mitad local que mueve al jugador (ficha §3, con diagonales) y el contorno de carga del
 * icono. Los efectos que ven todos (torbellinos, polvo, bucle) están en {@link StormWingEffects}. Bus del mod (solo el
 * registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class StormWingClient {
    private static final int BLUE = 0xFF4AA3FF;
    private static final int LONGEST_CHARGE = StormWingRules.chargeTicks(0f);
    private static final ChargeTracker TRACKER = new ChargeTracker(LONGEST_CHARGE);

    /** Contexto local vivo (para el estado del icono). */
    @Nullable
    private static WingContext current;

    private StormWingClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.STORM_WING.getId(), StormWingEffects::handle);
        ClientSkillContexts.registerFactory(VecManip.STORM_WING.getId(), WingContext::new);
        KeyHintHud.registerChargeOutline(VecManip.STORM_WING.getId(), TRACKER, outline(LONGEST_CHARGE));
        KeyHintHud.registerStateProvider(VecManip.STORM_WING.getId(), StormWingClient::hintState);
    }

    static ChargeOutline outline(int chargeTicks) {
        int total = Math.max(1, chargeTicks);
        return ChargeOutline.builder(total).band(total, BLUE).build();
    }

    /** Naranja mientras carga, azul mientras vuela. */
    private static KeyHintHud.HintState hintState(LocalPlayer player) {
        WingContext ctx = current;
        if (ctx == null || ctx.isTerminated()) {
            return KeyHintHud.HintState.IDLE;
        }
        return ctx.flying ? KeyHintHud.HintState.ACTIVE : KeyHintHud.HintState.CHARGE;
    }

    /**
     * Mueve al jugador local cada tick. Volando: velocidad objetivo según las teclas de movimiento (sumadas) y la
     * mirada, con aceleración limitada por eje; sin teclas o cargando: flota. El servidor solo cobra y anula la caída y
     * el anti-kick (como Magnet Movement).
     */
    private static final class WingContext extends ClientSkillContext {
        private float exp;
        private boolean started;
        private boolean flying;

        WingContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null) {
                exp = AbilityData.get(player).getSkillExp(getSkill().getId());
            }
            current = this;
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (StormWingSkill.CHANNEL_START.equals(channel)) {
                started = true;
                int charge = Math.clamp(data.getInt(StormWingSkill.CHARGE_KEY), 1, LONGEST_CHARGE);
                KeyHintHud.registerChargeOutline(VecManip.STORM_WING.getId(), TRACKER, outline(charge));
                TRACKER.start();
            } else if (StormWingSkill.CHANNEL_ACTIVE.equals(channel)) {
                started = true;
                flying = true;
                TRACKER.end();
            }
        }

        @Override
        protected void tick() {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (!started || player == null || getState() != State.ALIVE || player.isPassenger()) {
                return;
            }
            player.resetFallDistance();
            Options o = mc.options;
            double[] dir = flying && mc.screen == null
                    ? StormWingRules.direction(o.keyUp.isDown(), o.keyDown.isDown(), o.keyLeft.isDown(),
                            o.keyRight.isDown(), player.getYRot(), player.getXRot())
                    : new double[] {0, 0, 0};
            if (dir[0] == 0 && dir[1] == 0 && dir[2] == 0) {
                hover(player);
                return;
            }
            double speed = StormWingRules.speed(exp);
            // Velocidad "real" (lo que se movió de verdad tras colisiones): al chocar con una pared no se acumula.
            Vec3 actual = player.position().subtract(player.xo, player.yo, player.zo);
            double[] next = StormWingRules.nextVelocity(new double[] {actual.x, actual.y, actual.z},
                    new double[] {dir[0] * speed, dir[1] * speed, dir[2] * speed});
            player.setDeltaMovement(next[0], next[1], next[2]);
        }

        private void hover(LocalPlayer player) {
            Vec3 feet = player.position();
            HitResult hit = player.level().clip(new ClipContext(feet.add(0, 0.5, 0), feet.add(0, -0.3, 0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            Vec3 dm = player.getDeltaMovement();
            player.setDeltaMovement(dm.x, StormWingRules.hoverVertical(dm.y, hit.getType() != HitResult.Type.MISS),
                    dm.z);
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
            if (current == this) {
                current = null;
            }
        }
    }
}
