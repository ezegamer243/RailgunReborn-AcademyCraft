package com.railgunreborn.client.vecmanip;

import org.joml.Vector3f;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.vecmanip.VecDeviationRules;
import com.railgunreborn.ability.vecmanip.VecDeviationSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Vector Deviation. El brillo del icono mientras el campo está activo lo pone {@code KeyHintHud} solo (el
 * contexto local vive). Aquí: anillo pequeño de partículas y sonido en cada proyectil detenido, y sonido en el
 * jugador al reducir un golpe. Sin ondas en pantalla (decisión). Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class VecDeviationClient {
    private static final int RING_POINTS = 12;
    private static final double RING_RADIUS = 0.35;
    private static final DustParticleOptions RING_DUST = new DustParticleOptions(new Vector3f(0.85f, 0.9f, 1f), 0.6f);

    private VecDeviationClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.VEC_DEVIATION.getId(), VecDeviationClient::effect);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        Level level = caster.level();
        if (VecDeviationSkill.CHANNEL_HIT.equals(channel)) {
            level.playLocalSound(caster.getX(), caster.getY() + caster.getBbHeight() * 0.5, caster.getZ(),
                    ModSounds.VM_VEC_DEVIATION.get(), SoundSource.PLAYERS, VecDeviationRules.HIT_SOUND_VOLUME, 1f,
                    false);
            return;
        }
        if (!VecDeviationSkill.CHANNEL_STOP.equals(channel)) {
            return;
        }
        Vec3 pos = MagMovementSkill.readVec(data, VecDeviationSkill.POS_KEY);
        Entity entity = level.getEntity(data.getInt(VecDeviationSkill.ENTITY_KEY));
        if (entity != null) {
            // La copia del cliente también se para ya (no espera al paquete de velocidad).
            entity.setDeltaMovement(Vec3.ZERO);
        }
        ring(level, pos, pos.subtract(caster.getEyePosition()));
        level.playLocalSound(pos.x, pos.y, pos.z, ModSounds.VM_VEC_DEVIATION.get(), SoundSource.PLAYERS,
                VecDeviationRules.STOP_SOUND_VOLUME, 1f, false);
    }

    /** Anillo de partículas en {@code center}, de cara al que lo detuvo (perpendicular a {@code facing}). */
    private static void ring(Level level, Vec3 center, Vec3 facing) {
        Vec3 normal = facing.lengthSqr() < 1e-6 ? new Vec3(0, 1, 0) : facing.normalize();
        Vec3 helper = Math.abs(normal.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 u = normal.cross(helper).normalize();
        Vec3 v = normal.cross(u);
        for (int i = 0; i < RING_POINTS; i++) {
            double a = Math.PI * 2 * i / RING_POINTS;
            Vec3 p = center.add(u.scale(Math.cos(a) * RING_RADIUS)).add(v.scale(Math.sin(a) * RING_RADIUS));
            level.addParticle(RING_DUST, p.x, p.y, p.z, 0, 0, 0);
        }
    }
}
