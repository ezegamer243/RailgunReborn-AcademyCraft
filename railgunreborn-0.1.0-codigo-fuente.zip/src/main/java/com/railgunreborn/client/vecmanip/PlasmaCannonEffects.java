package com.railgunreborn.client.vecmanip;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.ability.vecmanip.PlasmaCannonRules;
import com.railgunreborn.ability.vecmanip.PlasmaCannonSkill;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Efectos de Plasma Cannon que ven todos los cercanos (ficha §7-8, con las decisiones): bucle moderado pegado al
 * lanzador; el cuerpo de plasma aproximado con halos ({@code glow_circle.png}) que orbitan (sin el shader del
 * original); y, mientras carga, un torbellino tenue del suelo a la bola. Nada tapa la pantalla: los halos se apagan
 * cerca de la cámara y no se dibujan los anillos a menos de {@link #RING_CAMERA_GAP} bloques de ella. La explosión es
 * la vanilla. Bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class PlasmaCannonEffects {
    /** Por si no llega el "stop": ninguna bola legítima vive tanto. */
    private static final int MAX_LIFE = 20 * 120;
    private static final int BODY_FADE_OUT = 20;
    private static final int TORNADO_FADE_IN = 20;
    private static final int TORNADO_FADE_OUT = 30;
    /** Decisión: torbellino más tenue (el original: 0.35) y base más estrecha (el original: ~8 de ancho). */
    private static final float TORNADO_ALPHA = 0.18f;
    private static final double TORNADO_BASE_RADIUS = 2.0;
    private static final double TORNADO_TOP_RADIUS = 3.5;
    private static final double TORNADO_MAX_DROP = 20.0;
    private static final int TORNADO_SEGMENTS = 16;
    private static final double RING_SPACING = 0.9;
    private static final double RING_CAMERA_GAP = 1.5;
    /** Los halos se apagan del todo a esta distancia de la cámara y vuelven del todo a {@code + HALO_FADE_RANGE}. */
    private static final double HALO_NEAR = 2.5;
    private static final double HALO_FADE_RANGE = 4.0;
    private static final float BODY_ALPHA = 0.55f;
    /** Halos: 4 grandes y 5 pequeños, como las metabolas del original (radios ×2 para que se vean como halo). */
    private static final int BIG = 4;
    private static final int SMALL = 5;

    private static final Map<Integer, Plasma> PLASMAS = new HashMap<>();

    private PlasmaCannonEffects() {
    }

    private record Orb(double size, double amplitude, double speed, double phase, Vec3 center, Vec3 axisA,
            Vec3 axisB) {
    }

    private static final class Plasma {
        final Player caster;
        final int contextId;
        final int chargeTicks;
        final EntityLoopSound sound;
        final Orb[] orbs;
        final double groundY;
        Vec3 pos;
        Vec3 prevPos;
        Vec3 dest;
        int age;
        int firedAt = -1;
        int stoppedAt = -1;

        Plasma(Player caster, int contextId, Vec3 pos, int chargeTicks) {
            this.caster = caster;
            this.contextId = contextId;
            this.pos = pos;
            this.prevPos = pos;
            this.chargeTicks = Math.max(1, chargeTicks);
            this.orbs = makeOrbs(caster.getRandom());
            this.groundY = groundBelow(caster, pos);
            this.sound = new EntityLoopSound(ModSounds.VM_PLASMA_CANNON.get(), SoundSource.PLAYERS, caster,
                    PlasmaCannonRules.LOOP_VOLUME);
            Minecraft.getInstance().getSoundManager().play(sound);
        }

        /** Cuerpo: aparece durante la carga y se apaga al terminar. */
        float bodyAlpha(float partial) {
            float t = age + partial;
            float in = Math.min(1f, t / chargeTicks);
            if (stoppedAt >= 0) {
                return BODY_ALPHA * in * Math.max(0f, 1f - (t - stoppedAt) / BODY_FADE_OUT);
            }
            return BODY_ALPHA * in;
        }

        /** Torbellino: solo mientras carga; se desvanece al disparar o terminar. */
        float tornadoAlpha(float partial) {
            float t = age + partial;
            float in = Math.min(1f, t / TORNADO_FADE_IN);
            int end = firedAt >= 0 ? firedAt : stoppedAt;
            if (end >= 0) {
                return TORNADO_ALPHA * in * Math.max(0f, 1f - (t - end) / TORNADO_FADE_OUT);
            }
            return TORNADO_ALPHA * in;
        }

        void stop() {
            if (stoppedAt < 0) {
                stoppedAt = age;
                sound.finish();
            }
        }
    }

    private static Orb[] makeOrbs(RandomSource random) {
        Orb[] orbs = new Orb[BIG + SMALL];
        for (int i = 0; i < orbs.length; i++) {
            boolean big = i < BIG;
            double spread = big ? 1.5 : 3.0;
            Vec3 center = new Vec3(Mth.nextDouble(random, -spread, spread), Mth.nextDouble(random, -spread, spread),
                    Mth.nextDouble(random, -spread, spread)).scale(0.5);
            Vec3 a = randomUnit(random);
            Vec3 b = a.cross(randomUnit(random));
            if (b.lengthSqr() < 1e-4) {
                b = a.cross(new Vec3(0, 1, 0));
            }
            b = b.normalize();
            double size = big ? Mth.nextDouble(random, 2.0, 3.0) : Mth.nextDouble(random, 0.4, 0.8);
            double amplitude = Mth.nextDouble(random, 1.4, 2.0) * (big ? 0.5 : 1.0);
            orbs[i] = new Orb(size, amplitude, Mth.nextDouble(random, 0.5, 0.7), random.nextDouble() * Math.PI * 2,
                    center, a, b);
        }
        return orbs;
    }

    private static Vec3 randomUnit(RandomSource random) {
        Vec3 v = new Vec3(random.nextGaussian(), random.nextGaussian(), random.nextGaussian());
        return v.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : v.normalize();
    }

    /** Suelo bajo la bola (rayo de 20 bloques hacia abajo; si no toca nada, 20 bloques bajo ella). */
    private static double groundBelow(Player caster, Vec3 pos) {
        BlockHitResult hit = caster.level().clip(new ClipContext(pos, pos.subtract(0, TORNADO_MAX_DROP, 0),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, caster));
        return hit.getType() == HitResult.Type.MISS ? pos.y - TORNADO_MAX_DROP : hit.getLocation().y;
    }

    /** Manejador de {@code SkillEffects} (lo registra {@link PlasmaCannonClient}). */
    static void handle(Player caster, int contextId, String channel, CompoundTag data) {
        Plasma plasma = PLASMAS.get(caster.getId());
        if (PlasmaCannonSkill.CHANNEL_START.equals(channel)) {
            if (plasma != null) {
                plasma.stop();
            }
            PLASMAS.put(caster.getId(), new Plasma(caster, contextId,
                    ElectronBombSkill.readVec(data.getCompound(PlasmaCannonSkill.POS_KEY)),
                    data.getInt(PlasmaCannonSkill.CHARGE_KEY)));
            return;
        }
        if (plasma == null || plasma.contextId != contextId) {
            return;
        }
        switch (channel) {
            case PlasmaCannonSkill.CHANNEL_FIRE -> {
                plasma.firedAt = plasma.age;
                plasma.pos = ElectronBombSkill.readVec(data.getCompound(PlasmaCannonSkill.POS_KEY));
                plasma.prevPos = plasma.pos;
                plasma.dest = ElectronBombSkill.readVec(data.getCompound(PlasmaCannonSkill.DEST_KEY));
            }
            case PlasmaCannonSkill.CHANNEL_SYNC ->
                    plasma.pos = ElectronBombSkill.readVec(data.getCompound(PlasmaCannonSkill.POS_KEY));
            case PlasmaCannonSkill.CHANNEL_EXPLODE -> {
                plasma.pos = ElectronBombSkill.readVec(data.getCompound(PlasmaCannonSkill.POS_KEY));
                plasma.prevPos = plasma.pos;
                plasma.dest = null;
                plasma.stop();
            }
            case PlasmaCannonSkill.CHANNEL_STOP -> {
                plasma.dest = null;
                plasma.stop();
            }
            default -> {
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (PLASMAS.isEmpty() || mc.isPaused()) {
            return;
        }
        for (Iterator<Plasma> it = PLASMAS.values().iterator(); it.hasNext(); ) {
            Plasma plasma = it.next();
            plasma.age++;
            plasma.prevPos = plasma.pos;
            if (plasma.caster.level() != mc.level || plasma.age > MAX_LIFE) {
                plasma.stop();
                it.remove();
                continue;
            }
            if (plasma.stoppedAt >= 0) {
                if (plasma.age - plasma.stoppedAt > Math.max(BODY_FADE_OUT, TORNADO_FADE_OUT)) {
                    it.remove();
                }
                continue;
            }
            // Entre sincronizaciones el cliente mueve la bola por su cuenta, como el servidor.
            if (plasma.dest != null) {
                double[] next = PlasmaCannonRules.step(new double[] {plasma.pos.x, plasma.pos.y, plasma.pos.z},
                        new double[] {plasma.dest.x, plasma.dest.y, plasma.dest.z});
                plasma.pos = new Vec3(next[0], next[1], next[2]);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || PLASMAS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();

        VertexConsumer rings = buffers.getBuffer(TornadoRenderType.TORNADO);
        boolean drewRings = false;
        for (Plasma plasma : PLASMAS.values()) {
            float alpha = plasma.tornadoAlpha(partial);
            if (alpha > 0.005f) {
                drawTornado(rings, pose, plasma, cam, plasma.age + partial, alpha);
                drewRings = true;
            }
        }
        if (drewRings) {
            buffers.endBatch(TornadoRenderType.TORNADO);
        }

        VertexConsumer glow = buffers.getBuffer(TornadoRenderType.PLASMA_GLOW);
        boolean drewGlow = false;
        Vec3 right = new Vec3(camera.getLeftVector()).scale(-1);
        Vec3 up = new Vec3(camera.getUpVector());
        for (Plasma plasma : PLASMAS.values()) {
            float alpha = plasma.bodyAlpha(partial);
            if (alpha > 0.005f) {
                drawBody(glow, pose, plasma, cam, right, up, partial, alpha);
                drewGlow = true;
            }
        }
        if (drewGlow) {
            buffers.endBatch(TornadoRenderType.PLASMA_GLOW);
        }
    }

    private static void drawBody(VertexConsumer consumer, PoseStack.Pose pose, Plasma plasma, Vec3 cam, Vec3 right,
            Vec3 up, float partial, float alpha) {
        Vec3 center = plasma.prevPos.lerp(plasma.pos, partial);
        double seconds = (plasma.age + partial) / 20.0;
        for (int i = 0; i < plasma.orbs.length; i++) {
            Orb orb = plasma.orbs[i];
            double angle = orb.phase() + seconds * orb.speed();
            Vec3 at = center.add(orb.center())
                    .add(orb.axisA().scale(Math.cos(angle) * orb.amplitude()))
                    .add(orb.axisB().scale(Math.sin(angle) * orb.amplitude()));
            double dist = at.distanceTo(cam);
            float near = (float) Mth.clamp((dist - HALO_NEAR - orb.size()) / HALO_FADE_RANGE, 0.0, 1.0);
            float a = alpha * near * (i < BIG ? 1f : 0.8f);
            if (a <= 0.005f) {
                continue;
            }
            // Blanco azulado en los grandes, violeta claro en los pequeños.
            int r = i < BIG ? 200 : 220;
            int g = i < BIG ? 225 : 180;
            int b = 255;
            int alphaByte = Mth.clamp((int) (a * 255), 0, 255);
            double half = orb.size() * 0.5;
            Vec3 c = at.subtract(cam);
            Vec3 rr = right.scale(half);
            Vec3 uu = up.scale(half);
            glowVertex(consumer, pose, c.add(rr).subtract(uu), r, g, b, alphaByte, 1f, 1f);
            glowVertex(consumer, pose, c.add(rr).add(uu), r, g, b, alphaByte, 1f, 0f);
            glowVertex(consumer, pose, c.subtract(rr).add(uu), r, g, b, alphaByte, 0f, 0f);
            glowVertex(consumer, pose, c.subtract(rr).subtract(uu), r, g, b, alphaByte, 0f, 1f);
        }
    }

    /** Anillos horizontales que giran, del suelo bajo la bola hasta ella; se ensanchan hacia arriba. */
    private static void drawTornado(VertexConsumer consumer, PoseStack.Pose pose, Plasma plasma, Vec3 cam,
            float time, float alpha) {
        Vec3 top = plasma.pos;
        double height = top.y - plasma.groundY;
        if (height < 1.0) {
            return;
        }
        int ringCount = Math.max(2, (int) (height / RING_SPACING));
        for (int i = 0; i < ringCount; i++) {
            double f = i / (double) ringCount;
            double y = plasma.groundY + height * f;
            double r = Mth.lerp(f, TORNADO_BASE_RADIUS, TORNADO_TOP_RADIUS);
            double sway = Math.sin(time * 0.12 + i * 0.6) * 0.25 * f;
            Vec3 c = new Vec3(top.x + sway, y, top.z + Math.cos(time * 0.1 + i * 0.5) * 0.25 * f);
            // Decisión: nada que tape la vista; el anillo que pase junto a la cámara no se dibuja.
            double horizontal = Math.hypot(cam.x - c.x, cam.z - c.z);
            if (Math.hypot(horizontal - r, cam.y - y) < RING_CAMERA_GAP) {
                continue;
            }
            double ringHeight = RING_SPACING * 0.7;
            double spin = time * (0.3 - 0.01 * i) + i * 0.9;
            int alphaByte = Mth.clamp((int) (alpha * (0.6f + 0.4f * (float) f) * 255), 0, 255);
            float vOffset = (float) ((spin * 0.05) % 1.0);
            Vec3 c0 = c.subtract(cam);
            Vec3 c1 = c0.add(0, ringHeight, 0);
            for (int s = 0; s < TORNADO_SEGMENTS; s++) {
                double t0 = spin + Math.PI * 2 * s / TORNADO_SEGMENTS;
                double t1 = spin + Math.PI * 2 * (s + 1) / TORNADO_SEGMENTS;
                Vec3 d0 = new Vec3(Math.cos(t0), 0, Math.sin(t0)).scale(r);
                Vec3 d1 = new Vec3(Math.cos(t1), 0, Math.sin(t1)).scale(r);
                float uA = (float) s / TORNADO_SEGMENTS;
                float uB = (float) (s + 1) / TORNADO_SEGMENTS;
                ringVertex(consumer, pose, c0.add(d0), alphaByte, uA, vOffset);
                ringVertex(consumer, pose, c0.add(d1), alphaByte, uB, vOffset);
                ringVertex(consumer, pose, c1.add(d1.scale(1.08)), alphaByte, uB, vOffset + 0.5f);
                ringVertex(consumer, pose, c1.add(d0.scale(1.08)), alphaByte, uA, vOffset + 0.5f);
            }
        }
    }

    private static void ringVertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, int alpha, float u,
            float v) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(255, 255, 255, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    /** Mezcla aditiva: el brillo se regula con el color (el alfa no cuenta). */
    private static void glowVertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, int r, int g, int b,
            int alpha, float u, float v) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(Mth.clamp(r, 0, 255), Mth.clamp(g, 0, 255), Mth.clamp(b, 0, 255), alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        PLASMAS.values().forEach(Plasma::stop);
        PLASMAS.clear();
    }
}
