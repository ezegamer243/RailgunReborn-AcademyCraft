package com.railgunreborn.client.vecmanip;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.vecmanip.StormWingRules;
import com.railgunreborn.ability.vecmanip.StormWingSkill;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Efectos de Storm Wing que ven todos los cercanos (ficha §8-9, con las decisiones): bucle moderado pegado al jugador,
 * cuatro torbellinos de anillos a la espalda (simplificados: conos de bandas con {@code tornado_ring.png} que giran)
 * y un remolino de polvo pequeño a su alrededor. En primera persona no se dibujan los propios torbellinos (nada que
 * tape la pantalla). Bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class StormWingEffects {
    private static final float MAX_ALPHA = 0.7f;
    private static final int FADE_OUT = 15;
    /** Por si no llega el "stop" (p. ej. salió del rango de efectos): ningún vuelo legítimo dura tanto. */
    private static final int MAX_LIFE = 20 * 60;
    private static final double ANCHOR_HEIGHT = 1.35;
    private static final double BACK_OFFSET = 0.25;
    private static final double TORNADO_LENGTH = 2.0;
    private static final int RINGS = 14;
    private static final int SEGMENTS = 12;
    private static final double BASE_RADIUS = 0.05;
    private static final double TOP_RADIUS = 0.42;
    /** Ángulos de los cuatro torbellinos alrededor del eje de la espalda (45° entre sí). */
    private static final float[] ANGLES = {-67.5f, -22.5f, 22.5f, 67.5f};
    private static final BlockParticleOption DUST =
            new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());

    private static final Map<Integer, Wing> WINGS = new HashMap<>();

    private StormWingEffects() {
    }

    private static final class Wing {
        final Player caster;
        final int contextId;
        final int chargeTicks;
        final EntityLoopSound sound;
        int age;
        boolean active;
        int stoppedAt = -1;

        Wing(Player caster, int contextId, int chargeTicks) {
            this.caster = caster;
            this.contextId = contextId;
            this.chargeTicks = Math.max(1, chargeTicks);
            this.sound = new EntityLoopSound(ModSounds.VM_STORM_WING.get(), SoundSource.PLAYERS, caster,
                    StormWingRules.LOOP_VOLUME);
            Minecraft.getInstance().getSoundManager().play(sound);
        }

        float alpha(float partial) {
            float t = age + partial;
            if (stoppedAt >= 0) {
                return MAX_ALPHA * Math.max(0f, 1f - (t - stoppedAt) / FADE_OUT);
            }
            return active ? MAX_ALPHA : MAX_ALPHA * Math.min(1f, t / chargeTicks);
        }

        void stop() {
            if (stoppedAt < 0) {
                stoppedAt = age;
                sound.finish();
            }
        }
    }

    /** Manejador de {@code SkillEffects} (lo registra {@link StormWingClient}). */
    static void handle(Player caster, int contextId, String channel, CompoundTag data) {
        Wing wing = WINGS.get(caster.getId());
        if (StormWingSkill.CHANNEL_START.equals(channel)) {
            if (wing != null) {
                wing.stop();
            }
            WINGS.put(caster.getId(), new Wing(caster, contextId, data.getInt(StormWingSkill.CHARGE_KEY)));
        } else if (wing != null && wing.contextId == contextId) {
            if (StormWingSkill.CHANNEL_ACTIVE.equals(channel)) {
                wing.active = true;
            } else if (StormWingSkill.CHANNEL_STOP.equals(channel)) {
                wing.stop();
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (WINGS.isEmpty() || mc.isPaused()) {
            return;
        }
        for (Iterator<Wing> it = WINGS.values().iterator(); it.hasNext(); ) {
            Wing wing = it.next();
            wing.age++;
            if (wing.caster.isRemoved() || wing.caster.level() != mc.level || wing.age > MAX_LIFE) {
                wing.stop();
                it.remove();
                continue;
            }
            if (wing.stoppedAt >= 0) {
                if (wing.age - wing.stoppedAt > FADE_OUT) {
                    it.remove();
                }
                continue;
            }
            spawnDust(mc, wing.caster);
        }
    }

    /** Polvo pequeño girando alrededor, a 3-8 bloques (decisión: menos que el original). */
    private static void spawnDust(Minecraft mc, Player caster) {
        if (mc.options.particles().get() == ParticleStatus.MINIMAL) {
            return;
        }
        RandomSource random = caster.getRandom();
        Vec3 center = caster.position().add(0, 1.0, 0);
        for (int i = 0; i < StormWingRules.PARTICLES_PER_TICK; i++) {
            double yaw = random.nextDouble() * Math.PI * 2;
            double pitch = (random.nextDouble() - 0.5) * Math.PI * 0.6;
            double r = Mth.nextDouble(random, 3.0, 8.0);
            Vec3 radial = new Vec3(Math.cos(yaw) * Math.cos(pitch), Math.sin(pitch), Math.sin(yaw) * Math.cos(pitch));
            Vec3 pos = center.add(radial.scale(r));
            // Tangente horizontal: el polvo gira alrededor del jugador.
            Vec3 tangent = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw)).scale(0.35);
            Particle particle = mc.particleEngine.createParticle(DUST, pos.x, pos.y, pos.z, 0, 0, 0);
            if (particle != null) {
                particle.setParticleSpeed(tangent.x, 0.02, tangent.z);
                particle.scale(0.5f);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || WINGS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 cam = event.getCamera().getPosition();
        PoseStack.Pose pose = event.getPoseStack().last();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(TornadoRenderType.TORNADO);
        boolean drew = false;
        for (Wing wing : WINGS.values()) {
            Player caster = wing.caster;
            if (caster == mc.player && mc.options.getCameraType().isFirstPerson() || caster.isInvisible()) {
                continue;
            }
            float alpha = wing.alpha(partial);
            if (alpha <= 0.01f) {
                continue;
            }
            drawWing(consumer, pose, caster, cam, partial, wing.age + partial, alpha);
            drew = true;
        }
        if (drew) {
            buffers.endBatch(TornadoRenderType.TORNADO);
        }
    }

    /** Cuatro conos detrás del jugador, orientados con el cuerpo (yaw) y el 20 % del pitch. */
    private static void drawWing(VertexConsumer consumer, PoseStack.Pose pose, Player caster, Vec3 cam,
            float partial, float time, float alpha) {
        float yaw = Mth.rotLerp(partial, caster.yBodyRotO, caster.yBodyRot) * Mth.DEG_TO_RAD;
        float pitch = 0.2f * Mth.lerp(partial, caster.xRotO, caster.getXRot()) * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 right = new Vec3(-Mth.cos(yaw), 0, -Mth.sin(yaw));
        // Inclinación con la mirada: el "arriba" de la espalda se echa hacia delante al mirar abajo.
        Vec3 up = new Vec3(0, Mth.cos(pitch), 0).add(forward.scale(Mth.sin(pitch)));
        Vec3 back = forward.scale(-Mth.cos(pitch)).add(0, Mth.sin(pitch), 0);
        Vec3 base = caster.getPosition(partial).add(0, ANCHOR_HEIGHT * caster.getBbHeight() / 1.8, 0)
                .add(back.scale(BACK_OFFSET)).subtract(cam);
        for (int k = 0; k < ANGLES.length; k++) {
            float a = ANGLES[k] * Mth.DEG_TO_RAD;
            Vec3 axis = back.scale(0.55).add(up.scale(Mth.cos(a) * 0.85)).add(right.scale(Mth.sin(a) * 0.85))
                    .normalize();
            Vec3 helper = Math.abs(axis.y) > 0.95 ? forward : new Vec3(0, 1, 0);
            Vec3 u = axis.cross(helper).normalize();
            Vec3 v = axis.cross(u).normalize();
            drawTornado(consumer, pose, base, axis, u, v, time * (k % 2 == 0 ? 1 : -1) + k * 7.3f, alpha);
        }
    }

    private static void drawTornado(VertexConsumer consumer, PoseStack.Pose pose, Vec3 base, Vec3 axis, Vec3 u,
            Vec3 v, float time, float alpha) {
        double step = TORNADO_LENGTH / RINGS;
        for (int i = 0; i < RINGS; i++) {
            double h0 = i * step;
            double h1 = h0 + step * 0.8;
            double r0 = Mth.lerp(i / (double) RINGS, BASE_RADIUS, TOP_RADIUS);
            double r1 = Mth.lerp((i + 0.8) / (double) RINGS, BASE_RADIUS, TOP_RADIUS);
            // Cada anillo gira a su ritmo (más rápido abajo) y se mece un poco: el aspecto de remolino.
            double spin = time * (0.35 - 0.015 * i) + i * 0.9;
            double sway = Math.sin(time * 0.21 + i * 0.7) * 0.03 * i;
            Vec3 c0 = base.add(axis.scale(h0)).add(u.scale(sway));
            Vec3 c1 = base.add(axis.scale(h1)).add(u.scale(sway));
            float ringAlpha = alpha * (1f - 0.5f * i / RINGS);
            int alphaByte = Mth.clamp((int) (ringAlpha * 255), 0, 255);
            float vOffset = (float) ((spin * 0.05) % 1.0);
            for (int s = 0; s < SEGMENTS; s++) {
                double t0 = spin + Math.PI * 2 * s / SEGMENTS;
                double t1 = spin + Math.PI * 2 * (s + 1) / SEGMENTS;
                Vec3 d0 = u.scale(Math.cos(t0)).add(v.scale(Math.sin(t0)));
                Vec3 d1 = u.scale(Math.cos(t1)).add(v.scale(Math.sin(t1)));
                float uA = (float) s / SEGMENTS;
                float uB = (float) (s + 1) / SEGMENTS;
                vertex(consumer, pose, c0.add(d0.scale(r0)), alphaByte, uA, vOffset);
                vertex(consumer, pose, c0.add(d1.scale(r0)), alphaByte, uB, vOffset);
                vertex(consumer, pose, c1.add(d1.scale(r1)), alphaByte, uB, vOffset + 0.5f);
                vertex(consumer, pose, c1.add(d0.scale(r1)), alphaByte, uA, vOffset + 0.5f);
            }
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, Vec3 p, int alpha, float u, float v) {
        consumer.addVertex(pose, (float) p.x, (float) p.y, (float) p.z)
                .setColor(255, 255, 255, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        WINGS.values().forEach(Wing::stop);
        WINGS.clear();
    }
}
