package com.railgunreborn.client.vecmanip;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.vecmanip.PlasmaCannonRules;
import com.railgunreborn.ability.vecmanip.PlasmaCannonSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Plasma Cannon: el contorno de carga del icono (se llena durante la carga y se queda lleno, con el icono
 * encendido, mientras está lista para soltar) y el aviso de carga completa. Los efectos que ven todos están en
 * {@link PlasmaCannonEffects}. Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class PlasmaCannonClient {
    private static final int VIOLET = 0xFFB48CFF;
    private static final int LONGEST_CHARGE = PlasmaCannonRules.chargeTicks(0f);
    /** El contorno no se apaga solo al llenarse: se queda hasta disparar (la bola puede esperar sin límite). */
    private static final int TRACKER_MAX = 20 * 60 * 30;
    private static final ChargeTracker TRACKER = new ChargeTracker(TRACKER_MAX);

    @Nullable
    private static PlasmaContext current;

    private PlasmaCannonClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.PLASMA_CANNON.getId(), PlasmaCannonEffects::handle);
        ClientSkillContexts.registerFactory(VecManip.PLASMA_CANNON.getId(), PlasmaContext::new);
        KeyHintHud.registerChargeOutline(VecManip.PLASMA_CANNON.getId(), TRACKER, outline(LONGEST_CHARGE));
        KeyHintHud.registerStateProvider(VecManip.PLASMA_CANNON.getId(), PlasmaCannonClient::hintState);
    }

    static ChargeOutline outline(int chargeTicks) {
        int total = Math.max(1, chargeTicks);
        return ChargeOutline.builder(total).band(total, VIOLET).build();
    }

    /** Naranja mientras carga; encendido cuando está lista (y mientras la bola vuela). */
    private static KeyHintHud.HintState hintState(LocalPlayer player) {
        PlasmaContext ctx = current;
        if (ctx == null || ctx.isTerminated()) {
            return KeyHintHud.HintState.IDLE;
        }
        return ctx.ready ? KeyHintHud.HintState.ACTIVE : KeyHintHud.HintState.CHARGE;
    }

    private static final class PlasmaContext extends ClientSkillContext {
        private boolean ready;

        PlasmaContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            current = this;
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (PlasmaCannonSkill.CHANNEL_START.equals(channel)) {
                int charge = Math.clamp(data.getInt(PlasmaCannonSkill.CHARGE_KEY), 1, LONGEST_CHARGE);
                KeyHintHud.registerChargeOutline(VecManip.PLASMA_CANNON.getId(), TRACKER, outline(charge));
                TRACKER.start();
            } else if (PlasmaCannonSkill.CHANNEL_READY.equals(channel)) {
                ready = true;
                LocalPlayer player = Minecraft.getInstance().player;
                if (player != null) {
                    player.level().playLocalSound(player.getX(), player.getY(), player.getZ(),
                            ModSounds.VM_PLASMA_CANNON_READY.get(), SoundSource.PLAYERS,
                            PlasmaCannonRules.READY_VOLUME, 1f, false);
                }
            }
        }

        @Override
        protected void onKeyUp() {
            // Soltada (disparo o carga perdida): el contorno ya no hace falta.
            TRACKER.end();
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
            if (current == this) {
                current = null;
            }
        }
    }
}
