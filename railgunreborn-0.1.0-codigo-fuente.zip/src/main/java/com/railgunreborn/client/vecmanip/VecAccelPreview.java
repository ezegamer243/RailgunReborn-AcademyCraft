package com.railgunreborn.client.vecmanip;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.vecmanip.VecAccelRules;
import com.railgunreborn.ability.vecmanip.VecAccelSkill;
import com.railgunreborn.ability.vecmanip.VecManip;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Línea de previsión de Vector Acceleration: la trayectoria con la velocidad de carga actual, solo para quien la usa y
 * solo en primera persona. Blanca si se puede usar, roja si no. Bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class VecAccelPreview {
    private static final int SEGMENTS = 100;
    private static final float HALF_WIDTH = 0.02f;
    private static boolean active;

    private VecAccelPreview() {
    }

    static void setActive(boolean value) {
        active = value;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (!active || event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.getCameraType() != CameraType.FIRST_PERSON) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        float exp = AbilityData.get(player).getSkillExp(VecManip.VEC_ACCEL.getId());
        boolean usable = VecAccelRules.canUse(exp, VecAccelSkill.blockBelow(player));

        double[] dir = VecAccelRules.direction(player.getViewYRot(partialTick), player.getViewXRot(partialTick));
        double speed = VecAccelRules.speed(VecAccelClient.TRACKER.ticks());
        Vec3 look = player.getViewVector(partialTick);
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 start = player.getEyePosition(partialTick).add(right.scale(0.3)).add(0, -0.3, 0).add(look.scale(0.5));

        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        Matrix4f pose = poseStack.last().pose();
        Vec3 camera = event.getCamera().getPosition();

        double vx = dir[0] * speed;
        double vy = dir[1] * speed;
        double vz = dir[2] * speed;
        Vec3 point = start;
        Vec3 side = right.scale(HALF_WIDTH);
        int red = 255;
        int green = usable ? 255 : 51;
        int blue = usable ? 255 : 51;

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(RenderType.lightning());
        for (int i = 0; i < SEGMENTS; i++) {
            Vec3 next = point.add(vx * 0.02, vy * 0.02, vz * 0.02);
            vx *= 0.98;
            vy = vy * 0.98 - 0.038;
            vz *= 0.98;
            int a = (int) (0.7f * (1f - i * 0.03f) * 255f);
            if (a > 0) {
                Vec3 p0 = point.subtract(camera);
                Vec3 p1 = next.subtract(camera);
                vertex(consumer, pose, p0.subtract(side), red, green, blue, a);
                vertex(consumer, pose, p0.add(side), red, green, blue, a);
                vertex(consumer, pose, p1.add(side), red, green, blue, a);
                vertex(consumer, pose, p1.subtract(side), red, green, blue, a);
            }
            point = next;
        }
        buffers.endBatch(RenderType.lightning());
    }

    private static void vertex(VertexConsumer c, Matrix4f pose, Vec3 p, int r, int g, int b, int a) {
        c.addVertex(pose, (float) p.x, (float) p.y, (float) p.z).setColor(r, g, b, a);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        active = false;
    }
}
