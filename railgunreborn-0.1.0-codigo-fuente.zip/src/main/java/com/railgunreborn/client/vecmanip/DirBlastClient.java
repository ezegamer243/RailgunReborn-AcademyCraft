package com.railgunreborn.client.vecmanip;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.ability.vecmanip.DirBlastRules;
import com.railgunreborn.ability.vecmanip.DirBlastSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.WaveEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Cliente de Directed Blastwave: contorno de carga en el icono (como Directed Shock: gris hasta el tick 6, azul de 7
 * a 49, parpadeo desde 45, gris al pasarse) y, para los jugadores cercanos, el golpe en el punto de impacto (sonido
 * moderado y la onda de anillos). Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class DirBlastClient {
    private static final int GRAY = 0xFF8A8F98;
    private static final int BLUE = 0xFF4AA3FF;
    private static final int WARNING_FROM = 45;
    /** La onda nace al 70 % del camino entre la cabeza del lanzador y el punto de impacto. */
    private static final double WAVE_AT = 0.7;

    public static final ChargeOutline OUTLINE = ChargeOutline.builder(DirBlastRules.MAX_TICKS + 1)
            .band(DirBlastRules.MIN_TICKS + 1, GRAY)
            .band(DirBlastRules.MAX_TICKS, BLUE)
            .band(DirBlastRules.MAX_TICKS + 1, GRAY)
            .warningFrom(WARNING_FROM)
            .build();

    private static final ChargeTracker TRACKER = new ChargeTracker(OUTLINE.totalTicks());

    private DirBlastClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.DIR_BLAST.getId(), DirBlastClient::effect);
        ClientSkillContexts.registerFactory(VecManip.DIR_BLAST.getId(), DirBlastClientContext::new);
        KeyHintHud.registerChargeOutline(VecManip.DIR_BLAST.getId(), TRACKER, OUTLINE);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!DirBlastSkill.CHANNEL_BLAST.equals(channel)) {
            return;
        }
        Vec3 point = ElectronBombSkill.readVec(data.getCompound(DirBlastSkill.POINT_KEY));
        Vec3 dir = ElectronBombSkill.readVec(data.getCompound(DirBlastSkill.DIR_KEY));
        caster.level().playLocalSound(point.x, point.y, point.z, ModSounds.VM_DIRECTED_BLAST.get(),
                SoundSource.PLAYERS, DirBlastRules.SOUND_VOLUME, 1.0f, false);
        Vec3 origin = caster.getEyePosition().lerp(point, WAVE_AT);
        WaveEffects.spawn(origin, dir, caster.getRandom());
    }

    /** Mitad local: cuenta los ticks de carga para el contorno. */
    private static final class DirBlastClientContext extends ClientSkillContext {
        DirBlastClientContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            TRACKER.start();
        }

        @Override
        protected void onKeyUp() {
            TRACKER.end();
        }

        @Override
        protected void onKeyAbort() {
            TRACKER.end();
        }

        @Override
        protected void onTerminated() {
            TRACKER.end();
        }
    }
}
