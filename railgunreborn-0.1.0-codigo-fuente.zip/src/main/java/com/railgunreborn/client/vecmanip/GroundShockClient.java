package com.railgunreborn.client.vecmanip;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.vecmanip.GroundShockRules;
import com.railgunreborn.ability.vecmanip.GroundShockSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Efectos de Ground Shock para los jugadores cercanos: estruendo {@code vecmanip.groundshock} (0.7), polvo del bloque
 * de cada casilla y humo reducido (partículas vanilla con tope). Sin movimiento de cámara (decisión del usuario).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class GroundShockClient {
    private GroundShockClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(VecManip.GROUND_SHOCK.getId(), GroundShockClient::effect);
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!GroundShockSkill.CHANNEL_PERFORM.equals(channel)) {
            return;
        }
        Level level = caster.level();
        RandomSource random = caster.getRandom();
        level.playLocalSound(caster.getX(), caster.getY(), caster.getZ(), ModSounds.VM_GROUNDSHOCK.get(),
                SoundSource.PLAYERS, GroundShockRules.SOUND_VOLUME, 1.0f, false);
        int smokes = 0;
        for (long packed : data.getLongArray(GroundShockSkill.CELLS_KEY)) {
            BlockPos pos = BlockPos.of(packed);
            double x = pos.getX() + 0.5;
            double y = pos.getY() + 1.2;
            double z = pos.getZ() + 0.5;
            BlockState state = level.getBlockState(pos);
            if (!state.isAir()) {
                BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK, state);
                int count = 4 + random.nextInt(4);
                for (int i = 0; i < count; i++) {
                    level.addParticle(dust, x + random.nextDouble() - 0.5, y, z + random.nextDouble() - 0.5,
                            (random.nextDouble() - 0.5) * 0.4, 0.1 + random.nextDouble() * 0.2,
                            (random.nextDouble() - 0.5) * 0.4);
                }
            }
            if (smokes < GroundShockRules.MAX_SMOKE && random.nextDouble() < GroundShockRules.SMOKE_PROB) {
                smokes++;
                level.addParticle(ParticleTypes.POOF, x, y - 0.1, z, 0.0, 0.03 + random.nextDouble() * 0.03, 0.0);
            }
        }
    }
}
