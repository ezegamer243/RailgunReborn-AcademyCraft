package com.railgunreborn.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.wireless.MatrixBlockEntity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.client.model.data.ModelData;

/**
 * Escudos de la matriz (como {@code RenderMatrix.drawShields} del original): con las 3 placas y un núcleo, 3 placas
 * del grupo "Shield" del OBJ giran alrededor del eje vertical central del multibloque (50°/s, separadas 120°) y suben
 * y bajan un poco cada una. El cuerpo (grupos "Main" y "Core") lo dibuja el modelo del bloque.
 */
public final class MatrixRenderer implements BlockEntityRenderer<MatrixBlockEntity> {
    public static final ModelResourceLocation SHIELD_MODEL = ModelResourceLocation.standalone(
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "block/matrix_shield"));
    private static final int SHIELDS = 3;

    public MatrixRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(MatrixBlockEntity be, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
            int packedLight, int packedOverlay) {
        Level level = be.getLevel();
        if (level == null || !be.isWorking()) {
            return;
        }
        double time = (level.getGameTime() + partialTick) / 20.0;
        float spin = (float) (time * 50.0 % 360.0);
        // El origen es sólido: la luz se toma del aire de encima de la matriz.
        int light = LevelRenderer.getLightColor(level, be.getBlockPos().above(2));
        BakedModel model = Minecraft.getInstance().getModelManager().getModel(SHIELD_MODEL);
        for (int i = 0; i < SHIELDS; i++) {
            poseStack.pushPose();
            // El OBJ va de 0 a 2 en X/Z: el eje de giro es el centro (1, 1).
            poseStack.translate(1.0, 0.1 * Math.sin(time * 1.111 + 40.0 * i), 1.0);
            poseStack.mulPose(Axis.YP.rotationDegrees(spin + 360f / SHIELDS * i));
            poseStack.translate(-1.0, 0.0, -1.0);
            Minecraft.getInstance().getBlockRenderer().getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS)), null, model, 1f, 1f,
                    1f, light, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
            poseStack.popPose();
        }
    }

    @Override
    public AABB getRenderBoundingBox(MatrixBlockEntity be) {
        return new AABB(be.getBlockPos()).expandTowards(1, 2, 1);
    }
}
