package com.railgunreborn.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.screen.PhaseGenScreen;
import com.railgunreborn.registry.ModMenus;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Cliente del generador de fase (bus del MOD): registra su pantalla. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class PhaseGenClient {
    private PhaseGenClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.PHASE_GEN.get(), PhaseGenScreen::new);
    }
}
