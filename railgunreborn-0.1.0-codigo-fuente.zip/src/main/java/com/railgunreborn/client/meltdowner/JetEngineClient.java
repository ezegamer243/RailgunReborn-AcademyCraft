package com.railgunreborn.client.meltdowner;

import javax.annotation.Nullable;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.electromaster.MagMovementSkill;
import com.railgunreborn.ability.electromaster.ThunderclapRules;
import com.railgunreborn.ability.meltdowner.JetEngineRules;
import com.railgunreborn.ability.meltdowner.JetEngineSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.client.context.ClientSkillContext;
import com.railgunreborn.client.context.ClientSkillContexts;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.DiamondShieldEffects;
import com.railgunreborn.client.electromaster.RippleRenderType;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Cliente de Jet Engine: la marca verde de destino mientras se apunta (solo el jugador local, ficha §7.1), el
 * movimiento del dash (solo el local, §4.2 con las decisiones) y el escudo con partículas para todos (§7.2). Sin
 * sonido. Solo cliente (bus del juego); {@link #setup()} se llama desde {@link MeltdownerClient}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class JetEngineClient {
    /** Contexto local que está apuntando (para dibujar la marca), o null. */
    @Nullable
    private static AimContext aiming;
    /** Dash en curso del jugador local. Independiente del contexto: si el servidor lo corta, el dash termina igual. */
    @Nullable
    private static Dash dash;

    private JetEngineClient() {
    }

    static void setup() {
        SkillEffects.register(Meltdowner.JET_ENGINE.getId(), JetEngineClient::handleEffect);
        ClientSkillContexts.registerFactory(Meltdowner.JET_ENGINE.getId(), AimContext::new);
    }

    private static void handleEffect(Player caster, int contextId, String channel, CompoundTag data) {
        switch (channel) {
            case JetEngineSkill.CHANNEL_DASH -> DiamondShieldEffects.start(caster, contextId);
            case JetEngineSkill.CHANNEL_STOP -> DiamondShieldEffects.stop(caster, contextId);
            default -> {
            }
        }
    }

    // --- Mitad local: apuntar y moverse ---

    private static final class AimContext extends ClientSkillContext {
        Vec3 point = Vec3.ZERO;
        Vec3 prevPoint = Vec3.ZERO;
        int age;

        AimContext(int id, Skill skill, int slot) {
            super(id, skill, slot);
        }

        @Override
        protected void onKeyDown() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player != null) {
                point = JetEngineSkill.destination(player);
                prevPoint = point;
                aiming = this;
            }
        }

        @Override
        protected void tick() {
            LocalPlayer player = Minecraft.getInstance().player;
            if (aiming != this || player == null) {
                return;
            }
            if (!isKeyHeld()) {
                aiming = null;
                return;
            }
            age++;
            prevPoint = point;
            point = JetEngineSkill.destination(player);
        }

        @Override
        protected void onKeyUp() {
            stopAiming();
        }

        @Override
        protected void onKeyAbort() {
            stopAiming();
        }

        @Override
        protected void onTerminated() {
            stopAiming();
        }

        private void stopAiming() {
            if (aiming == this) {
                aiming = null;
            }
        }

        @Override
        protected void onMessage(String channel, CompoundTag data) {
            if (!JetEngineSkill.CHANNEL_DASH.equals(channel)) {
                return;
            }
            stopAiming();
            LocalPlayer player = Minecraft.getInstance().player;
            Vec3 dest = MagMovementSkill.readVec(data, JetEngineSkill.DEST_KEY);
            if (player == null || dest == null
                    || !JetEngineRules.plausibleDestination(dest.distanceTo(player.position()))) {
                return;
            }
            // El inicio es donde está el jugador aquí y ahora (el cliente es quien lo mueve).
            dash = new Dash(player, player.position(), dest);
        }
    }

    /**
     * Cada tick lleva al jugador hacia la posición prevista del tick siguiente con {@code setDeltaMovement}: el juego
     * aplica el movimiento con colisiones, así que no atraviesa bloques. A los 8 ticks está en el destino y se para.
     */
    private static final class Dash {
        final LocalPlayer player;
        final double[] start;
        final double[] dest;
        final double maxStep;
        int ticks;

        Dash(LocalPlayer player, Vec3 start, Vec3 dest) {
            this.player = player;
            this.start = new double[] {start.x, start.y, start.z};
            this.dest = new double[] {dest.x, dest.y, dest.z};
            this.maxStep = JetEngineRules.maxStep(start.distanceTo(dest));
        }

        /** false = terminado. */
        boolean tick() {
            if (player.isRemoved() || player != Minecraft.getInstance().player) {
                return false;
            }
            player.resetFallDistance();
            if (player.isPassenger()) {
                return !JetEngineRules.flightOver(++ticks);
            }
            if (JetEngineRules.arrived(ticks)) {
                // Llegó: se para (decisión 2) y desde aquí manda el juego (gravedad).
                if (ticks == JetEngineRules.TRAVEL_TICKS) {
                    player.setDeltaMovement(Vec3.ZERO);
                }
                return !JetEngineRules.flightOver(++ticks);
            }
            ticks++;
            double[] next = JetEngineRules.dashPosition(start, dest, ticks);
            Vec3 step = new Vec3(next[0], next[1], next[2]).subtract(player.position());
            if (step.length() > maxStep) {
                step = step.normalize().scale(maxStep);
            }
            player.setDeltaMovement(step);
            return true;
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || dash == null) {
            return;
        }
        if (!dash.tick()) {
            dash = null;
        }
    }

    // --- Marca de destino ---

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        AimContext current = aiming;
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL || current == null
                || current.isTerminated()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) {
            return;
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        // En AFTER_LEVEL la vista ya no está en el estado de render: se aplica a mano, como Thunderclap.
        PoseStack poseStack = new PoseStack();
        poseStack.mulPose(event.getModelViewMatrix());
        Matrix4f pose = poseStack.last().pose();
        Vec3 camera = event.getCamera().getPosition();
        Vec3 at = current.prevPoint.lerp(current.point, partialTick).subtract(camera);
        double seconds = (current.age + partialTick) / 20.0;

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(RippleRenderType.RIPPLE);
        for (int ring = 0; ring < ThunderclapRules.RIPPLE_OFFSETS.length; ring++) {
            double phase = ThunderclapRules.ripplePhase(seconds, ring);
            int alpha = (int) (ThunderclapRules.rippleAlpha(phase) * JetEngineRules.MARK_ALPHA * 255f);
            if (alpha <= 0) {
                continue;
            }
            float half = (float) (ThunderclapRules.rippleSize(phase) / 2);
            float x = (float) at.x;
            float y = (float) (at.y + ThunderclapRules.rippleHeight(phase));
            float z = (float) at.z;
            vertex(consumer, pose, x - half, y, z - half, 0f, 0f, alpha);
            vertex(consumer, pose, x - half, y, z + half, 0f, 1f, alpha);
            vertex(consumer, pose, x + half, y, z + half, 1f, 1f, alpha);
            vertex(consumer, pose, x + half, y, z - half, 1f, 0f, alpha);
        }
        buffers.endBatch(RippleRenderType.RIPPLE);
    }

    private static void vertex(VertexConsumer c, Matrix4f pose, float x, float y, float z, float u, float v,
            int alpha) {
        c.addVertex(pose, x, y, z).setUv(u, v)
                .setColor(JetEngineRules.MARK_RED, JetEngineRules.MARK_GREEN, JetEngineRules.MARK_BLUE, alpha);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        aiming = null;
        dash = null;
    }

    /** Morir o cambiar de dimensión recrea el jugador local: la marca y el dash se cortan. */
    @SubscribeEvent
    public static void onPlayerClone(ClientPlayerNetworkEvent.Clone event) {
        aiming = null;
        dash = null;
    }
}
