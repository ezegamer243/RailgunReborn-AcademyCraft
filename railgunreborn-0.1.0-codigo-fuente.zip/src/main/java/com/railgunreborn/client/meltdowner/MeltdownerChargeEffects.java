package com.railgunreborn.client.meltdowner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.MeltdownerRules;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Efectos que duran varios ticks de la habilidad Meltdowner (ficha §5.2-5.4): el sonido de carga y las partículas
 * alrededor del que carga (las que el original pretendía y nunca salían), y las partículas que suelta el rayo grande
 * durante su vida. Solo cliente, bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MeltdownerChargeEffects {
    private static final float CHARGE_VOLUME = 0.7f; // -30 % a pedido del usuario (era 1.0)
    /** Si no llega el "stop" (fuera de rango), la carga se corta sola. */
    private static final int SAFETY_TICKS = MeltdownerRules.TOLERANCE_TICKS + 40;
    /** Vida del rayo grande y probabilidad por tick de una partícula a 0-10 bloques del origen. */
    private static final int RAY_LIFE = 50;
    private static final float RAY_PARTICLE_CHANCE = 0.8f;
    private static final double RAY_PARTICLE_SPREAD = 10.0;

    private static final Map<Integer, Charge> CHARGES = new HashMap<>();
    private static final List<RayEmitter> RAYS = new ArrayList<>();

    private MeltdownerChargeEffects() {
    }

    public static void start(Player caster) {
        stop(caster);
        EntityLoopSound sound = new EntityLoopSound(ModSounds.MD_CHARGE.get(), SoundSource.PLAYERS, caster,
                CHARGE_VOLUME, false);
        Minecraft.getInstance().getSoundManager().play(sound);
        CHARGES.put(caster.getId(), new Charge(caster, sound));
    }

    public static void stop(Player caster) {
        Charge charge = CHARGES.remove(caster.getId());
        if (charge != null) {
            charge.sound.finish();
        }
    }

    /** Partículas del rayo durante su vida, sobre los primeros 10 bloques. */
    public static void rayParticles(Level level, Vec3 origin, Vec3 dir, double length) {
        RAYS.add(new RayEmitter(level, origin, dir.normalize(), Math.min(length, RAY_PARTICLE_SPREAD)));
    }

    private static final class Charge {
        final Player caster;
        final EntityLoopSound sound;
        int age;

        Charge(Player caster, EntityLoopSound sound) {
            this.caster = caster;
            this.sound = sound;
        }

        /** 2-3 partículas por tick en un anillo de 0.7-1 bloques, por debajo de los ojos, que suben despacio. */
        boolean tick() {
            if (caster.isRemoved() || ++age > SAFETY_TICKS) {
                return false;
            }
            RandomSource random = caster.getRandom();
            int count = 2 + random.nextInt(2);
            Vec3 eyes = caster.getEyePosition();
            for (int i = 0; i < count; i++) {
                double r = 0.7 + random.nextDouble() * 0.3;
                double angle = random.nextDouble() * Math.PI * 2;
                double y = -1.2 * random.nextDouble();
                caster.level().addParticle(ModParticles.MD.get(), eyes.x + Math.cos(angle) * r, eyes.y + y,
                        eyes.z + Math.sin(angle) * r, (random.nextDouble() * 2 - 1) * 0.03,
                        0.01 + random.nextDouble() * 0.04, (random.nextDouble() * 2 - 1) * 0.03);
            }
            return true;
        }
    }

    private static final class RayEmitter {
        final Level level;
        final Vec3 origin;
        final Vec3 dir;
        final double spread;
        int age;

        RayEmitter(Level level, Vec3 origin, Vec3 dir, double spread) {
            this.level = level;
            this.origin = origin;
            this.dir = dir;
            this.spread = spread;
        }

        boolean tick() {
            if (++age > RAY_LIFE) {
                return false;
            }
            RandomSource random = level.getRandom();
            if (random.nextFloat() < RAY_PARTICLE_CHANCE) {
                Vec3 p = origin.add(dir.scale(random.nextDouble() * spread));
                level.addParticle(ModParticles.MD.get(), p.x, p.y, p.z, (random.nextDouble() * 2 - 1) * 0.03,
                        (random.nextDouble() * 2 - 1) * 0.03, (random.nextDouble() * 2 - 1) * 0.03);
            }
            return true;
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused()) {
            return;
        }
        for (Iterator<Charge> it = CHARGES.values().iterator(); it.hasNext(); ) {
            Charge charge = it.next();
            if (charge.caster.level() != mc.level || !charge.tick()) {
                charge.sound.finish();
                it.remove();
            }
        }
        RAYS.removeIf(ray -> ray.level != mc.level || !ray.tick());
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        CHARGES.values().forEach(charge -> charge.sound.finish());
        CHARGES.clear();
        RAYS.clear();
    }
}
