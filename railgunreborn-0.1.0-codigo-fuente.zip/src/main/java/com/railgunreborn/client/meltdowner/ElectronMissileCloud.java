package com.railgunreborn.client.meltdowner;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.ElectronMissileRules;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.Minecraft;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Nube de chispas verdes alrededor del que mantiene Electron Missile ({@code electron-missile.md} §7.1): 1-2
 * partículas por tick a 0.5-1 bloques, entre 0.4 y 1.6 sobre los pies, que suben. Se genera en el cliente sin mensajes
 * por tick. Solo cliente, bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ElectronMissileCloud {
    /** Si no llega el "stop" (fuera de rango), la nube se corta sola. */
    private static final int SAFETY_TICKS = ElectronMissileRules.maxTicks(1f) + 40;
    private static final Map<Integer, Cloud> CLOUDS = new HashMap<>();

    private ElectronMissileCloud() {
    }

    public static void start(Player caster) {
        CLOUDS.put(caster.getId(), new Cloud(caster));
    }

    public static void stop(Player caster) {
        CLOUDS.remove(caster.getId());
    }

    private static final class Cloud {
        final Player caster;
        int age;

        Cloud(Player caster) {
            this.caster = caster;
        }

        boolean tick() {
            if (caster.isRemoved() || ++age > SAFETY_TICKS) {
                return false;
            }
            RandomSource random = caster.getRandom();
            int count = 1 + random.nextInt(2);
            for (int i = 0; i < count; i++) {
                double r = 0.5 + random.nextDouble() * 0.5;
                double angle = random.nextDouble() * Math.PI * 2;
                double y = 0.4 + random.nextDouble() * 1.2;
                caster.level().addParticle(ModParticles.MD.get(), caster.getX() + Math.cos(angle) * r,
                        caster.getY() + y, caster.getZ() + Math.sin(angle) * r, (random.nextDouble() * 2 - 1) * 0.02,
                        0.01 + random.nextDouble() * 0.04, (random.nextDouble() * 2 - 1) * 0.02);
            }
            return true;
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || CLOUDS.isEmpty()) {
            return;
        }
        for (Iterator<Cloud> it = CLOUDS.values().iterator(); it.hasNext(); ) {
            Cloud cloud = it.next();
            if (cloud.caster.level() != mc.level || !cloud.tick()) {
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        CLOUDS.clear();
    }
}
