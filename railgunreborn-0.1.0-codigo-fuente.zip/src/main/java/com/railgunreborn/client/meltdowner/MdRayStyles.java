package com.railgunreborn.client.meltdowner;

import com.railgunreborn.client.effect.RayStyle;

/**
 * Estilos de los rayos verdes de Meltdowner para {@code RayEffect}/{@code RayEffects}. Núcleo verde casi blanco y halo
 * verde muy transparente; cinta con las texturas {@code mdray*} repetidas en el cuerpo. Números de
 * {@code electron-bomb.md} §7.2 (rayo pequeño) y {@code meltdowner-skill.md} §5.4 (rayo grande).
 */
public final class MdRayStyles {
    public static final int CORE_COLOR = RayStyle.rgba(216, 248, 216, 230);
    public static final int HALO_COLOR = RayStyle.rgba(106, 242, 106, 50);

    /** Rayo pequeño (Electron Bomb, Ray Barrage, Electron Missile): 14 ticks, radios 0.03/0.045, cinta 0.3. */
    public static final RayStyle SMALL = small("mdray_small");

    /** Rayo grande (habilidad Meltdowner): 50 ticks, radios 0.17/0.22, cinta 1.5. */
    public static final RayStyle LARGE = RayStyle.builder("mdray")
            .glow(1.5)
            .glowColor(RayStyle.rgba(255, 255, 255, 204), 0.2)
            .repeatTile(true)
            .cylinders(0.22, HALO_COLOR, 0.17, CORE_COLOR)
            .timing(50, 200.0, 700.0, 300.0)
            .wiggle(0.1, 0.4)
            .build();

    /**
     * Rayo previo de Ray Barrage ({@code ray-barrage.md} §9.1) con barn: 50 ticks, núcleo 0.045, halo 0.052, cinta
     * 0.4; sale de la mano.
     */
    public static final RayStyle BARRAGE_PRE = barragePre(50);
    /** Rayo previo sin barn (rayo directo): igual, 30 ticks. */
    public static final RayStyle BARRAGE_PRE_SHORT = barragePre(30);

    /** Sub-rayo del abanico de Ray Barrage (§9.2): el pequeño estándar, vivo 50 ticks, se apaga en los últimos 300 ms. */
    public static final RayStyle BARRAGE_FAN = RayStyle.builder("mdray_small")
            .glow(0.3)
            .glowColor(RayStyle.rgba(255, 255, 255, 128), 0.2)
            .repeatTile(true)
            .cylinders(0.045, HALO_COLOR, 0.03, CORE_COLOR)
            .timing(50, 200.0, 300.0, 300.0)
            .wiggle(0.1, 0.4)
            .build();

    /** Vida nominal de los rayos mantenidos (Mining Ray): no se desvanecen solos, los quita quien los maneja. */
    private static final int HELD_LIFE_TICKS = 1_000_000;

    /** Mining Ray básico ({@code mine-ray.md} §8.1): cinta 0.3 (alfa 0.5), núcleo 0.03, halo 0.045, verde. */
    public static final RayStyle MINE_BASIC = held("mdray_small", 0.3, 0.5,
            0.045, HALO_COLOR, 0.03, CORE_COLOR);

    /** Mining Ray experto: cinta 0.5 (alfa 0.5), núcleo 0.045 (alfa 180), halo 0.056, verde amarillento. */
    public static final RayStyle MINE_EXPERT = held("mdray_expert", 0.5, 0.5,
            0.056, HALO_COLOR, 0.045, RayStyle.rgba(216, 248, 216, 180));

    /** Mining Ray de suerte: cinta 0.45 (alfa 0.6), núcleo 0.04, halo 0.05, violeta. */
    public static final RayStyle MINE_LUCK = held("mdray_luck", 0.45, 0.6,
            0.05, RayStyle.rgba(205, 166, 232, 50), 0.04, RayStyle.rgba(241, 229, 247, 230));

    private MdRayStyles() {
    }

    /** Rayo fino continuo: entra en 200 ms, tiembla un poco (ancho 1.0-1.1, brillo 0.9-1.0) y dura lo que se mantenga. */
    private static RayStyle held(String textureDir, double glowWidth, double glowAlpha, double outerRadius,
            int outerColor, double innerRadius, int innerColor) {
        return RayStyle.builder(textureDir)
                .glow(glowWidth)
                .glowColor(RayStyle.rgba(255, 255, 255, (int) Math.round(glowAlpha * 255)), 0.1)
                .repeatTile(true)
                .cylinders(outerRadius, outerColor, innerRadius, innerColor)
                .timing(HELD_LIFE_TICKS, 200.0, 400.0, 400.0)
                .wiggle(0.1, 0.4)
                .build();
    }

    private static RayStyle barragePre(int lifeTicks) {
        return RayStyle.builder("mdray_small")
                .glow(0.4)
                .glowColor(RayStyle.rgba(255, 255, 255, 128), 0.2)
                .repeatTile(true)
                .cylinders(0.052, HALO_COLOR, 0.045, CORE_COLOR)
                .timing(lifeTicks, 200.0, 400.0, 500.0)
                .wiggle(0.1, 0.4)
                .fromHand(true)
                .build();
    }

    /** Rayo pequeño con otro juego de texturas ({@code mdray_expert}, {@code mdray_luck}...). */
    public static RayStyle small(String textureDir) {
        return RayStyle.builder(textureDir)
                .glow(0.3)
                .glowColor(RayStyle.rgba(255, 255, 255, 128), 0.2)
                .repeatTile(true)
                .cylinders(0.045, HALO_COLOR, 0.03, CORE_COLOR)
                .timing(14, 200.0, 400.0, 500.0)
                .wiggle(0.1, 0.4)
                .build();
    }
}
