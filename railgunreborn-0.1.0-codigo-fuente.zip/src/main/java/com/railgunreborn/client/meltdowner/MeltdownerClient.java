package com.railgunreborn.client.meltdowner;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.ability.meltdowner.LightShieldSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.MeltdownerRules;
import com.railgunreborn.ability.meltdowner.MeltdownerSkill;
import com.railgunreborn.ability.meltdowner.MineRaySkill;
import com.railgunreborn.ability.meltdowner.RayBarrageRules;
import com.railgunreborn.ability.meltdowner.RayBarrageSkill;
import com.railgunreborn.ability.meltdowner.ScatterBombRules;
import com.railgunreborn.ability.meltdowner.ScatterBombSkill;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.MdBallEffects;
import com.railgunreborn.client.effect.MdShieldEffects;
import com.railgunreborn.client.effect.RayEffect;
import com.railgunreborn.client.effect.RayEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;
import com.railgunreborn.client.hud.ScatterChargeState;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.registries.DeferredHolder;

/** Efectos de cliente de las habilidades de Meltdowner. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class MeltdownerClient {
    /** El servidor manda puntos reales; más lejos que esto no viene de un disparo legítimo. */
    private static final double MAX_DISTANCE = 40.0;
    private static final int MAX_BALL_LIFE = 40;
    /** Partículas del rayo: una por tick de vida del rayo, a 0-10 bloques del origen (ficha §7.2). */
    private static final int RAY_PARTICLES = 14;
    private static final double PARTICLE_SPREAD = 10.0;

    private MeltdownerClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Meltdowner.ELECTRON_BOMB.getId(), MeltdownerClient::electronBombEffect);
        SkillEffects.register(Meltdowner.SCATTER_BOMB.getId(), MeltdownerClient::scatterBombEffect);
        SkillEffects.register(Meltdowner.LIGHT_SHIELD.getId(), MeltdownerClient::lightShieldEffect);
        SkillEffects.register(Meltdowner.MELTDOWNER.getId(), MeltdownerClient::meltdownerEffect);
        SkillEffects.register(Meltdowner.RAY_BARRAGE.getId(), MeltdownerClient::rayBarrageEffect);
        for (DeferredHolder<Skill, MineRaySkill> holder : List.of(Meltdowner.MINE_RAY_BASIC,
                Meltdowner.MINE_RAY_EXPERT, Meltdowner.MINE_RAY_LUCK)) {
            SkillEffects.register(holder.getId(), (caster, contextId, channel, data) ->
                    MineRayEffects.handle(caster, contextId, channel, holder.get().variant(), data));
        }
        KeyHintHud.registerChargeOutline(Meltdowner.MELTDOWNER.getId(), MELTDOWNER_CHARGE, MELTDOWNER_OUTLINE);
        JetEngineClient.setup();
    }

    /** Carga de Meltdowner del jugador local (contorno del icono). */
    private static final ChargeTracker MELTDOWNER_CHARGE = new ChargeTracker(MeltdownerRules.TOLERANCE_TICKS + 20);

    /**
     * Gris hasta 20 (soltar no dispara), verde hasta 40 (cada tick mejora el disparo), ámbar hasta 80 (carga máxima,
     * solo gasta CP) y rojo parpadeante los últimos 20 ticks antes de cancelarse a los 100.
     */
    public static final ChargeOutline MELTDOWNER_OUTLINE = ChargeOutline.builder(MeltdownerRules.TOLERANCE_TICKS)
            .band(MeltdownerRules.MIN_TICKS, 0xFF8A8F98)
            .band(MeltdownerRules.MAX_TICKS, 0xFF6AF26A)
            .band(MeltdownerRules.TOLERANCE_TICKS - 20, 0xFFFFB02E)
            .band(MeltdownerRules.TOLERANCE_TICKS, 0xFFFF4A3A)
            .warningFrom(MeltdownerRules.TOLERANCE_TICKS - 20)
            .build();

    /** Origen del rayo grande: los ojos del lanzador; más lejos no viene de un disparo legítimo. */
    private static final double MAX_ORIGIN_DISTANCE = 8.0;
    /** Rayo pequeño (Electron Bomb, Ray Barrage, Electron Missile): -20 % a pedido del usuario. */
    private static final float RAY_SMALL_VOLUME = 0.64f;
    /** Scatter Bomb dispara varios rayos a la vez: -40 % más a pedido del usuario. */
    private static final float SCATTER_RAY_VOLUME = RAY_SMALL_VOLUME * 0.6f;
    private static final float MELTDOWNER_VOLUME = 0.35f; // -30 % a pedido del usuario (era 0.5)

    private static void meltdownerEffect(Player caster, int contextId, String channel, CompoundTag data) {
        boolean local = caster == Minecraft.getInstance().player;
        switch (channel) {
            case MeltdownerSkill.CHANNEL_START -> {
                MeltdownerChargeEffects.start(caster);
                if (local) {
                    MELTDOWNER_CHARGE.start();
                }
            }
            case MeltdownerSkill.CHANNEL_FIRE -> {
                Vec3 origin = ElectronBombSkill.readVec(data.getCompound(MeltdownerSkill.ORIGIN_KEY));
                Vec3 dir = ElectronBombSkill.readVec(data.getCompound(MeltdownerSkill.DIR_KEY));
                double length = Math.min(data.getFloat(MeltdownerSkill.LENGTH_KEY), MeltdownerRules.RANGE);
                if (dir.lengthSqr() < 1.0e-6 || origin.distanceTo(caster.getEyePosition()) > MAX_ORIGIN_DISTANCE) {
                    return;
                }
                if (length > 1.0e-3) {
                    RayEffects.spawn(new RayEffect(MdRayStyles.LARGE, caster, origin, dir, length));
                    MeltdownerChargeEffects.rayParticles(caster.level(), origin, dir, length);
                }
                caster.level().playLocalSound(caster.getX(), caster.getY(), caster.getZ(), ModSounds.MELTDOWNER.get(),
                        SoundSource.PLAYERS, MELTDOWNER_VOLUME, 1.0f, false);
            }
            case MeltdownerSkill.CHANNEL_STOP -> {
                MeltdownerChargeEffects.stop(caster);
                if (local) {
                    MELTDOWNER_CHARGE.end();
                }
            }
            default -> {
            }
        }
    }

    /**
     * Ray Barrage ({@code ray-barrage.md} §9): rayo previo de la mano al barn (o al final del rayo directo) y, si hubo
     * barn, abanico de 25-29 sub-rayos desde él con la orientación del jugador y un rayo más hacia cada afectado.
     */
    private static void rayBarrageEffect(Player caster, int contextId, String channel, CompoundTag data) {
        if (!RayBarrageSkill.CHANNEL_SHOT.equals(channel)) {
            return;
        }
        Vec3 from = ElectronBombSkill.readVec(data.getCompound(RayBarrageSkill.FROM_KEY));
        Vec3 to = ElectronBombSkill.readVec(data.getCompound(RayBarrageSkill.TO_KEY));
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (from.distanceTo(caster.getEyePosition()) > MAX_ORIGIN_DISTANCE || length > MAX_DISTANCE) {
            return;
        }
        boolean barn = data.getBoolean(RayBarrageSkill.BARN_KEY);
        var level = caster.level();
        if (length > 1.0e-3) {
            RayEffects.spawn(new RayEffect(barn ? MdRayStyles.BARRAGE_PRE : MdRayStyles.BARRAGE_PRE_SHORT, caster,
                    from, delta, length));
        }
        // 0.8 en la ficha, bajado un 20 % como el resto de rayos pequeños (pedido del usuario).
        level.playLocalSound(from.x, from.y, from.z, ModSounds.MD_RAY_SMALL.get(), SoundSource.PLAYERS, 0.64f, 1.0f,
                false);
        if (!barn) {
            return;
        }

        Vec3 center = ElectronBombSkill.readVec(data.getCompound(RayBarrageSkill.BARN_POS_KEY));
        if (center.distanceTo(from) > MAX_DISTANCE) {
            return;
        }
        float yaw = data.getFloat(RayBarrageSkill.YAW_KEY);
        float pitch = data.getFloat(RayBarrageSkill.PITCH_KEY);
        var random = caster.getRandom();
        int count = RayBarrageRules.FAN_RAYS_MIN
                + random.nextInt(RayBarrageRules.FAN_RAYS_MAX - RayBarrageRules.FAN_RAYS_MIN + 1);
        double spread = RayBarrageRules.FAN_SPREAD_MIN
                + random.nextDouble() * (RayBarrageRules.FAN_SPREAD_MAX - RayBarrageRules.FAN_SPREAD_MIN);
        for (int i = 0; i < count; i++) {
            float rayYaw = (float) (yaw + (random.nextDouble() * 2 - 1) * spread);
            float rayPitch = (float) Math.max(-89.0, Math.min(89.0, pitch + (random.nextDouble() * 2 - 1) * spread / 2));
            RayEffects.spawn(new RayEffect(MdRayStyles.BARRAGE_FAN, caster, center,
                    Vec3.directionFromRotation(rayPitch, rayYaw), RayBarrageRules.FAN_RAY_LENGTH));
        }
        ListTag targets = data.getList(RayBarrageSkill.TARGETS_KEY, Tag.TAG_COMPOUND);
        for (int i = 0; i < Math.min(targets.size(), RayBarrageSkill.MAX_TARGET_RAYS); i++) {
            Vec3 target = ElectronBombSkill.readVec(targets.getCompound(i));
            Vec3 d = target.subtract(center);
            double len = d.length();
            if (len > 1.0e-3 && len < MAX_DISTANCE) {
                RayEffects.spawn(new RayEffect(MdRayStyles.BARRAGE_FAN, caster, center, d, len));
            }
        }
        level.playLocalSound(center.x, center.y, center.z, ModSounds.MD_RAY_SMALL.get(), SoundSource.PLAYERS, 0.5f,
                1.0f, false);
    }

    private static void lightShieldEffect(Player caster, int contextId, String channel, CompoundTag data) {
        switch (channel) {
            case LightShieldSkill.CHANNEL_START -> MdShieldEffects.start(caster, contextId);
            case LightShieldSkill.CHANNEL_STOP -> MdShieldEffects.stop(caster, contextId);
            default -> {
            }
        }
    }

    private static void electronBombEffect(Player caster, int contextId, String channel, CompoundTag data) {
        switch (channel) {
            case ElectronBombSkill.CHANNEL_BALL -> {
                int life = Math.min(data.getInt(ElectronBombSkill.LIFE_KEY), MAX_BALL_LIFE);
                Vec3 offset = ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.OFFSET_KEY));
                if (life > 0 && offset.length() < 4.0) {
                    MdBallEffects.spawn(caster, offset, life);
                }
            }
            case ElectronBombSkill.CHANNEL_RAY -> spawnRay(caster, ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.FROM_KEY)),
                    ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.TO_KEY)));
            default -> {
            }
        }
    }

    private static void scatterBombEffect(Player caster, int contextId, String channel, CompoundTag data) {
        boolean local = caster == Minecraft.getInstance().player;
        switch (channel) {
            case ScatterBombSkill.CHANNEL_START -> {
                if (local) {
                    ScatterChargeState.start();
                }
            }
            case ScatterBombSkill.CHANNEL_BALL -> {
                Vec3 offset = ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.OFFSET_KEY));
                if (offset.length() < 4.0) {
                    MdBallEffects.spawnHeld(caster, offset);
                }
            }
            case ScatterBombSkill.CHANNEL_END -> {
                MdBallEffects.releaseHeld(caster);
                if (local) {
                    ScatterChargeState.end();
                }
                ListTag rays = data.getList(ScatterBombSkill.RAYS_KEY, Tag.TAG_COMPOUND);
                for (int i = 0; i < Math.min(rays.size(), ScatterBombRules.MAX_BALLS); i++) {
                    CompoundTag ray = rays.getCompound(i);
                    spawnRay(caster, ElectronBombSkill.readVec(ray.getCompound(ElectronBombSkill.FROM_KEY)),
                            ElectronBombSkill.readVec(ray.getCompound(ElectronBombSkill.TO_KEY)), SCATTER_RAY_VOLUME);
                }
            }
            default -> {
            }
        }
    }

    static void spawnRay(Player caster, Vec3 from, Vec3 to) {
        spawnRay(caster, from, to, RAY_SMALL_VOLUME);
    }

    static void spawnRay(Player caster, Vec3 from, Vec3 to, float volume) {
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < 1.0e-3 || length > MAX_DISTANCE || from.distanceTo(caster.position()) > MAX_DISTANCE) {
            return;
        }
        RayEffects.spawn(new RayEffect(MdRayStyles.SMALL, caster, from, delta, length));
        caster.level().playLocalSound(from.x, from.y, from.z, ModSounds.MD_RAY_SMALL.get(), SoundSource.PLAYERS, volume,
                1.0f, false);
        spawnParticles(caster, from, delta.normalize(), length);
    }

    private static void spawnParticles(Player caster, Vec3 from, Vec3 dir, double length) {
        var random = caster.getRandom();
        double spread = Math.min(length, PARTICLE_SPREAD);
        for (int i = 0; i < RAY_PARTICLES; i++) {
            Vec3 p = from.add(dir.scale(random.nextDouble() * spread));
            caster.level().addParticle(ModParticles.MD.get(), p.x, p.y, p.z,
                    (random.nextDouble() * 2 - 1) * 0.015, (random.nextDouble() * 2 - 1) * 0.015,
                    (random.nextDouble() * 2 - 1) * 0.015);
        }
    }
}
