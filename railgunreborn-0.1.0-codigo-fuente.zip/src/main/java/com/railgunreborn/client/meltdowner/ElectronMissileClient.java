package com.railgunreborn.client.meltdowner;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.ElectronBombSkill;
import com.railgunreborn.ability.meltdowner.ElectronMissileRules;
import com.railgunreborn.ability.meltdowner.ElectronMissileSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.client.context.SkillEffects;
import com.railgunreborn.client.effect.MdBallEffects;
import com.railgunreborn.client.hud.ChargeOutline;
import com.railgunreborn.client.hud.ChargeTracker;
import com.railgunreborn.client.hud.KeyHintHud;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Efectos de cliente de Electron Missile ({@code electron-missile.md} §7-8): bolas sostenidas que siguen al jugador,
 * rayo pequeño de la bola gastada a los ojos del objetivo, nube de partículas mientras dura
 * ({@link ElectronMissileCloud}) y contorno del icono con el tiempo restante. Bus del mod (solo el registro).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ElectronMissileClient {
    private static final int LONGEST = ElectronMissileRules.maxTicks(1f);
    /** Últimos ticks en rojo parpadeante antes de que se acabe el tiempo. */
    private static final int WARNING_TICKS = 20;

    private static final ChargeTracker TRACKER = new ChargeTracker(LONGEST + 1);
    /** El tiempo máximo depende de la exp: un contorno por duración, reemplazado al pulsar. */
    private static final Map<Integer, ChargeOutline> OUTLINES = new ConcurrentHashMap<>();

    private ElectronMissileClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        SkillEffects.register(Meltdowner.ELECTRON_MISSILE.getId(), ElectronMissileClient::effect);
        KeyHintHud.registerChargeOutline(Meltdowner.ELECTRON_MISSILE.getId(), TRACKER,
                outline(ElectronMissileRules.maxTicks(0f)));
    }

    /** Verde mientras dura y rojo parpadeante los últimos 20 ticks. */
    static ChargeOutline outline(int maxTicks) {
        int total = Math.max(maxTicks + 1, WARNING_TICKS + 1);
        return OUTLINES.computeIfAbsent(total, t -> ChargeOutline.builder(t)
                .band(t - WARNING_TICKS, 0xFF6AF26A)
                .band(t, 0xFFFF4A3A)
                .warningFrom(t - WARNING_TICKS)
                .build());
    }

    private static void effect(Player caster, int contextId, String channel, CompoundTag data) {
        boolean local = caster == Minecraft.getInstance().player;
        switch (channel) {
            case ElectronMissileSkill.CHANNEL_START -> {
                ElectronMissileCloud.start(caster);
                if (local) {
                    int maxTicks = Math.clamp(data.getInt(ElectronMissileSkill.MAX_TICKS_KEY), 1, LONGEST);
                    KeyHintHud.registerChargeOutline(Meltdowner.ELECTRON_MISSILE.getId(), TRACKER, outline(maxTicks));
                    TRACKER.start();
                }
            }
            case ElectronMissileSkill.CHANNEL_BALL -> {
                Vec3 offset = ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.OFFSET_KEY));
                if (offset.length() < 4.0) {
                    MdBallEffects.spawnHeld(caster, offset, data.getInt(ElectronMissileSkill.BALL_KEY));
                }
            }
            case ElectronMissileSkill.CHANNEL_ATTACK -> {
                MdBallEffects.removeHeld(caster, data.getInt(ElectronMissileSkill.BALL_KEY));
                MeltdownerClient.spawnRay(caster, ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.FROM_KEY)),
                        ElectronBombSkill.readVec(data.getCompound(ElectronBombSkill.TO_KEY)));
            }
            case ElectronMissileSkill.CHANNEL_STOP -> {
                MdBallEffects.releaseHeld(caster);
                ElectronMissileCloud.stop(caster);
                if (local) {
                    TRACKER.end();
                }
            }
            default -> {
            }
        }
    }
}
