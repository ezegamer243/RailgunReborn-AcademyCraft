package com.railgunreborn.client.meltdowner;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.random.RandomGenerator;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.MineRayRules.Variant;
import com.railgunreborn.ability.meltdowner.MineRaySkill;
import com.railgunreborn.client.effect.RayEffect;
import com.railgunreborn.client.effect.RayEffects;
import com.railgunreborn.client.effect.RayStyle;
import com.railgunreborn.client.sound.EntityLoopSound;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Efectos de Mining Ray en el cliente ({@code EntityMineRay*} y {@code MRContextC} del original, ficha §7-8): un
 * rayo fino continuo que sigue al jugador desde la mano hasta el bloque apuntado (o hasta el alcance si no hay;
 * decisión 10 de la ficha), partículas Md a lo largo del rayo y sobre el bloque que se mina, arranque por variante y
 * zumbido en bucle. Uno por jugador, en todos los clientes cercanos. Solo cliente (bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class MineRayEffects {
    private static final float STARTUP_VOLUME = 0.4f;
    private static final float LOOP_VOLUME = 0.3f;
    /** Partículas del rayo: a 0-10 bloques del ojo, velocidad ±0.03 por eje. */
    private static final double RAY_PARTICLE_SPREAD = 10.0;
    /** Partículas del bloque minado: 3 por tick en un cubo de 1.4 centrado en el bloque, velocidad ±0.06. */
    private static final int TARGET_PARTICLES = 3;
    private static final int BREAK_PARTICLES = 10;
    /** Si no llega el "stop" (fuera de rango, paquete perdido), el rayo de otro jugador se corta solo. */
    private static final int SAFETY_TICKS = 20 * 60 * 5;

    private static final Map<Integer, Beam> BEAMS = new HashMap<>();

    private MineRayEffects() {
    }

    public static void handle(Player caster, int contextId, String channel, Variant variant,
            CompoundTag data) {
        switch (channel) {
            case MineRaySkill.CHANNEL_START -> start(caster, contextId, variant);
            case MineRaySkill.CHANNEL_TARGET -> {
                Beam beam = BEAMS.get(caster.getId());
                if (beam != null && beam.contextId == contextId) {
                    beam.target = validPos(caster, variant, MineRaySkill.readPos(data));
                }
            }
            case MineRaySkill.CHANNEL_BREAK -> {
                BlockPos pos = validPos(caster, variant, MineRaySkill.readPos(data));
                if (pos != null) {
                    burst(caster, pos, particle(variant), BREAK_PARTICLES);
                }
            }
            case MineRaySkill.CHANNEL_STOP -> stop(caster, contextId);
            default -> {
            }
        }
    }

    /** Descarta posiciones que no pueden venir de un rayo legítimo de este jugador. */
    @Nullable
    private static BlockPos validPos(Player caster, Variant variant, @Nullable BlockPos pos) {
        if (pos == null || Vec3.atCenterOf(pos).distanceTo(caster.getEyePosition()) > variant.range + 2.0) {
            return null;
        }
        return pos;
    }

    private static void start(Player caster, int contextId, Variant variant) {
        stop(caster, -1);
        EntityLoopSound loop = new EntityLoopSound(ModSounds.MINE_LOOP.get(), SoundSource.PLAYERS, caster,
                LOOP_VOLUME);
        Minecraft.getInstance().getSoundManager().play(loop);
        caster.level().playLocalSound(caster.getX(), caster.getY(), caster.getZ(), startupSound(variant),
                SoundSource.PLAYERS, STARTUP_VOLUME, 1.0f, false);
        Beam beam = new Beam(caster, contextId, variant, loop);
        BEAMS.put(caster.getId(), beam);
        RayEffects.spawn(beam);
    }

    /** @param contextId el del "stop"; -1 quita cualquier rayo del jugador */
    private static void stop(Player caster, int contextId) {
        Beam beam = BEAMS.get(caster.getId());
        if (beam != null && (contextId < 0 || beam.contextId == contextId)) {
            BEAMS.remove(caster.getId());
            beam.finish();
        }
    }

    private static SoundEvent startupSound(Variant variant) {
        return switch (variant) {
            case BASIC -> ModSounds.MINE_BASIC_STARTUP.get();
            case EXPERT -> ModSounds.MINE_EXPERT_STARTUP.get();
            case LUCK -> ModSounds.MINE_LUCK_STARTUP.get();
        };
    }

    private static RayStyle styleOf(Variant variant) {
        return switch (variant) {
            case BASIC -> MdRayStyles.MINE_BASIC;
            case EXPERT -> MdRayStyles.MINE_EXPERT;
            case LUCK -> MdRayStyles.MINE_LUCK;
        };
    }

    private static SimpleParticleType particle(Variant variant) {
        return variant == Variant.LUCK ? ModParticles.MD_LUCK.get() : ModParticles.MD.get();
    }

    /** Chispas en un cubo de lado 1.4 centrado en el bloque, que caen despacio. */
    private static void burst(Player caster, BlockPos pos, SimpleParticleType type, int count) {
        RandomSource random = caster.getRandom();
        for (int i = 0; i < count; i++) {
            double x = pos.getX() - 0.2 + random.nextDouble() * 1.4;
            double y = pos.getY() - 0.2 + random.nextDouble() * 1.4;
            double z = pos.getZ() - 0.2 + random.nextDouble() * 1.4;
            caster.level().addParticle(type, x, y, z, (random.nextDouble() * 2 - 1) * 0.06,
                    (random.nextDouble() * 2 - 1) * 0.06 - 0.01, (random.nextDouble() * 2 - 1) * 0.06);
        }
    }

    /** El rayo: sigue la mirada del lanzador en cada fotograma; vive hasta el "stop". */
    private static final class Beam extends RayEffect {
        final Player caster;
        final int contextId;
        final Variant variant;
        final EntityLoopSound loop;
        @Nullable
        BlockPos target;
        boolean finished;
        int ticks;
        private float cachedPartial = Float.NaN;
        private int cachedAge = -1;
        @Nullable
        private Frame cached;

        Beam(Player caster, int contextId, Variant variant, EntityLoopSound loop) {
            super(styleOf(variant), caster, caster.getEyePosition(), caster.getViewVector(1f), variant.range);
            this.caster = caster;
            this.contextId = contextId;
            this.variant = variant;
            this.loop = loop;
        }

        void finish() {
            finished = true;
            loop.finish();
        }

        @Override
        public boolean tick(RandomGenerator rand) {
            if (!finished && (caster.isRemoved() || ++ticks > SAFETY_TICKS)) {
                BEAMS.remove(caster.getId(), this);
                finish();
            }
            if (finished) {
                return false;
            }
            RandomSource random = caster.getRandom();
            SimpleParticleType type = particle(variant);
            float chance = variant == Variant.BASIC ? 0.5f : 0.6f;
            if (random.nextFloat() < chance) {
                Vec3 p = caster.getEyePosition().add(caster.getViewVector(1f)
                        .scale(random.nextDouble() * Math.min(RAY_PARTICLE_SPREAD, variant.range)));
                caster.level().addParticle(type, p.x, p.y, p.z, (random.nextDouble() * 2 - 1) * 0.03,
                        (random.nextDouble() * 2 - 1) * 0.03, (random.nextDouble() * 2 - 1) * 0.03);
            }
            if (target != null) {
                burst(caster, target, type, TARGET_PARTICLES);
            }
            return super.tick(rand);
        }

        @Override
        protected Frame frame(float partialTick) {
            if (cached != null && cachedPartial == partialTick && cachedAge == age()) {
                return cached;
            }
            Vec3 eye = caster.getEyePosition(partialTick);
            Vec3 look = caster.getViewVector(partialTick);
            BlockHitResult hit = MineRaySkill.trace(caster.level(), eye, look, variant.range, null);
            Vec3 end = hit != null ? hit.getLocation() : eye.add(look.scale(variant.range));
            Vec3[] axes = axes(look);
            Vec3 start = eye.add(handOffset(caster, look, axes[0], axes[1]));
            Vec3 delta = end.subtract(start);
            double length = delta.length();
            cached = length < 1.0e-3 ? Frame.of(start, look, 0.0) : Frame.of(start, delta, length);
            cachedPartial = partialTick;
            cachedAge = age();
            return cached;
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused() || BEAMS.isEmpty()) {
            return;
        }
        for (Iterator<Beam> it = BEAMS.values().iterator(); it.hasNext(); ) {
            Beam beam = it.next();
            if (beam.caster.level() != mc.level) {
                beam.finish();
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        BEAMS.values().forEach(Beam::finish);
        BEAMS.clear();
    }
}
