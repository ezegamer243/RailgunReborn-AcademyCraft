package com.railgunreborn.client.meltdowner;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

/**
 * Partícula "Md" de Meltdowner ({@code MdParticleFactory} del original, ficha {@code rad-intensify.md} §5): vida 25-55
 * ticks, alfa 76-152 sobre 255 que se desvanece los últimos 20 ticks, tamaño 0.05-0.07, sin gravedad ni colisión, a
 * plena luz. La velocidad es la que manda quien la crea.
 */
public final class MdParticle extends TextureSheetParticle {
    private static final int FADE_TICKS = 20;

    private final float baseAlpha;

    private MdParticle(ClientLevel level, double x, double y, double z, double xd, double yd, double zd) {
        super(level, x, y, z);
        this.xd = xd;
        this.yd = yd;
        this.zd = zd;
        this.gravity = 0f;
        this.hasPhysics = false;
        this.lifetime = 25 + random.nextInt(31);
        this.baseAlpha = (76 + random.nextInt(77)) / 255f;
        this.alpha = baseAlpha;
        this.quadSize = 0.05f + random.nextFloat() * 0.02f;
    }

    @Override
    public void tick() {
        super.tick();
        alpha = baseAlpha * Mth.clamp((lifetime - age) / (float) FADE_TICKS, 0f, 1f);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    /** Registro del proveedor (bus del MOD, solo cliente). */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        private Registration() {
        }

        @SubscribeEvent
        public static void register(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.MD.get(), Provider::new);
            event.registerSpriteSet(ModParticles.MD_LUCK.get(), Provider::new);
        }
    }

    private record Provider(SpriteSet sprites) implements ParticleProvider<SimpleParticleType> {
        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                double xd, double yd, double zd) {
            MdParticle particle = new MdParticle(level, x, y, z, xd, yd, zd);
            particle.pickSprite(sprites);
            return particle;
        }
    }
}
