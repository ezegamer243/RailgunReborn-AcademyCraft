package com.railgunreborn.client;

import java.util.Map;
import java.util.WeakHashMap;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.client.screen.ImagFusorScreen;
import com.railgunreborn.client.sound.MachineLoopSound;
import com.railgunreborn.registry.ModMenus;
import com.railgunreborn.registry.ModSounds;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Cliente del Imag Fusor (bus del MOD): pantalla y sonido de trabajo en bucle. */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ImagFusorClient {
    /** Volumen moderado: el usuario prefiere sonidos de máquina discretos. */
    private static final float WORK_VOLUME = 0.4f;

    private static final Map<ImagFusorBlockEntity, MachineLoopSound> SOUNDS = new WeakHashMap<>();

    private ImagFusorClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.IMAG_FUSOR.get(), ImagFusorScreen::new);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        ImagFusorBlockEntity.clientTickHook = ImagFusorClient::tick;
    }

    private static void tick(ImagFusorBlockEntity be) {
        if (!be.isWorking()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        MachineLoopSound current = SOUNDS.get(be);
        if (current != null && mc.getSoundManager().isActive(current)) {
            return;
        }
        MachineLoopSound sound = new MachineLoopSound(ModSounds.IMAG_FUSOR_WORK.get(), be.getBlockPos(), WORK_VOLUME,
                () -> !be.isRemoved() && be.isWorking() && be.getLevel() == Minecraft.getInstance().level);
        SOUNDS.put(be, sound);
        mc.getSoundManager().play(sound);
    }
}
