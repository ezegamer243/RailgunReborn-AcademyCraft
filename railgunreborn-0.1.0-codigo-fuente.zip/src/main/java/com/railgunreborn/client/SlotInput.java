package com.railgunreborn.client;

import com.railgunreborn.client.context.ClientSkillContexts;

import net.minecraft.resources.ResourceLocation;

/**
 * Aquí llegan las pulsaciones de ranura con el modo habilidad activo. Solo se llama cuando la ranura del preset
 * activo tiene una habilidad; {@code onSlotUp} recibe la misma habilidad que recibió {@code onSlotDown} aunque
 * entre medias se haya cambiado de preset o desactivado el modo.
 */
public final class SlotInput {
    private SlotInput() {
    }

    /** Crea el contexto de la habilidad y avisa al servidor (si el cliente ya sabe que no puede, no hace nada). */
    public static void onSlotDown(int slot, ResourceLocation skill) {
        ClientSkillContexts.keyDown(slot, skill);
    }

    /** @param slot ranura 0-based (0 = clic izquierdo, 1 = clic derecho, 2 = R, 3 = F por defecto). */
    public static void onSlotUp(int slot, ResourceLocation skill) {
        ClientSkillContexts.keyUp(slot, skill);
    }
}
