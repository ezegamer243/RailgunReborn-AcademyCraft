package com.railgunreborn.client.sound;

import java.util.function.BooleanSupplier;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

/** Sonido en bucle de una máquina: suena en su posición mientras {@code active} sea cierto y luego se corta. */
public final class MachineLoopSound extends AbstractTickableSoundInstance {
    private final BooleanSupplier active;

    public MachineLoopSound(SoundEvent sound, BlockPos pos, float volume, BooleanSupplier active) {
        super(sound, SoundSource.BLOCKS, SoundInstance.createUnseededRandom());
        this.active = active;
        this.looping = true;
        this.delay = 0;
        this.volume = volume;
        this.x = pos.getX() + 0.5;
        this.y = pos.getY() + 0.5;
        this.z = pos.getZ() + 0.5;
    }

    @Override
    public void tick() {
        if (!active.getAsBoolean()) {
            stop();
        }
    }
}
