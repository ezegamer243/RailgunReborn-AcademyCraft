package com.railgunreborn.client.sound;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

/**
 * Sonido en bucle pegado a una entidad hasta {@link #finish()} o hasta que la entidad desaparezca
 * ({@code FollowEntitySound} del original). Reutilizable por las habilidades mantenidas.
 */
public final class EntityLoopSound extends AbstractTickableSoundInstance {
    private final Entity entity;

    public EntityLoopSound(SoundEvent sound, SoundSource source, Entity entity, float volume) {
        this(sound, source, entity, volume, true);
    }

    /** @param looping false = suena una vez, pegado a la entidad y cortable con {@link #finish()} (carga de Meltdowner) */
    public EntityLoopSound(SoundEvent sound, SoundSource source, Entity entity, float volume, boolean looping) {
        super(sound, source, SoundInstance.createUnseededRandom());
        this.entity = entity;
        this.looping = looping;
        this.delay = 0;
        this.volume = volume;
        this.x = entity.getX();
        this.y = entity.getY();
        this.z = entity.getZ();
    }

    public void finish() {
        stop();
    }

    @Override
    public void tick() {
        if (entity.isRemoved()) {
            stop();
            return;
        }
        x = entity.getX();
        y = entity.getY();
        z = entity.getZ();
    }
}
