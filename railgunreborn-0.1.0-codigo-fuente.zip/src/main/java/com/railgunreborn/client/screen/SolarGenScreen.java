package com.railgunreborn.client.screen;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.SolarGenBlockEntity;
import com.railgunreborn.block.SolarGenMenu;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.energy.EnergyFormat;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** Pantalla del generador solar en el estilo de {@link AcStyle}: estado, barra de energía y ranura de batería. */
public class SolarGenScreen extends AbstractContainerScreen<SolarGenMenu> {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");
    private static final int BAR_X = 18;
    private static final int BAR_Y = 34;
    private static final int BAR_W = 140;
    private static final int BAR_H = 12;

    public SolarGenScreen(SolarGenMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (rx >= BAR_X && rx < BAR_X + BAR_W && ry >= BAR_Y && ry < BAR_Y + BAR_H) {
            graphics.renderTooltip(font, Component.literal(EnergyFormat.fraction(menu.getEnergy(),
                    SolarGenBlockEntity.CAPACITY)), mouseX, mouseY);
        } else if (rx >= SolarGenMenu.BATTERY_X && rx < SolarGenMenu.BATTERY_X + 16 && ry >= SolarGenMenu.BATTERY_Y
                && ry < SolarGenMenu.BATTERY_Y + 16 && menu.getCarried().isEmpty()
                && !menu.slots.get(SolarGenBlockEntity.SLOT_BATTERY).hasItem()) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.solar_gen.battery"), mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        int fill = Math.round(BAR_W * Math.min(1f, menu.getEnergy() / (float) SolarGenBlockEntity.CAPACITY));
        if (fill > 0) {
            graphics.fill(x + BAR_X, y + BAR_Y, x + BAR_X + fill, y + BAR_Y + BAR_H, TechUiLayout.TANK_FILL);
        }
        AcStyle.frame(graphics, x + BAR_X, y + BAR_Y, BAR_W, BAR_H);
        AcStyle.slotGrid(graphics, x + SolarGenMenu.BATTERY_X, y + SolarGenMenu.BATTERY_Y, 1, 1);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);

        Component status = Component.translatable("gui.railgunreborn.solar_gen.status."
                + menu.getStatus().name().toLowerCase(java.util.Locale.ROOT));
        graphics.drawString(font, status, x + imageWidth / 2 - font.width(status) / 2, y + 16, TechUiLayout.TEXT, false);
        Component energy = Component.literal(EnergyFormat.fraction(menu.getEnergy(), SolarGenBlockEntity.CAPACITY));
        graphics.drawString(font, energy, x + imageWidth / 2 - font.width(energy) / 2, y + BAR_Y + BAR_H + 6,
                TechUiLayout.TEXT, false);
        AcStyle.end();
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }
}
