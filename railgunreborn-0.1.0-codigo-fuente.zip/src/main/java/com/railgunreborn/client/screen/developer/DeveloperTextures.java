package com.railgunreborn.client.screen.developer;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.mojang.blaze3d.platform.NativeImage;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;

/**
 * Texturas de la pantalla del Developer cargadas como {@link DynamicTexture}.
 *
 * <p>Las del original son de 128 px y se dibujan a 14-31 unidades: con el filtro vecino de las texturas normales
 * los aros finos se ven con dientes, así que se cargan con filtro lineal. La variante en grises sustituye al shader
 * {@code mono} del original (iconos de habilidades no aprendidas y requisitos no cumplidos).
 */
public final class DeveloperTextures {
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();

    private DeveloperTextures() {
    }

    /** {@code railgunreborn:textures/gui/developer/<name>.png} con filtro lineal. */
    public static ResourceLocation gui(String name) {
        return linear(path(name));
    }

    /** Ruta del recurso {@code railgunreborn:textures/gui/developer/<name>.png} (sin cargar). */
    public static ResourceLocation path(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/developer/" + name + ".png");
    }

    /** La textura tal cual, con filtro lineal. */
    public static ResourceLocation linear(ResourceLocation source) {
        return CACHE.computeIfAbsent("linear/" + key(source), k -> bake(k, source, false));
    }

    /** La textura en escala de grises (luminancia), con filtro lineal. */
    public static ResourceLocation grayscale(ResourceLocation source) {
        return CACHE.computeIfAbsent("gray/" + key(source), k -> bake(k, source, true));
    }

    /** Recarga de recursos: se liberan y se vuelven a cargar al primer dibujo. */
    public static void invalidate() {
        TextureManager manager = Minecraft.getInstance().getTextureManager();
        CACHE.values().forEach(manager::release);
        CACHE.clear();
    }

    private static String key(ResourceLocation source) {
        return (source.getNamespace() + "/" + source.getPath()).toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9_./-]", "_");
    }

    private static ResourceLocation bake(String key, ResourceLocation source, boolean gray) {
        try {
            NativeImage image;
            try (InputStream in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(source).open()) {
                image = NativeImage.read(in);
            }
            if (gray) {
                toGrayscale(image);
            }
            DynamicTexture texture = new DynamicTexture(image);
            texture.setFilter(true, false);
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "developer_baked/" + key);
            Minecraft.getInstance().getTextureManager().register(id, texture);
            return id;
        } catch (IOException | RuntimeException e) {
            RailgunReborn.LOGGER.error("Could not load developer texture '{}'", source, e);
            return MissingTextureAtlasSprite.getLocation(); // magenta visible; no se reintenta cada frame
        }
    }

    // NativeImage.getPixelRGBA devuelve ABGR.
    private static void toGrayscale(NativeImage image) {
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int abgr = image.getPixelRGBA(x, y);
                int r = abgr & 0xFF;
                int g = (abgr >> 8) & 0xFF;
                int b = (abgr >> 16) & 0xFF;
                int l = Math.min(255, Math.round(0.299f * r + 0.587f * g + 0.114f * b));
                image.setPixelRGBA(x, y, (abgr & 0xFF000000) | (l << 16) | (l << 8) | l);
            }
        }
    }
}
