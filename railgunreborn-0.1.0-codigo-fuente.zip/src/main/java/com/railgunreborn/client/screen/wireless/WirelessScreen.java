package com.railgunreborn.client.screen.wireless;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.lwjgl.glfw.GLFW;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.block.TechUiLayout.Rect;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.wireless.WirelessMenu;
import com.railgunreborn.wireless.WirelessResult;
import com.railgunreborn.wireless.WirelessUiLayout;
import com.railgunreborn.wireless.WirelessView;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Base de las pantallas inalámbricas en el estilo de {@link AcStyle}: campos de texto propios (sin el borde vanilla,
 * con marco brillante), contraseñas con asteriscos, una lista con selección y desplazamiento, y la línea de
 * resultado de la última acción. Mientras se escribe en un campo, las teclas (E, números) no cierran la pantalla.
 */
public abstract class WirelessScreen<M extends WirelessMenu> extends AbstractContainerScreen<M> {
    protected static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");
    protected static final String LANG = "gui.railgunreborn.wireless.";
    protected static final int OK_COLOR = 0xFF9CFFA8;
    protected static final int ERROR_COLOR = 0xFFFF8A80;
    protected static final int DIM = 0x99FFFFFF;
    private static final long MESSAGE_MS = 6000;

    private final List<EditBox> fields = new ArrayList<>();
    private int seenSerial;
    private long messageUntil;

    protected WirelessScreen(M menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        seenSerial = menu.getResultSerial();
    }

    @Override
    protected void init() {
        fields.clear();
        super.init();
    }

    /** Campo de texto dentro de {@code r} (relativo a {@code (ox, oy)} de la GUI); conserva {@code value}. */
    protected EditBox field(Rect r, int ox, int oy, String value, int maxLength, boolean password, String hintKey,
            Consumer<String> responder) {
        EditBox box = new EditBox(font, leftPos + ox + r.x() + 3, topPos + oy + r.y() + 2, r.w() - 6, r.h() - 3,
                Component.translatable(LANG + hintKey));
        box.setBordered(false);
        box.setMaxLength(maxLength);
        box.setValue(value);
        box.setTextColor(0xFFFFFF);
        box.setHint(Component.translatable(LANG + hintKey).withStyle(s -> s.withColor(0x808890)));
        if (password) {
            box.setFormatter((text, start) -> FormattedCharSequence.forward("*".repeat(text.length()), Style.EMPTY));
        }
        box.setResponder(responder);
        fields.add(addRenderableWidget(box));
        return box;
    }

    protected Button button(Rect r, int ox, int oy, Component label, Button.OnPress onPress) {
        return addRenderableWidget(Button.builder(label, onPress)
                .bounds(leftPos + ox + r.x(), topPos + oy + r.y(), r.w(), r.h()).build());
    }

    protected static void send(WirelessActionPayload payload) {
        PacketDistributor.sendToServer(payload);
    }

    // --- Dibujo ---

    protected void fieldFrame(GuiGraphics graphics, int ox, int oy, Rect r) {
        int x = leftPos + ox + r.x();
        int y = topPos + oy + r.y();
        graphics.fill(x, y, x + r.w(), y + r.h(), TechUiLayout.SLOT_FILL);
        AcStyle.frame(graphics, x, y, r.w(), r.h());
    }

    protected void text(GuiGraphics graphics, Component text, int x, int y, int color) {
        graphics.drawString(font, text, leftPos + x, topPos + y, color, false);
    }

    /** Texto cortado con "..." para que quepa en {@code width}. */
    protected String fit(String text, int width) {
        if (font.width(text) <= width) {
            return text;
        }
        return font.plainSubstrByWidth(text, Math.max(0, width - font.width("..."))) + "...";
    }

    /** Mensaje de la última acción (verde si salió bien), unos segundos, partido en líneas dentro de {@code r}. */
    protected void renderResult(GuiGraphics graphics, Rect r) {
        if (menu.getResultSerial() != seenSerial) {
            seenSerial = menu.getResultSerial();
            messageUntil = Util.getMillis() + MESSAGE_MS;
        }
        WirelessResult result = menu.getLastResult();
        if (result == null || Util.getMillis() > messageUntil) {
            return;
        }
        int y = topPos + r.y();
        for (FormattedCharSequence line : font.split(result.message(), r.w())) {
            if (y + font.lineHeight > topPos + r.y() + r.h() + 1) {
                break;
            }
            graphics.drawString(font, line, leftPos + r.x(), y, result.ok() ? OK_COLOR : ERROR_COLOR, false);
            y += font.lineHeight + 1;
        }
    }

    // --- Lista ---

    /** Lista de redes o nodos con selección por clic y rueda del ratón. */
    protected final class EntryList {
        private final Rect rect;
        private final int ox;
        private int scroll;
        private BlockPos selected;

        EntryList(Rect rect, int ox) {
            this.rect = rect;
            this.ox = ox;
        }

        BlockPos selected() {
            List<WirelessView.Entry> entries = menu.getView().entries();
            for (WirelessView.Entry e : entries) {
                if (e.pos().equals(selected)) {
                    return selected;
                }
            }
            return null;
        }

        void render(GuiGraphics graphics, int mouseX, int mouseY, Component empty, RowText rowText) {
            int x = leftPos + ox + rect.x();
            int y = topPos + rect.y();
            graphics.fill(x, y, x + rect.w(), y + rect.h(), TechUiLayout.SLOT_FILL);
            AcStyle.frame(graphics, x - 1, y - 1, rect.w() + 2, rect.h() + 2);
            List<WirelessView.Entry> entries = menu.getView().entries();
            int rows = WirelessUiLayout.rows(rect);
            scroll = Math.max(0, Math.min(scroll, entries.size() - rows));
            if (entries.isEmpty()) {
                graphics.drawString(font, empty, x + 3, y + 2, DIM, false);
                return;
            }
            BlockPos current = menu.getView().currentPos().orElse(null);
            for (int i = 0; i < rows && scroll + i < entries.size(); i++) {
                WirelessView.Entry e = entries.get(scroll + i);
                int ry = y + i * WirelessUiLayout.ROW_H;
                boolean hover = mouseX >= x && mouseX < x + rect.w() && mouseY >= ry
                        && mouseY < ry + WirelessUiLayout.ROW_H;
                if (e.pos().equals(selected)) {
                    graphics.fill(x, ry, x + rect.w(), ry + WirelessUiLayout.ROW_H, 0x5596D2FF);
                } else if (hover) {
                    graphics.fill(x, ry, x + rect.w(), ry + WirelessUiLayout.ROW_H, 0x30FFFFFF);
                }
                String right = rowText.right(e);
                int rightW = font.width(right);
                String left = fit((e.pos().equals(current) ? "> " : "") + rowText.left(e), rect.w() - rightW - 10);
                graphics.drawString(font, left, x + 3, ry + 2, e.pos().equals(current) ? OK_COLOR : 0xFFFFFFFF,
                        false);
                graphics.drawString(font, right, x + rect.w() - rightW - 3, ry + 2, DIM, false);
            }
            if (entries.size() > rows) {
                int barH = Math.max(4, rect.h() * rows / entries.size());
                int barY = y + (rect.h() - barH) * scroll / Math.max(1, entries.size() - rows);
                graphics.fill(x + rect.w() - 2, barY, x + rect.w(), barY + barH, 0xAAD6F2FF);
            }
        }

        boolean mouseClicked(double mouseX, double mouseY) {
            int x = leftPos + ox + rect.x();
            int y = topPos + rect.y();
            if (mouseX < x || mouseX >= x + rect.w() || mouseY < y || mouseY >= y + rect.h()) {
                return false;
            }
            int index = scroll + (int) (mouseY - y) / WirelessUiLayout.ROW_H;
            List<WirelessView.Entry> entries = menu.getView().entries();
            if (index >= 0 && index < entries.size()) {
                selected = entries.get(index).pos();
            }
            return true;
        }

        boolean mouseScrolled(double mouseX, double mouseY, double delta) {
            int x = leftPos + ox + rect.x();
            int y = topPos + rect.y();
            if (mouseX < x || mouseX >= x + rect.w() || mouseY < y || mouseY >= y + rect.h()) {
                return false;
            }
            scroll -= (int) Math.signum(delta);
            return true;
        }
    }

    protected interface RowText {
        String left(WirelessView.Entry e);

        String right(WirelessView.Entry e);
    }

    // --- Teclado ---

    private EditBox focusedField() {
        for (EditBox box : fields) {
            if (box.isFocused() && box.canConsumeInput()) {
                return box;
            }
        }
        return null;
    }

    /** Intro en un campo: la acción principal de la pantalla. */
    protected abstract void onEnter(EditBox box);

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        EditBox box = focusedField();
        if (box != null && keyCode != GLFW.GLFW_KEY_ESCAPE) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                onEnter(box);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_TAB) {
                int next = (fields.indexOf(box) + 1) % fields.size();
                box.setFocused(false);
                setFocused(fields.get(next));
                return true;
            }
            box.keyPressed(keyCode, scanCode, modifiers);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Un clic fuera de un campo le quita el foco (si no, la E seguiría escribiendo en vez de cerrar).
        for (EditBox box : fields) {
            if (!box.isMouseOver(mouseX, mouseY)) {
                box.setFocused(false);
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }
}
