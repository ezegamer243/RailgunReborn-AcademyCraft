package com.railgunreborn.client.screen;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.block.WindGenMainBlockEntity;
import com.railgunreborn.block.WindGenMainMenu;
import com.railgunreborn.block.WindGenRules;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla de la cabeza del generador eólico con el arte del original ({@code ui_windmain}): la caja de arriba es la
 * ranura de las aspas; debajo del dibujo de la cabeza, el estado (izquierda) y la producción y altura (derecha).
 */
public class WindGenMainScreen extends AbstractContainerScreen<WindGenMainMenu> {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");
    private static final ResourceLocation ART = WindGenScreens.tex("ui_windmain");

    // A los lados de la línea del pilar del arte (x = 87..88, de y = 73 a 99).
    private static final int LEFT_X = 6;
    private static final int LEFT_W = 76;
    private static final int RIGHT_X = 95;
    private static final int RIGHT_W = 76;
    private static final int TEXT_Y = 77;

    public WindGenMainScreen(WindGenMainMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (rx >= WindGenMainMenu.FAN_X && rx < WindGenMainMenu.FAN_X + 16 && ry >= WindGenMainMenu.FAN_Y
                && ry < WindGenMainMenu.FAN_Y + 16 && menu.getCarried().isEmpty()
                && !menu.slots.get(WindGenMainBlockEntity.SLOT_FAN).hasItem()) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.wind_gen.fan_slot"), mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        WindGenRules.Status status = menu.getStatus();
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        AcStyle.pushArtSpace(graphics, x, y);
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, ART);
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);

        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);

        column(graphics, WindGenBaseScreen.statusText(status), LEFT_X, LEFT_W, WindGenScreens.statusColor(status));
        int line = TEXT_Y;
        if (status == WindGenRules.Status.WORKING) {
            line = column(graphics, Component.translatable("gui.railgunreborn.wind_gen.output",
                    WindGenRules.formatCenti(menu.getOutputCenti())), RIGHT_X, RIGHT_W, TechUiLayout.TEXT, line);
        }
        column(graphics, Component.translatable("gui.railgunreborn.wind_gen.height", menu.getHeight()), RIGHT_X,
                RIGHT_W, TechUiLayout.TEXT, line);
        AcStyle.end();
    }

    private void column(GuiGraphics graphics, Component text, int columnX, int width, int color) {
        column(graphics, text, columnX, width, color, TEXT_Y);
    }

    private int column(GuiGraphics graphics, Component text, int columnX, int width, int color, int lineY) {
        int yy = topPos + lineY;
        for (FormattedCharSequence seq : font.split(text, width)) {
            graphics.drawString(font, seq, leftPos + columnX, yy, color, false);
            yy += font.lineHeight;
        }
        return yy - topPos;
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }
}
