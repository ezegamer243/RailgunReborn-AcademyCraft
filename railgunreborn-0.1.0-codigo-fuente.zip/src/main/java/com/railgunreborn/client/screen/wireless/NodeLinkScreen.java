package com.railgunreborn.client.screen.wireless;

import java.util.Optional;

import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.wireless.NodeLinkMenu;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessUiLayout;
import com.railgunreborn.wireless.WirelessView;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla "Current Node" de una máquina, generador o Developer (Mayús + clic derecho con la mano vacía): nodo
 * enlazado (con botón para desenlazar) y nodos en radio 20 para enlazar con la contraseña del nodo.
 */
public class NodeLinkScreen extends WirelessScreen<NodeLinkMenu> {
    private static final String[] TIERS = { "", "I", "II", "III" };

    private String password = "";
    private Button unlink;
    private Button link;
    private final EntryList nodes = new EntryList(WirelessUiLayout.LINK_LIST, 0);

    public NodeLinkScreen(NodeLinkMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = WirelessUiLayout.LINK_W;
        imageHeight = WirelessUiLayout.LINK_H;
    }

    @Override
    protected void init() {
        super.init();
        field(WirelessUiLayout.LINK_PASSWORD_FIELD, 0, 0, password, WirelessNetwork.MAX_PASSWORD_LENGTH, true,
                "password_hint", s -> password = s);
        unlink = button(WirelessUiLayout.LINK_UNLINK_BUTTON, 0, 0, Component.translatable(LANG + "link.unlink"),
                b -> send(new WirelessActionPayload(WirelessActions.Action.USER_UNLINK, menu.getPos())));
        link = button(WirelessUiLayout.LINK_BUTTON, 0, 0, Component.translatable(LANG + "link.link"), b -> link());
        updateButtons();
    }

    private void link() {
        BlockPos selected = nodes.selected();
        if (selected != null) {
            send(new WirelessActionPayload(WirelessActions.Action.USER_LINK, menu.getPos(), Optional.of(selected),
                    password, ""));
        }
    }

    @Override
    protected void onEnter(EditBox box) {
        if (link.active) {
            link();
        }
    }

    private void updateButtons() {
        unlink.active = menu.getView().currentPos().isPresent();
        BlockPos selected = nodes.selected();
        link.active = selected != null && !selected.equals(menu.getView().currentPos().orElse(null));
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateButtons();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (nodes.mouseClicked(mouseX, mouseY)) {
            updateButtons();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return nodes.mouseScrolled(mouseX, mouseY, scrollY) || super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        WirelessView view = menu.getView();
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, leftPos, topPos, imageWidth, imageHeight);
        text(graphics, Component.literal(fit(title.getString(), imageWidth - 16)), 8, 8, TechUiLayout.TEXT);
        Component linked;
        if (view.currentPos().isEmpty()) {
            linked = Component.translatable(LANG + "link.not_linked");
        } else {
            BlockPos p = view.currentPos().get();
            String name = view.current().isEmpty() ? "?" : view.current();
            linked = Component.translatable(LANG + "link.linked", name, p.getX() + ", " + p.getY() + ", " + p.getZ());
        }
        text(graphics, Component.literal(fit(linked.getString(), imageWidth - 16)), 8, 22,
                view.currentPos().isEmpty() ? DIM : OK_COLOR);
        text(graphics, Component.translatable(LANG + "link.in_range", (int) WirelessUiLayout.LINK_RADIUS), 8,
                WirelessUiLayout.LINK_LIST.y() - 11, TechUiLayout.TEXT);
        nodes.render(graphics, mouseX, mouseY, Component.translatable(LANG + "link.none_in_range"), new RowText() {
            @Override
            public String left(WirelessView.Entry e) {
                return e.name() + " " + TIERS[Math.max(0, Math.min(3, e.tier()))];
            }

            @Override
            public String right(WirelessView.Entry e) {
                return e.load() + "/" + e.max() + "  " + e.distance() + "m";
            }
        });
        text(graphics, Component.translatable(LANG + "password_short"), 8,
                WirelessUiLayout.LINK_PASSWORD_FIELD.y() + 2, TechUiLayout.TEXT);
        fieldFrame(graphics, 0, 0, WirelessUiLayout.LINK_PASSWORD_FIELD);
        renderResult(graphics, WirelessUiLayout.LINK_MESSAGE);
        AcStyle.end();
    }
}
