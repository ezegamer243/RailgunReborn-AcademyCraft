package com.railgunreborn.client.screen.developer;

import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopSession;

import net.minecraft.resources.ResourceLocation;

/**
 * Lo que el árbol necesita de un Developer abierto, sin depender de {@code DeveloperMenu}: así el mismo
 * {@link SkillTreeView} sirve en modo consulta (app "Skill Tree" del Terminal, T22c) pasando null.
 */
public interface DevelopLink {
    DevelopSession.State state();

    /** Progreso 0..1 del desarrollo en curso o del último. */
    float progress();

    DevelopResult result();

    /** Contador de intentos del servidor: cambia cuando una petición tiene respuesta (aceptada o rechazada). */
    int attempt();

    /** Pide aprender {@code skill}. */
    void startSkill(ResourceLocation skill);

    /** Pide obtener categoría (sin categoría) o subir de nivel. */
    void startLevel();

    /** Pide obtener {@code category} gastando un Induction Factor de ella. */
    void startCategory(ResourceLocation category);

    /** Pide abortar el desarrollo en curso. */
    void abort();

    /** IF que tiene ahora el Developer (buffer del bloque o batería del portátil). */
    default int energy() {
        return 0;
    }

    /** Si el servidor exige energía; si no, el desarrollo es gratis y no se muestra coste. */
    default boolean energyRequired() {
        return false;
    }

    default boolean isDeveloping() {
        return state() == DevelopSession.State.DEVELOPING;
    }
}
