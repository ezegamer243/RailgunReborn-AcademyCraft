package com.railgunreborn.client.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.client.hud.HudGlow;
import com.railgunreborn.network.EditPresetSlotPayload;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Pantalla "Preset Edit" (tecla N), port de {@code PresetEditUI}. Medidas en px de GUI según
 * {@code docs/spec/preset-gui.md} sección 1. Siempre lee la copia sincronizada de {@link PresetData}: cada edición
 * se manda al servidor y se ve cuando vuelve el sync (si se rechaza, no cambia nada).
 */
public class PresetEditScreen extends Screen {
    private static final float PAGE_W = 116.25f;
    private static final float PAGE_H = 141.5f;
    private static final float PAGE_SPACING = 125f;
    private static final float INACTIVE_SCALE = 0.8f;
    private static final float INACTIVE_ALPHA = 0.3f;
    private static final long TRANSITION_MS = 350L;

    private static final float ROW_X = 3.625f;
    private static final float ROW_W = 110f;
    private static final float ROW_H = 34.75f;
    private static final float[] ROW_Y = {1.5f, 36.25f, 71.0f, 105.75f};
    private static final float ICON_X = 2.25f;
    private static final float ICON_Y = 3.75f;
    private static final float ICON_SIZE = 26.5f;
    private static final float NAME_X = 36.25f;
    private static final float NAME_Y = 10f;
    private static final float NAME_W = 62.5f;
    private static final float NAME_H = 15f;
    private static final int SKILL_ICON_TEX = 32;

    private static final int SEL_COLUMNS = 4;
    private static final int SEL_ITEM = 15;
    private static final int SEL_STEP = 18;
    private static final float SEL_MARGIN = 2.5f;
    private static final int SEL_BG = 0xC8313131; // rgb(49,49,49), alfa 200
    private static final int SEL_GLOW = 0x99FFFFFF; // blanco alfa 0.6
    private static final int LABEL_GLOW = 0x33FFFFFF; // blanco alfa 0.2
    private static final int HOVER_TINT = 0x33FFFFFF;
    private static final int LABEL_COLOR = 0xBBBBBB;

    private static final ResourceLocation BACK = tex("back");
    private static final ResourceLocation SELECTED = tex("selected");
    private static final ResourceLocation CANCEL = tex("cancel");

    /** Página que se edita (no es el preset activo del jugador). */
    private int activePage;
    private int transitionFrom;
    private long transitionStart = -1;
    @Nullable
    private Selector selector;

    public PresetEditScreen(int initialPage) {
        super(Component.translatable("railgunreborn.gui.preset_edit.name"));
        this.activePage = Math.clamp(initialPage, 0, PresetData.MAX_PRESETS - 1);
        this.transitionFrom = activePage;
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                "textures/gui/preset_settings/" + name + ".png");
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        // Si pierde la categoría con la pantalla abierta (comando, muerte...), ya no hay nada que editar.
        LocalPlayer player = minecraft == null ? null : minecraft.player;
        if (player == null || !AbilityData.get(player).hasCategory()) {
            onClose();
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (minecraft != null && minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // --- Dibujo ---

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Velo negro 0.7 en lugar del desenfoque de vanilla, como el original.
        g.fill(0, 0, width, height, 0xB3000000);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        LocalPlayer player = minecraft == null ? null : minecraft.player;
        if (player == null) {
            return;
        }
        PresetData presets = PresetData.get(player);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        drawText(g, title, 5f, 5f + (18f - 8f * 1.2f) / 2f, 1.2f, 0xFFFFFFFF);

        float t = transitionProgress();
        boolean animating = t < 1f;
        for (int page = 0; page < PresetData.MAX_PRESETS; page++) {
            PageLayout layout = layout(page, t);
            boolean hoverable = page == activePage && !animating && selector == null;
            drawPage(g, presets, page, layout, hoverable ? hoveredRow(layout, mouseX, mouseY) : -1);
        }

        if (selector != null) {
            selector.render(g, mouseX, mouseY);
        }
        g.setColor(1f, 1f, 1f, 1f);
    }

    private void drawPage(GuiGraphics g, PresetData presets, int page, PageLayout layout, int hoveredRow) {
        var pose = g.pose();
        pose.pushPose();
        pose.translate(layout.centerX, layout.centerY, 0);
        pose.scale(layout.scale, layout.scale, 1f);
        pose.translate(-PAGE_W / 2f, -PAGE_H / 2f, 0);

        g.setColor(1f, 1f, 1f, layout.alpha);
        blitStretched(g, BACK, 0f, 0f, PAGE_W, PAGE_H, 465, 566);
        g.setColor(1f, 1f, 1f, 1f);

        int textAlpha = alphaBits(layout.alpha);
        Component tag = Component.translatable("railgunreborn.gui.preset_edit.tag", page + 1);
        float tagWidth = font.width(tag);
        drawText(g, tag, (PAGE_W - tagWidth) / 2f, -15f + (15f - 8f) / 2f, 1f, textAlpha | 0xFFFFFF);

        for (int slot = 0; slot < PresetData.MAX_SLOTS; slot++) {
            float rowY = ROW_Y[slot];
            if (slot == hoveredRow) {
                g.setColor(1f, 1f, 1f, layout.alpha);
                blitStretched(g, SELECTED, ROW_X, rowY, ROW_W, ROW_H, 440, 149);
            }
            ResourceLocation skillId = presets.getSlot(page, slot);
            if (skillId == null) {
                continue;
            }
            Optional<Skill> skill = AbilityRegistries.skill(skillId);
            if (skill.isPresent()) {
                g.setColor(1f, 1f, 1f, layout.alpha);
                blitStretched(g, skill.get().getIcon(), ROW_X + ICON_X, rowY + ICON_Y, ICON_SIZE, ICON_SIZE,
                        SKILL_ICON_TEX, SKILL_ICON_TEX);
            }
            g.setColor(1f, 1f, 1f, 1f);
            Component name = skill.map(Skill::getDisplayName).orElse(Component.literal(skillId.toString()));
            // Escala 1 = tamaño 10 del original; si el nombre no cabe en la caja se encoge.
            float scale = Math.min(1f, NAME_W / Math.max(1, font.width(name)));
            drawText(g, name, ROW_X + NAME_X, rowY + NAME_Y + (NAME_H - 8f * scale) / 2f, scale,
                    textAlpha | 0xFFFFFF);
        }
        g.setColor(1f, 1f, 1f, 1f);
        pose.popPose();
    }

    // --- Entrada ---

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 || transitionProgress() < 1f || minecraft == null || minecraft.player == null) {
            return true;
        }
        if (selector != null) {
            // Con el selector abierto, cualquier clic fuera de él solo lo cierra (filas incluidas).
            if (selector.contains(mouseX, mouseY)) {
                int index = selector.itemAt(mouseX, mouseY);
                if (index >= 0) {
                    selector.apply(index);
                    selector = null;
                }
            } else {
                selector = null;
            }
            return true;
        }
        for (int page = 0; page < PresetData.MAX_PRESETS; page++) {
            int row = hoveredRow(layout(page, 1f), mouseX, mouseY);
            if (row < 0) {
                continue;
            }
            if (page == activePage) {
                selector = new Selector(page, row, (float) mouseX, (float) mouseY);
            } else {
                transitionFrom = activePage;
                activePage = page;
                transitionStart = Util.getMillis();
            }
            return true;
        }
        return true;
    }

    // --- Geometría de páginas ---

    private record PageLayout(float centerX, float centerY, float scale, float alpha) {
    }

    private float transitionProgress() {
        if (transitionStart < 0) {
            return 1f;
        }
        return Math.min(1f, (Util.getMillis() - transitionStart) / (float) TRANSITION_MS);
    }

    /** Posición de una página con el progreso {@code t} de la animación entre transitionFrom y activePage. */
    private PageLayout layout(int page, float t) {
        float oldX = PAGE_SPACING * (page - transitionFrom);
        float newX = PAGE_SPACING * (page - activePage);
        float x = oldX + (newX - oldX) * t;
        float scale;
        float alpha;
        if (page == activePage && page == transitionFrom) {
            scale = 1f;
            alpha = 1f;
        } else if (page == activePage) {
            scale = INACTIVE_SCALE + (1f - INACTIVE_SCALE) * t;
            alpha = INACTIVE_ALPHA + (1f - INACTIVE_ALPHA) * t;
        } else if (page == transitionFrom) {
            scale = 1f - (1f - INACTIVE_SCALE) * t;
            alpha = 1f - (1f - INACTIVE_ALPHA) * t;
        } else {
            scale = INACTIVE_SCALE;
            alpha = INACTIVE_ALPHA;
        }
        // El original centra el panel ya escalado (alineación centro de CGUI), así que el pivote es el centro.
        return new PageLayout(width / 2f + x, height / 2f, scale, alpha);
    }

    /** Fila bajo el ratón en esa página, o -1. */
    private static int hoveredRow(PageLayout layout, double mouseX, double mouseY) {
        double localX = (mouseX - layout.centerX) / layout.scale + PAGE_W / 2f;
        double localY = (mouseY - layout.centerY) / layout.scale + PAGE_H / 2f;
        if (localX < ROW_X || localX >= ROW_X + ROW_W) {
            return -1;
        }
        for (int slot = 0; slot < ROW_Y.length; slot++) {
            if (localY >= ROW_Y[slot] && localY < ROW_Y[slot] + ROW_H) {
                return slot;
            }
        }
        return -1;
    }

    // --- Selector flotante ---

    /** Rejilla de habilidades para una ranura. El elemento 0 es "quitar"; los demás son habilidades. */
    private final class Selector {
        private final int page;
        private final int slot;
        private final float x;
        private final float y;
        private final List<Skill> skills;
        private final int width;
        private final int height;

        Selector(int page, int slot, float mouseX, float mouseY) {
            this.page = page;
            this.slot = slot;
            this.skills = availableSkills(page);
            int items = skills.size() + 1;
            int columns = Math.min(SEL_COLUMNS, items);
            int rows = (items + SEL_COLUMNS - 1) / SEL_COLUMNS;
            this.width = 5 + SEL_ITEM + SEL_STEP * (columns - 1);
            this.height = 5 + SEL_ITEM + SEL_STEP * (rows - 1);
            // Esquina superior izquierda en el ratón, como el original; se recoloca solo si se saldría de pantalla.
            float maxX = PresetEditScreen.this.width - width - 1f;
            float maxY = PresetEditScreen.this.height - height - 1f;
            this.x = Math.max(1f, Math.min(mouseX, maxX));
            this.y = Math.max(15f, Math.min(mouseY, maxY));
        }

        boolean contains(double mx, double my) {
            return mx >= x && mx < x + width && my >= y && my < y + height;
        }

        int itemAt(double mx, double my) {
            int items = skills.size() + 1;
            for (int i = 0; i < items; i++) {
                float ix = x + SEL_MARGIN + SEL_STEP * (i % SEL_COLUMNS);
                float iy = y + SEL_MARGIN + SEL_STEP * (i / SEL_COLUMNS);
                if (mx >= ix && mx < ix + SEL_ITEM && my >= iy && my < iy + SEL_ITEM) {
                    return i;
                }
            }
            return -1;
        }

        void apply(int index) {
            Optional<ResourceLocation> skill = index == 0
                    ? Optional.empty()
                    : Optional.of(skills.get(index - 1).getId());
            PacketDistributor.sendToServer(new EditPresetSlotPayload(page, slot, skill));
        }

        void render(GuiGraphics g, int mouseX, int mouseY) {
            var pose = g.pose();
            pose.pushPose();
            pose.translate(x, y, 200);

            fillF(g, 0f, 0f, width, height, SEL_BG);
            HudGlow.glow(g, 0, 0, width, height, 1, SEL_GLOW);
            g.flush();

            int hovered = itemAt(mouseX, mouseY);
            for (int i = 0; i < skills.size() + 1; i++) {
                float ix = SEL_MARGIN + SEL_STEP * (i % SEL_COLUMNS);
                float iy = SEL_MARGIN + SEL_STEP * (i / SEL_COLUMNS);
                if (i == 0) {
                    blitStretched(g, CANCEL, ix, iy, SEL_ITEM, SEL_ITEM, 23, 23);
                } else {
                    blitStretched(g, skills.get(i - 1).getIcon(), ix, iy, SEL_ITEM, SEL_ITEM, SKILL_ICON_TEX,
                            SKILL_ICON_TEX);
                }
                if (i == hovered) {
                    fillF(g, ix, iy, ix + SEL_ITEM, iy + SEL_ITEM, HOVER_TINT);
                }
            }

            // Etiqueta encima del selector con lo que hay bajo el ratón.
            Component label;
            if (hovered == 0) {
                label = Component.translatable("railgunreborn.gui.preset_edit.skill_remove");
            } else if (hovered > 0) {
                label = skills.get(hovered - 1).getDisplayName();
            } else {
                label = Component.translatable("railgunreborn.gui.preset_edit.skill_select");
            }
            int labelWidth = Math.round(font.width(label) * 0.9f + 6f);
            pose.translate(0, -13.5f, 0);
            fillF(g, 0f, 0f, labelWidth, 11.5f, SEL_BG);
            HudGlow.glow(g, 0, 0, labelWidth, 12, 1, LABEL_GLOW);
            g.flush();
            drawText(g, label, 3f, (11.5f - 8f * 0.9f) / 2f, 0.9f, 0xFF000000 | LABEL_COLOR);
            pose.popPose();
        }
    }

    /** Controlables y aprendidas de la categoría del jugador (orden del registro), sin las que ya están en el preset. */
    private List<Skill> availableSkills(int page) {
        List<Skill> out = new ArrayList<>();
        LocalPlayer player = minecraft == null ? null : minecraft.player;
        if (player == null) {
            return out;
        }
        AbilityData ability = AbilityData.get(player);
        Optional<Category> category = AbilityRegistries.category(ability.getCategory().orElse(null));
        if (category.isEmpty()) {
            return out;
        }
        PresetData presets = PresetData.get(player);
        for (Skill skill : category.get().getSkills()) {
            ResourceLocation id = skill.getId();
            if (!skill.canControl() || !ability.isLearned(id) || inPreset(presets, page, id)) {
                continue;
            }
            out.add(skill);
        }
        return out;
    }

    private static boolean inPreset(PresetData presets, int page, ResourceLocation id) {
        for (int slot = 0; slot < PresetData.MAX_SLOTS; slot++) {
            if (id.equals(presets.getSlot(page, slot))) {
                return true;
            }
        }
        return false;
    }

    // --- Utilidades de dibujo ---

    private static int alphaBits(float alpha) {
        // La fuente trata alfa < 4 como opaco: se fuerza un mínimo.
        return Math.max(4, Math.round(alpha * 255f)) << 24;
    }

    private void drawText(GuiGraphics g, Component text, float x, float y, float scale, int argb) {
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, argb, false);
        pose.popPose();
    }

    /** Dibuja la textura entera estirada a un rectángulo con coordenadas fraccionarias. */
    private static void blitStretched(GuiGraphics g, ResourceLocation texture, float x, float y, float w, float h,
            int texW, int texH) {
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(w / texW, h / texH, 1f);
        g.blit(texture, 0, 0, 0, 0, texW, texH, texW, texH);
        pose.popPose();
    }

    /** Como {@link GuiGraphics#fill} pero con coordenadas fraccionarias. Se vuelca al momento para respetar el orden. */
    private static void fillF(GuiGraphics g, float x1, float y1, float x2, float y2, int argb) {
        Matrix4f m = g.pose().last().pose();
        VertexConsumer buf = g.bufferSource().getBuffer(RenderType.gui());
        buf.addVertex(m, x1, y1, 0).setColor(argb);
        buf.addVertex(m, x1, y2, 0).setColor(argb);
        buf.addVertex(m, x2, y2, 0).setColor(argb);
        buf.addVertex(m, x2, y1, 0).setColor(argb);
        g.flush();
    }
}
