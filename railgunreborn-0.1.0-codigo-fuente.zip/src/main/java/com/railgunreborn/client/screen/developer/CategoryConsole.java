package com.railgunreborn.client.screen.developer;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

import javax.annotation.Nullable;

import org.lwjgl.glfw.GLFW;

import com.railgunreborn.ability.develop.CategoryLookup;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.client.screen.developer.DevelopTracker.Phase;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;

import net.minecraft.Util;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringUtil;

/**
 * Consola "Academy OS" del área del árbol cuando el jugador no tiene categoría ({@code developer.md} 3.8): arranque
 * con efecto de máquina de escribir que termina en "categoría inválida" y, con Developer, un prompt donde
 * {@code learn} + Enter pide obtener categoría y muestra el progreso. Al terminar con éxito avisa a la vista
 * ({@link #isFinished()}) para que pase al árbol.
 */
final class CategoryConsole {
    static final float LINE_HEIGHT = 10f;
    static final float MARGIN = 5f;
    static final float TEXT_SCALE = 0.8f;
    private static final int MAX_LINES = 10;
    private static final long CHAR_MS = 10L;
    private static final long CURSOR_BLINK_MS = 500L;
    private static final int MAX_INPUT = 32;
    private static final String PROMPT = "OS > ";

    private final SkillTreeView view;
    @Nullable
    private final DevelopTracker tracker;
    private final int wrapWidth;
    private final RandomSource random = RandomSource.create();

    private final List<String> lines = new ArrayList<>();
    private final Deque<Step> steps = new ArrayDeque<>();
    private long stepStart = -1;
    private boolean prompt;
    private final StringBuilder input = new StringBuilder();
    /** {@code learn} en curso (desde Enter hasta el final): la vista no debe quitar la consola. */
    private boolean learning;
    private boolean finished;

    /**
     * @param width ancho útil del área en unidades del original
     */
    CategoryConsole(SkillTreeView view, float width) {
        this.view = view;
        DevelopLink link = view.link();
        this.tracker = link == null ? null : new DevelopTracker(link);
        this.wrapWidth = (int) ((width - 2 * MARGIN) / TEXT_SCALE);
        boot();
    }

    // --- Secuencias ---

    private void boot() {
        type(tr("railgunreborn.developer.console.welcome"));
        type(tr("railgunreborn.developer.console.copyright"));
        type(Component.translatable("railgunreborn.developer.console.user_detected",
                view.player().getName()).getString());
        pause(400);
        // Porcentajes de arranque que se sustituyen en la misma línea y se quedan en 64-67 %.
        instant(() -> lines.add(""));
        for (int i = 1; i <= 6; i++) {
            int value = i * 10 + random.nextIntBetweenInclusive(-3, 3);
            instant(() -> setLast(value + "%"));
            pause(300);
        }
        int last = random.nextIntBetweenInclusive(64, 67);
        instant(() -> setLast(last + "%"));
        pause(300);
        type(tr("railgunreborn.developer.console.boot_failed"));
        type(tr("railgunreborn.developer.console.invalid_cat"));
        if (tracker != null) {
            type(tr("railgunreborn.developer.console.learn_hint"));
            instant(() -> prompt = true);
        }
    }

    private void execute(String raw) {
        lines.add(PROMPT + raw);
        String command = CategoryLookup.normalize(raw);
        if (command.isEmpty()) {
            return;
        }
        prompt = false;
        switch (command) {
            case "learn" -> startLearn(null);
            case "help" -> type(tr("railgunreborn.developer.console.help"));
            case "clear" -> instant(lines::clear);
            default -> CategoryLookup.byName(command).ifPresentOrElse(this::learnWithFactor,
                    () -> type(tr("railgunreborn.developer.console.invalid_command")));
        }
        if (!learning) {
            instant(() -> prompt = true);
        }
    }

    /** El servidor vuelve a comprobar el inventario; esto solo evita un viaje y da el mensaje de error al momento. */
    private void learnWithFactor(ResourceLocation category) {
        if (tracker == null || view.link() == null) {
            return;
        }
        if (InductionFactorItem.has(view.player(), category)) {
            startLearn(category);
        } else {
            type(tr("railgunreborn.developer.console.no_factor"));
        }
    }

    /** @param category null = {@code learn} (categoría al azar); si no, la de un Induction Factor que se gasta */
    private void startLearn(@Nullable ResourceLocation category) {
        DevelopTracker t = tracker;
        DevelopLink link = view.link();
        if (t == null || link == null) {
            return;
        }
        learning = true;
        type(tr("railgunreborn.developer.console.dev_begin"));
        instant(() -> {
            lines.add(progressLine(0f));
            t.send(category == null ? link::startLevel : () -> link.startCategory(category));
        });
        // Actualiza el porcentaje en su línea cada fotograma; al terminar encola el final.
        steps.add(elapsed -> {
            Phase phase = t.phase();
            setLast(progressLine(t.progress()));
            if (phase == Phase.DONE) {
                type(tr("railgunreborn.developer.console.dev_succ"));
                pause(500);
                instant(() -> finished = true);
                return true;
            }
            if (phase == Phase.FAILED || phase == Phase.NONE) {
                type(tr("railgunreborn.developer.console.dev_fail"));
                DevelopResult result = t.result();
                if (phase == Phase.FAILED && result != DevelopResult.NONE) {
                    type(tr(result.translationKey()));
                }
                instant(() -> {
                    learning = false;
                    prompt = true;
                });
                return true;
            }
            return false;
        });
    }

    private static String progressLine(float progress) {
        int percent = Math.min(99, (int) (progress * 100f));
        if (progress >= 1f) {
            percent = 100;
        }
        return Component.translatable("railgunreborn.developer.console.progress",
                String.format(Locale.ROOT, "%02d", percent)).getString();
    }

    // --- Pasos ---

    @FunctionalInterface
    private interface Step {
        /** @return true cuando el paso terminó */
        boolean run(long elapsedMs);
    }

    /** Escribe {@code text} con efecto de máquina de escribir, partido en líneas que quepan en el área. */
    private void type(String text) {
        for (FormattedText part : view.font().getSplitter().splitLines(text, wrapWidth, Style.EMPTY)) {
            String line = part.getString();
            boolean[] started = {false};
            steps.add(elapsed -> {
                if (!started[0]) {
                    started[0] = true;
                    lines.add("");
                }
                int chars = (int) Math.min(line.length(), elapsed / CHAR_MS);
                setLast(line.substring(0, chars));
                return chars >= line.length();
            });
        }
    }

    private void pause(long ms) {
        steps.add(elapsed -> elapsed >= ms);
    }

    private void instant(Runnable action) {
        steps.add(elapsed -> {
            action.run();
            return true;
        });
    }

    private void setLast(String text) {
        if (lines.isEmpty()) {
            lines.add(text);
        } else {
            lines.set(lines.size() - 1, text);
        }
    }

    private void advance() {
        long now = Util.getMillis();
        // Varios pasos pueden terminar en el mismo fotograma (los instantáneos, o un tirón de FPS).
        for (int guard = 0; guard < 64 && !steps.isEmpty(); guard++) {
            if (stepStart < 0) {
                stepStart = now;
            }
            if (!steps.peekFirst().run(now - stepStart)) {
                return;
            }
            steps.pollFirst();
            stepStart = -1;
        }
    }

    private static String tr(String key) {
        return Component.translatable(key).getString();
    }

    // --- Estado para la vista ---

    /** {@code learn} terminó con éxito y pasó la pausa final: la vista debe mostrar el árbol. */
    boolean isFinished() {
        return finished;
    }

    /** Mientras {@code learn} está en curso la vista mantiene la consola aunque ya llegue la categoría. */
    boolean isHolding() {
        return learning && !finished;
    }

    /** Hay prompt (con Developer): las teclas van a la consola y no cierran la pantalla (salvo ESC). */
    boolean capturesKeys() {
        return tracker != null;
    }

    // --- Dibujo ---

    void render(GuiGraphics g, float x, float y) {
        advance();
        List<String> shown = new ArrayList<>(lines);
        if (prompt) {
            boolean cursor = (Util.getMillis() / CURSOR_BLINK_MS) % 2 == 0;
            shown.add(PROMPT + input + (cursor ? "_" : ""));
        }
        int from = Math.max(0, shown.size() - MAX_LINES);
        Font font = view.font();
        for (int i = from; i < shown.size(); i++) {
            TreeDraw.text(g, font, Component.literal(shown.get(i)), x + MARGIN,
                    y + MARGIN + (i - from) * LINE_HEIGHT, TEXT_SCALE, 0xFFFFFFFF, Align.LEFT);
        }
    }

    // --- Entrada ---

    boolean keyPressed(int keyCode) {
        if (!prompt) {
            return true;
        }
        switch (keyCode) {
            case GLFW.GLFW_KEY_BACKSPACE -> {
                if (!input.isEmpty()) {
                    input.setLength(input.length() - 1);
                }
            }
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                String raw = input.toString();
                input.setLength(0);
                execute(raw);
            }
            default -> {
            }
        }
        return true;
    }

    boolean charTyped(char c) {
        if (prompt && input.length() < MAX_INPUT && StringUtil.isAllowedChatCharacter(c)) {
            input.append(c);
        }
        return true;
    }
}
