package com.railgunreborn.client.screen.wireless;

import static com.railgunreborn.wireless.WirelessUiLayout.SIDE_X;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.block.TechUiLayout.Rect;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.NodeMenu;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessUiLayout;
import com.railgunreborn.wireless.WirelessView;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla del nodo: a la izquierda el arte {@code ui_node} del original con las ranuras IN/OUT y, en el recuadro
 * central, nombre, barra de energía y enlaces; a la derecha nombre y contraseña del nodo, la red actual (con botón
 * para salir) y las redes al alcance para unirse con su contraseña.
 */
public class NodeScreen extends WirelessScreen<NodeMenu> {
    private static final ResourceLocation ART = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/wireless/ui_node.png");

    private String name;
    private String password = "";
    private String joinPassword = "";
    private EditBox nameBox;
    private EditBox joinBox;
    private Button save;
    private Button leave;
    private Button join;
    private final EntryList networks = new EntryList(WirelessUiLayout.NODE_LIST, SIDE_X);

    public NodeScreen(NodeMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = WirelessUiLayout.TOTAL_W;
        imageHeight = WirelessUiLayout.HEIGHT;
        name = menu.getView().name();
    }

    @Override
    protected void init() {
        super.init();
        nameBox = field(WirelessUiLayout.NODE_NAME_FIELD, SIDE_X, 0, name, NodeBlockEntity.MAX_NAME_LENGTH, false,
                "name_hint", s -> name = s);
        field(WirelessUiLayout.NODE_PASSWORD_FIELD, SIDE_X, 0, password, WirelessNetwork.MAX_PASSWORD_LENGTH, true,
                "password_keep_hint", s -> password = s);
        joinBox = field(WirelessUiLayout.NODE_JOIN_PASSWORD_FIELD, SIDE_X, 0, joinPassword,
                WirelessNetwork.MAX_PASSWORD_LENGTH, true, "password_hint", s -> joinPassword = s);
        save = button(WirelessUiLayout.NODE_SAVE_BUTTON, SIDE_X, 0, Component.translatable(LANG + "save"),
                b -> save());
        leave = button(WirelessUiLayout.NODE_LEAVE_BUTTON, SIDE_X, 0, Component.translatable(LANG + "node.leave"),
                b -> send(new WirelessActionPayload(WirelessActions.Action.NODE_LEAVE, menu.getPos())));
        join = button(WirelessUiLayout.NODE_JOIN_BUTTON, SIDE_X, 0, Component.translatable(LANG + "node.join"),
                b -> join());
        updateButtons();
    }

    private void save() {
        send(new WirelessActionPayload(WirelessActions.Action.NODE_CONFIGURE, menu.getPos(), Optional.empty(), name,
                password));
    }

    private void join() {
        BlockPos selected = networks.selected();
        if (selected != null) {
            send(new WirelessActionPayload(WirelessActions.Action.NODE_JOIN, menu.getPos(), Optional.of(selected),
                    joinPassword, ""));
        }
    }

    @Override
    protected void onEnter(EditBox box) {
        if (box == joinBox) {
            if (join.active) {
                join();
            }
        } else if (save.active) {
            save();
        }
    }

    private void updateButtons() {
        boolean canEdit = menu.getView().canEdit();
        save.active = canEdit && !name.isBlank();
        leave.active = canEdit && !menu.getView().current().isEmpty();
        BlockPos selected = networks.selected();
        join.active = canEdit && selected != null
                && !selected.equals(menu.getView().currentPos().orElse(null));
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateButtons();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (networks.mouseClicked(mouseX, mouseY)) {
            updateButtons();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return networks.mouseScrolled(mouseX, mouseY, scrollY) || super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        WirelessView view = menu.getView();
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, WirelessUiLayout.MAIN_W, imageHeight);
        AcStyle.panel(graphics, BACKGROUND, x + SIDE_X, y, WirelessUiLayout.SIDE_W, imageHeight);
        AcStyle.pushArtSpace(graphics, x, y);
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, ART);
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);

        // Recuadro central: nombre, energía, enlaces.
        Rect box = WirelessUiLayout.NODE_CENTER_BOX;
        String shownName = fit(view.name(), box.w() - 8);
        text(graphics, Component.literal(shownName), box.x() + box.w() / 2 - font.width(shownName) / 2, box.y() + 5,
                TechUiLayout.TEXT);
        Rect bar = WirelessUiLayout.NODE_ENERGY_BAR;
        AcStyle.energyBar(graphics, new Rect(x + bar.x(), y + bar.y(), bar.w(), bar.h()),
                EnergyMath.fill(menu.getEnergy(), menu.getCapacity()));
        Component links = Component.translatable(LANG + "node.links", view.load(), view.max());
        text(graphics, links, box.x() + box.w() / 2 - font.width(links) / 2, bar.y() + bar.h() + 4, DIM);

        int sx = SIDE_X + 8;
        text(graphics, Component.translatable(LANG + "name"), sx, WirelessUiLayout.NODE_NAME_FIELD.y() + 2,
                TechUiLayout.TEXT);
        text(graphics, Component.translatable(LANG + "password_short"), sx, WirelessUiLayout.NODE_PASSWORD_FIELD.y() + 2,
                TechUiLayout.TEXT);
        fieldFrame(graphics, SIDE_X, 0, WirelessUiLayout.NODE_NAME_FIELD);
        fieldFrame(graphics, SIDE_X, 0, WirelessUiLayout.NODE_PASSWORD_FIELD);
        Rect saveRect = WirelessUiLayout.NODE_SAVE_BUTTON;
        String owner = view.owner().isEmpty() ? "-" : view.owner();
        text(graphics, Component.literal(fit(Component.translatable(LANG + "owner", owner).getString(), 70)),
                SIDE_X + saveRect.x() + saveRect.w() + 6, saveRect.y() + 3, DIM);

        Rect leaveRect = WirelessUiLayout.NODE_LEAVE_BUTTON;
        Component network = view.current().isEmpty() ? Component.translatable(LANG + "node.no_network")
                : Component.translatable(LANG + "node.network", view.current());
        text(graphics, Component.literal(fit(network.getString(), leaveRect.x() - 12)), sx, leaveRect.y() + 3,
                view.current().isEmpty() ? DIM : OK_COLOR);
        text(graphics, Component.translatable(LANG + "node.in_range"), sx, WirelessUiLayout.NODE_LIST.y() - 11,
                TechUiLayout.TEXT);
        networks.render(graphics, mouseX, mouseY, Component.translatable(LANG + "node.none_in_range"),
                new RowText() {
                    @Override
                    public String left(WirelessView.Entry e) {
                        return e.name();
                    }

                    @Override
                    public String right(WirelessView.Entry e) {
                        return e.load() + "/" + e.max() + "  " + e.distance() + "m";
                    }
                });
        text(graphics, Component.translatable(LANG + "password_short"), sx, WirelessUiLayout.NODE_JOIN_PASSWORD_FIELD.y() + 2,
                TechUiLayout.TEXT);
        fieldFrame(graphics, SIDE_X, 0, WirelessUiLayout.NODE_JOIN_PASSWORD_FIELD);
        renderResult(graphics, WirelessUiLayout.NODE_MESSAGE);
        AcStyle.end();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        Rect bar = WirelessUiLayout.NODE_ENERGY_BAR;
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (rx >= bar.x() && rx < bar.x() + bar.w() && ry >= bar.y() - 1 && ry < bar.y() + bar.h() + 1) {
            graphics.renderTooltip(font, Component.literal(EnergyFormat.fraction(menu.getEnergy(),
                    menu.getCapacity())), mouseX, mouseY);
        }
    }
}
