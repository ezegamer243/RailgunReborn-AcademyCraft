package com.railgunreborn.client.screen.developer;

import com.railgunreborn.ability.develop.DevelopResult;

import net.minecraft.Util;

/**
 * Sigue una petición concreta hecha desde un panel o la consola: hasta que el servidor responde (cambia el contador
 * de intentos) el estado del menú es el del intento anterior y no se debe mostrar.
 */
final class DevelopTracker {
    /** Si el servidor no responde (no debería pasar), se vuelve a dejar pedir. */
    private static final long TIMEOUT_MS = 5000L;

    enum Phase {
        /** Aún no se pidió nada desde aquí. */
        NONE,
        /** Enviado, sin respuesta todavía. */
        WAITING,
        DEVELOPING,
        DONE,
        /** Rechazado al empezar, fallido al terminar o abortado: ver {@link #result()}. */
        FAILED
    }

    private final DevelopLink link;
    private boolean sent;
    private int sentAttempt;
    private long sentTime;

    DevelopTracker(DevelopLink link) {
        this.link = link;
    }

    void send(Runnable request) {
        sent = true;
        sentAttempt = link.attempt();
        sentTime = Util.getMillis();
        request.run();
    }

    Phase phase() {
        if (!sent) {
            return Phase.NONE;
        }
        if (link.attempt() == sentAttempt) {
            if (Util.getMillis() - sentTime > TIMEOUT_MS) {
                sent = false;
                return Phase.NONE;
            }
            return Phase.WAITING;
        }
        return switch (link.state()) {
            case DEVELOPING -> Phase.DEVELOPING;
            case DONE -> Phase.DONE;
            // IDLE tras responder = abortado.
            case FAILED, IDLE -> Phase.FAILED;
        };
    }

    /** Ocupado: no se puede pedir otra cosa ni cerrar el panel con clic. */
    boolean isBusy() {
        Phase p = phase();
        return p == Phase.WAITING || p == Phase.DEVELOPING;
    }

    float progress() {
        return switch (phase()) {
            case DEVELOPING -> link.progress();
            case DONE -> 1f;
            default -> 0f;
        };
    }

    DevelopResult result() {
        return link.result();
    }

    void abort() {
        if (phase() == Phase.DEVELOPING) {
            link.abort();
        }
    }
}
