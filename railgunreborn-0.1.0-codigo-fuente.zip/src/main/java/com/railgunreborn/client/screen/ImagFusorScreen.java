package com.railgunreborn.client.screen;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.block.ImagFusorMenu;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla del Imag Fusor con el arte del original (fondo, máquina y logo) en el estilo de {@link AcStyle}. El
 * recuadro de arriba es el depósito de líquido de fase (barra + mB + marca de lo que pide la receta); el del centro,
 * la barra de progreso. El inventario usa una cuadrícula propia alineada con las ranuras.
 */
public class ImagFusorScreen extends AbstractContainerScreen<ImagFusorMenu> {
    private static final ResourceLocation BACKGROUND = tex("background");
    private static final ResourceLocation INVENTORY = tex("inventory");
    private static final ResourceLocation OVERLAY = tex("overlay");
    private static final ResourceLocation PROGRESS = tex("progress");

    public ImagFusorScreen(ImagFusorMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/imag_fusor/" + name + ".png");
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        renderMachineTooltips(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        AcStyle.pushArtSpace(graphics, x, y);
        // El líquido va debajo del arte: así el marco y la gota del recuadro quedan por encima.
        int amount = menu.getTankAmount();
        int fill = Math.round(TechUiLayout.TANK_UW * Math.min(1f, amount / (float) ImagFusorBlockEntity.TANK_CAPACITY));
        if (fill > 0) {
            graphics.fill(TechUiLayout.TANK_U, TechUiLayout.TANK_V, TechUiLayout.TANK_U + fill,
                    TechUiLayout.TANK_V + TechUiLayout.TANK_VH, TechUiLayout.TANK_FILL);
        }
        int needed = menu.getNeeded();
        if (needed > 0) {
            int mark = TechUiLayout.TANK_U + Math.round(TechUiLayout.TANK_UW
                    * Math.min(1f, needed / (float) ImagFusorBlockEntity.TANK_CAPACITY)) - 2;
            graphics.fill(mark, TechUiLayout.TANK_V, mark + 2, TechUiLayout.TANK_V + TechUiLayout.TANK_VH,
                    TechUiLayout.NEEDED_MARK);
        }
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, OVERLAY);
        AcStyle.blit(graphics, INVENTORY, TechUiLayout.LOGO_U, TechUiLayout.LOGO_V, TechUiLayout.LOGO_U, TechUiLayout.LOGO_V,
                TechUiLayout.LOGO_W, TechUiLayout.LOGO_H, TechUiLayout.TEX_W, TechUiLayout.TEX_H);
        int max = menu.getMaxProgress();
        int progress = menu.getProgress();
        if (max > 0 && progress > 0) {
            int w = Math.round(TechUiLayout.FUSOR_PROGRESS_W * Math.min(1f, progress / (float) max));
            AcStyle.blit(graphics, PROGRESS, TechUiLayout.FUSOR_PROGRESS_U, TechUiLayout.FUSOR_PROGRESS_V, 0, 0, w,
                    TechUiLayout.FUSOR_PROGRESS_H, TechUiLayout.FUSOR_PROGRESS_W, TechUiLayout.FUSOR_PROGRESS_H);
        }
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);

        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);
        AcStyle.energyBar(graphics, bar(), EnergyMath.fill(menu.getEnergy(), ImagFusorBlockEntity.ENERGY_CAPACITY));

        Component label = Component.literal(amount + " mB");
        graphics.drawString(font, label, x + TechUiLayout.TANK_TEXT_CX - font.width(label) / 2,
                y + TechUiLayout.TANK_TEXT_Y, TechUiLayout.TEXT, false);
        AcStyle.end();
    }

    /** Sin títulos vanilla: la textura ya tiene sus rótulos (IN / OUT). */
    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }

    private TechUiLayout.Rect bar() {
        TechUiLayout.Rect b = TechUiLayout.ENERGY_BAR;
        return new TechUiLayout.Rect(leftPos + b.x(), topPos + b.y(), b.w(), b.h());
    }

    private void renderMachineTooltips(GuiGraphics graphics, int mouseX, int mouseY) {
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (rx >= TechUiLayout.TANK_X && rx < TechUiLayout.TANK_X + TechUiLayout.TANK_W && ry >= TechUiLayout.TANK_Y
                && ry < TechUiLayout.TANK_Y + TechUiLayout.TANK_H) {
            List<Component> lines = new ArrayList<>();
            lines.add(Component.translatable("gui.railgunreborn.imag_fusor.tank", menu.getTankAmount(),
                    ImagFusorBlockEntity.TANK_CAPACITY));
            if (menu.getNeeded() > 0) {
                lines.add(Component.translatable("gui.railgunreborn.imag_fusor.needed", menu.getNeeded()));
            }
            graphics.renderComponentTooltip(font, lines, mouseX, mouseY);
        } else if (TechUiLayout.ENERGY_BAR.contains(new TechUiLayout.Rect(rx, ry, 1, 1))) {
            graphics.renderTooltip(font, Component.literal(
                    EnergyFormat.fraction(menu.getEnergy(), ImagFusorBlockEntity.ENERGY_CAPACITY)), mouseX, mouseY);
        } else if (rx >= TechUiLayout.BATTERY_X && rx < TechUiLayout.BATTERY_X + 16 && ry >= TechUiLayout.BATTERY_Y
                && ry < TechUiLayout.BATTERY_Y + 16
                && menu.getCarried().isEmpty() && !menu.slots.get(ImagFusorBlockEntity.SLOT_BATTERY).hasItem()) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.imag_fusor.battery"), mouseX, mouseY);
        }
    }
}
