package com.railgunreborn.client.screen.wireless;

import static com.railgunreborn.wireless.WirelessUiLayout.SIDE_X;

import java.util.Locale;
import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.wireless.MatrixBlockEntity;
import com.railgunreborn.wireless.MatrixMenu;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessUiLayout;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla de la matriz: a la izquierda el arte {@code ui_matrix} del original con las 3 placas y el núcleo; a la
 * derecha nivel, nodos usados/máximo, ancho de banda, alcance y dueño, y los campos SSID y contraseña con el botón
 * para crear o actualizar la red (solo el dueño u operadores; el servidor lo vuelve a comprobar).
 */
public class MatrixScreen extends WirelessScreen<MatrixMenu> {
    private static final ResourceLocation ART = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/wireless/ui_matrix.png");

    private String ssid;
    private String password = "";
    private Button apply;

    public MatrixScreen(MatrixMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = WirelessUiLayout.TOTAL_W;
        imageHeight = WirelessUiLayout.HEIGHT;
        ssid = menu.getView().name();
    }

    @Override
    protected void init() {
        super.init();
        field(WirelessUiLayout.MATRIX_SSID_FIELD, SIDE_X, 0, ssid, WirelessNetwork.MAX_SSID_LENGTH, false,
                "ssid_hint", s -> ssid = s);
        field(WirelessUiLayout.MATRIX_PASSWORD_FIELD, SIDE_X, 0, password, WirelessNetwork.MAX_PASSWORD_LENGTH, true,
                "password_hint", s -> password = s);
        apply = button(WirelessUiLayout.MATRIX_BUTTON, SIDE_X, 0, Component.empty(), b -> submit());
        updateButton();
    }

    private void submit() {
        send(new WirelessActionPayload(WirelessActions.Action.MATRIX_CONFIGURE, menu.getPos(), Optional.empty(),
                ssid, password));
    }

    @Override
    protected void onEnter(EditBox box) {
        if (apply.active) {
            submit();
        }
    }

    private void updateButton() {
        apply.setMessage(Component.translatable(LANG + (menu.hasNetwork() ? "matrix.update" : "matrix.create")));
        apply.active = menu.getView().canEdit() && WirelessNetwork.validSsid(ssid);
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateButton();
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, WirelessUiLayout.MAIN_W, imageHeight);
        AcStyle.panel(graphics, BACKGROUND, x + SIDE_X, y, WirelessUiLayout.SIDE_W, imageHeight);
        AcStyle.pushArtSpace(graphics, x, y);
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, ART);
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);

        int sx = SIDE_X + 8;
        int tier = menu.getWorkingTier();
        text(graphics, title, sx, 7, TechUiLayout.TEXT);
        int ly = WirelessUiLayout.MATRIX_INFO_Y + 2;
        if (tier == 0) {
            text(graphics, Component.translatable(LANG + "matrix.not_working", menu.getPlateCount(),
                    MatrixBlockEntity.PLATE_SLOTS), sx, ly, ERROR_COLOR);
        } else {
            text(graphics, Component.translatable(LANG + "matrix.tier", tier), sx, ly, TechUiLayout.TEXT);
        }
        ly += WirelessUiLayout.LINE_H;
        int capacity = tier == 0 ? 0 : MatrixBlockEntity.capacityFor(tier);
        text(graphics, Component.translatable(LANG + "matrix.nodes", menu.getView().load(), capacity), sx, ly,
                TechUiLayout.TEXT);
        ly += WirelessUiLayout.LINE_H;
        text(graphics, Component.translatable(LANG + "matrix.bandwidth",
                EnergyFormat.format(tier == 0 ? 0 : MatrixBlockEntity.bandwidthFor(tier))), sx, ly, TechUiLayout.TEXT);
        ly += WirelessUiLayout.LINE_H;
        text(graphics, Component.translatable(LANG + "matrix.range", String.format(Locale.ROOT, "%.1f",
                tier == 0 ? 0.0 : MatrixBlockEntity.rangeFor(tier))), sx, ly, TechUiLayout.TEXT);
        ly += WirelessUiLayout.LINE_H;
        String owner = menu.getView().owner().isEmpty() ? "-" : menu.getView().owner();
        text(graphics, Component.literal(fit(Component.translatable(LANG + "owner", owner).getString(), 134)), sx, ly,
                TechUiLayout.TEXT);

        text(graphics, Component.translatable(LANG + "ssid"), sx, WirelessUiLayout.MATRIX_SSID_FIELD.y() - 10,
                TechUiLayout.TEXT);
        text(graphics, Component.translatable(LANG + (menu.hasNetwork() ? "password_keep" : "password")), sx,
                WirelessUiLayout.MATRIX_PASSWORD_FIELD.y() - 10, TechUiLayout.TEXT);
        fieldFrame(graphics, SIDE_X, 0, WirelessUiLayout.MATRIX_SSID_FIELD);
        fieldFrame(graphics, SIDE_X, 0, WirelessUiLayout.MATRIX_PASSWORD_FIELD);
        if (!menu.getView().canEdit()) {
            text(graphics, Component.translatable(LANG + "owner_only"), sx, WirelessUiLayout.MATRIX_BUTTON.y() + 22,
                    DIM);
        }
        renderResult(graphics, WirelessUiLayout.MAIN_MESSAGE);
        AcStyle.end();
    }
}
