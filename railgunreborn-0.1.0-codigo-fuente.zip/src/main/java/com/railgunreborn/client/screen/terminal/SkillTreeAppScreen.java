package com.railgunreborn.client.screen.terminal;

import org.lwjgl.glfw.GLFW;

import com.railgunreborn.client.screen.developer.SkillTreeView;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * App "Skill Tree" del Terminal: el árbol de habilidades en modo consulta ({@code developer.md} 3.9), sin Developer
 * ni acciones. Sin categoría, la vista muestra la consola "OS" con "categoría inválida" y sin {@code learn}.
 * ESC vuelve al Terminal.
 */
public class SkillTreeAppScreen extends Screen {
    private final Screen parent;
    private final SkillTreeView view;

    public SkillTreeAppScreen(Screen parent) {
        super(Component.translatable("railgunreborn.terminal.app.skill_tree"));
        this.parent = parent;
        this.view = new SkillTreeView(Minecraft.getInstance().player, null, null);
    }

    @Override
    protected void init() {
        view.resize(width, height);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(g);
        view.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        view.mouseClicked(mouseX, mouseY, button);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode != GLFW.GLFW_KEY_ESCAPE && view.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        return view.charTyped(codePoint, modifiers) || super.charTyped(codePoint, modifiers);
    }

    @Override
    public void onClose() {
        if (minecraft != null) {
            minecraft.setScreen(parent);
        }
    }
}
