package com.railgunreborn.client.screen.developer;

import java.util.List;

import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevCondition;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;
import com.railgunreborn.energy.EnergyFormat;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

/**
 * Panel de detalle al clicar un nodo ({@code developer.md} 3.5): icono grande, nombre y nivel, descripción y, con
 * Developer y sin aprender, requisitos, estado y botón "Aprender" (3.7).
 */
final class SkillDetailOverlay extends ActionOverlay {
    private static final float DESC_WIDTH = 200f;
    private static final float REQ_ICON = 14f;
    private static final float REQ_STEP = 16f;
    private static final int EXP_COLOR = 0xFFA1E1FF;
    private static final int MET_COLOR = 0xEEFFFFFF;
    private static final int UNMET_COLOR = 0xFFEE5858;

    private final Skill skill;
    /**
     * Si estaba aprendida al abrir: tras aprenderla aquí el panel sigue mostrando "Desarrollo completado." hasta
     * cerrarlo (como el original, que reconstruye al cerrar).
     */
    private final boolean learnedAtOpen;

    SkillDetailOverlay(SkillTreeView view, Skill skill) {
        super(view);
        this.skill = skill;
        this.learnedAtOpen = AbilityData.get(view.player()).isLearned(skill.getId());
    }

    @Override
    protected void renderContent(GuiGraphics g, Font font, float lx, float ly, float a) {
        AbilityData data = AbilityData.get(view.player());
        DeveloperType type = view.developerType();
        ResourceLocation id = skill.getId();
        boolean learned = learnedAtOpen;

        ResourceLocation icon = learned ? DeveloperTextures.linear(skill.getIcon())
                : DeveloperTextures.grayscale(skill.getIcon());
        drawActionIcon(g, icon, learned ? skill.getExp(view.player()) : -1f, a);

        float y = TEXT_TOP;
        Component title = Component.translatable("railgunreborn.developer.skill_title", skill.getDisplayName(),
                skill.getLevel()).withStyle(ChatFormatting.BOLD);
        TreeDraw.text(g, font, title, 0f, y, 1.2f, TreeDraw.withAlpha(0xFFFFFF, a), Align.CENTER);
        y += 13f;
        if (learned) {
            Component exp = Component.translatable("railgunreborn.developer.skill_exp",
                    Math.round(skill.getExp(view.player()) * 100f));
            TreeDraw.text(g, font, exp, 0f, y, 0.8f, TreeDraw.withAlpha(EXP_COLOR, a), Align.CENTER);
            y += 9f;
        } else {
            TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.skill_not_learned"), 0f, y, 1f,
                    TreeDraw.withAlpha(ERROR_COLOR, a), Align.CENTER);
            y += 11f;
        }
        List<FormattedCharSequence> desc = font.split(Component.translatable(skill.getDescriptionKey()),
                (int) (DESC_WIDTH / 0.9f));
        for (FormattedCharSequence line : desc) {
            TreeDraw.text(g, font, line, 0f, y, 0.9f, TreeDraw.withAlpha(0xFFFFFF, a), Align.CENTER);
            y += 9f;
        }

        if (!learned && type != null) {
            y += 3f;
            y = drawConditions(g, font, data, type, y, lx, ly, a);
            DevelopResult check = skill.checkLearn(data, type);
            DevelopLink link = view.link();
            Component question = link != null && link.energyRequired()
                    ? Component.translatable("railgunreborn.developer.learn_question_energy",
                            EnergyFormat.number(type.energyForStims(skill.getLearningStims())))
                    : Component.translatable("railgunreborn.developer.learn_question",
                            skill.getLearningStims());
            drawStatus(g, font, y, question, check.isOk() ? null : resultText(check),
                    Component.translatable("railgunreborn.developer.learn"), lx, ly, a);
        }
    }

    @Override
    protected void request(DevelopLink link) {
        link.startSkill(skill.getId());
    }

    @Override
    protected Component resultText(DevelopResult result) {
        if (result == DevelopResult.LEVEL_TOO_LOW) {
            return Component.translatable("railgunreborn.developer.level_fail", skill.getLevel());
        }
        return super.resultText(result);
    }

    /** Fila "Req." + iconos de condición (gris si no se cumple) y, al pasar el ratón, su texto a la derecha. */
    private float drawConditions(GuiGraphics g, Font font, AbilityData data, DeveloperType type, float y, float lx,
            float ly, float a) {
        List<DevCondition> conditions = skill.getDevConditions(data, type);
        if (conditions.isEmpty()) {
            return y;
        }
        float total = REQ_STEP * (conditions.size() - 1) + REQ_ICON;
        float startX = -total / 2f;
        TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.req"), startX - 3f,
                y + (REQ_ICON - 8f * 0.9f) / 2f, 0.9f, TreeDraw.withAlpha(DIM_COLOR, a), Align.RIGHT);
        DevCondition hovered = null;
        for (int i = 0; i < conditions.size(); i++) {
            DevCondition condition = conditions.get(i);
            float x = startX + REQ_STEP * i;
            ResourceLocation tex = conditionIcon(condition);
            ResourceLocation drawn = condition.met() ? DeveloperTextures.linear(tex) : DeveloperTextures.grayscale(tex);
            TreeDraw.texture(g, drawn, x, y, REQ_ICON, REQ_ICON, condition.met() ? a : 0.6f * a);
            if (lx >= x && lx < x + REQ_ICON && ly >= y && ly < y + REQ_ICON) {
                hovered = condition;
            }
        }
        if (hovered != null) {
            Component text = Component.literal("(").append(conditionText(hovered)).append(")");
            TreeDraw.text(g, font, text, startX + total + 4f, y + (REQ_ICON - 8f * 0.8f) / 2f, 0.8f,
                    TreeDraw.withAlpha(hovered.met() ? MET_COLOR : UNMET_COLOR, a), Align.LEFT);
        }
        return y + REQ_ICON + 4f;
    }

    // --- Condiciones ---

    private static ResourceLocation conditionIcon(DevCondition condition) {
        return switch (condition.kind()) {
            case DEVELOPER_TYPE -> SkillTreeView.typeIcon(condition.developer() != null
                    ? condition.developer()
                    : DeveloperType.PORTABLE);
            case PARENT, DEPENDENCY -> AbilityRegistries.skill(condition.skill()).map(Skill::getIcon)
                    .orElse(DeveloperTextures.path("icon_nocategory"));
            case ANY_SKILL_OF_LEVEL -> DeveloperTextures.path("condition_any" + Mth.clamp(condition.level(), 1, 5));
        };
    }

    private static Component conditionText(DevCondition condition) {
        return switch (condition.kind()) {
            case DEVELOPER_TYPE -> SkillTreeView.typeName(condition.developer() != null
                    ? condition.developer()
                    : DeveloperType.PORTABLE);
            case PARENT, DEPENDENCY -> Component.translatable("railgunreborn.developer.condition.skill",
                    AbilityRegistries.skill(condition.skill()).map(Skill::getDisplayName)
                            .orElse(Component.literal(String.valueOf(condition.skill()))),
                    Math.round(condition.minExp() * 100f));
            case ANY_SKILL_OF_LEVEL -> Component.translatable("railgunreborn.developer.anyskill", condition.level());
        };
    }
}
