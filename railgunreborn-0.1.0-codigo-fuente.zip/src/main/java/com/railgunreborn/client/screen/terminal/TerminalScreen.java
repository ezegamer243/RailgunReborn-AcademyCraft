package com.railgunreborn.client.screen.terminal;

import java.util.List;
import java.util.function.Function;

import javax.annotation.Nullable;

import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.ModKeys;
import com.railgunreborn.client.screen.developer.DeveloperTextures;
import com.railgunreborn.client.screen.developer.TreeDraw;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Terminal de datos mínimo ({@code docs/spec/terminal.md}): panel en perspectiva a la derecha de la pantalla con la
 * cabecera del original y la rejilla de apps (hoy solo "Skill Tree"). Cursor virtual del original: el puntero del
 * sistema se oculta y la posición del ratón en la ventana se lleva al área 605x740 del panel.
 *
 * <p>Medidas en unidades del layout original ({@code guis/terminal.xml}).
 */
public class TerminalScreen extends Screen {
    private static final float PANEL_W = 640f;
    private static final float PANEL_H = 785f;
    /** Área del cursor virtual (y de la selección por tercios). */
    private static final float AREA_W = 605f;
    private static final float AREA_H = 740f;
    /** Panel a 4 unidades de una cámara de 50° a escala 1/310: alto de pantalla = 2·4·tan25°·310 unidades. */
    private static final float SCREEN_H_UNITS = 2f * 4f * (float) Math.tan(Math.toRadians(25)) * 310f;
    private static final float TAN_HALF_FOV = (float) Math.tan(Math.toRadians(25));
    private static final float LEFT_FRAC = 0.594f;
    private static final float TOP_FRAC = 0.178f;
    private static final float PIVOT_X = 310f;
    private static final float PIVOT_Y = 558f;
    /** Profundidad GUI del panel: delante del resto para que el test de profundidad no lo recorte. */
    private static final float PANEL_Z = 200f;
    private static final float CURSOR_SPEED = 3000f;

    private static final int COLUMNS = 3;
    private static final float APP_X = 65f;
    private static final float APP_Y = 155f;
    private static final float APP_STEP = 180f;
    private static final float APP_SIZE = 151f;
    private static final float ICON_SIZE = 110f;
    /** Ancho máximo del nombre y de "N Apps, HH:MM" (que no pisen "DATA TERMINAL"). */
    private static final float HEADER_RIGHT_W = 300f;

    private static final ResourceLocation BACK = tex("back");
    private static final ResourceLocation LOGO = tex("logo");
    private static final ResourceLocation APP_BACK = tex("app_back");
    private static final ResourceLocation APP_BACK_HIGHLIGHT = tex("app_back_highlight");
    private static final ResourceLocation CURSOR = tex("cursor");

    /** Apps del Terminal; por ahora solo "Skill Tree" (siempre instalada). */
    private static final List<App> APPS = List.of(
            new App("skill_tree", tex("app_skill_tree"), SkillTreeAppScreen::new));

    private final long openTime = Util.getMillis();
    private long lastFrame;
    private float cursorX = AREA_W / 2f;
    private float cursorY = AREA_H / 2f;
    private float buffX = cursorX;
    private float buffY = cursorY;
    private int selection = -1;

    public TerminalScreen() {
        super(Component.translatable("railgunreborn.terminal.title"));
    }

    @Override
    protected void init() {
        setSystemCursorHidden(true);
    }

    @Override
    public void removed() {
        setSystemCursorHidden(false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // --- Dibujo ---

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Sin fondo ni widgets vanilla: el Terminal flota sobre el juego como en el original.
        long now = Util.getMillis();
        float dt = lastFrame == 0 ? 0f : Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        updateCursor(mouseX, mouseY, dt);
        float lifetime = (now - openTime) / 1000f;

        float unit = height / SCREEN_H_UNITS;
        float left = Math.min(width * LEFT_FRAC, width - PANEL_W * unit * 1.05f);
        float top = height * TOP_FRAC;
        float yaw = -18f - 4f * (buffX / AREA_W - 0.5f) + Mth.sin(now / 1000f);
        float pitch = 7f + 4f * (buffY / AREA_H - 0.5f);

        withPerspective(g, () -> {
            var pose = g.pose();
            pose.pushPose();
            pose.translate(left, top, PANEL_Z);
            pose.scale(unit, unit, unit);
            // Giros del original pasados a coordenadas GUI (Y hacia abajo): cambian de signo los de X y Z.
            pose.translate(PIVOT_X, PIVOT_Y, 0f);
            pose.mulPose(Axis.ZP.rotationDegrees(1.6f));
            pose.mulPose(Axis.YP.rotationDegrees(yaw));
            pose.mulPose(Axis.XP.rotationDegrees(-pitch));
            pose.translate(-PIVOT_X, -PIVOT_Y, 0f);
            drawPanel(g, lifetime, now);
            pose.popPose();
        });
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }

    private void drawPanel(GuiGraphics g, float lifetime, long now) {
        var pose = g.pose();
        TreeDraw.texture(g, DeveloperTextures.linear(BACK), 0f, 0f, PANEL_W, PANEL_H, 1f);

        // Capas separadas un poco hacia el jugador para que no se peleen en profundidad.
        pose.translate(0f, 0f, 2f);
        TreeDraw.texture(g, DeveloperTextures.linear(LOGO), 40f, 50f, 50f, 50f, 1f);
        TreeDraw.text(g, font, Component.literal("DATA"), 98f, 57f - 18f, 4f, 0xAAFFFFFF, Align.LEFT);
        TreeDraw.text(g, font, Component.literal("TERMINAL"), 98f, 89f - 18f, 4f, 0xAAFFFFFF, Align.LEFT);
        if (minecraft != null && minecraft.player != null) {
            Component name = minecraft.player.getName();
            TreeDraw.text(g, font, name, PANEL_W - 40f, 41.67f, fitScale(name, 4f, HEADER_RIGHT_W), 0xCCFFFFFF,
                    Align.RIGHT);
        }
        Component count = appCountLine();
        TreeDraw.text(g, font, count, PANEL_W - 40f, 99f - 13.5f, fitScale(count, 3f, HEADER_RIGHT_W), 0x99FFFFFF,
                Align.RIGHT);

        for (int i = 0; i < APPS.size(); i++) {
            drawApp(g, i, APPS.get(i), lifetime);
        }

        pose.translate(0f, 0f, 4f);
        float size = (selectedApp() != null ? 1.3f : 1f) * (20f + 2f * Mth.sin(now / 300f));
        drawAdditive(g, DeveloperTextures.linear(CURSOR), buffX - size / 2f, buffY + 120f - size / 2f, size, 0.4f);
    }

    private void drawApp(GuiGraphics g, int index, App app, float lifetime) {
        float x = APP_X + APP_STEP * (index % COLUMNS);
        float y = APP_Y + APP_STEP * (index / COLUMNS);
        float alpha = Mth.clamp((lifetime - (index + 1) * 0.1f) / 0.4f, 0f, 1f);
        if (alpha <= 0f) {
            return;
        }
        boolean selected = index == selection;
        TreeDraw.texture(g, DeveloperTextures.linear(selected ? APP_BACK_HIGHLIGHT : APP_BACK), x, y, APP_SIZE,
                APP_SIZE, alpha);
        // El layout original pone el icono en (9, 32); aquí va centrado en la casilla.
        float iconOffset = (APP_SIZE - ICON_SIZE) / 2f;
        TreeDraw.texture(g, DeveloperTextures.linear(app.icon()), x + iconOffset, y + iconOffset, ICON_SIZE,
                ICON_SIZE, alpha * (selected ? 0.8f : 0.6f));
        Component name = app.displayName();
        float nameScale = fitScale(name, 3.2f, APP_SIZE);
        TreeDraw.text(g, font, name, x + APP_SIZE / 2f, y + 158.5f - 4.5f * nameScale, nameScale,
                TreeDraw.withAlpha(0xFFFFFF, alpha), Align.CENTER);
    }

    /** Escala del texto: la del original salvo que no quepa en {@code maxWidth}. */
    private float fitScale(Component text, float scale, float maxWidth) {
        return Math.min(scale, maxWidth / Math.max(1, font.width(text)));
    }

    /** "N Apps, HH:MM" con la hora del mundo como el original (sin desfase de 6 h). */
    private Component appCountLine() {
        long dayTime = minecraft != null && minecraft.level != null ? minecraft.level.getDayTime() % 24000L : 0L;
        int hours = (int) (dayTime / 1000L);
        int minutes = (int) (dayTime % 1000L * 60L / 1000L);
        return Component.translatable("railgunreborn.terminal.app_count", APPS.size())
                .append(String.format(", %02d:%02d", hours, minutes));
    }

    /**
     * Dibuja con proyección en perspectiva (FOV vertical 50°, cámara en el centro de la pantalla) en lugar de la
     * ortográfica de las GUI. El plano z = {@link #PANEL_Z} queda igual que en la ortográfica; lo que se acerca al
     * jugador crece y lo que se aleja encoge.
     */
    private void withPerspective(GuiGraphics g, Runnable draw) {
        g.flush();
        float cx = width / 2f;
        float cy = height / 2f;
        float d = height / 2f / TAN_HALF_FOV;
        float z0 = PANEL_Z;
        // Columnas (JOML): w = 1 - (z - z0) / d; x' = cx + (x - cx) / w (igual en y).
        Matrix4f perspective = new Matrix4f(
                1f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f,
                -cx / d, -cy / d, 1f, -1f / d,
                cx * z0 / d, cy * z0 / d, 0f, 1f + z0 / d);
        Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());
        Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix())
                .mul(modelView)
                .mul(perspective)
                .mul(new Matrix4f(modelView).invert());
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(projection, RenderSystem.getVertexSorting());
        try {
            draw.run();
            g.flush();
        } finally {
            RenderSystem.restoreProjectionMatrix();
        }
    }

    /** Cuadro con mezcla aditiva (el brillo del cursor del original). */
    private static void drawAdditive(GuiGraphics g, ResourceLocation tex, float x, float y, float size, float alpha) {
        g.flush();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, tex);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS,
                DefaultVertexFormat.POSITION_TEX_COLOR);
        buf.addVertex(m, x, y, 0).setUv(0f, 0f).setColor(1f, 1f, 1f, alpha);
        buf.addVertex(m, x, y + size, 0).setUv(0f, 1f).setColor(1f, 1f, 1f, alpha);
        buf.addVertex(m, x + size, y + size, 0).setUv(1f, 1f).setColor(1f, 1f, 1f, alpha);
        buf.addVertex(m, x + size, y, 0).setUv(1f, 0f).setColor(1f, 1f, 1f, alpha);
        BufferUploader.drawWithShader(buf.buildOrThrow());
        RenderSystem.defaultBlendFunc();
    }

    // --- Cursor y selección ---

    private void updateCursor(int mouseX, int mouseY, float dt) {
        cursorX = Mth.clamp(width > 0 ? mouseX / (float) width * AREA_W : 0f, 0f, AREA_W);
        cursorY = Mth.clamp(height > 0 ? mouseY / (float) height * AREA_H : 0f, 0f, AREA_H);
        buffX = approach(buffX, cursorX, CURSOR_SPEED * dt);
        buffY = approach(buffY, cursorY, CURSOR_SPEED * dt);
        // Selección por tercios del área, como el original (el cursor se dibuja 120 más abajo y así cuadra con la
        // rejilla).
        int row = Math.min(2, (int) (cursorY / AREA_H * 3f));
        int col = Math.min(2, (int) (cursorX / AREA_W * 3f));
        selection = row * COLUMNS + col;
    }

    private static float approach(float from, float to, float maxStep) {
        float delta = to - from;
        return from + Math.copySign(Math.min(maxStep, Math.abs(delta)), delta);
    }

    @Nullable
    private App selectedApp() {
        return selection >= 0 && selection < APPS.size() ? APPS.get(selection) : null;
    }

    // --- Entrada ---

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        // Como el original: la app se abre al soltar el clic izquierdo.
        App app = selectedApp();
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && app != null && minecraft != null) {
            minecraft.setScreen(app.opener().apply(this));
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModKeys.OPEN_TERMINAL.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void setSystemCursorHidden(boolean hidden) {
        if (minecraft != null) {
            GLFW.glfwSetInputMode(minecraft.getWindow().getWindow(), GLFW.GLFW_CURSOR,
                    hidden ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL);
        }
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/terminal/" + name + ".png");
    }

    /** App del Terminal: id (nombre en {@code railgunreborn.terminal.app.<id>}), icono y pantalla que abre. */
    private record App(String id, ResourceLocation icon, Function<TerminalScreen, Screen> opener) {
        Component displayName() {
            return Component.translatable("railgunreborn.terminal.app." + id);
        }
    }
}
