package com.railgunreborn.client.screen.developer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * Árbol de habilidades + paneles de la pantalla del Developer ({@code developer.md} sección 3), sin depender del
 * menú: recibe el jugador, el tipo de Developer (null = modo consulta, app "Skill Tree" del Terminal, T22c) y un
 * {@link DevelopLink} opcional con el estado del desarrollo.
 *
 * <p>Todas las medidas están en unidades del original; el conjunto {@code main} (400x187) se centra en pantalla y
 * solo se reduce si no cabe. Lo que muestra sale de {@link AbilityData} sincronizada (solo visual; el servidor
 * revalida todo).
 */
public class SkillTreeView {
    static final float MAIN_W = 400f;
    static final float MAIN_H = 187f;
    private static final float MARGIN = 4f;
    private static final float LEFT_X = 4f;
    private static final float LEFT_W = 108.5f;
    private static final float RIGHT_W = 278f;
    private static final float RIGHT_X = MAIN_W - 4f - RIGHT_W;
    private static final float AREA_X = RIGHT_X + 10f;
    private static final float AREA_Y = 18f;
    private static final float AREA_W = 257f;
    private static final float AREA_H = 139f;

    // Nodos (3.2)
    private static final float NODE_SIZE = 16f;
    private static final float DISK_SIZE = 23f;
    private static final float RING_SIZE = 31f;
    private static final float ICON_SIZE = 14f;
    private static final float HOVER_SCALE = 1.2f;
    private static final float HOVER_SECONDS = 0.1f;
    private static final float ALPHA_LEARNED = 1.0f;
    private static final float ALPHA_AVAILABLE = 0.7f;
    private static final float ALPHA_LOCKED = 0.25f;
    private static final float BG_PARALLAX = 0.01f;
    private static final float BG_ZOOM = 1.01f;
    private static final float NODE_PARALLAX = 10f;
    // Líneas (3.3)
    private static final float LINE_WIDTH = 5.5f;
    private static final float LINE_TRIM = 12.2f;

    // Bloque de categoría (3.4), relativo al panel izquierdo
    private static final float ABILITY_X = 2f;
    private static final float ABILITY_Y = 67.5f;
    private static final float BAR_X = 31f;
    private static final float BAR_Y = 13.25f;
    private static final float BAR_W = 70f;
    private static final float BAR_H = 1.5f;
    private static final float UPGRADE_X = 60f;
    private static final float UPGRADE_Y = 14.5f;
    private static final float UPGRADE_W = 48f;
    private static final float UPGRADE_H = 48f * 64f / 200f;
    private static final int LEVEL_COLOR = 0xFF1177D6;

    // Panel de máquina (3.4), relativo al panel izquierdo
    private static final float MACHINE_X = 5.75f;
    private static final float MACHINE_BAR_W = 97f;
    private static final float MACHINE_BAR_H = 8f;
    private static final int POWER_COLOR = 0xFFFCC532;
    private static final int SYNC_COLOR = 0xFF32A4FC;

    private static final ResourceLocation PANEL_LEFT_BG = DeveloperTextures.path("panel_left_bg");
    private static final ResourceLocation PANEL_RIGHT_BG = DeveloperTextures.path("panel_right_bg");
    private static final ResourceLocation PANEL_MACHINE_BG = DeveloperTextures.path("panel_machine_bg");
    private static final ResourceLocation FRAME_LEFT = DeveloperTextures.path("frame_left");
    private static final ResourceLocation FRAME_LEFT_SKILLTREE = DeveloperTextures.path("frame_left_skilltree");
    private static final ResourceLocation FRAME_RIGHT = DeveloperTextures.path("frame_right");
    private static final ResourceLocation AREA_BG = DeveloperTextures.path("area_background");
    private static final ResourceLocation ICON_NO_CATEGORY = DeveloperTextures.path("icon_nocategory");

    private final Player player;
    @Nullable
    private final DeveloperType developerType;
    @Nullable
    private final DevelopLink link;
    private final Font font;

    private int screenWidth;
    private int screenHeight;
    private float scale = 1f;
    private float originX;
    private float originY;

    private List<Node> nodes = List.of();
    private long buildTime;
    @Nullable
    private Signature signature;
    private long lastFrame;
    @Nullable
    private ActionOverlay detail;
    /** Consola "OS" (sin categoría); se crea al hacer falta y se quita al pasar al árbol. */
    @Nullable
    private CategoryConsole console;

    /**
     * @param developerType tipo de Developer abierto, o null en modo consulta (sin panel de máquina ni requisitos)
     * @param link          estado del desarrollo, o null en modo consulta
     */
    public SkillTreeView(Player player, @Nullable DeveloperType developerType, @Nullable DevelopLink link) {
        this.player = player;
        this.developerType = developerType;
        this.link = link;
        this.font = Minecraft.getInstance().font;
    }

    // --- Ciclo de vida ---

    public void resize(int width, int height) {
        screenWidth = width;
        screenHeight = height;
        scale = Math.min(1f, Math.min((width - 2 * MARGIN) / MAIN_W, (height - 2 * MARGIN) / MAIN_H));
        scale = Math.max(0.1f, scale);
        originX = (width - MAIN_W * scale) / 2f;
        originY = (height - MAIN_H * scale) / 2f;
    }

    /**
     * Reconstruye nodos y reinicia la animación de entrada. Se llama sola cuando cambian categoría, nivel o
     * habilidades aprendidas (sync de {@link AbilityData}), pero no con un panel abierto: así, tras un desarrollo
     * con éxito, el árbol se reconstruye al cerrar el panel (como el original).
     */
    public void rebuild() {
        AbilityData data = AbilityData.get(player);
        signature = Signature.of(data);
        buildTime = Util.getMillis();
        List<Node> list = new ArrayList<>();
        Optional<Category> category = category(data);
        if (category.isPresent()) {
            Map<ResourceLocation, Node> byId = new HashMap<>();
            for (Skill skill : category.get().getSkills()) {
                if (isVisible(data, skill)) {
                    Node node = new Node(skill, list.size());
                    list.add(node);
                    byId.put(skill.getId(), node);
                }
            }
            for (Node node : list) {
                node.parent = node.skill.getParent().map(dep -> byId.get(dep.skill())).orElse(null);
            }
        }
        nodes = List.copyOf(list);
    }

    @Nullable
    DeveloperType developerType() {
        return developerType;
    }

    @Nullable
    DevelopLink link() {
        return link;
    }

    Player player() {
        return player;
    }

    Font font() {
        return font;
    }

    /** Si el panel de detalle o de subida está abierto. */
    public boolean isDetailOpen() {
        return detail != null;
    }

    // --- Dibujo ---

    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = Util.getMillis();
        float dt = lastFrame == 0 ? 0f : (now - lastFrame) / 1000f;
        lastFrame = now;
        AbilityData data = AbilityData.get(player);
        boolean showConsole = updateConsole(data);
        if (detail == null && (signature == null || !signature.equals(Signature.of(data)))) {
            rebuild();
        }

        // Paralaje: ratón normalizado a toda la pantalla, -0.5..0.5.
        float pdx = screenWidth > 0 ? Mth.clamp(mouseX / (float) screenWidth, 0f, 1f) - 0.5f : 0f;
        float pdy = screenHeight > 0 ? Mth.clamp(mouseY / (float) screenHeight, 0f, 1f) - 0.5f : 0f;
        float lx = (mouseX - originX) / scale;
        float ly = (mouseY - originY) / scale;
        boolean interactive = detail == null;

        var pose = g.pose();
        pose.pushPose();
        pose.translate(originX, originY, 0);
        pose.scale(scale, scale, 1f);

        // Panel derecho: fondo, área con paralaje, marco.
        TreeDraw.texture(g, DeveloperTextures.linear(PANEL_RIGHT_BG), RIGHT_X, 0f, RIGHT_W, MAIN_H, 1f);
        float visible = 1f / BG_ZOOM;
        float u0 = (1f - visible) / 2f + pdx * BG_PARALLAX;
        float v0 = (1f - visible) / 2f + pdy * BG_PARALLAX;
        TreeDraw.quad(g, DeveloperTextures.linear(AREA_BG), AREA_X, AREA_Y, AREA_W, AREA_H, u0, v0, u0 + visible,
                v0 + visible, 1f, 1f, 1f, 1f);
        TreeDraw.texture(g, DeveloperTextures.linear(FRAME_RIGHT), RIGHT_X, 0f, RIGHT_W, MAIN_H, 1f);

        if (showConsole && console != null) {
            console.render(g, AREA_X, AREA_Y);
        } else if (category(data).isPresent()) {
            Node hovered = interactive ? nodeAt(lx, ly, pdx, pdy) : null;
            drawTree(g, data, now, dt, pdx, pdy, hovered);
        }

        // Panel izquierdo.
        TreeDraw.texture(g, DeveloperTextures.linear(PANEL_LEFT_BG), LEFT_X, 0f, LEFT_W, MAIN_H, 1f);
        if (developerType != null) {
            TreeDraw.texture(g, DeveloperTextures.linear(PANEL_MACHINE_BG), LEFT_X, 0f, LEFT_W, MAIN_H, 1f);
        }
        TreeDraw.texture(g, DeveloperTextures.linear(developerType != null ? FRAME_LEFT : FRAME_LEFT_SKILLTREE),
                LEFT_X, 0f, LEFT_W, MAIN_H, 1f);
        drawCategoryPanel(g, data, interactive && isOverUpgrade(lx, ly, data));
        if (developerType != null) {
            drawMachinePanel(g, developerType);
        }
        pose.popPose();

        if (detail != null) {
            detail.render(g, screenWidth, screenHeight, scale, mouseX, mouseY);
            if (detail.isGone()) {
                detail = null;
            }
        }
    }

    private void drawTree(GuiGraphics g, AbilityData data, long now, float dt, float pdx, float pdy,
            @Nullable Node hovered) {
        float elapsed = (now - buildTime) / 1000f;
        ResourceLocation back = DeveloperTextures.gui("skill_back");
        ResourceLocation outline = DeveloperTextures.gui("skill_outline");
        for (Node node : nodes) {
            node.hover = Mth.clamp(node.hover + (node == hovered ? dt : -dt) / HOVER_SECONDS, 0f, 1f);
            float t = elapsed - node.startDelay();
            float diskA = clamp01(t / 0.1f);
            float iconA = clamp01((t - 0.08f) / 0.1f);
            float ringT = clamp01((t - 0.12f) / 0.5f);
            boolean learned = data.isLearned(node.skill.getId());
            float alpha = stateAlpha(data, node.skill);

            var pose = g.pose();
            pose.pushPose();
            pose.translate(nodeCenterX(node, pdx), nodeCenterY(node, pdy), 0);
            float s = 1f + (HOVER_SCALE - 1f) * node.hover;
            pose.scale(s, s, 1f);
            TreeDraw.centered(g, back, 0f, 0f, DISK_SIZE, 1f, 1f, 1f, alpha * diskA);
            TreeDraw.centered(g, outline, 0f, 0f, RING_SIZE, 0.2f, 0.2f, 0.2f, 0.6f * alpha * diskA);
            ResourceLocation icon = learned ? DeveloperTextures.linear(node.skill.getIcon())
                    : DeveloperTextures.grayscale(node.skill.getIcon());
            TreeDraw.centered(g, icon, 0f, 0f, ICON_SIZE, 1f, 1f, 1f, alpha * iconA);
            if (learned) {
                float exp = node.skill.getExp(player);
                TreeDraw.radial(g, outline, 0f, 0f, RING_SIZE, exp * easeOut(ringT), 1f, 1f, 1f, alpha * diskA);
            }
            pose.popPose();
        }

        // Líneas hijo→padre, encima de los nodos; crecen desde el padre.
        ResourceLocation line = DeveloperTextures.gui("line");
        for (Node node : nodes) {
            Node parent = node.parent;
            if (parent == null) {
                continue;
            }
            float px = nodeCenterX(parent, pdx);
            float py = nodeCenterY(parent, pdy);
            float cx = nodeCenterX(node, pdx);
            float cy = nodeCenterY(node, pdy);
            float dx = cx - px;
            float dy = cy - py;
            float len = Mth.sqrt(dx * dx + dy * dy);
            float drawn = len - 2 * LINE_TRIM;
            if (drawn <= 0f) {
                continue;
            }
            float grow = clamp01((elapsed - node.startDelay()) / 0.2f);
            float nx = dx / len;
            float ny = dy / len;
            float sx = px + nx * LINE_TRIM;
            float sy = py + ny * LINE_TRIM;
            float lineAlpha = stateAlpha(data, node.skill)
                    * (data.isLearned(node.skill.getId()) ? 1f : 0.4f);
            g.pose().pushPose();
            g.pose().translate(0, 0, 11);
            TreeDraw.line(g, line, sx, sy, sx + nx * drawn * grow, sy + ny * drawn * grow, LINE_WIDTH, lineAlpha);
            g.pose().popPose();
        }
    }

    /**
     * Crea la consola si no hay categoría y la quita cuando llega (salvo mientras {@code learn} sigue mostrando su
     * final). Al quitarla se reconstruye el árbol con la animación de entrada.
     *
     * @return si el área muestra la consola
     */
    private boolean updateConsole(AbilityData data) {
        boolean hasCategory = category(data).isPresent();
        if (console == null && !hasCategory) {
            console = new CategoryConsole(this, AREA_W);
        } else if (console != null && hasCategory && !console.isHolding()) {
            console = null;
            rebuild();
        }
        return console != null;
    }

    private void drawCategoryPanel(GuiGraphics g, AbilityData data, boolean upgradeHovered) {
        float bx = LEFT_X + ABILITY_X;
        float by = ABILITY_Y;
        Optional<Category> category = category(data);
        ResourceLocation icon = category.map(SkillTreeView::developerIcon).orElse(ICON_NO_CATEGORY);
        TreeDraw.texture(g, DeveloperTextures.linear(icon), bx, by, 32f, 32f, 1f);

        Component name = category.map(Category::getDisplayName)
                .orElse(Component.translatable("railgunreborn.developer.no_category"));
        float nameScale = Math.min(1.3f, BAR_W / Math.max(1, font.width(name)));
        TreeDraw.text(g, font, name, bx + BAR_X, by + 0.5f, nameScale, 0xFFFFFFFF, Align.LEFT);

        float progress = category.map(c -> c.levelProgressFraction(data.getLevel(), data.getLevelProgress()))
                .orElse(0f);
        TreeDraw.fill(g, bx + BAR_X, by + BAR_Y, BAR_W, BAR_H, 0x4C666666);
        if (category.isPresent()) {
            TreeDraw.fill(g, bx + BAR_X, by + BAR_Y, BAR_W * Math.max(0.02f, progress), BAR_H, 0xFFFFFFFF);
        }
        TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.level_exp",
                Math.round(progress * 100f)), bx + 30f, by + 17f, 0.8f, 0xFFFFFFFF, Align.LEFT);

        if (showUpgradeButton(data)) {
            TreeDraw.texture(g, DeveloperTextures.gui("button_learn"), bx + UPGRADE_X, by + UPGRADE_Y, UPGRADE_W,
                    UPGRADE_H, upgradeHovered ? 1f : 0.7f);
        } else {
            TreeDraw.text(g, font, Component.translatable("railgunreborn.level." + data.getLevel()),
                    bx + BAR_X + BAR_W, by + 16f, 0.9f, LEVEL_COLOR, Align.RIGHT);
        }
    }

    /**
     * En lugar de "Current Node" se muestra el tipo de Developer. La barra de energía muestra el buffer real; con
     * {@code energyRequired} desactivado se dibuja llena con "∞" para no dejar el hueco vacío de la textura.
     */
    private void drawMachinePanel(GuiGraphics g, DeveloperType type) {
        float x = LEFT_X + MACHINE_X;
        float right = x + MACHINE_BAR_W;
        TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.machine.developer"), x, 104.5f, 1f,
                0xFFFFFFFF, Align.LEFT);
        TreeDraw.texture(g, DeveloperTextures.linear(typeIcon(type)), x, 116.5f, 12f, 12f, 1f);
        Component typeName = typeName(type);
        float typeScale = Math.min(0.9f, (MACHINE_BAR_W - 16f) / Math.max(1, font.width(typeName)));
        TreeDraw.text(g, font, typeName, x + 16f, 122.5f - 4f * typeScale, typeScale, 0xFFFFFFFF, Align.LEFT);

        TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.machine.power"), x, 132.5f, 1f,
                0xFFFFFFFF, Align.LEFT);
        if (link != null && link.energyRequired()) {
            int stored = link.energy();
            int capacity = type.energyCapacity();
            Component amount = Component.literal(EnergyFormat.fraction(stored, capacity));
            float amountScale = Math.min(0.8f, (MACHINE_BAR_W - 40f) / Math.max(1, font.width(amount)));
            TreeDraw.text(g, font, amount, right, 132.5f + 4f * (1f - amountScale), amountScale, 0xFFFFFFFF,
                    Align.RIGHT);
            TreeDraw.fill(g, x, 145f, MACHINE_BAR_W, MACHINE_BAR_H, 0x4C666666);
            TreeDraw.fill(g, x, 145f, MACHINE_BAR_W * EnergyMath.fill(stored, capacity), MACHINE_BAR_H, POWER_COLOR);
        } else {
            TreeDraw.text(g, font, Component.literal("∞"), right, 132.5f, 1f, 0xFFFFFFFF, Align.RIGHT);
            TreeDraw.fill(g, x, 145f, MACHINE_BAR_W, MACHINE_BAR_H, POWER_COLOR);
        }

        TreeDraw.text(g, font, Component.translatable("railgunreborn.developer.machine.sync_rate"), x, 155f, 1f,
                0xFFFFFFFF, Align.LEFT);
        TreeDraw.text(g, font, Component.literal(Math.round(type.syncRate() * 100f) + "%"), right, 155f, 1f,
                0xFFFFFFFF, Align.RIGHT);
        TreeDraw.fill(g, x, 167f, MACHINE_BAR_W * type.syncRate(), MACHINE_BAR_H, SYNC_COLOR);
    }

    // --- Entrada ---

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (detail != null) {
            detail.mouseClicked(mouseX, mouseY, screenWidth, screenHeight, scale);
            return true;
        }
        if (button != 0) {
            return false;
        }
        float lx = (float) ((mouseX - originX) / scale);
        float ly = (float) ((mouseY - originY) / scale);
        AbilityData data = AbilityData.get(player);
        if (isOverUpgrade(lx, ly, data)) {
            detail = new LevelUpOverlay(this);
            return true;
        }
        if (console == null && category(data).isPresent()) {
            float pdx = screenWidth > 0 ? (float) mouseX / screenWidth - 0.5f : 0f;
            float pdy = screenHeight > 0 ? (float) mouseY / screenHeight - 0.5f : 0f;
            Node node = nodeAt(lx, ly, pdx, pdy);
            if (node != null) {
                detail = new SkillDetailOverlay(this, node.skill);
                return true;
            }
        }
        return false;
    }

    /**
     * Teclas (salvo ESC, que maneja la pantalla). Con la consola de Developer visible se las queda todas: escribir
     * "e" no debe cerrar la pantalla como haría la tecla de inventario.
     *
     * @return true si la tecla se consumió
     */
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (detail == null && console != null && console.capturesKeys()) {
            return console.keyPressed(keyCode);
        }
        return false;
    }

    public boolean charTyped(char c, int modifiers) {
        if (detail == null && console != null && console.capturesKeys()) {
            return console.charTyped(c);
        }
        return false;
    }

    // --- Lógica de nodos ---

    /**
     * Decisión del usuario (2026-10-08): el árbol muestra siempre todas las habilidades; las que aún no se pueden
     * aprender se ven con el alfa de "bloqueada". El original solo revelaba las de nivel alcanzado o con el padre
     * aprendido ({@code canBePotentiallyLearned}, ficha 3.2).
     */
    private static boolean isVisible(AbilityData data, Skill skill) {
        return true;
    }

    private static boolean parentLearned(AbilityData data, Skill skill) {
        return skill.getParent()
                .map(dep -> AbilityRegistries.skill(dep.skill()).isEmpty() || data.isLearned(dep.skill()))
                .orElse(true);
    }

    /**
     * Aprendida 1.0; disponible 0.7; bloqueada 0.25. Con Developer, "disponible" = se puede aprender ahí ahora
     * ({@link Skill#checkLearn}); en modo consulta, como el original: raíz o padre aprendido.
     */
    private float stateAlpha(AbilityData data, Skill skill) {
        if (data.isLearned(skill.getId())) {
            return ALPHA_LEARNED;
        }
        boolean available = developerType != null
                ? skill.checkLearn(data, developerType).isOk()
                : parentLearned(data, skill);
        return available ? ALPHA_AVAILABLE : ALPHA_LOCKED;
    }

    @Nullable
    private Node nodeAt(float lx, float ly, float pdx, float pdy) {
        for (Node node : nodes) {
            float cx = nodeCenterX(node, pdx);
            float cy = nodeCenterY(node, pdy);
            if (Math.abs(lx - cx) <= NODE_SIZE / 2f && Math.abs(ly - cy) <= NODE_SIZE / 2f) {
                return node;
            }
        }
        return null;
    }

    private static float nodeCenterX(Node node, float pdx) {
        return AREA_X + node.skill.getGuiX() - pdx * NODE_PARALLAX + NODE_SIZE / 2f;
    }

    private static float nodeCenterY(Node node, float pdy) {
        return AREA_Y + node.skill.getGuiY() - pdy * NODE_PARALLAX + NODE_SIZE / 2f;
    }

    private boolean showUpgradeButton(AbilityData data) {
        return developerType != null && category(data).map(c -> c.canLevelUp(data)).orElse(false);
    }

    private boolean isOverUpgrade(float lx, float ly, AbilityData data) {
        if (!showUpgradeButton(data)) {
            return false;
        }
        float x = LEFT_X + ABILITY_X + UPGRADE_X;
        float y = ABILITY_Y + UPGRADE_Y;
        return lx >= x && lx < x + UPGRADE_W && ly >= y && ly < y + UPGRADE_H;
    }

    private static Optional<Category> category(AbilityData data) {
        return AbilityRegistries.category(data.getCategory().orElse(null));
    }

    /** Icono grande de la categoría del original ({@code guis/icons/icon_<cat>.png}). */
    private static ResourceLocation developerIcon(Category category) {
        return category.getId().withPath(p -> "textures/category/" + p + "_developer_icon.png");
    }

    static ResourceLocation typeIcon(DeveloperType type) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                "textures/item/developer_" + type.name().toLowerCase(Locale.ROOT) + ".png");
    }

    static Component typeName(DeveloperType type) {
        return Component.translatable("railgunreborn.developer.type." + type.name().toLowerCase(Locale.ROOT));
    }

    private static float clamp01(float v) {
        return Mth.clamp(v, 0f, 1f);
    }

    private static float easeOut(float t) {
        float inv = 1f - t;
        return 1f - inv * inv;
    }

    private static final class Node {
        final Skill skill;
        final int index;
        @Nullable
        Node parent;
        float hover;

        Node(Skill skill, int index) {
            this.skill = skill;
            this.index = index;
        }

        /** Entrada en cascada: el nodo {@code idx} empieza a los {@code idx * 0.08 + 0.1} s. */
        float startDelay() {
            return index * 0.08f + 0.1f;
        }
    }

    /** Lo que cambia la forma del árbol: si cambia, se reconstruye (y se repite la animación de entrada). */
    private record Signature(Optional<ResourceLocation> category, int level, Set<ResourceLocation> learned) {
        static Signature of(AbilityData data) {
            return new Signature(data.getCategory(), data.getLevel(), Set.copyOf(data.getLearnedSkills()));
        }
    }
}
