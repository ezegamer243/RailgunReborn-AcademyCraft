package com.railgunreborn.client.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.teleporter.LocationData;
import com.railgunreborn.ability.teleporter.LocationData.SavedLocation;
import com.railgunreborn.ability.teleporter.LocationTeleportRules;
import com.railgunreborn.ability.teleporter.LocationTeleportRules.Problem;
import com.railgunreborn.ability.teleporter.LocationTeleportSkill;
import com.railgunreborn.client.teleporter.LocationTeleportClient;

import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Pantalla de Location Teleport ({@code location-teleport.md} §6 y §13.3): lista de ubicaciones a la derecha del centro
 * y panel de información a la izquierda, que sigue a la fila bajo el ratón. Sin velo y sin pausa. Rueda = scroll (6
 * filas visibles). La lista se lee de la copia sincronizada de {@link LocationData}; cada acción va al servidor por el
 * canal del contexto y se ve cuando vuelve el sync. Medidas en px de GUI respecto al centro de la pantalla.
 */
public class LocationTeleportScreen extends Screen {
    private static final float MENU_DX = 4.8f;
    private static final float MENU_DY = -43.0f;
    private static final float MENU_W = 106.1f;
    private static final float MENU_H = 127.2f;
    private static final float ROWS_TOP = 4.3f;
    private static final float ROW_H = 19.2f;
    private static final float ROW_STEP = 19.68f;
    private static final int VISIBLE_ROWS = 6;
    private static final float NAME_X = 10.9f;
    private static final float NAME_Y = 3.9f;
    private static final float NAME_H = 13.3f;
    private static final float NAME_MAX_W = 67f;
    private static final float ICON = 8f;
    private static final float ICON_Y = 7.2f;
    /** El área de clic es de 12x12, centrada en el icono de 8x8. */
    private static final float ICON_HIT_PAD = 2f;
    private static final float TELEPORT_X = 80.4f;
    private static final float REMOVE_X = 90.0f;
    private static final float CHECK_X = 90.2f;
    private static final int ICON_TEX = 48;
    private static final float PANEL_RIGHT_DX = -5.6f;
    private static final float PANEL_MARGIN = 4.8f;
    private static final float PANEL_LINE = 10.08f;

    private static final int MENU_BG = 0x80353535;
    private static final int MENU_LINE = 0x9E7A929C;
    private static final int TEXT = 0xC1CFD5;
    private static final int TEXT_DISABLED = 0xA2A2A2;
    private static final int HINT = 0xA4D4E9;
    private static final float ROW_ALPHA = 0.1f;
    private static final float ROW_ALPHA_HOVER = 0.4f;
    private static final float ICON_ALPHA = 0.7f;

    // Tiempos de la animación de entrada (segundos, [DUDA] 5).
    private static final float MENU_GROW = 0.4f;
    private static final float ROW_DELAY = 0.06f;
    private static final float ROW_FADE = 0.2f;

    private static final ResourceLocation ICON_TELEPORT = tex("location_on");
    private static final ResourceLocation ICON_REMOVE = tex("clear");
    private static final ResourceLocation ICON_CHECK = tex("check");
    private static final Set<String> VANILLA_DIMENSIONS = Set.of("overworld", "the_nether", "the_end");
    private static final String LANG = "railgunreborn.gui.location_teleport.";

    private final LocationTeleportClient.ScreenContext context;
    private final long openedAt = Util.getMillis();
    private long rowsAt = openedAt;
    @Nullable
    private LocationData shown;
    @Nullable
    private EditBox nameBox;
    private boolean editing;
    private int scroll;
    private boolean closing;

    public LocationTeleportScreen(LocationTeleportClient.ScreenContext context) {
        super(Component.translatable("railgunreborn.ability.teleporter.location_teleport.name"));
        this.context = context;
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/location/" + name + ".png");
    }

    public boolean isFor(LocationTeleportClient.ScreenContext ctx) {
        return context == ctx;
    }

    public boolean isClosing() {
        return closing;
    }

    @Override
    protected void init() {
        String previous = nameBox == null ? "" : nameBox.getValue();
        nameBox = new EditBox(font, 0, 0, (int) NAME_MAX_W, 9, Component.translatable(LANG + "add"));
        nameBox.setBordered(false);
        nameBox.setMaxLength(LocationTeleportRules.MAX_NAME_LENGTH);
        nameBox.setTextColor(TEXT);
        nameBox.setValue(previous);
        nameBox.setFocused(editing);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.player == null || context.isTerminated()) {
            onClose();
        }
    }

    @Override
    public void removed() {
        closing = true;
        if (!context.isTerminated()) {
            context.terminate();
        }
    }

    // --- Modelo ---

    private Skill skill() {
        return context.getSkill();
    }

    private LocationData data() {
        return LocationData.get(minecraft.player);
    }

    /** Ubicaciones + la fila "Añadir". */
    private int rowCount(LocationData data) {
        return data.size() + 1;
    }

    private int maxScroll(LocationData data) {
        return Math.max(0, rowCount(data) - VISIBLE_ROWS);
    }

    /** Lo mismo que comprobará el servidor, con los datos sincronizados (se recalcula cada fotograma). */
    private Problem problem(LocalPlayer player, SavedLocation location) {
        ClientPacketListener connection = minecraft.getConnection();
        boolean exists = connection == null || connection.levels().contains(location.dimension());
        float exp = AbilityData.get(player).getSkillExp(skill().getId());
        boolean cross = LocationTeleportSkill.crossesDimension(player, location);
        float cost = LocationTeleportSkill.cpCost(exp, player, location);
        boolean enough = CPData.get(player).canConsume(player,
                LocationTeleportRules.overload() * skill().getOverloadConsumeSpeed(),
                cost * skill().getCpConsumeSpeed());
        return LocationTeleportRules.check(exists, cross, exp, enough);
    }

    private int displayedCost(LocalPlayer player, SavedLocation location) {
        float exp = AbilityData.get(player).getSkillExp(skill().getId());
        return Math.round(LocationTeleportSkill.cpCost(exp, player, location) * skill().getCpConsumeSpeed());
    }

    private static Component locationName(SavedLocation location, int index) {
        return location.name().isEmpty()
                ? Component.translatable(LANG + "default_name", index + 1)
                : Component.literal(location.name());
    }

    private static Component dimensionName(ResourceKey<Level> dimension) {
        ResourceLocation id = dimension.location();
        if (ResourceLocation.DEFAULT_NAMESPACE.equals(id.getNamespace())
                && VANILLA_DIMENSIONS.contains(id.getPath())) {
            return Component.translatable("railgunreborn.dimension." + id.getPath());
        }
        return Component.literal(id.toString());
    }

    private static Component coords(Vec3 pos) {
        return Component.literal("(" + Mth.floor(pos.x) + ", " + Mth.floor(pos.y) + ", " + Mth.floor(pos.z) + ")");
    }

    // --- Geometría ---

    private float menuX() {
        return width / 2f + MENU_DX;
    }

    private float menuY() {
        return height / 2f + MENU_DY;
    }

    private float menuHeightNow() {
        return MENU_H * blend(seconds(openedAt), 0f, MENU_GROW);
    }

    private float rowTop(int row) {
        return menuY() + ROWS_TOP + (row - scroll) * ROW_STEP;
    }

    private boolean isRowVisible(int row, LocationData data) {
        return row >= scroll && row < Math.min(rowCount(data), scroll + VISIBLE_ROWS);
    }

    /** Fila bajo el ratón (índice absoluto), o -1. */
    private int hoveredRow(double mouseX, double mouseY, LocationData data) {
        float x = menuX();
        if (mouseX < x || mouseX >= x + MENU_W || mouseY >= menuY() + menuHeightNow()) {
            return -1;
        }
        for (int row = scroll; row < Math.min(rowCount(data), scroll + VISIBLE_ROWS); row++) {
            float top = rowTop(row);
            if (mouseY >= top && mouseY < top + ROW_H) {
                return row;
            }
        }
        return -1;
    }

    private boolean overIcon(int row, float iconX, double mouseX, double mouseY) {
        double localX = mouseX - menuX() - iconX;
        double localY = mouseY - rowTop(row) - ICON_Y;
        return localX >= -ICON_HIT_PAD && localX < ICON + ICON_HIT_PAD
                && localY >= -ICON_HIT_PAD && localY < ICON + ICON_HIT_PAD;
    }

    private static float seconds(long since) {
        return (Util.getMillis() - since) / 1000f;
    }

    /** Progreso lineal 0..1 de una animación que empieza en {@code start} y dura {@code length}. */
    private static float blend(float t, float start, float length) {
        return Mth.clamp((t - start) / length, 0f, 1f);
    }

    // --- Dibujo ---

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Sin velo ni desenfoque: se ve el juego detrás, como el original.
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        LocalPlayer player = minecraft == null ? null : minecraft.player;
        if (player == null || nameBox == null) {
            return;
        }
        LocationData data = data();
        if (data != shown) {
            // Lista nueva (añadir/borrar): se recoloca el scroll y vuelve a empezar la entrada de las filas.
            shown = data;
            rowsAt = Util.getMillis();
            scroll = Mth.clamp(scroll, 0, maxScroll(data));
        }
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        float x = menuX();
        float y = menuY();
        float menuH = menuHeightNow();
        fillF(g, x, y, x + MENU_W, y + menuH, MENU_BG);
        outline(g, x, y, MENU_W, menuH, MENU_LINE);

        int hovered = hoveredRow(mouseX, mouseY, data);
        g.enableScissor(Mth.floor(x), Mth.floor(y), Mth.ceil(x + MENU_W), Mth.ceil(y + menuH));
        float rowsT = seconds(rowsAt);
        for (int row = scroll; row < Math.min(rowCount(data), scroll + VISIBLE_ROWS); row++) {
            float delay = (row - scroll) * ROW_DELAY;
            if (row < data.size()) {
                drawLocationRow(g, player, data.list().get(row), row, row == hovered, rowsT, delay, mouseX, mouseY);
            } else {
                drawAddRow(g, data, row, row == hovered, rowsT, delay, mouseX, mouseY, partialTick);
            }
        }
        g.disableScissor();
        drawScrollBar(g, data, x, y, menuH);

        if (hovered >= 0) {
            drawInfoPanel(g, player, data, hovered);
            Component tip = iconTooltip(player, data, hovered, mouseX, mouseY);
            if (tip != null) {
                g.renderTooltip(font, tip, mouseX, mouseY);
            }
        }
        g.setColor(1f, 1f, 1f, 1f);
    }

    private void drawRowBackground(GuiGraphics g, int row, boolean hovered, float fade) {
        float x = menuX();
        float top = rowTop(row);
        float alpha = (hovered ? ROW_ALPHA_HOVER : ROW_ALPHA) * fade;
        fillF(g, x, top, x + MENU_W, top + ROW_H, argb(alpha, 0xFFFFFF));
    }

    private void drawLocationRow(GuiGraphics g, LocalPlayer player, SavedLocation location, int row, boolean hovered,
            float t, float delay, int mouseX, int mouseY) {
        float fade = blend(t, delay, ROW_FADE);
        drawRowBackground(g, row, hovered, fade);
        boolean usable = problem(player, location) == Problem.NONE;
        int color = usable ? TEXT : TEXT_DISABLED;
        drawName(g, locationName(location, row), row, color, blend(t, delay + 0.1f, 0.1f));
        if (usable) {
            drawIcon(g, ICON_TELEPORT, row, TELEPORT_X, color, blend(t, delay + 0.03f, 0.1f),
                    overIcon(row, TELEPORT_X, mouseX, mouseY));
        }
        drawIcon(g, ICON_REMOVE, row, REMOVE_X, color, blend(t, delay + 0.05f, 0.1f),
                overIcon(row, REMOVE_X, mouseX, mouseY));
    }

    private void drawAddRow(GuiGraphics g, LocationData data, int row, boolean hovered, float t, float delay,
            int mouseX, int mouseY, float partialTick) {
        float fade = blend(t, delay, ROW_FADE);
        drawRowBackground(g, row, hovered, fade);
        if (data.isFull()) {
            drawName(g, Component.translatable(LANG + "err_full"), row, TEXT_DISABLED, blend(t, delay + 0.1f, 0.1f));
            return;
        }
        float textFade = blend(t, delay + 0.1f, 0.1f);
        if (editing) {
            nameBox.setX(Math.round(menuX() + NAME_X));
            nameBox.setY(Math.round(rowTop(row) + NAME_Y + (NAME_H - 8f) / 2f));
            if (nameBox.getValue().isEmpty()) {
                drawName(g, Component.translatable(LANG + "add"), row, HINT, 0.8f * textFade);
            }
            nameBox.render(g, mouseX, mouseY, partialTick);
        } else {
            drawName(g, Component.translatable(LANG + "add"), row, HINT, 0.4f * textFade);
        }
        drawIcon(g, ICON_CHECK, row, CHECK_X, TEXT, blend(t, delay, 0.1f), overIcon(row, CHECK_X, mouseX, mouseY));
    }

    private void drawName(GuiGraphics g, Component name, int row, int rgb, float alpha) {
        float scale = Math.min(1f, NAME_MAX_W / Math.max(1, font.width(name)));
        float top = rowTop(row) + NAME_Y + (NAME_H - 8f * scale) / 2f;
        drawText(g, name, menuX() + NAME_X, top, scale, argbText(alpha, rgb));
    }

    private void drawIcon(GuiGraphics g, ResourceLocation texture, int row, float iconX, int rgb, float fade,
            boolean hover) {
        float alpha = (hover ? 1f : ICON_ALPHA) * fade;
        g.setColor(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f, alpha);
        blitStretched(g, texture, menuX() + iconX, rowTop(row) + ICON_Y, ICON, ICON, ICON_TEX, ICON_TEX);
        g.setColor(1f, 1f, 1f, 1f);
    }

    private void drawScrollBar(GuiGraphics g, LocationData data, float x, float y, float menuH) {
        int total = rowCount(data);
        if (total <= VISIBLE_ROWS) {
            return;
        }
        float trackTop = y + ROWS_TOP;
        float trackH = Math.min(VISIBLE_ROWS * ROW_STEP, menuH - ROWS_TOP);
        if (trackH <= 0) {
            return;
        }
        float thumbH = trackH * VISIBLE_ROWS / total;
        float thumbTop = trackTop + (trackH - thumbH) * scroll / maxScroll(data);
        float barX = x + MENU_W + 1.5f;
        fillF(g, barX, trackTop, barX + 1f, trackTop + trackH, MENU_BG);
        fillF(g, barX, thumbTop, barX + 1f, thumbTop + thumbH, MENU_LINE);
    }

    private void drawInfoPanel(GuiGraphics g, LocalPlayer player, LocationData data, int row) {
        List<Component> lines = new ArrayList<>();
        if (row < data.size()) {
            SavedLocation location = data.list().get(row);
            lines.add(dimensionName(location.dimension()).copy().append(" (#" + (row + 1) + ")"));
            lines.add(coords(location.pos()));
            if (!LocationTeleportSkill.crossesDimension(player, location)) {
                lines.add(Component.translatable(LANG + "distance",
                        Mth.floor(LocationTeleportSkill.distance(player, location))));
            }
            lines.add(Component.translatable(LANG + "cost", displayedCost(player, location)));
            String reason = LocationTeleportSkill.problemKey(problem(player, location));
            if (reason != null) {
                lines.add(Component.translatable(reason));
            }
        } else {
            lines.add(dimensionName(player.level().dimension()).copy().append(" (#" + (data.size() + 1) + ")"));
            lines.add(coords(player.position()));
            lines.add(Component.translatable(data.isFull() ? LANG + "err_full" : LANG + "tip_add"));
        }
        int widest = 0;
        for (Component line : lines) {
            widest = Math.max(widest, font.width(line));
        }
        float panelW = widest + 2 * PANEL_MARGIN;
        float panelH = PANEL_LINE * lines.size() + 2 * PANEL_MARGIN;
        float right = width / 2f + PANEL_RIGHT_DX;
        float left = right - panelW;
        float top = Mth.clamp(rowTop(row), 2f, Math.max(2f, height - panelH - 2f));

        var pose = g.pose();
        pose.pushPose();
        pose.translate(0, 0, 100);
        fillF(g, left, top, right, top + panelH, MENU_BG);
        outline(g, left, top, panelW, panelH, MENU_LINE);
        for (int i = 0; i < lines.size(); i++) {
            Component line = lines.get(i);
            float lineY = top + PANEL_MARGIN + i * PANEL_LINE + (PANEL_LINE - 8f) / 2f;
            drawText(g, line, right - PANEL_MARGIN - font.width(line), lineY, 1f, 0xFF000000 | TEXT);
        }
        pose.popPose();
    }

    @Nullable
    private Component iconTooltip(LocalPlayer player, LocationData data, int row, int mouseX, int mouseY) {
        if (row < data.size()) {
            if (overIcon(row, TELEPORT_X, mouseX, mouseY)
                    && problem(player, data.list().get(row)) == Problem.NONE) {
                return Component.translatable(LANG + "tip_teleport");
            }
            if (overIcon(row, REMOVE_X, mouseX, mouseY)) {
                return Component.translatable(LANG + "tip_remove");
            }
        } else if (!data.isFull() && overIcon(row, CHECK_X, mouseX, mouseY)) {
            return Component.translatable(LANG + "tip_add");
        }
        return null;
    }

    // --- Entrada ---

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        LocalPlayer player = minecraft == null ? null : minecraft.player;
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || player == null) {
            return true;
        }
        LocationData data = data();
        int row = hoveredRow(mouseX, mouseY, data);
        if (row < 0) {
            stopEditing();
            return true;
        }
        if (row < data.size()) {
            stopEditing();
            if (overIcon(row, TELEPORT_X, mouseX, mouseY)
                    && problem(player, data.list().get(row)) == Problem.NONE) {
                context.requestTeleport(row);
            } else if (overIcon(row, REMOVE_X, mouseX, mouseY)) {
                context.requestRemove(row);
            }
            return true;
        }
        if (data.isFull()) {
            return true;
        }
        // El icono de confirmar solo actúa con el campo en edición ([DUDA] 4); si no, empieza a editar.
        if (editing && overIcon(row, CHECK_X, mouseX, mouseY)) {
            submit();
        } else if (!editing) {
            startEditing(data);
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (minecraft == null || minecraft.player == null || scrollY == 0) {
            return true;
        }
        scroll = Mth.clamp(scroll - (int) Math.signum(scrollY), 0, maxScroll(data()));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (editing && nameBox != null) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                submit();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                // La primera pulsación solo cancela la edición.
                stopEditing();
                return true;
            }
            nameBox.keyPressed(keyCode, scanCode, modifiers);
            return true;
        }
        if (minecraft != null && minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (editing && nameBox != null) {
            return nameBox.charTyped(codePoint, modifiers);
        }
        return super.charTyped(codePoint, modifiers);
    }

    private void startEditing(LocationData data) {
        if (nameBox == null || data.isFull()) {
            return;
        }
        editing = true;
        nameBox.setValue("");
        nameBox.setFocused(true);
        scroll = maxScroll(data);
    }

    private void stopEditing() {
        editing = false;
        if (nameBox != null) {
            nameBox.setFocused(false);
            nameBox.setValue("");
        }
    }

    private void submit() {
        if (nameBox != null) {
            context.requestAdd(nameBox.getValue());
        }
        stopEditing();
    }

    // --- Utilidades de dibujo ---

    private static int argb(float alpha, int rgb) {
        return (Math.round(Mth.clamp(alpha, 0f, 1f) * 255f) << 24) | (rgb & 0xFFFFFF);
    }

    /** La fuente trata alfa < 4 como opaco: se fuerza un mínimo. */
    private static int argbText(float alpha, int rgb) {
        return (Math.max(4, Math.round(Mth.clamp(alpha, 0f, 1f) * 255f)) << 24) | (rgb & 0xFFFFFF);
    }

    private void drawText(GuiGraphics g, Component text, float x, float y, float scale, int argb) {
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, argb, false);
        pose.popPose();
    }

    private static void outline(GuiGraphics g, float x, float y, float w, float h, int argb) {
        fillF(g, x, y, x + w, y + 1f, argb);
        fillF(g, x, y + h - 1f, x + w, y + h, argb);
        fillF(g, x, y + 1f, x + 1f, y + h - 1f, argb);
        fillF(g, x + w - 1f, y + 1f, x + w, y + h - 1f, argb);
    }

    /** Dibuja la textura entera estirada a un rectángulo con coordenadas fraccionarias. */
    private static void blitStretched(GuiGraphics g, ResourceLocation texture, float x, float y, float w, float h,
            int texW, int texH) {
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(w / texW, h / texH, 1f);
        g.blit(texture, 0, 0, 0, 0, texW, texH, texW, texH);
        pose.popPose();
    }

    /** Como {@link GuiGraphics#fill} pero con coordenadas fraccionarias. Se vuelca al momento para respetar el orden. */
    private static void fillF(GuiGraphics g, float x1, float y1, float x2, float y2, int argb) {
        if (x2 <= x1 || y2 <= y1 || (argb >>> 24) == 0) {
            return;
        }
        Matrix4f m = g.pose().last().pose();
        VertexConsumer buf = g.bufferSource().getBuffer(RenderType.gui());
        buf.addVertex(m, x1, y1, 0).setColor(argb);
        buf.addVertex(m, x1, y2, 0).setColor(argb);
        buf.addVertex(m, x2, y2, 0).setColor(argb);
        buf.addVertex(m, x2, y1, 0).setColor(argb);
        g.flush();
    }
}
