package com.railgunreborn.client.screen.developer;

import javax.annotation.Nullable;

import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.client.screen.developer.DevelopTracker.Phase;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;

import net.minecraft.Util;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Panel superpuesto con velo negro ({@code developer.md} 3.5-3.7): base del detalle de habilidad y del panel de
 * subida de nivel. Lleva el fundido, el icono de acción con su aro y, con Developer, la línea de estado y el botón
 * que piden la acción y siguen su progreso.
 */
abstract class ActionOverlay {
    private static final long FADE_MS = 200L;
    private static final float VEIL_ALPHA = 0.7f;
    protected static final float ICON_BOX = 50f;
    protected static final float ICON_SIZE = 27f;
    protected static final float TEXT_TOP = 25f;
    private static final float BUTTON_W = 32f;
    private static final float BUTTON_H = 16f;
    protected static final int DIM_COLOR = 0xAAFFFFFF;
    protected static final int ERROR_COLOR = 0xFFFF5555;
    private static final int SUCCESS_COLOR = 0xFFA1E1FF;

    protected final SkillTreeView view;
    /** Null en modo consulta (sin Developer). */
    @Nullable
    protected final DevelopTracker tracker;
    private final long openTime = Util.getMillis();
    private long closeTime = -1;

    // Rectángulo del botón en unidades locales (centro de pantalla = 0, 0); null = no hay botón.
    @Nullable
    private float[] buttonRect;
    private boolean buttonEnabled;

    ActionOverlay(SkillTreeView view) {
        this.view = view;
        DevelopLink link = view.link();
        this.tracker = link == null ? null : new DevelopTracker(link);
    }

    boolean isGone() {
        return closeTime >= 0 && Util.getMillis() - closeTime >= FADE_MS;
    }

    void close() {
        if (closeTime < 0) {
            closeTime = Util.getMillis();
        }
    }

    /** Ocupado = no se cierra con clic (como el original mientras desarrolla). */
    boolean isBusy() {
        return tracker != null && tracker.isBusy();
    }

    private float fade() {
        long now = Util.getMillis();
        float in = Mth.clamp((now - openTime) / (float) FADE_MS, 0f, 1f);
        if (closeTime < 0) {
            return in;
        }
        return Math.min(in, 1f - Mth.clamp((now - closeTime) / (float) FADE_MS, 0f, 1f));
    }

    // --- Dibujo ---

    final void render(GuiGraphics g, int screenWidth, int screenHeight, float scale, int mouseX, int mouseY) {
        float a = fade();
        var pose = g.pose();
        pose.pushPose();
        pose.translate(0, 0, 300);
        TreeDraw.fill(g, 0f, 0f, screenWidth, screenHeight, ((int) (VEIL_ALPHA * a * 255f)) << 24);
        if (a >= 0.02f) {
            pose.translate(screenWidth / 2f, screenHeight / 2f, 0);
            pose.scale(scale, scale, 1f);
            float lx = (mouseX - screenWidth / 2f) / scale;
            float ly = (mouseY - screenHeight / 2f) / scale;
            buttonRect = null;
            renderContent(g, view.font(), lx, ly, a);
        }
        pose.popPose();
    }

    /** Contenido centrado en (0, 0), en unidades del original. */
    protected abstract void renderContent(GuiGraphics g, Font font, float lx, float ly, float a);

    /** Petición al servidor al pulsar el botón. */
    protected abstract void request(DevelopLink link);

    /**
     * Disco, icono, guía del aro y aro revelado. {@code ring} &lt; 0 = usar el progreso del desarrollo pedido desde
     * este panel (con brillo al completarse).
     */
    protected void drawActionIcon(GuiGraphics g, ResourceLocation icon, float ring, float a) {
        TreeDraw.centered(g, DeveloperTextures.gui("skill_back"), 0f, 0f, ICON_BOX, 1f, 1f, 1f, a);
        TreeDraw.centered(g, icon, 0f, 0f, ICON_SIZE, 1f, 1f, 1f, a);
        ResourceLocation outline = DeveloperTextures.gui("skill_view_outline");
        TreeDraw.centered(g, outline, 0f, 0f, ICON_BOX, 0.2f, 0.2f, 0.2f, 0.6f * a);
        boolean glow = false;
        if (ring < 0f) {
            ring = tracker == null ? 0f : tracker.progress();
            glow = tracker != null && tracker.phase() == Phase.DONE;
        }
        TreeDraw.radial(g, glow ? DeveloperTextures.gui("skill_view_outline_glow") : outline, 0f, 0f, ICON_BOX,
                ring, 1f, 1f, 1f, a);
    }

    /**
     * Línea de estado y botón (3.5/3.7). Antes de pedir: la pregunta y el botón, o el motivo por el que no se puede
     * (botón deshabilitado). Pedido: "Desarrollando..." / "Progreso NN%" con botón de abortar; al terminar,
     * "Desarrollo completado." o el motivo del fallo (y se puede reintentar).
     *
     * @param blocked motivo por el que ahora no se puede (comprobación visual del cliente), o null
     */
    protected void drawStatus(GuiGraphics g, Font font, float y, Component question, @Nullable Component blocked,
            Component buttonLabel, float lx, float ly, float a) {
        if (tracker == null) {
            return;
        }
        Phase phase = tracker.phase();
        Component message;
        int color = DIM_COLOR;
        Component label = buttonLabel;
        boolean showButton = true;
        boolean enabled = blocked == null;
        switch (phase) {
            case WAITING -> {
                message = Component.translatable("railgunreborn.developer.developing");
                showButton = false;
            }
            case DEVELOPING -> {
                message = Component.translatable("railgunreborn.developer.progress",
                        Math.round(tracker.progress() * 100f));
                label = Component.translatable("railgunreborn.developer.abort");
                enabled = true;
            }
            case DONE -> {
                message = Component.translatable("railgunreborn.developer.successful");
                color = SUCCESS_COLOR;
                showButton = false;
            }
            case FAILED -> {
                message = resultText(tracker.result());
                color = ERROR_COLOR;
            }
            default -> {
                message = blocked != null ? blocked : question;
                color = blocked != null ? ERROR_COLOR : DIM_COLOR;
            }
        }
        TreeDraw.text(g, font, message, 0f, y, 1f, TreeDraw.withAlpha(color, a), Align.CENTER);
        if (showButton) {
            drawButton(g, font, y + 13f, label, enabled, lx, ly, a);
        }
    }

    /** Texto de un resultado del servidor; algunos motivos llevan un dato concreto. */
    protected Component resultText(DevelopResult result) {
        return Component.translatable(result.translationKey());
    }

    private void drawButton(GuiGraphics g, Font font, float y, Component label, boolean enabled, float lx, float ly,
            float a) {
        float x = -BUTTON_W / 2f;
        boolean hovered = enabled && lx >= x && lx < x + BUTTON_W && ly >= y && ly < y + BUTTON_H;
        float tint = !enabled ? 0.35f : hovered ? 1f : 0.6f;
        TreeDraw.texture(g, DeveloperTextures.gui("button"), x, y, BUTTON_W, BUTTON_H, tint, tint, tint,
                enabled ? a : 0.6f * a);
        float labelScale = Math.min(0.55f, 16f / Math.max(1, font.width(label)));
        TreeDraw.text(g, font, label, x + 22f, y + (BUTTON_H - 8f * labelScale) / 2f, labelScale,
                TreeDraw.withAlpha(0x2A2A2A, a), Align.CENTER);
        buttonRect = new float[] {x, y, x + BUTTON_W, y + BUTTON_H};
        buttonEnabled = enabled;
    }

    // --- Entrada ---

    void mouseClicked(double mouseX, double mouseY, int screenWidth, int screenHeight, float scale) {
        if (closeTime >= 0) {
            return;
        }
        float lx = (float) ((mouseX - screenWidth / 2f) / scale);
        float ly = (float) ((mouseY - screenHeight / 2f) / scale);
        float[] rect = buttonRect;
        if (tracker != null && rect != null && lx >= rect[0] && lx < rect[2] && ly >= rect[1] && ly < rect[3]) {
            if (buttonEnabled) {
                if (tracker.phase() == Phase.DEVELOPING) {
                    tracker.abort();
                } else if (!tracker.isBusy()) {
                    tracker.send(() -> request(view.link()));
                }
            }
            return;
        }
        if (isBusy()) {
            return; // como el original: no se cierra con clic mientras desarrolla
        }
        close();
    }
}
