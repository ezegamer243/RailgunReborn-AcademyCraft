package com.railgunreborn.client.screen;

import com.railgunreborn.block.TechUiLayout;

import static com.railgunreborn.block.TechUiLayout.ART_SHIFT_Y;
import static com.railgunreborn.block.TechUiLayout.ART_TINT;
import static com.railgunreborn.block.TechUiLayout.BACKDROP;
import static com.railgunreborn.block.TechUiLayout.GLOW_ALPHA;
import static com.railgunreborn.block.TechUiLayout.LINE_ALPHA;
import static com.railgunreborn.block.TechUiLayout.LINE_RGB;
import static com.railgunreborn.block.TechUiLayout.SLOT_FILL;
import static com.railgunreborn.block.TechUiLayout.SLOT_PITCH;
import static com.railgunreborn.block.TechUiLayout.TEX_H;
import static com.railgunreborn.block.TechUiLayout.TEX_W;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/**
 * Estilo de las interfaces de AcademyCraft: panel oscuro translúcido y arte de líneas blancas con alfa, teñido de
 * blanco celeste, con un brillo suave alrededor. Lo comparten el Imag Fusor, el Metal Former y el reactor.
 * <p>
 * El arte del original es de doble resolución: se dibuja en un "espacio de textura" (escala 0.5) para no perder el
 * medio píxel de sus líneas y brillos. Los marcos propios se dibujan igual, así se parecen al arte.
 * <p>
 * Ojo: {@code GuiGraphics.blit} no activa la mezcla de alfa (las texturas vanilla son opacas); sin
 * {@link #begin()} los píxeles semitransparentes salen opacos (blanco macizo sobre negro).
 */
public final class AcStyle {
    private static final float TINT_A = (ART_TINT >>> 24) / 255f;
    private static final float TINT_R = (ART_TINT >> 16 & 0xFF) / 255f;
    private static final float TINT_G = (ART_TINT >> 8 & 0xFF) / 255f;
    private static final float TINT_B = (ART_TINT & 0xFF) / 255f;

    private AcStyle() {
    }

    /** Activa la mezcla de alfa para todo lo que sigue; cerrar con {@link #end()}. */
    public static void begin() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    /**
     * {@code GuiGraphics.blit} con la mezcla de alfa activada justo antes. Hace falta en cada dibujo: {@code fill} va
     * por {@code RenderType.gui()} y, al vaciarse, su estado de transparencia apaga la mezcla; el blit siguiente salía
     * opaco (arte blanco macizo y fondo negro, captura del usuario 2026-10-10).
     */
    public static void blit(GuiGraphics graphics, ResourceLocation texture, int x, int y, int width, int height,
            float u, float v, int uWidth, int vHeight, int texW, int texH) {
        begin();
        graphics.blit(texture, x, y, width, height, u, v, uWidth, vHeight, texW, texH);
    }

    /** Como {@link #blit(GuiGraphics, ResourceLocation, int, int, int, int, float, float, int, int, int, int)}. */
    public static void blit(GuiGraphics graphics, ResourceLocation texture, int x, int y, float u, float v, int width,
            int height, int texW, int texH) {
        begin();
        graphics.blit(texture, x, y, u, v, width, height, texW, texH);
    }

    public static void end() {
        RenderSystem.disableBlend();
    }

    /**
     * Abre el espacio de textura del arte con origen en (x, y) de la GUI: 1 unidad = medio píxel de GUI, medio píxel
     * más arriba ({@code TechUiLayout.ART_SHIFT_Y}). Cerrar con {@link #popSpace}.
     */
    public static void pushArtSpace(GuiGraphics graphics, int x, int y) {
        graphics.pose().pushPose();
        graphics.pose().translate(x, y + ART_SHIFT_Y, 0);
        graphics.pose().scale(0.5f, 0.5f, 1f);
    }

    public static void popSpace(GuiGraphics graphics) {
        graphics.pose().popPose();
    }

    /** Tiñe lo que se dibuje con blit hasta {@link #untint}; {@code brightness} oscurece (flechas sin el ratón). */
    public static void tint(GuiGraphics graphics, float brightness) {
        graphics.setColor(TINT_R * brightness, TINT_G * brightness, TINT_B * brightness, TINT_A);
    }

    public static void untint(GuiGraphics graphics) {
        graphics.setColor(1f, 1f, 1f, 1f);
    }

    /** Fondo: velo oscuro + el fondo del original (negro al 50 % con las barras de arriba y abajo), sin teñir. */
    public static void panel(GuiGraphics graphics, ResourceLocation background, int x, int y, int w, int h) {
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, BACKDROP);
        graphics.pose().pushPose();
        graphics.pose().translate(x, y, 0);
        graphics.pose().scale(0.5f, 0.5f, 1f);
        blit(graphics, background, 0, 0, w * 2, h * 2, 0, 0, TEX_W, TEX_H, TEX_W, TEX_H);
        graphics.pose().popPose();
    }

    /** Una capa de arte a pantalla completa (en el espacio de {@link #pushArtSpace}). */
    public static void layer(GuiGraphics graphics, ResourceLocation texture) {
        blit(graphics, texture, 0, 0, 0, 0, TEX_W, TEX_H, TEX_W, TEX_H);
    }

    /**
     * Cuadrícula de ranuras propia: celdas de 18 px que comparten la línea, con la esquina superior izquierda de la
     * primera ranura en (x, y) de la GUI. Las líneas quedan fuera de la zona del ítem y de su número.
     */
    public static void slotGrid(GuiGraphics graphics, int x, int y, int cols, int rows) {
        int left = x - 1;
        int top = y - 1;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int cx = left + 1 + c * SLOT_PITCH;
                int cy = top + 1 + r * SLOT_PITCH;
                graphics.fill(cx, cy, cx + SLOT_PITCH - 1, cy + SLOT_PITCH - 1, SLOT_FILL);
            }
        }
        int right = left + cols * SLOT_PITCH;
        int bottom = top + rows * SLOT_PITCH;
        graphics.pose().pushPose();
        graphics.pose().scale(0.5f, 0.5f, 1f);
        for (int c = 0; c <= cols; c++) {
            vLine(graphics, 2 * (left + c * SLOT_PITCH), 2 * top, 2 * bottom + 2);
        }
        for (int r = 0; r <= rows; r++) {
            hLine(graphics, 2 * left, 2 * right + 2, 2 * (top + r * SLOT_PITCH));
        }
        graphics.pose().popPose();
    }

    /**
     * Barra de energía horizontal: fondo oscuro, relleno de izquierda a derecha ({@code fill} de 0 a 1) y marco con
     * brillo alrededor de {@code bar} (coordenadas absolutas de pantalla). Usa solo {@code fill}: no hace blit.
     */
    public static void energyBar(GuiGraphics graphics, TechUiLayout.Rect bar, float fill) {
        graphics.fill(bar.x(), bar.y(), bar.x() + bar.w(), bar.y() + bar.h(), SLOT_FILL);
        int w = Math.round(bar.w() * Math.max(0f, Math.min(1f, fill)));
        if (w > 0) {
            graphics.fill(bar.x(), bar.y(), bar.x() + w, bar.y() + bar.h(), TechUiLayout.ENERGY_FILL);
        }
        frame(graphics, bar.x() - 1, bar.y() - 1, bar.w() + 2, bar.h() + 2);
    }

    /** Marco con brillo en el borde del rectángulo (x, y, w, h) de la GUI. */
    public static void frame(GuiGraphics graphics, int x, int y, int w, int h) {
        graphics.pose().pushPose();
        graphics.pose().scale(0.5f, 0.5f, 1f);
        vLine(graphics, 2 * x, 2 * y, 2 * (y + h));
        vLine(graphics, 2 * (x + w - 1), 2 * y, 2 * (y + h));
        hLine(graphics, 2 * x, 2 * (x + w), 2 * y);
        hLine(graphics, 2 * x, 2 * (x + w), 2 * (y + h - 1));
        graphics.pose().popPose();
    }

    /** Línea vertical de 2 px de textura en tx, de ty0 a ty1, con brillo a ambos lados. */
    private static void vLine(GuiGraphics graphics, int tx, int ty0, int ty1) {
        graphics.fill(tx, ty0, tx + 2, ty1, LINE_ALPHA << 24 | LINE_RGB);
        for (int i = 0; i < GLOW_ALPHA.length; i++) {
            int color = GLOW_ALPHA[i] << 24 | LINE_RGB;
            graphics.fill(tx - 1 - i, ty0, tx - i, ty1, color);
            graphics.fill(tx + 2 + i, ty0, tx + 3 + i, ty1, color);
        }
    }

    private static void hLine(GuiGraphics graphics, int tx0, int tx1, int ty) {
        graphics.fill(tx0, ty, tx1, ty + 2, LINE_ALPHA << 24 | LINE_RGB);
        for (int i = 0; i < GLOW_ALPHA.length; i++) {
            int color = GLOW_ALPHA[i] << 24 | LINE_RGB;
            graphics.fill(tx0, ty - 1 - i, tx1, ty - i, color);
            graphics.fill(tx0, ty + 2 + i, tx1, ty + 3 + i, color);
        }
    }
}
