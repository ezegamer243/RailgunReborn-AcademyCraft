package com.railgunreborn.client.screen;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.PhaseGenBlockEntity;
import com.railgunreborn.block.PhaseGenMenu;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** Pantalla del generador de fase en el estilo de {@link AcStyle}: producción, depósito, energía y 3 ranuras. */
public class PhaseGenScreen extends AbstractContainerScreen<PhaseGenMenu> {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");
    private static final int BAR_X = 18;
    private static final int BAR_W = 140;
    private static final int BAR_H = 12;
    private static final int TANK_Y = 22;
    private static final int ENERGY_Y = 48;

    public PhaseGenScreen(PhaseGenMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    private static boolean over(int rx, int ry, int x, int y, int w, int h) {
        return rx >= x && rx < x + w && ry >= y && ry < y + h;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (over(rx, ry, BAR_X, TANK_Y, BAR_W, BAR_H)) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.phase_gen.tank",
                    menu.getTankAmount(), PhaseGenBlockEntity.TANK_CAPACITY), mouseX, mouseY);
        } else if (over(rx, ry, BAR_X, ENERGY_Y, BAR_W, BAR_H)) {
            graphics.renderTooltip(font, Component.literal(EnergyFormat.fraction(menu.getEnergy(),
                    PhaseGenBlockEntity.CAPACITY)), mouseX, mouseY);
        } else if (menu.getCarried().isEmpty()) {
            emptySlotTooltip(graphics, rx, ry, mouseX, mouseY, PhaseGenMenu.UNIT_IN_X,
                    PhaseGenBlockEntity.SLOT_UNIT_IN, "unit_in");
            emptySlotTooltip(graphics, rx, ry, mouseX, mouseY, PhaseGenMenu.UNIT_OUT_X,
                    PhaseGenBlockEntity.SLOT_UNIT_OUT, "unit_out");
            emptySlotTooltip(graphics, rx, ry, mouseX, mouseY, PhaseGenMenu.BATTERY_X,
                    PhaseGenBlockEntity.SLOT_BATTERY, "battery");
        }
    }

    private void emptySlotTooltip(GuiGraphics graphics, int rx, int ry, int mouseX, int mouseY, int slotX, int slot,
            String key) {
        if (over(rx, ry, slotX, PhaseGenMenu.SLOTS_Y, 16, 16) && !menu.slots.get(slot).hasItem()) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.phase_gen." + key), mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        int fill = Math.round(BAR_W * EnergyMath.fill(menu.getTankAmount(), PhaseGenBlockEntity.TANK_CAPACITY));
        if (fill > 0) {
            graphics.fill(x + BAR_X, y + TANK_Y, x + BAR_X + fill, y + TANK_Y + BAR_H, TechUiLayout.TANK_FILL);
        }
        AcStyle.frame(graphics, x + BAR_X, y + TANK_Y, BAR_W, BAR_H);
        AcStyle.energyBar(graphics, new TechUiLayout.Rect(x + BAR_X, y + ENERGY_Y, BAR_W, BAR_H),
                EnergyMath.fill(menu.getEnergy(), PhaseGenBlockEntity.CAPACITY));

        AcStyle.slotGrid(graphics, x + PhaseGenMenu.UNIT_IN_X, y + PhaseGenMenu.SLOTS_Y, 1, 1);
        AcStyle.slotGrid(graphics, x + PhaseGenMenu.BATTERY_X, y + PhaseGenMenu.SLOTS_Y, 1, 1);
        AcStyle.slotGrid(graphics, x + PhaseGenMenu.UNIT_OUT_X, y + PhaseGenMenu.SLOTS_Y, 1, 1);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);

        center(graphics, Component.translatable("gui.railgunreborn.phase_gen.output", menu.getOutput()), y + 8);
        center(graphics, Component.translatable("gui.railgunreborn.phase_gen.tank", menu.getTankAmount(),
                PhaseGenBlockEntity.TANK_CAPACITY), y + TANK_Y + BAR_H + 3);
        center(graphics, Component.literal(EnergyFormat.fraction(menu.getEnergy(), PhaseGenBlockEntity.CAPACITY)),
                y + ENERGY_Y + BAR_H + 3);
        AcStyle.end();
    }

    private void center(GuiGraphics graphics, Component text, int y) {
        graphics.drawString(font, text, leftPos + imageWidth / 2 - font.width(text) / 2, y, TechUiLayout.TEXT, false);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }
}
