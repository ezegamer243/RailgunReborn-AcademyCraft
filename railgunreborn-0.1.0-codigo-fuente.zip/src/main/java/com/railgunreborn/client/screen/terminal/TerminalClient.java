package com.railgunreborn.client.screen.terminal;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.ModKeys;
import com.railgunreborn.terminal.TerminalAccess;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Tecla del Terminal en el juego (con el Terminal abierto la cierra {@link TerminalScreen}). */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class TerminalClient {
    private TerminalClient() {
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        while (ModKeys.OPEN_TERMINAL.consumeClick()) {
            if (player == null || mc.screen != null) {
                continue;
            }
            if (TerminalAccess.isInstalled(player)) {
                mc.setScreen(new TerminalScreen());
            } else {
                player.displayClientMessage(Component.translatable("railgunreborn.terminal.not_installed"), false);
            }
        }
    }
}
