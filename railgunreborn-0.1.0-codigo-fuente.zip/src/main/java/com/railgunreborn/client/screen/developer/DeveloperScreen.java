package com.railgunreborn.client.screen.developer;

import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopSession;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.network.DevelopActionPayload;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Pantalla del Developer ({@code developer.md} sección 3) para {@link DeveloperMenu}. Sin ranuras, sin inventario
 * ni título vanilla: todo lo dibuja {@link SkillTreeView}, que no depende del menú (lo reutiliza el modo consulta).
 */
public class DeveloperScreen extends AbstractContainerScreen<DeveloperMenu> {
    private final SkillTreeView view;

    public DeveloperScreen(DeveloperMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = (int) SkillTreeView.MAIN_W;
        this.imageHeight = (int) SkillTreeView.MAIN_H;
        this.view = new SkillTreeView(inventory.player, menu.getDeveloperType(), new MenuLink(menu));
    }

    @Override
    protected void init() {
        super.init();
        view.resize(width, height);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Sin super.render: no hay ranuras, etiquetas ni tooltips de inventario. Sin desenfoque de fondo.
        renderTransparentBackground(g);
        view.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // No se delega en AbstractContainerScreen: un clic "fuera" mandaría un clic de ranura -999 al servidor.
        view.mouseClicked(mouseX, mouseY, button);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // ESC siempre cierra (y cerrar cancela el desarrollo en el servidor); el resto puede ir a la consola.
        if (keyCode != GLFW.GLFW_KEY_ESCAPE && view.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        return view.charTyped(codePoint, modifiers) || super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return true;
    }

    /** Estado del desarrollo leído del {@code ContainerData} del menú. */
    private record MenuLink(DeveloperMenu menu) implements DevelopLink {
        @Override
        public DevelopSession.State state() {
            return menu.getState();
        }

        @Override
        public float progress() {
            return menu.getProgress();
        }

        @Override
        public DevelopResult result() {
            return menu.getResult();
        }

        @Override
        public int energy() {
            return menu.getEnergy();
        }

        @Override
        public boolean energyRequired() {
            return menu.isEnergyRequired();
        }

        @Override
        public int attempt() {
            return menu.getAttempt();
        }

        @Override
        public void startSkill(ResourceLocation skill) {
            PacketDistributor.sendToServer(DevelopActionPayload.startSkill(menu.containerId, skill));
        }

        @Override
        public void startLevel() {
            PacketDistributor.sendToServer(DevelopActionPayload.startLevel(menu.containerId));
        }

        @Override
        public void startCategory(ResourceLocation category) {
            PacketDistributor.sendToServer(DevelopActionPayload.startCategory(menu.containerId, category));
        }

        @Override
        public void abort() {
            PacketDistributor.sendToServer(DevelopActionPayload.abort(menu.containerId));
        }
    }
}
