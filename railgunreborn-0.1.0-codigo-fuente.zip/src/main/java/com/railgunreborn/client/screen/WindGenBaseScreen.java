package com.railgunreborn.client.screen;

import java.util.Locale;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.block.WindGenBaseBlockEntity;
import com.railgunreborn.block.WindGenBaseMenu;
import com.railgunreborn.block.WindGenRules;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.energy.EnergyMath;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla de la base del generador eólico con el arte del original ({@code ui_windbase}): en el recuadro, los
 * iconos de cabeza / pilares / base encendidos según lo que esté bien; a la izquierda el estado y la producción; a
 * la derecha pilares y altura; abajo la ranura de batería (caja "OUT") y la barra de energía.
 */
public class WindGenBaseScreen extends AbstractContainerScreen<WindGenBaseMenu> {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");
    private static final ResourceLocation ART = WindGenScreens.tex("ui_windbase");
    private static final ResourceLocation ICON_MAIN = WindGenScreens.tex("icon_wind_main");
    private static final ResourceLocation ICON_MIDDLE = WindGenScreens.tex("icon_wind_middle");
    private static final ResourceLocation ICON_BASE = WindGenScreens.tex("icon_wind_base");

    // Iconos del original (page_windbase): 24x24, centrados, en y = 13 / 31 / 49.
    private static final int ICON_X = (TechUiLayout.WIDTH - 24) / 2;
    private static final int[] ICON_Y = { 13, 31, 49 };
    /** Columnas de texto a los lados del recuadro del arte (que va de x=60 a x=115). */
    private static final int LEFT_X = 5;
    private static final int RIGHT_X = 119;
    private static final int COLUMN_W = 53;
    private static final int TEXT_Y = 16;

    public WindGenBaseScreen(WindGenBaseMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = TechUiLayout.WIDTH;
        imageHeight = TechUiLayout.HEIGHT;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (TechUiLayout.ENERGY_BAR.contains(new TechUiLayout.Rect(rx, ry, 1, 1))) {
            graphics.renderTooltip(font, Component.literal(EnergyFormat.fraction(menu.getEnergy(),
                    WindGenRules.CAPACITY)), mouseX, mouseY);
        } else if (rx >= WindGenBaseMenu.BATTERY_X && rx < WindGenBaseMenu.BATTERY_X + 16
                && ry >= WindGenBaseMenu.BATTERY_Y && ry < WindGenBaseMenu.BATTERY_Y + 16
                && menu.getCarried().isEmpty() && !menu.slots.get(WindGenBaseBlockEntity.SLOT_BATTERY).hasItem()) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.wind_gen.battery"), mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        WindGenRules.Status status = menu.getStatus();
        int pillars = menu.getPillars();
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        AcStyle.pushArtSpace(graphics, x, y);
        AcStyle.tint(graphics, 1f);
        AcStyle.layer(graphics, ART);
        AcStyle.untint(graphics);
        AcStyle.popSpace(graphics);

        boolean pillarsOk = pillars >= WindGenRules.MIN_PILLARS && pillars <= WindGenRules.MAX_PILLARS;
        icon(graphics, ICON_MAIN, ICON_Y[0], status.structureComplete());
        icon(graphics, ICON_MIDDLE, ICON_Y[1], pillarsOk);
        icon(graphics, ICON_BASE, ICON_Y[2], true);

        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + TechUiLayout.INV_X, y + TechUiLayout.HOTBAR_Y, 9, 1);
        TechUiLayout.Rect bar = TechUiLayout.ENERGY_BAR;
        AcStyle.energyBar(graphics, new TechUiLayout.Rect(x + bar.x(), y + bar.y(), bar.w(), bar.h()),
                EnergyMath.fill(menu.getEnergy(), WindGenRules.CAPACITY));

        int line = column(graphics, statusText(status), LEFT_X, TEXT_Y, WindGenScreens.statusColor(status));
        if (status == WindGenRules.Status.WORKING) {
            column(graphics, Component.translatable("gui.railgunreborn.wind_gen.output",
                    WindGenRules.formatCenti(menu.getOutputCenti())), LEFT_X, line + 3, TechUiLayout.TEXT);
        }
        int right = column(graphics, Component.translatable("gui.railgunreborn.wind_gen.pillars", pillars,
                WindGenRules.MIN_PILLARS, WindGenRules.MAX_PILLARS), RIGHT_X, TEXT_Y, TechUiLayout.TEXT);
        int height = menu.getHeight();
        if (height != WindGenBaseBlockEntity.NO_HEIGHT) {
            column(graphics, Component.translatable("gui.railgunreborn.wind_gen.height", height), RIGHT_X, right + 3,
                    TechUiLayout.TEXT);
        }
        AcStyle.end();
    }

    static Component statusText(WindGenRules.Status status) {
        return Component.translatable("gui.railgunreborn.wind_gen.status." + status.name().toLowerCase(Locale.ROOT));
    }

    private void icon(GuiGraphics graphics, ResourceLocation texture, int iconY, boolean lit) {
        AcStyle.tint(graphics, lit ? 1f : 0.3f);
        AcStyle.blit(graphics, texture, leftPos + ICON_X, topPos + iconY, 24, 24, 0, 0, 48, 48, 48, 48);
        AcStyle.untint(graphics);
    }

    /** Texto partido en líneas de {@link #COLUMN_W}; devuelve la y de debajo de la última línea. */
    private int column(GuiGraphics graphics, Component text, int columnX, int lineY, int color) {
        int yy = topPos + lineY;
        for (FormattedCharSequence seq : font.split(text, COLUMN_W)) {
            graphics.drawString(font, seq, leftPos + columnX, yy, color, false);
            yy += font.lineHeight;
        }
        return yy - topPos;
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
    }
}
