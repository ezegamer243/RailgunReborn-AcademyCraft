package com.railgunreborn.client.screen.developer;

import java.util.Optional;

import javax.annotation.Nullable;

import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.client.screen.developer.TreeDraw.Align;
import com.railgunreborn.energy.EnergyFormat;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * Panel de subida de nivel ({@code developer.md} 3.6): icono "alguna habilidad de nivel N+1", "Subir a Nivel N+1",
 * coste en estímulos (sin energía) y "¿Continuar?" con el botón; mismos estados que el detalle de habilidad.
 */
final class LevelUpOverlay extends ActionOverlay {
    /** Nivel al abrir: tras subir, el panel sigue hablando del mismo paso hasta cerrarlo. */
    private final int fromLevel;

    LevelUpOverlay(SkillTreeView view) {
        super(view);
        this.fromLevel = AbilityData.get(view.player()).getLevel();
    }

    @Override
    protected void renderContent(GuiGraphics g, Font font, float lx, float ly, float a) {
        int target = fromLevel + 1;
        drawActionIcon(g, DeveloperTextures.gui("condition_any" + Mth.clamp(target, 1, 5)), -1f, a);

        float y = TEXT_TOP;
        Component title = Component.translatable("railgunreborn.developer.uplevel",
                Component.translatable("railgunreborn.level." + Mth.clamp(target, 0, DevelopRules.MAX_LEVEL)))
                .withStyle(ChatFormatting.BOLD);
        TreeDraw.text(g, font, title, 0f, y, 1.2f, TreeDraw.withAlpha(0xFFFFFF, a), Align.CENTER);
        y += 14f;
        Component cost = Component.translatable("railgunreborn.developer.level_cost",
                DevelopRules.stimsForLevelAction(fromLevel));
        TreeDraw.text(g, font, cost, 0f, y, 0.9f, TreeDraw.withAlpha(DIM_COLOR, a), Align.CENTER);
        y += 13f;
        DevelopLink link = view.link();
        Component question = link != null && link.energyRequired() && view.developerType() != null
                ? Component.translatable("railgunreborn.developer.level_question_energy", EnergyFormat.number(
                        view.developerType().energyForStims(DevelopRules.stimsForLevelAction(fromLevel))))
                : Component.translatable("railgunreborn.developer.level_question");
        drawStatus(g, font, y, question, blockedReason(),
                Component.translatable("railgunreborn.developer.upgrade"), lx, ly, a);
    }

    /** Misma regla que el servidor ({@code DevelopAction.level().check}), solo visual. */
    @Nullable
    private Component blockedReason() {
        AbilityData data = AbilityData.get(view.player());
        Optional<Category> category = AbilityRegistries.category(data.getCategory().orElse(null));
        float fraction = category.map(c -> c.levelProgressFraction(data.getLevel(), data.getLevelProgress()))
                .orElse(0f);
        DevelopResult check = DevelopRules.checkLevelAction(data.hasCategory(), data.getLevel(), fraction);
        return check.isOk() ? null : resultText(check);
    }

    @Override
    protected void request(DevelopLink link) {
        link.startLevel();
    }
}
