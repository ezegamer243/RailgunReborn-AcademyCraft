package com.railgunreborn.client.screen.developer;

import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

/**
 * Primitivas de dibujo con coordenadas fraccionarias (unidades de diseño del original) para la pantalla del Developer
 * (también las usa el Terminal).
 */
public final class TreeDraw {
    /** Segmentos de una vuelta completa del aro de progreso. */
    private static final int RING_SEGMENTS = 64;

    public enum Align {
        LEFT, CENTER, RIGHT
    }

    private TreeDraw() {
    }

    /** Textura entera estirada a (x, y, w, h), teñida con (r, g, b) y alfa {@code a}. */
    public static void texture(GuiGraphics g, ResourceLocation tex, float x, float y, float w, float h, float r,
            float gr, float b, float a) {
        quad(g, tex, x, y, w, h, 0f, 0f, 1f, 1f, r, gr, b, a);
    }

    public static void texture(GuiGraphics g, ResourceLocation tex, float x, float y, float w, float h, float a) {
        quad(g, tex, x, y, w, h, 0f, 0f, 1f, 1f, 1f, 1f, 1f, a);
    }

    /** Textura centrada en (cx, cy) de tamaño {@code size}. */
    public static void centered(GuiGraphics g, ResourceLocation tex, float cx, float cy, float size, float r, float gr,
            float b, float a) {
        quad(g, tex, cx - size / 2f, cy - size / 2f, size, size, 0f, 0f, 1f, 1f, r, gr, b, a);
    }

    public static void quad(GuiGraphics g, ResourceLocation tex, float x, float y, float w, float h, float u0, float v0,
            float u1, float v1, float r, float gr, float b, float a) {
        if (a <= 0.004f || w <= 0f || h <= 0f) {
            return;
        }
        g.flush(); // respeta el orden con lo que GuiGraphics tenga en cola
        begin(tex);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS,
                DefaultVertexFormat.POSITION_TEX_COLOR);
        buf.addVertex(m, x, y, 0).setUv(u0, v0).setColor(r, gr, b, a);
        buf.addVertex(m, x, y + h, 0).setUv(u0, v1).setColor(r, gr, b, a);
        buf.addVertex(m, x + w, y + h, 0).setUv(u1, v1).setColor(r, gr, b, a);
        buf.addVertex(m, x + w, y, 0).setUv(u1, v0).setColor(r, gr, b, a);
        BufferUploader.drawWithShader(buf.buildOrThrow());
    }

    /**
     * Textura cuadrada centrada en (cx, cy) revelada en abanico desde arriba (las 12) en sentido horario hasta
     * {@code progress} (0..1). Sustituye al shader {@code skill_progbar} (máscara angular) del original.
     */
    public static void radial(GuiGraphics g, ResourceLocation tex, float cx, float cy, float size, float progress,
            float r, float gr, float b, float a) {
        float p = Mth.clamp(progress, 0f, 1f);
        if (p <= 0f || a <= 0.004f) {
            return;
        }
        g.flush();
        begin(tex);
        RenderSystem.disableCull();
        int segments = Math.max(1, Mth.ceil(RING_SEGMENTS * p));
        float step = p * Mth.TWO_PI / segments;
        // Radio un poco mayor que medio lado para que las cuerdas del polígono no corten el aro.
        float radius = size / 2f / Mth.cos(Mth.PI / RING_SEGMENTS);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLES,
                DefaultVertexFormat.POSITION_TEX_COLOR);
        for (int i = 0; i < segments; i++) {
            float a0 = -Mth.HALF_PI + i * step;
            float a1 = a0 + step;
            buf.addVertex(m, cx, cy, 0).setUv(0.5f, 0.5f).setColor(r, gr, b, a);
            ringVertex(buf, m, cx, cy, size, radius, a0, r, gr, b, a);
            ringVertex(buf, m, cx, cy, size, radius, a1, r, gr, b, a);
        }
        BufferUploader.drawWithShader(buf.buildOrThrow());
        RenderSystem.enableCull();
    }

    private static void ringVertex(BufferBuilder buf, Matrix4f m, float cx, float cy, float size, float radius,
            float angle, float r, float gr, float b, float a) {
        float ox = Mth.cos(angle) * radius;
        float oy = Mth.sin(angle) * radius;
        buf.addVertex(m, cx + ox, cy + oy, 0).setUv(0.5f + ox / size, 0.5f + oy / size).setColor(r, gr, b, a);
    }

    /** Segmento texturizado de (x0, y0) a (x1, y1) de ancho {@code width}; U a lo largo, V a lo ancho. */
    public static void line(GuiGraphics g, ResourceLocation tex, float x0, float y0, float x1, float y1, float width,
            float a) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float len = Mth.sqrt(dx * dx + dy * dy);
        if (len <= 0.01f || a <= 0.004f) {
            return;
        }
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x0, y0, 0);
        pose.mulPose(Axis.ZP.rotation((float) Math.atan2(dy, dx)));
        quad(g, tex, 0f, -width / 2f, len, width, 0f, 0f, 1f, 1f, 1f, 1f, 1f, a);
        pose.popPose();
    }

    /** Rectángulo de color liso con coordenadas fraccionarias. */
    public static void fill(GuiGraphics g, float x, float y, float w, float h, int argb) {
        if ((argb >>> 24) == 0 || w <= 0f || h <= 0f) {
            return;
        }
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(w / 1000f, h / 1000f, 1f);
        g.fill(0, 0, 1000, 1000, argb);
        pose.popPose();
        g.flush();
    }

    /** Texto con escala; {@code x} es el borde izquierdo, el centro o el borde derecho según {@code align}. */
    public static void text(GuiGraphics g, Font font, Component text, float x, float y, float scale, int argb,
            Align align) {
        text(g, font, text.getVisualOrderText(), x, y, scale, argb, align);
    }

    public static void text(GuiGraphics g, Font font, FormattedCharSequence text, float x, float y, float scale,
            int argb, Align align) {
        float w = font.width(text) * scale;
        float left = switch (align) {
            case LEFT -> x;
            case CENTER -> x - w / 2f;
            case RIGHT -> x - w;
        };
        var pose = g.pose();
        pose.pushPose();
        pose.translate(left, y, 0);
        pose.scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, argb, false);
        pose.popPose();
    }

    /** ARGB con el alfa multiplicado; la fuente trata alfa < 4 como opaco, así que se fuerza un mínimo. */
    public static int withAlpha(int rgb, float alpha) {
        int a = Math.max(4, Math.round(Mth.clamp(alpha, 0f, 1f) * ((rgb >>> 24) == 0 ? 255 : (rgb >>> 24))));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static void begin(ResourceLocation tex) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, tex);
    }
}
