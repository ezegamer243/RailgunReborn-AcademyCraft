package com.railgunreborn.client.screen;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.WindGenRules;

import net.minecraft.resources.ResourceLocation;

/** Lo común de las dos pantallas del generador eólico: texturas del original y color del estado. */
final class WindGenScreens {
    private WindGenScreens() {
    }

    static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/wind_gen/" + name + ".png");
    }

    /** Verde si produce, ámbar si solo falta algo (aspas o aire), rojo si la estructura está mal. */
    static int statusColor(WindGenRules.Status status) {
        return switch (status) {
            case WORKING -> 0xFF9CFFB0;
            case NO_FAN, BLOCKED -> 0xFFFFD27F;
            default -> 0xFFFF9A8A;
        };
    }
}
