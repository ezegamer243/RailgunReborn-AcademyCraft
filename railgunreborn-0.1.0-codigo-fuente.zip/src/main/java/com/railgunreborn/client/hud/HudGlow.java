package com.railgunreborn.client.hud;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;

/** Brillo alrededor de un rectángulo con degradados (sustituye a las texturas {@code glow_*} del original). */
public final class HudGlow {
    private HudGlow() {
    }

    /**
     * Dibuja un marco de {@code spread} unidades alrededor de (x, y, w, h), opaco junto al borde y transparente por
     * fuera. {@code argb} lleva el alfa máximo. Las esquinas se cubren con los tramos laterales.
     */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int spread, int argb) {
        if ((argb >>> 24) == 0) {
            return;
        }
        int clear = argb & 0x00FFFFFF;
        // Arriba y abajo (incluyen las esquinas, ensanchados en spread a cada lado).
        g.fillGradient(x - spread, y - spread, x + w + spread, y, clear, argb);
        g.fillGradient(x - spread, y + h, x + w + spread, y + h + spread, argb, clear);
        // Laterales: fillGradient es solo vertical, así que se hace el degradado horizontal a mano.
        horizontal(g, x - spread, y, x, h, clear, argb);
        horizontal(g, x + w, y, x + w + spread, h, argb, clear);
    }

    private static void horizontal(GuiGraphics g, int x1, int y, int x2, int h, int left, int right) {
        Matrix4f m = g.pose().last().pose();
        VertexConsumer buf = g.bufferSource().getBuffer(RenderType.gui());
        buf.addVertex(m, x1, y, 0).setColor(left);
        buf.addVertex(m, x1, y + h, 0).setColor(left);
        buf.addVertex(m, x2, y + h, 0).setColor(right);
        buf.addVertex(m, x2, y, 0).setColor(right);
    }
}
