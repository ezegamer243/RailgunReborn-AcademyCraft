package com.railgunreborn.client.hud;

import java.util.Optional;

import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;

import net.minecraft.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Barra de CP y overload (port de {@code cn.academy.client.auxgui.CPBar}). Ver {@code docs/spec/hud-cpbar.md}.
 *
 * <p>Todo el dibujo se hace en "píxeles de diseño" (la textura mide 964x147) con la pose escalada a 0.2, igual que
 * el widget original. Los shaders del original se sustituyen por texturas horneadas ({@link CPBarTextures}).
 * Solo cliente: se registra desde el bus del mod con {@code Dist.CLIENT}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class CPBarHud {
    public static final ResourceLocation LAYER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "cp_bar");

    private static final float WIDTH = CPBarTextures.WIDTH;
    private static final float HEIGHT = CPBarTextures.HEIGHT;
    private static final float SCALE = 0.2f;
    private static final float MARGIN_RIGHT = 12;
    private static final float MARGIN_TOP = 12;

    private static final float BALANCE_SPEED = 2.0f; // fracciones de barra por segundo
    private static final long BLEND_MS = 200L;
    private static final double SIN_44 = Math.sin(Math.toRadians(44.0));

    // Tramos (progreso, ARGB) con interpolación lineal, como ProgColor del original.
    private static final float[] CP_PROG = {0.0f, 0.35f, 1.0f};
    private static final int[] CP_COLORS = {0xFFF06767, 0xFFFFAE44, 0xFFFFFFFF};
    private static final float[] OVERLOAD_PROG = {0.0f, 0.55f, 1.0f};
    private static final int[] OVERLOAD_COLORS = {0x0ADFDFDF, 0x23F0D49D, 0x50F56464};

    // Estado de animación (solo hilo de render).
    private static boolean lastFrameActive;
    private static long showTime;
    private static long lastDrawTime;
    private static float bufferedCP;
    private static float bufferedOverload;
    private static boolean showingNumbers;
    private static long lastShowValueChange;
    private static float consumptionHint;

    private CPBarHud() {
    }

    @SubscribeEvent
    public static void registerLayer(RegisterGuiLayersEvent event) {
        // Encima de la barra de experiencia; arriba a la derecha no choca con hotbar ni chat.
        event.registerAbove(VanillaGuiLayers.EXPERIENCE_BAR, LAYER_ID, CPBarHud::render);
        PresetIndicatorHud.register(event);
        KeyHintHud.register(event);
    }

    @SubscribeEvent
    public static void registerReloadListener(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener)
                manager -> CPBarTextures.invalidate());
    }

    /** Gancho para la tecla V (mantener muestra los números): el original llama a start/stopDisplayNumbers. */
    public static void startDisplayNumbers() {
        showingNumbers = true;
        lastShowValueChange = Util.getMillis();
    }

    public static void stopDisplayNumbers() {
        showingNumbers = false;
        long now = Util.getMillis();
        // Si se mantuvo poco, no hay fundido de salida (igual que el original).
        lastShowValueChange = now - lastShowValueChange > 400 ? now : 0;
    }

    /** CP que gastará lo que el jugador está cargando; 0 = sin aviso. Dibuja una vista previa parpadeante. */
    public static void setConsumptionHint(float cp) {
        consumptionHint = Math.max(0f, cp);
    }

    private static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui || player.isSpectator()) {
            return;
        }
        AbilityData ability = AbilityData.get(player);
        Optional<Category> category = AbilityRegistries.category(ability.getCategory().orElse(null));
        if (category.isEmpty()) {
            return;
        }
        CPData cp = CPData.get(player);

        long now = Util.getMillis();
        boolean active = cp.isActivated();
        if (!lastFrameActive && active) {
            showTime = now;
        }
        long deltaMs = Math.min(100L, now - lastDrawTime);

        // Aparece en 200 ms al activar y se desvanece en 200 ms al desactivar.
        float alpha = now - showTime < BLEND_MS
                ? (float) (now - showTime) / BLEND_MS
                : (active ? 1.0f : Math.max(0.0f, 1 - (now - lastDrawTime) / (float) BLEND_MS));

        float targetOverload = alpha > 0 ? cp.getOverload() / cp.getMaxOverload() : 0;
        float targetCP = alpha > 0 ? cp.getCP() / cp.getMaxCP() : 0;
        float step = deltaMs * 1e-3f * BALANCE_SPEED;
        bufferedOverload = balance(bufferedOverload, targetOverload, step);
        bufferedCP = balance(bufferedCP, targetCP, step);

        if (alpha > 0) {
            draw(graphics, mc, cp, category.get(), alpha, now, targetCP);
        }
        if (active) {
            lastDrawTime = now;
        }
        lastFrameActive = active;
    }

    private static void draw(GuiGraphics graphics, Minecraft mc, CPData cp, Category category, float alpha, long now,
            float targetCP) {
        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(graphics.guiWidth() - MARGIN_RIGHT - WIDTH * SCALE, MARGIN_TOP, 0);
        pose.scale(SCALE, SCALE, 1f);
        Matrix4f m = pose.last().pose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        if (cp.isOverloaded()) {
            drawOverloaded(m, alpha, now);
        } else {
            drawNormal(m, alpha, bufferedOverload);
        }

        ResourceLocation cpTex = CPBarTextures.cpWithHole(category.getIconOverlay());
        // Sobrecargado: no puede usar habilidades, la barra de CP se atenúa (0.3).
        float cpAlpha = alpha * (cp.isOverloaded() ? 0.3f : 1f);
        if (consumptionHint != 0f) {
            float after = Math.max(0f, cp.getCP() - consumptionHint) / cp.getMaxCP();
            float pulse = 0.2f + 0.1f * (1 + (float) Math.sin(now / 80.0));
            drawCPBar(m, cpTex, targetCP, cpAlpha * pulse);
            drawCPBar(m, cpTex, after, cpAlpha);
        } else {
            drawCPBar(m, cpTex, bufferedCP, cpAlpha);
        }

        drawNumbers(graphics, mc.font, cp, alpha, now);

        RenderSystem.enableCull();
        pose.popPose();
    }

    private static void drawNormal(Matrix4f m, float alpha, float overload) {
        quad(m, CPBarTextures.plain("back_normal"), 0, 0, WIDTH, 0, HEIGHT, 0, 1f, 1f, 1f, 0.8f * alpha);

        // Barra de overload: franja de la máscara, crece desde la derecha, teñida por progreso.
        float x0 = 0, y0 = 21, w = 943, h = 104;
        float len = Mth.clamp(overload, 0f, 1f) * w;
        int color = lerpColor(OVERLOAD_PROG, OVERLOAD_COLORS, overload);
        quad(m, CPBarTextures.plain("mask"), x0 + w - len, x0 + w - len, x0 + w, y0, y0 + h, 0,
                red(color), green(color), blue(color), alpha(color) * alpha);
    }

    private static void drawOverloaded(Matrix4f m, float alpha, long now) {
        quad(m, CPBarTextures.plain("back_overload"), 0, 0, WIDTH, 0, HEIGHT, 0, 1f, 1f, 1f, 0.8f * alpha);

        // Frente con la máscara ya aplicada; empieza en x=30 y deja 20 px libres a la derecha.
        float x0 = 30, w2 = WIDTH - x0 - 20;
        quad(m, CPBarTextures.frontOverloadMasked(), x0, x0, x0 + w2, 0, HEIGHT, x0, 1f, 1f, 1f, alpha);

        // Resalte pulsante. El original usa sin(tiempo/200) con tiempo en segundos (casi estático); aquí en ms.
        float pulse = 0.3f + 0.35f * ((float) Math.sin(now / 200.0) + 1f);
        quad(m, CPBarTextures.plain("highlight_overload"), 0, 0, WIDTH, 0, HEIGHT, 0, 1f, 1f, 1f,
                Math.min(1f, pulse) * alpha);
    }

    /** Relleno de CP: paralelogramo cortado en diagonal (44 grados), de derecha a izquierda. */
    private static void drawCPBar(Matrix4f m, ResourceLocation tex, float progress, float alpha) {
        progress = Mth.clamp(progress, 0f, 1f);
        int color = lerpColor(CP_PROG, CP_COLORS, progress);
        // El relleno nunca queda vacío del todo: remapeo 0.16 + p*0.8 del original.
        float mapped = 0.16f + progress * 0.8f;

        final float off = (float) (103 * SIN_44);
        final float x0 = 47, y0 = 30, w = 883, h = 84;
        float len = w * mapped;
        float len2 = len - off;
        quad(m, tex, x0 + (w - len), x0 + (w - len2), x0 + w, y0, y0 + h, 0,
                red(color), green(color), blue(color), alpha);
    }

    private static void drawNumbers(GuiGraphics graphics, Font font, CPData cp, float alpha, long now) {
        float numAlpha;
        long dt = lastShowValueChange == 0 ? Long.MAX_VALUE : now - lastShowValueChange;
        if (cp.isOverloaded()) {
            numAlpha = 0f;
        } else if (showingNumbers) {
            numAlpha = Mth.clamp((dt - 200) / 400f, 0f, 1f); // 200 ms de retraso antes de aparecer
        } else if (dt < 300) {
            numAlpha = 1 - dt / 300f;
        } else {
            numAlpha = 0f;
        }
        int a = (int) (255 * 0.6f * alpha * numAlpha);
        if (a < 4) { // por debajo de 4 el Font lo trataría como opaco
            return;
        }
        int argb = (a << 24) | 0xFFFFFF;

        String cpLabel = Component.translatable("railgunreborn.hud.cp").getString() + " ";
        String olLabel = Component.translatable("railgunreborn.hud.overload").getString() + " ";
        String cpCur = String.format("%.0f", cp.getCP());
        String cpMax = String.format("/%.0f", cp.getMaxCP());
        String olCur = String.format("%.0f", cp.getOverload());
        String olMax = String.format("/%.0f", cp.getMaxOverload());

        // El texto mide 40 px de diseño = 8 px de pantalla: escala 5 sobre la pose de 0.2 da tamaño normal.
        final float textScale = 5f;
        final float x0 = 110;
        float labelW = Math.max(font.width(cpLabel), font.width(olLabel));
        float curW = Math.max(font.width(cpCur), font.width(olCur));
        float xCur = x0 + (labelW + curW) * textScale; // borde derecho de las cifras actuales

        PoseStack pose = graphics.pose();
        drawText(pose, graphics, font, cpLabel, x0, 55, textScale, argb);
        drawText(pose, graphics, font, cpCur, xCur - font.width(cpCur) * textScale, 55, textScale, argb);
        drawText(pose, graphics, font, cpMax, xCur, 55, textScale, argb);
        drawText(pose, graphics, font, olLabel, x0, 85, textScale, argb);
        drawText(pose, graphics, font, olCur, xCur - font.width(olCur) * textScale, 85, textScale, argb);
        drawText(pose, graphics, font, olMax, xCur, 85, textScale, argb);
    }

    private static void drawText(PoseStack pose, GuiGraphics graphics, Font font, String text, float x, float y,
            float scale, int argb) {
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);
        graphics.drawString(font, text, 0, 0, argb, false);
        pose.popPose();
    }

    /**
     * Cuadrilátero texturizado en coordenadas de diseño. El borde izquierdo puede ser oblicuo
     * ({@code leftTop} arriba, {@code leftBottom} abajo). UV = (x - uOrigin) / tamaño de la textura.
     */
    private static void quad(Matrix4f m, ResourceLocation tex, float leftTop, float leftBottom, float right,
            float top, float bottom, float uOrigin, float r, float g, float b, float a) {
        if (a <= 0f) {
            return;
        }
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, tex);
        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
        float v0 = top / HEIGHT;
        float v1 = bottom / HEIGHT;
        buf.addVertex(m, leftTop, top, 0).setUv((leftTop - uOrigin) / texWidth(tex), v0).setColor(r, g, b, a);
        buf.addVertex(m, leftBottom, bottom, 0).setUv((leftBottom - uOrigin) / texWidth(tex), v1).setColor(r, g, b, a);
        buf.addVertex(m, right, bottom, 0).setUv((right - uOrigin) / texWidth(tex), v1).setColor(r, g, b, a);
        buf.addVertex(m, right, top, 0).setUv((right - uOrigin) / texWidth(tex), v0).setColor(r, g, b, a);
        BufferUploader.drawWithShader(buf.buildOrThrow());
    }

    /** Todas miden 964 de ancho salvo front_overload (974), que es la única que se dibuja con origen propio. */
    private static float texWidth(ResourceLocation tex) {
        return tex.equals(CPBarTextures.frontOverloadMasked()) ? 974f : WIDTH;
    }

    private static float balance(float from, float to, float max) {
        float delta = to - from;
        return from + Math.signum(delta) * Math.min(max, Math.abs(delta));
    }

    private static int lerpColor(float[] prog, int[] colors, float p) {
        p = Mth.clamp(p, 0f, 1f);
        for (int i = 0; i < prog.length; i++) {
            if (prog[i] >= p) {
                if (i == 0) {
                    return colors[0];
                }
                float t = (p - prog[i - 1]) / (prog[i] - prog[i - 1]);
                int a = (int) Mth.lerp(t, colors[i - 1] >>> 24, colors[i] >>> 24);
                int r = (int) Mth.lerp(t, (colors[i - 1] >> 16) & 0xFF, (colors[i] >> 16) & 0xFF);
                int g = (int) Mth.lerp(t, (colors[i - 1] >> 8) & 0xFF, (colors[i] >> 8) & 0xFF);
                int b = (int) Mth.lerp(t, colors[i - 1] & 0xFF, colors[i] & 0xFF);
                return (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
        return colors[colors.length - 1];
    }

    private static float alpha(int argb) {
        return (argb >>> 24) / 255f;
    }

    private static float red(int argb) {
        return ((argb >> 16) & 0xFF) / 255f;
    }

    private static float green(int argb) {
        return ((argb >> 8) & 0xFF) / 255f;
    }

    private static float blue(int argb) {
        return (argb & 0xFF) / 255f;
    }
}
