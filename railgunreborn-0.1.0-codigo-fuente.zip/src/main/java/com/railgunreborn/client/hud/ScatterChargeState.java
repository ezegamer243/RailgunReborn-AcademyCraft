package com.railgunreborn.client.hud;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.meltdowner.ScatterBombRules;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Estado de la carga de Scatter Bomb, solo para quien mantiene la tecla; lo lee {@link KeyHintHud} para dibujar el
 * contorno del icono. Misma idea que {@link IntensifyChargeState}: cuenta ticks en el cliente desde el aviso de inicio
 * y se funde al terminar. Solo tiene un evento del bus del juego.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ScatterChargeState {
    private static final long FADE_MS = 300L;

    private static boolean active;
    private static boolean ended;
    private static long endMs;
    private static int ticks;

    private ScatterChargeState() {
    }

    public static void start() {
        active = true;
        ended = false;
        ticks = 0;
    }

    public static void end() {
        if (active && !ended) {
            ended = true;
            endMs = Util.getMillis();
        }
    }

    public static void reset() {
        active = false;
        ended = false;
        ticks = 0;
    }

    public static boolean isShown() {
        return active && alpha() > 0f;
    }

    public static boolean hasEnded() {
        return ended;
    }

    public static int ticks() {
        return ticks;
    }

    public static float smoothTicks(float partialTick) {
        return ended ? ticks : Math.min(ScatterBombRules.BLOW_TICK, ticks + partialTick);
    }

    public static float alpha() {
        return ended ? Math.max(0f, 1f - (Util.getMillis() - endMs) / (float) FADE_MS) : 1f;
    }

    @SubscribeEvent
    public static void onLoggingOut(net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent.LoggingOut event) {
        reset();
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!active || Minecraft.getInstance().isPaused()) {
            return;
        }
        if (ended) {
            if (Util.getMillis() - endMs > FADE_MS) {
                reset();
            }
        } else if (ticks < ScatterBombRules.BLOW_TICK) {
            ticks++;
        }
    }
}
