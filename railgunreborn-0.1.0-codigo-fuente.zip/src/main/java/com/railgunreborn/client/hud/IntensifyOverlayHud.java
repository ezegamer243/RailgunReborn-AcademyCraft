package com.railgunreborn.client.hud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.mojang.blaze3d.systems.RenderSystem;
import com.railgunreborn.RailgunReborn;

import net.minecraft.Util;
import net.minecraft.client.CameraType;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Capa de pantalla de Body Intensify (ficha 8.1), solo para quien mantiene la tecla: arcos 2D cerca del borde (sin
 * máscara ni viñeta: decisión del usuario, tapaban la vista). Sube en 0.5 s, baja en 0.2 s al terminar y se destruye 1 s despues. Al soltar con exito
 * en primera persona los arcos se sustituyen por una rafaga de 10-14 mas grandes.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class IntensifyOverlayHud {
    public static final ResourceLocation LAYER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "intensify_overlay");
    /** Tamano real de intensify_arc/0..9.png. */
    private static final int[][] ARC_DIMS = {{119, 109}, {103, 128}, {115, 94}, {128, 101}, {114, 128},
            {112, 96}, {128, 128}, {128, 114}, {128, 122}, {128, 128}};
    private static final ResourceLocation[] ARC_TEXTURES = new ResourceLocation[ARC_DIMS.length];

    static {
        for (int i = 0; i < ARC_TEXTURES.length; i++) {
            ARC_TEXTURES[i] = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                    "textures/gui/intensify_arc/" + i + ".png");
        }
    }

    private static final long RISE_MS = 500L;
    private static final long FADE_MS = 200L;
    private static final long DESTROY_MS = 1000L;
    private static final Random RANDOM = new Random();

    private static final List<Arc2D> ARCS = new ArrayList<>();
    private static boolean shown;
    private static long startMs;
    /** 0 = aun se mantiene la tecla. */
    private static long endMs;
    private static float alphaAtEnd;

    private IntensifyOverlayHud() {
    }

    /** Un arco 2D: posicion normalizada respecto al centro, tamano en pixeles, vida en ticks (-1 = infinita). */
    private static final class Arc2D {
        final float nx;
        final float ny;
        final float size;
        final double frameRate;
        final double switchRate;
        int life;
        int frame = RANDOM.nextInt(ARC_TEXTURES.length);
        boolean visible = true;

        Arc2D(float minPhi, float maxPhi, float size, int life, double frameRate, double switchRate) {
            double theta = RANDOM.nextDouble() * Math.PI * 2;
            double phi = minPhi + RANDOM.nextDouble() * (maxPhi - minPhi);
            this.nx = (float) (Math.sin(theta) * phi);
            this.ny = (float) (Math.cos(theta) * phi);
            this.size = size;
            this.life = life;
            this.frameRate = frameRate;
            this.switchRate = switchRate;
        }

        /** false = muerto. */
        boolean tick() {
            if (RANDOM.nextDouble() < 0.5 * frameRate) {
                frame = RANDOM.nextInt(ARC_TEXTURES.length);
            }
            if (switchRate > 0 && RANDOM.nextDouble() < 0.4 * switchRate) {
                visible = !visible;
            }
            return life < 0 || --life > 0;
        }
    }

    static void register(RegisterGuiLayersEvent event) {
        event.registerBelow(VanillaGuiLayers.HOTBAR, LAYER_ID, IntensifyOverlayHud::render);
    }

    @SubscribeEvent
    public static void registerLayer(RegisterGuiLayersEvent event) {
        register(event);
    }

    /** Pulsar la tecla: empieza a subir y aparecen 5-6 arcos pequenos en el borde. */
    public static void start() {
        ARCS.clear();
        shown = true;
        startMs = Util.getMillis();
        endMs = 0L;
        int count = 5 + RANDOM.nextInt(2);
        for (int i = 0; i < count; i++) {
            ARCS.add(new Arc2D(0.84f, 0.96f, 25f + RANDOM.nextFloat() * 5f, -1, 0.3, 0));
        }
    }

    /** Soltar o cancelar. La rafaga solo se ve en primera persona. */
    public static void end(boolean performed) {
        if (!shown || endMs != 0L) {
            return;
        }
        alphaAtEnd = alpha(Util.getMillis());
        endMs = Util.getMillis();
        ARCS.clear();
        if (performed && Minecraft.getInstance().options.getCameraType() == CameraType.FIRST_PERSON) {
            int count = 10 + RANDOM.nextInt(5);
            for (int i = 0; i < count; i++) {
                ARCS.add(new Arc2D(0.6f, 1.0f, 35f + RANDOM.nextFloat() * 5f, 25, 0.3, 0.2));
            }
        }
    }

    public static void reset() {
        shown = false;
        ARCS.clear();
    }

    /** El tick de cliente es un evento del bus del juego, no del bus del mod donde vive esta clase. */
    @EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            IntensifyOverlayHud.onClientTick(event);
        }
    }

    static void onClientTick(ClientTickEvent.Post event) {
        if (!shown || Minecraft.getInstance().isPaused()) {
            return;
        }
        for (Iterator<Arc2D> it = ARCS.iterator(); it.hasNext(); ) {
            if (!it.next().tick()) {
                it.remove();
            }
        }
        if (endMs != 0L && Util.getMillis() - endMs > DESTROY_MS) {
            reset();
        }
    }

    private static float alpha(long now) {
        if (endMs == 0L) {
            return Math.min(1f, (now - startMs) / (float) RISE_MS);
        }
        return Math.max(0f, alphaAtEnd * (1f - (now - endMs) / (float) FADE_MS));
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (!shown || mc.player == null || mc.options.hideGui) {
            return;
        }
        int w = g.guiWidth();
        int h = g.guiHeight();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        // Decisión del usuario: sin máscara celeste ni oscurecido (tapaba la vista); solo quedan los arcos.
        float arcAlpha = endMs != 0L && ARCS.isEmpty() ? 0f : (endMs != 0L ? 0.4f : 0.3f);
        g.setColor(1f, 1f, 1f, arcAlpha);
        for (Arc2D arc : ARCS) {
            if (!arc.visible) {
                continue;
            }
            int[] dims = ARC_DIMS[arc.frame];
            float scale = arc.size / Math.max(dims[0], dims[1]);
            int dw = Math.round(dims[0] * scale);
            int dh = Math.round(dims[1] * scale);
            int x = Math.round(w / 2f + arc.nx * w / 2f - dw / 2f);
            int y = Math.round(h / 2f + arc.ny * h / 2f - dh / 2f);
            g.blit(ARC_TEXTURES[arc.frame], x, y, dw, dh, 0, 0, dims[0], dims[1], dims[0], dims[1]);
        }
        g.setColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
