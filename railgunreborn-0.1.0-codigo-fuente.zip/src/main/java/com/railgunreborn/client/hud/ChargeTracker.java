package com.railgunreborn.client.hud;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.railgunreborn.RailgunReborn;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Cuenta de carga del jugador local para el contorno del icono (versión genérica de {@link ScatterChargeState}): arranca
 * con el aviso de inicio del servidor, cuenta ticks de cliente, se congela al terminar y se funde en {@link #FADE_MS}.
 * Si no llega el fin, se corta sola en {@code maxTicks}. Todas las instancias las avanza el tick de cliente de esta
 * clase (solo bus del juego).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class ChargeTracker {
    private static final long FADE_MS = 300L;
    private static final List<ChargeTracker> ALL = new CopyOnWriteArrayList<>();

    private final int maxTicks;
    private boolean active;
    private boolean ended;
    private long endMs;
    private int ticks;

    public ChargeTracker(int maxTicks) {
        this.maxTicks = maxTicks;
        ALL.add(this);
    }

    public void start() {
        active = true;
        ended = false;
        ticks = 0;
    }

    public void end() {
        if (active && !ended) {
            ended = true;
            endMs = Util.getMillis();
        }
    }

    public void reset() {
        active = false;
        ended = false;
        ticks = 0;
    }

    public boolean isShown() {
        return active && alpha() > 0f;
    }

    public boolean hasEnded() {
        return ended;
    }

    public int ticks() {
        return ticks;
    }

    public float smoothTicks(float partialTick) {
        return ended ? ticks : Math.min(maxTicks, ticks + partialTick);
    }

    public float alpha() {
        return ended ? Math.max(0f, 1f - (Util.getMillis() - endMs) / (float) FADE_MS) : 1f;
    }

    private void tick() {
        if (!active) {
            return;
        }
        if (ended) {
            if (Util.getMillis() - endMs > FADE_MS) {
                reset();
            }
        } else if (ticks < maxTicks) {
            ticks++;
        } else {
            end();
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!Minecraft.getInstance().isPaused()) {
            for (ChargeTracker tracker : ALL) {
                tracker.tick();
            }
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        for (ChargeTracker tracker : ALL) {
            tracker.reset();
        }
    }
}
