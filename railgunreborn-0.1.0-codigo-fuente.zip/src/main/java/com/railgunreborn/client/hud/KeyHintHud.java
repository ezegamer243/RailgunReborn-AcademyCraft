package com.railgunreborn.client.hud;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.client.ModKeys;
import com.railgunreborn.client.context.ClientSkillContexts;

import net.minecraft.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/**
 * Pistas de teclas (port de {@code KeyHintUI}): una fila por ranura asignada del preset activo, a la derecha de la
 * pantalla y centrada en vertical. Ver {@code docs/spec/preset-gui.md}, sección 3. El estado del icono es IDLE o
 * ACTIVE (contexto vivo); una habilidad puede dar CHARGE/ACTIVE propios con {@link #registerStateProvider} (Railgun:
 * moneda en el aire o carga con hierro). Se dibuja en unidades de diseño con la pose escalada a 0.23.
 */
public final class KeyHintHud {
    public static final ResourceLocation LAYER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "key_hint");

    private static final float SCALE = 0.23f;
    private static final int ROW_WIDTH = 185;
    private static final int ROW_HEIGHT = 83;
    private static final int ROW_STEP = 92;
    /** Distancia (px de pantalla) del borde izquierdo de la fila al borde derecho de la pantalla. */
    private static final float ROW_LEFT_FROM_RIGHT = 50f;
    private static final float OFFSET_Y = 30f;
    private static final long FADE_MS = 300L;
    private static final int ICON_SIZE = 62;
    private static final int ICON_TEXTURE_SIZE = 32; // los iconos de habilidad son de 32x32
    private static final int KEY_TEXT_COLOR = 0x194246;
    private static final int ACTIVE_GLOW_RGB = 0x46B3FF;
    /** Contorno de carga: cuadrado de 76 de lado centrado en el fondo del icono (94, 5, 72), de 6 de grosor. */
    private static final int OUTLINE_X = 92;
    private static final int OUTLINE_Y = 3;
    private static final int OUTLINE_SIDE = 76;
    private static final int OUTLINE_THICKNESS = 6;
    /** Brillo naranja del estado CARGA (KeyHintUI del original). */
    private static final int CHARGE_GLOW_RGB = 0xFF9A30;

    /** Estado del icono de una ranura. */
    public enum HintState {
        IDLE,
        /** Brillo naranja parpadeante (p. ej. la moneda sube o se carga con hierro). */
        CHARGE,
        /** Brillo azul parpadeante (contexto vivo o, p. ej., moneda en la ventana del QTE). */
        ACTIVE
    }

    private static final Map<ResourceLocation, Function<LocalPlayer, HintState>> STATE_PROVIDERS =
            new ConcurrentHashMap<>();

    private static final ResourceLocation BACK = tex("back");
    private static final ResourceLocation ICON_BACK = tex("icon_back");
    private static final ResourceLocation KEY_SHORT = tex("key_short");
    private static final ResourceLocation KEY_LONG = tex("key_long");
    private static final ResourceLocation MOUSE_LEFT = tex("mouse_left");
    private static final ResourceLocation MOUSE_RIGHT = tex("mouse_right");
    private static final ResourceLocation MOUSE_GENERIC = tex("mouse_generic");

    private static long lastDrawTime;
    private static long showStart;

    /** Contorno de carga genérico de una habilidad: su cuenta y su forma. */
    private record OutlineEntry(ChargeTracker tracker, ChargeOutline outline) {
    }

    private static final Map<ResourceLocation, OutlineEntry> CHARGE_OUTLINES = new ConcurrentHashMap<>();

    /**
     * Contorno de carga alrededor del icono de {@code skill} mientras {@code tracker} tenga algo que mostrar (llamar en
     * {@code FMLClientSetupEvent}).
     */
    public static void registerChargeOutline(ResourceLocation skill, ChargeTracker tracker, ChargeOutline outline) {
        CHARGE_OUTLINES.put(skill, new OutlineEntry(tracker, outline));
    }

    /** Estado extra del icono de una habilidad (llamar en {@code FMLClientSetupEvent}). IDLE = el normal. */
    public static void registerStateProvider(ResourceLocation skill, Function<LocalPlayer, HintState> provider) {
        STATE_PROVIDERS.put(skill, provider);
    }

    private KeyHintHud() {
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "textures/gui/key_hint/" + name + ".png");
    }

    static void register(RegisterGuiLayersEvent event) {
        event.registerAbove(PresetIndicatorHud.LAYER_ID, LAYER_ID, KeyHintHud::render);
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui || player.isSpectator() || !CPData.get(player).isActivated()
                || AbilityRegistries.category(AbilityData.get(player).getCategory().orElse(null)).isEmpty()) {
            return;
        }
        PresetData presets = PresetData.get(player);
        int rows = 0;
        for (int slot = 0; slot < PresetData.MAX_SLOTS; slot++) {
            if (presets.getSlot(presets.getActive(), slot) != null) {
                rows++;
            }
        }
        long now = Util.getMillis();
        if (now - lastDrawTime > FADE_MS) {
            showStart = now; // reaparece tras estar oculto: sube de 0 a 1 en 0.3 s
        }
        lastDrawTime = now;
        if (rows == 0) {
            return;
        }
        float master = Math.min(1f, (now - showStart) / (float) FADE_MS);
        boolean canUse = CPData.get(player).canUseAbility();
        CooldownData cooldowns = CooldownData.get(player);

        float blockHeight = (rows - 1) * ROW_STEP + ROW_HEIGHT;
        float top = (g.guiHeight() - blockHeight * SCALE) / 2f + OFFSET_Y;
        var pose = g.pose();
        pose.pushPose();
        pose.translate(g.guiWidth() - ROW_LEFT_FROM_RIGHT, top, 0);
        pose.scale(SCALE, SCALE, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        int row = 0;
        for (int slot = 0; slot < PresetData.MAX_SLOTS; slot++) {
            ResourceLocation skillId = presets.getSlot(presets.getActive(), slot);
            if (skillId == null) {
                continue;
            }
            Optional<Skill> skill = AbilityRegistries.skill(skillId);
            pose.pushPose();
            pose.translate(0, row * ROW_STEP, 0);
            drawRow(g, mc, ModKeys.SLOTS[slot], skillId, skill.orElse(null), canUse, cooldowns, now, master,
                    delta.getGameTimeDeltaPartialTick(true));
            pose.popPose();
            row++;
        }
        g.setColor(1f, 1f, 1f, 1f);
        pose.popPose();
    }

    private static void drawRow(GuiGraphics g, Minecraft mc, KeyMapping key, ResourceLocation skillId, Skill skill,
            boolean canUse, CooldownData cooldowns, long now, float master, float partialTick) {
        float cooldown = cooldowns.getProgress(skillId, 0);
        boolean inCooldown = cooldown > 0f;
        boolean grey = !canUse || inCooldown;

        // Fondo (la textura mide 256 de ancho y se estira a 185).
        g.setColor(1f, 1f, 1f, master);
        g.blit(BACK, 0, 0, ROW_WIDTH, ROW_HEIGHT, 0, 0, 256, 83, 256, 83);

        // Tecla: se lee del KeyMapping actual, así que refleja lo que el jugador configure en Controles.
        float shade = grey ? 0.7f : 1f;
        g.setColor(shade, shade, shade, master);
        InputConstants.Key bound = key.getKey();
        boolean mouse = bound.getType() == InputConstants.Type.MOUSE;
        String label = "";
        ResourceLocation keyTex;
        int texW = 48;
        int texH = 48;
        if (mouse && bound.getValue() == 0) {
            keyTex = MOUSE_LEFT;
        } else if (mouse && bound.getValue() == 1) {
            keyTex = MOUSE_RIGHT;
        } else if (mouse) {
            keyTex = MOUSE_GENERIC;
            label = String.valueOf(bound.getValue() + 1);
        } else {
            label = key.getTranslatedKeyMessage().getString();
            keyTex = label.codePointCount(0, label.length()) <= 2 ? KEY_SHORT : KEY_LONG;
            texW = 50;
        }
        g.blit(keyTex, 24, 10, 70, 70, 0, 0, texW, texH, texW, texH);
        g.setColor(1f, 1f, 1f, 1f);
        if (!label.isEmpty()) {
            int textColor = grey ? 0x6A6A6A : KEY_TEXT_COLOR;
            drawKeyLabel(g, mc, label, 58f, 27f, (Math.max(4, (int) (master * 255)) << 24) | textColor);
        }
        // Dibujar texto deja la mezcla apagada: sin esto, en las filas con tecla escrita el icono salía opaco.
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // Fondo del icono e icono
        g.setColor(1f, 1f, 1f, master);
        g.blit(ICON_BACK, 94, 5, 72, 72, 0, 0, 72, 72, 72, 72);

        Function<LocalPlayer, HintState> provider = STATE_PROVIDERS.get(skillId);
        HintState extra = provider != null && mc.player != null ? provider.apply(mc.player) : HintState.IDLE;
        boolean charge = extra == HintState.CHARGE;
        boolean active = !charge && (extra == HintState.ACTIVE || ClientSkillContexts.getActive().stream()
                .anyMatch(ctx -> !ctx.isTerminated() && ctx.getSkill().getId().equals(skillId)));
        float pulse = 0.6f + 0.2f * (1f + (float) Math.sin(now * (Math.PI * 2 / 1000.0)));
        float iconAlpha;
        if (inCooldown) {
            iconAlpha = 0.4f;
        } else if (active || charge) {
            iconAlpha = 0.4f + 0.6f * pulse;
        } else {
            iconAlpha = 0.7f;
        }
        if ((active || charge) && !inCooldown) {
            int glowAlpha = (int) (255 * pulse * master);
            HudGlow.glow(g, 99, 10, ICON_SIZE, ICON_SIZE, 6,
                    (glowAlpha << 24) | (charge ? CHARGE_GLOW_RGB : ACTIVE_GLOW_RGB));
        }
        if (skill != null) {
            g.setColor(1f, 1f, 1f, iconAlpha * master);
            g.blit(skill.getIcon(), 99, 10, ICON_SIZE, ICON_SIZE, 0, 0, ICON_TEXTURE_SIZE, ICON_TEXTURE_SIZE,
                    ICON_TEXTURE_SIZE, ICON_TEXTURE_SIZE);
            g.setColor(1f, 1f, 1f, 1f);
        }

        // Velo de cooldown: cubre la parte baja del icono y su borde superior baja al avanzar.
        if (inCooldown) {
            int height = Math.round(ICON_SIZE * cooldown);
            int veil = ((int) (0.3f * 255 * master) << 24) | 0x999999;
            g.fill(99, 10 + ICON_SIZE - height, 99 + ICON_SIZE, 10 + ICON_SIZE, veil);
        }

        if (skill != null && Electromaster.BODY_INTENSIFY.getId().equals(skillId) && IntensifyChargeState.isShown()) {
            drawChargeOutline(g, master, partialTick);
        } else if (skill != null && Meltdowner.SCATTER_BOMB.getId().equals(skillId) && ScatterChargeState.isShown()) {
            drawScatterOutline(g, master, partialTick);
        } else if (skill != null) {
            OutlineEntry entry = CHARGE_OUTLINES.get(skillId);
            if (entry != null && entry.tracker().isShown()) {
                drawGenericOutline(g, master, partialTick, entry.tracker(), entry.outline());
            }
        }
    }

    /** Contorno de carga registrado con {@link #registerChargeOutline}: mismo trazado que el de Body Intensify. */
    private static void drawGenericOutline(GuiGraphics g, float master, float partialTick, ChargeTracker tracker,
            ChargeOutline outline) {
        float alpha = master * tracker.alpha();
        if (outline.warning(tracker.ticks()) && !tracker.hasEnded()) {
            alpha *= 0.55f + 0.45f * ((float) Math.sin(Util.getMillis() / 60.0) * 0.5f + 0.5f);
        }
        float filled = outline.fill(tracker.smoothTicks(partialTick));

        g.pose().pushPose();
        g.pose().translate(OUTLINE_X, OUTLINE_Y, 0);
        drawStrips(g, IntensifyChargeBarLogic.outlineStrips(0f, 1f, OUTLINE_SIDE, OUTLINE_THICKNESS),
                withAlpha(0xA0161A20, alpha));
        for (ChargeOutline.Band band : outline.bands()) {
            float from = outline.fill(band.start());
            float to = Math.min(filled, outline.fill(band.end()));
            if (to > from) {
                drawStrips(g, IntensifyChargeBarLogic.outlineStrips(from, to, OUTLINE_SIDE, OUTLINE_THICKNESS),
                        withAlpha(band.color(), alpha));
            }
        }
        g.pose().popPose();
    }

    /**
     * Contorno de carga de Body Intensify alrededor del icono: sale del centro del borde superior en sentido horario y
     * da la vuelta entera al llegar al tope de cancelacion. Mismos tramos y colores que {@link IntensifyChargeBarLogic};
     * el cambio de color marca los umbrales (a este tamano no caben marcas). Parpadea en los ultimos ticks.
     */
    private static void drawChargeOutline(GuiGraphics g, float master, float partialTick) {
        int ticks = IntensifyChargeState.ticks();
        float alpha = master * IntensifyChargeState.alpha();
        if (IntensifyChargeBarLogic.warning(ticks) && !IntensifyChargeState.hasEnded()) {
            alpha *= 0.55f + 0.45f * ((float) Math.sin(Util.getMillis() / 60.0) * 0.5f + 0.5f);
        }
        float smooth = IntensifyChargeState.smoothTicks(partialTick);
        float filled = IntensifyChargeBarLogic.fill(smooth);

        g.pose().pushPose();
        g.pose().translate(OUTLINE_X, OUTLINE_Y, 0);
        // Pista oscura de todo el recorrido y, encima, lo recorrido tramo a tramo.
        drawStrips(g, IntensifyChargeBarLogic.outlineStrips(0f, 1f, OUTLINE_SIDE, OUTLINE_THICKNESS),
                withAlpha(0xA0161A20, alpha));
        for (IntensifyChargeBarLogic.Segment segment : IntensifyChargeBarLogic.Segment.values()) {
            float from = IntensifyChargeBarLogic.markFraction(segment.start());
            float to = Math.min(filled, IntensifyChargeBarLogic.markFraction(segment.end()));
            if (to > from) {
                drawStrips(g, IntensifyChargeBarLogic.outlineStrips(from, to, OUTLINE_SIDE, OUTLINE_THICKNESS),
                        withAlpha(segment.color(), alpha));
            }
        }
        g.pose().popPose();
    }

    /** Contorno de carga de Scatter Bomb: mismo trazado que el de Body Intensify, con los tramos de ScatterChargeBarLogic. */
    private static void drawScatterOutline(GuiGraphics g, float master, float partialTick) {
        int ticks = ScatterChargeState.ticks();
        float alpha = master * ScatterChargeState.alpha();
        if (ScatterChargeBarLogic.warning(ticks) && !ScatterChargeState.hasEnded()) {
            alpha *= 0.55f + 0.45f * ((float) Math.sin(Util.getMillis() / 60.0) * 0.5f + 0.5f);
        }
        float filled = ScatterChargeBarLogic.fill(ScatterChargeState.smoothTicks(partialTick));

        g.pose().pushPose();
        g.pose().translate(OUTLINE_X, OUTLINE_Y, 0);
        drawStrips(g, IntensifyChargeBarLogic.outlineStrips(0f, 1f, OUTLINE_SIDE, OUTLINE_THICKNESS),
                withAlpha(0xA0161A20, alpha));
        for (ScatterChargeBarLogic.Segment segment : ScatterChargeBarLogic.Segment.values()) {
            float from = ScatterChargeBarLogic.fill(segment.start());
            float to = Math.min(filled, ScatterChargeBarLogic.fill(segment.end()));
            if (to > from) {
                drawStrips(g, IntensifyChargeBarLogic.outlineStrips(from, to, OUTLINE_SIDE, OUTLINE_THICKNESS),
                        withAlpha(segment.color(), alpha));
            }
        }
        g.pose().popPose();
    }

    private static void drawStrips(GuiGraphics g, java.util.List<int[]> strips, int argb) {
        for (int[] r : strips) {
            g.fill(r[0], r[1], r[2], r[3], argb);
        }
    }

    private static int withAlpha(int argb, float alpha) {
        int a = Math.max(0, Math.min(255, (int) ((argb >>> 24) * alpha)));
        return (a << 24) | (argb & 0x00FFFFFF);
    }

    /** Nombre de la tecla de tamaño 32 de diseño, centrado en x; se encoge si no cabe en la tecla (56 de ancho). */
    private static void drawKeyLabel(GuiGraphics g, Minecraft mc, String label, float centerX, float top, int argb) {
        float scale = 4f;
        float width = mc.font.width(label) * scale;
        if (width > 56f) {
            scale *= 56f / width;
            width = 56f;
        }
        var pose = g.pose();
        pose.pushPose();
        pose.translate(centerX - width / 2f, top, 0);
        pose.scale(scale, scale, 1f);
        g.drawString(mc.font, label, 0, 0, argb, false);
        pose.popPose();
    }
}
