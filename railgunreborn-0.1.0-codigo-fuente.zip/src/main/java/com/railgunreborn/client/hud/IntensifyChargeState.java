package com.railgunreborn.client.hud;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.electromaster.BodyIntensifyRules;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Estado de la carga de Body Intensify, solo para quien mantiene la tecla; lo lee {@link KeyHintHud} para dibujar el
 * contorno del icono. Cuenta ticks en el cliente desde el aviso de inicio del servidor (el mismo instante en que
 * arranca la cuenta de {@code BodyIntensifySkill}), asi que coincide con el servidor salvo la latencia. Al terminar se
 * congela y se funde en {@link #FADE_MS}.
 *
 * <p>Esta clase solo tiene un evento del bus del juego (el tick de cliente); no hay nada del bus del mod.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class IntensifyChargeState {
    private static final long FADE_MS = 300L;

    private static boolean active;
    private static boolean ended;
    private static long endMs;
    private static int ticks;

    private IntensifyChargeState() {
    }

    /** Llega el aviso de inicio: la cuenta arranca en 0. */
    public static void start() {
        active = true;
        ended = false;
        ticks = 0;
    }

    /** Soltar o cancelar: se congela y se funde. */
    public static void end() {
        if (active && !ended) {
            ended = true;
            endMs = Util.getMillis();
        }
    }

    public static void reset() {
        active = false;
        ended = false;
        ticks = 0;
    }

    /** Hay carga que dibujar (cargando o fundiendose). */
    public static boolean isShown() {
        return active && alpha() > 0f;
    }

    public static boolean hasEnded() {
        return ended;
    }

    public static int ticks() {
        return ticks;
    }

    /** Ticks con la parte del tick actual, para que el contorno avance suave; congelado al terminar. */
    public static float smoothTicks(float partialTick) {
        return ended ? ticks : Math.min(BodyIntensifyRules.TIMEOUT_TICKS, ticks + partialTick);
    }

    /** 1 mientras carga; baja a 0 en {@link #FADE_MS} al terminar. */
    public static float alpha() {
        return ended ? Math.max(0f, 1f - (Util.getMillis() - endMs) / (float) FADE_MS) : 1f;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!active || Minecraft.getInstance().isPaused()) {
            return;
        }
        if (ended) {
            if (Util.getMillis() - endMs > FADE_MS) {
                reset();
            }
        } else if (ticks < BodyIntensifyRules.TIMEOUT_TICKS) {
            ticks++;
        }
    }
}
