package com.railgunreborn.client.hud;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


import com.mojang.blaze3d.platform.NativeImage;
import com.railgunreborn.RailgunReborn;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;

/**
 * Texturas de la barra de CP "horneadas" en CPU y registradas como {@link DynamicTexture}.
 *
 * <p>Motivos: (1) el original recortaba el icono de la categoría del relleno de CP y aplicaba la máscara a la barra
 * de overload con shaders GLSL 120; aquí se hace una sola vez al cargar. (2) Las texturas de 964 px se dibujan
 * a escala 0.2, y las texturas normales de recursos usan filtro vecino (aliasing); las dinámicas permiten filtro
 * lineal sin tocar los PNG.
 */
final class CPBarTextures {
    static final int WIDTH = 964;
    static final int HEIGHT = 147;

    // Posición y tamaño (en píxeles de diseño) del hueco del icono en cp.png (cpbar_cp.frag del original).
    private static final int ICON_X = 857;
    private static final int ICON_Y = 43;
    private static final int ICON_SIZE = 65;

    private static final String DIR = "textures/gui/cpbar/";
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();

    private CPBarTextures() {
    }

    /** Textura sin modificar (con filtro lineal): {@code back_normal}, {@code back_overload}, {@code mask}... */
    static ResourceLocation plain(String name) {
        return CACHE.computeIfAbsent(name, k -> bake(k, () -> read(DIR + name + ".png")));
    }

    /** {@code front_overload} con el alfa de {@code mask} aplicado (lo que hacía cpbar_overload.frag). */
    static ResourceLocation frontOverloadMasked() {
        return CACHE.computeIfAbsent("front_overload_masked", k -> bake(k, () -> {
            NativeImage front = read(DIR + "front_overload.png");
            NativeImage mask = read(DIR + "mask.png");
            for (int y = 0; y < front.getHeight(); y++) {
                for (int x = 0; x < front.getWidth(); x++) {
                    // La máscara solo existe en 964 de ancho; fuera de ella no se pinta nada.
                    int maskA = x < mask.getWidth() && y < mask.getHeight() ? alpha(mask.getPixelRGBA(x, y)) : 0;
                    int px = front.getPixelRGBA(x, y);
                    front.setPixelRGBA(x, y, withAlpha(px, alpha(px) * maskA / 255));
                }
            }
            mask.close();
            return front;
        }));
    }

    /** {@code cp.png} con la silueta de {@code overlay} recortada en la zona del icono. */
    static ResourceLocation cpWithHole(ResourceLocation overlayTexture) {
        String key = "cp_" + overlayTexture.getNamespace() + "_" + overlayTexture.getPath().replace('/', '_');
        return CACHE.computeIfAbsent(key, k -> bake(k, () -> {
            NativeImage cp = read(DIR + "cp.png");
            NativeImage overlay = readFull(overlayTexture);
            for (int dy = 0; dy < ICON_SIZE; dy++) {
                for (int dx = 0; dx < ICON_SIZE; dx++) {
                    int x = ICON_X + dx;
                    int y = ICON_Y + dy;
                    if (x >= cp.getWidth() || y >= cp.getHeight()) {
                        continue;
                    }
                    int ox = Math.min(overlay.getWidth() - 1, dx * overlay.getWidth() / ICON_SIZE);
                    int oy = Math.min(overlay.getHeight() - 1, dy * overlay.getHeight() / ICON_SIZE);
                    int hole = alpha(overlay.getPixelRGBA(ox, oy));
                    int px = cp.getPixelRGBA(x, y);
                    cp.setPixelRGBA(x, y, withAlpha(px, alpha(px) * (255 - hole) / 255));
                }
            }
            overlay.close();
            return cp;
        }));
    }

    /** Libera todo (recarga de recursos): se volverá a hornear al primer dibujo. */
    static void invalidate() {
        TextureManager manager = Minecraft.getInstance().getTextureManager();
        CACHE.values().forEach(loc -> {
            if (loc != null) {
                manager.release(loc);
            }
        });
        CACHE.clear();
    }

    @FunctionalInterface
    private interface ImageSource {
        NativeImage load() throws IOException;
    }

    private static ResourceLocation bake(String name, ImageSource source) {
        try {
            DynamicTexture texture = new DynamicTexture(source.load());
            texture.setFilter(true, false);
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                    "cpbar_baked/" + name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9_./-]", "_"));
            Minecraft.getInstance().getTextureManager().register(id, texture);
            return id;
        } catch (IOException | RuntimeException e) {
            RailgunReborn.LOGGER.error("Could not load CP bar texture '{}'", name, e);
            return MissingTextureAtlasSprite.getLocation(); // magenta visible; no se reintenta cada frame
        }
    }

    private static NativeImage read(String path) throws IOException {
        return readFull(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path));
    }

    private static NativeImage readFull(ResourceLocation location) throws IOException {
        try (InputStream in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(location).open()) {
            return NativeImage.read(in);
        }
    }

    // NativeImage.getPixelRGBA usa ABGR: el alfa son siempre los 8 bits altos.
    private static int alpha(int abgr) {
        return abgr >>> 24;
    }

    private static int withAlpha(int abgr, int a) {
        return (abgr & 0x00FFFFFF) | (Math.clamp(a, 0, 255) << 24);
    }
}
