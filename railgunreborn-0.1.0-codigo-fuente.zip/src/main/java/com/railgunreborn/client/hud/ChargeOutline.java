package com.railgunreborn.client.hud;

import java.util.ArrayList;
import java.util.List;

/**
 * Forma genérica del contorno de carga alrededor del icono de una habilidad ({@link KeyHintHud}): tramos de color
 * sobre una cuenta de {@code totalTicks} (el contorno da la vuelta entera al llegar) y parpadeo desde
 * {@code warningFrom}. Lógica pura (sin Minecraft) para probarla con JUnit. Body Intensify y Scatter Bomb tienen la suya
 * propia anterior; las habilidades nuevas usan esta.
 */
public final class ChargeOutline {
    /** Tramo {@code [start, end)} en ticks pintado de {@code color} (ARGB). */
    public record Band(int start, int end, int color) {
    }

    private final int totalTicks;
    private final int warningFrom;
    private final List<Band> bands;

    private ChargeOutline(int totalTicks, int warningFrom, List<Band> bands) {
        this.totalTicks = totalTicks;
        this.warningFrom = warningFrom;
        this.bands = List.copyOf(bands);
    }

    public static Builder builder(int totalTicks) {
        return new Builder(totalTicks);
    }

    public int totalTicks() {
        return totalTicks;
    }

    public List<Band> bands() {
        return bands;
    }

    /** Fracción del recorrido en [0, 1]. */
    public float fill(float ticks) {
        return Math.clamp(ticks / totalTicks, 0f, 1f);
    }

    /** Si el contorno parpadea (aviso antes del final). */
    public boolean warning(int ticks) {
        return ticks >= warningFrom;
    }

    /** Tramo en el que cae {@code ticks}; el último si se pasa. */
    public Band band(int ticks) {
        for (Band band : bands) {
            if (ticks < band.end()) {
                return band;
            }
        }
        return bands.get(bands.size() - 1);
    }

    public static final class Builder {
        private final int totalTicks;
        private final List<Band> bands = new ArrayList<>();
        private int next;
        private int warningFrom = Integer.MAX_VALUE;

        private Builder(int totalTicks) {
            if (totalTicks <= 0) {
                throw new IllegalArgumentException("totalTicks must be positive");
            }
            this.totalTicks = totalTicks;
        }

        /** Siguiente tramo, desde el final del anterior hasta {@code end} (exclusivo). */
        public Builder band(int end, int color) {
            if (end <= next || end > totalTicks) {
                throw new IllegalArgumentException("band end " + end + " out of order");
            }
            bands.add(new Band(next, end, color));
            next = end;
            return this;
        }

        public Builder warningFrom(int ticks) {
            this.warningFrom = ticks;
            return this;
        }

        public ChargeOutline build() {
            if (next != totalTicks) {
                throw new IllegalStateException("bands must cover up to " + totalTicks + ", got " + next);
            }
            return new ChargeOutline(totalTicks, warningFrom, bands);
        }
    }
}
