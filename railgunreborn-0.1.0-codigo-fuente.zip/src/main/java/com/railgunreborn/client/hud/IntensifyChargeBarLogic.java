package com.railgunreborn.client.hud;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.ability.electromaster.BodyIntensifyRules;

/** Logica pura de la carga de Body Intensify (tramos, fracciones y contorno), sin clases de Minecraft: se prueba con JUnit. */
public final class IntensifyChargeBarLogic {
    /** Ultimos ticks antes de cancelar en los que el contorno parpadea. */
    public static final int BLINK_TICKS = 20;

    public enum Segment {
        /** Aun no da efecto. */
        NOT_YET(0xFF8A8F98),
        /** Da efecto, nivel I y no seguro. */
        READY(0xFF7CC8F5),
        /** Efecto fuerte garantizado. */
        STRONG(0xFF2E9BFF),
        /** Ya no mejora ni cobra CP; sigue hasta cancelar. */
        OVERCHARGE(0xFFFFB02E);

        private final int color;

        Segment(int color) {
            this.color = color;
        }

        public int color() {
            return color;
        }

        /** Primer tick (inclusive) del tramo. */
        public int start() {
            return switch (this) {
                case NOT_YET -> 0;
                case READY -> BodyIntensifyRules.MIN_TICKS;
                case STRONG -> BodyIntensifyRules.STRONG_TICKS;
                case OVERCHARGE -> BodyIntensifyRules.MAX_CHARGE_TICKS;
            };
        }

        /** Tick (exclusivo) donde acaba el tramo. */
        public int end() {
            return switch (this) {
                case NOT_YET -> BodyIntensifyRules.MIN_TICKS;
                case READY -> BodyIntensifyRules.STRONG_TICKS;
                case STRONG -> BodyIntensifyRules.MAX_CHARGE_TICKS;
                case OVERCHARGE -> BodyIntensifyRules.TIMEOUT_TICKS;
            };
        }
    }

    private IntensifyChargeBarLogic() {
    }

    public static Segment segment(int ticks) {
        if (ticks >= BodyIntensifyRules.MAX_CHARGE_TICKS) {
            return Segment.OVERCHARGE;
        }
        if (ticks >= BodyIntensifyRules.STRONG_TICKS) {
            return Segment.STRONG;
        }
        if (ticks >= BodyIntensifyRules.MIN_TICKS) {
            return Segment.READY;
        }
        return Segment.NOT_YET;
    }

    /** Fraccion de llenado en [0, 1] sobre el tiempo de cancelacion. */
    public static float fill(float ticks) {
        return Math.clamp(ticks / BodyIntensifyRules.TIMEOUT_TICKS, 0f, 1f);
    }

    /** Fraccion del recorrido donde cae un umbral en ticks. */
    public static float markFraction(int thresholdTicks) {
        return fill(thresholdTicks);
    }

    /** En la cuenta atras final antes de cancelar. */
    public static boolean warning(int ticks) {
        return ticks >= BodyIntensifyRules.TIMEOUT_TICKS - BLINK_TICKS;
    }

    /**
     * Rectangulos {x1, y1, x2, y2} (x2/y2 exclusivos) del contorno de un cuadrado de lado {@code side} y grosor
     * {@code thickness} entre las fracciones {@code from} y {@code to} del recorrido. El recorrido sale del centro del
     * borde superior y va en sentido horario; cada lado mide {@code side}, asi que las esquinas se solapan sin hueco.
     */
    public static List<int[]> outlineStrips(float from, float to, int side, int thickness) {
        List<int[]> out = new ArrayList<>();
        float total = 4f * side;
        float a = Math.clamp(from, 0f, 1f) * total;
        float b = Math.clamp(to, 0f, 1f) * total;
        float half = side / 2f;
        // Mitad derecha de arriba, derecha, abajo, izquierda y mitad izquierda de arriba.
        float[] starts = {0f, half, half + side, half + 2f * side, half + 3f * side};
        float[] ends = {half, half + side, half + 2f * side, half + 3f * side, total};
        int h = Math.round(half);
        for (int leg = 0; leg < 5; leg++) {
            float lo = Math.max(a, starts[leg]) - starts[leg];
            float hi = Math.min(b, ends[leg]) - starts[leg];
            int d0 = Math.round(lo);
            int d1 = Math.round(hi);
            if (hi <= lo || d1 <= d0) {
                continue;
            }
            out.add(switch (leg) {
                case 0 -> new int[] {h + d0, 0, h + d1, thickness};
                case 1 -> new int[] {side - thickness, d0, side, d1};
                case 2 -> new int[] {side - d1, side - thickness, side - d0, side};
                case 3 -> new int[] {0, side - d1, thickness, side - d0};
                default -> new int[] {d0, 0, d1, thickness};
            });
        }
        return out;
    }
}
