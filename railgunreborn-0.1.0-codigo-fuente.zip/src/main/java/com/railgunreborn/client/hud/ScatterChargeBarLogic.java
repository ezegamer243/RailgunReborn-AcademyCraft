package com.railgunreborn.client.hud;

import com.railgunreborn.ability.meltdowner.ScatterBombRules;

/** Logica pura del contorno de carga de Scatter Bomb (tramos y fracciones); se prueba con JUnit. */
public final class ScatterChargeBarLogic {
    /** Ultimos ticks antes del dano propio en los que el contorno parpadea. */
    public static final int BLINK_TICKS = 20;

    public enum Segment {
        /** Aun no hay bola. */
        NOT_YET(0xFF8A8F98, 0, ScatterBombRules.FIRST_BALL_TICK),
        /** Se crean bolas y se gasta CP. */
        CHARGING(0xFF6AF26A, ScatterBombRules.FIRST_BALL_TICK, ScatterBombRules.MAX_CP_TICKS),
        /** Sin mas bolas ni CP, pero cuenta atras hacia el dano propio. */
        HOLDING(0xFFFFB02E, ScatterBombRules.MAX_CP_TICKS, ScatterBombRules.BLOW_TICK);

        private final int color;
        private final int start;
        private final int end;

        Segment(int color, int start, int end) {
            this.color = color;
            this.start = start;
            this.end = end;
        }

        public int color() {
            return color;
        }

        /** Primer tick (inclusive) del tramo. */
        public int start() {
            return start;
        }

        /** Tick (exclusivo) donde acaba el tramo. */
        public int end() {
            return end;
        }
    }

    private ScatterChargeBarLogic() {
    }

    public static Segment segment(int ticks) {
        if (ticks >= ScatterBombRules.MAX_CP_TICKS) {
            return Segment.HOLDING;
        }
        return ticks >= ScatterBombRules.FIRST_BALL_TICK ? Segment.CHARGING : Segment.NOT_YET;
    }

    /** Fraccion de llenado en [0, 1] sobre el tiempo hasta el dano propio. */
    public static float fill(float ticks) {
        return Math.clamp(ticks / ScatterBombRules.BLOW_TICK, 0f, 1f);
    }

    /** En la cuenta atras final antes del dano propio. */
    public static boolean warning(int ticks) {
        return ticks >= ScatterBombRules.BLOW_TICK - BLINK_TICKS;
    }
}
