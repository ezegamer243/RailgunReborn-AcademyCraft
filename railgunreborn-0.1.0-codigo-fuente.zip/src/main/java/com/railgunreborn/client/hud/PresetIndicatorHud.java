package com.railgunreborn.client.hud;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;

import net.minecraft.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/**
 * Indicador de cambio de preset: 4 cuadrados numerados bajo la barra de CP durante 2 s (ver
 * {@code docs/spec/preset-gui.md}, sección 2). Se dispara cuando el preset activo sincronizado cambia en el cliente
 * (tecla C, comando, sincronización tras morir...), no solo con la tecla. Se dibuja en el sistema de coordenadas de
 * diseño del CPBar (964 x 147, escala 0.2) para quedar pegado a la barra.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class PresetIndicatorHud {
    public static final ResourceLocation LAYER_ID =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "preset_indicator");

    private static final long DURATION_MS = 2000L;
    private static final long FADE_IN_MIN_GAP_MS = 3000L;
    private static final float SCALE = 0.2f;
    private static final float MARGIN_RIGHT = 12;
    private static final float MARGIN_TOP = 12;
    private static final int BOX_X = 580;
    private static final int BOX_Y = 136;
    private static final int BOX_SIZE = 52;
    private static final int BOX_STEP = 62;
    private static final int GLOW = 5;
    private static final float TEXT_SCALE = 46f / 8f; // tamaño de fuente 46 de diseño sobre los 8 de la fuente

    // -1 = aún no se ha visto ningún valor (el primero no dispara nada).
    private static int lastSeenPreset = -1;
    private static long changeTime = Long.MIN_VALUE / 2;
    private static boolean fadeIn;

    private PresetIndicatorHud() {
    }

    /** Capa propia, registrada desde {@link CPBarHud} (mismo bus de mod, mismo punto de anclaje). */
    static void register(RegisterGuiLayersEvent event) {
        event.registerAbove(CPBarHud.LAYER_ID, LAYER_ID, PresetIndicatorHud::render);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            lastSeenPreset = -1;
            return;
        }
        int active = PresetData.get(player).getActive();
        if (lastSeenPreset != -1 && active != lastSeenPreset) {
            trigger(Util.getMillis());
        }
        lastSeenPreset = active;
    }

    private static void trigger(long now) {
        // Sin fundido de entrada si se cambia varias veces seguidas.
        fadeIn = now - changeTime > FADE_IN_MIN_GAP_MS;
        changeTime = now;
    }

    /** Fracción de alfa (0..1) del relleno según el tiempo transcurrido; 0 fuera de los 2 s. */
    static float fadeAlpha(long elapsedMs, boolean fadeIn) {
        if (elapsedMs < 0 || elapsedMs >= DURATION_MS) {
            return 0f;
        }
        float progress = elapsedMs / (float) DURATION_MS;
        float alpha = 1f;
        if (fadeIn && progress < 0.2f) {
            alpha = progress / 0.2f;
        } else if (progress > 0.8f) {
            alpha = (1f - progress) / 0.2f;
        }
        return alpha * 0.75f;
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui || player.isSpectator() || !CPData.get(player).isActivated()
                || AbilityRegistries.category(AbilityData.get(player).getCategory().orElse(null)).isEmpty()) {
            return;
        }
        float alpha = fadeAlpha(Util.getMillis() - changeTime, fadeIn);
        if (alpha <= 0f) {
            return;
        }
        int active = PresetData.get(player).getActive();

        var pose = g.pose();
        pose.pushPose();
        pose.translate(g.guiWidth() - MARGIN_RIGHT - CPBarTextures.WIDTH * SCALE, MARGIN_TOP, 0);
        pose.scale(SCALE, SCALE, 1f);
        int fill = ((int) (alpha * 255) << 24) | 0x303030;
        int textAlpha = (int) (Math.max(0.05f, alpha * 0.8f) * 255);
        for (int i = 0; i < PresetData.MAX_PRESETS; i++) {
            int x = BOX_X + i * BOX_STEP;
            if (i == active) {
                HudGlow.glow(g, x, BOX_Y, BOX_SIZE, BOX_SIZE, GLOW, 0xC8FFFFFF);
            }
            g.fill(x, BOX_Y, x + BOX_SIZE, BOX_Y + BOX_SIZE, fill);
            Component number = Component.literal(String.valueOf(i + 1)).setStyle(Style.EMPTY.withBold(true));
            int width = mc.font.width(number);
            pose.pushPose();
            pose.translate(x + (BOX_SIZE - width * TEXT_SCALE) / 2f, BOX_Y + 5, 0);
            pose.scale(TEXT_SCALE, TEXT_SCALE, 1f);
            g.drawString(mc.font, number, 0, 0, (textAlpha << 24) | 0xFFFFFF, false);
            pose.popPose();
        }
        pose.popPose();
    }
}
