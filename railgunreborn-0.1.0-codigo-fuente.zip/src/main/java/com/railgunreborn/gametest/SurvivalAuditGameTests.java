package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.WirelessRegistry;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * Auditoría de supervivencia (T88): cada ítem del mod debe tener una fuente en supervivencia o estar declarado
 * solo-creativo. Para añadir ítems nuevos: si tienen receta (de cualquier tipo) no hay que hacer nada; si salen de
 * botín, generación del mundo o de una acción (cubo, rellenar), añadirlos a {@link #NON_RECIPE_SOURCES}; si son
 * solo creativos a propósito, a {@link #CREATIVE_ONLY}.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class SurvivalAuditGameTests {
    private static final String EMPTY = "empty";

    /** Ítems que no son resultado de ninguna receta pero se consiguen en supervivencia (botín, mundo, acciones). */
    private static final Set<String> NON_RECIPE_SOURCES = Set.of(
            "constraint_metal",          // mena: generación del mundo
            "crystal_ore",               // mena: generación del mundo
            "imagsil_ore",               // mena: generación del mundo
            "reso_ore",                  // mena: generación del mundo
            "reso_crystal",              // drop de reso_ore
            "phase_liquid_bucket",       // se recoge de los lagos de líquido de fase con un cubo
            "matter_unit_phase_liquid",  // unidad de materia llena con líquido de fase
            "induction_factor");         // botín de cofres (modificador global de botín)

    /** Ítems solo creativos a propósito (vacío: lo que falte debe tener fuente). */
    private static final Set<String> CREATIVE_ONLY = Set.of("cat_engine");

    @GameTest(template = EMPTY)
    public static void everyItemHasSurvivalSource(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        Set<ResourceLocation> crafted = new java.util.HashSet<>();
        for (RecipeHolder<?> holder : manager.getRecipes()) {
            ItemStack out = holder.value().getResultItem(helper.getLevel().registryAccess());
            if (!out.isEmpty()) {
                crafted.add(BuiltInRegistries.ITEM.getKey(out.getItem()));
            }
        }
        List<String> orphan = new ArrayList<>();
        for (ResourceLocation id : BuiltInRegistries.ITEM.keySet()) {
            if (!id.getNamespace().equals(RailgunReborn.MODID)) {
                continue;
            }
            String path = id.getPath();
            if (!crafted.contains(id) && !NON_RECIPE_SOURCES.contains(path) && !CREATIVE_ONLY.contains(path)) {
                orphan.add(path);
            }
        }
        if (!orphan.isEmpty()) {
            helper.fail("items without survival source (add a recipe or list them in SurvivalAuditGameTests): " + orphan);
            return;
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void auditListsAreNotStale(GameTestHelper helper) {
        List<String> stale = new ArrayList<>();
        for (String path : NON_RECIPE_SOURCES) {
            if (!BuiltInRegistries.ITEM.containsKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path))) {
                stale.add(path);
            }
        }
        for (String path : CREATIVE_ONLY) {
            if (!BuiltInRegistries.ITEM.containsKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path))) {
                stale.add(path);
            }
        }
        if (!stale.isEmpty()) {
            helper.fail("audit lists name unknown items: " + stale);
            return;
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerNormalGrid(GameTestHelper helper) {
        ItemStack e = ItemStack.EMPTY;
        ItemStack dev = new ItemStack(ModItems.DEVELOPER_PORTABLE.get());
        ItemStack core = new ItemStack(WirelessRegistry.MAT_CORE_0.get());
        ItemStack bed = new ItemStack(Items.RED_BED);
        ItemStack piston = new ItemStack(Items.PISTON);
        ItemStack crystal = new ItemStack(ModItems.CRYSTAL_NORMAL.get());
        ItemStack frame = new ItemStack(ModItems.MACHINE_FRAME.get());
        ItemStack redstone = new ItemStack(Items.REDSTONE);
        craftsInto(helper, List.of(e, dev, e, core, bed, piston, crystal, frame, redstone),
                ModItems.DEVELOPER_NORMAL.get(), "developer_normal with portable");
        ItemStack brain = new ItemStack(ModItems.BRAIN_COMPONENT.get());
        ItemStack info = new ItemStack(ModItems.INFO_COMPONENT.get());
        ItemStack conv = new ItemStack(ModItems.ENERGY_CONVERT_COMPONENT.get());
        craftsInto(helper, List.of(brain, info, conv, core, bed, piston, crystal, frame, redstone),
                ModItems.DEVELOPER_NORMAL.get(), "developer_normal without portable");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerAdvancedGrid(GameTestHelper helper) {
        ItemStack plate = new ItemStack(ModItems.CONSTRAINT_PLATE.get());
        ItemStack glow = new ItemStack(Items.GLOWSTONE_DUST);
        ItemStack dev = new ItemStack(ModItems.DEVELOPER_NORMAL.get());
        ItemStack node = new ItemStack(WirelessRegistry.NODE_STANDARD_ITEM.get());
        ItemStack pure = new ItemStack(ModItems.CRYSTAL_PURE.get());
        ItemStack reso = new ItemStack(ModItems.RESO_CRYSTAL.get());
        craftsInto(helper, List.of(plate, plate, plate, glow, dev, glow, node, pure, reso),
                ModItems.DEVELOPER_ADVANCED.get(), "developer_advanced");
        // Con la piedra luminosa en otro sitio no debe salir.
        CraftingInput wrong = CraftingInput.of(3, 3,
                List.of(plate, plate, plate, dev, glow, glow, node, pure, reso));
        if (helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, wrong, helper.getLevel())
                .isPresent()) {
            helper.fail("developer_advanced must not craft with a scrambled grid");
            return;
        }
        helper.succeed();
    }

    private static void craftsInto(GameTestHelper helper, List<ItemStack> grid, Item expected, String label) {
        CraftingInput input = CraftingInput.of(3, 3, grid);
        ItemStack out = helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        if (!out.is(expected) || out.getCount() != 1) {
            helper.fail(label + ": expected " + expected + " x1 but got " + out);
        }
    }
}
