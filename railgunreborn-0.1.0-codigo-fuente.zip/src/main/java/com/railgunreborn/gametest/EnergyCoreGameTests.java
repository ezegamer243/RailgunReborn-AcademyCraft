package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModDataComponents;
import com.railgunreborn.registry.ModItems;

import io.netty.buffer.Unpooled;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests del núcleo de energía (T97): Energy Unit, componente, ranura de batería, config. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class EnergyCoreGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos POS = new BlockPos(1, 1, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static ItemStack unit(int energy) {
        return EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT.get()), energy);
    }

    private static IEnergyStorage cap(GameTestHelper helper, ItemStack stack) {
        IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        if (storage == null) {
            helper.fail("no FE capability on " + stack);
            throw new IllegalStateException();
        }
        return storage;
    }

    @GameTest(template = EMPTY)
    public static void energyUnitChargesWithinLimits(GameTestHelper helper) {
        ItemStack stack = new ItemStack(ModItems.ENERGY_UNIT.get());
        check(helper, stack.getMaxStackSize() == 1, "energy unit should not stack");
        IEnergyStorage storage = cap(helper, stack);
        check(helper, storage.getMaxEnergyStored() == 10_000, "capacity should be 10000");
        check(helper, storage.getEnergyStored() == 0, "a new unit is empty");
        check(helper, storage.extractEnergy(100, false) == 0, "nothing to extract from an empty unit");
        check(helper, storage.receiveEnergy(1000, true) == 20, "simulated receive limited to 20");
        check(helper, storage.getEnergyStored() == 0, "simulate must not change energy");
        check(helper, storage.receiveEnergy(1000, false) == 20, "receive limited to 20 per call");
        check(helper, EnergyUnitItem.getEnergy(stack) == 20, "energy stored in the component");
        int calls = 1;
        while (storage.receiveEnergy(1000, false) > 0) {
            calls++;
        }
        check(helper, calls == 500, "10000 / 20 = 500 calls to fill, got " + calls);
        check(helper, storage.getEnergyStored() == 10_000, "full at 10000, got " + storage.getEnergyStored());
        check(helper, storage.receiveEnergy(5, false) == 0, "a full unit accepts nothing");
        check(helper, storage.extractEnergy(1000, false) == 20, "extract limited to 20 per call");
        check(helper, storage.extractEnergy(7, false) == 7, "small extract");
        check(helper, cap(helper, stack).getEnergyStored() == 9973, "a fresh capability reads the component");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void energyComponentPersists(GameTestHelper helper) {
        var registries = helper.getLevel().registryAccess();
        ItemStack stack = unit(1234);
        Tag saved = stack.save(registries);
        ItemStack loaded = ItemStack.parseOptional(registries, (CompoundTag) saved);
        check(helper, loaded.is(ModItems.ENERGY_UNIT.get()) && EnergyUnitItem.getEnergy(loaded) == 1234,
                "codec round trip lost energy: " + saved);
        RegistryFriendlyByteBuf buf = new RegistryFriendlyByteBuf(Unpooled.buffer(), registries);
        try {
            ItemStack.STREAM_CODEC.encode(buf, stack);
            ItemStack synced = ItemStack.STREAM_CODEC.decode(buf);
            check(helper, EnergyUnitItem.getEnergy(synced) == 1234, "stream codec lost energy");
        } finally {
            buf.release();
        }
        check(helper, unit(99_999).get(ModDataComponents.ENERGY.get()) == 10_000, "withEnergy clamps to capacity");
        check(helper, unit(EnergyUnitItem.CAPACITY).getBarWidth() == 13, "full bar");
        check(helper, new ItemStack(ModItems.ENERGY_UNIT.get()).getBarWidth() == 0, "empty bar");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void batterySlotMovesEnergy(GameTestHelper helper) {
        int[] changes = {0};
        ModEnergyStorage machine = ModEnergyStorage.receiver(2000, 50, () -> changes[0]++);
        ItemStack full = unit(10_000);
        check(helper, BatterySlot.dischargeItem(full, machine, 50) == 20, "item bandwidth (20) limits discharge");
        check(helper, machine.getEnergyStored() == 20 && EnergyUnitItem.getEnergy(full) == 9980,
                "discharge moved wrong amounts");
        check(helper, changes[0] == 1, "onChanged should run once, ran " + changes[0]);
        check(helper, BatterySlot.dischargeItem(full, machine, 5) == 5, "machine rate (5) limits discharge");
        machine.setEnergy(1995);
        check(helper, BatterySlot.dischargeItem(full, machine, 50) == 5, "machine space limits discharge");
        check(helper, BatterySlot.dischargeItem(full, machine, 50) == 0 && machine.isFull(), "full machine");

        ModEnergyStorage generator = ModEnergyStorage.provider(1000, 100, () -> changes[0]++);
        generator.addEnergy(1000, false);
        check(helper, generator.getEnergyStored() == 1000, "addEnergy ignores the receive limit of 0");
        check(helper, generator.receiveEnergy(10, false) == 0, "generator accepts nothing from outside");
        ItemStack empty = unit(0);
        check(helper, BatterySlot.chargeItem(empty, generator, 100) == 20, "item bandwidth limits charging");
        check(helper, generator.getEnergyStored() == 980 && EnergyUnitItem.getEnergy(empty) == 20,
                "charge moved wrong amounts");
        generator.setEnergy(3);
        check(helper, BatterySlot.chargeItem(empty, generator, 100) == 3, "source energy limits charging");

        // Entre dos almacenes FE cualesquiera: respeta los topes públicos de ambos.
        check(helper, BatterySlot.transfer(cap(helper, full), machine, 100) == 0, "machine already full");
        machine.setEnergy(0);
        check(helper, BatterySlot.transfer(cap(helper, full), machine, 100) == 20, "transfer limited by item");
        check(helper, BatterySlot.transfer(machine, cap(helper, empty), 100) == 0, "receiver cannot extract");
        check(helper, BatterySlot.dischargeItem(new ItemStack(Items.DIAMOND), machine, 50) == 0, "no FE item");
        check(helper, machine.tryConsume(20) && machine.getEnergyStored() == 0, "tryConsume takes everything");
        check(helper, !machine.tryConsume(1), "tryConsume is all or nothing");

        CompoundTag tag = new CompoundTag();
        generator.setEnergy(777);
        generator.save(tag, "Energy", helper.getLevel().registryAccess());
        ModEnergyStorage copy = ModEnergyStorage.provider(1000, 100, () -> {
        });
        copy.load(tag, "Energy", helper.getLevel().registryAccess());
        check(helper, copy.getEnergyStored() == 777, "storage save/load");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void configFallsBackToDefaults(GameTestHelper helper) {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        ModConfigSpec.BooleanValue flag = builder.define("flag", true);
        ModConfigSpec.IntValue rate = builder.defineInRange("rate", 1000, 1, Integer.MAX_VALUE);
        ModConfigSpec unloaded = builder.build();
        check(helper, !unloaded.isLoaded(), "test spec should not be loaded");
        check(helper, RailgunConfig.readOrDefault(unloaded, flag), "unloaded boolean -> default");
        check(helper, RailgunConfig.readOrDefault(unloaded, rate) == 1000, "unloaded int -> default");
        check(helper, RailgunConfig.ENERGY_REQUIRED.getDefault(), "energyRequired defaults to true");
        check(helper, RailgunConfig.REACTOR_CHARGE_RATE.getDefault() == 1000, "reactorChargeRate default 1000");
        check(helper, RailgunConfig.GENERATOR_MULTIPLIER.getDefault() == 1.0, "generatorMultiplier default 1.0");
        // Con el servidor arrancado la config está cargada: los accesores no deben lanzar.
        RailgunConfig.energyRequired();
        check(helper, RailgunConfig.reactorChargeRate() >= 1, "reactor charge rate in range");
        check(helper, RailgunConfig.generatorMultiplier() >= 0, "generator multiplier in range");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void batterySlotsAcceptAnyFeItem(GameTestHelper helper) {
        ItemStack fake = new ItemStack(Items.LIGHTNING_ROD);
        check(helper, BatterySlot.isEnergyItem(fake), "the test-only FE item should have the capability");
        helper.setBlock(POS, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof ImagFusorBlockEntity fusor)) {
            helper.fail("imag fusor block entity missing");
            return;
        }
        var items = fusor.getItems();
        int slot = ImagFusorBlockEntity.SLOT_BATTERY;
        check(helper, items.isItemValid(slot, unit(0)), "fusor battery slot accepts an energy unit");
        check(helper, items.isItemValid(slot, fake), "fusor battery slot accepts any FE item");
        check(helper, !items.isItemValid(slot, new ItemStack(Items.DIAMOND)), "fusor battery slot rejects others");
        check(helper, items.insertItem(slot, fake.copy(), false).isEmpty(), "FE item inserted in the fusor");

        BlockPos formerPos = POS.east();
        helper.setBlock(formerPos, MetalFormerRegistry.METAL_FORMER.get().defaultBlockState());
        if (!(helper.getBlockEntity(formerPos) instanceof MetalFormerBlockEntity former)) {
            helper.fail("metal former block entity missing");
            return;
        }
        int battery = MetalFormerBlockEntity.SLOT_BATTERY;
        check(helper, former.getItems().isItemValid(battery, unit(10_000)), "former battery accepts an energy unit");
        check(helper, former.getItems().isItemValid(battery, fake), "former battery accepts any FE item");
        check(helper, !former.getItems().isItemValid(battery, new ItemStack(Items.IRON_INGOT)),
                "former battery rejects others");
        helper.succeed();
    }

    // --- Baterías High y Mega (T110) ---

    private static void checkBattery(GameTestHelper helper, ItemStack stack, int capacity, int transfer) {
        check(helper, stack.getMaxStackSize() == 1, "battery should not stack");
        IEnergyStorage storage = cap(helper, stack);
        check(helper, storage.getMaxEnergyStored() == capacity, "capacity should be " + capacity);
        check(helper, storage.getEnergyStored() == 0, "a new battery is empty");
        check(helper, storage.receiveEnergy(100_000, true) == transfer, "simulated receive limited to " + transfer);
        check(helper, storage.receiveEnergy(100_000, false) == transfer, "receive limited per call");
        int calls = 1;
        while (storage.receiveEnergy(100_000, false) > 0) {
            calls++;
        }
        check(helper, calls == capacity / transfer, "calls to fill: " + calls);
        check(helper, storage.getEnergyStored() == capacity, "full at " + capacity);
        check(helper, storage.extractEnergy(100_000, false) == transfer, "extract limited per call");
        check(helper, EnergyUnitItem.withEnergy(stack, capacity * 2).get(ModDataComponents.ENERGY.get()) == capacity,
                "withEnergy clamps to the battery capacity");
        check(helper, stack.getBarWidth() == 13, "full bar");
        check(helper, new ItemStack(stack.getItem()).getBarWidth() == 0, "empty bar");
    }

    @GameTest(template = EMPTY)
    public static void highBatteryCapacityAndTransfer(GameTestHelper helper) {
        checkBattery(helper, new ItemStack(ModItems.ENERGY_UNIT_HIGH.get()), 20_000, 40);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void megaBatteryCapacityAndTransfer(GameTestHelper helper) {
        checkBattery(helper, new ItemStack(ModItems.ENERGY_UNIT_MEGA.get()), 40_000, 80);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void highAndMegaRecipesGiveEmptyBatteries(GameTestHelper helper) {
        var level = helper.getLevel();
        for (String[] pair : new String[][] {{"energy_unit_high", "high"}, {"energy_unit_mega", "mega"}}) {
            var holder = level.getRecipeManager()
                    .byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, pair[0]));
            check(helper, holder.isPresent(), "missing recipe " + pair[0]);
            ItemStack out = holder.get().value().getResultItem(level.registryAccess());
            Item expected = pair[1].equals("high") ? ModItems.ENERGY_UNIT_HIGH.get() : ModItems.ENERGY_UNIT_MEGA.get();
            check(helper, out.is(expected) && out.getCount() == 1, pair[0] + " should output one battery, got " + out);
            check(helper, EnergyUnitItem.getEnergy(out) == 0 && !out.has(ModDataComponents.ENERGY.get()),
                    pair[0] + " output should be empty");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void highAndMegaWorkInFusorBatterySlot(GameTestHelper helper) {
        helper.setBlock(POS, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof ImagFusorBlockEntity be)) {
            helper.fail("imag fusor block entity missing");
            return;
        }
        be.getEnergy().setEnergy(0);
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_BATTERY,
                EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT_MEGA.get()), 3000));
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getEnergy().getEnergyStored() > 0, "mega battery should charge the fusor");
            helper.assertTrue(EnergyUnitItem.getEnergy(be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_BATTERY))
                    + be.getEnergy().getEnergyStored() == 3000, "energy must be conserved");
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void highBatteryInsertableInFusorSlot(GameTestHelper helper) {
        helper.setBlock(POS, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof ImagFusorBlockEntity be)) {
            helper.fail("imag fusor block entity missing");
            return;
        }
        be.getEnergy().setEnergy(0);
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_BATTERY,
                EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT_HIGH.get()), 500));
        helper.succeedWhen(() -> helper.assertTrue(be.getEnergy().getEnergyStored() > 0,
                "high battery should charge the fusor"));
    }
}
