package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.PenetrateRules;
import com.railgunreborn.ability.teleporter.PenetrateTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Penetrate Teleport (T59). Jugador falso de nivel 2 sobre un suelo de piedra de 9x9. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class PenetrateTeleportGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper, Vec3 at, float yaw) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-penetrate"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la dirección de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Muro de piedra de 3 de alto en X 2-7 y Z {@code [z0, z1]}. */
    private static void wall(GameTestHelper helper, int z0, int z1) {
        for (int z = z0; z <= z1; z++) {
            for (int y = 1; y <= 3; y++) {
                for (int x = 2; x <= 7; x++) {
                    helper.setBlock(new BlockPos(x, y, z), Blocks.STONE);
                }
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void check0(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    /** Teleporter nivel 2 con Penetrate aprendida (exp 0), CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(2);
        Skill skill = Teleporter.PENETRATE_TELEPORT.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, pide {@code distance} (null = la que hay por defecto, la máxima), mantiene un tick y suelta. */
    private static void use(ServerPlayer player, Skill skill, Double distance) {
        check0(SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        if (distance != null) {
            CompoundTag data = new CompoundTag();
            data.putDouble(PenetrateTeleportSkill.DISTANCE_KEY, distance);
            SkillContexts.handleClientMessage(player, 1, PenetrateTeleportSkill.CHANNEL_DISTANCE, data);
        }
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
        SkillContexts.tick(player);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel2UnderThreatening(GameTestHelper helper) {
        Skill skill = Teleporter.PENETRATE_TELEPORT.get();
        check(helper, skill.getId().equals(Teleporter.PENETRATE_TELEPORT_ID), "id " + skill.getId());
        check(helper, skill.getLevel() == 2 && skill.canControl(), "level 2, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.THREATENING_TELEPORT_ID)
                && p.minExp() == 0.5f).orElse(false), "parent: threatening_teleport 0.5");
        check(helper, skill.getGuiX() == 60 && skill.getGuiY() == 46, "gui position 60, 46");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/penetrate_teleport.png"),
                "icon " + skill.getIcon());
        check(helper, Teleporter.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void goesThroughATwoBlockWall(GameTestHelper helper) {
        floor(helper);
        wall(helper, 3, 4);
        ServerPlayer player = player(helper, new Vec3(4.5, 1, 1.5), 0f);
        Skill skill = setUp(player);
        float cpBefore = CPData.get(player).getCP();

        use(player, skill, 6.0);

        Vec3 expected = helper.absoluteVec(new Vec3(4.5, 1, 7.5));
        check(helper, player.position().distanceTo(expected) < 1e-3,
                "behind the wall at z 7.5, was " + helper.relativeVec(player.position()));
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 6 * 14f) < 0.5f,
                "CP: 6 blocks x 14, spent " + (cpBefore - CPData.get(player).getCP()));
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 50, "cooldown 50");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId())
                - 6 * PenetrateRules.EXP_PER_BLOCK) < 1e-6f, "exp 0.00014 per block");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void endingInsideRockDoesNothing(GameTestHelper helper) {
        floor(helper);
        wall(helper, 3, 8);
        ServerPlayer player = player(helper, new Vec3(4.5, 1, 1.5), 0f);
        Skill skill = setUp(player);
        Vec3 start = player.position();
        float cpBefore = CPData.get(player).getCP();
        float overloadBefore = CPData.get(player).getOverload();

        use(player, skill, 5.0);

        check(helper, player.position().equals(start), "did not move, now " + helper.relativeVec(player.position()));
        check(helper, CPData.get(player).getCP() == cpBefore && CPData.get(player).getOverload() == overloadBefore,
                "nothing charged");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 0, "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void requestedDistanceIsClampedToTheMaximum(GameTestHelper helper) {
        floor(helper);
        // Diagonal hacia +X +Z: hay sitio para 10 bloques (el máximo con exp 0).
        ServerPlayer player = player(helper, new Vec3(0.5, 1, 0.5), -45f);
        Skill skill = setUp(player);
        Vec3 start = player.position();
        float cpBefore = CPData.get(player).getCP();

        use(player, skill, 100.0);

        double moved = start.distanceTo(player.position());
        check(helper, Math.abs(moved - 10) < 1e-3, "moved the max 10 blocks, moved " + moved);
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 140f) < 0.5f,
                "CP 140, spent " + (cpBefore - CPData.get(player).getCP()));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpNothingHappens(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, new Vec3(4.5, 1, 1.5), 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP());
        check(helper, cp.getCP() == 0f, "CP drained");
        Vec3 start = player.position();

        use(player, skill, 5.0);

        check(helper, player.position().equals(start), "did not move");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 0, "no cooldown");
        check(helper, cp.getOverload() == 0f, "no overload");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void cpLimitsTheDistance(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, new Vec3(4.5, 1, 1.5), 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        // Quedan 42 CP: 3 bloques a 14 por bloque.
        cp.consumeWithForce(player, 0f, cp.getCP() - 42f);
        Vec3 start = player.position();

        use(player, skill, 6.0);

        double moved = start.distanceTo(player.position());
        check(helper, Math.abs(moved - 3) < 1e-2, "CP allows 3 blocks, moved " + moved);
        check(helper, cp.getCP() < 0.5f, "all CP spent, left " + cp.getCP());
        helper.succeed();
    }
}
