package com.railgunreborn.gametest;

import java.util.Optional;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.teleporter.SpaceCriticals;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.teleporter.TpDamage;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de la categoría Teleporter y sus piezas compartidas (T56): registro, críticos, daño y SafeTeleport. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class TeleporterGameTests {
    private static final String EMPTY = "empty";
    private static final String TALL = "tall";
    private static final float EPS = 1e-3f;

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static ServerPlayer teleporter(GameTestHelper helper, String name, boolean dimFolding,
            boolean spaceFluct) {
        ServerPlayer player = player(helper, name, new Vec3(4.5, 1, 1.5));
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(4);
        if (dimFolding) {
            ability.learnSkill(Teleporter.DIM_FOLDING_ID);
        }
        if (spaceFluct) {
            ability.learnSkill(Teleporter.SPACE_FLUCT_ID);
        }
        CPData.get(player);
        return player;
    }

    /** Cerdo quieto sobre piedra. */
    private static Pig pig(GameTestHelper helper, int x, int z) {
        helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
        return helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(x + 0.5, 1, z + 0.5));
    }

    private static int run(ServerPlayer player, String command) {
        try {
            return player.server.getCommands().getDispatcher().execute(command,
                    player.createCommandSourceStack().withPermission(4).withSuppressedOutput());
        } catch (CommandSyntaxException e) {
            return 0;
        }
    }

    /** Primera semilla cuya tirada con esas exp da un nivel que cumple {@code wanted}. */
    private static long seedFor(float dimExp, float fluctExp, java.util.function.IntPredicate wanted) {
        for (long seed = 0; seed < 10_000; seed++) {
            if (wanted.test(SpaceCriticals.roll(RandomSource.create(seed), dimExp, fluctExp))) {
                return seed;
            }
        }
        throw new IllegalStateException("no seed found");
    }

    private static boolean bypassesArmor(GameTestHelper helper, ResourceKey<DamageType> key) {
        return helper.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(key)
                .is(DamageTypeTags.BYPASSES_ARMOR);
    }

    // --- Registro y comandos ---

    @GameTest(template = EMPTY)
    public static void teleporterCategoryIsRegistered(GameTestHelper helper) {
        Category category = AbilityRegistries.category(Teleporter.ID).orElse(null);
        check(helper, category != null, "teleporter category should be registered");
        check(helper, category == Teleporter.CATEGORY.get(), "registry entry should be the holder's");
        check(helper, AbilityRegistries.CATEGORY_REGISTRY.size() >= 3,
                "the Developer picks among electromaster, meltdowner and teleporter, found "
                        + AbilityRegistries.CATEGORY_REGISTRY.size());
        check(helper, category.getColor() == Teleporter.COLOR, "category color");
        check(helper, category.getIcon().getPath().equals("textures/category/teleporter_icon.png"),
                "icon path " + category.getIcon());

        Skill dim = Teleporter.DIM_FOLDING.get();
        check(helper, dim.getId().equals(Teleporter.DIM_FOLDING_ID), "dim folding id " + dim.getId());
        check(helper, dim.getLevel() == 1 && !dim.canControl(), "dim folding: level 1, passive");
        check(helper, dim.getParent().map(p -> p.skill().equals(Teleporter.THREATENING_TELEPORT_ID)
                && p.minExp() == 0.2f).orElse(false), "dim folding parent: threatening_teleport 0.2");
        check(helper, dim.getGuiX() == 50 && dim.getGuiY() == 75, "dim folding gui position");
        check(helper, dim.getIcon().getPath().equals("textures/skill/teleporter/dim_folding_theorem.png"),
                "dim folding icon " + dim.getIcon());

        Skill fluct = Teleporter.SPACE_FLUCT.get();
        check(helper, fluct.getId().equals(Teleporter.SPACE_FLUCT_ID), "space fluct id " + fluct.getId());
        check(helper, fluct.getLevel() == 4 && !fluct.canControl(), "space fluct: level 4, passive");
        check(helper, fluct.getParent().map(p -> p.skill().equals(Teleporter.SHIFT_TP_ID) && p.minExp() == 0f)
                .orElse(false), "space fluct parent: shift_tp 0.0");
        check(helper, fluct.getGuiX() == 160 && fluct.getGuiY() == 80, "space fluct gui position");

        for (GenericRules.Kind kind : GenericRules.Kind.values()) {
            check(helper, Teleporter.GENERICS.get(kind).get().getCategoryId().equals(Teleporter.ID),
                    "generic " + kind + " registered for teleporter");
        }
        check(helper, category.getSkills().contains(dim) && category.getSkills().contains(fluct),
                "teleporter skills include both passives: " + category.getSkills());

        check(helper, bypassesArmor(helper, ModDamageTypes.THREATENING_TELEPORT), "threatening ignores armor");
        check(helper, bypassesArmor(helper, ModDamageTypes.FLESH_RIPPING), "flesh ripping ignores armor");
        check(helper, !bypassesArmor(helper, ModDamageTypes.SHIFT_TELEPORT), "shift teleport respects armor");
        check(helper, ModItems.NEEDLE.get().getDefaultMaxStackSize() == 64, "needle is a plain item of 64");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void commandSetsTeleporterAndLearnsPassives(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-tp-command", new Vec3(4.5, 1, 1.5));
        check(helper, run(player, "railgunreborn category teleporter") > 0, "category command should succeed");
        check(helper, run(player, "railgunreborn level 4") > 0, "level command should succeed");
        AbilityData ability = AbilityData.get(player);
        check(helper, ability.getCategory().map(Teleporter.ID::equals).orElse(false),
                "category should be teleporter, was " + ability.getCategory());
        check(helper, ability.getLevel() == 4, "level should be 4");
        check(helper, run(player, "railgunreborn learn teleporter/dim_folding_theorem") > 0, "learn dim folding");
        check(helper, run(player, "railgunreborn learn teleporter/space_fluct") > 0, "learn space fluct");
        check(helper, ability.isLearned(Teleporter.DIM_FOLDING_ID) && ability.isLearned(Teleporter.SPACE_FLUCT_ID),
                "both passives learned");
        helper.succeed();
    }

    // --- TpDamage ---

    @GameTest(template = EMPTY)
    public static void noPassivesMeansNoCritical(GameTestHelper helper) {
        ServerPlayer player = teleporter(helper, "test-tp-nocrit", false, false);
        Pig pig = pig(helper, 4, 4);
        Skill skill = Teleporter.DIM_FOLDING.get();
        for (int i = 0; i < 30; i++) {
            float before = pig.getHealth();
            TpDamage.Result result = TpDamage.attack(player, skill, ModDamageTypes.THREATENING_TELEPORT, pig, 0.5f,
                    false, true);
            check(helper, result.hurt() && !result.critical(), "hit " + i + " should hurt without critical");
            check(helper, Math.abs(before - pig.getHealth() - 0.5f) < EPS, "plain damage");
            pig.setHealth(pig.getMaxHealth());
        }
        AbilityData ability = AbilityData.get(player);
        check(helper, !ability.isLearned(Teleporter.DIM_FOLDING_ID) && !ability.isLearned(Teleporter.SPACE_FLUCT_ID),
                "no passive may be learned by hitting");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void dimFoldingCriticalMultipliesAndGivesExp(GameTestHelper helper) {
        ServerPlayer player = teleporter(helper, "test-tp-dimcrit", true, false);
        Pig pig = pig(helper, 4, 4);
        long seed = seedFor(0f, SpaceCriticals.NOT_LEARNED, tier -> tier == 0);
        float before = pig.getHealth();
        TpDamage.Result result = TpDamage.attack(player, Teleporter.DIM_FOLDING.get(),
                ModDamageTypes.THREATENING_TELEPORT, pig, 2f, false, false, RandomSource.create(seed));
        check(helper, result.hurt() && result.tier() == 0, "seeded hit should be a x1.3 critical, was " + result);
        check(helper, Math.abs(result.multiplier() - 1.3f) < EPS, "multiplier 1.3");
        check(helper, Math.abs(before - pig.getHealth() - 2.6f) < EPS,
                "damage 2 x 1.3 = 2.6, lost " + (before - pig.getHealth()));
        AbilityData ability = AbilityData.get(player);
        check(helper, Math.abs(ability.getSkillExp(Teleporter.DIM_FOLDING_ID) - 0.005f) < 1e-5f,
                "dim folding +0.005, was " + ability.getSkillExp(Teleporter.DIM_FOLDING_ID));
        check(helper, !ability.isLearned(Teleporter.SPACE_FLUCT_ID), "space fluct stays unlearned");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void spaceFluctGivesHigherTiersAndOnlyItsOwnExp(GameTestHelper helper) {
        ServerPlayer player = teleporter(helper, "test-tp-fluctcrit", false, true);
        Pig pig = pig(helper, 4, 4);
        long seed = seedFor(SpaceCriticals.NOT_LEARNED, 0f, tier -> tier >= 1);
        int expected = SpaceCriticals.roll(RandomSource.create(seed), SpaceCriticals.NOT_LEARNED, 0f);
        float before = pig.getHealth();
        TpDamage.Result result = TpDamage.attack(player, Teleporter.SPACE_FLUCT.get(),
                ModDamageTypes.THREATENING_TELEPORT, pig, 2f, false, false, RandomSource.create(seed));
        check(helper, result.hurt() && result.tier() == expected, "tier " + expected + " expected, was " + result);
        check(helper, Math.abs(before - pig.getHealth() - 2f * SpaceCriticals.rate(expected)) < EPS,
                "multiplied damage, lost " + (before - pig.getHealth()));
        AbilityData ability = AbilityData.get(player);
        check(helper, Math.abs(ability.getSkillExp(Teleporter.SPACE_FLUCT_ID) - 0.001f) < 1e-6f,
                "space fluct +0.001, was " + ability.getSkillExp(Teleporter.SPACE_FLUCT_ID));
        check(helper, !ability.isLearned(Teleporter.DIM_FOLDING_ID), "dim folding stays unlearned");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void criticalWithoutDamageGivesNothing(GameTestHelper helper) {
        ServerPlayer player = teleporter(helper, "test-tp-nodamage", true, true);
        long seed = seedFor(0f, 0f, tier -> tier >= 0);
        AbilityData ability = AbilityData.get(player);

        Pig invulnerable = pig(helper, 4, 4);
        invulnerable.setInvulnerable(true);
        TpDamage.Result result = TpDamage.attack(player, Teleporter.DIM_FOLDING.get(),
                ModDamageTypes.THREATENING_TELEPORT, invulnerable, 2f, false, false, RandomSource.create(seed));
        check(helper, !result.hurt() && !result.critical(), "invulnerable target: no hit, was " + result);

        helper.setBlock(new BlockPos(6, 0, 4), Blocks.STONE);
        Wolf wolf = helper.spawnWithNoFreeWill(EntityType.WOLF, new Vec3(6.5, 1, 4.5));
        wolf.tame(player);
        float wolfHealth = wolf.getHealth();
        result = TpDamage.attack(player, Teleporter.DIM_FOLDING.get(), ModDamageTypes.THREATENING_TELEPORT, wolf, 2f,
                false, false, RandomSource.create(seed));
        check(helper, !result.hurt() && wolf.getHealth() == wolfHealth, "own pet must not be hurt");

        check(helper, ability.getSkillExp(Teleporter.DIM_FOLDING_ID) == 0f
                && ability.getSkillExp(Teleporter.SPACE_FLUCT_ID) == 0f, "no exp without effective damage");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void protectedPlayerIsNotHurt(GameTestHelper helper) {
        ServerPlayer attacker = teleporter(helper, "test-tp-pvp-a", true, true);
        ServerPlayer victim = player(helper, "test-tp-pvp-b", new Vec3(4.5, 1, 4.5));
        var scoreboard = helper.getLevel().getScoreboard();
        var team = scoreboard.addPlayerTeam("tp_pvp_" + UUID.randomUUID().toString().substring(0, 8));
        team.setAllowFriendlyFire(false);
        scoreboard.addPlayerToTeam(attacker.getScoreboardName(), team);
        scoreboard.addPlayerToTeam(victim.getScoreboardName(), team);
        try {
            float before = victim.getHealth();
            TpDamage.Result result = TpDamage.attack(attacker, Teleporter.DIM_FOLDING.get(),
                    ModDamageTypes.FLESH_RIPPING, victim, 4f, false, false,
                    RandomSource.create(seedFor(0f, 0f, tier -> tier >= 0)));
            check(helper, !result.hurt() && victim.getHealth() == before, "a protected player must not be hurt");
            check(helper, AbilityData.get(attacker).getSkillExp(Teleporter.DIM_FOLDING_ID) == 0f, "no exp");
        } finally {
            scoreboard.removePlayerTeam(team);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void damageTypeDecidesArmor(GameTestHelper helper) {
        ServerPlayer player = teleporter(helper, "test-tp-armor", false, false);
        Skill skill = Teleporter.DIM_FOLDING.get();
        Zombie[] zombies = new Zombie[2];
        for (int i = 0; i < 2; i++) {
            helper.setBlock(new BlockPos(2 + 4 * i, 0, 5), Blocks.STONE);
            Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(2.5 + 4 * i, 1, 5.5));
            zombie.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
            zombie.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
            zombie.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
            zombie.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
            zombies[i] = zombie;
        }
        // Los atributos de armadura del equipo se aplican en el siguiente tick de la entidad.
        helper.runAfterDelay(2, () -> {
            float before0 = zombies[0].getHealth();
            float before1 = zombies[1].getHealth();
            check(helper, TpDamage.attack(player, skill, ModDamageTypes.THREATENING_TELEPORT, zombies[0], 4f).hurt(),
                    "threatening hits");
            check(helper, TpDamage.attack(player, skill, ModDamageTypes.SHIFT_TELEPORT, zombies[1], 4f).hurt(),
                    "shift hits");
            float lost0 = before0 - zombies[0].getHealth();
            float lost1 = before1 - zombies[1].getHealth();
            check(helper, Math.abs(lost0 - 4f) < EPS, "armor ignored: lost " + lost0);
            check(helper, lost1 < 3f, "armor applies to shift teleport: lost " + lost1);
            helper.succeed();
        });
    }

    // --- SafeTeleport ---

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    @GameTest(template = TALL)
    public static void safeTeleportRejectsBlocksAndLava(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-tp-safe", new Vec3(1.5, 1, 1.5));
        ServerLevel level = helper.getLevel();
        helper.setBlock(new BlockPos(4, 1, 4), Blocks.STONE);
        helper.setBlock(new BlockPos(4, 2, 4), Blocks.STONE);
        check(helper, SafeTeleport.validate(level, player, helper.absoluteVec(new Vec3(4.5, 1, 4.5))).isEmpty(),
                "inside a block is rejected");
        // Cabeza dentro de un bloque.
        helper.setBlock(new BlockPos(6, 2, 4), Blocks.STONE);
        check(helper, SafeTeleport.validate(level, player, helper.absoluteVec(new Vec3(6.5, 1, 4.5))).isEmpty(),
                "head inside a block is rejected");
        helper.setBlock(new BlockPos(2, 1, 6), Blocks.LAVA);
        check(helper, SafeTeleport.validate(level, player, helper.absoluteVec(new Vec3(2.5, 1, 6.5))).isEmpty(),
                "lava is rejected");
        helper.setBlock(new BlockPos(2, 1, 6), Blocks.AIR);
        helper.setBlock(new BlockPos(6, 0, 6), Blocks.MAGMA_BLOCK);
        check(helper, SafeTeleport.validate(level, player, helper.absoluteVec(new Vec3(6.5, 1, 6.5))).isEmpty(),
                "standing on magma is rejected");
        check(helper, SafeTeleport.validate(level, player, helper.absoluteVec(new Vec3(2.5, 1, 2.5))).isPresent(),
                "free spot on the floor is valid");
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void safeTeleportSnapsToGroundWithinThreeBlocks(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-tp-snap", new Vec3(1.5, 1, 1.5));
        ServerLevel level = helper.getLevel();
        Vec3 high = helper.absoluteVec(new Vec3(4.5, 3.5, 4.5));
        Optional<Vec3> snapped = SafeTeleport.validate(level, player, high);
        check(helper, snapped.isPresent() && Math.abs(snapped.get().y - helper.absoluteVec(new Vec3(0, 1, 0)).y) < 1e-6,
                "2.5 blocks above the floor: lands on it, was " + snapped);
        Vec3 sky = helper.absoluteVec(new Vec3(4.5, 8, 4.5));
        Optional<Vec3> air = SafeTeleport.validate(level, player, sky);
        check(helper, air.isPresent() && air.get().equals(sky), "7 blocks above the floor: stays in the air");
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void safeTeleportBacksOffAlongTheRay(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-tp-backoff", new Vec3(4.5, 1, 1.5));
        ServerLevel level = helper.getLevel();
        for (int z = 6; z <= 7; z++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(4, y, z), Blocks.STONE);
            }
        }
        Vec3 from = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        Optional<Vec3> found = SafeTeleport.findSafe(level, player, from, helper.absoluteVec(new Vec3(4.5, 1, 7.5)),
                3);
        double expectedZ = helper.absoluteVec(new Vec3(0, 0, 5.5)).z;
        check(helper, found.isPresent() && Math.abs(found.get().z - expectedZ) < 1e-6,
                "stops in front of the wall at z 5.5, was " + found);
        // Muro pegado: ningún punto a ≥ 3 bloques.
        Optional<Vec3> none = SafeTeleport.findSafe(level, player, helper.absoluteVec(new Vec3(4.5, 1, 4.5)),
                helper.absoluteVec(new Vec3(4.5, 1, 7.5)), 3);
        check(helper, none.isEmpty(), "no valid point at 3 blocks or more: rejected, was " + none);
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void safeTeleportMovesThePlayerAndGuardsTheFall(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-tp-move", new Vec3(1.5, 1, 1.5));
        player.fallDistance = 5f;
        Vec3 ground = helper.absoluteVec(new Vec3(5.5, 1, 5.5));
        SafeTeleport.teleport(player, ground);
        check(helper, player.position().distanceTo(ground) < 1e-6, "player at the destination, was " + player.position());
        check(helper, player.fallDistance == 0f, "fall distance reset");
        check(helper, !SafeTeleport.isFallGuarded(player), "landing on the ground needs no fall guard");

        Vec3 sky = helper.absoluteVec(new Vec3(4.5, 9, 4.5));
        SafeTeleport.teleport(player, sky);
        check(helper, player.position().distanceTo(sky) < 1e-6, "player in the air");
        check(helper, SafeTeleport.isFallGuarded(player), "arriving in the air sets the fall guard");
        float health = player.getHealth();
        player.causeFallDamage(8f, 1f, player.damageSources().fall());
        check(helper, player.getHealth() == health, "guarded fall must not hurt");
        helper.succeed();
    }
}
