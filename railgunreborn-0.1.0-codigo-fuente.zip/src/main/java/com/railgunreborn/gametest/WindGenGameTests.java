package com.railgunreborn.gametest;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.WindGenBaseBlock;
import com.railgunreborn.block.WindGenBaseBlockEntity;
import com.railgunreborn.block.WindGenMainBlockEntity;
import com.railgunreborn.block.WindGenRules;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModCapabilities;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests del generador eólico (T102). La producción depende de la Y absoluta de la cabeza, así que cada test
 * construye la torre en la columna de su recinto pero a una altura fija (base en Y=100 o Y=150, lejos del suelo de
 * los recintos), llama a los ticks a mano, comprueba y lo desmonta todo en el mismo tick. Van en su propio lote para
 * que ningún otro test ponga bloques en el cuadro de 15x15 del rotor.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class WindGenGameTests {
    private static final String EMPTY = "empty";
    private static final String BATCH = "wind_gen";
    private static final BlockPos COLUMN = new BlockPos(1, 1, 1);

    /** Torre construida por un test: base, pilares y cabeza mirando al sur. */
    private record Rig(ServerLevel level, BlockPos base, BlockPos main, WindGenBaseBlockEntity baseBe,
            WindGenMainBlockEntity mainBe) {
        BlockPos front() {
            return main.relative(Direction.SOUTH);
        }

        void tick(int times) {
            for (int i = 0; i < times; i++) {
                WindGenBaseBlockEntity.serverTick(level, base, baseBe.getBlockState(), baseBe);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static Rig build(GameTestHelper helper, int baseY, int pillars, boolean fan) {
        ServerLevel level = helper.getLevel();
        BlockPos column = helper.absolutePos(COLUMN);
        BlockPos base = new BlockPos(column.getX(), baseY, column.getZ());
        clearArea(level, base, pillars);
        ModBlocks.WINDGEN_BASE.get().place(level, base);
        for (int i = 0; i < pillars; i++) {
            level.setBlock(base.above(2 + i), ModBlocks.WINDGEN_PILLAR.get().defaultBlockState(), Block.UPDATE_ALL);
        }
        BlockPos main = base.above(2 + pillars);
        ModBlocks.WINDGEN_MAIN.get().place(level, main, Direction.SOUTH);
        WindGenBaseBlockEntity baseBe = (WindGenBaseBlockEntity) level.getBlockEntity(base);
        WindGenMainBlockEntity mainBe = (WindGenMainBlockEntity) level.getBlockEntity(main);
        if (fan) {
            mainBe.getItems().setStackInSlot(WindGenMainBlockEntity.SLOT_FAN, new ItemStack(ModItems.WINDGEN_FAN.get()));
        }
        baseBe.getEnergy().setEnergy(0);
        ModCapabilities.TEST_RECEIVER.setEnergy(0);
        return new Rig(level, base, main, baseBe, mainBe);
    }

    /** Deja en aire la caja que ocupa la torre y su rotor (x ±8, z ±2, de la base a 8 por encima de la cabeza). */
    private static void clearArea(ServerLevel level, BlockPos base, int pillars) {
        int top = base.getY() + 2 + pillars + WindGenRules.CLEAR_RADIUS + 1;
        for (BlockPos pos : BlockPos.betweenClosed(base.getX() - 8, base.getY(), base.getZ() - 2, base.getX() + 8, top,
                base.getZ() + 2)) {
            if (!level.getBlockState(pos).isAir()) {
                level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Vacía las ranuras (para que no suelten nada) y quita la torre. */
    private static void dismantle(Rig rig, int pillars) {
        if (rig.level.getBlockEntity(rig.main) instanceof WindGenMainBlockEntity main) {
            main.getItems().setStackInSlot(WindGenMainBlockEntity.SLOT_FAN, ItemStack.EMPTY);
        }
        if (rig.level.getBlockEntity(rig.base) instanceof WindGenBaseBlockEntity base) {
            base.getItems().setStackInSlot(WindGenBaseBlockEntity.SLOT_BATTERY, ItemStack.EMPTY);
        }
        clearArea(rig.level, rig.base, pillars);
        discardItems(rig.level, rig.base, pillars);
    }

    private static void discardItems(ServerLevel level, BlockPos base, int pillars) {
        AABB box = new AABB(base).inflate(9, 0, 3).expandTowards(0, pillars + 12, 0);
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box)) {
            item.discard();
        }
    }

    private static int expectedEnergy(int mainY, int ticks) {
        return (int) Math.floor(ticks * WindGenRules.outputPerTick(mainY, RailgunConfig.generatorMultiplier()) + 1e-6);
    }

    // --- Producción ---

    @GameTest(template = EMPTY, batch = BATCH)
    public static void producesFifteenAtFullHeight(GameTestHelper helper) {
        Rig rig = build(helper, 150, 8, true); // cabeza en Y=160: factor 1
        try {
            rig.tick(20);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.WORKING,
                    "status should be WORKING, was " + rig.baseBe.getStatus());
            check(helper, rig.mainBe.getStatus() == WindGenRules.Status.WORKING,
                    "head status should be WORKING, was " + rig.mainBe.getStatus());
            double rate = rig.baseBe.getOutputPerTick();
            check(helper, Math.abs(rate - 15.0 * RailgunConfig.generatorMultiplier()) < 1e-9,
                    "15 IF/t at Y=160, got " + rate);
            int stored = rig.baseBe.getEnergy().getEnergyStored();
            check(helper, stored == expectedEnergy(160, 20), "20 ticks x 15 IF, got " + stored);
            check(helper, rig.baseBe.getBlockState().getValue(WindGenBaseBlock.COMPLETE), "base shows complete texture");
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void producesByHeightFormula(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, true); // cabeza en Y=110: 15 x (0,5 + 0,5 x 40/90) = 10,83
        try {
            rig.tick(30);
            double rate = rig.baseBe.getOutputPerTick();
            double expected = 15.0 * (0.5 + 0.5 * 40.0 / 90.0) * RailgunConfig.generatorMultiplier();
            check(helper, Math.abs(rate - expected) < 1e-9, "expected " + expected + " IF/t, got " + rate);
            int stored = rig.baseBe.getEnergy().getEnergyStored();
            int wanted = expectedEnergy(110, 30);
            check(helper, Math.abs(stored - wanted) <= 1, "30 ticks should give ~" + wanted + ", got " + stored);
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void higherHeadProducesMore(GameTestHelper helper) {
        Rig low = build(helper, 100, 8, true);
        double lowRate;
        int lowStored;
        try {
            low.tick(20);
            lowRate = low.baseBe.getOutputPerTick();
            lowStored = low.baseBe.getEnergy().getEnergyStored();
        } finally {
            dismantle(low, 8);
        }
        Rig high = build(helper, 100, 40, true); // cabeza en Y=142
        try {
            high.tick(20);
            double highRate = high.baseBe.getOutputPerTick();
            int highStored = high.baseBe.getEnergy().getEnergyStored();
            check(helper, high.baseBe.getStatus() == WindGenRules.Status.WORKING, "40 pillars is still valid");
            check(helper, highRate > lowRate && highStored > lowStored,
                    "higher should produce more: " + lowRate + " vs " + highRate);
            check(helper, Math.abs(highRate - WindGenRules.outputPerTick(142, RailgunConfig.generatorMultiplier())) < 1e-9,
                    "rate at Y=142, got " + highRate);
        } finally {
            dismantle(high, 40);
        }
        helper.succeed();
    }

    // --- Sin producir ---

    @GameTest(template = EMPTY, batch = BATCH)
    public static void noFanProducesNothing(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, false);
        try {
            rig.tick(20);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.NO_FAN,
                    "status should be NO_FAN, was " + rig.baseBe.getStatus());
            check(helper, rig.baseBe.getEnergy().getEnergyStored() == 0, "no fan: 0 IF");
            check(helper, rig.baseBe.getBlockState().getValue(WindGenBaseBlock.COMPLETE), "structure itself is complete");
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void brokenPillarInvalidates(GameTestHelper helper) {
        Rig rig = build(helper, 100, 10, true);
        try {
            rig.tick(1);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.WORKING, "works before breaking a pillar");
            rig.level.setBlock(rig.base.above(5), Blocks.STONE.defaultBlockState(), Block.UPDATE_ALL);
            rig.baseBe.refresh();
            rig.baseBe.getEnergy().setEnergy(0);
            rig.tick(5);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.INCOMPLETE,
                    "status should be INCOMPLETE, was " + rig.baseBe.getStatus());
            check(helper, rig.baseBe.getEnergy().getEnergyStored() == 0, "broken pillar: 0 IF");
            check(helper, !rig.baseBe.getBlockState().getValue(WindGenBaseBlock.COMPLETE), "base texture goes dark");
            rig.mainBe.refresh();
            check(helper, rig.mainBe.getStatus() == WindGenRules.Status.INCOMPLETE,
                    "head also sees the broken column, was " + rig.mainBe.getStatus());
        } finally {
            dismantle(rig, 10);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void pillarLimits(GameTestHelper helper) {
        Rig shortRig = build(helper, 100, 7, true);
        try {
            shortRig.tick(5);
            check(helper, shortRig.baseBe.getStatus() == WindGenRules.Status.TOO_SHORT,
                    "7 pillars: TOO_SHORT, was " + shortRig.baseBe.getStatus());
            check(helper, shortRig.baseBe.getEnergy().getEnergyStored() == 0, "too short: 0 IF");
        } finally {
            dismantle(shortRig, 7);
        }
        Rig tallRig = build(helper, 100, 41, true);
        try {
            tallRig.tick(5);
            check(helper, tallRig.baseBe.getStatus() == WindGenRules.Status.TOO_TALL,
                    "41 pillars: TOO_TALL, was " + tallRig.baseBe.getStatus());
            check(helper, tallRig.baseBe.getEnergy().getEnergyStored() == 0, "too tall: 0 IF");
        } finally {
            dismantle(tallRig, 41);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void blockedRotorStops(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, true);
        try {
            // Fuera del plano del rotor (un bloque más al frente): no molesta.
            rig.level.setBlock(rig.front().south().east(3), Blocks.STONE.defaultBlockState(), Block.UPDATE_ALL);
            rig.tick(1);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.WORKING,
                    "a block outside the rotor plane is fine, was " + rig.baseBe.getStatus());
            // Dentro del cuadro de 15x15 (7 a un lado, 7 abajo: la esquina).
            rig.level.setBlock(rig.front().west(7).below(7), Blocks.STONE.defaultBlockState(), Block.UPDATE_ALL);
            rig.baseBe.refresh();
            rig.baseBe.getEnergy().setEnergy(0);
            rig.tick(5);
            check(helper, rig.baseBe.getStatus() == WindGenRules.Status.BLOCKED,
                    "status should be BLOCKED, was " + rig.baseBe.getStatus());
            check(helper, rig.baseBe.getEnergy().getEnergyStored() == 0, "blocked: 0 IF");
            check(helper, !rig.mainBe.isAreaClear(), "head knows the rotor area is not clear");
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    // --- Energía ---

    @GameTest(template = EMPTY, batch = BATCH)
    public static void pushesToAdjacentReceiver(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, false);
        BlockPos gold = rig.base.east();
        try {
            rig.level.setBlock(gold, Blocks.GOLD_BLOCK.defaultBlockState(), Block.UPDATE_ALL);
            rig.baseBe.getEnergy().setEnergy(1000);
            rig.tick(1);
            int received = ModCapabilities.TEST_RECEIVER.getEnergyStored();
            check(helper, received == WindGenRules.BANDWIDTH, "one tick pushes the 300 bandwidth, got " + received);
            check(helper, rig.baseBe.getEnergy().getEnergyStored() == 700,
                    "buffer drops to 700, got " + rig.baseBe.getEnergy().getEnergyStored());
        } finally {
            rig.level.setBlock(gold, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void bothHalvesExposeExtractOnlyEnergy(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, false);
        try {
            for (BlockPos pos : List.of(rig.base, rig.base.above())) {
                IEnergyStorage cap = rig.level.getCapability(Capabilities.EnergyStorage.BLOCK, pos, Direction.NORTH);
                check(helper, cap == rig.baseBe.getEnergy(), "half at " + pos + " gives the controller's storage");
                check(helper, !cap.canReceive() && cap.canExtract(), "extract only");
                check(helper, cap.getMaxEnergyStored() == WindGenRules.CAPACITY, "capacity 20000");
            }
            rig.baseBe.getEnergy().setEnergy(1000);
            IEnergyStorage cap = rig.level.getCapability(Capabilities.EnergyStorage.BLOCK, rig.base, null);
            check(helper, cap.extractEnergy(1000, false) == WindGenRules.BANDWIDTH, "cable extraction capped at 300");
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void batterySlotChargesEnergyUnit(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, false);
        try {
            ItemStack unit = new ItemStack(ModItems.ENERGY_UNIT.get());
            check(helper, rig.baseBe.getItems().insertItem(WindGenBaseBlockEntity.SLOT_BATTERY, unit, false).isEmpty(),
                    "energy unit accepted in the battery slot");
            check(helper, !rig.baseBe.getItems().isItemValid(WindGenBaseBlockEntity.SLOT_BATTERY,
                    new ItemStack(Blocks.DIRT)), "dirt is not valid in the battery slot");
            rig.baseBe.getEnergy().setEnergy(500);
            rig.tick(1);
            int unitEnergy = EnergyUnitItem.getEnergy(rig.baseBe.getItems().getStackInSlot(WindGenBaseBlockEntity.SLOT_BATTERY));
            check(helper, unitEnergy == 20, "unit charges at its 20/tick bandwidth, got " + unitEnergy);
            check(helper, rig.baseBe.getEnergy().getEnergyStored() == 480,
                    "buffer drops by 20, got " + rig.baseBe.getEnergy().getEnergyStored());
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    // --- Bloques ---

    @GameTest(template = EMPTY, batch = BATCH)
    public static void fanSlotOnlyTakesOneFan(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, false);
        try {
            check(helper, !rig.mainBe.getItems().isItemValid(WindGenMainBlockEntity.SLOT_FAN,
                    new ItemStack(ModItems.ENERGY_UNIT.get())), "only the fan fits");
            ItemStack rest = rig.mainBe.getItems().insertItem(WindGenMainBlockEntity.SLOT_FAN,
                    new ItemStack(ModItems.WINDGEN_FAN.get(), 3), false);
            check(helper, rest.getCount() == 2, "one fan per head, left " + rest.getCount());
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void breakingAPartRemovesTheWholePiece(GameTestHelper helper) {
        Rig rig = build(helper, 100, 8, true);
        try {
            rig.level.destroyBlock(rig.front(), false);
            check(helper, rig.level.getBlockState(rig.main).isAir(), "head center removed with the front part");
            check(helper, rig.level.getBlockState(rig.main.north()).isAir(), "head tail removed too");
            AABB around = new AABB(rig.main).inflate(2);
            boolean fanDropped = rig.level.getEntitiesOfClass(ItemEntity.class, around).stream()
                    .anyMatch(e -> e.getItem().is(ModItems.WINDGEN_FAN.get()));
            check(helper, fanDropped, "the fan drops when the head breaks");
            rig.level.destroyBlock(rig.base.above(), false);
            check(helper, rig.level.getBlockState(rig.base).isAir(), "base lower half removed with the upper half");
            check(helper, rig.level.getBlockState(rig.base.above(2)).is(ModBlocks.WINDGEN_PILLAR.get()),
                    "pillars stay");
        } finally {
            dismantle(rig, 8);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY, batch = BATCH)
    public static void recipesLoad(GameTestHelper helper) {
        for (String name : List.of("windgen_base", "windgen_pillar", "windgen_main", "windgen_fan")) {
            check(helper, helper.getLevel().getRecipeManager()
                    .byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, name)).isPresent(),
                    name + " recipe should load");
        }
        helper.succeed();
    }
}
