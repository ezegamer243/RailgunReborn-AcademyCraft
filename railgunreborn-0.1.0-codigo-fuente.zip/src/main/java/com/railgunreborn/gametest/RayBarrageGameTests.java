package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.RayBarrageRules;
import com.railgunreborn.entity.SilbarnEntity;
import com.railgunreborn.registry.ModEntities;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Ray Barrage (T49). El abanico alcanza 20 bloques: para no tocar las pruebas vecinas se dispara desde
 * un pilar mirando muy hacia abajo (la zona solo llega a ~4.5 bloques en horizontal). Cerdos y gólems: no se queman.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class RayBarrageGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 4 con Ray Barrage aprendida (exp 0), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(4);
        Skill skill = Meltdowner.RAY_BARRAGE.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Barn quieto (flota los primeros 50 ticks) con el centro en {@code center}. */
    private static SilbarnEntity barnAt(ServerPlayer player, Vec3 center) {
        SilbarnEntity barn = new SilbarnEntity(ModEntities.SILBARN.get(), player.level());
        barn.setPos(center.x, center.y - barn.getBbHeight() / 2, center.z);
        barn.setDeltaMovement(Vec3.ZERO);
        player.level().addFreshEntity(barn);
        return barn;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static float exp(ServerPlayer player, Skill skill) {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    @GameTest(template = EMPTY)
    public static void rayBarrageIsRegisteredAtLevel4(GameTestHelper helper) {
        Skill skill = Meltdowner.RAY_BARRAGE.get();
        check(helper, skill.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, skill.getLevel() == 4 && skill.canControl(), "level 4, controllable");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Meltdowner.MELTDOWNER.getId())
                && Math.abs(skill.getParent().get().minExp() - 0.5f) < EPS, "parent: meltdowner (0.5)");
        check(helper, skill.getGuiX() == 140 && skill.getGuiY() == 10, "tree position should be 140, 10");
        int id = AbilityRegistries.SKILL_REGISTRY.getId(skill);
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.MINE_RAY_BASIC.get()) < id
                && id < AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.MINE_RAY_EXPERT.get()),
                "registered between the basic and the expert mining ray");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void barnFanHurtsInsideAndSparesOutside(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(new BlockPos(4, 3, 2), Blocks.STONE);
        // Sobre el pilar, mirando a +Z y 70° hacia abajo.
        ServerPlayer player = player(helper, "test-ray-barrage-fan", new Vec3(4.5, 4, 2.5), 70f);
        Skill skill = setUp(player);
        LivingEntity inside = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(4.5, 1, 5.5));
        LivingEntity outside = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(0.5, 1, 2.5));
        float insideBefore = inside.getHealth();
        float outsideBefore = outside.getHealth();
        SilbarnEntity barn = barnAt(player, player.getEyePosition().add(player.getViewVector(1.0f).scale(2.5)));
        check(helper, SilbarnEntity.findLookedAt(player, RayBarrageRules.RANGE) == barn, "player looks at the barn");
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, SkillContexts.active(player).isEmpty(), "context ends right away");
        check(helper, barn.isHit() && !barn.isUsable(), "the barn is consumed");
        check(helper, inside.getHealth() <= insideBefore - RayBarrageRules.damageFan(0f) + 0.5f,
                "pig inside the fan should take ~10, had " + insideBefore + " now " + inside.getHealth());
        check(helper, outside.getHealth() == outsideBefore, "pig outside the fan must not be hurt");
        check(helper, player.getHealth() == player.getMaxHealth(), "the caster is not hurt");
        check(helper, Math.abs(cpBefore - cp.getCP() - RayBarrageRules.cp(0f)) < 1f,
                "pays 450 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - RayBarrageRules.overload(0f)) < 1f,
                "adds 300 overload, was " + cp.getOverload());
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == RayBarrageRules.cooldown(0f),
                "cooldown of 100 ticks");
        check(helper, Math.abs(exp(player, skill) - RayBarrageRules.EXP_GAIN) < 1e-6f,
                "hurting someone gives 0.005 exp, was " + exp(player, skill));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutBarnDirectRayHurtsTheTarget(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-ray-barrage-direct", new Vec3(4.5, 1, 1.5), 10f);
        Skill skill = setUp(player);
        LivingEntity golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        LivingEntity aside = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(1.5, 1, 4.5));
        float before = golem.getHealth();
        float asideBefore = aside.getHealth();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        float lost = before - golem.getHealth();
        check(helper, Math.abs(lost - RayBarrageRules.damageDirect(0f)) < 0.5f,
                "golem should lose 25 health, lost " + lost);
        check(helper, aside.getHealth() == asideBefore, "no area damage without a barn");
        check(helper, Math.abs(exp(player, skill) - RayBarrageRules.EXP_GAIN) < 1e-6f, "hit gives exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void shootingTheAirPaysButGivesNoExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-ray-barrage-air", new Vec3(4.5, 1, 1.5), -90f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, cp.getCP() < cpBefore - 400f, "the shot is paid");
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "cooldown set");
        check(helper, exp(player, skill) == 0f, "no exp when nothing is hurt, was " + exp(player, skill));
        helper.succeed();
    }
}
