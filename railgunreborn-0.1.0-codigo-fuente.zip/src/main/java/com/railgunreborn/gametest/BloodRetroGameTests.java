package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.BloodRetroRules;
import com.railgunreborn.ability.vecmanip.BloodRetroSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.PlayerTeam;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Blood Retrograde (T75). Jugador falso en (4.5, 1, 1.5) mirando a +z; golem (100 de vida, no se quema)
 * pegado delante.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class BloodRetroGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    private static final Vec3 NEAR = new Vec3(4.5, 1, 2.5);

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-br-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Vector Manipulation nivel 4 con Blood Retrograde aprendida, CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(4);
        Skill skill = VecManip.BLOOD_RETRO.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void press(GameTestHelper helper, ServerPlayer player, Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
    }

    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Pulsa, mantiene {@code ticks} ticks y suelta. */
    private static void shoot(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        press(helper, player, skill);
        hold(player, ticks);
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
    }

    private static boolean slowed(ServerPlayer player) {
        return player.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(BloodRetroSkill.SLOW_MODIFIER_ID) != null;
    }

    private static void assertNothingHappened(GameTestHelper helper, ServerPlayer player, Skill skill,
            float cpBefore) {
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel4(GameTestHelper helper) {
        Skill skill = VecManip.BLOOD_RETRO.get();
        check(helper, skill.getLevel() == 4 && skill.canControl(), "level 4, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(VecManip.skillId("dir_blast"))
                && p.minExp() == 0.0f).orElse(false), "parent dir_blast at 0.0");
        check(helper, skill.getGuiX() == 204 && skill.getGuiY() == 83, "gui position 204, 83");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/blood_retro.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hitsTheMobAndCharges(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, NEAR);
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        shoot(helper, player, skill, 3);

        check(helper, Math.abs(before - golem.getHealth() - 30f) < EPS,
                "30 damage, lost " + (before - golem.getHealth()));
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 280f) < 0.5f, "CP charged (280 at exp 0)");
        check(helper, Math.abs(CPData.get(player).getOverload() - 55f) < 0.5f, "overload 55");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 90, "cooldown 90");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - BloodRetroRules.EXP) < 1e-6f,
                "exp +0.002");
        check(helper, !slowed(player), "slowdown removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noTargetCostsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        float cpBefore = CPData.get(player).getCP();
        shoot(helper, player, skill, 3);
        assertNothingHappened(helper, player, skill, cpBefore);
        check(helper, !slowed(player), "slowdown removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void aTargetOutOfReachCostsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();
        shoot(helper, player, skill, 3);
        check(helper, golem.getHealth() == before, "no damage out of reach");
        assertNothingHappened(helper, player, skill, cpBefore);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void aWallBlocksTheBurst(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        // El muro (z = 2) queda entre los ojos y el golem pegado detrás.
        for (int y = 1; y <= 4; y++) {
            for (int x = 2; x <= 7; x++) {
                helper.setBlock(new BlockPos(x, y, 2), Blocks.STONE);
            }
        }
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 3.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();
        shoot(helper, player, skill, 3);
        check(helper, golem.getHealth() == before, "no damage through the wall");
        assertNothingHappened(helper, player, skill, cpBefore);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void aNonLivingEntityIsIgnoredWithoutError(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        Entity cart = helper.spawn(EntityType.MINECART, new Vec3(4.5, 1, 2.5));
        float cpBefore = CPData.get(player).getCP();
        shoot(helper, player, skill, 3);
        check(helper, cart.isAlive(), "the minecart is untouched");
        assertNothingHappened(helper, player, skill, cpBefore);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpTheKeyIsRejected(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData.get(player).consumeWithForce(player, 0f, 1.0e9f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, NEAR);
        float before = golem.getHealth();
        shoot(helper, player, skill, 3);
        check(helper, golem.getHealth() == before, "no damage without CP");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, !slowed(player), "no slowdown left");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void protectedPlayerCostsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        ServerPlayer victim = player(helper);
        Vec3 at = helper.absoluteVec(NEAR);
        victim.moveTo(at.x, at.y, at.z, 0f, 0f);
        var scoreboard = helper.getLevel().getScoreboard();
        PlayerTeam team = scoreboard.addPlayerTeam("br_pvp_" + UUID.randomUUID().toString().substring(0, 8));
        team.setAllowFriendlyFire(false);
        scoreboard.addPlayerToTeam(player.getScoreboardName(), team);
        scoreboard.addPlayerToTeam(victim.getScoreboardName(), team);
        float cpBefore = CPData.get(player).getCP();
        try {
            float before = victim.getHealth();
            shoot(helper, player, skill, 3);
            check(helper, victim.getHealth() == before, "a protected player must not be hurt");
            assertNothingHappened(helper, player, skill, cpBefore);
        } finally {
            scoreboard.removePlayerTeam(team);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void slowdownGrowsWhileHeldAndAlwaysEnds(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        double base = player.getAttributeValue(Attributes.MOVEMENT_SPEED);
        press(helper, player, skill);
        check(helper, slowed(player), "slowed on press");
        hold(player, 20);
        AttributeModifier modifier = player.getAttribute(Attributes.MOVEMENT_SPEED)
                .getModifier(BloodRetroSkill.SLOW_MODIFIER_ID);
        check(helper, modifier != null && Math.abs(modifier.amount() + 0.93) < 1e-9,
                "-0.93 after 20 ticks, was " + (modifier == null ? "none" : modifier.amount()));
        check(helper, Math.abs(player.getAttributeValue(Attributes.MOVEMENT_SPEED) - base * 0.07) < 1e-9,
                "7 % of the base speed");
        // Abortar (sin soltar) también la quita.
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_ABORT);
        check(helper, !slowed(player), "slowdown removed on abort");
        check(helper, Math.abs(player.getAttributeValue(Attributes.MOVEMENT_SPEED) - base) < 1e-9,
                "base speed back");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasesByItselfAtThirtyTicks(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, NEAR);
        float before = golem.getHealth();
        press(helper, player, skill);
        hold(player, BloodRetroRules.AUTO_RELEASE_TICKS - 1);
        check(helper, SkillContexts.find(player, skill).isPresent() && golem.getHealth() == before,
                "still charging at 29 ticks");
        hold(player, 1);
        check(helper, SkillContexts.find(player, skill).isEmpty(), "the context ended by itself at 30 ticks");
        check(helper, Math.abs(before - golem.getHealth() - 30f) < EPS, "the burst fired");
        check(helper, !slowed(player), "slowdown removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void damageGrowsWithExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 1f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, NEAR);
        float before = golem.getHealth();
        shoot(helper, player, skill, 3);
        check(helper, Math.abs(before - golem.getHealth() - 60f) < EPS,
                "60 damage at exp 1, lost " + (before - golem.getHealth()));
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 40, "cooldown 40");
        helper.succeed();
    }
}
