package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerMode;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorBlockEntity.Status;
import com.railgunreborn.reactor.CategoryReactorMenu;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.WirelessRegistry;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.items.IItemHandler;

/**
 * Integración de la fase de supervivencia (T93): cadenas completas con los sistemas reales (recetas del
 * RecipeManager, máquinas, Developer, reactor), cada prueba independiente.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class SurvivalIntegrationGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos MACHINE = new BlockPos(1, 2, 1);
    private static final BlockPos CLICKED = new BlockPos(4, 0, 4);
    private static final BlockPos CONTROLLER = CLICKED.above(2);

    /** Mena -> horno -> lingote -> mesa (2 placas); mena de cristal -> crystal_low en el alto horno. */
    @GameTest(template = EMPTY)
    public static void oreToIngotToPlateByRecipes(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        check(helper, cooks(helper, manager, RecipeType.SMELTING, ModItems.CONSTRAINT_METAL.get(),
                ModItems.CONSTRAINT_INGOT.get()), "constraint_metal should smelt into an ingot");
        check(helper, cooks(helper, manager, RecipeType.BLASTING, ModItems.CRYSTAL_ORE.get(),
                ModItems.CRYSTAL_LOW.get()), "crystal_ore should blast into crystal_low");
        ItemStack ingot = new ItemStack(ModItems.CONSTRAINT_INGOT.get());
        ItemStack plates = craft(helper, 3, 1, List.of(ingot, ingot.copy(), ingot.copy()));
        check(helper, plates.is(ModItems.CONSTRAINT_PLATE.get()) && plates.getCount() == 2,
                "3 ingots should craft 2 constraint plates, got " + plates);
        helper.succeed();
    }

    /** Metal Former en modo PLATE: un lingote de constraint sale como una placa tras la receta (60 t). */
    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void metalFormerPlateProducesPlate(GameTestHelper helper) {
        helper.setBlock(MACHINE, MetalFormerRegistry.METAL_FORMER.get().defaultBlockState());
        if (!(helper.getBlockEntity(MACHINE) instanceof MetalFormerBlockEntity be)) {
            helper.fail("metal former block entity missing");
            return;
        }
        be.getEnergy().setEnergy(MetalFormerBlockEntity.ENERGY_CAPACITY);
        be.setMode(MetalFormerMode.PLATE);
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CONSTRAINT_INGOT.get()));
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(ModItems.CONSTRAINT_PLATE.get()) && out.getCount() == 1,
                    "expected a constraint plate, got " + out);
            helper.assertTrue(helper.getTick() >= 60, "finished before the 60 ticks of the recipe");
        });
    }

    /** Imag Fusor: crystal_low + 3 unidades llenas -> crystal_normal. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void imagFusorMakesCrystalNormal(GameTestHelper helper) {
        helper.setBlock(MACHINE, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(MACHINE) instanceof ImagFusorBlockEntity be)) {
            helper.fail("imag fusor block entity missing");
            return;
        }
        be.getEnergy().setEnergy(ImagFusorBlockEntity.ENERGY_CAPACITY);
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CRYSTAL_LOW.get()));
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN,
                new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get(), 3));
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(ModItems.CRYSTAL_NORMAL.get()) && out.getCount() == 1,
                    "expected crystal_normal, got " + out);
            helper.assertTrue(be.getTank().getFluidAmount() == 0, "the 3000 mB should be spent");
        });
    }

    /** developer_normal con los ítems reales de la cadena (portátil, núcleo de matriz 0, cama, pistón, cristal, armazón). */
    @GameTest(template = EMPTY)
    public static void developerNormalCraftsViaRecipeManager(GameTestHelper helper) {
        ItemStack out = craft(helper, 3, 3, List.of(
                ItemStack.EMPTY, new ItemStack(ModItems.DEVELOPER_PORTABLE.get()), ItemStack.EMPTY,
                new ItemStack(WirelessRegistry.MAT_CORE_0.get()), new ItemStack(Items.RED_BED),
                new ItemStack(Items.PISTON),
                new ItemStack(ModItems.CRYSTAL_NORMAL.get()), new ItemStack(ModItems.MACHINE_FRAME.get()),
                new ItemStack(Items.REDSTONE)));
        check(helper, out.is(ModItems.DEVELOPER_NORMAL.get()), "expected developer_normal, got " + out);
        helper.succeed();
    }

    /** El reactor se fabrica con una estrella del Nether y las piezas de la cadena. */
    @GameTest(template = EMPTY)
    public static void reactorCraftsWithNetherStar(GameTestHelper helper) {
        ItemStack plate = new ItemStack(ModItems.CONSTRAINT_PLATE.get());
        ItemStack pure = new ItemStack(ModItems.CRYSTAL_PURE.get());
        ItemStack frame = new ItemStack(ModItems.MACHINE_FRAME.get());
        ItemStack out = craft(helper, 3, 3, List.of(
                plate, new ItemStack(Items.NETHER_STAR), plate.copy(),
                pure, new ItemStack(ModItems.IMAG_FUSOR.get()), pure.copy(),
                frame, new ItemStack(ModItems.BRAIN_COMPONENT.get()), frame.copy()));
        check(helper, out.is(CategoryReactorRegistry.ITEM.get()), "expected the category reactor, got " + out);
        helper.succeed();
    }

    /**
     * Jugador sin categoría: consola del Developer con el nombre de la categoría y un factor -> categoría nueva,
     * nivel 1. Luego un reactor (colocado con su ítem, lleno por capacidad) con otro factor cambia la categoría.
     */
    @GameTest(template = EMPTY)
    public static void factorGivesCategoryThenReactorSwitchesIt(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);

        // 1) Primera categoría por la consola (camino del nombre).
        player.setItemInHand(InteractionHand.MAIN_HAND, DeveloperEnergyTesting.chargedPortable());
        DeveloperMenu menu = DeveloperMenu.open(player, DeveloperType.PORTABLE, null);
        check(helper, menu != null && player.containerMenu == menu, "portable developer should open");
        check(helper, menu.start(player, DevelopAction.levelWithFactor(Teleporter.ID)) == DevelopResult.NO_FACTOR,
                "without a factor the console must refuse");
        check(helper, !data.hasCategory(), "no category without a factor");
        player.getInventory().add(InductionFactorItem.of(Teleporter.ID));
        check(helper, menu.start(player, DevelopAction.levelWithFactor(Teleporter.ID)) == DevelopResult.OK,
                "the console should start with the factor");
        for (int i = 0; i < DevelopRules.totalTicks(5, DeveloperType.PORTABLE); i++) {
            menu.serverTick(player);
        }
        check(helper, Teleporter.ID.equals(data.getCategory().orElse(null)), "category should be teleporter");
        check(helper, data.getLevel() == 1, "level should be 1");
        check(helper, !InductionFactorItem.has(player, Teleporter.ID), "the factor must be consumed");
        player.closeContainer();

        // 2) Reactor: ítem sobre un bloque, volumen libre.
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(CategoryReactorRegistry.ITEM.get()));
        helper.setBlock(CLICKED, Blocks.STONE);
        BlockPos clicked = helper.absolutePos(CLICKED);
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(clicked).add(0, 0.5, 0), Direction.UP, clicked, false);
        InteractionResult placed = player.getMainHandItem().useOn(new UseOnContext(player, InteractionHand.MAIN_HAND, hit));
        check(helper, placed.consumesAction(), "the reactor should be placed, got " + placed);
        if (!(helper.getBlockEntity(CONTROLLER) instanceof CategoryReactorBlockEntity be)) {
            helper.fail("reactor controller missing");
            return;
        }
        IFluidHandler fluid = helper.getLevel().getCapability(Capabilities.FluidHandler.BLOCK,
                helper.absolutePos(CONTROLLER.offset(1, 1, -1)), Direction.UP);
        check(helper, fluid != null, "reactor parts must expose the fluid capability");
        int filled = fluid.fill(new FluidStack(ModFluids.PHASE_LIQUID.get(), 30_000), IFluidHandler.FluidAction.EXECUTE);
        check(helper, filled == 30_000 && be.getTank().getFluidAmount() == 30_000, "tank should hold 30000 mB");
        IItemHandler items = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK,
                helper.absolutePos(CONTROLLER.below()), Direction.DOWN);
        check(helper, items != null && items.insertItem(0, InductionFactorItem.of(Electromaster.ID), false).isEmpty(),
                "the factor should go into the reactor");

        be.getEnergy().setEnergy(CategoryReactorBlockEntity.ENERGY_CAPACITY);
        // 3) Activar: categoría del factor, nivel 1, líquido y factor gastados.
        CategoryReactorMenu reactorMenu = new CategoryReactorMenu(1, player.getInventory(), be, player);
        check(helper, reactorMenu.getStatus() == Status.READY, "reactor should be ready, got " + reactorMenu.getStatus());
        reactorMenu.clickMenuButton(player, CategoryReactorMenu.BUTTON_ACTIVATE);
        check(helper, Electromaster.ID.equals(data.getCategory().orElse(null)),
                "category should now be electromaster, got " + data.getCategory());
        check(helper, data.getLevel() == 1, "level should be 1");
        check(helper, be.getTank().getFluidAmount() == 0 && be.getFactor().isEmpty(), "liquid and factor are spent");
        check(helper, be.isFiring(), "the reactor should be firing");
        helper.succeed();
    }

    // --- Utilidades ---

    private static ItemStack craft(GameTestHelper helper, int width, int height, List<ItemStack> grid) {
        CraftingInput input = CraftingInput.of(width, height, grid);
        return helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
    }

    private static <T extends AbstractCookingRecipe> boolean cooks(GameTestHelper helper, RecipeManager manager,
            RecipeType<T> type, Item in, Item out) {
        return manager.getRecipeFor(type, new SingleRecipeInput(new ItemStack(in)), helper.getLevel())
                .map(h -> h.value().getResultItem(helper.getLevel().registryAccess()).is(out)).orElse(false);
    }

    /** Jugador falso (como en CategoryReactorGameTests): el listener descarta los paquetes. */
    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-survival-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setGameMode(GameType.SURVIVAL);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }
}
