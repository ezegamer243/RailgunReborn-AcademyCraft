package com.railgunreborn.gametest;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.ImagFusorBlock;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.crafting.ImagFusorRecipe;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModRecipes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

/** GameTests del Imag Fusor (T86): recetas, proceso, recipientes y capacidades. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ImagFusorGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos POS = new BlockPos(1, 1, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static ImagFusorBlockEntity place(GameTestHelper helper) {
        helper.setBlock(POS, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof ImagFusorBlockEntity be)) {
            helper.fail("imag fusor block entity missing");
            throw new IllegalStateException();
        }
        be.getEnergy().setEnergy(ImagFusorBlockEntity.ENERGY_CAPACITY);
        return be;
    }

    @GameTest(template = EMPTY)
    public static void recipesLoad(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        List<RecipeHolder<ImagFusorRecipe>> fusor = manager.getAllRecipesFor(ModRecipes.IMAG_FUSOR.get());
        check(helper, fusor.size() == 2, "expected 2 imag fusor recipes, got " + fusor.size());
        ImagFusorRecipe normal = ImagFusorBlockEntity.findRecipe(helper.getLevel(), new ItemStack(ModItems.CRYSTAL_LOW.get()))
                .map(RecipeHolder::value).orElse(null);
        check(helper, normal != null && normal.liquid() == 3000 && normal.time() == 120
                && normal.energyPerTick() == 12 && normal.result().is(ModItems.CRYSTAL_NORMAL.get()),
                "crystal_low recipe wrong: " + normal);
        ImagFusorRecipe pure = ImagFusorBlockEntity.findRecipe(helper.getLevel(), new ItemStack(ModItems.CRYSTAL_NORMAL.get()))
                .map(RecipeHolder::value).orElse(null);
        check(helper, pure != null && pure.liquid() == 8000 && pure.result().is(ModItems.CRYSTAL_PURE.get()),
                "crystal_normal recipe wrong: " + pure);
        for (String id : List.of("imag_fusor", "imag_fusor_converter", "imag_fusor_converter_mirrored")) {
            check(helper, manager.byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, id)).isPresent(),
                    "missing crafting recipe " + id);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void blockCraftsFromFirstVariant(GameTestHelper helper) {
        ItemStack p = new ItemStack(ModItems.CONSTRAINT_PLATE.get());
        ItemStack c = new ItemStack(ModItems.CRYSTAL_LOW.get());
        ItemStack k = new ItemStack(ModItems.CALC_CHIP.get());
        ItemStack f = new ItemStack(ModItems.MACHINE_FRAME.get());
        ItemStack u = new ItemStack(ModItems.MATTER_UNIT.get());
        CraftingInput input = CraftingInput.of(3, 3, List.of(p, c, p.copy(), k, f, k.copy(), p.copy(), u, p.copy()));
        ItemStack out = helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        check(helper, out.is(ModItems.IMAG_FUSOR.get()), "first recipe should craft the imag fusor, got " + out);
        helper.succeed();
    }

    /** crystal_low + 3 unidades llenas -> crystal_normal, depósito vacío y 3 unidades vacías. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void fusesCrystalWithThreeUnits(GameTestHelper helper) {
        ImagFusorBlockEntity be = place(helper);
        ItemStackHandler items = be.getItems();
        items.setStackInSlot(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CRYSTAL_LOW.get()));
        items.setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get(), 3));
        helper.runAtTickTime(60, () -> {
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT).isEmpty(), "finished too early");
            check(helper, be.getTank().getFluidAmount() == 3000, "tank should hold 3000 mB, has " + be.getTank().getFluidAmount());
            check(helper, helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "fusor should be working");
        });
        helper.succeedWhen(() -> {
            helper.assertTrue(items.getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT).is(ModItems.CRYSTAL_NORMAL.get()),
                    "no crystal_normal yet");
            helper.assertTrue(be.getTank().getFluidAmount() == 0, "tank should be empty");
            helper.assertTrue(items.getStackInSlot(ImagFusorBlockEntity.SLOT_INPUT).isEmpty(), "input not consumed");
            ItemStack empties = items.getStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_OUT);
            helper.assertTrue(empties.is(ModItems.MATTER_UNIT.get()) && empties.getCount() == 3, "expected 3 empty units");
            helper.assertTrue(helper.getTick() >= 120, "finished before 120 ticks");
            helper.assertFalse(helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "fusor should be idle again");
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void notEnoughLiquidDoesNothing(GameTestHelper helper) {
        ImagFusorBlockEntity be = place(helper);
        ItemStackHandler items = be.getItems();
        items.setStackInSlot(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CRYSTAL_LOW.get()));
        items.setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get(), 2));
        helper.runAtTickTime(160, () -> {
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT).isEmpty(), "should not craft with 2000 mB");
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_INPUT).getCount() == 1, "input must stay");
            check(helper, be.getTank().getFluidAmount() == 2000, "tank should keep 2000 mB");
            check(helper, !helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "should not be working");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void bucketAndUnitReturnEmptyContainers(GameTestHelper helper) {
        ImagFusorBlockEntity be = place(helper);
        ItemStackHandler items = be.getItems();
        items.setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.PHASE_LIQUID_BUCKET.get()));
        helper.runAtTickTime(3, () -> {
            check(helper, be.getTank().getFluidAmount() == 1000, "bucket should add 1000 mB");
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_OUT).is(Items.BUCKET), "should return a bucket");
            // El cubo vacío ocupa la salida: una unidad llena no puede devolver su unidad vacía, así que espera.
            items.setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get()));
        });
        helper.runAtTickTime(6, () -> {
            check(helper, be.getTank().getFluidAmount() == 1000, "unit must wait while the output holds a bucket");
            items.setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_OUT, ItemStack.EMPTY);
        });
        helper.runAtTickTime(9, () -> {
            check(helper, be.getTank().getFluidAmount() == 2000, "unit should add 1000 mB");
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_OUT).is(ModItems.MATTER_UNIT.get()),
                    "should return an empty matter unit");
            check(helper, items.getStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN).isEmpty(), "unit slot should be empty");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void fluidCapabilityFillsOnlyPhaseLiquid(GameTestHelper helper) {
        ImagFusorBlockEntity be = place(helper);
        IFluidHandler handler = helper.getLevel().getCapability(Capabilities.FluidHandler.BLOCK, helper.absolutePos(POS), Direction.NORTH);
        check(helper, handler != null, "fluid capability missing");
        check(helper, handler.fill(new FluidStack(Fluids.WATER, 1000), IFluidHandler.FluidAction.EXECUTE) == 0, "water accepted");
        int filled = handler.fill(new FluidStack(ModFluids.PHASE_LIQUID.get(), 10000), IFluidHandler.FluidAction.EXECUTE);
        check(helper, filled == ImagFusorBlockEntity.TANK_CAPACITY, "should fill up to 8000 mB, filled " + filled);
        check(helper, handler.drain(1000, IFluidHandler.FluidAction.EXECUTE).isEmpty(), "pipes must not drain the tank");
        check(helper, be.getTank().getFluidAmount() == ImagFusorBlockEntity.TANK_CAPACITY, "tank should be full");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void itemCapabilityIsSided(GameTestHelper helper) {
        ImagFusorBlockEntity be = place(helper);
        BlockPos abs = helper.absolutePos(POS);
        IItemHandler top = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.UP);
        IItemHandler side = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.EAST);
        IItemHandler bottom = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.DOWN);
        check(helper, top != null && side != null && bottom != null, "item capability missing");
        ItemStack crystal = new ItemStack(ModItems.CRYSTAL_LOW.get());
        check(helper, top.insertItem(ImagFusorBlockEntity.SLOT_INPUT, crystal, false).isEmpty(), "top should accept crystals");
        check(helper, !top.insertItem(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(Items.DIRT), true).isEmpty(),
                "input must reject non-recipe items");
        ItemStack unit = new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get());
        check(helper, !top.insertItem(ImagFusorBlockEntity.SLOT_UNIT_IN, unit, true).isEmpty(), "top must not take units");
        check(helper, side.insertItem(ImagFusorBlockEntity.SLOT_UNIT_IN, unit, false).isEmpty(), "side should take units");
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT, new ItemStack(ModItems.CRYSTAL_NORMAL.get()));
        check(helper, side.extractItem(ImagFusorBlockEntity.SLOT_OUTPUT, 1, true).isEmpty(), "side must not extract output");
        check(helper, bottom.extractItem(ImagFusorBlockEntity.SLOT_OUTPUT, 1, false).is(ModItems.CRYSTAL_NORMAL.get()),
                "bottom should extract the output");
        helper.succeed();
    }
}
