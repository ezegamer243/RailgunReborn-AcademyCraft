package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.RailgunRules;
import com.railgunreborn.ability.electromaster.RailgunSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.ability.vecmanip.VecReflectionRules;
import com.railgunreborn.ability.vecmanip.VecReflectionSkill;
import com.railgunreborn.ability.vecmanip.VecTargets;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Vector Reflection (T76). Jugador falso en (4.5, 1, 1.5) mirando a +Z (salvo en la escena del rayo).
 * Se usa exp 0.5 (overload fijo 300, cabe en el máximo 350 del nivel 4): a exp 0 el overload fijo no cabe.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class VecReflectionGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    private static final float EXP = 0.5f;
    private static final float UP = -90f;
    private static final Vec3 TOWARDS_PLAYER = new Vec3(0, 0, -0.5);

    private static ServerPlayer player(GameTestHelper helper, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-vr-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static ServerPlayer player(GameTestHelper helper) {
        return player(helper, new Vec3(4.5, 1, 1.5), 0f, 0f);
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Vector Manipulation nivel 4 con Vector Reflection (exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(4);
        Skill skill = VecManip.VEC_REFLECTION.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Pulsa y suelta la tecla: el campo queda activo (sin ningún tick todavía). */
    private static VecReflectionSkill.VecReflectionContext turnOn(GameTestHelper helper, ServerPlayer player,
            Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        VecReflectionSkill.VecReflectionContext field = VecReflectionSkill.activeField(player);
        check(helper, field != null, "the field should be active after releasing the key");
        return field;
    }

    /** Gasta la protección de aparición (60 ticks) del jugador falso. */
    private static void burnSpawnProtection(ServerPlayer player) {
        for (int i = 0; i < 61; i++) {
            player.tick();
        }
        player.invulnerableTime = 0;
        player.setHealth(20f);
    }

    /** Golpe con {@code attacker} como entidad directa y sin causante: así no escala con la dificultad. */
    private static void hit(ServerPlayer player, Entity attacker, float amount) {
        player.invulnerableTime = 0;
        player.setHealth(20f);
        DamageSource source = new DamageSource(player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(DamageTypes.MOB_ATTACK), attacker, null);
        player.hurt(source, amount);
    }

    // --- Registro ---

    @GameTest(template = EMPTY)
    public static void vecReflectionIsRegisteredAtLevel4UnderVecDeviation(GameTestHelper helper) {
        Skill skill = VecManip.VEC_REFLECTION.get();
        check(helper, skill.getCategoryId().equals(VecManip.ID), "belongs to vecmanip");
        check(helper, skill.getLevel() == 4 && skill.canControl(), "level 4, controllable");
        check(helper, skill.isToggle(), "it is a toggle");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(VecManip.VEC_DEVIATION.getId())
                && Math.abs(skill.getParent().get().minExp()) < EPS, "parent: vec_deviation (0.0)");
        check(helper, skill.getGuiX() == 210 && skill.getGuiY() == 50, "tree position should be 210, 50");
        check(helper, VecManip.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/vec_reflection.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    // --- Interruptor y coste ---

    @GameTest(template = EMPTY)
    public static void keyTurnsTheFieldOnAndKeepsTheOverload(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        CPData cp = CPData.get(player);
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, player, skill);
        float keep = VecReflectionRules.overloadKeep(EXP);
        check(helper, Math.abs(cp.getOverload() - keep) < EPS, "activating adds the fixed overload: " + cp.getOverload());
        float cpBefore = cp.getCP();
        ping(player, 5);
        check(helper, !field.isTerminated(), "still active without holding the key");
        check(helper, Math.abs(cpBefore - cp.getCP() - 5 * VecReflectionRules.cpPerTick(EXP)) < 0.01f,
                "13 CP per tick, spent " + (cpBefore - cp.getCP()));
        check(helper, cp.getOverload() >= keep - EPS, "the overload does not go down: " + cp.getOverload());
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, field.isTerminated() && VecReflectionSkill.activeField(player) == null,
                "pressing the key again turns it off");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void rejectedWhenTheFixedOverloadDoesNotFit(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        // exp 0: 350 de overload fijo contra un máximo de 350 sin bonus.
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start is accepted by the engine");
        check(helper, VecReflectionSkill.activeField(player) == null, "but the field does not turn on");
        check(helper, cp.getOverload() < EPS && !cp.isOverloaded(), "and no overload is added: " + cp.getOverload());
        helper.succeed();
    }

    // --- Golpes ---

    @GameTest(template = EMPTY)
    public static void meleeHitIsReflectedChargingCp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        burnSpawnProtection(player);
        Skill skill = setUp(player, EXP);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 3.5));
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, player, skill);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        float zombieBefore = zombie.getHealth();
        hit(player, zombie, 10f);
        check(helper, player.getHealth() == 20f, "the hit is cancelled entirely: health " + player.getHealth());
        float spent = cpBefore - cp.getCP();
        check(helper, Math.abs(spent - VecReflectionRules.cpPerDamage(EXP, 10f)) < 0.01f,
                "175 CP for a 10 damage hit, spent " + spent);
        check(helper, zombie.getHealth() < zombieBefore, "the zombie takes the reflected damage");
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, exp > EXP, "reflecting gives exp: " + exp);
        check(helper, field.reflectedCount() == 1 && !field.isTerminated(), "one reflection, still on");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fallAndFireAreNotReflected(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        burnSpawnProtection(player);
        Skill skill = setUp(player, EXP);
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, player, skill);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        player.hurt(player.damageSources().fall(), 4f);
        check(helper, Math.abs(player.getHealth() - 16f) < EPS, "fall damage lands: " + player.getHealth());
        player.invulnerableTime = 0;
        player.setHealth(20f);
        player.hurt(player.damageSources().inFire(), 3f);
        check(helper, player.getHealth() < 20f, "fire damage lands: " + player.getHealth());
        player.invulnerableTime = 0;
        player.setHealth(20f);
        player.hurt(player.damageSources().lava(), 3f);
        check(helper, player.getHealth() < 20f, "lava damage lands: " + player.getHealth());
        check(helper, cp.getCP() == cpBefore, "nothing charged");
        check(helper, field.reflectedCount() == 0 && !field.isTerminated(), "nothing reflected, still on");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutEnoughCpTheHitLandsAndTheFieldTurnsOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        burnSpawnProtection(player);
        Skill skill = setUp(player, EXP);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 3.5));
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, player, skill);
        CPData cp = CPData.get(player);
        // Deja 50 de CP: el golpe de 10 cuesta 175.
        cp.consumeWithForce(player, 0f, cp.getCP() - 50f);
        float zombieBefore = zombie.getHealth();
        hit(player, zombie, 10f);
        check(helper, Math.abs(player.getHealth() - 10f) < EPS, "the hit lands normally: " + player.getHealth());
        check(helper, field.isTerminated() && VecReflectionSkill.activeField(player) == null,
                "the field turns off");
        check(helper, Math.abs(cp.getCP() - 50f) < 0.01f, "nothing charged: " + cp.getCP());
        check(helper, zombie.getHealth() == zombieBefore, "no damage returned");
        helper.succeed();
    }

    // --- Proyectiles ---

    @GameTest(template = EMPTY)
    public static void arrowIsSentWhereThePlayerLooks(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        Arrow arrow = helper.spawn(EntityType.ARROW, new Vec3(4.5, 1.5, 4.5));
        arrow.setNoGravity(true);
        arrow.setDeltaMovement(TOWARDS_PLAYER);
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, player, skill);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        ping(player, 1);
        Vec3 motion = arrow.getDeltaMovement();
        check(helper, motion.z > 0.4, "the arrow now flies away along +Z: " + motion);
        check(helper, Math.abs(motion.length() - TOWARDS_PLAYER.length()) < 0.01, "speed kept: " + motion.length());
        check(helper, arrow.getOwner() == player, "the reflector owns the arrow now");
        check(helper, VecTargets.isMarked(arrow), "and it is marked");
        float spent = cpBefore - cp.getCP();
        float expected = VecReflectionRules.cpPerTick(EXP) + VecReflectionRules.cpPerEntity(EXP, 1f);
        check(helper, Math.abs(spent - expected) < 0.01f, "tick + arrow cost " + expected + ", spent " + spent);
        check(helper, field.reflectedCount() == 1, "one reflected, was " + field.reflectedCount());
        ping(player, 1);
        check(helper, field.reflectedCount() == 1, "a reflected arrow is processed once");
        arrow.discard();
        helper.succeed();
    }

    // --- Rayos ---

    /** Ejecuta con mobGriefing apagado y PvP encendido y los restaura (el servidor de pruebas arranca sin PvP). */
    private static void withPvp(GameTestHelper helper, Runnable action) {
        MinecraftServer server = helper.getLevel().getServer();
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean originalGriefing = rule.get();
        boolean originalPvp = server.isPvpAllowed();
        try {
            rule.set(false, server);
            server.setPvpAllowed(true);
            action.run();
        } finally {
            rule.set(originalGriefing, server);
            server.setPvpAllowed(originalPvp);
        }
    }

    @GameTest(template = EMPTY)
    public static void railgunBeamIsReflectedChargingCp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer shooter = player(helper, new Vec3(4.5, 1, 4.5), 0f, UP);
        ServerPlayer reflector = player(helper, new Vec3(4.5, 2.65, 4.5), 0f, 0f);
        Zombie behind = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 5, 4.5));
        Pig pig = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(4.5, 3.5, 8.5));

        AbilityData ability = AbilityData.get(shooter);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(4);
        RailgunSkill railgun = Electromaster.RAILGUN.get();
        ability.learnSkill(railgun.getId());
        CPData.get(shooter).setActivated(shooter, true);
        CPData.get(shooter).recoverAll();
        shooter.addTag(RailgunSkill.IRON_MODE_TAG);
        shooter.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_INGOT, 1));

        Skill skill = setUp(reflector, EXP);
        VecReflectionSkill.VecReflectionContext field = turnOn(helper, reflector, skill);
        CPData cp = CPData.get(reflector);
        float cpBefore = cp.getCP();
        float reflectorBefore = reflector.getHealth();
        float zombieBefore = behind.getHealth();
        float pigBefore = pig.getHealth();
        withPvp(helper, () -> {
            check(helper, SkillContexts.start(shooter, ID, railgun) == StartResult.OK, "railgun start accepted");
            for (int i = 0; i < RailgunRules.HOLD_TICKS; i++) {
                SkillContexts.tick(shooter);
            }
        });
        check(helper, field.reflectedCount() == 1 && !field.isTerminated(), "the beam is reflected, field still on");
        float spent = cpBefore - cp.getCP();
        float expected = VecReflectionRules.cpPerDamage(EXP, RailgunRules.damage(0f));
        check(helper, Math.abs(spent - expected) < 0.05f, "cost " + expected + ", spent " + spent);
        check(helper, reflector.getHealth() == reflectorBefore, "the reflector is not hurt");
        check(helper, behind.getHealth() == zombieBefore, "the beam stops at the reflector");
        check(helper, pig.getHealth() < pigBefore, "the counter attack hits what the reflector looks at");
        float exp = AbilityData.get(reflector).getSkillExp(skill.getId());
        check(helper, exp > EXP, "reflecting the beam gives exp: " + exp);
        helper.succeed();
    }
}
