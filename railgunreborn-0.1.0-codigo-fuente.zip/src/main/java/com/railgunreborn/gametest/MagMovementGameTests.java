package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagMovementRules;
import com.railgunreborn.ability.electromaster.MagneticTargets;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Magnet Movement (T28). El jugador falso mira al sur (+Z) desde (4.5, 1, 1.5); el objetivo se pone a la
 * altura de los ojos en z = 6. El movimiento lo hace el cliente, así que aquí solo se prueba el servidor: objetivo,
 * cobro, exp y terminación. Los ticks del contexto se dan a mano con {@link SkillContexts#tick}.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MagMovementGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    private static final BlockPos TARGET = new BlockPos(4, 2, 6);

    // --- utilidades (mismo jugador falso que ChargingGameTests) ---

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 2 con Magnet Movement aprendida y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(2);
        Skill skill = Electromaster.MAG_MOVEMENT.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData.get(player).setActivated(player, true);
        return skill;
    }

    private static float exp(ServerPlayer player, Skill skill) {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void tick(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.tick(player);
        }
    }

    /** Pulsar apuntando a algo que no sirve: termina en el acto, sin overload, CP ni exp. */
    private static void assertNothingHappens(GameTestHelper helper, ServerPlayer player, Skill skill, float expBefore) {
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, SkillContexts.active(player).isEmpty(), "without a valid target it should end at once");
        check(helper, cp.getOverload() == 0f, "no overload should be charged, was " + cp.getOverload());
        check(helper, cp.getCP() == startCP, "no CP should be spent");
        check(helper, Math.abs(exp(player, skill) - expBefore) < 1e-7f,
                "no exp should be given, was " + exp(player, skill));
    }

    // --- tests ---

    @GameTest(template = EMPTY)
    public static void magMovementIsRegistered(GameTestHelper helper) {
        Skill skill = Electromaster.MAG_MOVEMENT.get();
        check(helper, skill.getLevel() == 2, "level should be 2");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Electromaster.ARC_GEN.getId())
                && skill.getParent().get().minExp() == 0f, "parent should be arc_gen (0.0)");
        check(helper, skill.getGuiX() == 137 && skill.getGuiY() == 35, "tree position should be 137, 35");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void magneticTagsHaveOriginalDefaults(GameTestHelper helper) {
        for (Block block : new Block[] {Blocks.RAIL, Blocks.IRON_BARS, Blocks.IRON_BLOCK, Blocks.ACTIVATOR_RAIL,
                Blocks.DETECTOR_RAIL, Blocks.POWERED_RAIL, Blocks.STICKY_PISTON, Blocks.PISTON}) {
            check(helper, block.defaultBlockState().is(MagneticTargets.MAGNETIC_BLOCKS), block + " should be magnetic");
        }
        for (Block block : new Block[] {Blocks.DISPENSER, Blocks.HOPPER, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE}) {
            check(helper, block.defaultBlockState().is(MagneticTargets.WEAK_MAGNETIC_BLOCKS),
                    block + " should be weakly magnetic");
        }
        check(helper, !Blocks.STONE.defaultBlockState().is(MagneticTargets.MAGNETIC_BLOCKS), "stone is not magnetic");
        for (EntityType<?> type : new EntityType<?>[] {EntityType.MINECART, EntityType.CHEST_MINECART,
                EntityType.FURNACE_MINECART, EntityType.TNT_MINECART, EntityType.HOPPER_MINECART,
                EntityType.SPAWNER_MINECART, EntityType.COMMAND_BLOCK_MINECART, EntityType.IRON_GOLEM}) {
            check(helper, type.is(MagneticTargets.MAGNETIC_ENTITIES), type + " should be magnetic");
        }
        check(helper, !EntityType.ZOMBIE.is(MagneticTargets.MAGNETIC_ENTITIES), "zombie is not magnetic");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ironBlockStartsPullAndCharges(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(TARGET, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, !SkillContexts.active(player).isEmpty(), "an iron block is a valid target");
        check(helper, Math.abs(cp.getOverload() - MagMovementRules.overloadCost(0f)) < EPS,
                "initial overload should be 60, was " + cp.getOverload());
        check(helper, cp.getCP() == startCP, "pressing alone must not spend CP");

        int ticks = 10;
        player.fallDistance = 5f;
        tick(player, ticks);
        check(helper, !SkillContexts.active(player).isEmpty(), "context should stay alive while held");
        float expectedCP = startCP - ticks * MagMovementRules.cpPerTick(0f);
        check(helper, Math.abs(cp.getCP() - expectedCP) < EPS, "CP should be " + expectedCP + ", was " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - MagMovementRules.overloadCost(0f)) < EPS,
                "overload must not change while held, was " + cp.getOverload());
        check(helper, player.fallDistance == 0f, "fall distance should be reset while pulling");
        check(helper, exp(player, skill) == 0f, "exp is only given at the end");

        // Soltar termina; exp mínima (no se movió) y sin cooldown.
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, SkillContexts.active(player).isEmpty(), "releasing the key should terminate");
        check(helper, Math.abs(exp(player, skill) - MagMovementRules.MIN_EXP_GAIN) < 1e-6f,
                "exp should be the 0.005 minimum, was " + exp(player, skill));
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "mag movement has no cooldown");
        check(helper, SkillContexts.validateStart(player, skill) == StartResult.OK, "should be startable again");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void railIsTargetableByOutline(GameTestHelper helper) {
        floor(helper);
        // Riel sin colisión en el suelo: hay que mirar hacia abajo para verlo.
        helper.setBlock(new BlockPos(4, 1, 4), Blocks.RAIL);
        ServerPlayer player = player(helper);
        Vec3 pos = player.position();
        player.moveTo(pos.x, pos.y, pos.z, 0f, 25f);
        Skill skill = setUp(player, 0f);
        SkillContexts.start(player, 1, skill);
        check(helper, !SkillContexts.active(player).isEmpty(), "a rail should be a valid target (outline trace)");
        SkillContexts.terminateAll(player, TerminationReason.LOGOUT);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void stoneOrNothingChargesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        // Nada delante.
        assertNothingHappens(helper, player, skill, 0f);
        // Piedra delante de un bloque de hierro: cuenta el primer impacto.
        helper.setBlock(TARGET, Blocks.IRON_BLOCK);
        helper.setBlock(TARGET.north(), Blocks.STONE);
        assertNothingHappens(helper, player, skill, 0f);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void weakBlockNeedsExp06(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(TARGET, Blocks.HOPPER);
        ServerPlayer low = player(helper);
        Skill skill = setUp(low, 0.5f);
        assertNothingHappens(helper, low, skill, 0.5f);
        // Que no estorbe al trazado del segundo jugador.
        Vec3 aside = helper.absoluteVec(new Vec3(1.5, 1, 1.5));
        low.moveTo(aside.x, aside.y, aside.z, 0f, 0f);

        ServerPlayer high = player(helper);
        setUp(high, 0.6f);
        CPData cp = CPData.get(high);
        SkillContexts.start(high, 1, skill);
        check(helper, !SkillContexts.active(high).isEmpty(), "with exp 0.6 a hopper is a valid target");
        check(helper, Math.abs(cp.getOverload() - MagMovementRules.overloadCost(0.6f)) < EPS,
                "initial overload should be 42, was " + cp.getOverload());
        SkillContexts.terminateAll(high, TerminationReason.LOGOUT);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void entityTargetEndsWhenItDisappears(GameTestHelper helper) {
        floor(helper);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        SkillContexts.start(player, 1, skill);
        check(helper, !SkillContexts.active(player).isEmpty(), "an iron golem is a valid target");
        tick(player, 2);
        check(helper, !SkillContexts.active(player).isEmpty(), "should keep pulling while the golem exists");
        golem.discard();
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "a removed target should terminate");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void brokenBlockTargetEnds(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(TARGET, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        SkillContexts.start(player, 1, skill);
        check(helper, !SkillContexts.active(player).isEmpty(), "start should find the iron block");
        helper.setBlock(TARGET, Blocks.AIR);
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "breaking the target block should terminate");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void runningOutOfCpEnds(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(TARGET, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 20f); // un tick de 15 y el segundo falla
        SkillContexts.start(player, 1, skill);
        tick(player, 1);
        check(helper, !SkillContexts.active(player).isEmpty(), "one tick should still be paid");
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "running out of CP should terminate");
        helper.succeed();
    }
}
