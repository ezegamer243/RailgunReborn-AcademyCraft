package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.DirBlastRules;
import com.railgunreborn.ability.vecmanip.DirBlastSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.registry.ModDamageTypes;
import com.railgunreborn.registry.ModSounds;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Directed Blastwave (T73). Jugador falso en (4.5, 1, 1.5) mirando a +z; el golpe cae a ≤ 4 bloques.
 * Las tiradas de rotura se fijan a 0 (se evalúan todas las casillas de la esfera). Golems (no se queman).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class DirBlastGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    private static final int HOLD = 10;
    /** Pared de tierra a z = 4 (x 1..7, y 1..3): el rayo de los ojos da en (4, 2, 4). */
    private static final int WALL_Z = 4;
    private static final BlockPos AIMED = new BlockPos(4, 2, WALL_Z);

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-db-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void wall(GameTestHelper helper) {
        for (int x = 1; x <= 7; x++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(x, y, WALL_Z), Blocks.DIRT);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Vector Manipulation nivel 3 con Directed Blastwave aprendida, CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(3);
        Skill skill = VecManip.DIR_BLAST.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, mantiene {@code ticks} ticks de servidor y suelta, con las tiradas de rotura fijas a 0. */
    private static void hold(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        DirBlastSkill.rollOverride = () -> 0.0;
        try {
            check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
            for (int i = 0; i < ticks; i++) {
                SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
                SkillContexts.tick(player);
            }
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
            check(helper, SkillContexts.find(player, skill).isEmpty(), "releasing ends the context");
        } finally {
            DirBlastSkill.rollOverride = null;
        }
    }

    private static void withGriefing(GameTestHelper helper, boolean mobGriefing, Runnable action) {
        MinecraftServer server = helper.getLevel().getServer();
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(mobGriefing, server);
            action.run();
        } finally {
            rule.set(original, server);
        }
    }

    private static boolean is(GameTestHelper helper, BlockPos pos, Block block) {
        return helper.getBlockState(pos).is(block);
    }

    private static List<ItemEntity> items(GameTestHelper helper) {
        AABB box = new AABB(helper.absolutePos(BlockPos.ZERO)).inflate(12);
        return helper.getLevel().getEntitiesOfClass(ItemEntity.class, box);
    }

    private static float exp(ServerPlayer player, Skill skill) {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    // --- pruebas ---

    @GameTest(template = EMPTY)
    public static void dirBlastIsRegistered(GameTestHelper helper) {
        Skill skill = AbilityRegistries.skill(VecManip.skillId("dir_blast")).orElse(null);
        check(helper, skill == VecManip.DIR_BLAST.get(), "dir_blast registered");
        check(helper, skill.getCategoryId().equals(VecManip.ID) && skill.getLevel() == 3 && skill.canControl(),
                "vecmanip level 3, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(VecManip.skillId("ground_shock"))
                && p.minExp() == 0f).orElse(false), "parent ground_shock 0.0");
        check(helper, skill.getGuiX() == 136 && skill.getGuiY() == 80, "gui position 136, 80");
        check(helper, VecManip.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/dir_blast.png"),
                "icon " + skill.getIcon());
        check(helper, ModSounds.VM_DIRECTED_BLAST.get() != null, "sound registered");
        check(helper, helper.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(ModDamageTypes.DIR_BLAST).isPresent(), "damage type dir_blast loaded");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releaseInTheWindowHurtsAndPushesAGolem(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        withGriefing(helper, false, () -> hold(helper, player, skill, HOLD));

        check(helper, Math.abs(before - golem.getHealth() - 10f) < EPS,
                "10 damage at exp 0, lost " + (before - golem.getHealth()));
        Vec3 v = golem.getDeltaMovement();
        check(helper, v.z > 0.9 && Math.abs(v.x) < 0.1 && v.y > 0.3, "strong push away (+z) and up, velocity " + v);
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 160f) < 0.5f, "CP 160 charged");
        check(helper, Math.abs(CPData.get(player).getOverload() - 50f) < 0.5f, "overload 50");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 80, "cooldown 80");
        check(helper, Math.abs(exp(player, skill) - DirBlastRules.EXP_HIT) < 1e-6f, "exp +0.0025");
        check(helper, player.getHealth() == player.getMaxHealth(), "the caster is not hurt");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void breaksBlocksWithDropsWhenMobGriefingIsOn(GameTestHelper helper) {
        floor(helper);
        wall(helper);
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 0f);

        withGriefing(helper, true, () -> hold(helper, player, skill, HOLD));

        check(helper, is(helper, AIMED, Blocks.AIR), "the aimed block is broken");
        check(helper, is(helper, AIMED.east(), Blocks.AIR) && is(helper, AIMED.above(), Blocks.AIR),
                "neighbours inside the sphere are broken");
        check(helper, is(helper, new BlockPos(1, 2, WALL_Z), Blocks.DIRT), "a block outside the sphere stays");
        check(helper, is(helper, new BlockPos(4, 0, 1), Blocks.STONE), "the floor under the caster stays");
        long dirt = items(helper).stream().filter(i -> i.getItem().is(Items.DIRT))
                .mapToLong(i -> i.getItem().getCount()).sum();
        check(helper, dirt >= 10, "broken dirt is dropped, items: " + dirt);
        check(helper, Math.abs(exp(player, skill) - DirBlastRules.EXP_BLOCKS_ONLY) < 1e-6f,
                "exp +0.0012 for blocks only, was " + exp(player, skill));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void breaksNothingWhenMobGriefingIsOff(GameTestHelper helper) {
        floor(helper);
        wall(helper);
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 0f);

        withGriefing(helper, false, () -> hold(helper, player, skill, HOLD));

        for (int x = 1; x <= 7; x++) {
            for (int y = 1; y <= 3; y++) {
                check(helper, is(helper, new BlockPos(x, y, WALL_Z), Blocks.DIRT), "wall intact at " + x + "," + y);
            }
        }
        check(helper, items(helper).isEmpty(), "no drops");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 80, "still charged and cooled");
        check(helper, exp(player, skill) == 0f, "nothing hit: no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void neverBreaksAChest(GameTestHelper helper) {
        floor(helper);
        wall(helper);
        helper.setBlock(AIMED, Blocks.CHEST);
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 1f);

        withGriefing(helper, true, () -> hold(helper, player, skill, HOLD));

        check(helper, is(helper, AIMED, Blocks.CHEST), "the chest is never broken");
        check(helper, is(helper, AIMED.east(), Blocks.AIR), "the dirt around it is");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void airBlastChargesWithoutExp(GameTestHelper helper) {
        // Sin suelo ni nada a 4 bloques: el golpe no toca nada.
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 0f);
        float cpBefore = CPData.get(player).getCP();

        withGriefing(helper, true, () -> hold(helper, player, skill, HOLD));

        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 160f) < 0.5f, "CP charged anyway");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 80, "cooldown set anyway");
        check(helper, exp(player, skill) == 0f, "no exp in the air, was " + exp(player, skill));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingOutsideTheWindowDoesNothing(GameTestHelper helper) {
        floor(helper);
        wall(helper);
        ServerPlayer player = player(helper, 0f, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 3.0));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        withGriefing(helper, true, () -> {
            hold(helper, player, skill, 3);
            hold(helper, player, skill, DirBlastRules.MAX_TICKS + 10);
        });

        check(helper, golem.getHealth() == before, "no damage");
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, exp(player, skill) == 0f, "no exp");
        check(helper, is(helper, AIMED, Blocks.DIRT), "no block broken");
        helper.succeed();
    }
}
