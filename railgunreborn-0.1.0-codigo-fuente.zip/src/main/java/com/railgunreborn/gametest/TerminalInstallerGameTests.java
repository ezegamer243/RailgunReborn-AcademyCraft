package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.terminal.TerminalAccess;
import com.railgunreborn.terminal.TerminalData;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests del Terminal como ítem (T92): instalador, dato persistente, acceso, receta y comando. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class TerminalInstallerGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper, GameType mode) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-terminal-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        player.setGameMode(mode);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    @GameTest(template = EMPTY)
    public static void installerSetsFlagAndConsumesOne(GameTestHelper helper) {
        ServerPlayer p = player(helper, GameType.SURVIVAL);
        ItemStack stack = new ItemStack(ModItems.TERMINAL_INSTALLER.get());
        p.setItemInHand(InteractionHand.MAIN_HAND, stack);
        check(helper, !TerminalAccess.isInstalled(p), "survival player must start without terminal");
        stack.use(helper.getLevel(), p, InteractionHand.MAIN_HAND);
        check(helper, TerminalAccess.hasInstalledFlag(p), "flag must be set after use");
        check(helper, TerminalAccess.isInstalled(p), "access must be granted after use");
        check(helper, stack.isEmpty(), "installer must be consumed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void secondUseDoesNotConsume(GameTestHelper helper) {
        ServerPlayer p = player(helper, GameType.SURVIVAL);
        TerminalAccess.setInstalled(p, true);
        ItemStack stack = new ItemStack(ModItems.TERMINAL_INSTALLER.get());
        p.setItemInHand(InteractionHand.MAIN_HAND, stack);
        stack.use(helper.getLevel(), p, InteractionHand.MAIN_HAND);
        check(helper, !stack.isEmpty(), "installer must not be consumed when already installed");
        check(helper, TerminalAccess.hasInstalledFlag(p), "flag must stay set");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void creativeAlwaysHasAccess(GameTestHelper helper) {
        ServerPlayer creative = player(helper, GameType.CREATIVE);
        check(helper, TerminalAccess.isInstalled(creative), "creative must have access");
        check(helper, !TerminalAccess.hasInstalledFlag(creative), "creative access must not set the flag");
        creative.setGameMode(GameType.SURVIVAL);
        check(helper, !TerminalAccess.isInstalled(creative), "survival without flag must not have access");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void flagSurvivesCodecAndDeathCopy(GameTestHelper helper) {
        TerminalData on = new TerminalData(true);
        var tag = TerminalData.CODEC.encodeStart(NbtOps.INSTANCE, on).getOrThrow();
        TerminalData back = TerminalData.CODEC.parse(NbtOps.INSTANCE, tag).getOrThrow();
        check(helper, back.installed(), "codec roundtrip must keep installed=true");
        // Mundos viejos: sin el campo queda en false.
        TerminalData old = TerminalData.CODEC.parse(NbtOps.INSTANCE, new CompoundTag()).getOrThrow();
        check(helper, !old.installed(), "missing field must default to false");
        // La copia al morir pasa por este mismo Codec (copyOnDeath serializa y deserializa el attachment).
        ServerPlayer p = player(helper, GameType.SURVIVAL);
        p.setData(ModAttachments.TERMINAL_DATA, on);
        ServerPlayer clone = player(helper, GameType.SURVIVAL);
        clone.setData(ModAttachments.TERMINAL_DATA, TerminalData.CODEC
                .parse(NbtOps.INSTANCE, TerminalData.CODEC.encodeStart(NbtOps.INSTANCE, TerminalData.get(p))
                        .getOrThrow()).getOrThrow());
        check(helper, TerminalAccess.hasInstalledFlag(clone), "copy must keep the flag");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void recipeLoads(GameTestHelper helper) {
        ItemStack e = ItemStack.EMPTY;
        ItemStack chip = new ItemStack(ModItems.DATA_CHIP.get());
        ItemStack pane = new ItemStack(Items.GLASS_PANE);
        ItemStack plate = new ItemStack(ModItems.REINFORCED_IRON_PLATE.get());
        ItemStack brain = new ItemStack(ModItems.BRAIN_COMPONENT.get());
        ItemStack info = new ItemStack(ModItems.INFO_COMPONENT.get());
        ItemStack block = new ItemStack(Items.REDSTONE_BLOCK);
        List<ItemStack> grid = List.of(chip, pane, chip, plate, brain, plate, info, block, info);
        CraftingInput input = CraftingInput.of(3, 3, grid);
        ItemStack out = helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(e);
        Item expected = ModItems.TERMINAL_INSTALLER.get();
        check(helper, out.is(expected) && out.getCount() == 1, "terminal_installer recipe: got " + out);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void commandInstallsAndUninstalls(GameTestHelper helper) {
        ServerPlayer p = player(helper, GameType.SURVIVAL);
        MinecraftServer server = helper.getLevel().getServer();
        var source = p.createCommandSourceStack().withPermission(2);
        server.getCommands().performPrefixedCommand(source, "railgunreborn terminal install");
        check(helper, TerminalAccess.hasInstalledFlag(p), "command install must set the flag");
        server.getCommands().performPrefixedCommand(source, "railgunreborn terminal uninstall");
        check(helper, !TerminalAccess.hasInstalledFlag(p), "command uninstall must clear the flag");
        // Sin permiso de operador no hace nada.
        var plain = p.createCommandSourceStack().withPermission(0);
        server.getCommands().performPrefixedCommand(plain, "railgunreborn terminal install");
        check(helper, !TerminalAccess.hasInstalledFlag(p), "non-op must not be able to install");
        helper.succeed();
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }
}
