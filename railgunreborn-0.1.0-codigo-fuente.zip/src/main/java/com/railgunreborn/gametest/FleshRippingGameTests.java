package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.FleshRippingRules;
import com.railgunreborn.ability.teleporter.FleshRippingSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.PlayerTeam;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Flesh Ripping (T60). Jugador falso en (4.5, 1, 1.5) mirando hacia +Z; golem (no se quema). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class FleshRippingGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-flesh-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Teleporter nivel 3 con Flesh Ripping aprendida (con la exp dada), CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(3);
        Skill skill = Teleporter.FLESH_RIPPING.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void press(ServerPlayer player, Skill skill) {
        if (SkillContexts.start(player, 1, skill) != StartResult.OK) {
            throw new AssertionError("start should be accepted");
        }
    }

    /** Pulsa, mantiene un tick y suelta. */
    private static void shoot(ServerPlayer player, Skill skill) {
        press(player, skill);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
        SkillContexts.tick(player);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    private static void assertNothingHappened(GameTestHelper helper, ServerPlayer player, Skill skill,
            float cpBefore) {
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        check(helper, !player.hasEffect(MobEffects.CONFUSION), "no nausea");
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel3(GameTestHelper helper) {
        Skill skill = Teleporter.FLESH_RIPPING.get();
        check(helper, skill.getLevel() == 3 && skill.canControl(), "level 3, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.skillId("mark_teleport"))
                && p.minExp() == 0.5f).orElse(false), "parent mark_teleport at 0.5");
        check(helper, skill.getGuiX() == 130 && skill.getGuiY() == 12, "gui position 130, 12");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/flesh_ripping.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hitsTheMobAndCharges(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        FleshRippingSkill.disgustRollOverride = () -> 0.99;
        try {
            IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
            float before = golem.getHealth();
            float cpBefore = CPData.get(player).getCP();

            shoot(player, skill);

            check(helper, Math.abs(before - golem.getHealth() - 5f) < EPS,
                    "5 damage, lost " + (before - golem.getHealth()));
            check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 130f) < 0.5f, "CP charged (130 at exp 0)");
            check(helper, Math.abs(CPData.get(player).getOverload() - 60f) < 0.5f, "overload 60");
            check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 90, "cooldown 90");
            check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - FleshRippingRules.EXP_HIT)
                    < 1e-6f, "exp +0.005");
            check(helper, !player.hasEffect(MobEffects.CONFUSION), "no nausea with a high roll");
        } finally {
            FleshRippingSkill.disgustRollOverride = null;
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ignoresArmor(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 5.5));
        zombie.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        zombie.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        zombie.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        zombie.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        float before = zombie.getHealth();
        shoot(player, skill);
        check(helper, Math.abs(before - zombie.getHealth() - 5f) < EPS,
                "armor ignored, lost " + (before - zombie.getHealth()));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingBeforeTheFirstTickStillWorks(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        press(player, skill);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, before - golem.getHealth() > 4f, "damaged with no server tick in between");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void aWallBlocksTheRipAndCostsNothing(GameTestHelper helper) {
        floor(helper);
        for (int y = 1; y <= 4; y++) {
            for (int x = 2; x <= 7; x++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.STONE);
            }
        }
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();
        FleshRippingSkill.disgustRollOverride = () -> 0.0;
        try {
            shoot(player, skill);
        } finally {
            FleshRippingSkill.disgustRollOverride = null;
        }
        check(helper, golem.getHealth() == before, "no damage through the wall");
        assertNothingHappened(helper, player, skill, cpBefore);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpTheKeyIsRejected(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData.get(player).consumeWithForce(player, 0f, 1.0e9f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, golem.getHealth() == before, "no damage without CP");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void protectedPlayerCostsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        ServerPlayer victim = player(helper);
        Vec3 at = helper.absoluteVec(new Vec3(4.5, 1, 5.5));
        victim.moveTo(at.x, at.y, at.z, 0f, 0f);
        var scoreboard = helper.getLevel().getScoreboard();
        PlayerTeam team = scoreboard.addPlayerTeam("fr_pvp_" + UUID.randomUUID().toString().substring(0, 8));
        team.setAllowFriendlyFire(false);
        scoreboard.addPlayerToTeam(player.getScoreboardName(), team);
        scoreboard.addPlayerToTeam(victim.getScoreboardName(), team);
        float cpBefore = CPData.get(player).getCP();
        FleshRippingSkill.disgustRollOverride = () -> 0.0;
        try {
            float before = victim.getHealth();
            shoot(player, skill);
            check(helper, victim.getHealth() == before, "a protected player must not be hurt");
            assertNothingHappened(helper, player, skill, cpBefore);
        } finally {
            FleshRippingSkill.disgustRollOverride = null;
            scoreboard.removePlayerTeam(team);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void lowRollNauseatesTheCasterForFiveSeconds(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        FleshRippingSkill.disgustRollOverride = () -> 0.0;
        try {
            shoot(player, skill);
        } finally {
            FleshRippingSkill.disgustRollOverride = null;
        }
        var effect = player.getEffect(MobEffects.CONFUSION);
        check(helper, effect != null && effect.getDuration() == FleshRippingRules.DISGUST_TICKS
                && effect.getAmplifier() == 0, "nausea 100 ticks, level I");
        helper.succeed();
    }
}
