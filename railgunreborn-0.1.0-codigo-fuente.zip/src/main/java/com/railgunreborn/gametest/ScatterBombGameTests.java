package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.ScatterBombRules;
import com.railgunreborn.ability.meltdowner.ScatterBombSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import com.railgunreborn.network.SkillContextActionPayload;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Scatter Bomb (T44). Jugador falso mirando hacia +Z desde (4.5, 1, 1.5). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ScatterBombGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-4f;

    private static ServerPlayer player(GameTestHelper helper, float pitch, double dy) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-scatter-bomb"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1 + dy, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 2 con Scatter Bomb aprendida (con la exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(2);
        Skill bomb = Meltdowner.SCATTER_BOMB.get();
        ability.learnSkill(bomb.getId());
        ability.setSkillExp(bomb.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return bomb;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Ticks de servidor con el cliente vivo (keep-alive), como mantener la tecla. */
    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static int balls(ServerPlayer player) {
        for (var ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof ScatterBombSkill.ScatterBombContext scatter) {
                return scatter.ballCount();
            }
        }
        return -1;
    }

    private static void release(ServerPlayer player) {
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void scatterBombIsRegisteredAtLevel2UnderElectronBomb(GameTestHelper helper) {
        Skill bomb = Meltdowner.SCATTER_BOMB.get();
        check(helper, bomb.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, bomb.getLevel() == 2 && bomb.canControl(), "level 2, controllable");
        check(helper, bomb.getParent().isPresent()
                && bomb.getParent().get().skill().equals(Meltdowner.ELECTRON_BOMB.getId())
                && Math.abs(bomb.getParent().get().minExp() - 0.8f) < EPS, "parent: electron bomb (0.8)");
        check(helper, bomb.getGuiX() == 70 && bomb.getGuiY() == 50, "tree position should be 70, 50");
        check(helper, AbilityRegistries.SKILL_REGISTRY.containsKey(bomb.getId()), "present in the skill registry");
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.RAD_INTENSIFY.get())
                < AbilityRegistries.SKILL_REGISTRY.getId(bomb), "registered after rad intensify");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void holdingFortyFiveTicksMakesThreeBallsAndReleaseHurtsTheMob(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f, 0);
        // exp 0.9: 2 de 3 bolas apuntan solas al gigante, asi el golpe no depende de la dispersion.
        Skill bomb = setUp(player, 0.9f);
        IronGolem target = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        float before = target.getHealth();
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        float expectedOverload = ScatterBombRules.initialOverload(0.9f);
        check(helper, Math.abs(cp.getOverload() - expectedOverload) < EPS, "initial overload " + cp.getOverload());
        hold(player, 45);
        check(helper, balls(player) == 3, "3 balls at tick 45, had " + balls(player));
        check(helper, Math.abs(cp.getOverload() - expectedOverload) < EPS, "overload stays fixed while held");
        float expectedCp = cpBefore - 45 * ScatterBombRules.cpPerTick(0.9f);
        check(helper, Math.abs(cp.getCP() - expectedCp) < 0.01f, "CP " + cp.getCP() + " expected " + expectedCp);
        check(helper, target.getHealth() == before, "no damage while charging");

        release(player);
        check(helper, SkillContexts.active(player).isEmpty(), "release ends the context");
        float damage = ScatterBombRules.damage(0.9f);
        check(helper, target.getHealth() <= before - 2 * damage + 0.01f,
                "at least the 2 aimed balls hit: " + before + " -> " + target.getHealth());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingBeforeTick20FiresNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f, 0);
        Skill bomb = setUp(player, 0.9f);
        IronGolem target = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        float before = target.getHealth();

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        hold(player, 19);
        check(helper, balls(player) == 0, "no ball before tick 20");
        release(player);
        check(helper, target.getHealth() == before, "nothing is fired");
        check(helper, AbilityData.get(player).getSkillExp(bomb.getId()) == 0.9f, "no exp");
        check(helper, CPData.get(player).getOverload() > 0f, "the initial overload is already spent");
        check(helper, !CooldownData.get(player).isInCooldown(bomb.getId()), "scatter bomb has no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void expComesOnlyFromBallsThatHurtALivingEntity(GameTestHelper helper) {
        floor(helper);
        // Al cielo y sin mobs: ninguna bola daña, ninguna exp.
        ServerPlayer sky = player(helper, -90f, 40);
        Skill bomb = setUp(sky, 0f);
        check(helper, SkillContexts.start(sky, 1, bomb) == StartResult.OK, "start should be accepted");
        hold(sky, 45);
        release(sky);
        check(helper, AbilityData.get(sky).getSkillExp(bomb.getId()) == 0f, "misses give no exp");

        // Con autoapuntado al gigante, cada bola que impacta da 0.001 (2 de 3 seguras).
        ServerPlayer shooter = player(helper, 0f, 0);
        setUp(shooter, 0.9f);
        helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        check(helper, SkillContexts.start(shooter, 1, bomb) == StartResult.OK, "start should be accepted");
        hold(shooter, 45);
        release(shooter);
        float gained = AbilityData.get(shooter).getSkillExp(bomb.getId()) - 0.9f;
        check(helper, gained >= 2 * ScatterBombRules.EXP_PER_BALL - 1e-6f
                && gained <= 3 * ScatterBombRules.EXP_PER_BALL + 1e-6f, "exp per hitting ball, gained " + gained);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void holdingTwoHundredTicksHurtsThePlayerForSix(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, -90f, 40);
        Skill bomb = setUp(player, 0f);
        // El jugador falso nace con la proteccion de aparicion (60 ticks): se gasta antes de empezar.
        for (int i = 0; i < 61; i++) {
            player.tick();
        }
        player.invulnerableTime = 0;
        player.setHealth(20f);
        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        hold(player, 199);
        check(helper, player.getHealth() == 20f && !SkillContexts.active(player).isEmpty(), "still safe at 199");
        check(helper, balls(player) == ScatterBombRules.MAX_BALLS, "7 balls max");
        hold(player, 1);
        check(helper, Math.abs(player.getHealth() - 14f) < 0.01f, "6 self damage, health " + player.getHealth());
        check(helper, SkillContexts.active(player).isEmpty(), "the context ends at tick 200");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noCpEndsTheContextAndStillFiresTheBallsMade(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f, 0);
        Skill bomb = setUp(player, 0.9f);
        IronGolem target = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        float before = target.getHealth();
        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        hold(player, 45);
        // Se queda sin CP: el siguiente tick no se paga, termina y dispara las 3 bolas.
        CPData.get(player).consumeWithForce(player, 0f, CPData.get(player).getCP());
        hold(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "no CP ends the context");
        check(helper, target.getHealth() < before, "balls made so far still fire");
        helper.succeed();
    }
}
