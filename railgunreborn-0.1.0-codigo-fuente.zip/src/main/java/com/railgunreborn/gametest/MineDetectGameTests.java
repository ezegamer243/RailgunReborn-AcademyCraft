package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MineDetectRules;
import com.railgunreborn.ability.electromaster.MineDetectSkill;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Mine Detection (T31). La detección y el dibujo son del cliente; aquí se prueba lo del servidor
 * (consumo, Ceguera, exp, cooldown) y que el tag y el nivel de herramienta clasifican bien bloques reales.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MineDetectGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    // --- utilidades (mismo jugador falso que ThunderBoltGameTests) ---

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setYHeadRot(0f); // el mock nace con la cabeza girada al azar y getViewVector la usa
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    /** Electromaster nivel 3 con Mine Detection aprendida (exp 0) y modo habilidad encendido. */
    private static Skill setUpMineDetect(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(3);
        Skill skill = Electromaster.MINE_DETECT.get();
        ability.learnSkill(skill.getId());
        CPData.get(player).setActivated(player, true);
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    // --- tests ---

    @GameTest(template = EMPTY)
    public static void mineDetectIsRegisteredInTheTree(GameTestHelper helper) {
        Skill skill = Electromaster.MINE_DETECT.get();
        check(helper, skill.getLevel() == 3, "level should be 3");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Electromaster.MAG_MANIP.getId())
                && Math.abs(skill.getParent().get().minExp() - 1.0f) < EPS, "parent should be mag_manip (1.0)");
        check(helper, skill.getExtraDependencies().isEmpty(), "no extra dependencies");
        check(helper, skill.getGuiX() == 225 && skill.getGuiY() == 12, "tree position should be 225, 12");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mineDetectBlindsAndSpendsResources(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUpMineDetect(player);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        StartResult result = SkillContexts.start(player, 1, skill);
        check(helper, result == StartResult.OK, "start should be accepted, was " + result);
        MobEffectInstance blindness = player.getEffect(MobEffects.BLINDNESS);
        check(helper, blindness != null && blindness.getDuration() == MineDetectRules.EFFECT_TICKS
                && blindness.getAmplifier() == 0, "should get Blindness I for 100 ticks, got " + blindness);
        check(helper, Math.abs(cp.getCP() - (cpBefore - 1500f)) < EPS,
                "CP should drop by 1500, was " + cpBefore + " -> " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - 200f) < EPS, "overload should be 200, was " + cp.getOverload());
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, Math.abs(exp - MineDetectRules.EXP_GAIN) < 1e-6f, "exp should be 0.008, was " + exp);
        int cooldown = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, cooldown == MineDetectRules.cooldownTicks(MineDetectRules.EXP_GAIN),
                "cooldown should use the exp after the gain (896), was " + cooldown);
        check(helper, SkillContexts.active(player).isEmpty(), "context should have terminated itself");
        check(helper, SkillContexts.validateStart(player, skill) == StartResult.COOLDOWN,
                "second use should be rejected by cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mineDetectWithoutCpDoesNothing(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUpMineDetect(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 1000f); // quedan 1000, faltan 500
        float cpBefore = cp.getCP();

        SkillContexts.start(player, 1, skill);
        check(helper, player.getEffect(MobEffects.BLINDNESS) == null, "no Blindness without enough CP");
        check(helper, cp.getCP() == cpBefore, "CP must not change, was " + cpBefore + " -> " + cp.getCP());
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown on a failed use");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp on a failed use");
        check(helper, SkillContexts.active(player).isEmpty(), "context should have terminated itself");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mineDetectRejectedWithoutCategoryOrLearning(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = Electromaster.MINE_DETECT.get();
        StartResult noCategory = SkillContexts.validateStart(player, skill);
        check(helper, noCategory == StartResult.WRONG_CATEGORY, "expected WRONG_CATEGORY, was " + noCategory);

        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(3);
        CPData.get(player).setActivated(player, true);
        StartResult notLearned = SkillContexts.validateStart(player, skill);
        check(helper, notLearned == StartResult.NOT_LEARNED, "expected NOT_LEARNED, was " + notLearned);
        check(helper, player.getEffect(MobEffects.BLINDNESS) == null, "a rejected start must not blind");
        helper.succeed();
    }

    /** El tag {@code detectable_ores} (= {@code #c:ores}) y el color por nivel de herramienta sobre bloques colocados. */
    @GameTest(template = EMPTY)
    public static void oresAreClassifiedByTagAndToolTier(GameTestHelper helper) {
        expect(helper, new BlockPos(1, 1, 1), Blocks.IRON_ORE, true, MineDetectRules.TOOL_STONE);
        expect(helper, new BlockPos(2, 1, 1), Blocks.DEEPSLATE_DIAMOND_ORE, true, MineDetectRules.TOOL_IRON);
        expect(helper, new BlockPos(3, 1, 1), Blocks.COAL_ORE, true, MineDetectRules.TOOL_NONE);
        expect(helper, new BlockPos(4, 1, 1), Blocks.NETHER_GOLD_ORE, true, MineDetectRules.TOOL_NONE);
        expect(helper, new BlockPos(5, 1, 1), Blocks.NETHER_QUARTZ_ORE, true, MineDetectRules.TOOL_NONE);
        expect(helper, new BlockPos(6, 1, 1), Blocks.ANCIENT_DEBRIS, true, MineDetectRules.TOOL_DIAMOND);
        expect(helper, new BlockPos(7, 1, 1), Blocks.COPPER_ORE, true, MineDetectRules.TOOL_STONE);
        expect(helper, new BlockPos(1, 1, 2), Blocks.STONE, false, MineDetectRules.TOOL_NONE);
        expect(helper, new BlockPos(2, 1, 2), Blocks.IRON_BLOCK, false, MineDetectRules.TOOL_STONE);
        expect(helper, new BlockPos(3, 1, 2), Blocks.RAW_IRON_BLOCK, false, MineDetectRules.TOOL_STONE);
        helper.succeed();
    }

    private static void expect(GameTestHelper helper, BlockPos pos, Block block, boolean detectable, int tier) {
        helper.setBlock(pos, block);
        var state = helper.getBlockState(pos);
        check(helper, MineDetectSkill.isDetectable(state) == detectable,
                block + " detectable should be " + detectable);
        if (detectable) {
            check(helper, MineDetectSkill.toolTier(state) == tier,
                    block + " tool tier should be " + tier + ", was " + MineDetectSkill.toolTier(state));
        }
    }
}
