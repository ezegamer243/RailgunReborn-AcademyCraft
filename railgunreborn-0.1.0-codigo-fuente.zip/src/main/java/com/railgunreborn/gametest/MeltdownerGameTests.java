package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.meltdowner.MdDamage;
import com.railgunreborn.ability.meltdowner.MdMark;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.RadIntensifyRules;
import com.railgunreborn.ability.meltdowner.RadIntensifySkill;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de la categoría Meltdowner y sus piezas compartidas (T42): registro, comando, Rad Intensify. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MeltdownerGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, String name) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static ServerPlayer meltdowner(GameTestHelper helper, String name, int level, boolean radIntensify) {
        ServerPlayer player = player(helper, name);
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(level);
        if (radIntensify) {
            ability.learnSkill(Meltdowner.RAD_INTENSIFY.getId());
        }
        CPData.get(player);
        return player;
    }

    /** Cerdo quieto sobre un bloque de piedra (sin caídas ni sol que lo dañen por su cuenta). */
    private static Pig pig(GameTestHelper helper, int x, int z) {
        helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
        return helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(x + 0.5, 1, z + 0.5));
    }

    /** Ejecuta el comando como el jugador (con permisos de operador); 0 si falla. */
    private static int run(ServerPlayer player, String command) {
        try {
            return player.server.getCommands().getDispatcher().execute(command,
                    player.createCommandSourceStack().withPermission(4).withSuppressedOutput());
        } catch (CommandSyntaxException e) {
            return 0;
        }
    }

    // --- Registro ---

    @GameTest(template = EMPTY)
    public static void meltdownerCategoryIsRegistered(GameTestHelper helper) {
        Category category = AbilityRegistries.category(Meltdowner.ID).orElse(null);
        check(helper, category != null, "meltdowner category should be registered");
        check(helper, category == Meltdowner.CATEGORY.get(), "registry entry should be the holder's");
        check(helper, AbilityRegistries.category(Electromaster.ID).isPresent(), "electromaster must stay registered");
        check(helper, AbilityRegistries.CATEGORY_REGISTRY.size() >= 2,
                "the Developer picks among the categories, found " + AbilityRegistries.CATEGORY_REGISTRY.size());
        check(helper, category.getColor() == Meltdowner.COLOR, "category color");
        check(helper, category.getIcon().getPath().equals("textures/category/meltdowner_icon.png"),
                "icon path " + category.getIcon());

        Skill rad = Meltdowner.RAD_INTENSIFY.get();
        check(helper, rad.getCategoryId().equals(Meltdowner.ID), "rad intensify belongs to meltdowner");
        check(helper, rad.getLevel() == 1 && !rad.canControl(), "rad intensify: level 1, passive");
        check(helper, rad.getGuiX() == 35 && rad.getGuiY() == 75, "rad intensify gui position");
        for (GenericRules.Kind kind : GenericRules.Kind.values()) {
            check(helper, Meltdowner.GENERICS.get(kind).get().getCategoryId().equals(Meltdowner.ID),
                    "generic " + kind + " registered for meltdowner");
        }
        check(helper, category.getSkills().contains(rad) && category.getSkills().size() == 14,
                "meltdowner skills: electron bomb + rad intensify + scatter bomb + light shield + meltdowner + 3 mining rays + ray barrage + jet engine + electron missile + 3 generics, was " + category.getSkills());
        // Niveles 1 a 4 tienen habilidades controlables (Mining Ray experta en el 4): progreso 0 con exp 0.
        for (int level = 1; level <= 4; level++) {
            float threshold = category.levelUpThreshold(level);
            check(helper, threshold >= 0f && !Float.isNaN(threshold), "threshold at level " + level);
            check(helper, category.levelProgressFraction(level, 0f) == 0f,
                    "levels 1-4 have controllable skills");
        }
        check(helper, Float.isInfinite(category.levelUpThreshold(5)), "level 5 cannot level up");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void commandSetsMeltdownerAndLevel(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-md-command");
        check(helper, run(player, "railgunreborn category meltdowner") > 0, "category command should succeed");
        check(helper, run(player, "railgunreborn level 3") > 0, "level command should succeed");
        AbilityData ability = AbilityData.get(player);
        check(helper, ability.getCategory().map(Meltdowner.ID::equals).orElse(false),
                "category should be meltdowner, was " + ability.getCategory());
        check(helper, ability.getLevel() == 3, "level should be 3, was " + ability.getLevel());
        CPData cp = CPData.get(player);
        check(helper, Math.abs(cp.getMaxCP() - CPData.initCp(3)) < EPS, "max CP of level 3, was " + cp.getMaxCP());
        check(helper, run(player, "railgunreborn learn meltdowner/rad_intensify") > 0, "learn rad intensify");
        check(helper, ability.isLearned(Meltdowner.RAD_INTENSIFY.getId()), "rad intensify learned");
        helper.succeed();
    }

    // --- Rad Intensify ---

    @GameTest(template = EMPTY)
    public static void radIntensifyIsLearnableAtLevelOne(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-learn", 1, false);
        // Rad Intensify cuelga de Electron Bomb con exp 0.5.
        AbilityData.get(player).learnSkill(Meltdowner.ELECTRON_BOMB.getId());
        AbilityData.get(player).setSkillExp(Meltdowner.ELECTRON_BOMB.getId(), 0.5f);
        DevelopResult result = Meltdowner.RAD_INTENSIFY.get().checkLearn(AbilityData.get(player),
                DeveloperType.PORTABLE);
        check(helper, result == DevelopResult.OK, "rad intensify should be learnable at level 1, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void radIntensifyExpFollowsMaxCp(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-exp", 1, true);
        RadIntensifySkill rad = Meltdowner.RAD_INTENSIFY.get();
        float expected = CPData.get(player).getMaxCP() / CPData.initCp(5);
        check(helper, Math.abs(rad.getExp(player) - expected) < EPS, "exp at level 1 should be " + expected
                + ", was " + rad.getExp(player));
        AbilityData.get(player).setLevel(5);
        CPData.get(player);
        check(helper, Math.abs(rad.getExp(player) - 1f) < EPS, "exp at level 5 should be 1, was " + rad.getExp(player));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void markedTargetTakesMultipliedDamage(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-mark", 1, true);
        RadIntensifySkill rad = Meltdowner.RAD_INTENSIFY.get();
        Pig marked = pig(helper, 2, 5);
        Pig plain = pig(helper, 6, 5);
        float rate = RadIntensifyRules.rate(rad.getExp(player));

        float before = marked.getHealth();
        check(helper, MdDamage.attack(player, rad, DamageTypes.PLAYER_ATTACK, marked, 2f),
                "the marking hit should land");
        // El golpe que marca no se multiplica (la marca se pone después).
        check(helper, Math.abs(before - marked.getHealth() - 2f) < EPS,
                "first hit is not multiplied, lost " + (before - marked.getHealth()));
        MdMark mark = RadIntensifySkill.activeMark(marked);
        check(helper, mark != null, "the target should be marked");
        check(helper, mark.ticks() == RadIntensifyRules.MARK_TICKS, "mark lasts 60 ticks, was " + mark.ticks());
        check(helper, Math.abs(mark.rate() - rate) < EPS, "mark rate " + mark.rate() + " vs " + rate);

        // Cualquier fuente de daño posterior se multiplica; sobre el cerdo sin marca no.
        marked.invulnerableTime = 0;
        before = marked.getHealth();
        marked.hurt(helper.getLevel().damageSources().generic(), 2f);
        float lossMarked = before - marked.getHealth();
        before = plain.getHealth();
        plain.hurt(helper.getLevel().damageSources().generic(), 2f);
        float lossPlain = before - plain.getHealth();
        check(helper, Math.abs(lossPlain - 2f) < EPS, "unmarked target takes normal damage, lost " + lossPlain);
        check(helper, Math.abs(lossMarked - 2f * rate) < EPS,
                "marked target takes x" + rate + ", lost " + lossMarked);
        check(helper, RadIntensifySkill.activeMark(plain) == null, "the other pig must not be marked");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noMarkWithoutTheSkill(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-nomark", 1, false);
        Pig target = pig(helper, 4, 5);
        check(helper, MdDamage.attack(player, Meltdowner.RAD_INTENSIFY.get(), DamageTypes.PLAYER_ATTACK, target, 2f),
                "the hit should land");
        check(helper, RadIntensifySkill.activeMark(target) == null, "no mark without rad intensify learned");
        target.invulnerableTime = 0;
        float before = target.getHealth();
        target.hurt(helper.getLevel().damageSources().generic(), 2f);
        check(helper, Math.abs(before - target.getHealth() - 2f) < EPS, "damage stays normal");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noMarkWhenMarksIsFalse(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-nomarks", 1, true);
        Pig target = pig(helper, 4, 5);
        MdDamage.attack(player, Meltdowner.RAD_INTENSIFY.get(), DamageTypes.PLAYER_ATTACK, target, 2f, false, false);
        check(helper, RadIntensifySkill.activeMark(target) == null, "marks=false must not mark");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 120)
    public static void markExpiresAfterSixtyTicks(GameTestHelper helper) {
        ServerPlayer player = meltdowner(helper, "test-md-expire", 1, true);
        Pig target = pig(helper, 4, 5);
        MdDamage.attack(player, Meltdowner.RAD_INTENSIFY.get(), DamageTypes.PLAYER_ATTACK, target, 1f);
        check(helper, RadIntensifySkill.activeMark(target) != null, "marked");
        helper.runAfterDelay(RadIntensifyRules.MARK_TICKS - 10, () -> check(helper,
                RadIntensifySkill.activeMark(target) != null, "still marked before 60 ticks"));
        helper.runAfterDelay(RadIntensifyRules.MARK_TICKS + 2, () -> {
            check(helper, RadIntensifySkill.activeMark(target) == null, "mark should expire after 60 ticks");
            target.invulnerableTime = 0;
            float before = target.getHealth();
            target.hurt(helper.getLevel().damageSources().generic(), 2f);
            check(helper, Math.abs(before - target.getHealth() - 2f) < EPS, "no multiplier once expired");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void protectedPlayerIsNeitherHurtNorMarked(GameTestHelper helper) {
        ServerPlayer attacker = meltdowner(helper, "test-md-pvp-a", 1, true);
        ServerPlayer victim = player(helper, "test-md-pvp-b");
        // Mismo equipo sin fuego amigo: canHarmPlayer = false.
        var scoreboard = helper.getLevel().getScoreboard();
        String teamName = "md_pvp_" + UUID.randomUUID().toString().substring(0, 8);
        var team = scoreboard.addPlayerTeam(teamName);
        team.setAllowFriendlyFire(false);
        scoreboard.addPlayerToTeam(attacker.getScoreboardName(), team);
        scoreboard.addPlayerToTeam(victim.getScoreboardName(), team);
        try {
            float before = victim.getHealth();
            boolean hurt = MdDamage.attack(attacker, Meltdowner.RAD_INTENSIFY.get(), DamageTypes.PLAYER_ATTACK,
                    victim, 4f);
            check(helper, !hurt, "a protected player must not be hurt");
            check(helper, victim.getHealth() == before, "health unchanged");
            check(helper, RadIntensifySkill.activeMark(victim) == null, "a protected player must not be marked");
        } finally {
            scoreboard.removePlayerTeam(team);
        }
        helper.succeed();
    }
}
