package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.MineRayRules;
import com.railgunreborn.ability.meltdowner.MineRayRules.Variant;
import com.railgunreborn.ability.meltdowner.MineRaySkill;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de las tres Mining Ray (T47). El jugador siempre mira hacia abajo, a bloques de la propia estructura, y
 * la fila de bloques termina en roca madre para que el rayo nunca salga de la prueba. Todo es síncrono: se pulsa, se
 * mantienen los ticks justos y se suelta dentro de la misma llamada (con {@code mobGriefing} fijado mientras tanto).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MineRayGameTests {
    private static final String EMPTY = "empty";
    private static final String TALL = "tall";
    private static final float EPS = 1e-3f;
    private static final float DOWN = 90f;
    /** Columna central de cada prueba. */
    private static final int CX = 4;
    private static final int CZ = 4;

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        // moveTo no toca la cabeza; la vista (getViewVector) usa la rotación del cuerpo y la cabeza va igual.
        player.moveTo(pos.x, pos.y, pos.z, 0f, DOWN);
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    /** Meltdowner nivel 5 con la habilidad aprendida (exp dada), CP lleno y modo habilidad encendido. */
    private static MineRaySkill setUp(ServerPlayer player, MineRaySkill skill, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(5);
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Pulsa, mantiene {@code ticks} y suelta, con {@code mobGriefing} fijado durante la llamada. */
    private static void mine(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks, boolean griefing) {
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(griefing, helper.getLevel().getServer());
            check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
            hold(player, ticks);
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
    }

    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Columna de {@code block} en y = 1..height sobre roca madre; devuelve dónde se pone el jugador (encima). */
    private static Vec3 column(GameTestHelper helper, Block block, int height) {
        helper.setBlock(new BlockPos(CX, 0, CZ), Blocks.BEDROCK);
        for (int y = 1; y <= height; y++) {
            helper.setBlock(new BlockPos(CX, y, CZ), block);
        }
        return new Vec3(CX + 0.5, height + 1, CZ + 0.5);
    }

    private static int ticks(Variant variant, float exp, Block block) {
        return MineRayRules.ticksToBreak(block.defaultDestroyTime(), MineRayRules.speed(variant, exp));
    }

    private static int countItems(GameTestHelper helper, Item item) {
        AABB box = new AABB(helper.absolutePos(new BlockPos(0, 0, 0))).inflate(9);
        int count = 0;
        for (ItemEntity entity : helper.getLevel().getEntitiesOfClass(ItemEntity.class, box)) {
            if (entity.getItem().is(item)) {
                count += entity.getItem().getCount();
            }
        }
        return count;
    }

    @GameTest(template = EMPTY)
    public static void mineRaysAreRegistered(GameTestHelper helper) {
        record Expected(MineRaySkill skill, Variant variant, int level, Skill parent, float minExp, int x, int y) {
        }
        List<Expected> all = List.of(
                new Expected(Meltdowner.MINE_RAY_BASIC.get(), Variant.BASIC, 3, Meltdowner.MELTDOWNER.get(), 0.3f,
                        140, 70),
                new Expected(Meltdowner.MINE_RAY_EXPERT.get(), Variant.EXPERT, 4, Meltdowner.MINE_RAY_BASIC.get(),
                        0.8f, 172, 70),
                new Expected(Meltdowner.MINE_RAY_LUCK.get(), Variant.LUCK, 5, Meltdowner.MINE_RAY_EXPERT.get(), 1.0f,
                        205, 82));
        for (Expected e : all) {
            Skill s = e.skill();
            String name = e.variant().path;
            check(helper, s.getId().getPath().equals("meltdowner/" + name), "id of " + name + ": " + s.getId());
            check(helper, s.getCategoryId().equals(Meltdowner.ID), name + " belongs to meltdowner");
            check(helper, e.skill().variant() == e.variant(), name + " variant");
            check(helper, s.getLevel() == e.level() && s.canControl(), name + " level " + e.level());
            check(helper, s.getParent().isPresent() && s.getParent().get().skill().equals(e.parent().getId())
                    && Math.abs(s.getParent().get().minExp() - e.minExp()) < EPS, name + " parent");
            check(helper, s.getExtraDependencies().isEmpty(), name + " has no extra dependencies");
            check(helper, s.getGuiX() == e.x() && s.getGuiY() == e.y(), name + " tree position");
            check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.MELTDOWNER.get())
                    < AbilityRegistries.SKILL_REGISTRY.getId(s), name + " registered after meltdowner");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void basicBreaksStoneAndDropsCobblestone(GameTestHelper helper) {
        Vec3 at = column(helper, Blocks.STONE, 2);
        ServerPlayer player = player(helper, "test-mine-stone", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_BASIC.get(), 0f);
        CPData cp = CPData.get(player);
        int needed = ticks(Variant.BASIC, 0f, Blocks.STONE);
        check(helper, needed == 9, "stone with basic e=0 takes 9 ticks, rules say " + needed);

        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(true, helper.getLevel().getServer());
            check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
            check(helper, Math.abs(cp.getOverload() - MineRayRules.initialOverload(Variant.BASIC, 0f)) < EPS,
                    "initial overload " + cp.getOverload());
            hold(player, needed - 1);
            check(helper, helper.getBlockState(new BlockPos(CX, 2, CZ)).is(Blocks.STONE),
                    "one tick early the stone is still there");
            hold(player, 1);
            check(helper, helper.getBlockState(new BlockPos(CX, 2, CZ)).isAir(), "stone broken on time");
            check(helper, helper.getBlockState(new BlockPos(CX, 1, CZ)).is(Blocks.STONE), "only one block");
            check(helper, Math.abs(cp.getOverload() - MineRayRules.initialOverload(Variant.BASIC, 0f)) < 1f,
                    "overload stays put while held: " + cp.getOverload());
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
        check(helper, SkillContexts.active(player).isEmpty(), "release ends the context");
        check(helper, countItems(helper, Items.COBBLESTONE) == 1, "one cobblestone dropped");
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, Math.abs(exp - Variant.BASIC.expPerBlock * skill.getExpIncrSpeed()) < 1e-6f, "exp " + exp);
        int cooldown = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, cooldown == MineRayRules.cooldown(Variant.BASIC, 0f), "cooldown " + cooldown);
        check(helper, cp.getCP() < cp.getMaxCP(), "CP spent");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void basicCannotBreakObsidian(GameTestHelper helper) {
        Vec3 at = column(helper, Blocks.OBSIDIAN, 1);
        ServerPlayer player = player(helper, "test-mine-basic-obs", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_BASIC.get(), 0.5f);
        mine(helper, player, skill, 120, true);
        check(helper, helper.getBlockState(new BlockPos(CX, 1, CZ)).is(Blocks.OBSIDIAN), "obsidian must stay");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0.5f, "no exp gained");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void expertBreaksObsidian(GameTestHelper helper) {
        Vec3 at = column(helper, Blocks.OBSIDIAN, 1);
        ServerPlayer player = player(helper, "test-mine-expert-obs", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_EXPERT.get(), 1f);
        mine(helper, player, skill, ticks(Variant.EXPERT, 1f, Blocks.OBSIDIAN), true);
        check(helper, helper.getBlockState(new BlockPos(CX, 1, CZ)).isAir(), "obsidian broken");
        check(helper, helper.getBlockState(new BlockPos(CX, 0, CZ)).is(Blocks.BEDROCK), "bedrock stays");
        check(helper, countItems(helper, Items.OBSIDIAN) == 1, "obsidian dropped");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void rayGoesThroughGrass(GameTestHelper helper) {
        Vec3 at = column(helper, Blocks.STONE, 1);
        helper.setBlock(new BlockPos(CX, 2, CZ), Blocks.SHORT_GRASS);
        ServerPlayer player = player(helper, "test-mine-grass", at.add(0, 1, 0));
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_EXPERT.get(), 0f);
        mine(helper, player, skill, ticks(Variant.EXPERT, 0f, Blocks.STONE), true);
        check(helper, helper.getBlockState(new BlockPos(CX, 1, CZ)).isAir(), "stone under the grass is mined");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noMobGriefingBreaksNothing(GameTestHelper helper) {
        Vec3 at = column(helper, Blocks.STONE, 2);
        ServerPlayer player = player(helper, "test-mine-nogrief", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_EXPERT.get(), 1f);
        CPData cp = CPData.get(player);
        mine(helper, player, skill, 30, false);
        check(helper, helper.getBlockState(new BlockPos(CX, 2, CZ)).is(Blocks.STONE), "stone must stay");
        check(helper, cp.getCP() < cp.getMaxCP(), "holding the ray still costs CP");
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "cooldown still applies");
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void luckUsesFortuneThree(GameTestHelper helper) {
        ItemStack luckTool = MineRaySkill.tool(helper.getLevel(), Variant.LUCK);
        var enchantments = helper.getLevel().registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        check(helper, EnchantmentHelper.getItemEnchantmentLevel(enchantments.getHolderOrThrow(Enchantments.FORTUNE),
                luckTool) == 3, "luck tool has Fortune III");
        check(helper, EnchantmentHelper.getItemEnchantmentLevel(
                enchantments.getHolderOrThrow(Enchantments.SILK_TOUCH), luckTool) == 0, "and no Silk Touch");
        check(helper, MineRaySkill.tool(helper.getLevel(), Variant.EXPERT).isEmpty(), "expert mines bare-handed");

        int ores = 8;
        Vec3 at = column(helper, Blocks.DIAMOND_ORE, ores);
        ServerPlayer player = player(helper, "test-mine-luck", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_LUCK.get(), 1f);
        mine(helper, player, skill, ores * ticks(Variant.LUCK, 1f, Blocks.DIAMOND_ORE), true);
        for (int y = 1; y <= ores; y++) {
            check(helper, helper.getBlockState(new BlockPos(CX, y, CZ)).isAir(), "ore at y=" + y + " mined");
        }
        int diamonds = countItems(helper, Items.DIAMOND);
        // Con Fortuna III cada mineral da 1-4 (media 2.2); 8 minerales a 1 cada uno tiene un 0.07 % de probabilidad.
        check(helper, diamonds > ores, "Fortune III should give more than " + ores + " diamonds, got " + diamonds);
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void miningOresDropsExperience(GameTestHelper helper) {
        int ores = 8;
        Vec3 at = column(helper, Blocks.COAL_ORE, ores);
        ServerPlayer player = player(helper, "test-mine-xp", at);
        MineRaySkill skill = setUp(player, Meltdowner.MINE_RAY_EXPERT.get(), 1f);
        mine(helper, player, skill, ores * ticks(Variant.EXPERT, 1f, Blocks.COAL_ORE), true);
        check(helper, helper.getBlockState(new BlockPos(CX, 1, CZ)).isAir(), "all coal mined");
        check(helper, countItems(helper, Items.COAL) >= ores, "coal dropped");
        AABB box = new AABB(helper.absolutePos(new BlockPos(0, 0, 0))).inflate(12);
        // El carbón suelta 0-2 de XP por bloque: con 8 bloques que no salga ninguno es un 0.015 %.
        check(helper, !helper.getLevel().getEntitiesOfClass(ExperienceOrb.class, box).isEmpty(),
                "experience orbs should drop");
        helper.succeed();
    }
}
