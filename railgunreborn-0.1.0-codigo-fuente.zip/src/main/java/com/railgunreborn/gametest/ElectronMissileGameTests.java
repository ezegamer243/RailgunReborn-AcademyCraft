package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.ElectronMissileRules;
import com.railgunreborn.ability.meltdowner.ElectronMissileSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Electron Missile (T51). Jugador falso mirando hacia +Z desde (4.5, 1, 1.5); exp 0 = alcance 5. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ElectronMissileGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-4f;

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-electron-missile"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 5 con Electron Missile aprendida (con la exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(5);
        Skill skill = Meltdowner.ELECTRON_MISSILE.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Ticks de servidor con el cliente vivo (keep-alive), como mantener la tecla. */
    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static int balls(ServerPlayer player) {
        for (var ctx : SkillContexts.active(player).snapshot()) {
            if (ctx instanceof ElectronMissileSkill.ElectronMissileContext missile) {
                return missile.ballCount();
            }
        }
        return -1;
    }

    private static void release(ServerPlayer player) {
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void electronMissileIsRegisteredAtLevel5UnderJetEngine(GameTestHelper helper) {
        Skill skill = Meltdowner.ELECTRON_MISSILE.get();
        check(helper, skill.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, skill.getLevel() == 5 && skill.canControl(), "level 5, controllable");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Meltdowner.skillId("jet_engine"))
                && Math.abs(skill.getParent().get().minExp() - 0.3f) < EPS, "parent: jet engine (0.3)");
        check(helper, skill.getGuiX() == 210 && skill.getGuiY() == 35, "tree position should be 210, 35");
        check(helper, AbilityRegistries.SKILL_REGISTRY.containsKey(skill.getId()), "present in the skill registry");
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.MINE_RAY_LUCK.get())
                < AbilityRegistries.SKILL_REGISTRY.getId(skill), "registered after mining ray (luck)");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ballsAppearAndTheClosestMobIsHit(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        // Cerca: 2.5 bloques; lejos pero dentro del alcance 5: ~4.6 bloques.
        IronGolem near = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.0));
        IronGolem far = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(1.0, 1, 4.5));
        float nearBefore = near.getHealth();
        float farBefore = far.getHealth();
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, Math.abs(cp.getOverload() - ElectronMissileRules.OVERLOAD_START) < EPS,
                "initial overload " + cp.getOverload());
        hold(player, 1);
        check(helper, balls(player) == 1, "first ball at tick 0, had " + balls(player));
        hold(player, 7);
        check(helper, near.getHealth() == nearBefore, "no attack before tick 8");
        hold(player, 1);
        float damage = ElectronMissileRules.damage(0f);
        check(helper, Math.abs(near.getHealth() - (nearBefore - damage)) < 0.01f,
                "the closest mob takes " + damage + ": " + nearBefore + " -> " + near.getHealth());
        check(helper, far.getHealth() == farBefore, "the farther mob is not hit");
        check(helper, balls(player) == 0, "the ball is spent, had " + balls(player));
        float expectedCp = cpBefore - 9 * ElectronMissileRules.cpPerTick(0f) - ElectronMissileRules.cpPerAttack(0f);
        check(helper, Math.abs(cp.getCP() - expectedCp) < 0.01f, "CP " + cp.getCP() + " expected " + expectedCp);
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, Math.abs(exp - ElectronMissileRules.EXP_PER_ATTACK) < 1e-6f, "exp per attack, had " + exp);

        // Tick 10: otra bola; tick 16: el golpe entra aunque acabe de recibir daño.
        hold(player, 8);
        check(helper, Math.abs(near.getHealth() - (nearBefore - 2 * damage)) < 0.01f,
                "second hit ignores invulnerability, health " + near.getHealth());
        release(player);
        check(helper, SkillContexts.active(player).isEmpty(), "release ends the context");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ownWolfAndArmorStandAreNotAttacked(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        Wolf wolf = helper.spawnWithNoFreeWill(EntityType.WOLF, new Vec3(2.5, 1, 2.5));
        wolf.tame(player);
        ArmorStand stand = helper.spawn(EntityType.ARMOR_STAND, new Vec3(6.5, 1, 3.5));
        float wolfBefore = wolf.getHealth();
        float standBefore = stand.getHealth();
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 51);
        check(helper, wolf.getHealth() == wolfBefore && wolf.isAlive(), "own wolf is not attacked");
        check(helper, stand.getHealth() == standBefore && stand.isAlive(), "armor stand is not attacked");
        check(helper, balls(player) == ElectronMissileRules.MAX_BALLS, "5 balls max, had " + balls(player));
        float expectedCp = cpBefore - 51 * ElectronMissileRules.cpPerTick(0f);
        check(helper, Math.abs(cp.getCP() - expectedCp) < 0.01f, "no attack cost, CP " + cp.getCP());
        release(player);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void cooldownDependsOnExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 1);
        release(player);
        int remaining = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, remaining == 700, "cooldown at exp 0 should be 700, was " + remaining);

        CooldownData.get(player).clear();
        AbilityData.get(player).setSkillExp(skill.getId(), 1f);
        CPData.get(player).recoverAll();
        check(helper, SkillContexts.start(player, 2, skill) == StartResult.OK, "second start should be accepted");
        release(player, 2);
        remaining = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, remaining == 400, "cooldown at exp 1 should be 400, was " + remaining);
        helper.succeed();
    }

    private static void release(ServerPlayer player, int contextId) {
        SkillContexts.handleAction(player, contextId, SkillContextActionPayload.Action.KEY_UP);
    }
}
