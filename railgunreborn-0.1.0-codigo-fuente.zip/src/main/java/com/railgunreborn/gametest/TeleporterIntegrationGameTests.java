package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.registry.ModBlocks;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de integración de Teleporter (T64): recorrer el árbol completo con un Developer avanzado real, y reglas
 * comunes a todas las habilidades (modo habilidad, presets, pasivas y genéricas sin tecla).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class TeleporterIntegrationGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-tp-integration"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        face(player, 0f);
        return player;
    }

    /** moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa. */
    private static void face(ServerPlayer player, float yaw) {
        player.setYRot(yaw);
        player.setYHeadRot(yaw);
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Las siete habilidades activas de Teleporter (todas menos las pasivas Dim Folding y Space Fluctuation). */
    private static List<Skill> controllable() {
        return List.of(Teleporter.THREATENING_TELEPORT.get(), Teleporter.PENETRATE_TELEPORT.get(),
                Teleporter.MARK_TELEPORT.get(), Teleporter.FLESH_RIPPING.get(), Teleporter.LOCATION_TELEPORT.get(),
                Teleporter.SHIFT_TP.get(), Teleporter.FLASHING.get());
    }

    private static void learn(GameTestHelper helper, ServerPlayer player, DeveloperMenu menu, Skill skill,
            DeveloperType type) {
        DevelopResult started = menu.start(player, DevelopAction.learn(skill));
        check(helper, started == DevelopResult.OK, skill + " should start learning, was " + started);
        for (int i = 0, n = DevelopRules.totalTicks(skill.getLearningStims(), type); i < n; i++) {
            menu.serverTick(player);
        }
        check(helper, menu.getResult() == DevelopResult.OK, skill + " should finish OK, was " + menu.getResult());
        check(helper, AbilityData.get(player).isLearned(skill.getId()), skill + " should be learned");
    }

    private static void refused(GameTestHelper helper, ServerPlayer player, DeveloperMenu menu, Skill skill,
            DevelopResult expected) {
        DevelopResult result = menu.start(player, DevelopAction.learn(skill));
        check(helper, result == expected, skill + " must be refused with " + expected + ", was " + result);
    }

    @GameTest(template = EMPTY, timeoutTicks = 800)
    public static void wholeTreeLearnedInOrderWithAdvancedDeveloper(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(5);
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_ADVANCED.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperEnergyTesting.fill(helper.getLevel(), block);
        DeveloperType type = DeveloperType.ADVANCED;
        DeveloperMenu menu = DeveloperMenu.open(player, type, block);
        check(helper, menu != null, "advanced developer should open");

        Skill threatening = Teleporter.THREATENING_TELEPORT.get();
        Skill dimFolding = Teleporter.DIM_FOLDING.get();
        Skill penetrate = Teleporter.PENETRATE_TELEPORT.get();
        Skill mark = Teleporter.MARK_TELEPORT.get();
        Skill flesh = Teleporter.FLESH_RIPPING.get();
        Skill location = Teleporter.LOCATION_TELEPORT.get();
        Skill shift = Teleporter.SHIFT_TP.get();
        Skill spaceFluct = Teleporter.SPACE_FLUCT.get();
        Skill flashing = Teleporter.FLASHING.get();

        // Todo cuelga de Threatening Teleport.
        for (Skill s : List.of(dimFolding, penetrate, mark, flesh, location, shift, spaceFluct, flashing)) {
            DevelopResult early = s.checkLearn(data, type);
            check(helper, early == DevelopResult.PARENT_NOT_MET, s + " needs its parent, was " + early);
        }

        learn(helper, player, menu, threatening, type);
        data.setSkillExp(threatening.getId(), 0.1f);
        refused(helper, player, menu, dimFolding, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(threatening.getId(), 0.2f);
        learn(helper, player, menu, dimFolding, type);
        data.setSkillExp(threatening.getId(), 0.4f);
        refused(helper, player, menu, penetrate, DevelopResult.PARENT_NOT_MET);
        learn(helper, player, menu, mark, type);
        data.setSkillExp(threatening.getId(), 0.5f);
        learn(helper, player, menu, penetrate, type);

        // Flesh Ripping: padre Mark al 50 % y dependencia Penetrate al 50 %.
        refused(helper, player, menu, flesh, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(mark.getId(), 0.5f);
        refused(helper, player, menu, flesh, DevelopResult.DEPENDENCY_NOT_MET);
        data.setSkillExp(penetrate.getId(), 0.5f);
        learn(helper, player, menu, flesh, type);

        // Location Teleport: padre Penetrate al 80 % y dependencia Mark al 80 %.
        refused(helper, player, menu, location, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(penetrate.getId(), 0.8f);
        refused(helper, player, menu, location, DevelopResult.DEPENDENCY_NOT_MET);
        data.setSkillExp(mark.getId(), 0.8f);
        learn(helper, player, menu, location, type);

        // Shift Teleport cuelga de Location al 50 %; Space Fluctuation y Flashing, de Shift.
        refused(helper, player, menu, shift, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(location.getId(), 0.5f);
        learn(helper, player, menu, shift, type);
        learn(helper, player, menu, spaceFluct, type);
        refused(helper, player, menu, flashing, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(shift.getId(), 0.8f);
        learn(helper, player, menu, flashing, type);

        check(helper, data.getLearnedSkills().size() == 9, "nine skills learned, was " + data.getLearnedSkills());
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noSkillStartsWithAbilityModeOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(5);
        for (Skill s : controllable()) {
            data.learnSkill(s.getId());
        }
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, false);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.MODE_OFF, s + " must need ability mode, was " + result);
        }
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.OK, s + " should start with mode on, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void unlearnedSkillsAreRefusedEvenWithModeOn(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.NOT_LEARNED, s + " must be refused if not learned, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void passivesAndGenericsHaveNoKeyAndCannotBeInPresets(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        List<Skill> noKey = new ArrayList<>();
        noKey.add(Teleporter.DIM_FOLDING.get());
        noKey.add(Teleporter.SPACE_FLUCT.get());
        Teleporter.GENERICS.values().forEach(holder -> noKey.add(holder.get()));
        for (Skill s : noKey) {
            data.learnSkill(s.getId());
            StartResult start = SkillContexts.validateStart(player, s);
            check(helper, start == StartResult.NOT_CONTROLLABLE, s + " has no key, was " + start);
            PresetRules.Result edit = PresetRules.applyEdit(player, 0, 0, s.getId());
            check(helper, edit == PresetRules.Result.NOT_CONTROLLABLE, s + " not allowed in presets, was " + edit);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void everyTeleporterActiveSkillFitsInPresetsWithoutDuplicates(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(5);
        List<Skill> skills = controllable();
        for (Skill s : skills) {
            data.learnSkill(s.getId());
        }
        data.learnSkill(Teleporter.DIM_FOLDING.get().getId());
        data.learnSkill(Teleporter.SPACE_FLUCT.get().getId());
        for (int i = 0; i < skills.size(); i++) {
            ResourceLocation id = skills.get(i).getId();
            PresetRules.Result result = PresetRules.applyEdit(player, i / 4, i % 4, id);
            check(helper, result == PresetRules.Result.OK, id + " should fit in a preset, was " + result);
        }
        PresetRules.Result dup = PresetRules.applyEdit(player, 0, 3, skills.get(0).getId());
        check(helper, dup == PresetRules.Result.DUPLICATE, "duplicate in a preset must be refused, was " + dup);
        helper.succeed();
    }
}
