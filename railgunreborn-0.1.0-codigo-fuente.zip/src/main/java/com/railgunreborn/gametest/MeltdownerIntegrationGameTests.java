package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.registry.ModBlocks;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de integración de Meltdowner (T52): recorrer el árbol completo con un Developer avanzado real, y reglas
 * comunes a todas las habilidades (modo habilidad, presets, pasivas y genéricas sin tecla).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MeltdownerIntegrationGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-md-integration"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        face(player, 0f);
        return player;
    }

    /** moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa. */
    private static void face(ServerPlayer player, float yaw) {
        player.setYRot(yaw);
        player.setYHeadRot(yaw);
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Las diez habilidades de Meltdowner con tecla (todas menos la pasiva Rad Intensify). */
    private static List<Skill> controllable() {
        return List.of(Meltdowner.ELECTRON_BOMB.get(), Meltdowner.SCATTER_BOMB.get(), Meltdowner.LIGHT_SHIELD.get(),
                Meltdowner.MELTDOWNER.get(), Meltdowner.MINE_RAY_BASIC.get(), Meltdowner.RAY_BARRAGE.get(),
                Meltdowner.JET_ENGINE.get(), Meltdowner.MINE_RAY_EXPERT.get(), Meltdowner.MINE_RAY_LUCK.get(),
                Meltdowner.ELECTRON_MISSILE.get());
    }

    private static void learn(GameTestHelper helper, ServerPlayer player, DeveloperMenu menu, Skill skill,
            DeveloperType type) {
        DevelopResult started = menu.start(player, DevelopAction.learn(skill));
        check(helper, started == DevelopResult.OK, skill + " should start learning, was " + started);
        for (int i = 0, n = DevelopRules.totalTicks(skill.getLearningStims(), type); i < n; i++) {
            menu.serverTick(player);
        }
        check(helper, menu.getResult() == DevelopResult.OK, skill + " should finish OK, was " + menu.getResult());
        check(helper, AbilityData.get(player).isLearned(skill.getId()), skill + " should be learned");
    }

    private static void refused(GameTestHelper helper, ServerPlayer player, DeveloperMenu menu, Skill skill,
            DevelopResult expected) {
        DevelopResult result = menu.start(player, DevelopAction.learn(skill));
        check(helper, result == expected, skill + " must be refused with " + expected + ", was " + result);
    }

    @GameTest(template = EMPTY, timeoutTicks = 800)
    public static void wholeTreeLearnedInOrderWithAdvancedDeveloper(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Meltdowner.ID);
        data.setLevel(5);
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_ADVANCED.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperEnergyTesting.fill(helper.getLevel(), block);
        DeveloperType type = DeveloperType.ADVANCED;
        DeveloperMenu menu = DeveloperMenu.open(player, type, block);
        check(helper, menu != null, "advanced developer should open");

        Skill electronBomb = Meltdowner.ELECTRON_BOMB.get();
        Skill radIntensify = Meltdowner.RAD_INTENSIFY.get();
        Skill scatterBomb = Meltdowner.SCATTER_BOMB.get();
        Skill lightShield = Meltdowner.LIGHT_SHIELD.get();
        Skill meltdowner = Meltdowner.MELTDOWNER.get();
        Skill mineBasic = Meltdowner.MINE_RAY_BASIC.get();
        Skill rayBarrage = Meltdowner.RAY_BARRAGE.get();
        Skill jetEngine = Meltdowner.JET_ENGINE.get();
        Skill mineExpert = Meltdowner.MINE_RAY_EXPERT.get();
        Skill mineLuck = Meltdowner.MINE_RAY_LUCK.get();
        Skill electronMissile = Meltdowner.ELECTRON_MISSILE.get();

        // Sin la raíz no se aprende nada de las ramas.
        for (Skill s : List.of(radIntensify, scatterBomb, lightShield, meltdowner, mineBasic, rayBarrage, jetEngine,
                mineExpert, mineLuck, electronMissile)) {
            DevelopResult early = s.checkLearn(data, type);
            check(helper, early == DevelopResult.PARENT_NOT_MET, s + " needs its parent, was " + early);
        }

        learn(helper, player, menu, electronBomb, type);
        // Rad Intensify pide Electron Bomb al 50 %, Scatter Bomb al 80 % y Light Shield al 100 %.
        data.setSkillExp(electronBomb.getId(), 0.4f);
        refused(helper, player, menu, radIntensify, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(electronBomb.getId(), 0.5f);
        learn(helper, player, menu, radIntensify, type);
        refused(helper, player, menu, scatterBomb, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(electronBomb.getId(), 0.8f);
        learn(helper, player, menu, scatterBomb, type);
        refused(helper, player, menu, lightShield, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(electronBomb.getId(), 1.0f);
        learn(helper, player, menu, lightShield, type);

        // Meltdowner: padre Scatter Bomb al 80 % y dependencia Light Shield al 80 %.
        refused(helper, player, menu, meltdowner, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(scatterBomb.getId(), 0.8f);
        refused(helper, player, menu, meltdowner, DevelopResult.DEPENDENCY_NOT_MET);
        data.setSkillExp(lightShield.getId(), 0.8f);
        learn(helper, player, menu, meltdowner, type);

        // Las tres ramas de Meltdowner piden su exp mínima.
        refused(helper, player, menu, mineBasic, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(meltdowner.getId(), 0.3f);
        learn(helper, player, menu, mineBasic, type);
        refused(helper, player, menu, rayBarrage, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(meltdowner.getId(), 0.5f);
        learn(helper, player, menu, rayBarrage, type);
        refused(helper, player, menu, jetEngine, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(meltdowner.getId(), 1.0f);
        learn(helper, player, menu, jetEngine, type);

        // Mine Ray: básica, experta, suerte; cada una con su padre.
        refused(helper, player, menu, mineExpert, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(mineBasic.getId(), 0.8f);
        learn(helper, player, menu, mineExpert, type);
        refused(helper, player, menu, mineLuck, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(mineExpert.getId(), 1.0f);
        learn(helper, player, menu, mineLuck, type);

        // Electron Missile cuelga de Jet Engine al 30 %.
        refused(helper, player, menu, electronMissile, DevelopResult.PARENT_NOT_MET);
        data.setSkillExp(jetEngine.getId(), 0.3f);
        learn(helper, player, menu, electronMissile, type);

        check(helper, data.getLearnedSkills().size() == 11, "eleven skills learned, was " + data.getLearnedSkills());
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noSkillStartsWithAbilityModeOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Meltdowner.ID);
        data.setLevel(5);
        for (Skill s : controllable()) {
            data.learnSkill(s.getId());
        }
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, false);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.MODE_OFF, s + " must need ability mode, was " + result);
        }
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.OK, s + " should start with mode on, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void unlearnedSkillsAreRefusedEvenWithModeOn(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Meltdowner.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.NOT_LEARNED, s + " must be refused if not learned, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void passiveAndGenericsHaveNoKeyAndCannotBeInPresets(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Meltdowner.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        List<Skill> noKey = new ArrayList<>();
        noKey.add(Meltdowner.RAD_INTENSIFY.get());
        Meltdowner.GENERICS.values().forEach(holder -> noKey.add(holder.get()));
        for (Skill s : noKey) {
            data.learnSkill(s.getId());
            StartResult start = SkillContexts.validateStart(player, s);
            check(helper, start == StartResult.NOT_CONTROLLABLE, s + " has no key, was " + start);
            PresetRules.Result edit = PresetRules.applyEdit(player, 0, 0, s.getId());
            check(helper, edit == PresetRules.Result.NOT_CONTROLLABLE, s + " not allowed in presets, was " + edit);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void everyMeltdownerActiveSkillFitsInPresetsWithoutDuplicates(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Meltdowner.ID);
        data.setLevel(5);
        List<Skill> skills = controllable();
        for (Skill s : skills) {
            data.learnSkill(s.getId());
        }
        data.learnSkill(Meltdowner.RAD_INTENSIFY.get().getId());
        for (int i = 0; i < skills.size(); i++) {
            ResourceLocation id = skills.get(i).getId();
            PresetRules.Result result = PresetRules.applyEdit(player, i / 4, i % 4, id);
            check(helper, result == PresetRules.Result.OK, id + " should fit in a preset, was " + result);
        }
        // La misma habilidad dos veces en el mismo preset se rechaza.
        PresetRules.Result dup = PresetRules.applyEdit(player, 0, 3, skills.get(0).getId());
        check(helper, dup == PresetRules.Result.DUPLICATE, "duplicate in a preset must be refused, was " + dup);
        helper.succeed();
    }
}
