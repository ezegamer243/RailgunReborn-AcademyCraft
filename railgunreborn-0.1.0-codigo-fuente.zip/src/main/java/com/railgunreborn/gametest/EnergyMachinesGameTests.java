package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.ImagFusorBlock;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.metalformer.MetalFormerBlock;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerMode;
import com.railgunreborn.metalformer.MetalFormerRecipes;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.AfterBatch;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.SimpleContainerData;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de la energía del Imag Fusor y el Metal Former (T98). Los de {@code energyRequired = false} van en un lote
 * propio ({@link #FREE_BATCH}): el override de {@link RailgunConfig} es global y los lotes corren uno tras otro.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class EnergyMachinesGameTests {
    private static final String EMPTY = "empty";
    private static final String FREE_BATCH = "energyFree";
    private static final BlockPos POS = new BlockPos(1, 2, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    @AfterBatch(batch = FREE_BATCH)
    public static void restoreConfig(ServerLevel level) {
        RailgunConfig.setEnergyRequiredOverrideForTests(null);
    }

    private static ImagFusorBlockEntity fusor(GameTestHelper helper, int energy) {
        helper.setBlock(POS, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof ImagFusorBlockEntity be)) {
            throw new IllegalStateException("imag fusor block entity missing");
        }
        be.getEnergy().setEnergy(energy);
        return be;
    }

    private static void loadFusor(ImagFusorBlockEntity be) {
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CRYSTAL_LOW.get()));
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN,
                new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get(), 3));
    }

    private static MetalFormerBlockEntity former(GameTestHelper helper, int energy) {
        helper.setBlock(POS, MetalFormerRegistry.METAL_FORMER.get().defaultBlockState());
        if (!(helper.getBlockEntity(POS) instanceof MetalFormerBlockEntity be)) {
            throw new IllegalStateException("metal former block entity missing");
        }
        be.setMode(MetalFormerMode.PLATE);
        be.getEnergy().setEnergy(energy);
        return be;
    }

    private static void loadFormer(MetalFormerBlockEntity be) {
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CONSTRAINT_INGOT.get()));
    }

    // --- Imag Fusor ---

    /** Una receta completa gasta 12 IF x 120 ticks = 1440 IF del buffer de 2000. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void fusorSpendsRecipeEnergy(GameTestHelper helper) {
        ImagFusorBlockEntity be = fusor(helper, ImagFusorBlockEntity.ENERGY_CAPACITY);
        loadFusor(be);
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CRYSTAL_NORMAL.get()), "no crystal yet");
            helper.assertTrue(be.getEnergy().getEnergyStored() == 2000 - 1440,
                    "expected 560 IF left, has " + be.getEnergy().getEnergyStored());
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void fusorWithoutEnergyDoesNothing(GameTestHelper helper) {
        ImagFusorBlockEntity be = fusor(helper, 0);
        loadFusor(be);
        helper.runAtTickTime(150, () -> {
            check(helper, be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT).isEmpty(), "crafted without energy");
            check(helper, be.getData().get(ImagFusorBlockEntity.DATA_PROGRESS) == 0, "progress without energy");
            check(helper, !helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "working without energy");
            check(helper, be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_INPUT).getCount() == 1, "input consumed");
            helper.succeed();
        });
    }

    /** Energía para 30 ticks de 120: el progreso se pierde, la luz se apaga, y con energía nueva se empieza de cero. */
    @GameTest(template = EMPTY, timeoutTicks = 500)
    public static void fusorLosesProgressWhenEnergyRunsOut(GameTestHelper helper) {
        ImagFusorBlockEntity be = fusor(helper, 12 * 30);
        loadFusor(be);
        helper.runAtTickTime(20, () -> {
            check(helper, be.getData().get(ImagFusorBlockEntity.DATA_PROGRESS) > 10, "should be progressing");
            check(helper, helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "should be working");
        });
        helper.runAtTickTime(60, () -> {
            check(helper, be.getData().get(ImagFusorBlockEntity.DATA_PROGRESS) == 0, "progress must reset to 0");
            check(helper, !helper.getBlockState(POS).getValue(ImagFusorBlock.WORKING), "light should be off");
            check(helper, be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT).isEmpty(), "crafted too early");
            be.getEnergy().setEnergy(ImagFusorBlockEntity.ENERGY_CAPACITY);
        });
        helper.runAtTickTime(100, () -> check(helper, be.getData().get(ImagFusorBlockEntity.DATA_PROGRESS) <= 45,
                "after recharging the recipe restarts from 0"));
        helper.succeedWhen(() -> {
            helper.assertTrue(helper.getTick() >= 61 + 120, "finished without restarting");
            helper.assertTrue(be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CRYSTAL_NORMAL.get()), "no crystal yet");
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 300, batch = FREE_BATCH)
    public static void fusorIsFreeWhenEnergyNotRequired(GameTestHelper helper) {
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        ImagFusorBlockEntity be = fusor(helper, 0);
        loadFusor(be);
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CRYSTAL_NORMAL.get()), "no crystal yet");
            helper.assertTrue(be.getEnergy().getEnergyStored() == 0, "should not have spent anything");
        });
    }

    // --- Metal Former ---

    /** Una operación gasta exactamente la energía de la receta (800), repartida en los 60 ticks. */
    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void formerSpendsRecipeEnergy(GameTestHelper helper) {
        MetalFormerBlockEntity be = former(helper, MetalFormerBlockEntity.ENERGY_CAPACITY);
        loadFormer(be);
        int total = MetalFormerRecipes.find(helper.getLevel(), MetalFormerMode.PLATE,
                new ItemStack(ModItems.CONSTRAINT_INGOT.get())).orElseThrow().energy();
        check(helper, total == 800, "constraint plate recipe should cost 800, got " + total);
        helper.runAtTickTime(30, () -> {
            int spent = MetalFormerBlockEntity.ENERGY_CAPACITY - be.getEnergy().getEnergyStored();
            check(helper, spent >= 13 * 29 && spent <= 14 * 31, "about 13.3 IF per tick, spent " + spent + " in 30 ticks");
        });
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CONSTRAINT_PLATE.get()), "no plate yet");
            helper.assertTrue(be.getEnergy().getEnergyStored() == MetalFormerBlockEntity.ENERGY_CAPACITY - 800,
                    "expected exactly 800 spent, left " + be.getEnergy().getEnergyStored());
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void formerWithoutEnergyDoesNothing(GameTestHelper helper) {
        MetalFormerBlockEntity be = former(helper, 0);
        loadFormer(be);
        helper.runAtTickTime(100, () -> {
            check(helper, be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT).isEmpty(), "crafted without energy");
            check(helper, be.getProgress() == 0, "progress without energy");
            check(helper, !helper.getBlockState(POS).getValue(MetalFormerBlock.WORKING), "working without energy");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void formerLosesProgressWhenEnergyRunsOut(GameTestHelper helper) {
        MetalFormerBlockEntity be = former(helper, 400);
        loadFormer(be);
        helper.runAtTickTime(20, () -> {
            check(helper, be.getProgress() > 10, "should be progressing");
            check(helper, helper.getBlockState(POS).getValue(MetalFormerBlock.WORKING), "should be working");
        });
        helper.runAtTickTime(60, () -> {
            check(helper, be.getProgress() == 0, "progress must reset to 0");
            check(helper, !helper.getBlockState(POS).getValue(MetalFormerBlock.WORKING), "light should be off");
            check(helper, be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT).isEmpty(), "crafted with 400 IF");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200, batch = FREE_BATCH)
    public static void formerIsFreeWhenEnergyNotRequired(GameTestHelper helper) {
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        MetalFormerBlockEntity be = former(helper, 0);
        loadFormer(be);
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CONSTRAINT_PLATE.get()), "no plate yet");
            helper.assertTrue(be.getEnergy().getEnergyStored() == 0, "should not have spent anything");
        });
    }

    @GameTest(template = EMPTY)
    public static void fractionalEnergyAddsUpExactly(GameTestHelper helper) {
        for (int[] c : new int[][] { { 800, 60 }, { 1440, 120 }, { 1, 60 }, { 61, 60 }, { 0, 60 } }) {
            int sum = 0;
            for (int t = 0; t < c[1]; t++) {
                int e = MetalFormerBlockEntity.energyForTick(c[0], c[1], t);
                check(helper, e >= c[0] / c[1] && e <= c[0] / c[1] + 1, "tick cost out of range: " + e);
                sum += e;
            }
            check(helper, sum == c[0], "E=" + c[0] + " T=" + c[1] + " summed " + sum);
        }
        helper.succeed();
    }

    // --- Batería, capacidad FE y datos ---

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void batterySlotChargesFusorBuffer(GameTestHelper helper) {
        ImagFusorBlockEntity be = fusor(helper, 0);
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_BATTERY,
                EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT.get()), 1500));
        helper.runAtTickTime(2, () -> check(helper, be.getEnergy().getEnergyStored() > 0, "should start charging"));
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getEnergy().getEnergyStored() == 1500, "buffer has " + be.getEnergy().getEnergyStored());
            IEnergyStorage item = be.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_BATTERY)
                    .getCapability(Capabilities.EnergyStorage.ITEM);
            helper.assertTrue(item != null && item.getEnergyStored() == 0, "the unit should be empty");
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void batterySlotChargesFormerBuffer(GameTestHelper helper) {
        MetalFormerBlockEntity be = former(helper, 0);
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_BATTERY,
                EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT.get()), 2000));
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getEnergy().getEnergyStored() == 2000, "buffer has " + be.getEnergy().getEnergyStored());
            IEnergyStorage item = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_BATTERY)
                    .getCapability(Capabilities.EnergyStorage.ITEM);
            helper.assertTrue(item != null && item.getEnergyStored() == 0, "the unit should be empty");
        });
    }

    /** Un "cable" (llamada a la capacidad FE) puede meter energía por cualquiera de las 6 caras y por la de null. */
    @GameTest(template = EMPTY)
    public static void cablesFeedBothMachinesFromAnySide(GameTestHelper helper) {
        BlockPos second = POS.below();
        helper.setBlock(second, MetalFormerRegistry.METAL_FORMER.get().defaultBlockState());
        ImagFusorBlockEntity fusor = fusor(helper, 0);
        MetalFormerBlockEntity former = (MetalFormerBlockEntity) helper.getBlockEntity(second);
        former.getEnergy().setEnergy(0);
        Direction[] sides = { Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST,
                Direction.WEST, null };
        for (Direction side : sides) {
            for (BlockPos pos : new BlockPos[] { POS, second }) {
                IEnergyStorage cap = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK,
                        helper.absolutePos(pos), side);
                check(helper, cap != null, "no FE capability at " + pos + " side " + side);
                check(helper, cap.canReceive() && !cap.canExtract(), "should only receive, side " + side);
                check(helper, cap.receiveEnergy(30, false) == 30, "should accept 30 IF, side " + side);
                check(helper, cap.receiveEnergy(1000, true) == 50, "per-call limit is 50 IF, side " + side);
            }
        }
        check(helper, fusor.getEnergy().getEnergyStored() == 30 * sides.length, "fusor energy "
                + fusor.getEnergy().getEnergyStored());
        check(helper, former.getEnergy().getEnergyStored() == 30 * sides.length, "former energy "
                + former.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void energyIsSavedAndSynced(GameTestHelper helper) {
        ImagFusorBlockEntity be = fusor(helper, 1234);
        var registries = helper.getLevel().registryAccess();
        var tag = be.saveWithoutMetadata(registries);
        ImagFusorBlockEntity copy = new ImagFusorBlockEntity(be.getBlockPos(), be.getBlockState());
        copy.loadWithComponents(tag, registries);
        check(helper, copy.getEnergy().getEnergyStored() == 1234, "fusor energy not saved");
        MetalFormerBlockEntity mf = former(helper, 2999);
        var mfTag = mf.saveWithoutMetadata(registries);
        MetalFormerBlockEntity mfCopy = new MetalFormerBlockEntity(mf.getBlockPos(), mf.getBlockState());
        mfCopy.loadWithComponents(mfTag, registries);
        check(helper, mfCopy.getEnergy().getEnergyStored() == 2999, "former energy not saved");
        // ContainerData: dos mitades, también por encima de 32767 y sobreviviendo al corte a short de la red.
        for (int value : new int[] { 0, 1, 32767, 32768, 65535, 65536, 200_000, 500_000, Integer.MAX_VALUE }) {
            SimpleContainerData client = new SimpleContainerData(2);
            client.set(0, (short) ContainerDataInts.low(value));
            client.set(1, (short) ContainerDataInts.high(value));
            check(helper, ContainerDataInts.get(client, 0) == value, "round trip failed for " + value);
        }
        check(helper, ContainerDataInts.get(new SimpleContainerData(2), 0) == 0, "empty data is 0");
        check(helper, ContainerDataInts.get(be.getData(), ImagFusorBlockEntity.DATA_ENERGY) == 1234,
                "fusor data energy");
        check(helper, ContainerDataInts.get(mf.getData(), MetalFormerBlockEntity.DATA_ENERGY) == 2999,
                "former data energy");
        helper.succeed();
    }
}
