package com.railgunreborn.gametest;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.MatrixBlockEntity;
import com.railgunreborn.wireless.MatrixMenu;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.NodeLinkMenu;
import com.railgunreborn.wireless.NodeMenu;
import com.railgunreborn.wireless.WirelessActions.Action;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessData;
import com.railgunreborn.wireless.WirelessLinking;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessRegistry;
import com.railgunreborn.wireless.WirelessResult;
import com.railgunreborn.wireless.WirelessView;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de las pantallas inalámbricas (T104), solo servidor: se llama al manejador de las acciones
 * ({@link WirelessActions#handle(Player, WirelessActionPayload, WirelessData)}) con jugadores falsos (dueño, otro,
 * operador, lejano) y un {@link WirelessData} propio; más las recetas de la red y de los Developers.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class WirelessUiGameTests {
    private static final String EMPTY = "empty";
    private static final String LONG = "x".repeat(33);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    /** Jugador falso en {@code rel} (centro del bloque); {@code op} = nivel de permisos 4. */
    private static Player player(GameTestHelper helper, String name, boolean op, BlockPos rel) {
        Player player = new Player(helper.getLevel(), BlockPos.ZERO, 0f, new GameProfile(UUID.randomUUID(), name)) {
            @Override
            public boolean isSpectator() {
                return false;
            }

            @Override
            public boolean isCreative() {
                return false;
            }

            @Override
            protected int getPermissionLevel() {
                return op ? 4 : 0;
            }
        };
        Vec3 at = Vec3.atBottomCenterOf(helper.absolutePos(rel));
        player.setPos(at.x, at.y, at.z);
        return player;
    }

    private static BlockPos matrix(GameTestHelper helper, BlockPos rel, String placer) {
        BlockPos abs = helper.absolutePos(rel);
        WirelessRegistry.MATRIX.get().place(helper.getLevel(), abs);
        MatrixBlockEntity be = (MatrixBlockEntity) helper.getLevel().getBlockEntity(abs);
        for (int slot = 0; slot < MatrixBlockEntity.PLATE_SLOTS; slot++) {
            be.getItems().setStackInSlot(slot, new ItemStack(ModItems.CONSTRAINT_PLATE.get()));
        }
        be.getItems().setStackInSlot(MatrixBlockEntity.SLOT_CORE, new ItemStack(WirelessRegistry.MAT_CORE_0.get()));
        be.setPlacerName(placer);
        return abs;
    }

    private static NodeBlockEntity node(GameTestHelper helper, BlockPos rel, String placer, String password) {
        helper.setBlock(rel, WirelessRegistry.NODE_BASIC.get().defaultBlockState());
        NodeBlockEntity be = (NodeBlockEntity) helper.getBlockEntity(rel);
        be.setPlacerName(placer);
        be.setPassword(password);
        return be;
    }

    private static WirelessActionPayload act(Action action, BlockPos pos, BlockPos target, String a, String b) {
        return new WirelessActionPayload(action, pos, Optional.ofNullable(target), a, b);
    }

    @GameTest(template = EMPTY)
    public static void matrixConfigureChecksPermissionAndLengths(GameTestHelper helper) {
        WirelessData data = new WirelessData();
        BlockPos origin = matrix(helper, new BlockPos(1, 1, 1), "owner");
        BlockPos part = origin.offset(1, 1, 0);
        Player owner = player(helper, "owner", false, new BlockPos(4, 1, 1));
        Player stranger = player(helper, "stranger", false, new BlockPos(4, 1, 2));
        Player op = player(helper, "admin", true, new BlockPos(4, 1, 3));
        Player far = player(helper, "owner", false, new BlockPos(4, 1, 1).above(20));

        check(helper, WirelessActions.handle(stranger, act(Action.MATRIX_CONFIGURE, part, null, "net", "pw"), data)
                == WirelessResult.NO_PERMISSION, "a stranger must not create the network");
        check(helper, data.getNetwork(origin) == null, "no network after the refused attempt");
        check(helper, WirelessActions.handle(far, act(Action.MATRIX_CONFIGURE, origin, null, "net", "pw"), data)
                == WirelessResult.TOO_FAR, "the owner must be near the matrix");
        check(helper, WirelessActions.handle(owner, act(Action.MATRIX_CONFIGURE, origin, null, "", "pw"), data)
                == WirelessResult.INVALID_NAME, "empty SSID");
        check(helper, WirelessActions.handle(owner, act(Action.MATRIX_CONFIGURE, origin, null, LONG, "pw"), data)
                == WirelessResult.INVALID_NAME, "SSID longer than 32");
        check(helper, WirelessActions.handle(owner, act(Action.MATRIX_CONFIGURE, origin, null, "net", LONG), data)
                == WirelessResult.INVALID_NAME, "password longer than 32");
        check(helper, data.getNetwork(origin) == null, "invalid input must not create anything");

        // Se crea desde cualquier parte; luego se actualiza con la contraseña vacía (= no cambiarla).
        check(helper, WirelessActions.handle(owner, act(Action.MATRIX_CONFIGURE, part, null, "net", "pw"), data).ok(),
                "the owner creates the network");
        WirelessNetwork net = data.getNetwork(origin);
        check(helper, net != null && net.getSsid().equals("net") && net.checkPassword("pw"), "network stored");
        check(helper, WirelessActions.handle(owner, act(Action.MATRIX_CONFIGURE, origin, null, "home", ""), data)
                .ok(), "update with empty password");
        check(helper, net.getSsid().equals("home") && net.checkPassword("pw"), "SSID changed, password kept");
        check(helper, WirelessActions.handle(stranger, act(Action.MATRIX_CONFIGURE, origin, null, "mine", "x"), data)
                == WirelessResult.NO_PERMISSION, "a stranger must not update it");
        check(helper, WirelessActions.handle(op, act(Action.MATRIX_CONFIGURE, origin, null, "admin", "new"), data)
                .ok(), "an operator may update it");
        check(helper, net.getSsid().equals("admin") && net.checkPassword("new"), "operator update applied");

        MatrixBlockEntity be = (MatrixBlockEntity) helper.getLevel().getBlockEntity(origin);
        WirelessView view = MatrixMenu.buildView(stranger, data, be);
        check(helper, !view.canEdit() && view.name().equals("admin") && view.owner().equals("owner")
                && view.max() == MatrixBlockEntity.capacityFor(1), "view for a stranger: " + view);
        check(helper, !view.toString().contains("new"), "the view must not carry the password");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void nodeJoinLeaveAndConfigureViaHandler(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos origin = matrix(helper, new BlockPos(1, 1, 1), "owner");
        data.createNetwork(level, origin, "net", "pw");
        NodeBlockEntity node = node(helper, new BlockPos(5, 1, 5), "owner", "k");
        BlockPos nodePos = node.getBlockPos();
        Player owner = player(helper, "owner", false, new BlockPos(5, 1, 3));
        Player stranger = player(helper, "stranger", false, new BlockPos(4, 1, 3));

        WirelessView view = NodeMenu.buildView(owner, level, data, node);
        check(helper, view.entries().size() == 1 && view.entries().get(0).pos().equals(origin)
                && view.entries().get(0).name().equals("net"), "network in range listed: " + view.entries());
        check(helper, WirelessActions.handle(stranger, act(Action.NODE_JOIN, nodePos, origin, "pw", ""), data)
                == WirelessResult.NO_PERMISSION, "a stranger must not move the node");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_JOIN, nodePos, origin, "bad", ""), data)
                == WirelessResult.WRONG_PASSWORD, "wrong network password");
        check(helper, data.networkOfNode(nodePos) == null, "still out after a wrong password");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_JOIN, nodePos, origin, "pw", ""), data).ok(),
                "join with the right password");
        check(helper, data.networkOfNode(nodePos) == data.getNetwork(origin), "node joined");
        check(helper, NodeMenu.buildView(owner, level, data, node).current().equals("net"), "current network shown");
        check(helper, WirelessActions.handle(stranger, act(Action.NODE_LEAVE, nodePos, null, "", ""), data)
                == WirelessResult.NO_PERMISSION, "a stranger must not make it leave");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_LEAVE, nodePos, null, "", ""), data).ok()
                && data.networkOfNode(nodePos) == null, "leave");

        check(helper, WirelessActions.handle(owner, act(Action.NODE_CONFIGURE, nodePos, null, LONG, ""), data)
                == WirelessResult.INVALID_NAME, "name longer than 32");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_CONFIGURE, nodePos, null, "Base", LONG), data)
                == WirelessResult.INVALID_NAME, "password longer than 32");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_CONFIGURE, nodePos, null, "Base", ""), data)
                .ok() && node.getNodeName().equals("Base") && node.checkPassword("k"),
                "rename keeps the password when the field is empty");
        check(helper, WirelessActions.handle(owner, act(Action.NODE_CONFIGURE, nodePos, null, "Base", "z"), data)
                .ok() && node.checkPassword("z"), "new node password");
        check(helper, WirelessActions.handle(stranger, act(Action.NODE_CONFIGURE, nodePos, null, "Mine", ""), data)
                == WirelessResult.NO_PERMISSION && node.getNodeName().equals("Base"), "a stranger must not rename");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void linkMachineViaHandler(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        NodeBlockEntity node = node(helper, new BlockPos(1, 1, 1), "owner", "k");
        BlockPos nodePos = node.getBlockPos();
        helper.setBlock(new BlockPos(4, 1, 1), ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        BlockPos fusor = helper.absolutePos(new BlockPos(4, 1, 1));
        helper.setBlock(new BlockPos(6, 1, 1), Blocks.STONE);
        // Cualquiera que sepa la contraseña del nodo puede enlazar (no hace falta ser el dueño).
        Player player = player(helper, "someone", false, new BlockPos(4, 1, 3));

        check(helper, fusor.equals(WirelessLinking.linkTarget(level, fusor)), "the fusor can be linked");
        check(helper, WirelessLinking.linkTarget(level, nodePos) == null, "a node is not a link target");
        check(helper, WirelessLinking.linkTarget(level, helper.absolutePos(new BlockPos(6, 1, 1))) == null,
                "stone is not a link target");
        WirelessView view = NodeLinkMenu.buildView(level, data, fusor);
        check(helper, view.currentPos().isEmpty() && view.entries().stream().anyMatch(e -> e.pos().equals(nodePos)),
                "node listed, nothing linked: " + view);

        check(helper, WirelessActions.handle(player, act(Action.USER_LINK, fusor, nodePos, "bad", ""), data)
                == WirelessResult.WRONG_PASSWORD, "wrong node password");
        check(helper, data.nodeOfUser(fusor) == null, "not linked after a wrong password");
        check(helper, WirelessActions.handle(player, act(Action.USER_LINK, fusor, nodePos, "k", ""), data).ok(),
                "link with the right password");
        check(helper, nodePos.equals(data.nodeOfUser(fusor)), "linked to the node");
        view = NodeLinkMenu.buildView(level, data, fusor);
        check(helper, view.currentPos().equals(Optional.of(nodePos)) && view.current().equals(node.getNodeName()),
                "view shows the linked node");
        Player far = player(helper, "someone", false, new BlockPos(4, 30, 3));
        check(helper, WirelessActions.handle(far, act(Action.USER_UNLINK, fusor, null, "", ""), data)
                == WirelessResult.TOO_FAR, "unlinking needs to be near");
        check(helper, WirelessActions.handle(player, act(Action.USER_UNLINK, fusor, null, "", ""), data).ok()
                && data.nodeOfUser(fusor) == null, "unlink");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void viewCodecRoundTrip(GameTestHelper helper) {
        WirelessView view = new WirelessView("net", "owner", true, "cur", Optional.of(new BlockPos(1, 2, 3)), 2, 8,
                List.of(new WirelessView.Entry(new BlockPos(4, 5, 6), "node", 1, 5, 7, 2)));
        ByteBuf buf = Unpooled.buffer();
        WirelessView.STREAM_CODEC.encode(buf, view);
        WirelessView back = WirelessView.STREAM_CODEC.decode(buf);
        check(helper, back.equals(view), "round trip: " + back);
        WirelessActionPayload payload = act(Action.NODE_JOIN, new BlockPos(1, 1, 1), new BlockPos(2, 2, 2), "pw", "");
        buf = Unpooled.buffer();
        WirelessActionPayload.STREAM_CODEC.encode(buf, payload);
        check(helper, WirelessActionPayload.STREAM_CODEC.decode(buf).equals(payload), "payload round trip");
        helper.succeed();
    }

    // --- Recetas ---

    private static void craftsInto(GameTestHelper helper, int w, int h, List<ItemStack> grid, Item expected) {
        CraftingInput input = CraftingInput.of(w, h, grid);
        ItemStack out = helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(r -> r.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        if (!out.is(expected) || out.getCount() != 1) {
            helper.fail(expected + ": expected x1 but got " + out);
        }
    }

    private static ItemStack s(Item item) {
        return new ItemStack(item);
    }

    @GameTest(template = EMPTY)
    public static void wirelessRecipesMatchTheSpec(GameTestHelper helper) {
        ItemStack e = ItemStack.EMPTY;
        ItemStack calc = s(ModItems.CALC_CHIP.get());
        ItemStack data = s(ModItems.DATA_CHIP.get());
        ItemStack ingot = s(ModItems.CONSTRAINT_INGOT.get());
        ItemStack frame = s(ModItems.MACHINE_FRAME.get());
        ItemStack low = s(ModItems.CRYSTAL_LOW.get());
        ItemStack normal = s(ModItems.CRYSTAL_NORMAL.get());
        ItemStack pure = s(ModItems.CRYSTAL_PURE.get());
        ItemStack reso = s(ModItems.RESO_CRYSTAL.get());
        ItemStack conv = s(ModItems.ENERGY_CONVERT_COMPONENT.get());
        ItemStack resonance = s(ModItems.RESONANCE_COMPONENT.get());
        ItemStack red = s(Items.REDSTONE);
        ItemStack glow = s(Items.GLOWSTONE_DUST);
        ItemStack pearl = s(Items.ENDER_PEARL);
        ItemStack basic = s(WirelessRegistry.NODE_BASIC_ITEM.get());
        ItemStack standard = s(WirelessRegistry.NODE_STANDARD_ITEM.get());
        ItemStack core0 = s(WirelessRegistry.MAT_CORE_0.get());
        ItemStack core1 = s(WirelessRegistry.MAT_CORE_1.get());

        craftsInto(helper, 3, 3, List.of(e, calc, e, ingot, frame, ingot, low, reso, low),
                WirelessRegistry.NODE_BASIC_ITEM.get());
        craftsInto(helper, 3, 3, List.of(e, normal, e, calc, conv, calc, e, basic, e),
                WirelessRegistry.NODE_STANDARD_ITEM.get());
        craftsInto(helper, 1, 3, List.of(pure, resonance, standard), WirelessRegistry.NODE_ADVANCED_ITEM.get());
        craftsInto(helper, 3, 3, List.of(e, reso, e, red, frame, red, data, reso, data),
                WirelessRegistry.MATRIX_ITEM.get());
        craftsInto(helper, 3, 3, List.of(e, low, e, calc, reso, data, e, conv, e), WirelessRegistry.MAT_CORE_0.get());
        craftsInto(helper, 1, 3, List.of(reso, normal, core0), WirelessRegistry.MAT_CORE_1.get());
        craftsInto(helper, 3, 3, List.of(glow, glow, glow, reso, pearl, reso, e, core1, e),
                WirelessRegistry.MAT_CORE_2.get());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerRecipesUseTheRealParts(GameTestHelper helper) {
        ItemStack e = ItemStack.EMPTY;
        ItemStack bed = s(Items.RED_BED);
        ItemStack piston = s(Items.PISTON);
        ItemStack normal = s(ModItems.CRYSTAL_NORMAL.get());
        ItemStack frame = s(ModItems.MACHINE_FRAME.get());
        ItemStack red = s(Items.REDSTONE);
        ItemStack dev = s(ModItems.DEVELOPER_PORTABLE.get());
        // Con el sustituto de antes (resonance_component en vez de mat_core 0) ya no sale.
        CraftingInput old = CraftingInput.of(3, 3, List.of(e, dev, e, s(ModItems.RESONANCE_COMPONENT.get()), bed,
                piston, normal, frame, red));
        check(helper, helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, old, helper.getLevel())
                .isEmpty(), "developer_normal must not accept the old substitute");
        ItemStack plate = s(ModItems.CONSTRAINT_PLATE.get());
        ItemStack glow = s(Items.GLOWSTONE_DUST);
        CraftingInput oldAdvanced = CraftingInput.of(3, 3, List.of(plate, plate, plate, glow,
                s(ModItems.DEVELOPER_NORMAL.get()), glow, s(ModItems.ENERGY_CONVERT_COMPONENT.get()),
                s(ModItems.CRYSTAL_PURE.get()), s(ModItems.RESO_CRYSTAL.get())));
        check(helper, helper.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, oldAdvanced,
                helper.getLevel()).isEmpty(), "developer_advanced must not accept the old substitute");
        craftsInto(helper, 3, 3, List.of(e, dev, e, s(WirelessRegistry.MAT_CORE_0.get()), bed, piston, normal, frame,
                red), ModItems.DEVELOPER_NORMAL.get());
        helper.succeed();
    }
}
