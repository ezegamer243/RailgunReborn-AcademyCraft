package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.VecAccelRules;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.registry.ModSounds;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Vector Acceleration (T71). Jugador falso en (4.5, y, 3.5) mirando a +Z. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class VecAccelGameTests {
    private static final String EMPTY = "empty";
    private static final double EPS = 0.01;

    private static ServerPlayer player(GameTestHelper helper, double y) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-va-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, y, 3.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(2);
        Skill skill = VecManip.VEC_ACCEL.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, mantiene {@code ticks} ticks de servidor y suelta. */
    private static void hold(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel2(GameTestHelper helper) {
        Skill skill = VecManip.VEC_ACCEL.get();
        check(helper, skill.getLevel() == 2 && skill.canControl(), "level 2, controllable");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(VecManip.skillId("dir_shock")), "parent dir_shock");
        check(helper, skill.getGuiX() == 76 && skill.getGuiY() == 40, "gui position 76, 40");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/vec_accel.png"),
                "icon " + skill.getIcon());
        check(helper, ModSounds.VM_VEC_ACCEL.get() != null, "sound registered");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAtMaxChargeSetsTheExpectedVelocity(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 1);
        Skill skill = setUp(player, 0f);
        float cpBefore = CPData.get(player).getCP();

        hold(helper, player, skill, 25);

        double[] dir = VecAccelRules.direction(0f, 0f);
        double speed = VecAccelRules.speed(VecAccelRules.MAX_CHARGE);
        Vec3 v = player.getDeltaMovement();
        check(helper, Math.abs(speed - 2.10) < EPS, "max speed is 2.10, was " + speed);
        check(helper, Math.abs(v.x - dir[0] * speed) < EPS && Math.abs(v.y - dir[1] * speed) < EPS
                && Math.abs(v.z - dir[2] * speed) < EPS, "velocity " + v);
        check(helper, v.y > 0.3 && v.z > 1.9, "launched forward and up, " + v);
        check(helper, player.hurtMarked, "velocity flagged to sync");
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 120f) < 0.5f, "CP 120 at exp 0");
        check(helper, Math.abs(CPData.get(player).getOverload() - 30f) < 0.5f, "overload 30");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 80, "cooldown 80");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - VecAccelRules.EXP) < 1e-6f,
                "exp +0.002");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void quickReleaseIsSlower(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 1);
        Skill skill = setUp(player, 0f);

        hold(helper, player, skill, 0);

        check(helper, Math.abs(player.getDeltaMovement().length() - VecAccelRules.speed(0)) < EPS,
                "minimum charge speed 0.97, was " + player.getDeltaMovement().length());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void lowExpWithoutGroundDoesNothing(GameTestHelper helper) {
        floor(helper);
        // 5 bloques sobre el suelo: fuera del alcance de 2.
        ServerPlayer player = player(helper, 6);
        Skill skill = setUp(player, 0.3f);
        float cpBefore = CPData.get(player).getCP();

        hold(helper, player, skill, 20);

        check(helper, player.getDeltaMovement().equals(Vec3.ZERO), "no impulse, " + player.getDeltaMovement());
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0.3f, "no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void highExpWorksInTheAir(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 6);
        Skill skill = setUp(player, 0.6f);

        hold(helper, player, skill, 20);

        check(helper, player.getDeltaMovement().length() > 1.5, "launched in the air, " + player.getDeltaMovement());
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "cooldown set");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void theFallAfterwardsDoesNoDamage(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 1);
        Skill skill = setUp(player, 0f);

        hold(helper, player, skill, 20);

        check(helper, SafeTeleport.isFallGuarded(player), "fall guard active");
        float health = player.getHealth();
        player.fallDistance = 30f;
        player.causeFallDamage(30f, 1f, player.damageSources().fall());
        check(helper, player.getHealth() == health, "no fall damage, health " + player.getHealth());
        helper.succeed();
    }
}
