package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.DirShockRules;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.registry.ModSounds;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Directed Shock (T69). Jugador falso en (4.5, 1, 1.5); golems (no se queman). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class DirShockGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper, float yaw) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-ds-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 3.5));
        player.moveTo(pos.x, pos.y, pos.z, yaw, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Vector Manipulation nivel 1 con Directed Shock aprendida (con la exp dada), CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(1);
        Skill skill = VecManip.DIR_SHOCK.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, mantiene {@code ticks} ticks de servidor y suelta. */
    private static void hold(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel1(GameTestHelper helper) {
        Skill skill = VecManip.DIR_SHOCK.get();
        check(helper, skill.getLevel() == 1 && skill.canControl(), "level 1, controllable");
        check(helper, skill.getParent().isEmpty(), "root of the tree");
        check(helper, skill.getGuiX() == 16 && skill.getGuiY() == 45, "gui position 16, 45");
        check(helper, skill.getCategoryId().equals(VecManip.ID), "category vecmanip");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/dir_shock.png"),
                "icon " + skill.getIcon());
        check(helper, ModSounds.VM_DIRECTED_SHOCK.get() != null, "sound registered");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAt10TicksHitsAndCharges(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        hold(helper, player, skill, 10);

        check(helper, Math.abs(before - golem.getHealth() - 7f) < EPS,
                "7 damage, lost " + (before - golem.getHealth()));
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 50f) < 0.5f, "CP charged (50 at exp 0)");
        check(helper, Math.abs(CPData.get(player).getOverload() - 18f) < 0.5f, "overload 18");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 60, "cooldown 60");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - DirShockRules.EXP_HIT) < 1e-6f,
                "exp +0.0035");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingBeforeTheMinimumDoesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        hold(helper, player, skill, 3);

        check(helper, golem.getHealth() == before, "no damage");
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        check(helper, SkillContexts.find(player, skill).isEmpty(), "the context ended");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingTooLateDoesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 6.5));
        float before = golem.getHealth();
        hold(helper, player, skill, DirShockRules.MAX_TICKS + 10);
        check(helper, golem.getHealth() == before, "no damage");
        check(helper, CPData.get(player).getOverload() == 0f, "no overload");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void airPunchChargesAndCoolsDownWithoutExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f);
        // Un golem demasiado lejos (4 bloques): no se alcanza.
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 8.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        hold(helper, player, skill, 10);

        check(helper, golem.getHealth() == before, "out of reach: no damage");
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 50f) < 0.5f, "CP charged anyway");
        check(helper, Math.abs(CPData.get(player).getOverload() - 18f) < 0.5f, "overload charged anyway");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 60, "cooldown set");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp on a miss");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void strongKnockbackFollowsTheGaze(GameTestHelper helper) {
        floor(helper);
        // yaw 90 mira hacia -X: el golem a la izquierda del jugador debe salir hacia -X (y no hacia +Z).
        ServerPlayer player = player(helper, 90f);
        Skill skill = setUp(player, 0.5f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(2.5, 1, 3.5));
        float before = golem.getHealth();

        hold(helper, player, skill, 10);

        check(helper, Math.abs(before - golem.getHealth() - 11f) < EPS,
                "11 damage at exp 0.5, lost " + (before - golem.getHealth()));
        Vec3 v = golem.getDeltaMovement();
        check(helper, v.x < -0.5, "pushed along the gaze (-X), velocity " + v);
        check(helper, Math.abs(v.z) < 0.1, "no sideways drift, velocity " + v);
        check(helper, v.y > 0.05, "pushed upwards, velocity " + v);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void lowExpOnlyGivesTheBasicPush(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 90f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(2.5, 1, 3.5));

        hold(helper, player, skill, 10);

        Vec3 v = golem.getDeltaMovement();
        check(helper, v.x < 0 && Math.abs(v.z) < 0.1, "still pushed away, velocity " + v);
        check(helper, Math.abs(v.x) < 0.5, "but not the strong push, velocity " + v);
        helper.succeed();
    }
}
