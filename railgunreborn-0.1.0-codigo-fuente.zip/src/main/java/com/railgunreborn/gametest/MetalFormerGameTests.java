package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerMenu;
import com.railgunreborn.metalformer.MetalFormerMode;
import com.railgunreborn.metalformer.MetalFormerRecipes;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests del Metal Former (T87). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MetalFormerGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos FORMER = new BlockPos(1, 2, 1);

    private static final List<String> IDS = List.of("incise/wafer", "incise/imag_silicon_piece",
            "incise/needle_from_plate", "incise/needle_from_rail", "etch/calc_chip", "etch/silbarn",
            "plate/reinforced_iron_plate", "plate/constraint_plate", "plate/coin", "refine/imag_silicon_ingot",
            "refine/constraint_ingot", "refine/reso_crystal", "refine/crystal_low", "refine/iron_ingot",
            "refine/gold_ingot", "refine/copper_ingot", "refine/diamond", "refine/emerald", "refine/quartz",
            "refine/coal", "refine/redstone_block", "refine/lapis_lazuli");

    @GameTest(template = EMPTY)
    public static void allRecipesLoad(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        List<String> missing = new ArrayList<>();
        for (String id : IDS) {
            if (manager.byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "metal_former/" + id))
                    .filter(h -> h.value().getType() == MetalFormerRegistry.RECIPE_TYPE.get()).isEmpty()) {
                missing.add(id);
            }
        }
        if (manager.byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "metal_former")).isEmpty()) {
            missing.add("metal_former (crafting)");
        }
        check(helper, missing.isEmpty(), "missing recipes: " + missing);
        check(helper, manager.getAllRecipesFor(MetalFormerRegistry.RECIPE_TYPE.get()).size() == IDS.size(),
                "unexpected number of metal former recipes");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 200)
    public static void plateTurnsConstraintIngotIntoPlate(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        be.setMode(MetalFormerMode.PLATE);
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CONSTRAINT_INGOT.get()));
        helper.runAfterDelay(30, () -> {
            check(helper, be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT).isEmpty(),
                    "the plate must not be ready before the recipe time");
            check(helper, be.getProgress() > 0, "the machine should be working");
        });
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(ModItems.CONSTRAINT_PLATE.get()) && out.getCount() == 1,
                    "expected 1 constraint plate, got " + out);
            helper.assertTrue(be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_INPUT).isEmpty(),
                    "the ingot should be consumed");
        });
    }

    @GameTest(template = EMPTY)
    public static void modeChangesMatchingRecipe(GameTestHelper helper) {
        ItemStack wafer = new ItemStack(ModItems.WAFER.get());
        expect(helper, MetalFormerMode.INCISE, wafer, ModItems.IMAG_SILICON_PIECE.get(), 4, 1);
        expect(helper, MetalFormerMode.ETCH, wafer, ModItems.SILBARN.get(), 1, 1);
        check(helper, find(helper, MetalFormerMode.PLATE, wafer).isEmpty(), "a wafer has no PLATE recipe");
        ItemStack chip = new ItemStack(ModItems.DATA_CHIP.get());
        expect(helper, MetalFormerMode.ETCH, chip, ModItems.CALC_CHIP.get(), 1, 1);
        check(helper, find(helper, MetalFormerMode.REFINE, chip).isEmpty(), "a data chip has no REFINE recipe");
        expect(helper, MetalFormerMode.PLATE, new ItemStack(Items.IRON_INGOT), ModItems.REINFORCED_IRON_PLATE.get(),
                1, 1);
        expect(helper, MetalFormerMode.INCISE, new ItemStack(ModItems.IMAG_SILICON_INGOT.get()), ModItems.WAFER.get(),
                2, 1);
        helper.succeed();
    }

    /** El botón del menú (clickMenuButton) cambia el modo en el servidor y reinicia el progreso. */
    @GameTest(template = EMPTY)
    public static void menuButtonCyclesMode(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        MetalFormerMenu menu = new MetalFormerMenu(1, player.getInventory(), be);
        check(helper, be.getMode() == MetalFormerMode.PLATE, "default mode should be PLATE");
        menu.clickMenuButton(player, MetalFormerMenu.BUTTON_NEXT);
        check(helper, be.getMode() == MetalFormerMode.INCISE, "next should go to INCISE");
        menu.clickMenuButton(player, MetalFormerMenu.BUTTON_PREVIOUS);
        menu.clickMenuButton(player, MetalFormerMenu.BUTTON_PREVIOUS);
        check(helper, be.getMode() == MetalFormerMode.REFINE, "previous from PLATE should wrap to REFINE");
        check(helper, menu.getMode() == MetalFormerMode.REFINE, "menu data should follow the block entity");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void refineDoublesOres(GameTestHelper helper) {
        expect(helper, MetalFormerMode.REFINE, new ItemStack(Items.IRON_ORE), Items.IRON_INGOT, 2, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(Items.DEEPSLATE_IRON_ORE), Items.IRON_INGOT, 2, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(Items.GOLD_ORE), Items.GOLD_INGOT, 2, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(Items.REDSTONE_ORE), Items.REDSTONE_BLOCK, 1, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(Items.LAPIS_ORE), Items.LAPIS_LAZULI, 12, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(ModItems.CONSTRAINT_METAL.get()),
                ModItems.CONSTRAINT_INGOT.get(), 2, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(ModItems.IMAGSIL_ORE.get()),
                ModItems.IMAG_SILICON_INGOT.get(), 4, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(ModItems.RESO_ORE.get()), ModItems.RESO_CRYSTAL.get(),
                3, 1);
        expect(helper, MetalFormerMode.REFINE, new ItemStack(ModItems.CRYSTAL_ORE.get()), ModItems.CRYSTAL_LOW.get(),
                4, 1);
        check(helper, find(helper, MetalFormerMode.PLATE, new ItemStack(Items.IRON_ORE)).isEmpty(),
                "iron ore is only refined in REFINE mode");
        helper.succeed();
    }

    /** Recorrido completo con la máquina: una mena de hierro vanilla y una nuestra dan el doble. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void refineMachineDoublesVanillaAndModOre(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        be.setMode(MetalFormerMode.REFINE);
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT, new ItemStack(Items.IRON_ORE));
        BlockPos second = FORMER.east(2);
        MetalFormerBlockEntity be2 = place(helper, second);
        be2.setMode(MetalFormerMode.REFINE);
        be2.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT,
                new ItemStack(ModItems.CONSTRAINT_METAL.get()));
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(Items.IRON_INGOT) && out.getCount() == 2, "expected 2 iron ingots, got " + out);
            ItemStack out2 = be2.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out2.is(ModItems.CONSTRAINT_INGOT.get()) && out2.getCount() == 2,
                    "expected 2 constraint ingots, got " + out2);
        });
    }

    @GameTest(template = EMPTY)
    public static void coinAndNeedleRecipes(GameTestHelper helper) {
        ItemStack plate = new ItemStack(ModItems.REINFORCED_IRON_PLATE.get());
        check(helper, find(helper, MetalFormerMode.PLATE, plate).isEmpty(), "one plate is not enough for coins");
        expect(helper, MetalFormerMode.PLATE, plate.copyWithCount(2), ModItems.COIN.get(), 3, 2);
        expect(helper, MetalFormerMode.INCISE, plate, ModItems.NEEDLE.get(), 6, 1);
        expect(helper, MetalFormerMode.INCISE, new ItemStack(Items.RAIL), ModItems.NEEDLE.get(), 2, 1);
        helper.succeed();
    }

    /** Con la máquina: 4 placas en PLATE dan 6 monedas (dos operaciones de 2 placas). */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void machineMakesCoins(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_INPUT,
                new ItemStack(ModItems.REINFORCED_IRON_PLATE.get(), 4));
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(ModItems.COIN.get()) && out.getCount() == 6, "expected 6 coins, got " + out);
            helper.assertTrue(be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_INPUT).isEmpty(),
                    "all plates should be used");
        });
    }

    /** Capacidad de ítems por caras: arriba/lados meten en la entrada, abajo saca de la salida. */
    @GameTest(template = EMPTY)
    public static void sidedItemCapability(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        be.setMode(MetalFormerMode.ETCH); // Sin receta para lingotes: no se procesa durante la prueba.
        BlockPos abs = helper.absolutePos(FORMER);
        IItemHandler top = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.UP);
        IItemHandler side = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.NORTH);
        IItemHandler bottom = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK, abs, Direction.DOWN);
        check(helper, top != null && side != null && bottom != null, "the capability should exist on every side");
        check(helper, top.insertItem(0, new ItemStack(Items.IRON_INGOT, 3), false).isEmpty(),
                "top should accept items into the input");
        check(helper, side.insertItem(0, new ItemStack(Items.IRON_INGOT, 2), false).isEmpty(),
                "sides should accept items into the input");
        check(helper, be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_INPUT).getCount() == 5,
                "input should hold 5 ingots");
        check(helper, top.extractItem(0, 1, false).isEmpty(), "the input must not be extractable");
        check(helper, bottom.insertItem(0, new ItemStack(Items.IRON_INGOT), false).getCount() == 1,
                "the bottom must not accept items");
        be.getItems().setStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT, new ItemStack(ModItems.COIN.get(), 2));
        ItemStack taken = bottom.extractItem(0, 64, false);
        check(helper, taken.is(ModItems.COIN.get()) && taken.getCount() == 2, "bottom should extract the output");
        helper.succeed();
    }

    /** Una tolva encima mete los ítems en la entrada y la máquina los procesa. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void hopperFeedsInput(GameTestHelper helper) {
        MetalFormerBlockEntity be = place(helper);
        BlockPos hopperPos = FORMER.above();
        helper.setBlock(hopperPos, Blocks.HOPPER.defaultBlockState().setValue(HopperBlock.FACING, Direction.DOWN));
        if (helper.getBlockEntity(hopperPos) instanceof HopperBlockEntity hopper) {
            hopper.setItem(0, new ItemStack(Items.IRON_INGOT, 2));
        } else {
            helper.fail("hopper block entity missing");
            return;
        }
        helper.succeedWhen(() -> {
            ItemStack out = be.getItems().getStackInSlot(MetalFormerBlockEntity.SLOT_OUTPUT);
            helper.assertTrue(out.is(ModItems.REINFORCED_IRON_PLATE.get()) && out.getCount() == 2,
                    "expected 2 reinforced plates from the hopper's ingots, got " + out);
        });
    }

    // --- Utilidades ---

    private static MetalFormerBlockEntity place(GameTestHelper helper) {
        return place(helper, FORMER);
    }

    private static MetalFormerBlockEntity place(GameTestHelper helper, BlockPos pos) {
        helper.setBlock(pos, MetalFormerRegistry.METAL_FORMER.get().defaultBlockState());
        if (helper.getBlockEntity(pos) instanceof MetalFormerBlockEntity be) {
            be.getEnergy().setEnergy(MetalFormerBlockEntity.ENERGY_CAPACITY);
            return be;
        }
        throw new IllegalStateException("metal former block entity missing at " + pos);
    }

    private static Optional<MetalFormerRecipes.Operation> find(GameTestHelper helper, MetalFormerMode mode,
            ItemStack input) {
        return MetalFormerRecipes.find(helper.getLevel(), mode, input);
    }

    private static void expect(GameTestHelper helper, MetalFormerMode mode, ItemStack input, Item result, int count,
            int consumed) {
        Optional<MetalFormerRecipes.Operation> op = find(helper, mode, input);
        check(helper, op.isPresent(), mode + " should have a recipe for " + input);
        ItemStack out = op.get().result();
        check(helper, out.is(result) && out.getCount() == count,
                mode + " " + input + " should give " + count + " " + result + ", got " + out);
        check(helper, op.get().inputCount() == consumed, mode + " " + input + " should consume " + consumed);
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }
}
