package com.railgunreborn.gametest;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.LootTable;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Materiales de supervivencia (T82): registro, textos en ambos idiomas y loot table de cada bloque. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class SurvivalMaterialsGameTests {
    private static final String EMPTY = "empty";

    private static final List<String> ITEMS = List.of("constraint_ingot", "constraint_plate", "imag_silicon_ingot",
            "wafer", "imag_silicon_piece", "crystal_low", "crystal_normal", "crystal_pure", "reso_crystal",
            "reinforced_iron_plate", "data_chip", "calc_chip", "info_component", "brain_component",
            "resonance_component", "energy_convert_component", "windgen_fan", "energy_unit",
            "energy_unit_high", "energy_unit_mega");
    private static final List<String> BLOCKS = List.of("constraint_metal", "crystal_ore", "imagsil_ore", "reso_ore",
            "machine_frame");

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path);
    }

    private static JsonObject lang(String code) throws Exception {
        try (InputStream in = SurvivalMaterialsGameTests.class
                .getResourceAsStream("/assets/" + RailgunReborn.MODID + "/lang/" + code + ".json")) {
            if (in == null) {
                throw new IllegalStateException("missing lang file " + code);
            }
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        }
    }

    @GameTest(template = EMPTY)
    public static void itemsAndBlocksAreRegistered(GameTestHelper helper) {
        List<String> missing = new ArrayList<>();
        for (String name : ITEMS) {
            if (!BuiltInRegistries.ITEM.containsKey(id(name))) {
                missing.add("item " + name);
            }
        }
        for (String name : BLOCKS) {
            if (!BuiltInRegistries.BLOCK.containsKey(id(name))) {
                missing.add("block " + name);
            }
            if (!BuiltInRegistries.ITEM.containsKey(id(name))) {
                missing.add("block item " + name);
            }
        }
        if (!missing.isEmpty()) {
            helper.fail("not registered: " + missing);
            return;
        }
        if (ModItems.MACHINE_FRAME.get() != ModBlocks.MACHINE_FRAME.get().asItem()) {
            helper.fail("machine_frame block item mismatch");
            return;
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void everyEntryHasLangKeyInBothLanguages(GameTestHelper helper) throws Exception {
        List<String> missing = new ArrayList<>();
        for (String code : List.of("en_us", "es_es")) {
            JsonObject json = lang(code);
            for (String name : ITEMS) {
                if (!json.has("item.railgunreborn." + name)) {
                    missing.add(code + ": item." + name);
                }
            }
            for (String name : BLOCKS) {
                if (!json.has("block.railgunreborn." + name)) {
                    missing.add(code + ": block." + name);
                }
            }
        }
        if (!missing.isEmpty()) {
            helper.fail("missing lang keys: " + missing);
            return;
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void everyBlockHasLootTable(GameTestHelper helper) {
        List<String> missing = new ArrayList<>();
        for (String name : BLOCKS) {
            ResourceKey<LootTable> key = ResourceKey.create(Registries.LOOT_TABLE, id("blocks/" + name));
            LootTable table = helper.getLevel().getServer().reloadableRegistries().getLootTable(key);
            if (table == LootTable.EMPTY) {
                missing.add(name);
            }
        }
        if (!missing.isEmpty()) {
            helper.fail("blocks without loot table: " + missing);
            return;
        }
        helper.succeed();
    }
}
