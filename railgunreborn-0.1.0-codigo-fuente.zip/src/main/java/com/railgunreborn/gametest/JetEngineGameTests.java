package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.JetEngineRules;
import com.railgunreborn.ability.meltdowner.JetEngineSkill;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Jet Engine (T50). El movimiento lo hace el cliente: aquí se prueba la mitad servidor (coste, destino,
 * daño en el recorrido) y el recorrido del cliente se imita moviendo al jugador con {@link JetEngineRules#dashPosition}.
 * Todo dentro de la estructura de 9x9: se apunta hacia abajo o contra una pared. Gólems y cerdos: no se queman.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class JetEngineGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 4 con Jet Engine aprendida (exp 0), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(4);
        Skill skill = Meltdowner.JET_ENGINE.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static void action(ServerPlayer player, SkillContextActionPayload.Action action) {
        SkillContexts.handleAction(player, 1, action);
    }

    private static JetEngineSkill.JetEngineContext dash(GameTestHelper helper, ServerPlayer player) {
        JetEngineSkill.JetEngineContext ctx = JetEngineSkill.activeDash(player);
        if (ctx == null) {
            helper.fail("the dash should be active after releasing");
        }
        return ctx;
    }

    /** Imita al cliente: cada tick coloca al jugador donde lo deja el dash y deja correr el tick del servidor. */
    private static void fly(ServerPlayer player, Vec3 start, Vec3 dest, int ticks) {
        double[] s = {start.x, start.y, start.z};
        double[] d = {dest.x, dest.y, dest.z};
        for (int tick = 1; tick <= ticks; tick++) {
            double[] p = JetEngineRules.dashPosition(s, d, tick);
            player.setPos(p[0], p[1], p[2]);
            player.fallDistance = 3f;
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    @GameTest(template = EMPTY)
    public static void jetEngineIsRegisteredAtLevel4(GameTestHelper helper) {
        Skill skill = Meltdowner.JET_ENGINE.get();
        check(helper, skill.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, skill.getLevel() == 4 && skill.canControl(), "level 4, controllable");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Meltdowner.MELTDOWNER.getId())
                && Math.abs(skill.getParent().get().minExp() - 1.0f) < EPS, "parent: meltdowner (1.0)");
        check(helper, skill.getGuiX() == 170 && skill.getGuiY() == 32, "tree position should be 170, 32");
        int id = AbilityRegistries.SKILL_REGISTRY.getId(skill);
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.RAY_BARRAGE.get()) < id
                && id < AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.MINE_RAY_EXPERT.get()),
                "registered between ray barrage and the expert mining ray");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingPaysRealCostAndSetsCooldown(GameTestHelper helper) {
        floor(helper);
        // Mirando a +Z y 45° hacia abajo: el destino cae en el suelo a ~1.6 bloques.
        ServerPlayer player = player(helper, "test-jet-release", new Vec3(4.5, 1, 2.5), 45f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 5);
        check(helper, cp.getCP() == cpBefore && cp.getOverload() == 0f, "aiming costs nothing");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown while aiming");
        action(player, SkillContextActionPayload.Action.KEY_UP);

        JetEngineSkill.JetEngineContext ctx = dash(helper, player);
        check(helper, Math.abs(cpBefore - cp.getCP() - JetEngineRules.cpCost(0f)) < 0.5f,
                "pays 60 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - JetEngineRules.overload(0f)) < 0.5f,
                "adds 170 overload, was " + cp.getOverload());
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == JetEngineRules.cooldown(0f),
                "cooldown of 60 ticks set on release");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - JetEngineRules.EXP_GAIN) < 1e-6f,
                "0.004 exp on release");
        Vec3 dest = ctx.destination();
        Vec3 floorTop = helper.absoluteVec(new Vec3(4.5, 1, 2.5));
        check(helper, Math.abs(dest.y - floorTop.y) < 1e-3 && dest.z > floorTop.z,
                "the destination is on the floor ahead, was " + dest.subtract(floorTop));

        Vec3 start = player.position();
        fly(player, start, dest, JetEngineRules.FLIGHT_TICKS - 1);
        check(helper, JetEngineSkill.activeDash(player) != null, "the flight lasts 15 ticks");
        check(helper, player.fallDistance == 0f, "no fall damage during the flight");
        fly(player, start, dest, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "the context ends after 15 flight ticks");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void destinationStopsAtTheWall(GameTestHelper helper) {
        floor(helper);
        for (int x = 2; x <= 6; x++) {
            for (int y = 1; y <= 4; y++) {
                helper.setBlock(new BlockPos(x, y, 5), Blocks.STONE);
            }
        }
        ServerPlayer player = player(helper, "test-jet-wall", new Vec3(4.5, 1, 1.5), 0f);
        setUp(player);
        Vec3 dest = JetEngineSkill.destination(player);
        Vec3 wallFace = helper.absoluteVec(new Vec3(4.5, 1, 5));
        check(helper, Math.abs(dest.z - wallFace.z) < 1e-3, "the destination is the face of the wall, was "
                + dest.subtract(wallFace));
        check(helper, dest.distanceTo(player.getEyePosition()) < JetEngineRules.REACH,
                "the wall is closer than 12 blocks");

        // Una telaraña a la altura de los ojos no tiene colisión: el destino sigue siendo la pared.
        helper.setBlock(new BlockPos(4, 2, 3), Blocks.COBWEB);
        check(helper, JetEngineSkill.destination(player).distanceTo(dest) < 1e-3,
                "blocks without collision do not stop the trace");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void dashHurtsTheMobOnThePathOnce(GameTestHelper helper) {
        floor(helper);
        LivingEntity golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.0));
        LivingEntity aside = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(0.5, 1, 6.5));
        float golemBefore = golem.getHealth();
        float asideBefore = aside.getHealth();
        // 20° hacia abajo: el destino queda en el suelo a ~4.5 bloques, pasado el gólem.
        ServerPlayer player = player(helper, "test-jet-hit", new Vec3(4.5, 1, 1.5), 20f);
        Skill skill = setUp(player);

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 2);
        action(player, SkillContextActionPayload.Action.KEY_UP);
        JetEngineSkill.JetEngineContext ctx = dash(helper, player);
        Vec3 dest = ctx.destination();
        check(helper, dest.z > golem.getBoundingBox().maxZ, "the destination is past the golem");
        fly(player, player.position(), dest, JetEngineRules.FLIGHT_TICKS);

        float lost = golemBefore - golem.getHealth();
        check(helper, Math.abs(lost - JetEngineRules.damage(0f)) < 0.5f,
                "the golem on the path loses 7 health once, lost " + lost);
        check(helper, aside.getHealth() == asideBefore, "the pig aside is not hurt");
        check(helper, player.getHealth() == player.getMaxHealth(), "the caster is not hurt");
        check(helper, SkillContexts.active(player).isEmpty(), "the flight ends");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void notEnoughCpOrAbortPaysNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer poor = player(helper, "test-jet-poor", new Vec3(2.5, 1, 2.5), 45f);
        Skill skill = setUp(poor);
        CPData cp = CPData.get(poor);
        cp.consumeWithForce(poor, 0f, cp.getCP() - 30f);
        SkillContexts.start(poor, 1, skill);
        hold(poor, 1);
        check(helper, SkillContexts.active(poor).isEmpty(), "without 60 CP the aim ends");
        check(helper, cp.getOverload() == 0f && Math.abs(cp.getCP() - 30f) < EPS, "nothing is paid");
        check(helper, !CooldownData.get(poor).isInCooldown(skill.getId()), "no cooldown");

        ServerPlayer aborting = player(helper, "test-jet-abort", new Vec3(6.5, 1, 2.5), 45f);
        setUp(aborting);
        CPData cp2 = CPData.get(aborting);
        float before = cp2.getCP();
        check(helper, SkillContexts.start(aborting, 1, skill) == StartResult.OK, "start should be accepted");
        hold(aborting, 3);
        action(aborting, SkillContextActionPayload.Action.KEY_ABORT);
        check(helper, SkillContexts.active(aborting).isEmpty(), "abort ends the context");
        check(helper, cp2.getCP() == before && cp2.getOverload() == 0f, "abort pays nothing");
        check(helper, !CooldownData.get(aborting).isInCooldown(skill.getId()), "abort sets no cooldown");
        check(helper, AbilityData.get(aborting).getSkillExp(skill.getId()) == 0f, "abort gives no exp");
        helper.succeed();
    }
}
