package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.ThunderclapRules;
import com.railgunreborn.ability.electromaster.ThunderclapSkill;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Thunderclap (T34). El jugador flota sobre la estructura y mira hacia arriba: el rayo cae 40 bloques
 * por encima, en el aire, y el radio (15 a exp 0) no llega a las estructuras vecinas. Los ticks del contexto se dan a
 * mano y todo ocurre dentro de la misma llamada (sin ticks del juego en medio).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ThunderclapGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    /** Por encima del techo de barreras que GameTest pone a cada estructura: el trazado hacia arriba no choca. */
    private static final Vec3 PLAYER_POS = new Vec3(4.5, 30, 1.5);

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(PLAYER_POS);
        // Mirando hacia arriba.
        player.moveTo(pos.x, pos.y, pos.z, 0f, -90f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    /** Electromaster nivel 5 con Thunderclap aprendida (exp 0) y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(5);
        Skill skill = Electromaster.THUNDER_CLAP.get();
        ability.learnSkill(skill.getId());
        CPData.get(player).setActivated(player, true);
        // Salvaguarda: si el trazado chocara con algo, el área podría alcanzar otras pruebas.
        Vec3 expected = player.getEyePosition().add(0, ThunderclapRules.TRACE_RANGE, 0);
        if (ThunderclapSkill.aim(player).distanceTo(expected) > 1e-3) {
            throw new IllegalStateException("Thunderclap test aim must be open air, got " + ThunderclapSkill.aim(player));
        }
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Ticks de carga con el KEEP_ALIVE que manda el cliente real (sin él, el servidor corta a los 30). */
    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static boolean hasSlowness(ServerPlayer player) {
        return player.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(ThunderclapSkill.SLOW_MODIFIER_ID) != null;
    }

    /** Zombi sin IA ni gravedad a {@code offset} del punto de impacto (40 bloques sobre los ojos). */
    private static Zombie zombieNearImpact(GameTestHelper helper, ServerPlayer player, Vec3 offset) {
        Vec3 impact = player.getEyePosition().add(0, ThunderclapRules.TRACE_RANGE, 0);
        Vec3 rel = helper.relativeVec(impact.add(offset));
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, rel);
        zombie.setNoGravity(true);
        return zombie;
    }

    @GameTest(template = EMPTY)
    public static void thunderclapIsRegisteredAtLevel5(GameTestHelper helper) {
        Skill skill = Electromaster.THUNDER_CLAP.get();
        check(helper, skill.getLevel() == 5, "level should be 5");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Electromaster.THUNDER_BOLT.getId())
                && Math.abs(skill.getParent().get().minExp() - 1.0f) < EPS, "parent should be thunder_bolt (1.0)");
        check(helper, skill.getGuiX() == 204 && skill.getGuiY() == 80, "tree position should be 204, 80");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAtThirtyTicksCancels(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, Math.abs(cp.getOverload() - ThunderclapRules.overloadCost(0f)) < EPS,
                "initial overload should be 390, was " + cp.getOverload());
        hold(player, 30);
        float expectedCP = startCP - 30 * ThunderclapRules.cpPerTick(0f);
        check(helper, Math.abs(cp.getCP() - expectedCP) < EPS, "CP should be " + expectedCP + ", was " + cp.getCP());
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);

        check(helper, SkillContexts.active(player).isEmpty(), "release should end the context");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown when cancelled");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp when cancelled");
        check(helper, !hasSlowness(player), "slowness must be removed after cancelling");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAtFiftyTicksStrikesInsideTheRadius(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        // 8 bloques por debajo del impacto (dentro del radio 15) y 20 por encima (fuera).
        Zombie inside = zombieNearImpact(helper, player, new Vec3(0, -8, 0));
        Zombie outside = zombieNearImpact(helper, player, new Vec3(0, 20, 0));
        float insideBefore = inside.getHealth();
        float outsideBefore = outside.getHealth();
        float playerBefore = player.getHealth();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 50);
        check(helper, !SkillContexts.active(player).isEmpty(), "still charging at 50 ticks");
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);

        boolean insideHurt = inside.getHealth() < insideBefore;
        boolean outsideUntouched = outside.getHealth() == outsideBefore;
        float playerAfter = player.getHealth();
        int cooldown = CooldownData.get(player).getRemaining(skill.getId(), 0);
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        inside.discard();
        outside.discard();

        // Esperado a 8 bloques: 37.2 * 7/15 = 17.4 (menos la armadura natural del zombi).
        check(helper, insideHurt, "zombie inside the radius should be hurt, had " + insideBefore);
        check(helper, outsideUntouched, "zombie outside the radius must not be hurt");
        check(helper, playerAfter == playerBefore, "the caster must not hurt himself");
        check(helper, cooldown == ThunderclapRules.cooldownTicks(0f, 50), "cooldown should be 500, was " + cooldown);
        check(helper, Math.abs(exp - ThunderclapRules.EXP_GAIN) < 1e-6f, "exp should be 0.003, was " + exp);
        check(helper, SkillContexts.active(player).isEmpty(), "context should end after the strike");
        check(helper, !hasSlowness(player), "slowness must be removed after the strike");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void holdingSixtyTicksStrikesByItself(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, ThunderclapRules.MAX_TICKS);
        check(helper, SkillContexts.active(player).isEmpty(), "60 ticks should strike and end");
        int cooldown = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, cooldown == 600, "full charge cooldown should be 600, was " + cooldown);
        check(helper, !hasSlowness(player), "slowness must be removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpNoOverloadIsCharged(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 10f);
        SkillContexts.start(player, 1, skill);
        check(helper, SkillContexts.active(player).isEmpty(), "without CP the context must end at once");
        check(helper, cp.getOverload() == 0f, "overload must not be charged, was " + cp.getOverload());
        check(helper, Math.abs(cp.getCP() - 10f) < EPS, "CP must not change, was " + cp.getCP());
        check(helper, !hasSlowness(player), "no slowness without starting");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void slownessFollowsChargeAndIsRemovedOnAbort(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        double baseSpeed = player.getAttributeValue(Attributes.MOVEMENT_SPEED);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, 30);
        AttributeModifier modifier = player.getAttribute(Attributes.MOVEMENT_SPEED)
                .getModifier(ThunderclapSkill.SLOW_MODIFIER_ID);
        check(helper, modifier != null, "slowness modifier expected while charging");
        check(helper, Math.abs(modifier.amount() - ThunderclapRules.speedModifierAmount(30)) < 1e-6,
                "modifier should follow the charge, was " + modifier.amount());
        double slowed = player.getAttributeValue(Attributes.MOVEMENT_SPEED);
        check(helper, Math.abs(slowed - baseSpeed * ThunderclapRules.speedFactor(30)) < 1e-6,
                "speed should be " + ThunderclapRules.speedFactor(30) + " of normal, was " + slowed / baseSpeed);

        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_ABORT);
        check(helper, SkillContexts.active(player).isEmpty(), "abort should end the context");
        check(helper, !hasSlowness(player), "slowness must be removed on abort");
        check(helper, Math.abs(player.getAttributeValue(Attributes.MOVEMENT_SPEED) - baseSpeed) < 1e-9,
                "speed should be back to normal");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "abort gives no cooldown");
        helper.succeed();
    }
}
