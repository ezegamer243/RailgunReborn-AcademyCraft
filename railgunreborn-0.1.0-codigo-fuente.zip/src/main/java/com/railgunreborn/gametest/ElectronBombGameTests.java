package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.ElectronBombRules;
import com.railgunreborn.ability.meltdowner.ElectronBombShots;
import com.railgunreborn.ability.meltdowner.Meltdowner;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Electron Bomb (T43). Jugador falso mirando hacia +Z desde (4.5, 1, 1.5). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ElectronBombGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-4f;

    private static ServerPlayer player(GameTestHelper helper, float pitch, double dy) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-electron-bomb"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1 + dy, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 1 con Electron Bomb aprendida (exp 0) y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(1);
        Skill bomb = Meltdowner.ELECTRON_BOMB.get();
        ability.learnSkill(bomb.getId());
        CPData.get(player).setActivated(player, true);
        return bomb;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    @GameTest(template = EMPTY)
    public static void electronBombIsRegisteredAndParentsRadIntensify(GameTestHelper helper) {
        Skill bomb = Meltdowner.ELECTRON_BOMB.get();
        check(helper, bomb.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, bomb.getLevel() == 1 && bomb.canControl(), "level 1, controllable");
        check(helper, bomb.getParent().isEmpty(), "root of the tree");
        check(helper, bomb.getGuiX() == 15 && bomb.getGuiY() == 45, "tree position should be 15, 45");
        check(helper, AbilityRegistries.SKILL_REGISTRY.containsKey(bomb.getId()), "present in the skill registry");

        Skill rad = Meltdowner.RAD_INTENSIFY.get();
        check(helper, rad.getParent().isPresent() && rad.getParent().get().skill().equals(bomb.getId())
                && Math.abs(rad.getParent().get().minExp() - 0.5f) < EPS, "rad intensify parent: electron bomb (0.5)");
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(bomb) < AbilityRegistries.SKILL_REGISTRY.getId(rad),
                "electron bomb is registered before rad intensify");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void bombHurtsZombieInFrontAfterEighteenTicksForFree(GameTestHelper helper) {
        floor(helper);
        // Mirada al cerdo (0.9 de alto, bajo la línea de ojos): si no, el aimPoint no lo ve y el rayo sale recto
        // desde la bola, que nace a una altura al azar y a veces pasa por encima.
        ServerPlayer player = player(helper, 20f, 0);
        Skill bomb = setUp(player);
        Pig target = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(4.5, 1, 4.5));
        float before = target.getHealth();
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        check(helper, SkillContexts.active(player).isEmpty(), "context ends right away");
        check(helper, Math.abs(cp.getCP() - cpBefore) < EPS && cp.getOverload() == 0f, "free: no CP, no overload");
        check(helper, CooldownData.get(player).isInCooldown(bomb.getId()), "cooldown set on click");
        check(helper, ElectronBombShots.pendingCount() >= 1, "the shot is pending");
        check(helper, target.getHealth() == before, "no damage at click time");

        helper.runAfterDelay(ElectronBombRules.fireTick(0f) - 3, () -> {
            check(helper, target.getHealth() == before, "no damage before the ball fires");
        });
        helper.runAfterDelay(ElectronBombRules.fireTick(0f) + 2, () -> {
            // Cerdo y no zombi: el zombi se quema al sol en la plantilla vacía y falsearía el "sin daño".
            check(helper, target.getHealth() <= before - 5.5f,
                    "target should lose ~6 health, had " + before + " now " + target.getHealth());
            check(helper, Math.abs(cp.getCP() - cpBefore) < EPS && cp.getOverload() == 0f, "still free");
            float exp = AbilityData.get(player).getSkillExp(bomb.getId());
            check(helper, Math.abs(exp - ElectronBombRules.EXP_GAIN) < 1e-6f, "hit gives 0.005 exp, was " + exp);
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void shotIntoTheAirGivesNoExp(GameTestHelper helper) {
        floor(helper);
        // Muy por encima de la estructura y mirando arriba: el rayo no toca nada ni a otros GameTests.
        ServerPlayer player = player(helper, -90f, 40);
        Skill bomb = setUp(player);

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        helper.runAfterDelay(ElectronBombRules.fireTick(0f) + 2, () -> {
            check(helper, AbilityData.get(player).getSkillExp(bomb.getId()) == 0f, "no exp when nothing is hit");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void secondClickIsRejectedByCooldown(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, -90f, 40);
        Skill bomb = setUp(player);

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "first click accepted");
        check(helper, CooldownData.get(player).isInCooldown(bomb.getId()), "cooldown set");
        StartResult second = SkillContexts.validateStart(player, bomb);
        check(helper, second == StartResult.COOLDOWN, "second click should hit cooldown, was " + second);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void deadPlayerCancelsThePendingShot(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f, 0);
        Skill bomb = setUp(player);
        Pig target = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(4.5, 1, 4.5));
        float before = target.getHealth();

        check(helper, SkillContexts.start(player, 1, bomb) == StartResult.OK, "start should be accepted");
        player.setHealth(0f);
        player.die(player.damageSources().generic());
        helper.runAfterDelay(ElectronBombRules.fireTick(0f) + 2, () -> {
            check(helper, target.getHealth() == before, "a dead caster must not shoot");
            helper.succeed();
        });
    }
}
