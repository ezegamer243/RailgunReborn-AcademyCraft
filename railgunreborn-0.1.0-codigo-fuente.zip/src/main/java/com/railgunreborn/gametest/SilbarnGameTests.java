package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.entity.SilbarnEntity;
import com.railgunreborn.item.SilbarnItem;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests del Silicon Barn (T48): lanzamiento, consumo, flotación y caída, apuntado y gasto. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class SilbarnGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper, GameType mode) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-silbarn-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la mirada (getViewVector) la usa.
        player.setYHeadRot(0f);
        player.setGameMode(mode);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static SilbarnEntity throwBarn(ServerPlayer player) {
        ((SilbarnItem) ModItems.SILBARN.get()).use(player.level(), player, InteractionHand.MAIN_HAND);
        List<SilbarnEntity> barns = player.level().getEntitiesOfClass(SilbarnEntity.class,
                player.getBoundingBox().inflate(3));
        return barns.isEmpty() ? null : barns.get(0);
    }

    @GameTest(template = EMPTY)
    public static void throwingConsumesOneInSurvival(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.SILBARN.get(), 3));
        SilbarnEntity barn = throwBarn(player);
        check(helper, barn != null, "barn entity should exist");
        check(helper, player.getMainHandItem().getCount() == 2, "should have 2 left");
        throwBarn(player);
        check(helper, player.getMainHandItem().getCount() == 1, "no cooldown: second throw consumes too");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void throwingDoesNotConsumeInCreative(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.CREATIVE);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.SILBARN.get(), 3));
        check(helper, throwBarn(player) != null, "barn entity should exist");
        check(helper, player.getMainHandItem().getCount() == 3, "creative must keep the stack");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 120)
    public static void hoversThenFalls(GameTestHelper helper) {
        // Lanzado 20 bloques más arriba: no choca con nada durante la prueba.
        ServerPlayer player = player(helper, GameType.CREATIVE);
        player.moveTo(player.getX(), player.getY() + 20, player.getZ(), 0f, 0f);
        player.setYHeadRot(0f);
        SilbarnEntity barn = throwBarn(player);
        check(helper, barn != null, "barn entity should exist");
        double startZ = barn.getZ();
        double[] y30 = {0};
        double[] y50 = {0};
        helper.onEachTick(() -> {
            int t = barn.tickCount;
            if (t == 30) {
                y30[0] = barn.getY();
            }
            if (t == 50) {
                y50[0] = barn.getY();
                double dz = barn.getZ() - startZ;
                check(helper, dz > 3.0 && dz < 4.2, "should have flown about 4 blocks, was " + dz);
                check(helper, Math.abs(y50[0] - y30[0]) < 0.05, "should float without gravity");
            }
            if (t == 70) {
                check(helper, barn.getY() < y50[0] - 0.5, "should be falling after the hover");
                barn.discard();
                helper.succeed();
            }
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 60)
    public static void findLookedAtFindsTheBarn(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.CREATIVE);
        SilbarnEntity barn = throwBarn(player);
        check(helper, barn != null, "barn entity should exist");
        helper.runAfterDelay(10, () -> {
            check(helper, SilbarnEntity.findLookedAt(player, 20) == barn, "should find the barn being looked at");
            player.setYRot(180f);
            player.setYHeadRot(180f);
            check(helper, SilbarnEntity.findLookedAt(player, 20) == null, "looking away should find nothing");
            player.setYRot(0f);
            player.setYHeadRot(0f);
            check(helper, barn.consume(), "consume should succeed once");
            check(helper, !barn.isUsable() && barn.isHit(), "consumed barn is no longer usable");
            check(helper, !barn.consume(), "second consume must fail");
            check(helper, SilbarnEntity.findLookedAt(player, 20) == null, "used barn is not found");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 100)
    public static void hitsGroundAndDisappears(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.CREATIVE);
        SilbarnEntity barn = throwBarn(player);
        check(helper, barn != null, "barn entity should exist");
        helper.runAfterDelay(90, () -> {
            check(helper, barn.isRemoved(), "barn should have fallen, hit the floor and been removed");
            AABB box = new AABB(helper.absolutePos(BlockPos.ZERO)).inflate(30);
            check(helper, helper.getLevel().getEntitiesOfClass(SilbarnEntity.class, box).isEmpty(),
                    "no barn should remain");
            helper.succeed();
        });
    }
}
