package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.context.TerminationReason;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.ChargingRules;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Current Charging (T26). Los ticks del contexto se dan a mano con {@link SkillContexts#tick} para que
 * la regeneración de CP (otro evento) no se mezcle. La carga FE real se prueba con JUnit ({@code ChargingRulesTest}):
 * vanilla no tiene bloques ni ítems con energía.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ChargingGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    // --- utilidades (mismo jugador falso que RailgunGameTests) ---

    static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 1 con Current Charging aprendida (exp 0) y modo habilidad encendido. */
    static Skill setUpCharging(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(1);
        Skill charging = Electromaster.CHARGING.get();
        ability.learnSkill(charging.getId());
        CPData.get(player).setActivated(player, true);
        return charging;
    }

    static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    static void tick(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.tick(player);
        }
    }

    // --- tests ---

    @GameTest(template = EMPTY)
    public static void chargingIsRegisteredUnderArcGen(GameTestHelper helper) {
        Skill charging = Electromaster.CHARGING.get();
        check(helper, charging.getLevel() == 1, "level should be 1");
        check(helper, charging.getParent().isPresent()
                && charging.getParent().get().skill().equals(Electromaster.ARC_GEN.getId())
                && Math.abs(charging.getParent().get().minExp() - 0.3f) < EPS, "parent should be arc_gen (0.3)");
        check(helper, charging.getGuiX() == 55 && charging.getGuiY() == 18, "tree position should be 55, 18");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargingWithoutTargetSpendsCpAndGivesIdleExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();

        StartResult result = SkillContexts.start(player, 1, charging);
        check(helper, result == StartResult.OK, "start should be accepted, was " + result);
        check(helper, Math.abs(cp.getOverload() - ChargingRules.overloadCost(0f)) < EPS,
                "initial overload should be 65, was " + cp.getOverload());
        check(helper, cp.getCP() == startCP, "pressing alone must not spend CP");

        int ticks = 20;
        tick(player, ticks);
        check(helper, !SkillContexts.active(player).isEmpty(), "context should stay alive while held");
        float expectedCP = startCP - ticks * ChargingRules.cpPerTick(0f);
        check(helper, Math.abs(cp.getCP() - expectedCP) < EPS,
                "CP should be " + expectedCP + ", was " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - ChargingRules.overloadCost(0f)) < EPS,
                "overload must not change while held, was " + cp.getOverload());
        float exp = AbilityData.get(player).getSkillExp(charging.getId());
        float expectedExp = ticks * ChargingRules.EXP_IDLE;
        check(helper, Math.abs(exp - expectedExp) < 1e-6f, "exp should be " + expectedExp + ", was " + exp);

        // Soltar la tecla termina; sin cooldown se puede volver a empezar enseguida.
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, SkillContexts.active(player).isEmpty(), "releasing the key should terminate");
        check(helper, !CooldownData.get(player).isInCooldown(charging.getId()), "charging has no cooldown");
        check(helper, SkillContexts.validateStart(player, charging) == StartResult.OK, "should be startable again");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargingStopsWhenCpRunsOut(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        CPData cp = CPData.get(player);
        // Deja 7 CP: dos ticks de 3 y el tercero falla.
        cp.consumeWithForce(player, 0f, cp.getCP() - 7f);

        check(helper, SkillContexts.start(player, 1, charging) == StartResult.OK, "start should be accepted");
        tick(player, 2);
        check(helper, !SkillContexts.active(player).isEmpty(), "two ticks should still be paid");
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "running out of CP should terminate");
        float exp = AbilityData.get(player).getSkillExp(charging.getId());
        check(helper, Math.abs(exp - 2 * ChargingRules.EXP_IDLE) < 1e-6f,
                "only the paid ticks give exp, was " + exp);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargingWithoutCpChargesNoOverload(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 1f);

        SkillContexts.start(player, 1, charging);
        check(helper, SkillContexts.active(player).isEmpty(), "without CP for a tick it should end at once");
        check(helper, cp.getOverload() == 0f, "no overload should be charged, was " + cp.getOverload());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargingEndsWhenAbilityModeTurnsOff(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        check(helper, SkillContexts.start(player, 1, charging) == StartResult.OK, "start should be accepted");
        CPData.get(player).setActivated(player, false);
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "turning ability mode off should terminate");
        SkillContexts.terminateAll(player, TerminationReason.LOGOUT);
        helper.succeed();
    }
}
