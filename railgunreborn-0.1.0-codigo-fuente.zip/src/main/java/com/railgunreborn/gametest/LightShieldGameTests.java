package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.LightShieldRules;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Light Shield (T45). Jugador falso en (4.5, 1, 1.5) mirando hacia +Z (yaw 0) o hacia -Z (yaw 180).
 * Gólems de hierro como atacantes/objetivos: no se queman al sol.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class LightShieldGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    /** Lejos del radio de contacto (3), delante si el jugador mira a +Z. */
    private static final Vec3 FAR_FRONT = new Vec3(4.5, 1, 7.5);

    private static ServerPlayer player(GameTestHelper helper, String name, float yaw) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, yaw, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el cono del escudo la usa.
        player.setYHeadRot(yaw);
        // El jugador falso nace con la protección de aparición (60 ticks): se gasta antes de empezar.
        for (int i = 0; i < 61; i++) {
            player.tick();
        }
        player.setYRot(yaw);
        player.setYHeadRot(yaw);
        player.invulnerableTime = 0;
        player.setHealth(20f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 2 con Light Shield aprendida (exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(2);
        Skill shield = Meltdowner.LIGHT_SHIELD.get();
        ability.learnSkill(shield.getId());
        ability.setSkillExp(shield.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return shield;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static void release(ServerPlayer player) {
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    /**
     * Golpe con {@code attacker} como entidad directa y sin causante: así no escala con la dificultad. Se limpia la
     * invulnerabilidad para que cada golpe cuente entero.
     */
    private static void hit(ServerPlayer player, Entity attacker, float amount) {
        player.invulnerableTime = 0;
        player.setHealth(20f);
        DamageSource source = new DamageSource(player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(DamageTypes.MOB_ATTACK), attacker, null);
        player.hurt(source, amount);
    }

    private static IronGolem golem(GameTestHelper helper, Vec3 at) {
        return helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, at);
    }

    @GameTest(template = EMPTY)
    public static void lightShieldIsRegisteredAtLevel2UnderElectronBomb(GameTestHelper helper) {
        Skill shield = Meltdowner.LIGHT_SHIELD.get();
        check(helper, shield.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, shield.getLevel() == 2 && shield.canControl(), "level 2, controllable");
        check(helper, shield.getParent().isPresent()
                && shield.getParent().get().skill().equals(Meltdowner.ELECTRON_BOMB.getId())
                && Math.abs(shield.getParent().get().minExp() - 1.0f) < EPS, "parent: electron bomb (1.0)");
        check(helper, shield.getGuiX() == 55 && shield.getGuiY() == 15, "tree position should be 55, 15");
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.SCATTER_BOMB.get())
                < AbilityRegistries.SKILL_REGISTRY.getId(shield), "registered after scatter bomb");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void frontalHitIsReducedAndCostsCpAndOverload(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-shield-front", 0f);
        Skill shield = setUp(player, 0f);
        IronGolem attacker = golem(helper, FAR_FRONT);
        CPData cp = CPData.get(player);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        check(helper, Math.abs(cp.getOverload() - LightShieldRules.initialOverload(0f)) < EPS,
                "initial overload " + cp.getOverload());
        hold(player, 2);
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();
        hit(player, attacker, 20f);
        // exp 0: absorbe 15 de 20.
        check(helper, Math.abs(player.getHealth() - 15f) < EPS, "20 - 15 absorbed, health " + player.getHealth());
        check(helper, Math.abs(cp.getCP() - (cpBefore - LightShieldRules.actionCp(0f))) < EPS,
                "absorbing costs 50 CP: " + cpBefore + " -> " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - (overloadBefore + LightShieldRules.actionOverload(0f))) < EPS,
                "absorbing adds 5 overload: " + overloadBefore + " -> " + cp.getOverload());
        check(helper, AbilityData.get(player).getSkillExp(shield.getId()) >= LightShieldRules.EXP_ABSORB,
                "absorbing gives exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hitFromBehindIsNotAbsorbed(GameTestHelper helper) {
        floor(helper);
        // Mira a -Z: el gólem en +Z queda a la espalda.
        ServerPlayer player = player(helper, "test-shield-back", 180f);
        Skill shield = setUp(player, 0f);
        IronGolem attacker = golem(helper, FAR_FRONT);
        CPData cp = CPData.get(player);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        hold(player, 2);
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();
        hit(player, attacker, 8f);
        check(helper, Math.abs(player.getHealth() - 12f) < EPS, "full damage from behind, health "
                + player.getHealth());
        check(helper, cp.getCP() == cpBefore && cp.getOverload() == overloadBefore, "nothing is charged");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void onlyOneHitIsAbsorbedEvery18Ticks(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-shield-interval", 0f);
        Skill shield = setUp(player, 0f);
        IronGolem attacker = golem(helper, FAR_FRONT);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        hold(player, 2);
        hit(player, attacker, 8f);
        check(helper, player.getHealth() == 20f, "first hit absorbed, health " + player.getHealth());
        hit(player, attacker, 8f);
        check(helper, Math.abs(player.getHealth() - 12f) < EPS, "same tick passes whole, health "
                + player.getHealth());
        hold(player, LightShieldRules.ACTION_INTERVAL);
        hit(player, attacker, 8f);
        check(helper, Math.abs(player.getHealth() - 12f) < EPS, "18 ticks later still passes whole, health "
                + player.getHealth());
        hold(player, 1);
        hit(player, attacker, 8f);
        check(helper, player.getHealth() == 20f, "19 ticks later absorbed again, health " + player.getHealth());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void anotherPlayersShieldDoesNotProtect(GameTestHelper helper) {
        floor(helper);
        ServerPlayer owner = player(helper, "test-shield-owner", 0f);
        ServerPlayer other = player(helper, "test-shield-other", 0f);
        Skill shield = setUp(owner, 0f);
        IronGolem attacker = golem(helper, FAR_FRONT);

        check(helper, SkillContexts.start(owner, 1, shield) == StartResult.OK, "start should be accepted");
        hold(owner, 2);
        float cpBefore = CPData.get(owner).getCP();
        hit(other, attacker, 8f);
        check(helper, Math.abs(other.getHealth() - 12f) < EPS, "the other player takes full damage");
        check(helper, CPData.get(owner).getCP() == cpBefore, "the owner pays nothing");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void touchingTheShieldHurtsANearbyMob(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-shield-touch", 0f);
        Skill shield = setUp(player, 0f);
        IronGolem near = golem(helper, new Vec3(4.5, 1, 3.5));
        float before = near.getHealth();
        CPData cp = CPData.get(player);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();
        hold(player, 1);
        float expected = LightShieldRules.touchDamage(0f) * shield.getDamageScale();
        check(helper, Math.abs(near.getHealth() - (before - expected)) < EPS,
                "contact damage " + before + " -> " + near.getHealth());
        float expectedCp = cpBefore - LightShieldRules.cpPerTick(0f) - LightShieldRules.actionCp(0f);
        check(helper, Math.abs(cp.getCP() - expectedCp) < EPS, "CP " + cp.getCP() + " expected " + expectedCp);
        check(helper, Math.abs(cp.getOverload() - (overloadBefore + LightShieldRules.actionOverload(0f))) < EPS,
                "contact adds overload: " + overloadBefore + " -> " + cp.getOverload());
        // Durante su invulnerabilidad no se le vuelve a dañar ni se cobra.
        float healthAfter = near.getHealth();
        float cpAfter = cp.getCP();
        hold(player, 1);
        check(helper, near.getHealth() == healthAfter, "no second hit while invulnerable");
        check(helper, Math.abs(cp.getCP() - (cpAfter - LightShieldRules.cpPerTick(0f))) < EPS,
                "only the per-tick CP");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void endingGivesSlownessTwoAndCooldown(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-shield-end", 0f);
        Skill shield = setUp(player, 0f);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        hold(player, 5);
        release(player);
        check(helper, SkillContexts.active(player).isEmpty(), "release ends the context");
        MobEffectInstance slow = player.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
        check(helper, slow != null && slow.getAmplifier() == LightShieldRules.SLOW_AMPLIFIER
                && slow.getDuration() == LightShieldRules.SLOW_TICKS, "Slowness II for 5 s: " + slow);
        int cooldown = CooldownData.get(player).getRemaining(shield.getId(), 0);
        check(helper, cooldown == LightShieldRules.cooldown(0f, 5), "cooldown lerp(2t, t): " + cooldown);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void reachingMaxDurationEndsTheShield(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-shield-max", 0f);
        Skill shield = setUp(player, 1f);

        check(helper, SkillContexts.start(player, 1, shield) == StartResult.OK, "start should be accepted");
        int max = LightShieldRules.maxTicks(1f);
        hold(player, max);
        check(helper, !SkillContexts.active(player).isEmpty(), "still active at the max tick");
        hold(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "ends after the max duration");
        check(helper, player.hasEffect(MobEffects.MOVEMENT_SLOWDOWN), "slowness after timing out");
        helper.succeed();
    }
}
