package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModItems;

import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de las recetas de mesa y horno de supervivencia (T84). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class SurvivalRecipeGameTests {
    private static final String EMPTY = "empty";

    private static final List<String> IDS = List.of("imag_silicon_piece", "wafer", "silbarn", "data_chip_iron",
            "data_chip_silicon", "calc_chip_quartz", "calc_chip_reso", "reinforced_iron_plate", "constraint_plate",
            "energy_unit_low", "energy_unit_high", "energy_unit_mega", "info_component", "brain_component",
            "resonance_component", "energy_convert_component", "machine_frame", "windgen_fan", "developer_portable",
            "imag_silicon_ingot_from_smelting", "imag_silicon_ingot_from_blasting", "constraint_ingot_from_smelting",
            "constraint_ingot_from_blasting", "crystal_low_from_smelting", "crystal_low_from_blasting");

    @GameTest(template = EMPTY)
    public static void allRecipesLoad(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        List<String> missing = new ArrayList<>();
        for (String id : IDS) {
            if (manager.byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, id)).isEmpty()) {
                missing.add(id);
            }
        }
        check(helper, missing.isEmpty(), "missing recipes: " + missing);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void silbarnFromTwoPieces(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        ItemStack piece = new ItemStack(ModItems.IMAG_SILICON_PIECE.get());
        CraftingInput input = CraftingInput.of(2, 1, List.of(piece, piece.copy()));
        ItemStack out = manager.getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        check(helper, out.is(ModItems.SILBARN.get()), "two silicon pieces should craft a silbarn, got " + out);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void constraintPlateRowGivesTwo(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        ItemStack ingot = new ItemStack(ModItems.CONSTRAINT_INGOT.get());
        CraftingInput input = CraftingInput.of(3, 1, List.of(ingot, ingot.copy(), ingot.copy()));
        ItemStack out = manager.getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        check(helper, out.is(ModItems.CONSTRAINT_PLATE.get()) && out.getCount() == 2,
                "3 constraint ingots in a row should give 2 plates, got " + out);
        CraftingInput column = CraftingInput.of(1, 3, List.of(ingot, ingot.copy(), ingot.copy()));
        check(helper, manager.getRecipeFor(RecipeType.CRAFTING, column, helper.getLevel()).isEmpty(),
                "a column of constraint ingots must not craft plates");
        helper.succeed();
    }

    /** La placa de hierro reforzada está en {@code c:plates/iron}: sin otros mods el chip de hierro se puede hacer. */
    @GameTest(template = EMPTY)
    public static void dataChipFromReinforcedPlate(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        ItemStack redstone = new ItemStack(Items.REDSTONE);
        ItemStack plate = new ItemStack(ModItems.REINFORCED_IRON_PLATE.get());
        CraftingInput input = CraftingInput.of(3, 2, List.of(redstone, redstone.copy(), redstone.copy(),
                ItemStack.EMPTY, plate, ItemStack.EMPTY));
        ItemStack out = manager.getRecipeFor(RecipeType.CRAFTING, input, helper.getLevel())
                .map(h -> h.value().assemble(input, helper.getLevel().registryAccess())).orElse(ItemStack.EMPTY);
        check(helper, out.is(ModItems.DATA_CHIP.get()), "3 redstone + reinforced iron plate should craft a data chip");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void furnaceSmeltsOres(GameTestHelper helper) {
        RecipeManager manager = helper.getLevel().getRecipeManager();
        check(helper, smelts(helper, manager, RecipeType.SMELTING, ModItems.CONSTRAINT_METAL.get(),
                ModItems.CONSTRAINT_INGOT.get()), "constraint_metal smelting");
        check(helper, smelts(helper, manager, RecipeType.BLASTING, ModItems.IMAGSIL_ORE.get(),
                ModItems.IMAG_SILICON_INGOT.get()), "imagsil_ore blasting");
        check(helper, smelts(helper, manager, RecipeType.SMELTING, ModItems.CRYSTAL_ORE.get(),
                ModItems.CRYSTAL_LOW.get()), "crystal_ore smelting");
        check(helper, manager.getRecipeFor(RecipeType.SMELTING,
                new SingleRecipeInput(new ItemStack(ModItems.RESO_ORE.get())), helper.getLevel()).isEmpty(),
                "reso_ore must not smelt");
        helper.succeed();
    }

    private static <T extends AbstractCookingRecipe> boolean smelts(GameTestHelper helper, RecipeManager manager,
            RecipeType<T> type, Item in, Item out) {
        return manager.getRecipeFor(type, new SingleRecipeInput(new ItemStack(in)), helper.getLevel())
                .map(h -> h.value().getResultItem(helper.getLevel().registryAccess()).is(out)).orElse(false);
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }
}
