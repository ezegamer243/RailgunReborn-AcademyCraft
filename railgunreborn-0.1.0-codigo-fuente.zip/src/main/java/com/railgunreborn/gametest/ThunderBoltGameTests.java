package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.ThunderBoltRules;
import com.railgunreborn.ability.electromaster.ThunderBoltSkill;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Thunder Bolt (T27). Jugador falso mirando hacia +Z desde (4.5, 1, 1.5), como en Arc Gen. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ThunderBoltGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    // --- utilidades (mismo jugador falso que RailgunGameTests) ---

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 4 con Thunder Bolt aprendida (exp 0) y modo habilidad encendido. */
    private static Skill setUpThunderBolt(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(4);
        Skill bolt = Electromaster.THUNDER_BOLT.get();
        ability.learnSkill(bolt.getId());
        CPData.get(player).setActivated(player, true);
        return bolt;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    // --- tests ---

    @GameTest(template = EMPTY)
    public static void thunderBoltIsRegisteredInTheTree(GameTestHelper helper) {
        Skill bolt = Electromaster.THUNDER_BOLT.get();
        check(helper, bolt.getLevel() == 4, "level should be 4");
        check(helper, bolt.getParent().isPresent()
                && bolt.getParent().get().skill().equals(Electromaster.ARC_GEN.getId())
                && bolt.getParent().get().minExp() == 0f, "parent should be arc_gen (0.0)");
        check(helper, bolt.getExtraDependencies().size() == 1
                && bolt.getExtraDependencies().get(0).skill().equals(Electromaster.CHARGING.getId())
                && Math.abs(bolt.getExtraDependencies().get(0).minExp() - 0.7f) < EPS,
                "dependency should be charging (0.7)");
        check(helper, bolt.getGuiX() == 86 && bolt.getGuiY() == 67, "tree position should be 86, 67");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void thunderBoltHurtsTargetAndAreaAndSpendsResources(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill bolt = setUpThunderBolt(player);
        Zombie direct = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        // Fuera de la línea del rayo pero a menos de 8 bloques de los ojos del objetivo.
        Zombie nearby = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(7.5, 1, 6.5));
        float directBefore = direct.getHealth();
        float nearbyBefore = nearby.getHealth();
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        StartResult result = SkillContexts.start(player, 1, bolt);
        check(helper, result == StartResult.OK, "start should be accepted, was " + result);
        // Armadura natural del zombi (2) quita algo menos del 2 %.
        check(helper, direct.getHealth() <= directBefore - 9f,
                "direct target should lose ~10 health, had " + directBefore + " now " + direct.getHealth());
        check(helper, nearby.getHealth() <= nearbyBefore - 5.5f && nearby.getHealth() >= nearbyBefore - 6.01f,
                "nearby mob should lose ~6 (area damage), had " + nearbyBefore + " now " + nearby.getHealth());
        check(helper, Math.abs(cp.getCP() - (cpBefore - ThunderBoltRules.cpCost(0f))) < EPS,
                "CP should drop by 280, was " + cpBefore + " -> " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - ThunderBoltRules.overloadCost(0f)) < EPS,
                "overload should be 50, was " + cp.getOverload());
        check(helper, CooldownData.get(player).isInCooldown(bolt.getId()), "cooldown should be set");
        float exp = AbilityData.get(player).getSkillExp(bolt.getId());
        check(helper, Math.abs(exp - ThunderBoltRules.EXP_EFFECTIVE) < 1e-6f, "effective hit gives 0.005, was " + exp);
        check(helper, SkillContexts.active(player).isEmpty(), "context should have terminated itself");
        check(helper, SkillContexts.validateStart(player, bolt) == StartResult.COOLDOWN,
                "second shot should be rejected by cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void areaExcludesCasterAndDirectTarget(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        setUpThunderBolt(player);
        Zombie direct = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        Zombie nearby = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(7.5, 1, 6.5));

        ThunderBoltSkill.Target target = ThunderBoltSkill.aim(player);
        check(helper, target.direct() == direct, "aim should pick the zombie in front, got " + target.direct());
        check(helper, target.point().distanceTo(direct.getEyePosition()) < EPS,
                "impact point should be the target's eyes");
        var aoe = ThunderBoltSkill.aoeTargets(player, target);
        // Solo se comprueba lo propio: otros GameTests corren al lado y sus entidades podrían caer en el radio.
        check(helper, aoe.contains(nearby), "area should contain the nearby zombie: " + aoe);
        check(helper, !aoe.contains(direct) && !aoe.contains(player), "area must exclude the direct target and the caster");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void waterDoesNotStopTheBolt(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        setUpThunderBolt(player);
        for (int y = 1; y <= 4; y++) {
            for (int x = 3; x <= 6; x++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.WATER);
            }
        }
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 6.5));
        check(helper, ThunderBoltSkill.aim(player).direct() == zombie, "the bolt should go through water");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void thunderBoltWithNobodyGivesEmptyExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill bolt = setUpThunderBolt(player);
        // Muy por encima de la estructura y mirando arriba: ni el rayo ni el área (8) llegan a otros GameTests.
        player.moveTo(player.getX(), player.getY() + 40, player.getZ(), 0f, -90f);
        check(helper, ThunderBoltSkill.aoeTargets(player, ThunderBoltSkill.aim(player)).isEmpty(),
                "nobody should be near the impact point");
        check(helper, SkillContexts.start(player, 1, bolt) == StartResult.OK, "start should be accepted");
        float exp = AbilityData.get(player).getSkillExp(bolt.getId());
        check(helper, Math.abs(exp - ThunderBoltRules.EXP_EMPTY) < 1e-6f, "empty shot gives 0.003, was " + exp);
        check(helper, CooldownData.get(player).isInCooldown(bolt.getId()), "empty shot still sets cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void thunderBoltWithoutCpDoesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill bolt = setUpThunderBolt(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 100f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        float before = zombie.getHealth();

        check(helper, SkillContexts.start(player, 1, bolt) == StartResult.OK, "start itself is accepted");
        check(helper, zombie.getHealth() == before, "without CP the zombie must not be hurt");
        check(helper, !CooldownData.get(player).isInCooldown(bolt.getId()), "no cooldown when nothing was spent");
        check(helper, AbilityData.get(player).getSkillExp(bolt.getId()) == 0f, "no exp when nothing was spent");
        check(helper, SkillContexts.active(player).isEmpty(), "context should have terminated");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void thunderBoltRejectedWithoutCategoryOrLearning(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill bolt = Electromaster.THUNDER_BOLT.get();
        StartResult noCategory = SkillContexts.validateStart(player, bolt);
        check(helper, noCategory == StartResult.WRONG_CATEGORY, "expected WRONG_CATEGORY, was " + noCategory);

        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(4);
        CPData.get(player).setActivated(player, true);
        StartResult notLearned = SkillContexts.validateStart(player, bolt);
        check(helper, notLearned == StartResult.NOT_LEARNED, "expected NOT_LEARNED, was " + notLearned);
        helper.succeed();
    }
}
