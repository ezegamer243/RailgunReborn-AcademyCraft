package com.railgunreborn.gametest;

import static com.railgunreborn.gametest.ChargingGameTests.check;
import static com.railgunreborn.gametest.ChargingGameTests.floor;
import static com.railgunreborn.gametest.ChargingGameTests.player;
import static com.railgunreborn.gametest.ChargingGameTests.setUpCharging;
import static com.railgunreborn.gametest.ChargingGameTests.tick;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.ChargingRules;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.DirectChargeable;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorStructure;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.WirelessRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * Current Charging con la energía del mod (T106): ítems (Energy Unit, Developer portátil) y bloques (carga directa
 * sin tope de ancho de banda). El jugador mira hacia +Z desde (4.5, 1, 1.5); el objetivo va en (4, 2, 4).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ChargingEnergyGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos TARGET = new BlockPos(4, 2, 4);
    private static final float EXP_TOLERANCE = 1e-6f;

    private static float exp(ServerPlayer player, Skill charging) {
        return AbilityData.get(player).getSkillExp(charging.getId());
    }

    private static void hold(GameTestHelper helper, ServerPlayer player, Skill charging, int ticks) {
        check(helper, SkillContexts.start(player, 1, charging) == StartResult.OK, "start should be accepted");
        tick(player, ticks);
    }

    @GameTest(template = EMPTY)
    public static void itemModeChargesEnergyUnitWithinItsBandwidth(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        player.setItemInHand(InteractionHand.MAIN_HAND, EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT.get()), 0));
        hold(helper, player, charging, 10);
        // exp 0: 15 por tick, por debajo del ancho de banda del ítem (20).
        int expected = 10 * ChargingRules.chargePerTick(0f);
        check(helper, EnergyUnitItem.getEnergy(player.getMainHandItem()) == expected,
                "energy unit should hold " + expected + ", had " + EnergyUnitItem.getEnergy(player.getMainHandItem()));
        check(helper, Math.abs(exp(player, charging) - 10 * ChargingRules.EXP_EFFECTIVE) < EXP_TOLERANCE,
                "item mode with a chargeable item gives the effective exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void itemModeChargesDeveloperPortable(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        player.setItemInHand(InteractionHand.OFF_HAND,
                DeveloperPortableItem.withEnergy(new ItemStack(ModItems.DEVELOPER_PORTABLE.get()), 0));
        hold(helper, player, charging, 10);
        int expected = 10 * ChargingRules.chargePerTick(0f);
        check(helper, DeveloperPortableItem.getEnergy(player.getOffhandItem()) == expected,
                "portable developer should hold " + expected + ", had "
                        + DeveloperPortableItem.getEnergy(player.getOffhandItem()));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void blockModeChargesImagFusorAndGivesEffectiveExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        helper.setBlock(TARGET, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        ImagFusorBlockEntity fusor = (ImagFusorBlockEntity) helper.getBlockEntity(TARGET);
        hold(helper, player, charging, 10);
        int expected = 10 * ChargingRules.chargePerTick(0f);
        check(helper, fusor.getEnergy().getEnergyStored() == expected,
                "fusor should hold " + expected + ", had " + fusor.getEnergy().getEnergyStored());
        check(helper, Math.abs(exp(player, charging) - 10 * ChargingRules.EXP_EFFECTIVE) < EXP_TOLERANCE,
                "effective exp expected, was " + exp(player, charging));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void directChargeIgnoresPerCallBandwidth(GameTestHelper helper) {
        helper.setBlock(TARGET, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        ImagFusorBlockEntity fusor = (ImagFusorBlockEntity) helper.getBlockEntity(TARGET);
        DirectChargeable direct = DirectChargeable.find(helper.getLevel(), helper.absolutePos(TARGET));
        check(helper, direct != null, "fusor must be directly chargeable");
        check(helper, fusor.getEnergy().receiveEnergy(500, true) == ImagFusorBlockEntity.ENERGY_MAX_RECEIVE,
                "the normal FE path is capped per call");
        check(helper, direct.chargeDirect(500, true) == 500, "simulate reports everything fits");
        check(helper, fusor.getEnergy().getEnergyStored() == 0, "simulate must not change anything");
        check(helper, direct.chargeDirect(500, false) == 500, "direct charge ignores the 50 per call cap");
        check(helper, fusor.getEnergy().getEnergyStored() == 500, "stored should be 500");
        int space = ImagFusorBlockEntity.ENERGY_CAPACITY - 500;
        check(helper, direct.chargeDirect(Integer.MAX_VALUE, false) == space, "capacity is still respected");
        check(helper, direct.chargeDirect(10, false) == 0, "full means nothing more goes in");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void blockModeChargesWirelessNode(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        helper.setBlock(TARGET, WirelessRegistry.NODE_BASIC.get().defaultBlockState());
        NodeBlockEntity node = (NodeBlockEntity) helper.getBlockEntity(TARGET);
        hold(helper, player, charging, 10);
        int expected = 10 * ChargingRules.chargePerTick(0f);
        check(helper, node.getEnergy().getEnergyStored() == expected,
                "node should hold " + expected + ", had " + node.getEnergy().getEnergyStored());
        DirectChargeable direct = DirectChargeable.find(helper.getLevel(), helper.absolutePos(TARGET));
        check(helper, direct != null && direct.chargeDirect(1000, false) == 1000, "node accepts beyond its bandwidth");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void directChargeReachesDeveloperThroughAnyPart(GameTestHelper helper) {
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_NORMAL.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperBlockEntity developer = (DeveloperBlockEntity) helper.getLevel().getBlockEntity(block);
        DirectChargeable direct = DirectChargeable.find(helper.getLevel(), block);
        check(helper, direct != null, "developer must be directly chargeable");
        int accepted = direct.chargeDirect(Integer.MAX_VALUE, false);
        check(helper, accepted > 0 && developer.getEnergy().getEnergyStored() == accepted, "developer takes the charge");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void reactorKeepsItsPerTickCapWhenCharged(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        BlockPos base = helper.absolutePos(new BlockPos(4, 1, 5));
        check(helper, CategoryReactorStructure.build(helper.getLevel(), base, player), "reactor should build");
        CategoryReactorBlockEntity reactor = (CategoryReactorBlockEntity) helper.getLevel()
                .getBlockEntity(CategoryReactorStructure.controllerFromBase(base));
        // Una pieza (no el controlador) también llega a la carga directa.
        BlockPos part = helper.absolutePos(new BlockPos(4, 2, 4));
        DirectChargeable direct = DirectChargeable.find(helper.getLevel(), part);
        check(helper, direct != null, "reactor parts must be directly chargeable");
        int rate = RailgunConfig.reactorChargeRate();
        check(helper, direct.chargeDirect(rate * 3, false) == rate, "only one tick's quota goes in");
        check(helper, direct.chargeDirect(10, false) == 0, "quota exhausted this tick");
        check(helper, reactor.getEnergy().getEnergyStored() == rate, "stored should equal one quota");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void generatorIsNotChargedAndGivesIdleExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        helper.setBlock(TARGET, ModBlocks.CAT_ENGINE.get().defaultBlockState());
        check(helper, DirectChargeable.find(helper.getLevel(), helper.absolutePos(TARGET)) == null,
                "generators are not directly chargeable");
        hold(helper, player, charging, 10);
        check(helper, Math.abs(exp(player, charging) - 10 * ChargingRules.EXP_IDLE) < EXP_TOLERANCE,
                "a generator is not a target: only the idle exp, was " + exp(player, charging));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noTargetGivesIdleExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill charging = setUpCharging(player);
        hold(helper, player, charging, 10);
        check(helper, Math.abs(exp(player, charging) - 10 * ChargingRules.EXP_IDLE) < EXP_TOLERANCE,
                "nothing to charge: idle exp only");
        helper.succeed();
    }
}
