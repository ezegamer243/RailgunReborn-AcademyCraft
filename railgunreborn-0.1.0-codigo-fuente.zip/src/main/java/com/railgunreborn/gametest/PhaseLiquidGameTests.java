package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.item.MatterUnitItem;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidActionResult;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Líquido de fase (T85): cubo, unidad de materia (uso y capacidad de fluido), lagos y etiquetas. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class PhaseLiquidGameTests {
    private static final String EMPTY = "empty";
    private static final TagKey<Fluid> C_PHASE_LIQUID = TagKey.create(Registries.FLUID,
            ResourceLocation.fromNamespaceAndPath("c", "phase_liquid"));

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path);
    }

    private static boolean isPhaseSource(GameTestHelper helper, BlockPos rel) {
        FluidState fluid = helper.getLevel().getFluidState(helper.absolutePos(rel));
        return fluid.isSource() && fluid.is(ModFluids.PHASE_LIQUID.get());
    }

    @GameTest(template = EMPTY)
    public static void lakeFeatureAndBiomeModifierExist(GameTestHelper helper) {
        var access = helper.getLevel().registryAccess();
        if (!access.registryOrThrow(Registries.CONFIGURED_FEATURE).containsKey(id("phase_liquid_lake"))) {
            helper.fail("missing configured_feature phase_liquid_lake");
        }
        if (!access.registryOrThrow(Registries.PLACED_FEATURE).containsKey(id("phase_liquid_lake"))) {
            helper.fail("missing placed_feature phase_liquid_lake");
        }
        if (!access.registryOrThrow(NeoForgeRegistries.Keys.BIOME_MODIFIERS).containsKey(id("phase_liquid_lake"))) {
            helper.fail("missing biome_modifier phase_liquid_lake");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fluidTagsAndProperties(GameTestHelper helper) {
        FluidState source = ModFluids.PHASE_LIQUID.get().defaultFluidState();
        FluidState flowing = ModFluids.FLOWING_PHASE_LIQUID.get().defaultFluidState();
        if (!source.is(C_PHASE_LIQUID) || !flowing.is(C_PHASE_LIQUID)) {
            helper.fail("phase liquid missing from c:phase_liquid");
        }
        if (source.is(FluidTags.WATER) || source.is(FluidTags.LAVA)) {
            helper.fail("phase liquid must not be tagged as water or lava");
        }
        if (source.getFluidType() != ModFluids.PHASE_LIQUID_TYPE.get() || ModFluids.PHASE_LIQUID_TYPE.get().getLightLevel() != 8) {
            helper.fail("fluid type wrong or light level is not 8");
        }
        if (ModBlocks.PHASE_LIQUID.get().defaultBlockState().getLightEmission() != 8) {
            helper.fail("liquid block should emit light 8");
        }
        if (source.createLegacyBlock().getBlock() != ModBlocks.PHASE_LIQUID.get()) {
            helper.fail("source fluid should map to the phase liquid block");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void bucketPicksUpAndPlaces(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        BlockPos rel = new BlockPos(1, 1, 1);
        BlockPos pos = helper.absolutePos(rel);
        helper.setBlock(rel, ModBlocks.PHASE_LIQUID.get().defaultBlockState());
        ItemStack bucket = ModBlocks.PHASE_LIQUID.get().pickupBlock(null, level, pos, level.getBlockState(pos));
        if (!bucket.is(ModItems.PHASE_LIQUID_BUCKET.get())) {
            helper.fail("picking up the source should give the phase liquid bucket, got " + bucket);
        }
        if (!level.getBlockState(pos).isAir()) {
            helper.fail("source should be gone after pickup");
        }
        if (!ModItems.PHASE_LIQUID_BUCKET.get().emptyContents(null, level, pos, null, bucket)) {
            helper.fail("bucket should place the liquid");
        }
        if (!isPhaseSource(helper, rel)) {
            helper.fail("bucket did not place a phase liquid source");
        }
        int amount = FluidUtil.getFluidContained(new ItemStack(ModItems.PHASE_LIQUID_BUCKET.get())).map(FluidStack::getAmount).orElse(0);
        if (amount != 1000) {
            helper.fail("bucket fluid capability should report 1000 mB, got " + amount);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matterUnitCollectsAndPlacesByUse(GameTestHelper helper) {
        BlockPos floor = new BlockPos(1, 1, 1);
        BlockPos liquid = floor.above();
        helper.setBlock(floor, Blocks.STONE);
        helper.setBlock(liquid, ModBlocks.PHASE_LIQUID.get().defaultBlockState());
        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        BlockPos abs = helper.absolutePos(liquid);
        player.moveTo(abs.getX() + 0.5, abs.getY() + 1.5, abs.getZ() + 0.5, 0f, 90f);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.MATTER_UNIT.get()));

        ItemStack filled = ModItems.MATTER_UNIT.get().use(helper.getLevel(), player, InteractionHand.MAIN_HAND).getObject();
        if (!filled.is(ModItems.MATTER_UNIT_PHASE_LIQUID.get())) {
            helper.fail("empty matter unit should become filled, got " + filled);
        }
        if (!helper.getLevel().getBlockState(abs).isAir()) {
            helper.fail("matter unit should remove the source block");
        }

        player.setItemInHand(InteractionHand.MAIN_HAND, filled);
        ItemStack empty = ModItems.MATTER_UNIT_PHASE_LIQUID.get().use(helper.getLevel(), player, InteractionHand.MAIN_HAND).getObject();
        if (!empty.is(ModItems.MATTER_UNIT.get())) {
            helper.fail("filled matter unit should give back an empty one, got " + empty);
        }
        if (!isPhaseSource(helper, liquid)) {
            helper.fail("filled matter unit should place the source on top of the floor");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matterUnitStaticHelpers(GameTestHelper helper) {
        BlockPos rel = new BlockPos(2, 1, 2);
        BlockPos pos = helper.absolutePos(rel);
        if (MatterUnitItem.collect(helper.getLevel(), pos)) {
            helper.fail("collect should fail on air");
        }
        if (!MatterUnitItem.place(helper.getLevel(), pos) || !isPhaseSource(helper, rel)) {
            helper.fail("place should put a source on air");
        }
        if (MatterUnitItem.place(helper.getLevel(), pos)) {
            helper.fail("place should refuse an existing source");
        }
        if (!MatterUnitItem.collect(helper.getLevel(), pos) || !helper.getLevel().getBlockState(pos).isAir()) {
            helper.fail("collect should remove the source");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matterUnitFluidCapability(GameTestHelper helper) {
        IFluidHandlerItem full = new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get()).getCapability(Capabilities.FluidHandler.ITEM);
        IFluidHandlerItem empty = new ItemStack(ModItems.MATTER_UNIT.get()).getCapability(Capabilities.FluidHandler.ITEM);
        if (full == null || empty == null) {
            helper.fail("matter units must expose the fluid handler capability");
            return;
        }
        FluidStack inside = full.getFluidInTank(0);
        if (inside.getAmount() != 1000 || !inside.is(ModFluids.PHASE_LIQUID.get())) {
            helper.fail("filled unit should report 1000 mB of phase liquid, got " + inside);
        }
        if (!empty.getFluidInTank(0).isEmpty() || empty.getTankCapacity(0) != 1000) {
            helper.fail("empty unit should be an empty 1000 mB tank");
        }
        if (empty.fill(new FluidStack(net.minecraft.world.level.material.Fluids.WATER, 1000), IFluidHandler.FluidAction.EXECUTE) != 0) {
            helper.fail("matter unit must reject water");
        }
        if (empty.fill(new FluidStack(ModFluids.PHASE_LIQUID.get(), 1000), IFluidHandler.FluidAction.EXECUTE) != 1000
                || !empty.getContainer().is(ModItems.MATTER_UNIT_PHASE_LIQUID.get())) {
            helper.fail("filling should turn the unit into a filled one");
        }
        FluidStack drained = full.drain(1000, IFluidHandler.FluidAction.EXECUTE);
        if (drained.getAmount() != 1000 || !full.getContainer().is(ModItems.MATTER_UNIT.get())) {
            helper.fail("draining should give 1000 mB and leave an empty unit");
        }
        ItemStack stack = new ItemStack(ModItems.MATTER_UNIT.get(), 2);
        IFluidHandlerItem stacked = stack.getCapability(Capabilities.FluidHandler.ITEM);
        if (stacked != null && stacked.fill(new FluidStack(ModFluids.PHASE_LIQUID.get(), 1000), IFluidHandler.FluidAction.EXECUTE) != 0) {
            helper.fail("a stack of 2 units must not be filled as one (dupe)");
        }

        // A través de FluidUtil, como haría otro mod: recoger del mundo con la unidad.
        BlockPos rel = new BlockPos(1, 1, 1);
        helper.setBlock(rel, ModBlocks.PHASE_LIQUID.get().defaultBlockState());
        FluidActionResult result = FluidUtil.tryPickUpFluid(new ItemStack(ModItems.MATTER_UNIT.get()), null, helper.getLevel(),
                helper.absolutePos(rel), Direction.UP);
        if (!result.isSuccess() || !result.getResult().is(ModItems.MATTER_UNIT_PHASE_LIQUID.get())) {
            helper.fail("FluidUtil pickup with a matter unit should give a filled unit");
        }
        helper.succeed();
    }
}
