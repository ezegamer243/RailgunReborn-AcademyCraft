package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.SolarGenBlockEntity;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModCapabilities;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de los generadores (T100). Los ticks se llaman a mano dentro de un mismo tick de juego para que el
 * reloj y la lluvia no cambien entre medias; el receptor de prueba es un bloque de oro (solo en el servidor de tests).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class GeneratorGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos GEN = new BlockPos(1, 1, 1);
    private static final BlockPos NEIGHBOR = new BlockPos(2, 1, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static SolarGenBlockEntity solar(GameTestHelper helper) {
        helper.setBlock(GEN, ModBlocks.SOLAR_GEN.get().defaultBlockState());
        // El recinto de pruebas tiene un techo de barreras unos bloques más arriba: se quita para ver el cielo.
        for (int i = 1; i <= 8; i++) {
            helper.setBlock(GEN.above(i), Blocks.AIR.defaultBlockState());
        }
        SolarGenBlockEntity be = (SolarGenBlockEntity) helper.getBlockEntity(GEN);
        be.getEnergy().setEnergy(0);
        ModCapabilities.TEST_RECEIVER.setEnergy(0);
        return be;
    }

    private static void tick(GameTestHelper helper, SolarGenBlockEntity be, int times) {
        BlockPos abs = helper.absolutePos(GEN);
        for (int i = 0; i < times; i++) {
            SolarGenBlockEntity.serverTick(helper.getLevel(), abs, be.getBlockState(), be);
        }
    }

    @GameTest(template = EMPTY)
    public static void solarProducesInDaylightWithOpenSky(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        long time = level.getDayTime();
        float rain = level.getRainLevel(1f);
        level.setRainLevel(0f);
        level.setDayTime(1000);
        SolarGenBlockEntity be = solar(helper);
        tick(helper, be, 10);
        int stored = be.getEnergy().getEnergyStored();
        SolarGenBlockEntity.Status status = be.getStatus();
        level.setDayTime(time);
        level.setRainLevel(rain);
        check(helper, status == SolarGenBlockEntity.Status.DAY, "status should be DAY, was " + status);
        check(helper, stored == 30, "3 IF/tick x 10 ticks = 30, got " + stored);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarStopsAtNightAndUnderCover(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        long time = level.getDayTime();
        float rain = level.getRainLevel(1f);
        level.setRainLevel(0f);
        SolarGenBlockEntity be = solar(helper);

        level.setDayTime(13000);
        tick(helper, be, 10);
        int night = be.getEnergy().getEnergyStored();
        SolarGenBlockEntity.Status nightStatus = be.getStatus();

        level.setDayTime(1000);
        helper.setBlock(GEN.above(), Blocks.STONE.defaultBlockState());
        tick(helper, be, 10);
        int covered = be.getEnergy().getEnergyStored();
        SolarGenBlockEntity.Status coveredStatus = be.getStatus();

        level.setDayTime(time);
        level.setRainLevel(rain);
        check(helper, night == 0 && nightStatus == SolarGenBlockEntity.Status.NIGHT,
                "night should give 0 / NIGHT, got " + night + " / " + nightStatus);
        check(helper, covered == 0 && coveredStatus == SolarGenBlockEntity.Status.BLOCKED,
                "covered should give 0 / BLOCKED, got " + covered + " / " + coveredStatus);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarRainMultiplier(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        long time = level.getDayTime();
        float rain = level.getRainLevel(1f);
        level.setRainLevel(1f);
        level.setDayTime(1000);
        SolarGenBlockEntity be = solar(helper);
        tick(helper, be, 100);
        int stored = be.getEnergy().getEnergyStored();
        SolarGenBlockEntity.Status status = be.getStatus();
        level.setDayTime(time);
        level.setRainLevel(rain);
        check(helper, status == SolarGenBlockEntity.Status.RAIN, "status should be RAIN, was " + status);
        check(helper, stored == 60, "0.6 IF/tick x 100 ticks = 60, got " + stored);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarPushesToAdjacentReceiver(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        long time = level.getDayTime();
        level.setDayTime(13000); // de noche: solo se reparte lo que hay en el buffer
        SolarGenBlockEntity be = solar(helper);
        helper.setBlock(NEIGHBOR, Blocks.GOLD_BLOCK.defaultBlockState());
        be.getEnergy().setEnergy(250);
        tick(helper, be, 1);
        int afterOne = ModCapabilities.TEST_RECEIVER.getEnergyStored();
        tick(helper, be, 3);
        level.setDayTime(time);
        check(helper, afterOne == 100, "one tick pushes the 100 bandwidth, got " + afterOne);
        check(helper, ModCapabilities.TEST_RECEIVER.getEnergyStored() == 250,
                "all 250 delivered, got " + ModCapabilities.TEST_RECEIVER.getEnergyStored());
        check(helper, be.getEnergy().getEnergyStored() == 0, "buffer empty, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarCapabilityOnlyExtracts(GameTestHelper helper) {
        solar(helper);
        IEnergyStorage cap = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK,
                helper.absolutePos(GEN), null);
        check(helper, cap != null, "solar should expose an FE capability");
        check(helper, !cap.canReceive() && cap.canExtract(), "extract only");
        check(helper, cap.getMaxEnergyStored() == 1000, "capacity 1000");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarBatterySlotChargesEnergyUnit(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        long time = level.getDayTime();
        level.setDayTime(13000);
        SolarGenBlockEntity be = solar(helper);
        ItemStack unit = new ItemStack(ModItems.ENERGY_UNIT.get());
        check(helper, be.getItems().insertItem(SolarGenBlockEntity.SLOT_BATTERY, unit, false).isEmpty(),
                "energy unit accepted in the battery slot");
        check(helper, !be.getItems().isItemValid(SolarGenBlockEntity.SLOT_BATTERY, new ItemStack(Blocks.DIRT)),
                "dirt is not valid in the battery slot");
        be.getEnergy().setEnergy(500);
        tick(helper, be, 1);
        int unitEnergy = EnergyUnitItem.getEnergy(be.getItems().getStackInSlot(SolarGenBlockEntity.SLOT_BATTERY));
        level.setDayTime(time);
        check(helper, unitEnergy == 20, "unit charges at its 20/tick bandwidth, got " + unitEnergy);
        check(helper, be.getEnergy().getEnergyStored() == 480, "buffer drops by 20, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void catEnginePushes500PerTick(GameTestHelper helper) {
        helper.setBlock(GEN, ModBlocks.CAT_ENGINE.get().defaultBlockState());
        helper.setBlock(NEIGHBOR, Blocks.GOLD_BLOCK.defaultBlockState());
        ModCapabilities.TEST_RECEIVER.setEnergy(0);
        CatEngineBlockEntity be = (CatEngineBlockEntity) helper.getBlockEntity(GEN);
        BlockPos abs = helper.absolutePos(GEN);
        CatEngineBlockEntity.serverTick(helper.getLevel(), abs, be.getBlockState(), be);
        int one = ModCapabilities.TEST_RECEIVER.getEnergyStored();
        CatEngineBlockEntity.serverTick(helper.getLevel(), abs, be.getBlockState(), be);
        int two = ModCapabilities.TEST_RECEIVER.getEnergyStored();
        check(helper, one == 500, "first tick pushes 500, got " + one);
        check(helper, two == 1000, "infinite: second tick pushes another 500, got " + two);
        IEnergyStorage cap = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK, abs, null);
        check(helper, cap != null && cap.extractEnergy(1000, false) == 500, "cable extraction capped at 500 per call");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void solarRecipeLoads(GameTestHelper helper) {
        check(helper, helper.getLevel().getRecipeManager()
                .byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "solar_gen")).isPresent(),
                "solar_gen recipe should load");
        helper.succeed();
    }
}
