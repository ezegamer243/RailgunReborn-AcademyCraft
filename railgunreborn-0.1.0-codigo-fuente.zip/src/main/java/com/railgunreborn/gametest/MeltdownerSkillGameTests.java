package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.MeltdownerRules;
import com.railgunreborn.ability.meltdowner.MeltdownerSkill;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de la habilidad Meltdowner (T46). El rayo mide 50 bloques: siempre se dispara en vertical (hacia arriba,
 * al cielo, o hacia abajo, al suelo de la propia prueba) para no tocar las pruebas vecinas, y {@code mobGriefing} solo
 * se enciende durante la llamada síncrona que dispara. Gólems de hierro como objetivos: no se queman al sol.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MeltdownerSkillGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    private static final float UP = -90f;
    private static final float DOWN = 90f;

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        aim(helper, player, at, pitch);
        return player;
    }

    /** Coloca y orienta al jugador; moveTo no toca la cabeza y la vista (getViewVector) la usa. */
    private static void aim(GameTestHelper helper, ServerPlayer player, Vec3 at, float pitch) {
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        player.setYHeadRot(0f);
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Meltdowner nivel 3 con la habilidad aprendida (exp dada), CP lleno y modo habilidad encendido. */
    private static MeltdownerSkill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(3);
        MeltdownerSkill skill = Meltdowner.MELTDOWNER.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void withMobGriefing(GameTestHelper helper, boolean value, Runnable action) {
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(value, helper.getLevel().getServer());
            action.run();
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
    }

    private static void hold(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static void release(ServerPlayer player) {
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    /** Pulsa, carga {@code ticks}, vuelve a fijar la orientación y suelta; todo síncrono. */
    private static void chargeAndRelease(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks,
            Vec3 at, float pitch) {
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        hold(player, ticks);
        aim(helper, player, at, pitch);
        release(player);
    }

    private static boolean fired(ServerPlayer player, Skill skill) {
        return CooldownData.get(player).getRemaining(skill.getId(), 0) > 0
                || AbilityData.get(player).getSkillExp(skill.getId()) > 0f;
    }

    @GameTest(template = EMPTY)
    public static void meltdownerIsRegisteredAtLevel3(GameTestHelper helper) {
        Skill skill = Meltdowner.MELTDOWNER.get();
        check(helper, skill.getCategoryId().equals(Meltdowner.ID), "belongs to meltdowner");
        check(helper, skill.getLevel() == 3 && skill.canControl(), "level 3, controllable");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Meltdowner.SCATTER_BOMB.getId())
                && Math.abs(skill.getParent().get().minExp() - 0.8f) < EPS, "parent: scatter bomb (0.8)");
        check(helper, skill.getExtraDependencies().size() == 1
                && skill.getExtraDependencies().get(0).skill().equals(Meltdowner.LIGHT_SHIELD.getId())
                && Math.abs(skill.getExtraDependencies().get(0).minExp() - 0.8f) < EPS,
                "extra dependency: light shield (0.8)");
        check(helper, skill.getGuiX() == 115 && skill.getGuiY() == 40, "tree position should be 115, 40");
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Meltdowner.LIGHT_SHIELD.get())
                < AbilityRegistries.SKILL_REGISTRY.getId(skill), "registered after light shield");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAt10TicksDoesNotFire(GameTestHelper helper) {
        floor(helper);
        Vec3 at = new Vec3(4.5, 1, 4.5);
        ServerPlayer player = player(helper, "test-md-early", at, UP);
        MeltdownerSkill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        withMobGriefing(helper, true, () -> {
            check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
            check(helper, Math.abs(cp.getOverload() - MeltdownerRules.initialOverload(0f)) < EPS,
                    "initial overload " + cp.getOverload());
            hold(player, 10);
            aim(helper, player, at, UP);
            release(player);
        });
        check(helper, SkillContexts.active(player).isEmpty(), "release ends the context");
        check(helper, !fired(player, skill), "10 ticks: no shot, no cooldown, no exp");
        check(helper, player.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(MeltdownerSkill.SLOW_MODIFIER_ID)
                == null, "charge slowness is removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void firingAt30TicksHurtsTheMobInLineOnly(GameTestHelper helper) {
        floor(helper);
        IronGolem inLine = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        IronGolem aside = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(0.5, 1, 0.5));
        float inLineBefore = inLine.getHealth();
        float asideBefore = aside.getHealth();
        // Encima del gólem mirando abajo: el rayo se mete en el suelo de esta prueba.
        Vec3 above = new Vec3(4.5, 4, 4.5);
        ServerPlayer player = player(helper, "test-md-hit", above, DOWN);
        MeltdownerSkill skill = setUp(player, 0f);
        withMobGriefing(helper, false, () -> chargeAndRelease(helper, player, skill, 30, above, DOWN));

        float expected = MeltdownerRules.damage(0f, 30) * skill.getDamageScale();
        check(helper, Math.abs(inLine.getHealth() - (inLineBefore - expected)) < EPS,
                "in line: " + inLineBefore + " -> " + inLine.getHealth() + ", expected -" + expected);
        check(helper, aside.getHealth() == asideBefore, "a golem 5.6 blocks off the axis must not be hit");
        int cooldown = CooldownData.get(player).getRemaining(skill.getId(), 0);
        check(helper, cooldown == MeltdownerRules.cooldown(0f, 30), "cooldown " + cooldown);
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, Math.abs(exp - MeltdownerRules.expGain(30)) < 1e-6f, "exp " + exp);
        check(helper, helper.getBlockState(new BlockPos(4, 0, 4)).is(Blocks.STONE),
                "with mobGriefing off the floor must stay");
        helper.succeed();
    }

    /** Losa de piedra 3x3 en y 4-5 sobre el jugador, que mira hacia arriba (al cielo). */
    private static void ceiling(GameTestHelper helper) {
        for (int x = 3; x <= 5; x++) {
            for (int z = 3; z <= 5; z++) {
                helper.setBlock(new BlockPos(x, 4, z), Blocks.STONE);
                helper.setBlock(new BlockPos(x, 5, z), Blocks.STONE);
            }
        }
    }

    @GameTest(template = EMPTY)
    public static void beamBreaksStoneWithMobGriefing(GameTestHelper helper) {
        floor(helper);
        ceiling(helper);
        Vec3 at = new Vec3(4.5, 1, 4.5);
        ServerPlayer player = player(helper, "test-md-break", at, UP);
        MeltdownerSkill skill = setUp(player, 0f);
        withMobGriefing(helper, true, () -> chargeAndRelease(helper, player, skill, 30, at, UP));
        check(helper, fired(player, skill), "the shot should have happened");
        check(helper, helper.getBlockState(new BlockPos(4, 4, 4)).isAir()
                && helper.getBlockState(new BlockPos(4, 5, 4)).isAir(), "stone above should be gone");
        check(helper, helper.getBlockState(new BlockPos(4, 0, 4)).is(Blocks.STONE), "floor under the player stays");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void beamKeepsStoneWithoutMobGriefing(GameTestHelper helper) {
        floor(helper);
        ceiling(helper);
        Vec3 at = new Vec3(4.5, 1, 4.5);
        ServerPlayer player = player(helper, "test-md-nobreak", at, UP);
        MeltdownerSkill skill = setUp(player, 0f);
        withMobGriefing(helper, false, () -> chargeAndRelease(helper, player, skill, 30, at, UP));
        check(helper, fired(player, skill), "the shot should have happened");
        for (int x = 3; x <= 5; x++) {
            for (int z = 3; z <= 5; z++) {
                check(helper, helper.getBlockState(new BlockPos(x, 4, z)).is(Blocks.STONE),
                        "stone at " + x + ",4," + z + " must stay");
            }
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargingPast100TicksCancelsWithoutFiring(GameTestHelper helper) {
        floor(helper);
        Vec3 at = new Vec3(4.5, 1, 4.5);
        ServerPlayer player = player(helper, "test-md-tolerance", at, UP);
        MeltdownerSkill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        withMobGriefing(helper, false, () -> {
            check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
            hold(player, MeltdownerRules.TOLERANCE_TICKS);
            check(helper, !SkillContexts.active(player).isEmpty(), "still charging at 100 ticks");
            check(helper, Math.abs(cp.getOverload() - MeltdownerRules.initialOverload(0f)) < 1f,
                    "overload stays fixed while charging: " + cp.getOverload());
            hold(player, 1);
            check(helper, SkillContexts.active(player).isEmpty(), "cancelled past 100 ticks");
            aim(helper, player, at, UP);
            release(player);
        });
        check(helper, !fired(player, skill), "no shot, no cooldown, no exp");
        check(helper, player.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(MeltdownerSkill.SLOW_MODIFIER_ID)
                == null, "charge slowness is removed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpNoOverloadIsCharged(GameTestHelper helper) {
        floor(helper);
        Vec3 at = new Vec3(4.5, 1, 4.5);
        ServerPlayer player = player(helper, "test-md-nocp", at, UP);
        MeltdownerSkill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP());
        check(helper, cp.getCP() == 0f, "CP drained");
        float overloadBefore = cp.getOverload();
        withMobGriefing(helper, false, () -> SkillContexts.start(player, 1, skill));
        check(helper, SkillContexts.active(player).isEmpty(), "without CP the charge does not start");
        check(helper, cp.getOverload() == overloadBefore, "no overload charged: " + cp.getOverload());
        helper.succeed();
    }
}
