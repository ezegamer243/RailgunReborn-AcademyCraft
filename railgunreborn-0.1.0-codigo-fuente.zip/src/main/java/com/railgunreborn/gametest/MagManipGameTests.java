package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.MagManipRules;
import com.railgunreborn.entity.MagneticBlockEntity;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Magnet Manipulation (T29). Jugador falso en (4.5, 1, 1.5) mirando a +Z (ojos a y ≈ 2.6); los bloques
 * a agarrar van a la altura de los ojos. El contexto se maneja a mano (start / KEY_UP); la entidad del bloque se
 * mueve sola con los ticks del mundo.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MagManipGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    /** Delante de los ojos, ya en el punto de sostén (2 bloques). */
    private static final BlockPos NEAR = new BlockPos(4, 2, 3);

    // --- utilidades (mismo jugador falso que las otras pruebas) ---

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-magmanip-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 2 con Magnet Manipulation aprendida y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(2);
        Skill skill = Electromaster.MAG_MANIP.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData.get(player).setActivated(player, true);
        return skill;
    }

    private static void withMobGriefing(GameTestHelper helper, boolean value, Runnable action) {
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(value, helper.getLevel().getServer());
            action.run();
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static List<MagneticBlockEntity> blocks(GameTestHelper helper) {
        AABB area = new AABB(helper.absolutePos(new BlockPos(-2, -2, -2)).getCenter(),
                helper.absolutePos(new BlockPos(11, 8, 11)).getCenter());
        return helper.getLevel().getEntitiesOfClass(MagneticBlockEntity.class, area, e -> e.isAlive());
    }

    /** Cuenta los bloques de hierro dentro de la zona de la prueba. */
    private static int ironBlocks(GameTestHelper helper) {
        int count = 0;
        for (int x = 0; x < 9; x++) {
            for (int y = 1; y < 6; y++) {
                for (int z = 0; z < 9; z++) {
                    if (helper.getBlockState(new BlockPos(x, y, z)).is(Blocks.IRON_BLOCK)) {
                        count++;
                    }
                }
            }
        }
        return count;
    }

    private static float exp(ServerPlayer player, Skill skill) {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    // --- tests ---

    @GameTest(template = EMPTY)
    public static void magManipIsRegistered(GameTestHelper helper) {
        Skill skill = Electromaster.MAG_MANIP.get();
        check(helper, skill.getLevel() == 2, "level should be 2");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Electromaster.MAG_MOVEMENT.getId())
                && Math.abs(skill.getParent().get().minExp() - 0.5f) < EPS, "parent should be mag_movement (0.5)");
        check(helper, skill.getGuiX() == 204 && skill.getGuiY() == 33, "tree position should be 204, 33");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 100)
    public static void thrownIronHurtsTheFirstZombieOnly(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(NEAR, Blocks.IRON_BLOCK);
        Zombie first = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 6.5));
        Zombie second = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 8.5));
        // Que el sol no los queme: solo debe contar el golpe del bloque.
        first.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000));
        second.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000));
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 1f);
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();

        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, !SkillContexts.active(player).isEmpty(), "an iron block in sight should be grabbed");
        check(helper, helper.getBlockState(NEAR).isAir(), "the grabbed block must leave the world");
        check(helper, blocks(helper).size() == 1, "one magnetic block entity expected");
        check(helper, cp.getCP() == startCP && cp.getOverload() == 0f, "grabbing must be free");

        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, SkillContexts.active(player).isEmpty(), "releasing ends the context");
        check(helper, Math.abs(cp.getCP() - (startCP - MagManipRules.cpCost(1f))) < EPS,
                "CP should drop by 270, was " + startCP + " -> " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - MagManipRules.overloadCost(1f)) < EPS,
                "overload should be 20, was " + cp.getOverload());
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "a throw sets the cooldown");
        check(helper, Math.abs(exp(player, skill) - 1f) < 1e-6f, "exp stays capped at 1");
        float maxHealth = second.getHealth();

        helper.succeedWhen(() -> {
            if (!(first.getHealth() < first.getMaxHealth())) {
                helper.fail("first zombie not hit yet");
            }
            if (!blocks(helper).isEmpty()) {
                helper.fail("the block should have landed");
            }
            check(helper, second.getHealth() == maxHealth, "the block must stop at the first entity");
            check(helper, ironBlocks(helper) == 1, "the iron block must be placed back in the world");
        });
    }

    @GameTest(template = EMPTY, timeoutTicks = 100)
    public static void throwIntoAWallPlacesTheBlock(GameTestHelper helper) {
        floor(helper);
        for (int x = 2; x <= 6; x++) {
            for (int y = 1; y <= 4; y++) {
                helper.setBlock(new BlockPos(x, y, 7), Blocks.STONE);
            }
        }
        helper.setBlock(NEAR, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 1f);
        SkillContexts.start(player, 1, skill);
        check(helper, blocks(helper).size() == 1, "the block should be grabbed");
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "should have been thrown");
        helper.succeedWhen(() -> {
            if (!blocks(helper).isEmpty()) {
                helper.fail("still flying");
            }
            boolean nextToWall = false;
            for (int x = 3; x <= 5; x++) {
                for (int y = 1; y <= 3; y++) {
                    nextToWall |= helper.getBlockState(new BlockPos(x, y, 6)).is(Blocks.IRON_BLOCK);
                }
            }
            check(helper, nextToWall, "the iron block should be placed against the wall (z = 6)");
            check(helper, ironBlocks(helper) == 1, "exactly one iron block expected");
        });
    }

    @GameTest(template = EMPTY)
    public static void noLineOfSightDoesNotGrab(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(new BlockPos(4, 2, 5), Blocks.IRON_BLOCK);
        helper.setBlock(new BlockPos(4, 2, 4), Blocks.GLASS);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        check(helper, SkillContexts.active(player).isEmpty(), "a block behind glass must not be grabbed");
        check(helper, helper.getBlockState(new BlockPos(4, 2, 5)).is(Blocks.IRON_BLOCK), "iron stays in place");
        check(helper, blocks(helper).isEmpty(), "no entity expected");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hopperWithBlockEntityIsNotGrabbed(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(NEAR, Blocks.HOPPER);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 1f);
        SkillContexts.start(player, 1, skill);
        check(helper, SkillContexts.active(player).isEmpty(), "a hopper (block entity) must not be grabbed");
        check(helper, helper.getBlockState(NEAR).is(Blocks.HOPPER), "the hopper stays");
        check(helper, blocks(helper).isEmpty(), "no entity expected");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mobGriefingOffDoesNotRemoveTheBlock(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(NEAR, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        withMobGriefing(helper, false, () -> SkillContexts.start(player, 1, skill));
        check(helper, SkillContexts.active(player).isEmpty(), "with mobGriefing off nothing is grabbed");
        check(helper, helper.getBlockState(NEAR).is(Blocks.IRON_BLOCK), "the iron block stays");
        check(helper, blocks(helper).isEmpty(), "no entity expected");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 100)
    public static void releaseWithoutCpPlacesItBackForFree(GameTestHelper helper) {
        floor(helper);
        helper.setBlock(NEAR, Blocks.IRON_BLOCK);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 10f);
        float startCP = cp.getCP();
        SkillContexts.start(player, 1, skill);
        check(helper, blocks(helper).size() == 1, "grabbing needs no CP");
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, SkillContexts.active(player).isEmpty(), "releasing ends the context");
        check(helper, cp.getCP() == startCP && cp.getOverload() == 0f, "nothing must be charged");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown without a throw");
        check(helper, exp(player, skill) == 0f, "no exp without a throw");
        helper.succeedWhen(() -> {
            if (!blocks(helper).isEmpty()) {
                helper.fail("still falling");
            }
            check(helper, ironBlocks(helper) == 1, "the block must be placed back in the world");
        });
    }

    @GameTest(template = EMPTY)
    public static void blockInHandIsUsedAsAmmo(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_BLOCK, 3));
        SkillContexts.start(player, 1, skill);
        check(helper, !SkillContexts.active(player).isEmpty(), "an iron block in hand should be grabbed");
        check(helper, player.getMainHandItem().getCount() == 2, "one item should be spent");
        List<MagneticBlockEntity> list = blocks(helper);
        check(helper, list.size() == 1 && list.get(0).getBlockState().is(Blocks.IRON_BLOCK),
                "the held entity should carry an iron block");
        // Que no quede nada suelto: se suelta sin lanzar y la entidad se quita.
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_ABORT);
        list.get(0).discard();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void railgunNowNeedsMagManipAtFullExp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(4);
        data.learnSkill(Electromaster.THUNDER_BOLT.getId());
        data.setSkillExp(Electromaster.THUNDER_BOLT.getId(), 0.3f);
        Skill railgun = Electromaster.RAILGUN.get();
        Skill magManip = Electromaster.MAG_MANIP.get();

        DevelopResult without = railgun.checkLearn(data, DeveloperType.ADVANCED);
        check(helper, without == DevelopResult.DEPENDENCY_NOT_MET, "expected DEPENDENCY_NOT_MET, was " + without);
        data.learnSkill(magManip.getId());
        data.setSkillExp(magManip.getId(), 0.99f);
        DevelopResult low = railgun.checkLearn(data, DeveloperType.ADVANCED);
        check(helper, low == DevelopResult.DEPENDENCY_NOT_MET, "exp 0.99 is not enough, was " + low);
        data.setSkillExp(magManip.getId(), 1.0f);
        DevelopResult ok = railgun.checkLearn(data, DeveloperType.ADVANCED);
        check(helper, ok == DevelopResult.OK, "with mag_manip at 1.0 railgun can be learned, was " + ok);
        helper.succeed();
    }
}
