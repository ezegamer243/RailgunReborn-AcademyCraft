package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.teleporter.ThreateningRules;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Threatening Teleport (T57). Jugador falso en (4.5, 1, 1.5) mirando hacia +Z; golem (no se quema). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ThreateningTeleportGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-threatening"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Teleporter nivel 1 con Threatening aprendida (con la exp dada), CP lleno, modo habilidad y {@code stack} en la mano. */
    private static Skill setUp(ServerPlayer player, float exp, ItemStack stack) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(1);
        Skill skill = Teleporter.THREATENING_TELEPORT.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        player.setItemInHand(InteractionHand.MAIN_HAND, stack);
        return skill;
    }

    /** Pulsa, mantiene un tick y suelta. */
    private static void shoot(ServerPlayer player, Skill skill) {
        check0(SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
        SkillContexts.tick(player);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    private static void check0(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static List<ItemEntity> drops(GameTestHelper helper, ItemStack like) {
        AABB area = new AABB(helper.absolutePos(BlockPos.ZERO)).inflate(20);
        return helper.getLevel().getEntitiesOfClass(ItemEntity.class, area, e -> e.getItem().is(like.getItem()));
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel1AndParentOfDimFolding(GameTestHelper helper) {
        Skill skill = Teleporter.THREATENING_TELEPORT.get();
        check(helper, skill.getId().equals(Teleporter.THREATENING_TELEPORT_ID), "id " + skill.getId());
        check(helper, skill.getLevel() == 1 && skill.canControl() && skill.getParent().isEmpty(),
                "level 1, controllable, root");
        check(helper, skill.getGuiX() == 14 && skill.getGuiY() == 42, "gui position 14, 42");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/threatening_teleport.png"),
                "icon " + skill.getIcon());
        check(helper, Teleporter.DIM_FOLDING.get().getParent().map(p -> p.skill().equals(skill.getId())
                && p.minExp() == 0.2f).orElse(false), "dim folding hangs from threatening at 0.2");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hitsTheMobAndDropsTheItem(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(Items.STICK, 3));
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        shoot(player, skill);

        check(helper, Math.abs(before - golem.getHealth() - 3f) < EPS, "3 damage, lost " + (before - golem.getHealth()));
        ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
        check(helper, held.getCount() == 2, "stack drops by 1, was " + held.getCount());
        List<ItemEntity> dropped = drops(helper, new ItemStack(Items.STICK));
        check(helper, dropped.size() == 1 && dropped.get(0).getItem().getCount() == 1, "one stick on the ground");
        check(helper, dropped.get(0).distanceTo(golem) < 1.5f, "the stick falls next to the target");
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 35f) < 0.5f, "CP charged (35 at exp 0)");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 30, "cooldown 30");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - ThreateningRules.EXP_HIT) < 1e-6f,
                "exp +0.003");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void needleDealsOneAndAHalfTimes(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(ModItems.NEEDLE.get(), 2));
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, Math.abs(before - golem.getHealth() - 4.5f) < EPS, "4.5 damage, lost " + (before - golem.getHealth()));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void aWallBlocksTheShotAndCostsNothing(GameTestHelper helper) {
        floor(helper);
        for (int y = 1; y <= 4; y++) {
            for (int x = 2; x <= 7; x++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.STONE);
            }
        }
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(Items.STICK, 3));
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();

        shoot(player, skill);

        check(helper, golem.getHealth() == before, "no damage through the wall");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "item kept");
        check(helper, drops(helper, new ItemStack(Items.STICK)).isEmpty(), "nothing dropped");
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void firingIntoTheAirCostsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, -90f);
        Skill skill = setUp(player, 0f, new ItemStack(Items.STICK, 3));
        float cpBefore = CPData.get(player).getCP();
        shoot(player, skill);
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "item kept");
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void creativeNeitherSpendsNorDropsTheItem(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        player.setGameMode(GameType.CREATIVE);
        Skill skill = setUp(player, 0f, new ItemStack(Items.STICK, 3));
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, golem.getHealth() < before, "still hurts");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "stack untouched");
        check(helper, drops(helper, new ItemStack(Items.STICK)).isEmpty(), "nothing dropped");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void emptyHandDoesNotStart(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, ItemStack.EMPTY);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, golem.getHealth() == before, "no shot without an item");
        helper.succeed();
    }

    private static int run(GameTestHelper helper, ServerPlayer player, String command) {
        try {
            return helper.getLevel().getServer().getCommands().getDispatcher()
                    .execute(command, player.createCommandSourceStack());
        } catch (com.mojang.brigadier.exceptions.CommandSyntaxException e) {
            return Integer.MIN_VALUE;
        }
    }

    @GameTest(template = EMPTY)
    public static void needleOnlyBlocksOtherItems(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(Items.DIAMOND, 3));
        AbilityData.get(player).setNeedleOnly(true);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        float cpBefore = CPData.get(player).getCP();
        shoot(player, skill);
        check(helper, golem.getHealth() == before, "no damage");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "item kept");
        check(helper, drops(helper, new ItemStack(Items.DIAMOND)).isEmpty(), "nothing thrown");
        check(helper, CPData.get(player).getCP() == cpBefore, "no CP spent");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 0, "no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void needleOnlyAllowsTheNeedle(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(ModItems.NEEDLE.get(), 2));
        AbilityData.get(player).setNeedleOnly(true);
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, Math.abs(before - golem.getHealth() - 4.5f) < EPS, "needle still hits");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void needleOnlyOffKeepsAnyItem(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, 0f, new ItemStack(Items.DIAMOND, 3));
        check(helper, !AbilityData.get(player).isNeedleOnly(), "default OFF");
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 5.5));
        float before = golem.getHealth();
        shoot(player, skill);
        check(helper, golem.getHealth() < before, "diamond hits");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 2, "diamond thrown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void needleOnlySurvivesCodecRoundTrip(GameTestHelper helper) {
        ServerPlayer player = player(helper, 0f);
        AbilityData.get(player).setNeedleOnly(true);
        var tag = AbilityData.CODEC.encodeStart(net.minecraft.nbt.NbtOps.INSTANCE, AbilityData.get(player))
                .getOrThrow();
        AbilityData copy = AbilityData.CODEC.parse(net.minecraft.nbt.NbtOps.INSTANCE, tag).getOrThrow();
        check(helper, copy.isNeedleOnly(), "saved as ON");
        // Guardado antiguo sin el campo -> OFF
        AbilityData old = AbilityData.CODEC.parse(net.minecraft.nbt.NbtOps.INSTANCE,
                new net.minecraft.nbt.CompoundTag()).getOrThrow();
        check(helper, !old.isNeedleOnly(), "old saves default to OFF");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void needleOnlyCommandIsOpenAndToggles(GameTestHelper helper) {
        ServerPlayer player = player(helper, 0f);
        check(helper, !player.hasPermissions(2), "mock player is not op");
        check(helper, run(helper, player, "railgunreborn needleonly on") == 1, "on");
        check(helper, AbilityData.get(player).isNeedleOnly(), "stored ON");
        check(helper, run(helper, player, "railgunreborn needleonly") == 1, "show reports ON");
        check(helper, run(helper, player, "railgunreborn needleonly off") == 0, "off");
        check(helper, !AbilityData.get(player).isNeedleOnly(), "stored OFF");
        check(helper, run(helper, player, "railgunreborn info") == Integer.MIN_VALUE,
                "other subcommands still need op");
        helper.succeed();
    }
}
