package com.railgunreborn.gametest;

import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

/** Atajos para los GameTests que usan Developers sin ser pruebas de energía: buffers llenos. */
final class DeveloperEnergyTesting {
    private DeveloperEnergyTesting() {
    }

    /** Llena el buffer del Developer de bloque cuyo controlador está en {@code origin}. */
    static void fill(ServerLevel level, BlockPos origin) {
        if (!(level.getBlockEntity(origin) instanceof DeveloperBlockEntity be)) {
            throw new IllegalStateException("developer block entity missing at " + origin);
        }
        be.getEnergy().setEnergy(be.getEnergy().getMaxEnergyStored());
    }

    static ItemStack chargedPortable() {
        return DeveloperPortableItem.withEnergy(new ItemStack(ModItems.DEVELOPER_PORTABLE.get()),
                DeveloperPortableItem.CAPACITY);
    }
}
