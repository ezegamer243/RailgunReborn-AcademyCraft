package com.railgunreborn.gametest;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.network.WirelessActionPayload;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorBlockEntity.Status;
import com.railgunreborn.reactor.CategoryReactorPartBlock;
import com.railgunreborn.reactor.CategoryReactorStructure;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.MatrixBlockEntity;
import com.railgunreborn.wireless.NodeBlock;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.NodeLinkMenu;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessData;
import com.railgunreborn.wireless.WirelessLinking;
import com.railgunreborn.wireless.WirelessRegistry;
import com.railgunreborn.wireless.WirelessResult;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.AfterBatch;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.registries.DeferredBlock;

/**
 * GameTests de integración de la energía (T108): cadenas completas generador -> nodo de una red -> máquina, solo en el
 * servidor. Cada test usa su propio {@link WirelessData} y lo avanza a mano con {@code onEachTick} (así no se cruza
 * con el de la dimensión). Los de {@code energyRequired = false} van en un lote propio: el override es global.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class EnergyIntegrationGameTests {
    private static final String EMPTY = "empty";
    private static final String FREE_BATCH = "energyIntegrationFree";
    private static final BlockPos MATRIX = new BlockPos(1, 1, 1);
    private static final BlockPos REACTOR_BASE = new BlockPos(4, 1, 4);
    private static final BlockPos REACTOR_CONTROLLER = REACTOR_BASE.above();

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    @AfterBatch(batch = FREE_BATCH)
    public static void restoreConfig(ServerLevel level) {
        RailgunConfig.setEnergyRequiredOverrideForTests(null);
    }

    // --- Utilidades ---

    private static Item core(int tier) {
        return switch (tier) {
            case 1 -> WirelessRegistry.MAT_CORE_0.get();
            case 2 -> WirelessRegistry.MAT_CORE_1.get();
            default -> WirelessRegistry.MAT_CORE_2.get();
        };
    }

    /** Matriz con las 3 placas y un núcleo del nivel dado, y la red "net" / "pw" creada con {@code data}. */
    private static BlockPos network(GameTestHelper helper, WirelessData data, int tier) {
        BlockPos abs = helper.absolutePos(MATRIX);
        WirelessRegistry.MATRIX.get().place(helper.getLevel(), abs);
        MatrixBlockEntity be = (MatrixBlockEntity) helper.getLevel().getBlockEntity(abs);
        for (int slot = 0; slot < MatrixBlockEntity.PLATE_SLOTS; slot++) {
            be.getItems().setStackInSlot(slot, new ItemStack(ModItems.CONSTRAINT_PLATE.get()));
        }
        be.getItems().setStackInSlot(MatrixBlockEntity.SLOT_CORE, new ItemStack(core(tier)));
        check(helper, data.createNetwork(helper.getLevel(), abs, "net", "pw").ok(), "network created");
        return abs;
    }

    /** Nodo con contraseña "np" ya unido a la red de {@code matrix}. */
    private static NodeBlockEntity joinedNode(GameTestHelper helper, WirelessData data, BlockPos matrix, BlockPos rel,
            DeferredBlock<NodeBlock> type) {
        helper.setBlock(rel, type.get().defaultBlockState());
        NodeBlockEntity node = (NodeBlockEntity) helper.getBlockEntity(rel);
        node.setPassword("np");
        check(helper, data.joinNetwork(helper.getLevel(), node.getBlockPos(), matrix, "pw").ok(), "node joined");
        return node;
    }

    private static CatEngineBlockEntity catEngine(GameTestHelper helper, BlockPos rel) {
        helper.setBlock(rel, ModBlocks.CAT_ENGINE.get().defaultBlockState());
        return (CatEngineBlockEntity) helper.getBlockEntity(rel);
    }

    private static ImagFusorBlockEntity loadedFusor(GameTestHelper helper, BlockPos rel) {
        helper.setBlock(rel, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        ImagFusorBlockEntity be = (ImagFusorBlockEntity) helper.getBlockEntity(rel);
        be.getEnergy().setEnergy(0);
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_INPUT, new ItemStack(ModItems.CRYSTAL_LOW.get()));
        be.getItems().setStackInSlot(ImagFusorBlockEntity.SLOT_UNIT_IN,
                new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get(), 3));
        return be;
    }

    private static CategoryReactorBlockEntity buildReactor(GameTestHelper helper, ServerPlayer player) {
        BlockPos base = helper.absolutePos(REACTOR_BASE);
        if (!CategoryReactorStructure.build(helper.getLevel(), base, player)) {
            throw new IllegalStateException("the reactor could not be built");
        }
        return (CategoryReactorBlockEntity) helper.getLevel()
                .getBlockEntity(CategoryReactorStructure.controllerFromBase(base));
    }

    private static void readyReactor(CategoryReactorBlockEntity reactor) {
        reactor.getFluidHandler().fill(new FluidStack(ModFluids.PHASE_LIQUID.get(),
                CategoryReactorBlockEntity.TANK_CAPACITY), IFluidHandler.FluidAction.EXECUTE);
        reactor.getItems().setStackInSlot(0, InductionFactorItem.of(Teleporter.ID));
    }

    private static WirelessActionPayload link(BlockPos user, BlockPos node, String password) {
        return new WirelessActionPayload(WirelessActions.Action.USER_LINK, user, Optional.of(node), password, "");
    }

    // --- Reactor y «Nodo actual» (T108) ---

    /** El reactor se enlaza por su controlador, se haga el gesto en el controlador o en cualquiera de las 26 piezas. */
    @GameTest(template = EMPTY)
    public static void reactorLinksToNodeViaHandlerFromAnyPart(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        ServerPlayer player = RailgunGameTests.player(helper);
        buildReactor(helper, player);
        BlockPos controller = helper.absolutePos(REACTOR_CONTROLLER);
        helper.setBlock(new BlockPos(1, 1, 1), WirelessRegistry.NODE_BASIC.get().defaultBlockState());
        NodeBlockEntity node = (NodeBlockEntity) helper.getBlockEntity(new BlockPos(1, 1, 1));
        node.setPassword("k");
        BlockPos nodePos = node.getBlockPos();

        int parts = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos pos = controller.offset(dx, dy, dz);
                    check(helper, controller.equals(WirelessLinking.linkTarget(level, pos)),
                            "every piece resolves to the controller, failed at " + dx + "," + dy + "," + dz);
                    if (level.getBlockState(pos).getBlock() instanceof CategoryReactorPartBlock) {
                        parts++;
                    }
                }
            }
        }
        check(helper, parts == 26, "26 parts expected, got " + parts);

        BlockPos corner = controller.offset(1, -1, -1);
        var view = NodeLinkMenu.buildView(level, data, controller);
        check(helper, view.entries().stream().anyMatch(e -> e.pos().equals(nodePos)), "node listed for the reactor");
        check(helper, WirelessActions.handle(player, link(corner, nodePos, "bad"), data)
                == WirelessResult.WRONG_PASSWORD, "wrong node password");
        check(helper, WirelessActions.handle(player, link(corner, nodePos, "k"), data).ok(), "link from a part");
        check(helper, nodePos.equals(data.nodeOfUser(controller)), "linked through its controller");
        check(helper, data.linksOf(nodePos).getReceivers().contains(controller), "the reactor is a receiver");
        check(helper, WirelessActions.handle(player,
                new WirelessActionPayload(WirelessActions.Action.USER_UNLINK, corner, Optional.empty(), "", ""), data)
                .ok() && data.nodeOfUser(controller) == null, "unlink from a part");
        helper.succeed();
    }

    // --- Cadenas completas ---

    /** Cat Engine -> nodo -> Imag Fusor (en una red): el Fusor sin buffer propio termina un cristal normal. */
    @GameTest(template = EMPTY, timeoutTicks = 500)
    public static void catEngineToNodeToFusorMakesCrystal(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos matrix = network(helper, data, 1);
        NodeBlockEntity node = joinedNode(helper, data, matrix, new BlockPos(6, 1, 1), WirelessRegistry.NODE_BASIC);
        CatEngineBlockEntity engine = catEngine(helper, new BlockPos(6, 1, 6));
        ImagFusorBlockEntity fusor = loadedFusor(helper, new BlockPos(1, 1, 6));
        check(helper, data.linkUser(level, engine.getBlockPos(), node.getBlockPos(), "np").ok(), "link engine");
        check(helper, data.linkUser(level, fusor.getBlockPos(), node.getBlockPos(), "np").ok(), "link fusor");
        helper.onEachTick(() -> data.tick(level));
        helper.succeedWhen(() -> {
            helper.assertTrue(fusor.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CRYSTAL_NORMAL.get()), "no crystal yet");
        });
    }

    /** Cat Engine -> nodo -> Developer normal: llega la energía estimada y el jugador obtiene categoría gastando 3500. */
    @GameTest(template = EMPTY, timeoutTicks = 400)
    public static void catEngineToNodeToDeveloperLevelsUpPlayer(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos matrix = network(helper, data, 1);
        NodeBlockEntity node = joinedNode(helper, data, matrix, new BlockPos(7, 1, 1), WirelessRegistry.NODE_BASIC);
        CatEngineBlockEntity engine = catEngine(helper, new BlockPos(7, 1, 7));
        BlockPos developer = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_NORMAL.get().place(level, developer, Direction.SOUTH);
        DeveloperBlockEntity be = (DeveloperBlockEntity) level.getBlockEntity(developer);
        check(helper, data.linkUser(level, engine.getBlockPos(), node.getBlockPos(), "np").ok(), "link engine");
        check(helper, data.linkUser(level, developer, node.getBlockPos(), "np").ok(), "link developer");
        ServerPlayer player = RailgunGameTests.player(helper);
        helper.onEachTick(() -> data.tick(level));
        helper.succeedWhen(() -> {
            helper.assertTrue(be.getEnergy().getEnergyStored() >= 5 * 700, "waiting for the network energy");
            int before = be.getEnergy().getEnergyStored();
            DeveloperMenu menu = DeveloperMenu.open(player, DeveloperType.NORMAL, developer);
            check(helper, menu != null, "developer should open");
            check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "should start");
            for (int i = 0; i < DevelopRules.totalTicks(5, DeveloperType.NORMAL); i++) {
                menu.serverTick(player);
            }
            check(helper, menu.getResult() == DevelopResult.OK, "should finish, was " + menu.getResult());
            check(helper, AbilityData.get(player).hasCategory(), "the player got a category");
            check(helper, be.getEnergy().getEnergyStored() == before - 5 * 700, "exact cost taken from the buffer");
        });
    }

    /** Tres nodos de distinto tamaño en la misma red acaban con el mismo porcentaje y la energía se conserva. */
    @GameTest(template = EMPTY)
    public static void threeNodeTypesBalanceToSamePercentage(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos matrix = network(helper, data, 3);
        NodeBlockEntity basic = joinedNode(helper, data, matrix, new BlockPos(6, 1, 1), WirelessRegistry.NODE_BASIC);
        NodeBlockEntity standard = joinedNode(helper, data, matrix, new BlockPos(6, 1, 4),
                WirelessRegistry.NODE_STANDARD);
        NodeBlockEntity advanced = joinedNode(helper, data, matrix, new BlockPos(6, 1, 7),
                WirelessRegistry.NODE_ADVANCED);
        basic.getEnergy().setEnergy(0);
        standard.getEnergy().setEnergy(0);
        advanced.getEnergy().setEnergy(100_000);
        for (int i = 0; i < 1500; i++) {
            data.tick(level);
        }
        int a = basic.getEnergy().getEnergyStored();
        int b = standard.getEnergy().getEnergyStored();
        int c = advanced.getEnergy().getEnergyStored();
        int buffer = data.getNetwork(matrix).getBuffer();
        check(helper, a + b + c + buffer == 100_000, "energy must be conserved, got " + (a + b + c + buffer));
        double pa = a / (double) basic.getEnergy().getMaxEnergyStored();
        double pb = b / (double) standard.getEnergy().getMaxEnergyStored();
        double pc = c / (double) advanced.getEnergy().getMaxEnergyStored();
        check(helper, Math.abs(pa - pc) < 0.02 && Math.abs(pb - pc) < 0.02,
                "same fill percentage expected, got " + pa + " / " + pb + " / " + pc);
        check(helper, a > 0 && b > 0, "the small nodes received energy");
        helper.succeed();
    }

    /** Nodos con energía de sobra cargan el reactor (tope de 1000/tick) hasta 500 000 y entonces se puede activar. */
    @GameTest(template = EMPTY, timeoutTicks = 1500)
    public static void networkChargesReactorToFullThenActivates(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos matrix = network(helper, data, 3);
        NodeBlockEntity feeder = joinedNode(helper, data, matrix, new BlockPos(7, 1, 1),
                WirelessRegistry.NODE_ADVANCED);
        NodeBlockEntity bank = joinedNode(helper, data, matrix, new BlockPos(7, 1, 7), WirelessRegistry.NODE_ADVANCED);
        feeder.getEnergy().setEnergy(0);
        bank.getEnergy().setEnergy(200_000);
        ServerPlayer player = RailgunGameTests.player(helper);
        AbilityData abilities = AbilityData.get(player);
        abilities.setCategory(Electromaster.ID);
        abilities.setLevel(3);
        CategoryReactorBlockEntity reactor = buildReactor(helper, player);
        readyReactor(reactor);
        reactor.getEnergy().setEnergy(400_000);
        BlockPos controller = helper.absolutePos(REACTOR_CONTROLLER);
        check(helper, data.linkUser(level, controller, feeder.getBlockPos(), "np").ok(), "link reactor");
        check(helper, reactor.tryActivate(player) == Status.NEED_ENERGY, "not full yet");

        helper.onEachTick(() -> data.tick(level));
        helper.succeedWhen(() -> {
            helper.assertTrue(reactor.getEnergy().getEnergyStored() == CategoryReactorBlockEntity.ENERGY_CAPACITY,
                    "reactor has " + reactor.getEnergy().getEnergyStored());
            check(helper, reactor.tryActivate(player) == Status.READY, "full reactor must activate");
            check(helper, reactor.getEnergy().getEnergyStored() == 0, "the buffer is emptied");
            check(helper, abilities.getCategory().filter(Teleporter.ID::equals).isPresent(), "now a teleporter");
        });
    }

    // --- energyRequired = false ---

    /** Sin energía requerida, el Fusor y el reactor funcionan aunque la red esté vacía y no se les saque nada. */
    @GameTest(template = EMPTY, timeoutTicks = 500, batch = FREE_BATCH)
    public static void freeModeWorksWithEmptyNetwork(GameTestHelper helper) {
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos matrix = network(helper, data, 1);
        NodeBlockEntity node = joinedNode(helper, data, matrix, new BlockPos(6, 1, 1), WirelessRegistry.NODE_BASIC);
        ImagFusorBlockEntity fusor = loadedFusor(helper, new BlockPos(1, 1, 6));
        check(helper, data.linkUser(level, fusor.getBlockPos(), node.getBlockPos(), "np").ok(), "link fusor");
        ServerPlayer player = RailgunGameTests.player(helper);
        AbilityData abilities = AbilityData.get(player);
        abilities.setCategory(Electromaster.ID);
        abilities.setLevel(3);
        CategoryReactorBlockEntity reactor = buildReactor(helper, player);
        readyReactor(reactor);
        check(helper, reactor.tryActivate(player) == Status.READY, "the reactor needs no energy");
        helper.onEachTick(() -> data.tick(level));
        helper.succeedWhen(() -> {
            helper.assertTrue(fusor.getItems().getStackInSlot(ImagFusorBlockEntity.SLOT_OUTPUT)
                    .is(ModItems.CRYSTAL_NORMAL.get()), "no crystal yet");
            check(helper, node.getEnergy().getEnergyStored() == 0 && fusor.getEnergy().getEnergyStored() == 0,
                    "nothing should move in free mode");
        });
    }
}
