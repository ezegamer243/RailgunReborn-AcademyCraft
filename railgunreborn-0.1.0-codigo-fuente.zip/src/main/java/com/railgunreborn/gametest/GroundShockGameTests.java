package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.GroundShockRules;
import com.railgunreborn.ability.vecmanip.GroundShockSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Ground Shock (T70). Estructura propia {@code ground_shock} de 32×6×16: la onda va hacia +x por la
 * fila z = 8 y nunca sale de ella (exp 0: 10 pasos; exp 1: 25 pasos desde x = 6 y barrido x/z de 1 a 10). Todas las
 * tiradas se fijan a 0.5: pasan la casilla central y las de ±1, no las de ±2 ni la rotura del suelo.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class GroundShockGameTests {
    private static final String STRUCTURE = "ground_shock";
    private static final int ID = 1;
    private static final float EAST = -90f;
    private static final int ROW = 8;
    private static final float EPS = 1e-4f;

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        player.setOnGround(true);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper, Block block) {
        for (int x = 0; x < 32; x++) {
            for (int z = 0; z < 16; z++) {
                helper.setBlock(new BlockPos(x, 0, z), block);
            }
        }
    }

    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(1);
        Skill skill = VecManip.GROUND_SHOCK.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, mantiene {@code ticks} ticks y suelta, con las tiradas fijas. */
    private static void use(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        GroundShockSkill.rollOverride = () -> 0.5;
        try {
            check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
            for (int i = 0; i < ticks; i++) {
                SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
                SkillContexts.tick(player);
            }
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
            check(helper, SkillContexts.find(player, skill).isEmpty(), "releasing ends the context");
        } finally {
            GroundShockSkill.rollOverride = null;
        }
    }

    private static void withGriefing(GameTestHelper helper, boolean mobGriefing, Runnable action) {
        MinecraftServer server = helper.getLevel().getServer();
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(mobGriefing, server);
            action.run();
        } finally {
            rule.set(original, server);
        }
    }

    private static boolean is(GameTestHelper helper, int x, int y, int z, Block block) {
        return helper.getBlockState(new BlockPos(x, y, z)).is(block);
    }

    private static IronGolem golem(GameTestHelper helper, double x) {
        return helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(x, 1, ROW + 0.5));
    }

    // --- pruebas ---

    @GameTest(template = STRUCTURE)
    public static void groundShockIsRegistered(GameTestHelper helper) {
        Skill skill = AbilityRegistries.skill(VecManip.skillId("ground_shock")).orElse(null);
        check(helper, skill == VecManip.GROUND_SHOCK.get(), "ground_shock registered");
        check(helper, skill.getCategoryId().equals(VecManip.ID) && skill.getLevel() == 1, "vecmanip level 1");
        check(helper, skill.getParent().map(p -> p.skill().equals(VecManip.skillId("dir_shock"))
                && p.minExp() == 0f).orElse(false), "parent dir_shock 0.0");
        check(helper, skill.getGuiX() == 64 && skill.getGuiY() == 85, "gui position 64, 85");
        check(helper, VecManip.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/ground_shock.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    @GameTest(template = STRUCTURE)
    public static void waveTurnsStoneToCobbleAndLaunchesAGolem(GameTestHelper helper) {
        floor(helper, Blocks.STONE);
        ServerPlayer player = player(helper, "test-gs-wave", new Vec3(2.5, 1, ROW + 0.5), EAST, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = golem(helper, 6.5);
        float cpBefore = CPData.get(player).getCP();
        withGriefing(helper, true, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS));

        // exp 0: 10 pasos (x 3..12), central y laterales ±1.
        for (int x = 3; x <= 12; x++) {
            check(helper, is(helper, x, 0, ROW, Blocks.COBBLESTONE), "center x=" + x + " should be cobblestone");
            check(helper, is(helper, x, 0, ROW - 1, Blocks.COBBLESTONE) && is(helper, x, 0, ROW + 1,
                    Blocks.COBBLESTONE), "sides ±1 at x=" + x + " should be cobblestone");
            check(helper, is(helper, x, 0, ROW - 2, Blocks.STONE) && is(helper, x, 0, ROW + 2, Blocks.STONE),
                    "sides ±2 at x=" + x + " failed their roll and stay stone");
        }
        check(helper, is(helper, 13, 0, ROW, Blocks.STONE), "the wave stops after 10 steps");
        check(helper, is(helper, 2, 0, ROW, Blocks.STONE), "the block under the feet is not part of the wave");

        check(helper, golem.getHealth() <= golem.getMaxHealth() - 4f + EPS,
                "golem takes 4 damage, health " + golem.getHealth());
        double expected = GroundShockRules.launchSpeed(0f, 0.5);
        check(helper, Math.abs(golem.getDeltaMovement().y - expected) < 1e-3,
                "golem launched up at " + expected + ", was " + golem.getDeltaMovement());
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - GroundShockRules.cp(0f)) < 0.01f,
                "costs 80 CP");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 80, "cooldown 80");
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, Math.abs(exp - (GroundShockRules.EXP_USE + GroundShockRules.EXP_PER_HIT)) < 1e-5f,
                "exp 0.001 + 0.002 for the golem, was " + exp);
        golem.discard();
        helper.succeed();
    }

    @GameTest(template = STRUCTURE)
    public static void withoutMobGriefingBlocksStayButMobsAreHit(GameTestHelper helper) {
        floor(helper, Blocks.STONE);
        helper.setBlock(new BlockPos(5, 1, ROW), Blocks.DIRT);
        ServerPlayer player = player(helper, "test-gs-nogrief", new Vec3(2.5, 1, ROW + 0.5), EAST, 0f);
        Skill skill = setUp(player, 0f);
        IronGolem golem = golem(helper, 8.5);
        withGriefing(helper, false, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS));

        for (int x = 3; x <= 12; x++) {
            for (int z = ROW - 2; z <= ROW + 2; z++) {
                check(helper, is(helper, x, 0, z, Blocks.STONE), "no block changes at " + x + ", " + z);
            }
        }
        check(helper, is(helper, 5, 1, ROW, Blocks.DIRT), "the column is not cleared");
        check(helper, golem.getHealth() < golem.getMaxHealth(), "the golem is still hurt");
        check(helper, golem.getDeltaMovement().y > 0.4, "and launched: " + golem.getDeltaMovement());
        golem.discard();
        helper.succeed();
    }

    @GameTest(template = STRUCTURE)
    public static void columnBreaksSoftBlocksButNeverAChest(GameTestHelper helper) {
        floor(helper, Blocks.STONE);
        helper.setBlock(new BlockPos(5, 1, ROW), Blocks.CHEST);
        helper.setBlock(new BlockPos(7, 1, ROW), Blocks.DIRT);
        helper.setBlock(new BlockPos(7, 2, ROW), Blocks.OAK_PLANKS);
        ServerPlayer player = player(helper, "test-gs-chest", new Vec3(2.5, 1, ROW + 0.5), EAST, 0f);
        Skill skill = setUp(player, 0f);
        withGriefing(helper, true, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS));

        check(helper, is(helper, 5, 1, ROW, Blocks.CHEST), "the chest is never broken");
        check(helper, helper.getBlockState(new BlockPos(7, 1, ROW)).isAir()
                && helper.getBlockState(new BlockPos(7, 2, ROW)).isAir(), "dirt and planks in the column break");
        AABB area = new AABB(helper.absolutePos(new BlockPos(6, 0, ROW - 1)))
                .expandTowards(2, 3, 2);
        check(helper, !helper.getLevel().getEntitiesOfClass(ItemEntity.class, area).isEmpty(),
                "broken blocks drop their items");
        helper.getLevel().getEntitiesOfClass(ItemEntity.class, area).forEach(ItemEntity::discard);
        helper.succeed();
    }

    @GameTest(template = STRUCTURE)
    public static void maxExpSweepKeepsTheBlockUnderTheFeet(GameTestHelper helper) {
        floor(helper, Blocks.GRASS_BLOCK);
        ServerPlayer player = player(helper, "test-gs-sweep", new Vec3(6.5, 1, ROW + 0.5), EAST, 0f);
        Skill skill = setUp(player, 1f);
        withGriefing(helper, true, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS));

        check(helper, !helper.getBlockState(new BlockPos(6, 0, ROW)).isAir(), "the block under the feet stays");
        check(helper, helper.getBlockState(new BlockPos(2, 0, 4)).isAir()
                && helper.getBlockState(new BlockPos(10, 0, 12)).isAir()
                && helper.getBlockState(new BlockPos(1, 0, 3)).isAir(), "soft ground in the 10×10 is swept");
        check(helper, is(helper, 0, 0, ROW, Blocks.GRASS_BLOCK) && is(helper, 6, 0, 13, Blocks.GRASS_BLOCK),
                "outside the 10×10 nothing changes");
        check(helper, is(helper, 20, 0, ROW, Blocks.DIRT), "further along the wave turns grass into dirt");
        AABB area = new AABB(helper.absolutePos(new BlockPos(1, 0, 3))).expandTowards(10, 2, 10);
        check(helper, !helper.getLevel().getEntitiesOfClass(ItemEntity.class, area).isEmpty(),
                "the sweep drops what it breaks");
        helper.getLevel().getEntitiesOfClass(ItemEntity.class, area).forEach(ItemEntity::discard);
        helper.succeed();
    }

    @GameTest(template = STRUCTURE)
    public static void shortHoldOrAirborneDoesNothing(GameTestHelper helper) {
        floor(helper, Blocks.STONE);
        ServerPlayer player = player(helper, "test-gs-noop", new Vec3(2.5, 1, ROW + 0.5), EAST, 0f);
        Skill skill = setUp(player, 0f);
        float cp = CPData.get(player).getCP();
        withGriefing(helper, true, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS - 1));
        check(helper, CPData.get(player).getCP() == cp && !CooldownData.get(player).isInCooldown(skill.getId()),
                "a short hold costs nothing");
        player.setOnGround(false);
        withGriefing(helper, true, () -> use(helper, player, skill, GroundShockRules.MIN_HOLD_TICKS));
        check(helper, CPData.get(player).getCP() == cp && !CooldownData.get(player).isInCooldown(skill.getId()),
                "in the air nothing happens");
        check(helper, is(helper, 3, 0, ROW, Blocks.STONE), "and the ground is untouched");
        helper.succeed();
    }
}
