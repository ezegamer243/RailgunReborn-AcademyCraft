package com.railgunreborn.gametest;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.BeamReflect;
import com.railgunreborn.ability.common.BeamReflectEvent;
import com.railgunreborn.ability.context.SkillContext;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.RailgunRules;
import com.railgunreborn.ability.electromaster.RailgunSkill;
import com.railgunreborn.ability.generic.GenericRules;
import com.railgunreborn.ability.meltdowner.Meltdowner;
import com.railgunreborn.ability.meltdowner.MeltdownerRules;
import com.railgunreborn.ability.meltdowner.MeltdownerSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.ability.vecmanip.VecTargets;
import com.railgunreborn.ability.vecmanip.VecTargetsRules.Verdict;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.vehicle.Minecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de la categoría Vector Manipulation y sus piezas compartidas (T68): registro, contextos de interruptor
 * (con Flashing, el único interruptor por ahora), {@link VecTargets} y {@link BeamReflectEvent} en Railgun y
 * Meltdowner. Los rayos se disparan en vertical hacia arriba, como en sus propias pruebas.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class VecManipGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    private static final float UP = -90f;

    /** Etiqueta de jugador que hace que {@link TestReflector} cancele el evento (solo para estas pruebas). */
    private static final String REFLECTOR_TAG = "railgunreborn.test_beam_reflector";
    private static final Map<UUID, BeamReflectEvent> SEEN = new ConcurrentHashMap<>();
    private static final Map<UUID, BeamReflect.Counter> COUNTERS = new ConcurrentHashMap<>();

    /** Reflector de prueba: refleja solo a jugadores con {@link #REFLECTOR_TAG} y hace el contragolpe. */
    @EventBusSubscriber(modid = RailgunReborn.MODID)
    public static final class TestReflector {
        private TestReflector() {
        }

        @SubscribeEvent
        public static void onBeamReflect(BeamReflectEvent event) {
            ServerPlayer target = event.getTarget();
            SEEN.put(target.getUUID(), event);
            if (!target.getTags().contains(REFLECTOR_TAG)) {
                return;
            }
            event.setCanceled(true);
            COUNTERS.put(target.getUUID(),
                    BeamReflect.counterAttack(target, event.getCounterDamage(), DamageTypes.PLAYER_ATTACK));
        }
    }

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static int run(ServerPlayer player, String command) {
        try {
            return player.server.getCommands().getDispatcher().execute(command,
                    player.createCommandSourceStack().withPermission(4).withSuppressedOutput());
        } catch (CommandSyntaxException e) {
            return 0;
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /**
     * Ejecuta con mobGriefing y PvP fijados y los restaura (todo síncrono: ninguna otra prueba corre en medio). El
     * servidor de GameTests arranca con el PvP apagado, y sin PvP los rayos ni dañan ni preguntan a los jugadores.
     */
    private static void withRules(GameTestHelper helper, boolean mobGriefing, boolean pvp, Runnable action) {
        MinecraftServer server = helper.getLevel().getServer();
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean originalGriefing = rule.get();
        boolean originalPvp = server.isPvpAllowed();
        try {
            rule.set(mobGriefing, server);
            server.setPvpAllowed(pvp);
            action.run();
        } finally {
            rule.set(originalGriefing, server);
            server.setPvpAllowed(originalPvp);
        }
    }

    // --- Registro ---

    @GameTest(template = EMPTY)
    public static void vecManipCategoryIsRegistered(GameTestHelper helper) {
        Category category = AbilityRegistries.category(VecManip.ID).orElse(null);
        check(helper, category != null, "vecmanip category should be registered");
        check(helper, category == VecManip.CATEGORY.get(), "registry entry should be the holder's");
        check(helper, AbilityRegistries.CATEGORY_REGISTRY.size() >= 4,
                "the Developer picks among the 4 categories, found " + AbilityRegistries.CATEGORY_REGISTRY.size());
        check(helper, category.getColor() == VecManip.COLOR && (category.getColor() >>> 24) > 0,
                "category color must be visible (alpha > 0)");
        check(helper, category.getProgIncrRate() == 1.0f, "prog_incr_rate 1.0");
        check(helper, category.getIcon().getPath().equals("textures/category/vecmanip_icon.png"),
                "icon path " + category.getIcon());
        for (GenericRules.Kind kind : GenericRules.Kind.values()) {
            check(helper, VecManip.GENERICS.get(kind).get().getCategoryId().equals(VecManip.ID),
                    "generic " + kind + " registered for vecmanip");
            check(helper, category.getSkills().contains(VecManip.GENERICS.get(kind).get()),
                    "generic " + kind + " listed in the category");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void commandSetsVecManip(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-command", new Vec3(4.5, 1, 1.5), 0f, 0f);
        check(helper, run(player, "railgunreborn category vecmanip") > 0, "category command should succeed");
        AbilityData ability = AbilityData.get(player);
        check(helper, ability.getCategory().map(VecManip.ID::equals).orElse(false),
                "category should be vecmanip, was " + ability.getCategory());
        helper.succeed();
    }

    // --- Contextos de interruptor (Flashing es interruptor) ---

    private static Skill toggleSetUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(5);
        Skill skill = Teleporter.FLASHING.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static boolean alive(ServerPlayer player, Skill skill) {
        return SkillContexts.find(player, skill).isPresent();
    }

    /** Pulsa y suelta: el interruptor queda abierto. */
    private static void toggleOn(GameTestHelper helper, ServerPlayer player, Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        check(helper, alive(player, skill), "releasing the key must not end a toggle");
    }

    @GameTest(template = EMPTY)
    public static void toggleSurvivesKeyUpAndClosesFromTheClient(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-toggle", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = toggleSetUp(player);
        check(helper, skill.isToggle(), "flashing is a toggle");
        check(helper, !Meltdowner.MELTDOWNER.get().isToggle() && !Electromaster.RAILGUN.get().isToggle(),
                "hold-to-use skills are not toggles");
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContext ctx = SkillContexts.find(player, skill).orElseThrow();
        check(helper, ctx.isKeyHeld(), "the key starts held");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_ABORT);
        check(helper, !ctx.isTerminated(), "an aborted key must not end a toggle");
        // Sin la tecla mantenida, el keep-alive del cliente lo mantiene vivo más allá del timeout.
        ping(player, SkillContexts.KEEP_ALIVE_TIMEOUT + 15);
        check(helper, alive(player, skill) && !ctx.isKeyHeld(), "alive without the key while pinged");
        // Volver a pulsar la tecla o V: el cliente lo cierra y avisa.
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, ctx.isTerminated() && !alive(player, skill), "the second press closes it");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleTimesOutWithoutKeepAlive(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-toggle-timeout", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = toggleSetUp(player);
        toggleOn(helper, player, skill);
        for (int i = 0; i < SkillContexts.KEEP_ALIVE_TIMEOUT; i++) {
            SkillContexts.tick(player);
        }
        check(helper, alive(player, skill), "still alive right at the timeout");
        SkillContexts.tick(player);
        check(helper, !alive(player, skill), "ends after the timeout without pings");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleEndsOnOverload(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-toggle-overload", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = toggleSetUp(player);
        toggleOn(helper, player, skill);
        ping(player, 3);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, cp.getMaxOverload() * 2f, 0f);
        check(helper, cp.isOverloaded(), "the player should be overloaded");
        ping(player, 1);
        check(helper, !alive(player, skill), "overload ends the toggle");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleEndsOnDeath(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-toggle-death", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = toggleSetUp(player);
        toggleOn(helper, player, skill);
        player.setHealth(0f);
        player.die(player.damageSources().generic());
        check(helper, !alive(player, skill), "death ends the toggle");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleEndsOnDimensionChange(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-toggle-dim", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = toggleSetUp(player);
        toggleOn(helper, player, skill);
        ServerLevel nether = helper.getLevel().getServer().getLevel(Level.NETHER);
        check(helper, nether != null, "the nether exists");
        player.teleportTo(nether, 0.5, 100, 0.5, 0f, 0f);
        check(helper, !alive(player, skill), "changing dimension ends the toggle");
        helper.succeed();
    }

    // --- VecTargets ---

    private static Arrow arrow(GameTestHelper helper, Vec3 at, Vec3 motion) {
        Arrow arrow = helper.spawn(EntityType.ARROW, at);
        arrow.setNoGravity(true);
        arrow.setDeltaMovement(motion);
        return arrow;
    }

    private static Verdict verdict(Entity entity, ServerPlayer owner) {
        return VecTargets.classify(entity, owner).verdict();
    }

    @GameTest(template = EMPTY)
    public static void onlyMovingForeignProjectilesAreAffected(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-targets", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Vec3 fast = new Vec3(0, 0, 0.5);

        Arrow flying = arrow(helper, new Vec3(2.5, 2, 2.5), fast);
        VecTargets.Affection affection = VecTargets.classify(flying, player);
        check(helper, affection.affected() && Math.abs(affection.difficulty() - 1.0f) < EPS,
                "a flying arrow is affected with difficulty 1, was " + affection);

        Arrow stuck = arrow(helper, new Vec3(2.5, 2, 6.5), Vec3.ZERO);
        check(helper, verdict(stuck, player) == Verdict.STILL, "a still arrow is not: " + verdict(stuck, player));

        Arrow own = arrow(helper, new Vec3(6.5, 2, 2.5), fast);
        own.setOwner(player);
        check(helper, verdict(own, player) == Verdict.OWN, "own arrow is not: " + verdict(own, player));
        check(helper, verdict(own, null) == Verdict.AFFECTED, "without an owner to compare it is affected");

        Arrow marked = arrow(helper, new Vec3(6.5, 2, 6.5), fast);
        check(helper, !VecTargets.isMarked(marked), "fresh arrows are not marked");
        VecTargets.mark(marked);
        check(helper, VecTargets.isMarked(marked) && verdict(marked, player) == Verdict.MARKED,
                "a marked arrow is never affected again");

        ItemEntity item = helper.spawnItem(Items.STONE, new Vec3(1.5, 2, 4.5));
        item.setDeltaMovement(fast);
        check(helper, verdict(item, player) == Verdict.EXCLUDED, "items are excluded: " + verdict(item, player));

        ExperienceOrb orb = helper.spawn(EntityType.EXPERIENCE_ORB, new Vec3(7.5, 2, 4.5));
        orb.setDeltaMovement(fast);
        check(helper, verdict(orb, player) == Verdict.EXCLUDED, "xp orbs are excluded: " + verdict(orb, player));

        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 7.5));
        zombie.setDeltaMovement(fast);
        check(helper, verdict(zombie, player) == Verdict.LIVING, "living entities never: " + verdict(zombie, player));

        Minecart cart = helper.spawn(EntityType.MINECART, new Vec3(4.5, 1, 1.5));
        cart.setDeltaMovement(fast);
        check(helper, verdict(cart, player) == Verdict.NOT_PROJECTILE,
                "a moving minecart is not a projectile (affected_extra is empty): " + verdict(cart, player));

        for (Entity e : new Entity[] {flying, stuck, own, marked, item, orb, cart}) {
            e.discard();
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void difficultiesComeFromTheDataMap(GameTestHelper helper) {
        check(helper, Math.abs(VecTargets.difficulty(EntityType.ARROW) - 1.0f) < EPS, "arrow 1.0");
        check(helper, Math.abs(VecTargets.difficulty(EntityType.SPECTRAL_ARROW) - 1.0f) < EPS, "spectral arrow 1.0");
        check(helper, Math.abs(VecTargets.difficulty(EntityType.POTION) - 1.4f) < EPS,
                "potion 1.4, was " + VecTargets.difficulty(EntityType.POTION));
        check(helper, Math.abs(VecTargets.difficulty(EntityType.SNOWBALL) - 0.1f) < EPS,
                "snowball 0.1, was " + VecTargets.difficulty(EntityType.SNOWBALL));
        check(helper, Math.abs(VecTargets.difficulty(EntityType.EGG) - 1.0f) < EPS, "unlisted types default to 1.0");
        check(helper, EntityType.ITEM.is(VecTargets.EXCLUDED) && EntityType.EXPERIENCE_BOTTLE.is(VecTargets.EXCLUDED)
                && EntityType.EYE_OF_ENDER.is(VecTargets.EXCLUDED), "excluded tag is loaded");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void inRangeUsesASphereFromTheFeet(GameTestHelper helper) {
        ServerPlayer player = player(helper, "test-vm-range", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Arrow near = arrow(helper, new Vec3(4.5, 1, 7.5), new Vec3(0, 0, -0.5));
        Arrow still = arrow(helper, new Vec3(5.5, 1, 4.5), Vec3.ZERO);
        check(helper, VecTargets.inRange(player, 5).contains(near), "an arrow 3 blocks away is in range 5");
        check(helper, !VecTargets.inRange(player, 2).contains(near), "but not in range 2");
        check(helper, !VecTargets.inRange(player, 5).contains(still), "still arrows are filtered out");
        check(helper, !VecTargets.inRange(player, 5).contains(player), "never the player");
        near.discard();
        still.discard();
        helper.succeed();
    }

    // --- BeamReflectEvent ---

    /** Electromaster nivel 4 con Railgun (exp 0), modo hierro y un lingote en la mano. */
    private static RailgunSkill railgunSetUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(4);
        RailgunSkill railgun = Electromaster.RAILGUN.get();
        ability.learnSkill(railgun.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        player.addTag(RailgunSkill.IRON_MODE_TAG);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_INGOT, 1));
        return railgun;
    }

    private static void fireRailgun(GameTestHelper helper, ServerPlayer player, RailgunSkill railgun, boolean pvp) {
        withRules(helper, false, pvp, () -> {
            check(helper, SkillContexts.start(player, ID, railgun) == StartResult.OK, "start should be accepted");
            for (int i = 0; i < RailgunRules.HOLD_TICKS; i++) {
                SkillContexts.tick(player);
            }
        });
    }

    /**
     * Tirador en el suelo mirando arriba; un jugador justo encima (en el aire) mirando a +Z, un zombi más arriba en
     * la misma línea y un cerdo a 4 bloques en la mirada del jugador del medio (fuera del cilindro del rayo).
     *
     * <p>El jugador del medio es nuevo: tiene la invulnerabilidad de aparición (60 ticks; su tick no corre), así que
     * el daño directo a él no se puede medir: se mide si el evento llega, si se cancela y si el rayo sigue.
     */
    private record BeamScene(ServerPlayer shooter, ServerPlayer middle, Zombie behind, Pig counterTarget) {
    }

    private static BeamScene beamScene(GameTestHelper helper, String name, boolean reflector) {
        floor(helper);
        ServerPlayer shooter = player(helper, name + "-a", new Vec3(4.5, 1, 4.5), 0f, UP);
        ServerPlayer middle = player(helper, name + "-b", new Vec3(4.5, 2.65, 4.5), 0f, 0f);
        if (reflector) {
            middle.addTag(REFLECTOR_TAG);
        }
        Zombie behind = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 5, 4.5));
        Pig pig = helper.spawnWithNoFreeWill(EntityType.PIG, new Vec3(4.5, 3.5, 8.5));
        return new BeamScene(shooter, middle, behind, pig);
    }

    @GameTest(template = EMPTY)
    public static void withoutPvpTheEventIsNotPosted(GameTestHelper helper) {
        BeamScene scene = beamScene(helper, "test-vm-rg-nopvp", true);
        RailgunSkill railgun = railgunSetUp(scene.shooter());
        fireRailgun(helper, scene.shooter(), railgun, false);
        check(helper, !SEEN.containsKey(scene.middle().getUUID()), "PvP off: players are skipped, no event");
        check(helper, scene.behind().isDeadOrDying(), "the beam goes on and kills the zombie behind");
        check(helper, !COUNTERS.containsKey(scene.middle().getUUID()), "no counter attack");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void railgunEventNotCancelledKeepsTheBeam(GameTestHelper helper) {
        BeamScene scene = beamScene(helper, "test-vm-rg-plain", false);
        RailgunSkill railgun = railgunSetUp(scene.shooter());
        float pigBefore = scene.counterTarget().getHealth();
        fireRailgun(helper, scene.shooter(), railgun, true);
        BeamReflectEvent event = SEEN.get(scene.middle().getUUID());
        check(helper, event != null && !event.isCanceled(), "the event is posted for the player and not cancelled");
        check(helper, scene.behind().isDeadOrDying(), "the beam goes on and kills the zombie behind");
        check(helper, scene.counterTarget().getHealth() == pigBefore, "no counter attack");
        float exp = AbilityData.get(scene.shooter()).getSkillExp(railgun.getId());
        check(helper, Math.abs(exp - RailgunRules.EXP_HIT) < 1e-6f, "hit exp as before: " + exp);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void cancelledEventCutsTheRailgunBeam(GameTestHelper helper) {
        BeamScene scene = beamScene(helper, "test-vm-rg-reflect", true);
        RailgunSkill railgun = railgunSetUp(scene.shooter());
        float middleBefore = scene.middle().getHealth();
        float zombieBefore = scene.behind().getHealth();
        float pigBefore = scene.counterTarget().getHealth();
        fireRailgun(helper, scene.shooter(), railgun, true);

        BeamReflectEvent event = SEEN.get(scene.middle().getUUID());
        check(helper, event != null && event.isCanceled(), "the event reached the listener and was cancelled");
        check(helper, event.getCaster() == scene.shooter() && event.getSkill() == railgun,
                "caster and skill in the event");
        check(helper, Math.abs(event.getCounterDamage() - RailgunRules.REFLECT_DAMAGE) < EPS, "railgun counter 14");
        check(helper, Math.abs(event.getDamage() - RailgunRules.damage(0f)) < EPS, "beam damage " + event.getDamage());
        check(helper, scene.middle().getHealth() == middleBefore, "the reflector is not hurt");
        check(helper, scene.behind().getHealth() == zombieBefore, "the beam stops at the reflector");
        BeamReflect.Counter counter = COUNTERS.get(scene.middle().getUUID());
        check(helper, counter != null && counter.hit() == scene.counterTarget() && counter.hurt(),
                "the counter attack hits the pig the reflector looks at: " + counter);
        check(helper, scene.counterTarget().getHealth() < pigBefore, "the pig takes the counter damage");
        float exp = AbilityData.get(scene.shooter()).getSkillExp(railgun.getId());
        check(helper, Math.abs(exp - RailgunRules.EXP_EMPTY) < 1e-6f, "a reflected shot hits nobody: exp " + exp);
        helper.succeed();
    }

    /** Meltdowner nivel 3 (exp 0), CP lleno, carga 30 ticks y suelta, con mobGriefing y PvP. */
    private static MeltdownerSkill fireMeltdowner(GameTestHelper helper, ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Meltdowner.ID);
        ability.setLevel(3);
        MeltdownerSkill skill = Meltdowner.MELTDOWNER.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        Vec3 at = helper.absoluteVec(new Vec3(4.5, 1, 4.5));
        withRules(helper, true, true, () -> {
            check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
            ping(player, 30);
            player.moveTo(at.x, at.y, at.z, 0f, UP);
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        });
        return skill;
    }

    /** Losa de piedra en y 6-7 sobre el tirador: sin reflejo el rayo la rompe. */
    private static void ceiling(GameTestHelper helper) {
        for (int x = 3; x <= 5; x++) {
            for (int z = 3; z <= 5; z++) {
                helper.setBlock(new BlockPos(x, 6, z), Blocks.STONE);
                helper.setBlock(new BlockPos(x, 7, z), Blocks.STONE);
            }
        }
    }

    @GameTest(template = EMPTY)
    public static void cancelledEventCutsTheMeltdownerBeamAndTunnel(GameTestHelper helper) {
        BeamScene scene = beamScene(helper, "test-vm-md-reflect", true);
        ceiling(helper);
        float middleBefore = scene.middle().getHealth();
        float zombieBefore = scene.behind().getHealth();
        MeltdownerSkill skill = fireMeltdowner(helper, scene.shooter());

        BeamReflectEvent event = SEEN.get(scene.middle().getUUID());
        check(helper, event != null && event.isCanceled() && event.getSkill() == skill,
                "the event reached the listener and was cancelled");
        check(helper, Math.abs(event.getCounterDamage() - MeltdownerRules.reflectDamage(0f)) < EPS,
                "meltdowner counter " + event.getCounterDamage());
        check(helper, Math.abs(event.getDamage() - MeltdownerRules.damage(0f, 30)) < EPS,
                "beam damage " + event.getDamage());
        check(helper, scene.middle().getHealth() == middleBefore, "the reflector is not hurt");
        check(helper, scene.behind().getHealth() == zombieBefore, "the beam stops at the reflector");
        check(helper, helper.getBlockState(new BlockPos(4, 6, 4)).is(Blocks.STONE)
                && helper.getBlockState(new BlockPos(4, 7, 4)).is(Blocks.STONE), "the tunnel stops too");
        BeamReflect.Counter counter = COUNTERS.get(scene.middle().getUUID());
        check(helper, counter != null && counter.hit() == scene.counterTarget() && counter.hurt(),
                "the counter attack hits the pig: " + counter);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void meltdownerEventNotCancelledBreaksTheCeiling(GameTestHelper helper) {
        BeamScene scene = beamScene(helper, "test-vm-md-plain", false);
        ceiling(helper);
        float zombieBefore = scene.behind().getHealth();
        fireMeltdowner(helper, scene.shooter());
        BeamReflectEvent event = SEEN.get(scene.middle().getUUID());
        check(helper, event != null && !event.isCanceled(), "the event is posted for the player and not cancelled");
        check(helper, scene.behind().getHealth() < zombieBefore, "the zombie behind is hurt too");
        check(helper, helper.getBlockState(new BlockPos(4, 6, 4)).isAir(), "the tunnel goes through the ceiling");
        helper.succeed();
    }
}
