package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.BodyIntensifyRules;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de Body Intensify (T30). Los ticks del contexto se dan a mano con {@link SkillContexts#tick}. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class BodyIntensifyGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 3 con Body Intensify aprendida (exp 0) y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(3);
        Skill skill = Electromaster.BODY_INTENSIFY.get();
        ability.learnSkill(skill.getId());
        CPData.get(player).setActivated(player, true);
        return skill;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void tick(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.tick(player);
        }
    }

    @GameTest(template = EMPTY)
    public static void bodyIntensifyIsRegisteredAtLevel3(GameTestHelper helper) {
        Skill skill = Electromaster.BODY_INTENSIFY.get();
        check(helper, skill.getLevel() == 3, "level should be 3");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(Electromaster.ARC_GEN.getId())
                && Math.abs(skill.getParent().get().minExp() - 1.0f) < EPS, "parent should be arc_gen (1.0)");
        check(helper, skill.getGuiX() == 97 && skill.getGuiY() == 15, "tree position should be 97, 15");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingBeforeTenTicksDoesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        tick(player, BodyIntensifyRules.MIN_TICKS - 1);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
        check(helper, SkillContexts.active(player).isEmpty(), "release should end the context");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown when cancelled");
        check(helper, !player.hasEffect(MobEffects.HUNGER), "no hunger when cancelled");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp when cancelled");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingAtThirtyTicksGivesEffectsAndCooldown(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float startCP = cp.getCP();
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        float expectedOverload = BodyIntensifyRules.overloadCost(0f);
        check(helper, Math.abs(cp.getOverload() - expectedOverload) < EPS,
                "initial overload should be 200, was " + cp.getOverload());

        int ticks = 30;
        tick(player, ticks);
        float expectedCP = startCP - ticks * BodyIntensifyRules.cpPerTick(0f);
        check(helper, Math.abs(cp.getCP() - expectedCP) < EPS, "CP should be " + expectedCP + ", was " + cp.getCP());
        check(helper, Math.abs(cp.getOverload() - expectedOverload) < EPS,
                "overload must not change while held, was " + cp.getOverload());
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);

        check(helper, SkillContexts.active(player).isEmpty(), "release should end the context");
        boolean anyBuff = player.hasEffect(MobEffects.MOVEMENT_SPEED) || player.hasEffect(MobEffects.DAMAGE_BOOST)
                || player.hasEffect(MobEffects.JUMP) || player.hasEffect(MobEffects.DAMAGE_RESISTANCE)
                || player.hasEffect(MobEffects.REGENERATION);
        check(helper, anyBuff, "at 30 ticks at least one buff is guaranteed");
        var hunger = player.getEffect(MobEffects.HUNGER);
        check(helper, hunger != null && hunger.getAmplifier() == 2 && hunger.getDuration() == 37,
                "hunger III of 37 ticks expected");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) > 0, "cooldown should be set");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - 0.01f) < 1e-6f,
                "exp should be 0.01");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void holdingForHundredTicksCancelsWithoutEffects(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player);
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        // El cliente real manda KEEP_ALIVE; sin el, el servidor corta a los 30 ticks.
        for (int i = 0; i < BodyIntensifyRules.TIMEOUT_TICKS - 1; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            tick(player, 1);
        }
        check(helper, !SkillContexts.active(player).isEmpty(), "still alive before 100 ticks");
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "100 ticks should cancel");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown on timeout");
        check(helper, !player.hasEffect(MobEffects.HUNGER), "no hunger on timeout");
        helper.succeed();
    }
}
