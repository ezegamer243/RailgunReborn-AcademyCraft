package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.vecmanip.VecDeviationRules;
import com.railgunreborn.ability.vecmanip.VecDeviationSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.ability.vecmanip.VecTargets;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.DragonFireball;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Vector Deviation (T72). Jugador falso en (4.5, 1, 1.5) mirando a +Z; los proyectiles vienen de +Z
 * hacia él, sin gravedad para que la velocidad medida sea solo la del campo.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class VecDeviationGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    private static final Vec3 TOWARDS_PLAYER = new Vec3(0, 0, -0.5);

    private static ServerPlayer player(GameTestHelper helper, Vec3 at) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-vd-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar.
        player.setYHeadRot(0f);
        return player;
    }

    private static ServerPlayer player(GameTestHelper helper) {
        return player(helper, new Vec3(4.5, 1, 1.5));
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Vector Manipulation nivel 2 con Vector Deviation (exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(2);
        Skill skill = VecManip.VEC_DEVIATION.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Pulsa y suelta la tecla: el campo queda activo (sin ningún tick todavía). */
    private static VecDeviationSkill.VecDeviationContext turnOn(GameTestHelper helper, ServerPlayer player,
            Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        VecDeviationSkill.VecDeviationContext field = VecDeviationSkill.activeField(player);
        check(helper, field != null, "the field should be active after releasing the key");
        return field;
    }

    private static Arrow arrow(GameTestHelper helper, Vec3 at, Vec3 motion) {
        Arrow arrow = helper.spawn(EntityType.ARROW, at);
        arrow.setNoGravity(true);
        arrow.setDeltaMovement(motion);
        return arrow;
    }

    // --- Registro ---

    @GameTest(template = EMPTY)
    public static void vecDeviationIsRegisteredAtLevel2UnderVecAccel(GameTestHelper helper) {
        Skill skill = VecManip.VEC_DEVIATION.get();
        check(helper, skill.getCategoryId().equals(VecManip.ID), "belongs to vecmanip");
        check(helper, skill.getLevel() == 2 && skill.canControl(), "level 2, controllable");
        check(helper, skill.isToggle(), "it is a toggle");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(VecManip.VEC_ACCEL.getId())
                && Math.abs(skill.getParent().get().minExp()) < EPS, "parent: vec_accel (0.0)");
        check(helper, skill.getGuiX() == 145 && skill.getGuiY() == 53, "tree position should be 145, 53");
        check(helper, VecManip.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/vec_deviation.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    // --- Interruptor y coste ---

    @GameTest(template = EMPTY)
    public static void keyTurnsTheFieldOnAndOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        VecDeviationSkill.VecDeviationContext field = turnOn(helper, player, skill);
        check(helper, Math.abs(cp.getOverload() - VecDeviationRules.initialOverload(0f)) < EPS,
                "activating adds the initial overload, was " + cp.getOverload());
        float cpBefore = cp.getCP();
        ping(player, 5);
        check(helper, !field.isTerminated(), "still active without holding the key");
        check(helper, Math.abs(cpBefore - cp.getCP() - 5 * VecDeviationRules.cpPerTick(0f)) < 0.01f,
                "18 CP per tick, spent " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - (VecDeviationRules.initialOverload(0f)
                + 5 * VecDeviationRules.overloadPerTick(0f))) < 0.01f, "overload grows every tick: " + cp.getOverload());
        // Segunda pulsación (o V): el cliente lo cierra y avisa.
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, field.isTerminated() && VecDeviationSkill.activeField(player) == null,
                "pressing the key again turns it off");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fieldTurnsOffWhenOverloaded(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        VecDeviationSkill.VecDeviationContext field = turnOn(helper, player, skill);
        // Deja 5 de margen: a 0.5 por tick se llena en 10 ticks.
        cp.consumeWithForce(player, cp.getMaxOverload() - cp.getOverload() - 5f, 0f);
        ping(player, 5);
        check(helper, !field.isTerminated() && !cp.isOverloaded(), "still on after 5 ticks");
        ping(player, 10);
        check(helper, cp.isOverloaded(), "the growing overload fills up");
        check(helper, field.isTerminated() && VecDeviationSkill.activeField(player) == null,
                "the field turns itself off when overloaded");
        helper.succeed();
    }

    // --- Proyectiles ---

    @GameTest(template = EMPTY)
    public static void arrowTowardsThePlayerIsStopped(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        Arrow near = arrow(helper, new Vec3(4.5, 1.5, 4.5), TOWARDS_PLAYER);
        Arrow far = arrow(helper, new Vec3(4.5, 1.5, 8.7), TOWARDS_PLAYER);
        VecDeviationSkill.VecDeviationContext field = turnOn(helper, player, skill);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        ping(player, 1);
        check(helper, near.getDeltaMovement().lengthSqr() < 1e-9, "the arrow 3 blocks away stops");
        check(helper, near.getBaseDamage() == 0.0, "and its damage drops to 0");
        check(helper, VecTargets.isMarked(near), "and it is marked");
        check(helper, far.getDeltaMovement().equals(TOWARDS_PLAYER), "the arrow 7 blocks away keeps flying");
        check(helper, field.stoppedCount() == 1, "one entity stopped, was " + field.stoppedCount());
        float spent = cpBefore - cp.getCP();
        float expected = VecDeviationRules.cpPerTick(0f) + VecDeviationRules.entityCost(0f, 1f);
        check(helper, Math.abs(spent - expected) < 0.01f, "tick + arrow cost " + expected + ", spent " + spent);
        float exp = AbilityData.get(player).getSkillExp(skill.getId());
        check(helper, exp > 0f, "stopping an arrow gives exp");
        // Ya marcada: no se vuelve a procesar (ni se cobra).
        ping(player, 1);
        check(helper, field.stoppedCount() == 1, "a stopped arrow is processed once");
        near.discard();
        far.discard();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ownArrowAndMobsAreNotAffected(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        Arrow own = arrow(helper, new Vec3(4.5, 1.5, 4.5), TOWARDS_PLAYER);
        own.setOwner(player);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(6.5, 1, 3.5));
        zombie.setDeltaMovement(TOWARDS_PLAYER);
        VecDeviationSkill.VecDeviationContext field = turnOn(helper, player, skill);
        ping(player, 1);
        check(helper, own.getDeltaMovement().equals(TOWARDS_PLAYER) && !VecTargets.isMarked(own),
                "the player's own arrow keeps flying");
        check(helper, zombie.getDeltaMovement().equals(TOWARDS_PLAYER), "living mobs are never stopped");
        check(helper, field.stoppedCount() == 0, "nothing stopped");
        own.discard();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void selfPropelledProjectilesAreRemovedWithoutExploding(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0f);
        LargeFireball fireball = helper.spawn(EntityType.FIREBALL, new Vec3(4.5, 1.5, 4.5));
        fireball.setDeltaMovement(TOWARDS_PLAYER);
        WitherSkull skull = helper.spawn(EntityType.WITHER_SKULL, new Vec3(3.5, 1.5, 4.5));
        skull.setDeltaMovement(TOWARDS_PLAYER);
        DragonFireball dragon = helper.spawn(EntityType.DRAGON_FIREBALL, new Vec3(5.5, 1.5, 4.5));
        dragon.setDeltaMovement(TOWARDS_PLAYER);
        VecDeviationSkill.VecDeviationContext field = turnOn(helper, player, skill);
        ping(player, 1);
        for (Entity e : new Entity[] {fireball, skull, dragon}) {
            check(helper, e.isRemoved(), e.getType().getDescriptionId() + " should be removed (it would resume)");
        }
        check(helper, field.stoppedCount() == 3, "three projectiles handled, was " + field.stoppedCount());
        for (int x = 2; x <= 6; x++) {
            for (int z = 2; z <= 6; z++) {
                check(helper, helper.getBlockState(new BlockPos(x, 0, z)).is(Blocks.STONE),
                        "no explosion: the floor is intact at " + x + ", " + z);
            }
        }
        check(helper, player.getHealth() == player.getMaxHealth(), "no explosion damage");
        helper.succeed();
    }

    // --- Daño ---

    /** Gasta la protección de aparición (60 ticks) del jugador falso. */
    private static void burnSpawnProtection(ServerPlayer player) {
        for (int i = 0; i < 61; i++) {
            player.tick();
        }
        player.invulnerableTime = 0;
        player.setHealth(20f);
    }

    /** Golpe con {@code attacker} como entidad directa y sin causante: así no escala con la dificultad. */
    private static void hit(ServerPlayer player, Entity attacker, float amount) {
        player.invulnerableTime = 0;
        player.setHealth(20f);
        DamageSource source = new DamageSource(player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(DamageTypes.MOB_ATTACK), attacker, null);
        player.hurt(source, amount);
    }

    @GameTest(template = EMPTY)
    public static void damageIsReducedOnlyForTheOwner(GameTestHelper helper) {
        ServerPlayer owner = player(helper);
        ServerPlayer other = player(helper, new Vec3(1.5, 1, 1.5));
        burnSpawnProtection(owner);
        burnSpawnProtection(other);
        Skill skill = setUp(owner, 0f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 6.5));
        turnOn(helper, owner, skill);
        ping(owner, 1);
        CPData cp = CPData.get(owner);
        float cpBefore = cp.getCP();
        hit(owner, zombie, 10f);
        check(helper, Math.abs(owner.getHealth() - (20f - VecDeviationRules.reducedDamage(10f, 0f))) < EPS,
                "40% less damage at exp 0: health " + owner.getHealth());
        check(helper, Math.abs(cpBefore - cp.getCP() - VecDeviationRules.hitCost(0f)) < 0.01f,
                "a reduced hit costs 15 CP");
        hit(other, zombie, 10f);
        check(helper, Math.abs(other.getHealth() - 10f) < EPS,
                "someone else's field does not protect: health " + other.getHealth());

        // A exp 1 se elimina el 90 %.
        AbilityData.get(owner).setSkillExp(skill.getId(), 1f);
        SkillContexts.handleAction(owner, ID, SkillContextActionPayload.Action.TERMINATE);
        CPData.get(owner).recoverAll();
        turnOn(helper, owner, skill);
        ping(owner, 1);
        hit(owner, zombie, 10f);
        check(helper, Math.abs(owner.getHealth() - 19f) < EPS, "90% less damage at exp 1: " + owner.getHealth());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutTheFieldDamageIsNotReduced(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        burnSpawnProtection(player);
        Skill skill = setUp(player, 0f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 6.5));
        turnOn(helper, player, skill);
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        hit(player, zombie, 10f);
        check(helper, Math.abs(player.getHealth() - 10f) < EPS, "field off: full damage " + player.getHealth());
        helper.succeed();
    }
}
