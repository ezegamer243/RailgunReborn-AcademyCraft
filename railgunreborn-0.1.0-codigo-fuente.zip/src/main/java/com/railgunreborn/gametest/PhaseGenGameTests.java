package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.PhaseGenBlock;
import com.railgunreborn.block.PhaseGenBlockEntity;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModCapabilities;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests del generador de fase (T101). Los ticks se llaman a mano. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class PhaseGenGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos GEN = new BlockPos(1, 1, 1);
    private static final BlockPos NEIGHBOR = new BlockPos(2, 1, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static PhaseGenBlockEntity gen(GameTestHelper helper) {
        helper.setBlock(GEN, ModBlocks.PHASE_GEN.get().defaultBlockState());
        PhaseGenBlockEntity be = (PhaseGenBlockEntity) helper.getBlockEntity(GEN);
        be.getEnergy().setEnergy(0);
        ModCapabilities.TEST_RECEIVER.setEnergy(0);
        return be;
    }

    private static void tick(GameTestHelper helper, PhaseGenBlockEntity be, int times) {
        BlockPos abs = helper.absolutePos(GEN);
        for (int i = 0; i < times; i++) {
            PhaseGenBlockEntity.serverTick(helper.getLevel(), abs, be.getBlockState(), be);
        }
    }

    private static void fill(PhaseGenBlockEntity be, int mb) {
        be.getTank().setFluid(mb <= 0 ? FluidStack.EMPTY : new FluidStack(ModFluids.PHASE_LIQUID.get(), mb));
    }

    @GameTest(template = EMPTY)
    public static void burnsHalfIfPerMbUpTo100PerTick(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        fill(be, 8000);
        tick(helper, be, 1);
        check(helper, be.getTank().getFluidAmount() == 7900, "100 mB burned in one tick, tank " + be.getTank().getFluidAmount());
        check(helper, be.getEnergy().getEnergyStored() == 50, "50 IF per tick, got " + be.getEnergy().getEnergyStored());
        tick(helper, be, 9);
        // el buffer empuja a vecinos solo si los hay: aquí no, así que se acumula
        check(helper, be.getTank().getFluidAmount() == 7000, "1000 mB after 10 ticks, tank " + be.getTank().getFluidAmount());
        check(helper, be.getEnergy().getEnergyStored() == 500, "500 IF after 10 ticks, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void stopsWhenTankEmpty(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        fill(be, 130);
        tick(helper, be, 5);
        check(helper, be.getTank().isEmpty(), "tank empty");
        check(helper, be.getEnergy().getEnergyStored() == 65, "130 mB x 0.5 = 65 IF, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void doesNotWasteLiquidWhenBufferFull(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        fill(be, 2000);
        be.getEnergy().setEnergy(PhaseGenBlockEntity.CAPACITY);
        tick(helper, be, 5);
        check(helper, be.getTank().getFluidAmount() == 2000, "full buffer: nothing burned, tank " + be.getTank().getFluidAmount());

        // Casi lleno: solo se quema lo que cabe.
        be.getEnergy().setEnergy(PhaseGenBlockEntity.CAPACITY - 30);
        tick(helper, be, 1);
        int stored = be.getEnergy().getEnergyStored();
        int burned = 2000 - be.getTank().getFluidAmount();
        check(helper, stored == PhaseGenBlockEntity.CAPACITY, "buffer topped up, got " + stored);
        check(helper, burned >= 59 && burned <= 61, "about 60 mB burned for 30 IF, got " + burned);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matterUnitAndBucketExchange(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        be.getItems().setStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get()));
        tick(helper, be, 1);
        check(helper, be.getItems().getStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_IN).isEmpty(), "filled unit consumed");
        ItemStack out = be.getItems().getStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_OUT);
        check(helper, out.is(ModItems.MATTER_UNIT.get()) && out.getCount() == 1, "empty unit returned, got " + out);
        // Entran 1000 y se queman 100 en el mismo tick.
        check(helper, be.getTank().getFluidAmount() == 900, "1000 in, 100 burned: 900, got " + be.getTank().getFluidAmount());

        fill(be, 0);
        be.getItems().setStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_OUT, ItemStack.EMPTY);
        be.getItems().setStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.PHASE_LIQUID_BUCKET.get()));
        tick(helper, be, 1);
        check(helper, be.getItems().getStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_OUT).is(Items.BUCKET), "bucket returned empty");

        // Sin sitio en el depósito no entra la unidad.
        fill(be, 8000);
        be.getEnergy().setEnergy(PhaseGenBlockEntity.CAPACITY);
        be.getItems().setStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_OUT, ItemStack.EMPTY);
        be.getItems().setStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_IN, new ItemStack(ModItems.MATTER_UNIT_PHASE_LIQUID.get()));
        tick(helper, be, 1);
        check(helper, !be.getItems().getStackInSlot(PhaseGenBlockEntity.SLOT_UNIT_IN).isEmpty(), "unit stays when the tank is full");
        check(helper, !be.getItems().isItemValid(PhaseGenBlockEntity.SLOT_UNIT_IN, new ItemStack(Items.WATER_BUCKET)),
                "water bucket is not valid");
        check(helper, !be.getItems().isItemValid(PhaseGenBlockEntity.SLOT_UNIT_OUT, new ItemStack(ModItems.MATTER_UNIT.get())),
                "output slot takes nothing from outside");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void pushesEnergyToAdjacentReceiver(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        helper.setBlock(NEIGHBOR, Blocks.GOLD_BLOCK.defaultBlockState());
        fill(be, 1000);
        tick(helper, be, 4);
        // Cada tick genera 50 y empuja 50 (su ancho de banda).
        int received = ModCapabilities.TEST_RECEIVER.getEnergyStored();
        check(helper, received == 200, "4 ticks x 50 IF delivered, got " + received);
        check(helper, be.getEnergy().getEnergyStored() == 0, "buffer empty, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void capabilitiesAreRestricted(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        BlockPos abs = helper.absolutePos(GEN);
        var energy = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK, abs, null);
        check(helper, energy != null && !energy.canReceive() && energy.canExtract(), "FE extract only");
        IFluidHandler fluid = helper.getLevel().getCapability(Capabilities.FluidHandler.BLOCK, abs, null);
        check(helper, fluid != null, "fluid capability present");
        check(helper, fluid.fill(new FluidStack(net.minecraft.world.level.material.Fluids.WATER, 500),
                IFluidHandler.FluidAction.EXECUTE) == 0, "rejects water");
        check(helper, fluid.fill(new FluidStack(ModFluids.PHASE_LIQUID.get(), 500), IFluidHandler.FluidAction.EXECUTE) == 500,
                "accepts phase liquid");
        check(helper, fluid.drain(500, IFluidHandler.FluidAction.EXECUTE).isEmpty(), "cannot be drained");
        check(helper, be.getTank().getFluidAmount() == 500, "tank holds 500");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void batterySlotChargesEnergyUnit(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        check(helper, be.getItems().insertItem(PhaseGenBlockEntity.SLOT_BATTERY, new ItemStack(ModItems.ENERGY_UNIT.get()), false)
                .isEmpty(), "energy unit accepted");
        be.getEnergy().setEnergy(500);
        tick(helper, be, 1);
        int unit = EnergyUnitItem.getEnergy(be.getItems().getStackInSlot(PhaseGenBlockEntity.SLOT_BATTERY));
        check(helper, unit == 20, "unit charges at 20/tick, got " + unit);
        check(helper, be.getEnergy().getEnergyStored() == 480, "buffer drops by 20, got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void levelFollowsTank(GameTestHelper helper) {
        PhaseGenBlockEntity be = gen(helper);
        be.getEnergy().setEnergy(PhaseGenBlockEntity.CAPACITY); // sin quemar
        fill(be, 8000);
        tick(helper, be, 1);
        check(helper, helper.getBlockState(GEN).getValue(PhaseGenBlock.LEVEL) == 4, "full tank = level 4");
        fill(be, 0);
        tick(helper, be, 1);
        check(helper, helper.getBlockState(GEN).getValue(PhaseGenBlock.LEVEL) == 0, "empty tank = level 0");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void phaseGenRecipeLoads(GameTestHelper helper) {
        check(helper, helper.getLevel().getRecipeManager()
                .byKey(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "phase_gen")).isPresent(),
                "phase_gen recipe should load");
        helper.succeed();
    }
}
