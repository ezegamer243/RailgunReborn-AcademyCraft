package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.MarkTeleportRules;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Mark Teleport (T58). Todo dentro de la estructura de 9x9: el jugador sale de z 0.5 mirando a +Z en
 * horizontal y se sueltan pocos ticks (alcance {@code (ticks + 1) * 2}).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class MarkTeleportGameTests {
    private static final String EMPTY = "empty";
    private static final Vec3 START = new Vec3(4.5, 1, 0.5);

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Teleporter nivel 2 con Mark Teleport aprendida (exp 0), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(2);
        Skill skill = Teleporter.MARK_TELEPORT.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Pulsa, mantiene {@code ticks} ticks y suelta. */
    private static void holdAndRelease(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        check(helper, SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    /** Nada cambió: misma posición, sin coste, sin cooldown ni exp. */
    private static void checkUntouched(GameTestHelper helper, ServerPlayer player, Skill skill, Vec3 start,
            float cpBefore, String what) {
        CPData cp = CPData.get(player);
        check(helper, player.position().distanceTo(start) < 1e-6, what + ": the player must not move, moved to "
                + player.position().subtract(start));
        check(helper, cp.getCP() == cpBefore && cp.getOverload() == 0f, what + ": no cost");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), what + ": no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, what + ": no exp");
        check(helper, SkillContexts.active(player).isEmpty(), what + ": the context ends");
    }

    @GameTest(template = EMPTY)
    public static void markTeleportIsRegisteredAtLevel2(GameTestHelper helper) {
        Skill skill = Teleporter.MARK_TELEPORT.get();
        check(helper, skill.getId().equals(Teleporter.skillId("mark_teleport")), "id " + skill.getId());
        check(helper, skill.getCategoryId().equals(Teleporter.ID), "belongs to teleporter");
        check(helper, skill.getLevel() == 2 && skill.canControl(), "level 2, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.THREATENING_TELEPORT_ID)
                && Math.abs(p.minExp() - 0.4f) < 1e-6f).orElse(false), "parent: threatening_teleport 0.4");
        check(helper, skill.getGuiX() == 70 && skill.getGuiY() == 16, "tree position should be 70, 16");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/mark_teleport.png"),
                "icon " + skill.getIcon());
        int id = AbilityRegistries.SKILL_REGISTRY.getId(skill);
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Teleporter.DIM_FOLDING.get()) < id
                && id < AbilityRegistries.SKILL_REGISTRY.getId(Teleporter.SPACE_FLUCT.get()),
                "registered between dim folding and space fluct");
        check(helper, Teleporter.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void holdingGrowsTheRangeAndReleasingTeleportsOnTheGround(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-mark-hold", START, 0f, 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        player.fallDistance = 4f;

        // 2 ticks: alcance 6. Mirando en horizontal, los ojos llegan a 6 bloques y los pies se posan en el suelo.
        holdAndRelease(helper, player, skill, 2);
        Vec3 expected = helper.absoluteVec(new Vec3(4.5, 1, 6.5));
        check(helper, player.position().distanceTo(expected) < 1e-3,
                "lands on the floor 6 blocks ahead, was " + player.position().subtract(helper.absoluteVec(START)));
        check(helper, Math.abs(cpBefore - cp.getCP() - 6 * MarkTeleportRules.cpPerBlock(0f)) < 0.01f,
                "pays 6 x 12 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - MarkTeleportRules.overload(0f)) < 0.01f,
                "adds 40 overload, was " + cp.getOverload());
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == MarkTeleportRules.cooldown(0f),
                "cooldown of 30 ticks");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - 6 * 0.00018f) < 1e-6f,
                "0.00018 exp per block");
        check(helper, player.fallDistance == 0f, "fall distance reset");
        check(helper, !SafeTeleport.isFallGuarded(player), "landed on the ground: no fall guard needed");
        check(helper, SkillContexts.active(player).isEmpty(), "the context ends after teleporting");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void rangeIsLimitedByCp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-mark-cp", START, 0f, 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        // Deja 48 CP: 4 bloques a 12 por bloque.
        cp.consume(player, 0f, cp.getCP() - 48f);
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();
        holdAndRelease(helper, player, skill, 6);
        Vec3 expected = helper.absoluteVec(new Vec3(4.5, 1, 4.5));
        check(helper, player.position().distanceTo(expected) < 0.01,
                "only 4 blocks with 48 CP, was " + player.position().subtract(helper.absoluteVec(START)));
        check(helper, cp.getCP() >= 0f && cpBefore - cp.getCP() <= 48f + 1e-3f,
                "never pays more than available, paid " + (cpBefore - cp.getCP()));
        check(helper, cp.getOverload() > overloadBefore, "overload added");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void shortTapDoesNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-mark-short", START, 0f, 0f);
        Skill skill = setUp(player);
        float cpBefore = CPData.get(player).getCP();
        // 0 ticks: alcance 2 (< 3).
        holdAndRelease(helper, player, skill, 0);
        checkUntouched(helper, player, skill, helper.absoluteVec(START), cpBefore, "range 2");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void wallTooCloseDoesNothing(GameTestHelper helper) {
        floor(helper);
        for (int x = 0; x < 9; x++) {
            for (int y = 1; y <= 4; y++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.STONE);
            }
        }
        ServerPlayer player = player(helper, "test-mark-wall", START, 0f, 0f);
        Skill skill = setUp(player);
        float cpBefore = CPData.get(player).getCP();
        // Pared a z 3: el destino queda a 0.6 de ella, a menos de 3 bloques.
        holdAndRelease(helper, player, skill, 5);
        checkUntouched(helper, player, skill, helper.absoluteVec(START), cpBefore, "wall at 2.5 blocks");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void destinationInsideBlocksIsRejectedWithoutCost(GameTestHelper helper) {
        floor(helper);
        // Fila de bloques de 1 de alto bajo el rayo (que pasa a la altura de los ojos): no cabe en ningún punto ≥ 3.
        for (int x = 0; x < 9; x++) {
            for (int z = 3; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 1, z), Blocks.STONE);
            }
        }
        ServerPlayer player = player(helper, "test-mark-block", START, 0f, 0f);
        Skill skill = setUp(player);
        float cpBefore = CPData.get(player).getCP();
        holdAndRelease(helper, player, skill, 2);
        checkUntouched(helper, player, skill, helper.absoluteVec(START), cpBefore, "inside blocks");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void lavaDestinationIsRejectedWithoutCost(GameTestHelper helper) {
        floor(helper);
        for (int x = 0; x < 9; x++) {
            for (int z = 3; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 1, z), Blocks.LAVA);
            }
        }
        ServerPlayer player = player(helper, "test-mark-lava", START, 0f, 0f);
        Skill skill = setUp(player);
        float cpBefore = CPData.get(player).getCP();
        holdAndRelease(helper, player, skill, 2);
        checkUntouched(helper, player, skill, helper.absoluteVec(START), cpBefore, "lava");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void lookingDownLandsOnTheFloor(GameTestHelper helper) {
        floor(helper);
        // Mirando 20° hacia abajo con alcance 6: el rayo toca el suelo (cara de arriba) a ~4.4 bloques.
        ServerPlayer player = player(helper, "test-mark-down", START, 0f, 20f);
        Skill skill = setUp(player);
        holdAndRelease(helper, player, skill, 2);
        Vec3 start = helper.absoluteVec(START);
        Vec3 moved = player.position().subtract(start);
        check(helper, Math.abs(moved.y) < 1e-6 && moved.z > 3 && moved.z < 6,
                "stands on the floor ahead, moved " + moved);
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "teleport happened");
        helper.succeed();
    }
}
