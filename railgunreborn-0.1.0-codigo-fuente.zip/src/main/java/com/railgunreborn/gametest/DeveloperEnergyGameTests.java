package com.railgunreborn.gametest;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DevelopSession;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.block.DeveloperBlock;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.AfterBatch;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de la energía de los Developers (T99). Los de {@code energyRequired = false} van en un lote propio: el
 * override de {@link RailgunConfig} es global y los lotes corren uno tras otro.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class DeveloperEnergyGameTests {
    private static final String EMPTY = "empty";
    private static final String FREE_BATCH = "developerEnergyFree";

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    @AfterBatch(batch = FREE_BATCH)
    public static void restoreConfig(ServerLevel level) {
        RailgunConfig.setEnergyRequiredOverrideForTests(null);
    }

    private static BlockPos place(GameTestHelper helper, DeveloperType type) {
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        DeveloperBlock developer = type == DeveloperType.ADVANCED ? ModBlocks.DEVELOPER_ADVANCED.get()
                : ModBlocks.DEVELOPER_NORMAL.get();
        developer.place(helper.getLevel(), block, Direction.SOUTH);
        return block;
    }

    private static DeveloperBlockEntity entity(GameTestHelper helper, BlockPos origin) {
        if (!(helper.getLevel().getBlockEntity(origin) instanceof DeveloperBlockEntity be)) {
            throw new IllegalStateException("developer block entity missing");
        }
        return be;
    }

    private static DeveloperMenu open(GameTestHelper helper, ServerPlayer player, DeveloperType type, BlockPos origin) {
        DeveloperMenu menu = DeveloperMenu.open(player, type, origin);
        check(helper, menu != null, "developer should open");
        return menu;
    }

    private static DeveloperMenu openPortable(GameTestHelper helper, ServerPlayer player, int energy) {
        player.setItemInHand(InteractionHand.MAIN_HAND, DeveloperPortableItem.withEnergy(
                new ItemStack(ModItems.DEVELOPER_PORTABLE.get()), energy));
        DeveloperMenu menu = DeveloperMenu.open(player, DeveloperType.PORTABLE, null);
        check(helper, menu != null, "portable should open");
        return menu;
    }

    private static void tick(DeveloperMenu menu, ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            menu.serverTick(player);
        }
    }

    private static ServerPlayer electromaster(GameTestHelper helper) {
        ServerPlayer player = RailgunGameTests.player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(1);
        return player;
    }

    // --- Bloque ---

    /** Obtener categoría = 5 estímulos x 700 IF del Developer normal = 3500 IF exactos. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void normalDeveloperLevelUpSpendsExactCost(GameTestHelper helper) {
        ServerPlayer player = RailgunGameTests.player(helper);
        BlockPos block = place(helper, DeveloperType.NORMAL);
        DeveloperBlockEntity be = entity(helper, block);
        be.getEnergy().setEnergy(10_000);
        DeveloperMenu menu = open(helper, player, DeveloperType.NORMAL, block);
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "should start");
        tick(menu, player, DevelopRules.totalTicks(5, DeveloperType.NORMAL));
        check(helper, menu.getResult() == DevelopResult.OK, "should finish, was " + menu.getResult());
        check(helper, AbilityData.get(player).hasCategory(), "category obtained");
        int left = be.getEnergy().getEnergyStored();
        check(helper, left == 10_000 - 5 * 700, "expected 6500 IF left, has " + left);
        check(helper, menu.getEnergy() == left, "synced energy must match");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void advancedDeveloperLearnSpendsExactCost(GameTestHelper helper) {
        ServerPlayer player = electromaster(helper);
        BlockPos block = place(helper, DeveloperType.ADVANCED);
        DeveloperBlockEntity be = entity(helper, block);
        be.getEnergy().setEnergy(200_000);
        DeveloperMenu menu = open(helper, player, DeveloperType.ADVANCED, block);
        check(helper, menu.getEnergy() == 200_000, "200 000 must survive the ContainerData sync, was " + menu.getEnergy());
        check(helper, menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get())) == DevelopResult.OK, "start");
        tick(menu, player, DevelopRules.totalTicks(3, DeveloperType.ADVANCED));
        check(helper, AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "learned");
        check(helper, be.getEnergy().getEnergyStored() == 200_000 - 3 * 600, "expected exactly 1800 spent");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void notEnoughEnergyIsRejectedAndNothingSpent(GameTestHelper helper) {
        ServerPlayer player = electromaster(helper);
        BlockPos block = place(helper, DeveloperType.NORMAL);
        DeveloperBlockEntity be = entity(helper, block);
        be.getEnergy().setEnergy(3 * 700 - 1);
        DeveloperMenu menu = open(helper, player, DeveloperType.NORMAL, block);
        DevelopResult result = menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get()));
        check(helper, result == DevelopResult.NO_ENERGY, "expected NO_ENERGY, was " + result);
        check(helper, menu.getState() == DevelopSession.State.FAILED, "state FAILED");
        check(helper, menu.getResult() == DevelopResult.NO_ENERGY, "reason must reach the client data");
        tick(menu, player, 200);
        check(helper, !AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "not learned");
        check(helper, be.getEnergy().getEnergyStored() == 3 * 700 - 1, "nothing spent");
        helper.succeed();
    }

    /** Se acaba la energía tras el primer estímulo: falla, no aprende nada y el Induction Factor se conserva. */
    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void energyRunningOutMidwayFailsAndKeepsFactor(GameTestHelper helper) {
        ServerPlayer player = RailgunGameTests.player(helper);
        ResourceLocation category = Electromaster.ID;
        player.getInventory().add(InductionFactorItem.of(category));
        BlockPos block = place(helper, DeveloperType.NORMAL);
        DeveloperBlockEntity be = entity(helper, block);
        be.getEnergy().setEnergy(5 * 700);
        DeveloperMenu menu = open(helper, player, DeveloperType.NORMAL, block);
        check(helper, menu.start(player, DevelopAction.levelWithFactor(category)) == DevelopResult.OK, "start");
        tick(menu, player, 5); // el primer estímulo ya está pagado
        check(helper, be.getEnergy().getEnergyStored() == 4 * 700, "first stimulation paid");
        be.getEnergy().setEnergy(100); // otro consumidor vacía el buffer
        tick(menu, player, DevelopRules.totalTicks(5, DeveloperType.NORMAL));
        check(helper, menu.getResult() == DevelopResult.NO_ENERGY, "expected NO_ENERGY, was " + menu.getResult());
        check(helper, menu.getState() == DevelopSession.State.FAILED, "state FAILED");
        check(helper, !AbilityData.get(player).hasCategory(), "nothing learned");
        check(helper, InductionFactorItem.has(player, category), "induction factor must be kept");
        check(helper, be.getEnergy().getEnergyStored() == 100, "nothing more spent");
        helper.succeed();
    }

    // --- Portátil ---

    @GameTest(template = EMPTY, timeoutTicks = 300)
    public static void portableDeveloperUsesItemEnergy(GameTestHelper helper) {
        ServerPlayer player = electromaster(helper);
        DeveloperMenu menu = openPortable(helper, player, 10_000);
        check(helper, menu.getEnergy() == 10_000, "item energy synced");
        check(helper, menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get())) == DevelopResult.OK, "start");
        tick(menu, player, DevelopRules.totalTicks(3, DeveloperType.PORTABLE));
        check(helper, AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "learned");
        int left = DeveloperPortableItem.getEnergy(player.getMainHandItem());
        check(helper, left == 10_000 - 3 * 750, "expected 7750 IF left in the item, has " + left);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void portableWithoutEnergyIsRejected(GameTestHelper helper) {
        ServerPlayer player = electromaster(helper);
        DeveloperMenu menu = openPortable(helper, player, 3 * 750 - 1);
        DevelopResult result = menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get()));
        check(helper, result == DevelopResult.NO_ENERGY, "expected NO_ENERGY, was " + result);
        check(helper, DeveloperPortableItem.getEnergy(player.getMainHandItem()) == 3 * 750 - 1, "nothing spent");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void portableItemIsAChargeableBattery(GameTestHelper helper) {
        ItemStack stack = new ItemStack(ModItems.DEVELOPER_PORTABLE.get());
        IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        check(helper, storage != null, "portable must expose an FE capability");
        check(helper, storage.getMaxEnergyStored() == 10_000, "capacity 10 000");
        check(helper, storage.receiveEnergy(500, false) == 50, "bandwidth 50 per operation");
        check(helper, DeveloperPortableItem.getEnergy(stack) == 50, "energy lives in the component");
        helper.succeed();
    }

    // --- Capacidad FE y NBT ---

    @GameTest(template = EMPTY)
    public static void fePluggedOnAnyPartAndSide(GameTestHelper helper) {
        BlockPos origin = place(helper, DeveloperType.NORMAL);
        DeveloperBlockEntity be = entity(helper, origin);
        ServerLevel level = helper.getLevel();
        Direction[] sides = { null, Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST,
                Direction.WEST };
        int expected = 0;
        for (int part : new int[] { 0, 4, 7 }) {
            BlockPos pos = DeveloperBlock.partPos(origin, Direction.SOUTH, part);
            for (Direction side : sides) {
                IEnergyStorage storage = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos, side);
                check(helper, storage != null, "FE capability missing at part " + part + " side " + side);
                check(helper, !storage.canExtract() && storage.canReceive(), "receive only");
                int got = storage.receiveEnergy(60, false);
                check(helper, got == 60, "should accept 60, got " + got);
                expected += 60;
            }
        }
        check(helper, be.getEnergy().getEnergyStored() == expected, "all inputs land in the controller buffer");
        IEnergyStorage other = level.getCapability(Capabilities.EnergyStorage.BLOCK,
                DeveloperBlock.partPos(origin, Direction.SOUTH, 1), Direction.UP);
        check(helper, other.receiveEnergy(5000, false) == 100, "bandwidth 100 per call for the normal developer");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void bufferIsSavedToNbt(GameTestHelper helper) {
        BlockPos origin = place(helper, DeveloperType.ADVANCED);
        DeveloperBlockEntity be = entity(helper, origin);
        be.getEnergy().setEnergy(123_456);
        CompoundTag tag = be.saveWithoutMetadata(helper.getLevel().registryAccess());
        be.getEnergy().setEnergy(0);
        be.loadWithComponents(tag, helper.getLevel().registryAccess());
        check(helper, be.getEnergy().getEnergyStored() == 123_456, "energy must round-trip, has "
                + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    // --- Sin energía requerida ---

    @GameTest(template = EMPTY, timeoutTicks = 300, batch = FREE_BATCH)
    public static void developerIsFreeWhenEnergyNotRequired(GameTestHelper helper) {
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        ServerPlayer player = electromaster(helper);
        BlockPos block = place(helper, DeveloperType.NORMAL);
        DeveloperBlockEntity be = entity(helper, block);
        DeveloperMenu menu = open(helper, player, DeveloperType.NORMAL, block);
        check(helper, !menu.isEnergyRequired(), "client must know it is free");
        check(helper, menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get())) == DevelopResult.OK, "start");
        tick(menu, player, DevelopRules.totalTicks(3, DeveloperType.NORMAL));
        check(helper, AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "learned for free");
        check(helper, be.getEnergy().getEnergyStored() == 0, "nothing spent");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 300, batch = FREE_BATCH)
    public static void portableIsFreeWhenEnergyNotRequired(GameTestHelper helper) {
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        ServerPlayer player = electromaster(helper);
        DeveloperMenu menu = openPortable(helper, player, 0);
        check(helper, menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get())) == DevelopResult.OK, "start");
        tick(menu, player, DevelopRules.totalTicks(3, DeveloperType.PORTABLE));
        check(helper, AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "learned for free");
        helper.succeed();
    }
}
