package com.railgunreborn.gametest;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.wireless.MatrixBlock;
import com.railgunreborn.wireless.MatrixBlockEntity;
import com.railgunreborn.wireless.NodeBlock;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.NodeLinks;
import com.railgunreborn.wireless.WirelessData;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessRegistry;
import com.railgunreborn.wireless.WirelessResult;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.registries.DeferredBlock;

/**
 * GameTests de la red inalámbrica (T103). Casi todos usan un {@link WirelessData} propio (no el de la dimensión) y
 * llaman a su {@code tick} a mano: así el tick global y los demás tests no se cruzan. Los de rotura usan el de la
 * dimensión, que es el que limpian los bloques al romperse. Los bloques fuera del recinto (pruebas de alcance) van
 * hacia arriba, donde no hay otros tests, y se quitan al final.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class WirelessGameTests {
    private static final String EMPTY = "empty";
    private static final BlockPos MATRIX = new BlockPos(1, 1, 1);

    private static void check(GameTestHelper helper, boolean ok, String message) {
        if (!ok) {
            helper.fail(message);
        }
    }

    private static Item core(int tier) {
        return switch (tier) {
            case 1 -> WirelessRegistry.MAT_CORE_0.get();
            case 2 -> WirelessRegistry.MAT_CORE_1.get();
            default -> WirelessRegistry.MAT_CORE_2.get();
        };
    }

    /** Matriz 2x2x2 en {@code rel} con las 3 placas y un núcleo del nivel dado (0 = sin núcleo). Devuelve el origen. */
    private static BlockPos matrix(GameTestHelper helper, BlockPos rel, int tier) {
        BlockPos abs = helper.absolutePos(rel);
        WirelessRegistry.MATRIX.get().place(helper.getLevel(), abs);
        MatrixBlockEntity be = (MatrixBlockEntity) helper.getLevel().getBlockEntity(abs);
        for (int slot = 0; slot < MatrixBlockEntity.PLATE_SLOTS; slot++) {
            be.getItems().setStackInSlot(slot, new ItemStack(ModItems.CONSTRAINT_PLATE.get()));
        }
        if (tier > 0) {
            be.getItems().setStackInSlot(MatrixBlockEntity.SLOT_CORE, new ItemStack(core(tier)));
        }
        return abs;
    }

    private static NodeBlockEntity node(GameTestHelper helper, BlockPos rel, DeferredBlock<NodeBlock> block) {
        helper.setBlock(rel, block.get().defaultBlockState());
        return (NodeBlockEntity) helper.getBlockEntity(rel);
    }

    /** Pone un bloque en una posición absoluta (fuera del recinto) y la apunta para quitarlo al final. */
    private static void setFar(ServerLevel level, BlockPos abs, BlockState state, List<BlockPos> placed) {
        level.setBlock(abs, state, Block.UPDATE_ALL);
        placed.add(abs);
    }

    private static void clearFar(ServerLevel level, List<BlockPos> placed) {
        for (BlockPos pos : placed) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    @GameTest(template = EMPTY)
    public static void createNetworkAndJoinWithPassword(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos origin = matrix(helper, MATRIX, 0);
        BlockPos nodePos = node(helper, new BlockPos(6, 1, 6), WirelessRegistry.NODE_BASIC).getBlockPos();

        check(helper, data.createNetwork(level, helper.absolutePos(new BlockPos(5, 1, 5)), "x", "") ==
                WirelessResult.NO_MATRIX, "create on a non-matrix block should fail");
        // Se crea desde cualquier parte de la matriz (aquí la de arriba al fondo).
        check(helper, data.createNetwork(level, origin.offset(1, 1, 1), "home", "secret").ok(),
                "create should succeed");
        check(helper, data.createNetwork(level, origin, "other", "") == WirelessResult.ALREADY_EXISTS,
                "second network on the same matrix");
        check(helper, data.createNetwork(level, origin, "", "") != WirelessResult.OK, "empty SSID");
        check(helper, data.getNetwork(origin) != null && data.getNetwork(origin).getSsid().equals("home"),
                "network should be stored under the matrix origin");

        check(helper, data.joinNetwork(level, nodePos, origin, "secret") == WirelessResult.MATRIX_NOT_WORKING,
                "matrix without core cannot take nodes");
        ((MatrixBlockEntity) level.getBlockEntity(origin)).getItems()
                .setStackInSlot(MatrixBlockEntity.SLOT_CORE, new ItemStack(core(1)));

        check(helper, data.joinNetwork(level, nodePos, origin, "wrong") == WirelessResult.WRONG_PASSWORD,
                "wrong password must be rejected");
        check(helper, data.networkOfNode(nodePos) == null, "rejected node must stay out");
        check(helper, data.joinNetworkBySsid(level, nodePos, "home", "secret").ok(), "join by SSID should work");
        check(helper, data.networkOfNode(nodePos) == data.getNetwork(origin), "node should be in the network");
        check(helper, data.leaveNetwork(nodePos).ok() && data.networkOfNode(nodePos) == null, "leave");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matrixCapacityLimit(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos origin = matrix(helper, MATRIX, 1);
        data.createNetwork(level, origin, "cap", "");
        int capacity = MatrixBlockEntity.capacityFor(1);
        check(helper, capacity == 8, "tier 1 holds 8 nodes");
        for (int i = 0; i <= capacity; i++) {
            BlockPos nodePos = node(helper, new BlockPos(i, 1, 7), WirelessRegistry.NODE_BASIC).getBlockPos();
            WirelessResult result = data.joinNetwork(level, nodePos, origin, "");
            WirelessResult expected = i < capacity ? WirelessResult.OK : WirelessResult.FULL;
            check(helper, result == expected, "node " + i + ": expected " + expected + ", got " + result);
        }
        check(helper, data.getNetwork(origin).getLoad() == capacity, "load should be " + capacity);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void matrixAndNodeRangeLimits(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        List<BlockPos> placed = new ArrayList<>();
        try {
            BlockPos origin = matrix(helper, MATRIX, 1);
            data.createNetwork(level, origin, "range", "");
            // Nivel 1: alcance 24 (justo en el borde vale).
            BlockPos inside = origin.above(24);
            BlockPos outside = origin.above(25);
            setFar(level, inside, WirelessRegistry.NODE_BASIC.get().defaultBlockState(), placed);
            setFar(level, outside, WirelessRegistry.NODE_BASIC.get().defaultBlockState(), placed);
            check(helper, data.joinNetwork(level, inside, origin, "").ok(), "node at 24 blocks should join");
            check(helper, data.joinNetwork(level, outside, origin, "") == WirelessResult.OUT_OF_RANGE,
                    "node at 25 blocks should be out of range");

            // Nodo básico: alcance 9 hasta sus generadores/receptores.
            BlockPos nodePos = helper.absolutePos(new BlockPos(6, 1, 6));
            helper.setBlock(new BlockPos(6, 1, 6), WirelessRegistry.NODE_BASIC.get().defaultBlockState());
            BlockPos near = nodePos.above(9);
            BlockPos far = nodePos.above(10);
            setFar(level, near, ModBlocks.CAT_ENGINE.get().defaultBlockState(), placed);
            setFar(level, far, ModBlocks.CAT_ENGINE.get().defaultBlockState(), placed);
            check(helper, data.linkUser(level, near, nodePos, "").ok(), "generator at 9 blocks should link");
            check(helper, data.linkUser(level, far, nodePos, "") == WirelessResult.OUT_OF_RANGE,
                    "generator at 10 blocks should be out of range");
        } finally {
            clearFar(level, placed);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void nodeLinkCapacityLimit(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        NodeBlockEntity node = node(helper, new BlockPos(4, 1, 4), WirelessRegistry.NODE_BASIC);
        int max = node.getNodeType().maxLinks;
        for (int i = 0; i <= max; i++) {
            BlockPos rel = new BlockPos(i, 1, 0);
            helper.setBlock(rel, ModBlocks.CAT_ENGINE.get().defaultBlockState());
            WirelessResult result = data.linkUser(level, helper.absolutePos(rel), node.getBlockPos(), "");
            WirelessResult expected = i < max ? WirelessResult.OK : WirelessResult.FULL;
            check(helper, result == expected, "link " + i + ": expected " + expected + ", got " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void energyFlowsGeneratorToNodeToReceiver(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        helper.setBlock(new BlockPos(1, 1, 1), ModBlocks.CAT_ENGINE.get().defaultBlockState());
        helper.setBlock(new BlockPos(7, 1, 7), ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        CatEngineBlockEntity engine = (CatEngineBlockEntity) helper.getBlockEntity(new BlockPos(1, 1, 1));
        ImagFusorBlockEntity fusor = (ImagFusorBlockEntity) helper.getBlockEntity(new BlockPos(7, 1, 7));
        NodeBlockEntity node = node(helper, new BlockPos(4, 1, 4), WirelessRegistry.NODE_BASIC);
        node.setPassword("np");
        engine.getEnergy().setEnergy(CatEngineBlockEntity.CAPACITY);
        fusor.getEnergy().setEnergy(0);
        BlockPos nodePos = node.getBlockPos();

        check(helper, data.linkUser(level, engine.getBlockPos(), nodePos, "bad") == WirelessResult.WRONG_PASSWORD,
                "node password must be checked");
        check(helper, data.linkUser(level, fusor.getBlockPos(), nodePos, "np", NodeLinks.Role.GENERATOR)
                == WirelessResult.NOT_ENERGY_BLOCK, "a machine cannot be a generator");
        check(helper, data.linkUser(level, helper.absolutePos(new BlockPos(5, 1, 5)), nodePos, "np")
                == WirelessResult.NOT_ENERGY_BLOCK, "air is not an energy block");
        check(helper, data.linkUser(level, engine.getBlockPos(), nodePos, "np").ok(), "link generator");
        check(helper, data.linkUser(level, fusor.getBlockPos(), nodePos, "np").ok(), "link receiver");
        check(helper, data.linksOf(nodePos).getGenerators().contains(engine.getBlockPos())
                && data.linksOf(nodePos).getReceivers().contains(fusor.getBlockPos()), "roles should be automatic");

        data.tick(level);
        int nodeEnergy = node.getEnergy().getEnergyStored();
        int fusorEnergy = fusor.getEnergy().getEnergyStored();
        // El nodo básico saca 150 (su ancho de banda) y el Fusor acepta 50 por llamada.
        check(helper, fusorEnergy == ImagFusorBlockEntity.ENERGY_MAX_RECEIVE,
                "fusor should get 50, got " + fusorEnergy);
        check(helper, nodeEnergy == 150 - fusorEnergy, "node should keep 100, got " + nodeEnergy);

        check(helper, data.unlinkUser(fusor.getBlockPos()).ok() && data.nodeOfUser(fusor.getBlockPos()) == null,
                "unlink");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void balancingBetweenTwoNodes(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        BlockPos origin = matrix(helper, MATRIX, 1);
        data.createNetwork(level, origin, "balance", "pw");
        NodeBlockEntity full = node(helper, new BlockPos(6, 1, 1), WirelessRegistry.NODE_BASIC);
        NodeBlockEntity empty = node(helper, new BlockPos(6, 1, 6), WirelessRegistry.NODE_BASIC);
        full.getEnergy().setEnergy(15_000);
        empty.getEnergy().setEnergy(0);
        data.joinNetwork(level, full.getBlockPos(), origin, "pw");
        data.joinNetwork(level, empty.getBlockPos(), origin, "pw");

        data.tick(level);
        // Nivel 1: la matriz mueve 60 IF/tick.
        check(helper, full.getEnergy().getEnergyStored() == 14_940 && empty.getEnergy().getEnergyStored() == 60,
                "first tick should move 60, got " + full.getEnergy().getEnergyStored() + " / "
                        + empty.getEnergy().getEnergyStored());
        for (int i = 0; i < 200; i++) {
            data.tick(level);
        }
        int a = full.getEnergy().getEnergyStored();
        int b = empty.getEnergy().getEnergyStored();
        int buffer = data.getNetwork(origin).getBuffer();
        check(helper, a + b + buffer == 15_000, "energy must be conserved, got " + (a + b + buffer));
        check(helper, a == 7500 && b == 7500, "nodes should end balanced, got " + a + " / " + b);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void wirelessDataSurvivesSaveAndLoad(GameTestHelper helper) {
        BlockPos matrix = new BlockPos(100, 64, 100);
        BlockPos nodeA = new BlockPos(110, 64, 100);
        BlockPos nodeB = new BlockPos(90, 64, 100);
        BlockPos gen = new BlockPos(111, 64, 100);
        BlockPos rec = new BlockPos(112, 64, 100);
        WirelessData data = new WirelessData(
                List.of(new WirelessNetwork(matrix, "saved", "pass", List.of(nodeA, nodeB), 123)),
                List.of(new NodeLinks(nodeA, List.of(gen), List.of(rec))));

        CompoundTag tag = data.save(new CompoundTag(), helper.getLevel().registryAccess());
        WirelessData loaded = WirelessData.load(tag, helper.getLevel().registryAccess());

        WirelessNetwork net = loaded.getNetwork(matrix);
        check(helper, net != null, "network should be loaded");
        check(helper, net.getSsid().equals("saved") && net.checkPassword("pass") && !net.checkPassword("x"),
                "SSID and password should survive");
        check(helper, net.getBuffer() == 123, "buffer should survive, got " + net.getBuffer());
        check(helper, net.getNodes().equals(java.util.Set.of(nodeA, nodeB)), "nodes should survive");
        check(helper, loaded.networkOfNode(nodeB) == net, "node index should be rebuilt");
        check(helper, nodeA.equals(loaded.nodeOfUser(gen)) && nodeA.equals(loaded.nodeOfUser(rec)),
                "user index should be rebuilt");
        check(helper, loaded.linksOf(nodeA).getGenerators().contains(gen)
                && loaded.linksOf(nodeA).getReceivers().contains(rec), "roles should survive");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void unloadedUserIsSkippedAndRemovedUserIsCleaned(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = new WirelessData();
        NodeBlockEntity node = node(helper, new BlockPos(4, 1, 4), WirelessRegistry.NODE_BASIC);
        node.getEnergy().setEnergy(1000);
        BlockPos nodePos = node.getBlockPos();

        // Un receptor en un chunk lejano que nadie ha cargado: se salta sin cargarlo y el enlace se conserva.
        BlockPos far = nodePos.offset(50_000, 0, 50_000);
        int cx = SectionPos.blockToSectionCoord(far.getX());
        int cz = SectionPos.blockToSectionCoord(far.getZ());
        check(helper, !level.hasChunk(cx, cz), "far chunk should not be loaded");
        data.forceLink(far, nodePos, NodeLinks.Role.RECEIVER);
        data.tick(level);
        check(helper, !level.hasChunk(cx, cz), "tick must not load the chunk");
        check(helper, nodePos.equals(data.nodeOfUser(far)), "link to an unloaded block must be kept");
        check(helper, node.getEnergy().getEnergyStored() == 1000, "no energy should go anywhere");

        // Un receptor que se rompe: el siguiente tick lo desenlaza.
        BlockPos fusorRel = new BlockPos(6, 1, 6);
        helper.setBlock(fusorRel, ModBlocks.IMAG_FUSOR.get().defaultBlockState());
        BlockPos fusor = helper.absolutePos(fusorRel);
        check(helper, data.linkUser(level, fusor, nodePos, "").ok(), "link fusor");
        helper.setBlock(fusorRel, Blocks.AIR.defaultBlockState());
        data.tick(level);
        check(helper, data.nodeOfUser(fusor) == null, "removed receiver should be unlinked");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void breakingMatrixDissolvesNetworkAndBreakingNodeDropsLinks(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        WirelessData data = WirelessData.get(level);
        BlockPos origin = matrix(helper, MATRIX, 2);
        NodeBlockEntity node = node(helper, new BlockPos(6, 1, 6), WirelessRegistry.NODE_STANDARD);
        BlockPos nodePos = node.getBlockPos();
        helper.setBlock(new BlockPos(7, 1, 1), ModBlocks.CAT_ENGINE.get().defaultBlockState());
        BlockPos engine = helper.absolutePos(new BlockPos(7, 1, 1));
        check(helper, data.createNetwork(level, origin, "t103_break", "").ok(), "create");
        check(helper, data.joinNetwork(level, nodePos, origin, "").ok(), "join");
        check(helper, data.linkUser(level, engine, nodePos, "").ok(), "link");

        // Estados del bloque del nodo: lleno y conectado.
        node.getEnergy().setEnergy(node.getEnergy().getMaxEnergyStored());
        node.refreshState();
        BlockState nodeState = level.getBlockState(nodePos);
        check(helper, nodeState.getValue(NodeBlock.ENERGY) == 4 && nodeState.getValue(NodeBlock.CONNECTED),
                "node state should show full and connected, got " + nodeState);

        // Romper una parte cualquiera (la de arriba al fondo) quita las 8 y disuelve la red.
        helper.setBlock(MATRIX.offset(1, 1, 1), Blocks.AIR.defaultBlockState());
        for (int part = 0; part < MatrixBlock.PART_COUNT; part++) {
            check(helper, level.getBlockState(MatrixBlock.partPos(origin, part)).isAir(),
                    "matrix part " + part + " should be gone");
        }
        check(helper, data.getNetwork(origin) == null, "network should be dissolved");
        check(helper, data.networkOfNode(nodePos) == null, "node should be out of the network");
        check(helper, nodePos.equals(data.nodeOfUser(engine)), "links of the node stay");

        helper.setBlock(new BlockPos(6, 1, 6), Blocks.AIR.defaultBlockState());
        check(helper, data.nodeOfUser(engine) == null && data.linksOf(nodePos) == null,
                "breaking the node should drop its links");
        helper.succeed();
    }
}
