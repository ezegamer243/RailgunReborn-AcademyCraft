package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorBlockEntity.Status;
import com.railgunreborn.reactor.CategoryReactorMenu;
import com.railgunreborn.reactor.CategoryReactorPartBlock;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.reactor.CategoryReactorStructure;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.items.IItemHandler;

/** GameTests del reactor de categoría (T90). */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class CategoryReactorGameTests {
    private static final String EMPTY = "empty";

    /** Decisión del usuario: la receta del reactor pide una estrella del Nether. */
    @GameTest(template = EMPTY)
    public static void recipeNeedsNetherStar(GameTestHelper helper) {
        var recipe = helper.getLevel().getRecipeManager()
                .byKey(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                        "category_reactor"));
        if (recipe.isEmpty()) {
            helper.fail("category_reactor recipe missing");
            return;
        }
        boolean star = recipe.get().value().getIngredients().stream()
                .anyMatch(ingredient -> ingredient.test(new ItemStack(Items.NETHER_STAR)));
        if (!star) {
            helper.fail("category_reactor recipe must need a nether star");
            return;
        }
        helper.succeed();
    }
    /** Bloque sobre el que se hace clic: la base (centro de la capa de abajo) queda encima. */
    private static final BlockPos CLICKED = new BlockPos(4, 0, 4);
    private static final BlockPos BASE = CLICKED.above();
    private static final BlockPos CONTROLLER = BASE.above();

    @GameTest(template = EMPTY)
    public static void placingBuilds27Blocks(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(CategoryReactorRegistry.ITEM.get()));
        InteractionResult result = use(helper, player);
        check(helper, result.consumesAction(), "placing in a clear space should succeed, got " + result);
        BlockPos controller = helper.absolutePos(CONTROLLER);
        int parts = 0;
        for (BlockPos pos : CategoryReactorStructure.volume(controller)) {
            BlockState state = helper.getLevel().getBlockState(pos);
            if (pos.equals(controller)) {
                check(helper, state.is(CategoryReactorRegistry.CONTROLLER.get()), "the center must be the controller");
            } else {
                check(helper, state.is(CategoryReactorRegistry.PART.get()), "missing part at " + pos);
                check(helper, CategoryReactorPartBlock.controllerPos(pos, state).equals(controller),
                        "part at " + pos + " must point to the controller");
                parts++;
            }
        }
        check(helper, parts == 26, "expected 26 parts, got " + parts);
        check(helper, helper.getBlockEntity(CONTROLLER) instanceof CategoryReactorBlockEntity,
                "the controller needs its block entity");
        check(helper, player.getMainHandItem().isEmpty(), "the item should be consumed in survival");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void blockedVolumeRefuses(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(CategoryReactorRegistry.ITEM.get()));
        helper.setBlock(CONTROLLER.offset(1, 1, 1), Blocks.STONE);
        InteractionResult result = use(helper, player);
        check(helper, !result.consumesAction(), "a blocked volume must refuse, got " + result);
        for (BlockPos pos : CategoryReactorStructure.volume(helper.absolutePos(CONTROLLER))) {
            BlockState state = helper.getLevel().getBlockState(pos);
            check(helper, !state.is(CategoryReactorRegistry.PART.get())
                    && !state.is(CategoryReactorRegistry.CONTROLLER.get()), "nothing should be placed at " + pos);
        }
        check(helper, player.getMainHandItem().is(CategoryReactorRegistry.ITEM.get()),
                "the item must not be consumed");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void breakingCornerRemovesAllAndDropsItemAndFactor(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        be.getItems().setStackInSlot(0, InductionFactorItem.of(Teleporter.ID));
        be.getFluidHandler().fill(phase(5000), IFluidHandler.FluidAction.EXECUTE);
        BlockPos corner = helper.absolutePos(CONTROLLER.offset(-1, -1, -1));
        helper.getLevel().destroyBlock(corner, true);
        for (BlockPos pos : CategoryReactorStructure.volume(helper.absolutePos(CONTROLLER))) {
            check(helper, helper.getLevel().getBlockState(pos).isAir(), "everything should be removed, " + pos
                    + " is " + helper.getLevel().getBlockState(pos));
        }
        List<ItemEntity> drops = helper.getLevel().getEntitiesOfClass(ItemEntity.class,
                new AABB(helper.absolutePos(CONTROLLER)).inflate(4));
        int reactors = 0;
        int factors = 0;
        for (ItemEntity drop : drops) {
            ItemStack stack = drop.getItem();
            if (stack.is(CategoryReactorRegistry.ITEM.get())) {
                reactors += stack.getCount();
            } else if (stack.is(ModItems.INDUCTION_FACTOR.get())) {
                factors += stack.getCount();
                check(helper, InductionFactorItem.categoryOf(stack).filter(Teleporter.ID::equals).isPresent(),
                        "the dropped factor must keep its category");
            } else {
                helper.fail("unexpected drop " + stack);
            }
        }
        check(helper, reactors == 1, "expected exactly 1 reactor item, got " + reactors);
        check(helper, factors == 1, "expected the factor to drop, got " + factors);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fillViaCapabilityAndBucket(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        BlockPos corner = helper.absolutePos(CONTROLLER.offset(1, 1, -1));
        IFluidHandler handler = helper.getLevel().getCapability(Capabilities.FluidHandler.BLOCK, corner, Direction.UP);
        check(helper, handler != null, "parts must expose the fluid capability");
        check(helper, handler.fill(new FluidStack(Fluids.WATER, 1000), IFluidHandler.FluidAction.EXECUTE) == 0,
                "only phase liquid is accepted");

        // Un cubo con clic derecho en una pieza: entra 1000 mB y vuelve el cubo vacío.
        BlockPos side = helper.absolutePos(CONTROLLER.offset(1, 0, 0));
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.PHASE_LIQUID_BUCKET.get()));
        helper.getLevel().getBlockState(side).useItemOn(player.getMainHandItem(), helper.getLevel(), player,
                InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(side), Direction.EAST, side, false));
        check(helper, be.getTank().getFluidAmount() == 1000, "a bucket should add 1000 mB, got "
                + be.getTank().getFluidAmount());
        check(helper, player.getMainHandItem().is(Items.BUCKET), "the empty bucket should be returned, got "
                + player.getMainHandItem());

        int filled = handler.fill(phase(40_000), IFluidHandler.FluidAction.EXECUTE);
        check(helper, filled == 29_000, "should fill up to the capacity, filled " + filled);
        check(helper, be.getTank().getFluidAmount() == CategoryReactorBlockEntity.TANK_CAPACITY, "tank should be full");
        check(helper, handler.drain(1000, IFluidHandler.FluidAction.EXECUTE).isEmpty(), "the tank is fill-only");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void activationChangesCategoryToTeleporter(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(3);
        CategoryReactorBlockEntity be = build(helper, player);
        be.getFluidHandler().fill(phase(CategoryReactorBlockEntity.TANK_CAPACITY), IFluidHandler.FluidAction.EXECUTE);
        IItemHandler items = helper.getLevel().getCapability(Capabilities.ItemHandler.BLOCK,
                helper.absolutePos(CONTROLLER.below()), Direction.DOWN);
        check(helper, items != null, "parts must expose the item capability");
        check(helper, items.insertItem(0, InductionFactorItem.of(Teleporter.ID), false).isEmpty(),
                "the factor should go in");
        be.getEnergy().setEnergy(CategoryReactorBlockEntity.ENERGY_CAPACITY);
        CategoryReactorMenu menu = new CategoryReactorMenu(1, player.getInventory(), be, player);
        check(helper, menu.getStatus() == Status.READY, "should be ready, got " + menu.getStatus());
        menu.clickMenuButton(player, CategoryReactorMenu.BUTTON_ACTIVATE);
        check(helper, be.getEnergy().getEnergyStored() == 0, "the energy buffer must be emptied");
        check(helper, data.getCategory().filter(Teleporter.ID::equals).isPresent(),
                "category should be teleporter, got " + data.getCategory());
        check(helper, data.getLevel() == 1, "level should be 1, got " + data.getLevel());
        check(helper, be.getTank().getFluidAmount() == 0, "the liquid should be used");
        check(helper, be.getFactor().isEmpty(), "the factor should be consumed");
        check(helper, be.isFiring(), "the reactor should be firing");
        check(helper, menu.getStatus() == Status.FIRING, "status should be FIRING right after");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void activationRefusedWhenNotReady(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Teleporter.ID);
        data.setLevel(4);
        CategoryReactorBlockEntity be = build(helper, player);

        // Sin factor.
        be.getFluidHandler().fill(phase(CategoryReactorBlockEntity.TANK_CAPACITY), IFluidHandler.FluidAction.EXECUTE);
        check(helper, be.tryActivate(player) == Status.NEED_FACTOR, "no factor must refuse");

        // Misma categoría.
        be.getItems().setStackInSlot(0, InductionFactorItem.of(Teleporter.ID));
        check(helper, be.tryActivate(player) == Status.SAME_CATEGORY, "same category must refuse");
        check(helper, be.getTank().getFluidAmount() == CategoryReactorBlockEntity.TANK_CAPACITY
                && !be.getFactor().isEmpty(), "a refused activation must not consume anything");

        // Factor de otra categoría pero depósito a medias (29 000 mB).
        be.getItems().setStackInSlot(0, InductionFactorItem.of(Electromaster.ID));
        be.getTank().drain(1000, IFluidHandler.FluidAction.EXECUTE);
        CategoryReactorMenu menu = new CategoryReactorMenu(1, player.getInventory(), be, player);
        menu.clickMenuButton(player, CategoryReactorMenu.BUTTON_ACTIVATE);
        check(helper, menu.getStatus() == Status.NEED_LIQUID, "a partial tank must refuse");
        check(helper, be.getTank().getFluidAmount() == 29_000 && !be.getFactor().isEmpty(),
                "a refused activation must not consume anything");
        check(helper, data.getCategory().filter(Teleporter.ID::equals).isPresent() && data.getLevel() == 4,
                "the player must be unchanged");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void factorCanBeInsertedAndRemovedFreely(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        CategoryReactorMenu menu = new CategoryReactorMenu(1, player.getInventory(), be, player);
        // Ranura 0 = factor; 1..27 inventario; 28..36 barra. La barra 0 es la ranura de menú 28.
        int hotbar0 = 28;
        player.getInventory().setItem(0, InductionFactorItem.of(Teleporter.ID).copyWithCount(2));
        for (int round = 0; round < 2; round++) {
            menu.quickMoveStack(player, hotbar0);
            check(helper, be.getFactorCategory().filter(Teleporter.ID::equals).isPresent(),
                    "the factor should be in the reactor (round " + round + ")");
            check(helper, be.getFactor().getCount() == 1, "only one factor fits");
            menu.quickMoveStack(player, 0);
            check(helper, be.getFactor().isEmpty(), "the factor should come back out (round " + round + ")");
        }
        int total = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(ModItems.INDUCTION_FACTOR.get())) {
                total += stack.getCount();
            }
        }
        check(helper, total == 2, "no factor may be lost, got " + total);
        check(helper, !be.getItems().isItemValid(0, new ItemStack(Items.DIAMOND)), "only factors are accepted");
        // Clic derecho con el factor en la mano sobre una pieza.
        player.setItemInHand(InteractionHand.MAIN_HAND, InductionFactorItem.of(Electromaster.ID));
        BlockPos side = helper.absolutePos(CONTROLLER.offset(0, 0, 1));
        helper.getLevel().getBlockState(side).useItemOn(player.getMainHandItem(), helper.getLevel(), player,
                InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(side), Direction.SOUTH, side, false));
        check(helper, be.getFactorCategory().filter(Electromaster.ID::equals).isPresent(),
                "right-clicking with a factor should insert it");
        check(helper, player.getMainHandItem().isEmpty(), "the factor should leave the hand");
        helper.succeed();
    }

    // --- Energía (T105) ---

    @GameTest(template = EMPTY)
    public static void energyChargeRespectsPerTickRateFromAnyFace(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        int rate = RailgunConfig.reactorChargeRate();
        IEnergyStorage a = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK,
                helper.absolutePos(CONTROLLER.offset(1, 1, -1)), Direction.UP);
        IEnergyStorage b = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK,
                helper.absolutePos(CONTROLLER.below()), Direction.DOWN);
        IEnergyStorage c = helper.getLevel().getCapability(Capabilities.EnergyStorage.BLOCK,
                helper.absolutePos(CONTROLLER), null);
        check(helper, a != null && b != null && c != null, "parts and controller must expose FE");
        check(helper, a.receiveEnergy(rate / 2, false) == rate / 2, "first half should go in");
        check(helper, b.receiveEnergy(rate, false) == rate - rate / 2, "the rest of the tick's quota only");
        check(helper, c.receiveEnergy(rate, false) == 0, "quota exhausted this tick");
        check(helper, a.extractEnergy(1000, false) == 0, "receive-only");
        check(helper, be.getEnergy().getEnergyStored() == rate, "stored should equal one tick's quota");
        helper.runAfterDelay(2, () -> {
            check(helper, c.receiveEnergy(Integer.MAX_VALUE, false) == rate, "a new tick restores the quota");
            check(helper, be.getEnergy().getEnergyStored() == 2 * rate, "stored should be two quotas");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void activationNeedsFullEnergyAndEmptiesIt(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        be.getFluidHandler().fill(phase(CategoryReactorBlockEntity.TANK_CAPACITY), IFluidHandler.FluidAction.EXECUTE);
        be.getItems().setStackInSlot(0, InductionFactorItem.of(Teleporter.ID));
        be.getEnergy().setEnergy(CategoryReactorBlockEntity.ENERGY_CAPACITY - 1);
        CategoryReactorMenu menu = new CategoryReactorMenu(1, player.getInventory(), be, player);
        check(helper, menu.getStatus() == Status.NEED_ENERGY, "got " + menu.getStatus());
        check(helper, menu.getEnergyAmount() == CategoryReactorBlockEntity.ENERGY_CAPACITY - 1,
                "the menu must sync the energy (> 32767), got " + menu.getEnergyAmount());
        check(helper, be.tryActivate(player) == Status.NEED_ENERGY, "must refuse with 499 999 IF");
        check(helper, be.getTank().getFluidAmount() == CategoryReactorBlockEntity.TANK_CAPACITY
                && !be.getFactor().isEmpty() && be.getEnergy().getEnergyStored() == 499_999,
                "a refused activation must not consume anything");
        be.getEnergy().setEnergy(CategoryReactorBlockEntity.ENERGY_CAPACITY);
        check(helper, be.tryActivate(player) == Status.READY, "full buffer should activate");
        check(helper, be.getEnergy().getEnergyStored() == 0, "the buffer is emptied entirely");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void activationIsFreeWhenEnergyNotRequired(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        be.getFluidHandler().fill(phase(CategoryReactorBlockEntity.TANK_CAPACITY), IFluidHandler.FluidAction.EXECUTE);
        be.getItems().setStackInSlot(0, InductionFactorItem.of(Teleporter.ID));
        RailgunConfig.setEnergyRequiredOverrideForTests(false);
        try {
            check(helper, be.tryActivate(player) == Status.READY, "no energy needed when not required");
        } finally {
            RailgunConfig.setEnergyRequiredOverrideForTests(null);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void energyBufferPersistsInNbt(GameTestHelper helper) {
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        CategoryReactorBlockEntity be = build(helper, player);
        be.getEnergy().setEnergy(123_456);
        net.minecraft.nbt.CompoundTag tag = be.saveWithoutMetadata(helper.getLevel().registryAccess());
        be.getEnergy().setEnergy(0);
        be.loadWithComponents(tag, helper.getLevel().registryAccess());
        check(helper, be.getEnergy().getEnergyStored() == 123_456, "got " + be.getEnergy().getEnergyStored());
        helper.succeed();
    }

    // --- Utilidades ---

    private static FluidStack phase(int amount) {
        return new FluidStack(ModFluids.PHASE_LIQUID.get(), amount);
    }

    private static InteractionResult use(GameTestHelper helper, ServerPlayer player) {
        helper.setBlock(CLICKED, Blocks.STONE);
        BlockPos clicked = helper.absolutePos(CLICKED);
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(clicked).add(0, 0.5, 0), Direction.UP, clicked, false);
        return player.getMainHandItem().useOn(new UseOnContext(player, InteractionHand.MAIN_HAND, hit));
    }

    private static CategoryReactorBlockEntity build(GameTestHelper helper, ServerPlayer player) {
        BlockPos base = helper.absolutePos(BASE);
        if (!CategoryReactorStructure.build(helper.getLevel(), base, player)) {
            throw new IllegalStateException("the reactor could not be built");
        }
        if (helper.getLevel().getBlockEntity(CategoryReactorStructure.controllerFromBase(base))
                instanceof CategoryReactorBlockEntity be) {
            return be;
        }
        throw new IllegalStateException("reactor block entity missing");
    }

    /** Jugador falso como en CoinGameTests: el listener descarta los paquetes (los payloads del mod no se negocian). */
    private static ServerPlayer player(GameTestHelper helper, GameType mode) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-reactor-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setGameMode(mode);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }
}
