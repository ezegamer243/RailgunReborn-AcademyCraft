package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.FlashingRules;
import com.railgunreborn.ability.teleporter.FlashingSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Flashing (T63). Los saltos (12 bloques a exp 0) no caben en la estructura de 9x9 en horizontal: el
 * salto libre va en diagonal y hacia arriba en la estructura alta; el de la pared, en la de 9x9.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class FlashingGameTests {
    private static final String EMPTY = "empty";
    private static final String TALL = "tall";
    private static final int ID = 1;
    private static final float EPS = 0.01f;

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar.
        player.setYHeadRot(yaw);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Teleporter nivel 5 con Flashing aprendida (exp 0), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(5);
        Skill skill = Teleporter.FLASHING.get();
        ability.learnSkill(skill.getId());
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Arranca el modo y suelta la tecla de la habilidad (el modo no depende de mantenerla). */
    private static void startMode(GameTestHelper helper, ServerPlayer player, Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
    }

    private static void tick(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static void jump(ServerPlayer player, FlashingRules.Dir dir) {
        CompoundTag data = new CompoundTag();
        data.putInt(FlashingSkill.DIR_KEY, dir.id());
        SkillContexts.handleClientMessage(player, ID, FlashingSkill.CHANNEL_JUMP, data);
    }

    private static boolean modeAlive(ServerPlayer player) {
        return SkillContexts.active(player).snapshot().stream()
                .anyMatch(ctx -> ctx instanceof FlashingSkill.FlashingContext f && f.isStarted());
    }

    @GameTest(template = EMPTY)
    public static void flashingIsRegisteredAtLevel5(GameTestHelper helper) {
        Skill skill = Teleporter.FLASHING.get();
        check(helper, skill.getId().equals(Teleporter.skillId("flashing")), "id " + skill.getId());
        check(helper, skill.getCategoryId().equals(Teleporter.ID), "belongs to teleporter");
        check(helper, skill.getLevel() == 5 && skill.canControl(), "level 5, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.SHIFT_TP_ID)
                && Math.abs(p.minExp() - 0.8f) < 1e-6f).orElse(false), "parent: shift_tp 0.8");
        check(helper, skill.getGuiX() == 220 && skill.getGuiY() == 20, "tree position should be 220, 20");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/flashing.png"),
                "icon " + skill.getIcon());
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Teleporter.SPACE_FLUCT.get())
                < AbilityRegistries.SKILL_REGISTRY.getId(skill), "registered after space fluct");
        check(helper, Teleporter.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void startingChargesAndOpensTheMode(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-flash-start", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        startMode(helper, player, skill);
        check(helper, Math.abs(cpBefore - cp.getCP() - FlashingRules.startCp(0f)) < EPS,
                "pays 80 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - FlashingRules.startOverload(0f)) < EPS,
                "adds 250 overload, was " + cp.getOverload());
        check(helper, modeAlive(player), "releasing the skill key keeps the mode alive");
        float overload = cp.getOverload();
        tick(player, 30);
        check(helper, modeAlive(player), "still alive after 30 ticks");
        check(helper, cp.getOverload() >= overload - EPS, "overload does not go down during the mode");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown while the mode lasts");
        helper.succeed();
    }

    @GameTest(template = TALL)
    public static void forwardJumpTeleportsTheFullDistance(GameTestHelper helper) {
        floor(helper);
        // Diagonal hacia +X+Z y 40° hacia arriba: 12 bloques caben en la estructura alta.
        Vec3 start = new Vec3(0.8, 1, 0.8);
        ServerPlayer player = player(helper, "test-flash-jump", start, -45f, -40f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        player.fallDistance = 3f;
        startMode(helper, player, skill);
        float cpBefore = cp.getCP();

        jump(player, FlashingRules.Dir.FORWARD);

        double[] d = FlashingRules.direction(FlashingRules.Dir.FORWARD, -45f, -40f);
        Vec3 expected = helper.absoluteVec(start).add(new Vec3(d[0], d[1], d[2]).scale(FlashingRules.distance(0f)));
        check(helper, player.position().distanceTo(expected) < 1e-3,
                "jumps 12 blocks along the view, moved " + player.position().subtract(helper.absoluteVec(start)));
        check(helper, Math.abs(cpBefore - cp.getCP() - FlashingRules.jumpCp(0f)) < EPS,
                "pays 13 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - FlashingRules.JUMP_EXP) < 1e-6f,
                "+0.002 exp");
        check(helper, player.fallDistance == 0f, "fall distance reset");
        check(helper, SafeTeleport.isFallGuarded(player), "in the air: fall guarded");
        check(helper, modeAlive(player), "the mode goes on after a jump");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void jumpAgainstAWallStopsInFrontOfIt(GameTestHelper helper) {
        floor(helper);
        for (int x = 0; x < 9; x++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(x, y, 5), Blocks.STONE);
            }
        }
        Vec3 start = new Vec3(4.5, 1, 0.5);
        ServerPlayer player = player(helper, "test-flash-wall", start, 0f, 0f);
        Skill skill = setUp(player);
        startMode(helper, player, skill);
        float cpBefore = CPData.get(player).getCP();

        jump(player, FlashingRules.Dir.FORWARD);

        Vec3 moved = player.position().subtract(helper.absoluteVec(start));
        // La cara de la pared está a z 5: la caja (medio ancho 0.3) se queda justo delante.
        check(helper, moved.z > 4.2 - 0.01 && moved.z <= 4.2 + 1e-6 && Math.abs(moved.x) < 1e-6
                && Math.abs(moved.y) < 1e-6, "stops in front of the wall, moved " + moved);
        check(helper, SafeTeleport.isSafeSpot(helper.getLevel(), player, player.position()), "not inside the wall");
        check(helper, cpBefore - CPData.get(player).getCP() > 0f, "the jump is paid");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void jumpWithoutRoomDoesNothing(GameTestHelper helper) {
        floor(helper);
        for (int x = 0; x < 9; x++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(x, y, 1), Blocks.STONE);
            }
        }
        // Pegado a la pared: no hay hueco ni a medio bloque.
        Vec3 start = new Vec3(4.5, 1, 0.7);
        ServerPlayer player = player(helper, "test-flash-room", start, 0f, 0f);
        Skill skill = setUp(player);
        startMode(helper, player, skill);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        jump(player, FlashingRules.Dir.FORWARD);
        check(helper, player.position().distanceTo(helper.absoluteVec(start)) < 1e-6, "does not move");
        check(helper, cp.getCP() == cpBefore, "no cost");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        check(helper, modeAlive(player), "the mode goes on");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void endingTheModeSetsTheCooldown(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-flash-end", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = setUp(player);
        startMode(helper, player, skill);
        // El cliente lo termina (volver a pulsar la tecla o V).
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, SkillContexts.active(player).isEmpty(), "the mode ends");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == FlashingRules.cooldown(0f),
                "cooldown of 900 ticks");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void theModeEndsWhenTimeRunsOut(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-flash-time", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = setUp(player);
        startMode(helper, player, skill);
        tick(player, FlashingRules.maxTicks(0f));
        check(helper, modeAlive(player), "alive during the 60 ticks");
        tick(player, 1);
        check(helper, SkillContexts.active(player).isEmpty(), "ends after 60 ticks");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == FlashingRules.cooldown(0f),
                "cooldown starts when the mode ends");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutCpTheModeDoesNotStart(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-flash-nocp", new Vec3(4.5, 1, 4.5), 0f, 0f);
        Skill skill = setUp(player);
        CPData cp = CPData.get(player);
        cp.consume(player, 0f, cp.getCP() - 50f);
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();
        SkillContexts.start(player, ID, skill);
        check(helper, SkillContexts.active(player).isEmpty(), "the context ends at once");
        check(helper, cp.getCP() == cpBefore && cp.getOverload() == overloadBefore, "nothing charged");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        helper.succeed();
    }
}
