package com.railgunreborn.gametest;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.generic.GenericSkill;
import com.railgunreborn.ability.vecmanip.PlasmaCannonRules;
import com.railgunreborn.ability.vecmanip.PlasmaCannonSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;
import com.railgunreborn.registry.ModDamageTypes;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Plasma Cannon (T77). Jugador falso en (4.5, 1, 1.5) mirando a +z hacia un muro de tierra en z = 5 sobre
 * un suelo de piedra; la bola nace encima (bajo el techo de la plantilla, a 5) y baja hasta el muro. Con radios reducidos
 * ({@link PlasmaCannonSkill#testRadii}): un radio de 12 rompería las plantillas vecinas. Todo pasa dentro de una sola
 * llamada (la gamerule se cambia y se restaura sin que corra otra prueba en medio).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class PlasmaCannonGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    /** Exp alta pero < 1 (la exp ganada se nota) y con overload fijo que cabe a nivel 5 (410 < 500). */
    private static final float EXP = 0.9f;
    private static final int WALL_Z = 5;
    private static final BlockPos AIMED = new BlockPos(4, 2, WALL_Z);
    private static final PlasmaCannonSkill.TestRadii RADII = new PlasmaCannonSkill.TestRadii(2.5f, 5.0);

    /** Casillas (absolutas) que el protector de prueba no deja romper. */
    private static final Set<BlockPos> PROTECTED = ConcurrentHashMap.newKeySet();

    /** Mod de protección de prueba: cancela la rotura en {@link #PROTECTED}. */
    @EventBusSubscriber(modid = RailgunReborn.MODID)
    public static final class TestProtector {
        private TestProtector() {
        }

        @SubscribeEvent
        public static void onBreak(BlockEvent.BreakEvent event) {
            if (PROTECTED.contains(event.getPos())) {
                event.setCanceled(true);
            }
        }
    }

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper, Vec3 at, float yaw, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-pc-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, yaw, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(yaw);
        return player;
    }

    private static ServerPlayer player(GameTestHelper helper) {
        return player(helper, new Vec3(4.5, 1, 1.5), 0f, 0f);
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floorAndWall(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
        for (int x = 1; x <= 7; x++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(x, y, WALL_Z), Blocks.DIRT);
            }
        }
    }

    private static int wallBlocks(GameTestHelper helper) {
        int count = 0;
        for (int x = 1; x <= 7; x++) {
            for (int y = 1; y <= 3; y++) {
                if (helper.getBlockState(new BlockPos(x, y, WALL_Z)).is(Blocks.DIRT)) {
                    count++;
                }
            }
        }
        return count;
    }

    /** Vector Manipulation nivel 5 con Plasma Cannon (exp dada), máximos del nivel, CP lleno y modo habilidad. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(5);
        Skill skill = VecManip.PLASMA_CANNON.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.recalcMaxValues(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    /** Golem de 500 de vida (sobrevive al daño) junto al muro, dentro de la esfera de daño de prueba. */
    private static IronGolem golem(GameTestHelper helper) {
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(6.5, 1, 3.5));
        golem.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500.0);
        golem.setHealth(500f);
        return golem;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Pulsa, mantiene {@code ticks}, suelta y deja volar la bola hasta que el contexto termine. */
    private static void shoot(GameTestHelper helper, ServerPlayer player, Skill skill, int ticks) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        ping(player, ticks);
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        for (int i = 0; i < 300 && PlasmaCannonSkill.active(player) != null; i++) {
            ping(player, 1);
        }
        check(helper, PlasmaCannonSkill.active(player) == null, "the context should end after the explosion");
    }

    private static void withGriefing(GameTestHelper helper, boolean mobGriefing, Runnable action) {
        MinecraftServer server = helper.getLevel().getServer();
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        PlasmaCannonSkill.testRadii = RADII;
        try {
            rule.set(mobGriefing, server);
            action.run();
        } finally {
            rule.set(original, server);
            PlasmaCannonSkill.testRadii = null;
        }
    }

    private static float exp(ServerPlayer player, Skill skill) {
        return AbilityData.get(player).getSkillExp(skill.getId());
    }

    private static float expectedDamage(Skill skill) {
        return PlasmaCannonRules.damage(EXP) * skill.getDamageScale();
    }

    // --- pruebas ---

    @GameTest(template = EMPTY)
    public static void plasmaCannonIsRegisteredAtLevel5UnderStormWing(GameTestHelper helper) {
        Skill skill = VecManip.PLASMA_CANNON.get();
        check(helper, skill.getCategoryId().equals(VecManip.ID), "belongs to vecmanip");
        check(helper, skill.getLevel() == 5 && skill.canControl() && !skill.isToggle(),
                "level 5, controllable, held");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(VecManip.STORM_WING.getId())
                && Math.abs(skill.getParent().get().minExp()) < EPS, "parent: storm_wing (0.0)");
        check(helper, skill.getGuiX() == 175 && skill.getGuiY() == 14, "tree position should be 175, 14");
        List<Skill> skills = VecManip.CATEGORY.get().getSkills();
        int index = skills.indexOf(skill);
        check(helper, index > skills.indexOf(VecManip.BLOOD_RETRO.get()), "registered after blood_retro");
        check(helper, index + 1 == skills.size() || skills.get(index + 1) instanceof GenericSkill,
                "the last own skill, right before the generic ones");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/plasma_cannon.png"),
                "icon " + skill.getIcon());
        check(helper, helper.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(ModDamageTypes.PLASMA_CANNON).isPresent(), "damage type plasma_cannon loaded");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void releasingBeforeTheChargeLosesItWithoutCooldown(GameTestHelper helper) {
        floorAndWall(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        IronGolem golem = golem(helper);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();

        withGriefing(helper, true, () -> {
            check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
            PlasmaCannonSkill.PlasmaCannonContext ctx = PlasmaCannonSkill.active(player);
            check(helper, ctx != null && ctx.chargeTicks() == PlasmaCannonRules.chargeTicks(EXP), "charge ticks");
            // La plantilla tiene techo a 5 bloques: la bola se queda debajo (sin techo, a 15; ver la prueba JUnit).
            double height = ctx.ball().y - player.getY();
            check(helper, height >= player.getEyeHeight() - 1e-6 && height <= 5.0 - PlasmaCannonRules.CEILING_MARGIN
                    + 1e-6 && ctx.ball().x == player.getX() && ctx.ball().z == player.getZ(),
                    "the ball forms above the caster, under the ceiling, at height " + height);
            check(helper, Math.abs(cp.getOverload() - PlasmaCannonRules.overload(EXP)) < 0.5f,
                    "fixed overload added on press, was " + cp.getOverload());
            ping(player, 10);
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        });

        check(helper, PlasmaCannonSkill.active(player) == null, "releasing early ends the context");
        check(helper, Math.abs(cpBefore - cp.getCP() - 10 * PlasmaCannonRules.cpPerTick(EXP)) < 0.5f,
                "the CP of 10 charge ticks is lost, spent " + (cpBefore - cp.getCP()));
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 0, "no cooldown");
        check(helper, golem.getHealth() == 500f, "nothing is hurt");
        check(helper, wallBlocks(helper) == 21, "nothing is broken");
        check(helper, exp(player, skill) == EXP, "no exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void chargedShotExplodesAtTheWallHurtsMobsAndBreaksBlocks(GameTestHelper helper) {
        floorAndWall(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        IronGolem golem = golem(helper);
        ItemEntity item = new ItemEntity(helper.getLevel(), 0, 0, 0, new ItemStack(Items.DIAMOND));
        Vec3 itemPos = helper.absoluteVec(new Vec3(3.5, 1, 4.2));
        item.setPos(itemPos.x, itemPos.y, itemPos.z);
        item.setDeltaMovement(Vec3.ZERO);
        helper.getLevel().addFreshEntity(item);

        withGriefing(helper, true, () -> shoot(helper, player, skill, PlasmaCannonRules.chargeTicks(EXP)));

        check(helper, Math.abs(500f - golem.getHealth() - expectedDamage(skill)) < 0.5f,
                "flat damage " + expectedDamage(skill) + ", lost " + (500f - golem.getHealth()));
        check(helper, player.getHealth() == player.getMaxHealth(), "the caster is immune");
        check(helper, item.isAlive() && item.getItem().is(Items.DIAMOND), "items on the ground are not destroyed");
        check(helper, helper.getBlockState(AIMED).isAir(), "the aimed block is blown up");
        check(helper, wallBlocks(helper) < 20, "the explosion breaks several blocks, left " + wallBlocks(helper));
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == PlasmaCannonRules.cooldown(EXP),
                "cooldown set on fire");
        check(helper, Math.abs(exp(player, skill) - EXP - PlasmaCannonRules.EXP * skill.getExpIncrSpeed()) < 1e-5f,
                "exp +0.008, now " + exp(player, skill));
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void casterIsImmuneAtGroundZero(GameTestHelper helper) {
        floorAndWall(helper);
        ServerPlayer player = player(helper, new Vec3(4.5, 1, 3.5), 0f, 0f);
        Skill skill = setUp(player, EXP);
        IronGolem golem = golem(helper);

        withGriefing(helper, false, () -> {
            check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
            ping(player, PlasmaCannonRules.chargeTicks(EXP));
            PlasmaCannonSkill.PlasmaCannonContext ctx = PlasmaCannonSkill.active(player);
            check(helper, ctx != null && ctx.phase() == PlasmaCannonSkill.Phase.CHARGED, "charged");
            ctx.explode(player.position().add(0, 1, 0));
            check(helper, ctx.hasExploded() && ctx.isTerminated(), "one explosion ends the context");
        });

        check(helper, player.getHealth() == player.getMaxHealth(), "the caster takes no damage");
        check(helper, player.getDeltaMovement().lengthSqr() < 1e-6, "the caster is not pushed either");
        check(helper, golem.getHealth() < 500f, "the golem next to it is hurt");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mobGriefingOffBreaksNothingButStillHurts(GameTestHelper helper) {
        floorAndWall(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        IronGolem golem = golem(helper);

        withGriefing(helper, false, () -> shoot(helper, player, skill, PlasmaCannonRules.chargeTicks(EXP)));

        check(helper, wallBlocks(helper) == 21, "the wall is intact, left " + wallBlocks(helper));
        check(helper, helper.getBlockState(new BlockPos(4, 0, 4)).is(Blocks.STONE), "the floor is intact");
        check(helper, Math.abs(500f - golem.getHealth() - expectedDamage(skill)) < 0.5f, "the damage still applies");
        check(helper, exp(player, skill) > EXP, "hurting something gives exp");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void protectedBlockIsUntouched(GameTestHelper helper) {
        floorAndWall(helper);
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, EXP);
        BlockPos guarded = helper.absolutePos(AIMED);
        PROTECTED.add(guarded);
        try {
            withGriefing(helper, true, () -> shoot(helper, player, skill, PlasmaCannonRules.chargeTicks(EXP)));
        } finally {
            PROTECTED.remove(guarded);
        }

        check(helper, helper.getBlockState(AIMED).is(Blocks.DIRT), "the protected block stays");
        check(helper, wallBlocks(helper) < 21, "unprotected blocks around it still break");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void insufficientOverloadIsRejectedOnPress(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        // Exp 0: overload fijo de 500 = máximo de nivel 5 sin bonus: no cabe.
        Skill skill = setUp(player, 0f);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        check(helper, Math.abs(cp.getMaxOverload() - 500f) < EPS, "level 5 max overload 500, was "
                + cp.getMaxOverload());

        StartResult result = SkillContexts.start(player, ID, skill);

        check(helper, !result.isSuccess(), "rejected, was " + result);
        check(helper, PlasmaCannonSkill.active(player) == null, "no context");
        check(helper, cp.getOverload() == 0f && cp.getCP() == cpBefore && !cp.isOverloaded(), "nothing is spent");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 0, "no cooldown");

        // Con exp 1 (400) sí cabe, pero no con 100 de overload previo.
        AbilityData.get(player).setSkillExp(skill.getId(), 1f);
        // Sin consume: este sumaría bonus al máximo.
        cp.raiseOverloadTo(100f);
        check(helper, !SkillContexts.start(player, ID + 1, skill).isSuccess(), "400 + 100 does not fit either");
        cp.recoverAll();
        check(helper, SkillContexts.start(player, ID + 2, skill).isSuccess(), "400 fits with no previous overload");
        helper.succeed();
    }
}
