package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.registry.ModBlocks;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de integración de Electromaster (T36): recorrer el árbol completo con un Developer avanzado real,
 * y reglas comunes a todas las habilidades (modo habilidad, presets, genéricas sin tecla).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ElectromasterIntegrationGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-integration-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar y la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Las nueve habilidades con tecla de Electromaster. */
    private static List<Skill> controllable() {
        return List.of(Electromaster.ARC_GEN.get(), Electromaster.CHARGING.get(),
                Electromaster.BODY_INTENSIFY.get(), Electromaster.MAG_MOVEMENT.get(),
                Electromaster.THUNDER_BOLT.get(), Electromaster.MAG_MANIP.get(), Electromaster.RAILGUN.get(),
                Electromaster.MINE_DETECT.get(), Electromaster.THUNDER_CLAP.get());
    }

    private static void learn(GameTestHelper helper, ServerPlayer player, DeveloperMenu menu, Skill skill,
            DeveloperType type) {
        DevelopResult started = menu.start(player, DevelopAction.learn(skill));
        check(helper, started == DevelopResult.OK, skill + " should start learning, was " + started);
        for (int i = 0, n = DevelopRules.totalTicks(skill.getLearningStims(), type); i < n; i++) {
            menu.serverTick(player);
        }
        check(helper, menu.getResult() == DevelopResult.OK, skill + " should finish OK, was " + menu.getResult());
        check(helper, AbilityData.get(player).isLearned(skill.getId()), skill + " should be learned");
    }

    @GameTest(template = EMPTY, timeoutTicks = 400)
    public static void wholeTreeLearnedInOrderWithAdvancedDeveloper(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_ADVANCED.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperEnergyTesting.fill(helper.getLevel(), block);
        DeveloperType type = DeveloperType.ADVANCED;
        DeveloperMenu menu = DeveloperMenu.open(player, type, block);
        check(helper, menu != null, "advanced developer should open");

        Skill arcGen = Electromaster.ARC_GEN.get();
        Skill charging = Electromaster.CHARGING.get();
        Skill magMovement = Electromaster.MAG_MOVEMENT.get();
        Skill magManip = Electromaster.MAG_MANIP.get();
        Skill thunderBolt = Electromaster.THUNDER_BOLT.get();
        Skill railgun = Electromaster.RAILGUN.get();
        Skill mineDetect = Electromaster.MINE_DETECT.get();
        Skill bodyIntensify = Electromaster.BODY_INTENSIFY.get();
        Skill thunderClap = Electromaster.THUNDER_CLAP.get();

        // Sin la raíz no se aprende nada de las ramas.
        for (Skill s : List.of(charging, magMovement, thunderBolt, railgun)) {
            DevelopResult early = s.checkLearn(data, type);
            check(helper, early == DevelopResult.PARENT_NOT_MET, s + " needs its parent, was " + early);
        }

        learn(helper, player, menu, arcGen, type);
        data.setSkillExp(arcGen.getId(), 0.3f);
        learn(helper, player, menu, charging, type);
        data.setSkillExp(charging.getId(), 0.7f);
        learn(helper, player, menu, magMovement, type);
        data.setSkillExp(magMovement.getId(), 0.5f);
        learn(helper, player, menu, magManip, type);
        learn(helper, player, menu, thunderBolt, type);
        data.setSkillExp(thunderBolt.getId(), 0.3f);

        // Railgun: Thunder Bolt 0.3 no basta, hace falta Mag Manip al 100 %.
        check(helper, menu.start(player, DevelopAction.learn(railgun)) == DevelopResult.DEPENDENCY_NOT_MET,
                "railgun must be refused while mag_manip < 1.0");
        data.setSkillExp(magManip.getId(), 1.0f);
        learn(helper, player, menu, railgun, type);

        learn(helper, player, menu, mineDetect, type);
        // Body Intensify pide Arc Gen y Current Charging al 100 %.
        check(helper, menu.start(player, DevelopAction.learn(bodyIntensify)) == DevelopResult.PARENT_NOT_MET,
                "body_intensify must be refused while arc_gen < 1.0");
        data.setSkillExp(arcGen.getId(), 1.0f);
        check(helper, menu.start(player, DevelopAction.learn(bodyIntensify)) == DevelopResult.DEPENDENCY_NOT_MET,
                "body_intensify must be refused while charging < 1.0");
        data.setSkillExp(charging.getId(), 1.0f);
        learn(helper, player, menu, bodyIntensify, type);
        // Thunderclap pide Thunder Bolt al 100 %.
        check(helper, menu.start(player, DevelopAction.learn(thunderClap)) == DevelopResult.PARENT_NOT_MET,
                "thunder_clap must be refused while thunder_bolt < 1.0");
        data.setSkillExp(thunderBolt.getId(), 1.0f);
        learn(helper, player, menu, thunderClap, type);

        check(helper, data.getLearnedSkills().size() == 9, "nine skills learned, was " + data.getLearnedSkills());
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noSkillStartsWithAbilityModeOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        for (Skill s : controllable()) {
            data.learnSkill(s.getId());
        }
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, false);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.MODE_OFF, s + " must need ability mode, was " + result);
        }
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.OK, s + " should start with mode on, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void unlearnedSkillsAreRefusedEvenWithModeOn(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        for (Skill s : controllable()) {
            StartResult result = SkillContexts.validateStart(player, s);
            check(helper, result == StartResult.NOT_LEARNED, s + " must be refused if not learned, was " + result);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void genericsHaveNoKeyAndCannotBeInPresets(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        CPData cp = CPData.get(player);
        cp.recoverAll();
        cp.setActivated(player, true);
        Electromaster.GENERICS.values().forEach(holder -> {
            Skill s = holder.get();
            data.learnSkill(s.getId());
            StartResult start = SkillContexts.validateStart(player, s);
            check(helper, start == StartResult.NOT_CONTROLLABLE, s + " has no key, was " + start);
            PresetRules.Result edit = PresetRules.applyEdit(player, 0, 0, s.getId());
            check(helper, edit == PresetRules.Result.NOT_CONTROLLABLE, s + " not allowed in presets, was " + edit);
        });
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void everyElectromasterSkillFitsInPresetsWithoutDuplicates(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        List<Skill> skills = controllable();
        for (Skill s : skills) {
            data.learnSkill(s.getId());
        }
        for (int i = 0; i < skills.size(); i++) {
            ResourceLocation id = skills.get(i).getId();
            PresetRules.Result result = PresetRules.applyEdit(player, i / 4, i % 4, id);
            check(helper, result == PresetRules.Result.OK, id + " should fit in a preset, was " + result);
        }
        // La misma habilidad dos veces en el mismo preset se rechaza.
        PresetRules.Result dup = PresetRules.applyEdit(player, 0, 3, skills.get(0).getId());
        check(helper, dup == PresetRules.Result.DUPLICATE, "duplicate in a preset must be refused, was " + dup);
        helper.succeed();
    }
}
