package com.railgunreborn.gametest;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** Menas en el mundo (T83): features registradas, biome modifiers, drops con Fortuna/toque de seda y etiquetas. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class OreWorldGenGameTests {
    private static final String EMPTY = "empty";
    private static final List<String> ORES = List.of("constraint_metal", "crystal_ore", "imagsil_ore", "reso_ore");

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, path);
    }

    private static List<ItemStack> drops(GameTestHelper helper, Block block, ItemStack tool) {
        ServerLevel level = helper.getLevel();
        ResourceKey<LootTable> key = ResourceKey.create(Registries.LOOT_TABLE, id("blocks/" + block.builtInRegistryHolder().key().location().getPath()));
        LootTable table = level.getServer().reloadableRegistries().getLootTable(key);
        LootParams params = new LootParams.Builder(level)
                .withParameter(LootContextParams.ORIGIN, Vec3.ZERO)
                .withParameter(LootContextParams.BLOCK_STATE, block.defaultBlockState())
                .withParameter(LootContextParams.TOOL, tool)
                .create(LootContextParamSets.BLOCK);
        return table.getRandomItems(params);
    }

    private static ItemStack pickaxe(GameTestHelper helper, net.minecraft.resources.ResourceKey<net.minecraft.world.item.enchantment.Enchantment> ench, int lvl) {
        ItemStack tool = new ItemStack(Items.IRON_PICKAXE);
        if (ench != null) {
            tool.enchant(helper.getLevel().registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ench), lvl);
        }
        return tool;
    }

    private static int count(List<ItemStack> list, Item item) {
        int n = 0;
        for (ItemStack s : list) {
            if (s.is(item)) {
                n += s.getCount();
            }
        }
        return n;
    }

    @GameTest(template = EMPTY)
    public static void featuresAndBiomeModifiersExist(GameTestHelper helper) {
        var access = helper.getLevel().registryAccess();
        Registry<ConfiguredFeature<?, ?>> configured = access.registryOrThrow(Registries.CONFIGURED_FEATURE);
        Registry<PlacedFeature> placed = access.registryOrThrow(Registries.PLACED_FEATURE);
        var modifiers = access.registryOrThrow(NeoForgeRegistries.Keys.BIOME_MODIFIERS);
        for (String ore : ORES) {
            if (!configured.containsKey(id(ore))) {
                helper.fail("missing configured_feature " + ore);
            }
            if (!placed.containsKey(id(ore))) {
                helper.fail("missing placed_feature " + ore);
            }
            if (!modifiers.containsKey(id(ore))) {
                helper.fail("missing biome_modifier " + ore);
            }
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void selfDroppingOresDropThemselves(GameTestHelper helper) {
        ItemStack tool = pickaxe(helper, null, 0);
        if (count(drops(helper, ModBlocks.CONSTRAINT_METAL.get(), tool), ModItems.CONSTRAINT_METAL.get()) != 1) {
            helper.fail("constraint_metal should drop itself once");
        }
        if (count(drops(helper, ModBlocks.IMAGSIL_ORE.get(), tool), ModItems.IMAGSIL_ORE.get()) != 1) {
            helper.fail("imagsil_ore should drop itself once");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void crystalOresDropCrystals(GameTestHelper helper) {
        ItemStack tool = pickaxe(helper, null, 0);
        for (int i = 0; i < 60; i++) {
            int low = count(drops(helper, ModBlocks.CRYSTAL_ORE.get(), tool), ModItems.CRYSTAL_LOW.get());
            if (low < 1 || low > 3) {
                helper.fail("crystal_ore dropped " + low + " crystal_low (expected 1-3)");
            }
            int reso = count(drops(helper, ModBlocks.RESO_ORE.get(), tool), ModItems.RESO_CRYSTAL.get());
            if (reso < 1 || reso > 2) {
                helper.fail("reso_ore dropped " + reso + " reso_crystal (expected 1-2)");
            }
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fortuneIncreasesDrops(GameTestHelper helper) {
        ItemStack plain = pickaxe(helper, null, 0);
        ItemStack fortune = pickaxe(helper, Enchantments.FORTUNE, 3);
        int base = 0;
        int boosted = 0;
        int max = 0;
        for (int i = 0; i < 300; i++) {
            base += count(drops(helper, ModBlocks.CRYSTAL_ORE.get(), plain), ModItems.CRYSTAL_LOW.get());
            int n = count(drops(helper, ModBlocks.CRYSTAL_ORE.get(), fortune), ModItems.CRYSTAL_LOW.get());
            boosted += n;
            max = Math.max(max, n);
        }
        if (boosted <= base * 1.5) {
            helper.fail("fortune III should clearly increase drops: " + boosted + " vs " + base);
        }
        if (max <= 3) {
            helper.fail("fortune III should exceed the base maximum of 3 at least once");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void silkTouchGivesTheBlock(GameTestHelper helper) {
        ItemStack silk = pickaxe(helper, Enchantments.SILK_TOUCH, 1);
        List<ItemStack> crystal = drops(helper, ModBlocks.CRYSTAL_ORE.get(), silk);
        if (count(crystal, ModItems.CRYSTAL_ORE.get()) != 1 || count(crystal, ModItems.CRYSTAL_LOW.get()) != 0) {
            helper.fail("silk touch on crystal_ore should give only the block");
        }
        List<ItemStack> reso = drops(helper, ModBlocks.RESO_ORE.get(), silk);
        if (count(reso, ModItems.RESO_ORE.get()) != 1 || count(reso, ModItems.RESO_CRYSTAL.get()) != 0) {
            helper.fail("silk touch on reso_ore should give only the block");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void oresHaveCommonTags(GameTestHelper helper) {
        for (Block block : List.of(ModBlocks.CONSTRAINT_METAL.get(), ModBlocks.CRYSTAL_ORE.get(),
                ModBlocks.IMAGSIL_ORE.get(), ModBlocks.RESO_ORE.get())) {
            if (!block.defaultBlockState().is(Tags.Blocks.ORES) || !block.defaultBlockState().is(Tags.Blocks.ORES_IN_GROUND_STONE)) {
                helper.fail("block missing c:ores tags: " + block);
            }
            if (!block.defaultBlockState().is(BlockTags.MINEABLE_WITH_PICKAXE)) {
                helper.fail("block not pickaxe-mineable: " + block);
            }
            if (!new ItemStack(block).is(Tags.Items.ORES)) {
                helper.fail("item missing c:ores: " + block);
            }
        }
        if (!new ItemStack(ModItems.CONSTRAINT_INGOT.get()).is(Tags.Items.INGOTS)
                || !new ItemStack(ModItems.CRYSTAL_LOW.get()).is(Tags.Items.GEMS)
                || !new ItemStack(ModItems.RESO_CRYSTAL.get()).is(Tags.Items.GEMS)) {
            helper.fail("ingots/gems tags missing");
        }
        helper.succeed();
    }
}
