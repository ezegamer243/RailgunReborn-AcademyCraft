package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.LocationData;
import com.railgunreborn.ability.teleporter.LocationData.SavedLocation;
import com.railgunreborn.ability.teleporter.LocationTeleportRules;
import com.railgunreborn.ability.teleporter.LocationTeleportSkill;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Location Teleport (T62). Los mensajes de la pantalla se mandan como los manda el cliente: por el canal
 * del contexto ({@link SkillContexts#handleClientMessage}).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class LocationTeleportGameTests {
    private static final String EMPTY = "empty";
    private static final int CTX = 1;
    private static final Vec3 A = new Vec3(1.5, 1, 1.5);
    private static final Vec3 B = new Vec3(6.5, 1, 6.5);

    private static ServerPlayer player(GameTestHelper helper, String name, Vec3 at) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(new GameProfile(UUID.randomUUID(), name),
                false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(at);
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Teleporter nivel 3 con Location Teleport aprendida (exp {@code exp}), CP lleno, modo encendido y pantalla abierta. */
    private static Skill open(GameTestHelper helper, ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(3);
        Skill skill = Teleporter.LOCATION_TELEPORT.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        check(helper, SkillContexts.start(player, CTX, skill) == StartResult.OK, "start should be accepted");
        // Soltar la tecla no cierra la pantalla.
        SkillContexts.handleAction(player, CTX, SkillContextActionPayload.Action.KEY_UP);
        check(helper, !SkillContexts.active(player).isEmpty(), "the context lives while the screen is open");
        return skill;
    }

    private static void add(ServerPlayer player, String name) {
        CompoundTag tag = new CompoundTag();
        tag.putString(LocationTeleportSkill.NAME_KEY, name);
        SkillContexts.handleClientMessage(player, CTX, LocationTeleportSkill.CHANNEL_ADD, tag);
    }

    private static void indexMessage(ServerPlayer player, String channel, int index) {
        CompoundTag tag = new CompoundTag();
        tag.putInt(LocationTeleportSkill.INDEX_KEY, index);
        SkillContexts.handleClientMessage(player, CTX, channel, tag);
    }

    /** Guarda una ubicación en {@code at} (relativa a la prueba) y vuelve a donde estaba. */
    private static void saveAt(GameTestHelper helper, ServerPlayer player, Vec3 at, String name) {
        Vec3 back = player.position();
        Vec3 there = helper.absoluteVec(at);
        player.teleportTo(there.x, there.y, there.z);
        add(player, name);
        player.teleportTo(back.x, back.y, back.z);
    }

    @GameTest(template = EMPTY)
    public static void locationTeleportIsRegisteredAtLevel3(GameTestHelper helper) {
        Skill skill = Teleporter.LOCATION_TELEPORT.get();
        check(helper, skill.getId().equals(Teleporter.skillId("location_teleport")), "id " + skill.getId());
        check(helper, skill.getCategoryId().equals(Teleporter.ID), "belongs to teleporter");
        check(helper, skill.getLevel() == 3 && skill.canControl(), "level 3, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.PENETRATE_TELEPORT_ID)
                && Math.abs(p.minExp() - 0.8f) < 1e-6f).orElse(false), "parent: penetrate_teleport 0.8");
        check(helper, skill.getExtraDependencies().size() == 1
                && skill.getExtraDependencies().get(0).skill().equals(Teleporter.skillId("mark_teleport"))
                && Math.abs(skill.getExtraDependencies().get(0).minExp() - 0.8f) < 1e-6f,
                "dependency: mark_teleport 0.8");
        check(helper, skill.getGuiX() == 118 && skill.getGuiY() == 50, "tree position should be 118, 50");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/location_teleport.png"),
                "icon " + skill.getIcon());
        int id = AbilityRegistries.SKILL_REGISTRY.getId(skill);
        check(helper, AbilityRegistries.SKILL_REGISTRY.getId(Teleporter.FLESH_RIPPING.get()) < id
                && id < AbilityRegistries.SKILL_REGISTRY.getId(Teleporter.SPACE_FLUCT.get()),
                "registered between flesh ripping and space fluct");
        check(helper, Teleporter.CATEGORY.get().getSkills().contains(skill), "listed in the category");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void addAndRemoveRespectTheCapAndSanitizeNames(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-add", A);
        open(helper, player, 0f);
        LocationData data = LocationData.get(player);

        add(player, "  §cHome\u0007 base with a very long name  ");
        check(helper, data.size() == 1, "one location saved, got " + data.size());
        SavedLocation first = data.get(0).orElseThrow();
        check(helper, first.name().equals("cHome base with"), "sanitized to 'cHome base with', was '"
                + first.name() + "'");
        check(helper, first.name().length() <= LocationTeleportRules.MAX_NAME_LENGTH, "at most 16 characters");
        check(helper, first.dimension().equals(Level.OVERWORLD), "saves the dimension");
        check(helper, first.pos().distanceTo(player.position()) < 1e-9, "saves the exact feet position");

        for (int i = 1; i < 20; i++) {
            add(player, "spot " + i);
        }
        check(helper, data.size() == LocationTeleportRules.MAX_LOCATIONS, "capped at 16, got " + data.size());
        check(helper, data.get(15).orElseThrow().name().equals("spot 15"), "the 17th and later are rejected");

        indexMessage(player, LocationTeleportSkill.CHANNEL_REMOVE, 0);
        check(helper, data.size() == 15 && data.get(0).orElseThrow().name().equals("spot 1"),
                "removing index 0 shifts the rest");
        indexMessage(player, LocationTeleportSkill.CHANNEL_REMOVE, 99);
        indexMessage(player, LocationTeleportSkill.CHANNEL_REMOVE, -1);
        check(helper, data.size() == 15, "invalid indices are ignored");
        add(player, "   ");
        check(helper, data.size() == 16 && data.get(15).orElseThrow().name().isEmpty(),
                "a blank name is stored empty (shown as the default name)");
        check(helper, CPData.get(player).getOverload() == 0f, "adding and removing is free");
        check(helper, !SkillContexts.active(player).isEmpty(), "the screen stays open");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void teleportsWithinTheDimensionAndPays(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-tp", A);
        Skill skill = open(helper, player, 0f);
        saveAt(helper, player, B, "far");
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        player.fallDistance = 5f;

        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        Vec3 expected = helper.absoluteVec(B);
        check(helper, player.position().distanceTo(expected) < 1e-3,
                "arrives at the saved spot, was " + player.position().subtract(expected));
        // Distancia ~7 (< 64): factor 8 -> 1600 CP con exp 0.
        check(helper, Math.abs(cpBefore - cp.getCP() - 1600f) < 0.01f, "pays 1600 CP, paid " + (cpBefore - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - LocationTeleportRules.OVERLOAD) < 0.01f,
                "adds 240 overload, was " + cp.getOverload());
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 30, "cooldown of 30 ticks");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - 0.015f) < 1e-6f,
                "gains 0.015 exp");
        check(helper, player.fallDistance == 0f, "fall distance reset");
        check(helper, SkillContexts.active(player).isEmpty(), "the context ends after teleporting");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void blockedDestinationIsRejectedWithoutCost(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-blocked", A);
        Skill skill = open(helper, player, 0f);
        saveAt(helper, player, B, "walled");
        // Se tapa el sitio y todo lo que se prueba alrededor (radio 1, de -1 a +2 de alto).
        for (int x = 4; x <= 8; x++) {
            for (int y = 1; y <= 6; y++) {
                for (int z = 4; z <= 8; z++) {
                    helper.setBlock(new BlockPos(x, y, z), Blocks.STONE);
                }
            }
        }
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        Vec3 start = player.position();
        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        check(helper, player.position().distanceTo(start) < 1e-6, "the player does not move");
        check(helper, cp.getCP() == cpBefore && cp.getOverload() == 0f, "no cost");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp");
        check(helper, !SkillContexts.active(player).isEmpty(), "the screen stays open to pick another");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ownWolfTravelsButZombieDoesNot(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-pets", A);
        open(helper, player, 0f);
        saveAt(helper, player, B, "pets");
        Wolf wolf = helper.spawnWithNoFreeWill(EntityType.WOLF, new Vec3(2.5, 1, 1.5));
        wolf.tame(player);
        Wolf stray = helper.spawnWithNoFreeWill(EntityType.WOLF, new Vec3(1.5, 1, 2.5));
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(0.5, 1, 1.5));
        Vec3 strayStart = stray.position();
        Vec3 zombieStart = zombie.position();

        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        check(helper, player.position().distanceTo(helper.absoluteVec(B)) < 1e-3, "the player teleports");
        Vec3 wolfExpected = helper.absoluteVec(B.add(1, 0, 0));
        check(helper, wolf.position().distanceTo(wolfExpected) < 1e-3,
                "the own wolf keeps its offset, was " + wolf.position().subtract(wolfExpected));
        check(helper, stray.position().distanceTo(strayStart) < 1e-6, "someone else's animal stays");
        check(helper, zombie.position().distanceTo(zombieStart) < 1e-6, "the zombie stays");
        for (Entity e : new Entity[] {wolf, stray, zombie}) {
            e.discard();
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void crossingDimensionsNeedsExpAbove08(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-dim", A);
        Skill skill = open(helper, player, 0.5f);
        ServerLevel nether = helper.getLevel().getServer().getLevel(Level.NETHER);
        check(helper, nether != null, "the nether exists");
        // Caja cerrada de piedra con 3x3x3 de aire dentro, aislada de la lava del Nether.
        BlockPos base = helper.absolutePos(new BlockPos(4, 0, 4));
        BlockPos center = new BlockPos(base.getX(), 100, base.getZ());
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 3; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean shell = Math.abs(dx) == 2 || Math.abs(dz) == 2 || dy == -1 || dy == 3;
                    nether.setBlockAndUpdate(center.offset(dx, dy, dz),
                            shell ? Blocks.STONE.defaultBlockState() : Blocks.AIR.defaultBlockState());
                }
            }
        }
        Vec3 target = Vec3.atBottomCenterOf(center);
        LocationData.get(player).add(new SavedLocation("nether", Level.NETHER, target));

        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        Vec3 start = player.position();
        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        check(helper, player.level() == helper.getLevel() && player.position().distanceTo(start) < 1e-6,
                "exp 0.5 cannot cross dimensions");
        check(helper, cp.getCP() == cpBefore, "no cost when refused");
        AbilityData.get(player).setSkillExp(skill.getId(), 0.8f);
        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        check(helper, player.level() == helper.getLevel(), "exp 0.8 is not enough (strictly above)");

        AbilityData.get(player).setSkillExp(skill.getId(), 0.9f);
        double distance = start.distanceTo(target);
        float expected = LocationTeleportRules.cpCost(0.9f, distance, true);
        indexMessage(player, LocationTeleportSkill.CHANNEL_TELEPORT, 0);
        check(helper, player.level().dimension().equals(Level.NETHER), "exp 0.9 crosses to the nether");
        check(helper, player.position().distanceTo(target) < 1e-3, "arrives at the saved spot in the nether");
        check(helper, Math.abs(cpBefore - cp.getCP() - expected) < 0.05f,
                "pays double: " + expected + ", paid " + (cpBefore - cp.getCP()));
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "cooldown set");
        nether.removePlayerImmediately(player, Entity.RemovalReason.DISCARDED);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void locationsSurviveDeathAndSaving(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, "test-loc-death", A);
        open(helper, player, 0f);
        add(player, "home");
        saveAt(helper, player, B, "");
        LocationData data = LocationData.get(player);
        check(helper, data.size() == 2, "two locations saved");

        // Muerte: NeoForge copia al jugador nuevo los attachments con copyOnDeath.
        ServerLevel level = helper.getLevel();
        ServerPlayer reborn = new ServerPlayer(level.getServer(), level,
                new GameProfile(UUID.randomUUID(), "test-loc-reborn"), player.clientInformation());
        reborn.copyAttachmentsFrom(player, true);
        LocationData copied = LocationData.get(reborn);
        check(helper, copied.list().equals(data.list()), "locations survive death");

        // Guardado: ida y vuelta por el Codec.
        Tag saved = LocationData.CODEC.encodeStart(NbtOps.INSTANCE, data).getOrThrow();
        LocationData loaded = LocationData.CODEC.parse(NbtOps.INSTANCE, saved).getOrThrow();
        check(helper, loaded.list().equals(data.list()), "locations survive saving and loading");
        helper.succeed();
    }
}
