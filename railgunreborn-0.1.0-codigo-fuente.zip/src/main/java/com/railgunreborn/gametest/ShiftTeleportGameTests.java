package com.railgunreborn.gametest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.teleporter.ShiftTeleportRules;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Shift Teleport (T61). Jugador falso en (4.5, 1, 1.5) mirando hacia +Z (ojos a y 2.62); muro de piedra
 * en z = 8, así que el bloque va a la celda (4, 2, 7).
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class ShiftTeleportGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    private static final BlockPos DEST = new BlockPos(4, 2, 7);

    private static ServerPlayer player(GameTestHelper helper, float pitch) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-shift"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, pitch);
        // moveTo no toca la cabeza: yHeadRot nace al azar y el trazado de la vista la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    /** Suelo y muro en z = 8. */
    private static void arena(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
        for (int x = 2; x <= 7; x++) {
            for (int y = 1; y <= 4; y++) {
                helper.setBlock(new BlockPos(x, y, 8), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static void check0(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    /** Teleporter nivel 4 con Shift Teleport aprendida, CP lleno, modo habilidad y {@code stack} en la mano. */
    private static Skill setUp(ServerPlayer player, ItemStack stack) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Teleporter.ID);
        ability.setLevel(4);
        Skill skill = Teleporter.SHIFT_TP.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), 0f);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        player.setItemInHand(InteractionHand.MAIN_HAND, stack);
        return skill;
    }

    /** Pulsa, mantiene un tick y suelta. */
    private static void shoot(ServerPlayer player, Skill skill) {
        check0(SkillContexts.start(player, 1, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEEP_ALIVE);
        SkillContexts.tick(player);
        SkillContexts.handleAction(player, 1, SkillContextActionPayload.Action.KEY_UP);
    }

    private static List<ItemEntity> drops(GameTestHelper helper) {
        AABB area = new AABB(helper.absolutePos(BlockPos.ZERO)).inflate(20);
        return helper.getLevel().getEntitiesOfClass(ItemEntity.class, area, e -> e.getItem().is(Items.DIRT));
    }

    private static void withMobGriefing(GameTestHelper helper, boolean value, Runnable action) {
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(value, helper.getLevel().getServer());
            action.run();
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
    }

    @GameTest(template = EMPTY)
    public static void registeredAtLevel4AndParentOfSpaceFluct(GameTestHelper helper) {
        Skill skill = Teleporter.SHIFT_TP.get();
        check(helper, skill.getId().equals(Teleporter.SHIFT_TP_ID), "id " + skill.getId());
        check(helper, skill.getLevel() == 4 && skill.canControl(), "level 4, controllable");
        check(helper, skill.getParent().map(p -> p.skill().equals(Teleporter.skillId("location_teleport"))
                && p.minExp() == 0.5f).orElse(false), "parent location_teleport 0.5");
        check(helper, skill.getGuiX() == 175 && skill.getGuiY() == 47, "gui position 175, 47");
        check(helper, skill.getIcon().getPath().equals("textures/skill/teleporter/shift_tp.png"),
                "icon " + skill.getIcon());
        check(helper, Teleporter.SPACE_FLUCT.get().getParent().map(p -> p.skill().equals(skill.getId())
                && p.minExp() == 0f).orElse(false), "space fluct hangs from shift_tp at 0.0");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void placesTheBlockAndSpendsOne(GameTestHelper helper) {
        arena(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));
        float cpBefore = CPData.get(player).getCP();

        shoot(player, skill);

        check(helper, helper.getBlockState(DEST).is(Blocks.DIRT), "dirt placed next to the wall");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 2, "one block spent");
        check(helper, drops(helper).isEmpty(), "nothing dropped");
        check(helper, Math.abs(cpBefore - CPData.get(player).getCP() - 260f) < 0.5f, "CP charged (260 at exp 0)");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 100, "cooldown 100");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId()) - ShiftTeleportRules.BASE_EXP)
                < 1e-6f, "exp +0.002");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void hurtsTheGolemButNotTheOwnWolf(GameTestHelper helper) {
        arena(helper);
        // Pedestal para que el lobo quede a la altura de la línea (y ≈ 2.55).
        helper.setBlock(new BlockPos(4, 1, 6), Blocks.STONE);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));
        IronGolem golem = helper.spawnWithNoFreeWill(EntityType.IRON_GOLEM, new Vec3(4.5, 1, 4.5));
        Wolf wolf = helper.spawnWithNoFreeWill(EntityType.WOLF, new Vec3(4.5, 2, 6.5));
        wolf.setTame(true, false);
        wolf.setOwnerUUID(player.getUUID());
        float golemBefore = golem.getHealth();
        float wolfBefore = wolf.getHealth();

        shoot(player, skill);

        check(helper, Math.abs(golemBefore - golem.getHealth() - 15f) < EPS,
                "15 damage to the golem, lost " + (golemBefore - golem.getHealth()));
        check(helper, wolf.getHealth() == wolfBefore, "own wolf untouched");
        check(helper, helper.getBlockState(DEST).is(Blocks.DIRT), "block placed too");
        check(helper, Math.abs(AbilityData.get(player).getSkillExp(skill.getId())
                - ShiftTeleportRules.expGain(true, 1)) < 1e-6f, "exp 0.002 + 0.002 per hurt target");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutMobGriefingTheBlockDropsAsItem(GameTestHelper helper) {
        arena(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));

        withMobGriefing(helper, false, () -> shoot(player, skill));

        check(helper, helper.getBlockState(DEST).isAir(), "nothing placed");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 2, "one unit left the hand");
        List<ItemEntity> dropped = drops(helper);
        check(helper, dropped.size() == 1 && dropped.get(0).getItem().getCount() == 1, "one dirt on the ground");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == 100, "still a use: cooldown");
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) == 0f, "no exp without placing or hits");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void inAProtectedSpotTheBlockDropsAsItem(GameTestHelper helper) {
        arena(helper);
        ServerPlayer player = player(helper, 0f);
        // Modo aventura: sin permiso de construcción, como en una zona protegida.
        player.setGameMode(GameType.ADVENTURE);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));

        shoot(player, skill);

        check(helper, helper.getBlockState(DEST).isAir(), "nothing placed");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 2, "one unit left the hand");
        check(helper, drops(helper).size() == 1, "dropped as an item");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void intoTheAirTheBlockFloats(GameTestHelper helper) {
        arena(helper);
        // La prueba está encerrada en barreras: se abre un hueco en la columna del jugador y se repone al final.
        Map<BlockPos, BlockState> removed = new HashMap<>();
        for (int y = 3; y <= 30; y++) {
            BlockPos pos = new BlockPos(4, y, 1);
            BlockState state = helper.getBlockState(pos);
            if (!state.isAir()) {
                removed.put(pos, state);
                helper.setBlock(pos, Blocks.AIR);
            }
        }
        ServerPlayer player = player(helper, -90f);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));

        shoot(player, skill);

        // Ojos a 2.62 + 25 de alcance = 27.62: celda y 27.
        BlockPos floating = new BlockPos(4, 27, 1);
        boolean placed = helper.getBlockState(floating).is(Blocks.DIRT);
        helper.setBlock(floating, Blocks.AIR);
        removed.forEach(helper::setBlock);
        check(helper, placed, "dirt floating at the end of the range");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 2, "one block spent");
        check(helper, drops(helper).isEmpty(), "nothing dropped");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void withoutABlockNothingHappens(GameTestHelper helper) {
        arena(helper);
        ServerPlayer player = player(helper, 0f);
        Skill skill = setUp(player, new ItemStack(Items.STICK, 3));
        float cpBefore = CPData.get(player).getCP();
        shoot(player, skill);
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "item kept");
        check(helper, CPData.get(player).getCP() >= cpBefore - 1e-3f, "no CP charged");
        check(helper, !CooldownData.get(player).isInCooldown(skill.getId()), "no cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void creativeDoesNotSpendTheBlock(GameTestHelper helper) {
        arena(helper);
        ServerPlayer player = player(helper, 0f);
        player.setGameMode(GameType.CREATIVE);
        Skill skill = setUp(player, new ItemStack(Items.DIRT, 3));
        shoot(player, skill);
        check(helper, helper.getBlockState(DEST).is(Blocks.DIRT), "placed");
        check(helper, player.getItemInHand(InteractionHand.MAIN_HAND).getCount() == 3, "stack untouched");
        helper.succeed();
    }
}
