package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.electromaster.RailgunRules;
import com.railgunreborn.ability.electromaster.RailgunSkill;
import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests del Railgun (T33). Jugador falso en (4.5, 1, 1.5) mirando a +Z, como en Arc Gen.
 *
 * <p>Los GameTests corren a la vez unos al lado de otros: los disparos completos se hacen mirando en vertical y con
 * {@code mobGriefing} apagado durante la llamada (síncrona), para que el rayo de 50 bloques no rompa ni mate nada de
 * otras pruebas. El túnel se prueba aparte con {@link RailgunSkill#breakTunnel} y pocos pasos, dentro de la
 * estructura.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class RailgunSkillGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;
    /** Edad de la moneda dentro de la ventana estricta (25-29 con el jugador quieto en el suelo de la prueba). */
    private static final int WINDOW_AGE = 26;
    private static final int EARLY_AGE = 5;

    // --- utilidades ---

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-railgun-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Electromaster nivel 4 con Railgun aprendida (exp 0) y modo habilidad encendido. */
    private static RailgunSkill setUpRailgun(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(4);
        RailgunSkill railgun = Electromaster.RAILGUN.get();
        ability.learnSkill(railgun.getId());
        CPData.get(player).setActivated(player, true);
        player.addTag(RailgunSkill.IRON_MODE_TAG); // los tests disparan con hierro; ver ironModeIsLockedWithoutTheBauble
        return railgun;
    }

    /** Mirando hacia arriba: el rayo solo cruza aire, lejos de las demás pruebas. */
    private static void lookUp(ServerPlayer player) {
        player.moveTo(player.getX(), player.getY(), player.getZ(), 0f, -90f);
    }

    private static void withMobGriefing(GameTestHelper helper, boolean value, Runnable action) {
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(value, helper.getLevel().getServer());
            action.run();
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
    }

    private static StartResult start(GameTestHelper helper, ServerPlayer player, int id, Skill skill) {
        StartResult[] result = new StartResult[1];
        withMobGriefing(helper, false, () -> result[0] = SkillContexts.start(player, id, skill));
        return result[0];
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static boolean fired(ServerPlayer player, Skill skill) {
        return CooldownData.get(player).isInCooldown(skill.getId());
    }

    // --- registro ---

    @GameTest(template = EMPTY)
    public static void railgunIsRegisteredInTheTree(GameTestHelper helper) {
        RailgunSkill railgun = Electromaster.RAILGUN.get();
        check(helper, railgun.getLevel() == 4, "level should be 4");
        check(helper, railgun.getParent().isPresent()
                && railgun.getParent().get().skill().equals(Electromaster.THUNDER_BOLT.getId())
                && Math.abs(railgun.getParent().get().minExp() - 0.3f) < EPS, "parent should be thunder_bolt (0.3)");
        check(helper, railgun.getExtraDependencies().size() == 1
                && railgun.getExtraDependencies().get(0).skill().equals(Electromaster.MAG_MANIP.getId())
                && Math.abs(railgun.getExtraDependencies().get(0).minExp() - 1.0f) < EPS,
                "dependency should be mag_manip (1.0)");
        check(helper, railgun.getGuiX() == 164 && railgun.getGuiY() == 59, "tree position should be 164, 59");
        helper.succeed();
    }

    // --- QTE con moneda ---

    @GameTest(template = EMPTY)
    public static void coinShotInsideTheWindowFires(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        lookUp(player);
        CoinEntity coin = CoinEntity.spawn(player, true);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getCP();
        boolean[] done = {false};
        helper.onEachTick(() -> {
            if (done[0] || coin.getAge() < WINDOW_AGE) {
                return;
            }
            done[0] = true;
            check(helper, coin.isInQteWindow(), "coin should be in the strict window at age " + coin.getAge());
            check(helper, start(helper, player, 1, railgun) == StartResult.OK, "start should be accepted");
            check(helper, coin.isRemoved(), "the coin must be consumed by the shot");
            check(helper, fired(player, railgun), "cooldown should be set after a shot");
            check(helper, Math.abs(cp.getCP() - (cpBefore - RailgunRules.cpCost(0f))) < EPS,
                    "CP should drop by 200, was " + cpBefore + " -> " + cp.getCP());
            check(helper, Math.abs(cp.getOverload() - RailgunRules.overloadCost(0f)) < EPS,
                    "overload should be 180, was " + cp.getOverload());
            float exp = AbilityData.get(player).getSkillExp(railgun.getId());
            check(helper, Math.abs(exp - RailgunRules.EXP_EMPTY) < 1e-6f, "shot at nothing gives 0.005, was " + exp);
            check(helper, player.getMainHandItem().isEmpty(), "a consumed coin is not returned");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void coinShotOutsideTheWindowSpendsTheOnlyAttempt(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        lookUp(player);
        CoinEntity coin = CoinEntity.spawn(player, true);
        float cpBefore = CPData.get(player).getCP();
        int[] phase = {0};
        helper.onEachTick(() -> {
            if (phase[0] == 0 && coin.getAge() >= EARLY_AGE) {
                phase[0] = 1;
                check(helper, !coin.isInQteWindow(CoinEntity.QTE_TOLERANCE_TICKS), "age 5 is before the window");
                check(helper, start(helper, player, 1, railgun) == StartResult.OK, "start itself is accepted");
                check(helper, coin.isAttemptSpent(), "an early press spends the attempt");
                check(helper, !coin.isRemoved(), "an early press must not consume the coin");
                check(helper, !fired(player, railgun), "an early press must not fire");
            } else if (phase[0] == 1 && coin.getAge() >= WINDOW_AGE) {
                phase[0] = 2;
                check(helper, coin.isInQteWindow(), "coin should now be in the window");
                check(helper, start(helper, player, 2, railgun) == StartResult.OK, "second start is accepted");
                check(helper, !coin.isRemoved(), "the second press must not consume the coin either");
                check(helper, !fired(player, railgun), "only one attempt per coin: no shot");
                check(helper, CPData.get(player).getCP() == cpBefore, "nothing should be spent");
                check(helper, SkillContexts.active(player).isEmpty(), "contexts should have terminated");
                helper.succeed();
            }
        });
    }

    @GameTest(template = EMPTY)
    public static void coinShotWithoutCpKeepsTheCoin(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        lookUp(player);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, cp.getCP() - 100f);
        CoinEntity coin = CoinEntity.spawn(player, true);
        boolean[] pressed = {false};
        helper.onEachTick(() -> {
            if (!pressed[0] && coin.getAge() >= WINDOW_AGE) {
                pressed[0] = true;
                check(helper, start(helper, player, 1, railgun) == StartResult.OK, "start itself is accepted");
                check(helper, !coin.isRemoved(), "without CP the coin must not be consumed");
                check(helper, !fired(player, railgun), "without CP there is no shot");
                check(helper, AbilityData.get(player).getSkillExp(railgun.getId()) == 0f, "no exp without a shot");
            } else if (pressed[0] && coin.isRemoved()) {
                check(helper, player.getMainHandItem().is(ModItems.COIN.get()),
                        "the unused coin should come back to the hand");
                helper.succeed();
            }
        });
    }

    // --- Modo hierro ---

    @GameTest(template = EMPTY)
    /** Decisión del usuario: el modo hierro queda bloqueado hasta que exista el bauble que lo desbloquee. */
    public static void ironModeIsLockedWithoutTheBauble(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        lookUp(player);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_INGOT, 3));
        player.removeTag(RailgunSkill.IRON_MODE_TAG);
        check(helper, !RailgunSkill.ironModeUnlocked(player), "iron mode must be locked for now");
        withMobGriefing(helper, false, () -> {
            SkillContexts.start(player, 1, railgun);
            for (int i = 0; i < RailgunRules.HOLD_TICKS + 5; i++) {
                SkillContexts.tick(player);
            }
        });
        check(helper, !fired(player, railgun), "must not fire with iron while the mode is locked");
        check(helper, player.getMainHandItem().getCount() == 3, "no ingot must be spent");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void ironModeReleasedEarlyOrEmptyHandSpendsNothing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        lookUp(player);
        float cpBefore = CPData.get(player).getCP();
        // Mano vacía y sin moneda: la tecla no hace nada.
        check(helper, start(helper, player, 1, railgun) == StartResult.OK, "start itself is accepted");
        check(helper, SkillContexts.active(player).isEmpty(), "nothing to shoot: context ends at once");

        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_BLOCK, 1));
        withMobGriefing(helper, false, () -> {
            SkillContexts.start(player, 2, railgun);
            for (int i = 0; i < 10; i++) {
                SkillContexts.tick(player);
            }
            SkillContexts.handleAction(player, 2,
                    com.railgunreborn.network.SkillContextActionPayload.Action.KEY_UP);
        });
        check(helper, !fired(player, railgun), "released early: no shot");
        check(helper, player.getMainHandItem().getCount() == 1, "released early: the iron block stays");
        check(helper, CPData.get(player).getCP() == cpBefore, "nothing should be spent");
        helper.succeed();
    }

    // --- Daño ---

    @GameTest(template = EMPTY)
    public static void beamKillsZombieInLineAndSparesOthers(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        Zombie inLine = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        Zombie aside = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(0.5, 1, 0.5));
        // Encima del zombi mirando abajo: el rayo baja por el suelo, no cruza ninguna otra prueba.
        Vec3 above = helper.absoluteVec(new Vec3(4.5, 4, 4.5));
        player.moveTo(above.x, above.y, above.z, 0f, 90f);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_INGOT, 1));
        float asideBefore = aside.getHealth();
        withMobGriefing(helper, false, () -> {
            SkillContexts.start(player, 1, railgun);
            for (int i = 0; i < RailgunRules.HOLD_TICKS; i++) {
                SkillContexts.tick(player);
            }
        });
        check(helper, fired(player, railgun), "the shot should have happened");
        check(helper, inLine.isDeadOrDying(), "60 damage should kill the zombie in line, health " + inLine.getHealth());
        check(helper, aside.getHealth() == asideBefore, "a zombie 5.6 blocks off the axis must not be hit");
        float exp = AbilityData.get(player).getSkillExp(railgun.getId());
        check(helper, Math.abs(exp - RailgunRules.EXP_HIT) < 1e-6f, "hitting a mob gives 0.01, was " + exp);
        check(helper, helper.getBlockState(new BlockPos(4, 0, 4)).is(Blocks.STONE),
                "with mobGriefing off the floor must stay");
        helper.succeed();
    }

    // --- Túnel ---

    /** Pared de piedra de 3x3 en z = {@code z}, delante del jugador. */
    private static void stoneWall(GameTestHelper helper, int z, Block block) {
        for (int x = 3; x <= 5; x++) {
            for (int y = 1; y <= 3; y++) {
                helper.setBlock(new BlockPos(x, y, z), block);
            }
        }
    }

    private static int tunnel(ServerPlayer player, RailgunSkill railgun, int steps) {
        return railgun.breakTunnel(player, player.getEyePosition(), player.getViewVector(1.0f),
                RailgunRules.energy(0f), steps);
    }

    @GameTest(template = EMPTY)
    public static void tunnelBreaksStoneInFront(GameTestHelper helper) {
        floor(helper);
        stoneWall(helper, 3, Blocks.STONE);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        int[] broken = {0};
        withMobGriefing(helper, true, () -> broken[0] = tunnel(player, railgun, 3));
        check(helper, broken[0] >= 9, "the whole wall should break, broke " + broken[0]);
        for (int x = 3; x <= 5; x++) {
            for (int y = 1; y <= 3; y++) {
                check(helper, helper.getBlockState(new BlockPos(x, y, 3)).isAir(),
                        "stone at " + x + "," + y + ",3 should be gone");
            }
        }
        // El paso 0 (el plano del jugador) no se toca: el suelo bajo sus pies sigue.
        check(helper, helper.getBlockState(new BlockPos(4, 0, 1)).is(Blocks.STONE), "floor under the player stays");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void tunnelDoesNothingWithoutMobGriefing(GameTestHelper helper) {
        floor(helper);
        stoneWall(helper, 3, Blocks.STONE);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        int[] broken = {-1};
        withMobGriefing(helper, false, () -> broken[0] = tunnel(player, railgun, 3));
        check(helper, broken[0] == 0, "nothing should break, broke " + broken[0]);
        check(helper, helper.getBlockState(new BlockPos(4, 2, 3)).is(Blocks.STONE), "the wall must stay");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void tunnelStopsAtBedrock(GameTestHelper helper) {
        floor(helper);
        // Pared de bedrock que tapa todo el disco (x 1-7, y 0-4) y piedra detrás.
        for (int x = 1; x <= 7; x++) {
            for (int y = 0; y <= 4; y++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.BEDROCK);
            }
        }
        stoneWall(helper, 4, Blocks.STONE);
        ServerPlayer player = player(helper);
        RailgunSkill railgun = setUpRailgun(player);
        withMobGriefing(helper, true, () -> tunnel(player, railgun, 3));
        check(helper, helper.getBlockState(new BlockPos(4, 2, 3)).is(Blocks.BEDROCK), "bedrock is unbreakable");
        for (int x = 3; x <= 5; x++) {
            for (int y = 1; y <= 3; y++) {
                check(helper, helper.getBlockState(new BlockPos(x, y, 4)).is(Blocks.STONE),
                        "stone behind bedrock at " + x + "," + y + " must stay");
            }
        }
        helper.succeed();
    }
}
