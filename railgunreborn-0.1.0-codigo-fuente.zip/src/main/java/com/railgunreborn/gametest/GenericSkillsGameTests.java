package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.generic.GenericRules;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de las habilidades genéricas (T35): aprender, máximos, regeneración y rechazos. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class GenericSkillsGameTests {
    private static final String EMPTY = "empty";
    private static final float EPS = 1e-3f;

    private static Skill brain() {
        return Electromaster.GENERICS.get(GenericRules.Kind.BRAIN_COURSE).get();
    }

    private static Skill advanced() {
        return Electromaster.GENERICS.get(GenericRules.Kind.BRAIN_COURSE_ADVANCED).get();
    }

    private static Skill mind() {
        return Electromaster.GENERICS.get(GenericRules.Kind.MIND_COURSE).get();
    }

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 2, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static AbilityData electromaster(ServerPlayer player, int level) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(level);
        CPData.get(player);
        return ability;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static boolean near(float a, float b) {
        return Math.abs(a - b) < EPS;
    }

    /** Aprende como el Developer (validando) y aplica los recálculos pendientes de CP. */
    private static void learn(GameTestHelper helper, ServerPlayer player, Skill skill, DeveloperType type) {
        AbilityData ability = AbilityData.get(player);
        DevelopResult result = skill.checkLearn(ability, type);
        check(helper, result == DevelopResult.OK, skill + " should be learnable, was " + result);
        ability.learnSkill(skill.getId());
        CPData.get(player);
    }

    /** Da una habilidad propia saltándose el árbol (solo hace falta que cuente como aprendida). */
    private static void grant(ServerPlayer player, Skill skill) {
        AbilityData.get(player).learnSkill(skill.getId());
        CPData.get(player);
    }

    @GameTest(template = EMPTY)
    public static void genericsAreRegisteredAsPassives(GameTestHelper helper) {
        Skill brain = brain();
        Skill advanced = advanced();
        Skill mind = mind();
        check(helper, !brain.canControl() && !advanced.canControl() && !mind.canControl(), "all must be passive");
        check(helper, brain.getLevel() == 3 && advanced.getLevel() == 4 && mind.getLevel() == 5, "levels 3/4/5");
        check(helper, brain.getLearningStims() == 7 && advanced.getLearningStims() == 11
                && mind.getLearningStims() == 15, "stims 7/11/15");
        check(helper, brain.getMinimumDeveloperType() == DeveloperType.NORMAL
                && advanced.getMinimumDeveloperType() == DeveloperType.ADVANCED
                && mind.getMinimumDeveloperType() == DeveloperType.ADVANCED, "developer types");
        check(helper, brain.getRequiredAnySkillLevel() == 3 && advanced.getRequiredAnySkillLevel() == 4
                && mind.getRequiredAnySkillLevel() == 5, "any-skill conditions 3/4/5");
        check(helper, brain.getParent().isEmpty()
                && advanced.getParent().get().skill().equals(brain.getId())
                && mind.getParent().get().skill().equals(advanced.getId()), "parent chain");
        check(helper, brain.getGuiX() == 30 && brain.getGuiY() == 110 && advanced.getGuiX() == 115
                && mind.getGuiX() == 205 && mind.getGuiY() == 110, "tree positions");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void brainCourseRaisesMaxCpAndRefillsCp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = electromaster(player, 3);
        grant(player, Electromaster.MINE_DETECT.get());
        CPData cp = CPData.get(player);
        float before = cp.getMaxCP();
        cp.consumeWithForce(player, 100f, 1500f);
        check(helper, cp.getCP() < before && cp.getOverload() > 0f, "CP and overload should be spent first");

        learn(helper, player, brain(), DeveloperType.NORMAL);
        check(helper, near(cp.getMaxCP(), before + 1000f),
                "max CP should be " + (before + 1000f) + ", was " + cp.getMaxCP());
        check(helper, near(cp.getCP(), cp.getMaxCP()), "CP should be refilled");
        check(helper, cp.getOverload() == 0f, "overload should be emptied");
        check(helper, ability.isLearned(brain().getId()), "should be learned");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void brainCourseAdvancedAddsCpAndOverload(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        electromaster(player, 4);
        grant(player, Electromaster.MINE_DETECT.get());
        grant(player, Electromaster.THUNDER_BOLT.get());
        learn(helper, player, brain(), DeveloperType.ADVANCED);
        CPData cp = CPData.get(player);
        float cpBefore = cp.getMaxCP();
        float overloadBefore = cp.getMaxOverload();

        learn(helper, player, advanced(), DeveloperType.ADVANCED);
        check(helper, near(cp.getMaxCP(), cpBefore + 1500f), "max CP should rise by 1500, was " + cp.getMaxCP());
        check(helper, near(cp.getMaxOverload(), overloadBefore + 100f),
                "max overload should rise by 100, was " + cp.getMaxOverload());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mindCourseRecoversCpTwentyPercentFaster(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        electromaster(player, 5);
        grant(player, Electromaster.MINE_DETECT.get());
        learn(helper, player, brain(), DeveloperType.ADVANCED);
        CPData cp = CPData.get(player);

        float without = recoveryRatio(player, cp);
        check(helper, near(without, 1f), "without mind_course the ratio should be 1, was " + without);

        grant(player, Electromaster.THUNDER_BOLT.get());
        learn(helper, player, advanced(), DeveloperType.ADVANCED);
        grant(player, Electromaster.THUNDER_CLAP.get());
        learn(helper, player, mind(), DeveloperType.ADVANCED);
        float with = recoveryRatio(player, cp);
        check(helper, near(with, 1.2f), "with mind_course the ratio should be 1.2, was " + with);
        helper.succeed();
    }

    /** Gasta CP, espera la pausa de 15 ticks y mide la ganancia del siguiente tick frente a la fórmula sin modificador. */
    private static float recoveryRatio(ServerPlayer player, CPData cp) {
        cp.consumeWithForce(player, 0f, cp.getMaxCP() * 0.5f);
        for (int i = 0; i < 15; i++) {
            cp.tick(player);
        }
        float cur = cp.getCP();
        float baseMax = cp.getMaxCP() - cp.getAddMaxCP();
        float expectedBase = 0.0003f * baseMax * Mth.lerp(cur / baseMax, 1f, 2f);
        cp.tick(player);
        return (cp.getCP() - cur) / expectedBase;
    }

    @GameTest(template = EMPTY)
    public static void brainCourseNeedsASkillOfLevelThree(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = electromaster(player, 3);
        Skill brain = brain();
        DevelopResult result = brain.checkLearn(ability, DeveloperType.NORMAL);
        check(helper, result == DevelopResult.ANY_SKILL_NOT_MET, "should be ANY_SKILL_NOT_MET, was " + result);
        result = brain.checkLearn(ability, DeveloperType.PORTABLE);
        check(helper, result == DevelopResult.DEVELOPER_TOO_WEAK, "portable should be too weak, was " + result);
        AbilityData low = electromaster(player, 2);
        check(helper, brain.checkLearn(low, DeveloperType.NORMAL) == DevelopResult.LEVEL_TOO_LOW,
                "player level 2 should be too low");

        electromaster(player, 3).learnSkill(Electromaster.BODY_INTENSIFY.getId());
        check(helper, brain.checkLearn(AbilityData.get(player), DeveloperType.NORMAL) == DevelopResult.OK,
                "a level 3 skill unlocks it");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void advancedAndMindNeedTheirParentAndConditions(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = electromaster(player, 5);
        ability.learnSkill(Electromaster.THUNDER_BOLT.getId());
        check(helper, advanced().checkLearn(ability, DeveloperType.ADVANCED) == DevelopResult.PARENT_NOT_MET,
                "advanced needs brain_course");
        check(helper, advanced().checkLearn(ability, DeveloperType.NORMAL) == DevelopResult.DEVELOPER_TOO_WEAK,
                "advanced needs an advanced developer");
        ability.learnSkill(brain().getId());
        ability.learnSkill(advanced().getId());
        check(helper, mind().checkLearn(ability, DeveloperType.ADVANCED) == DevelopResult.ANY_SKILL_NOT_MET,
                "mind needs thunder_clap");
        ability.learnSkill(Electromaster.THUNDER_CLAP.getId());
        check(helper, mind().checkLearn(ability, DeveloperType.ADVANCED) == DevelopResult.OK, "mind unlocked");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void learningANormalSkillDoesNotRefillCp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        electromaster(player, 3);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 50f, 1000f);
        float cpBefore = cp.getCP();
        float overloadBefore = cp.getOverload();

        grant(player, Electromaster.MINE_DETECT.get());
        check(helper, near(cp.getCP(), cpBefore), "CP must not change, was " + cp.getCP() + " expected " + cpBefore);
        check(helper, near(cp.getOverload(), overloadBefore), "overload must not change");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void genericsCannotGoInPresets(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = electromaster(player, 3);
        ability.learnSkill(Electromaster.BODY_INTENSIFY.getId());
        ability.learnSkill(brain().getId());
        PresetRules.Result result = PresetRules.validateEdit(player, PresetData.get(player), 0, 0, brain().getId());
        check(helper, result == PresetRules.Result.NOT_CONTROLLABLE, "should be NOT_CONTROLLABLE, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void changingCategoryRemovesTheBonus(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = electromaster(player, 3);
        grant(player, Electromaster.MINE_DETECT.get());
        learn(helper, player, brain(), DeveloperType.NORMAL);
        CPData cp = CPData.get(player);
        check(helper, near(cp.getMaxCP(), 5000f), "max CP should be 5000, was " + cp.getMaxCP());
        ability.setCategory(Electromaster.ID);
        ability.setLevel(3);
        CPData.get(player);
        check(helper, near(cp.getMaxCP(), 4000f), "bonus should be gone, was " + cp.getMaxCP());
        helper.succeed();
    }
}
