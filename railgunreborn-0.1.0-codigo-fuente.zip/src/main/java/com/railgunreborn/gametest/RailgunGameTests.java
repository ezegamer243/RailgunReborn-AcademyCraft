package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DevelopRules;
import com.railgunreborn.ability.develop.DevelopSession;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.ability.electromaster.ArcGenSkill;
import com.railgunreborn.ability.electromaster.Electromaster;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.block.DeveloperBlock;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de T15: datos de habilidad, validacion de inicio de contextos y Arc Gen con un jugador falso.
 * La estructura "empty" (data/railgunreborn/structure/empty.nbt) es un cubo de aire de 9x5x9.
 * Ejecutar con {@code .\gradlew.bat runGameTestServer}.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class RailgunGameTests {
    private static final String EMPTY = "empty";

    // --- utilidades ---

    /**
     * Jugador falso. No se usa {@code helper.makeMockServerPlayerInLevel()}: su conexion no negocia los canales de red
     * del mod, y el sync de {@code DataSync} al entrar revienta con "Payload ... may not be sent to the client".
     * Aqui el listener descarta todo lo que se le envia, asi que los payloads del mod no hacen nada.
     */
    static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-mock-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        // Mirando hacia +Z (sur), en el centro de la estructura, sobre el suelo.
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    /** Categoria Electromaster, nivel dado, Arc Gen aprendida y modo habilidad encendido. */
    private static Skill setUpArcGen(ServerPlayer player, int level) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);
        ability.setLevel(level);
        Skill arcGen = Electromaster.ARC_GEN.get();
        ability.learnSkill(arcGen.getId());
        CPData.get(player).setActivated(player, true);
        return arcGen;
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    // --- AbilityData / CPData ---

    @GameTest(template = EMPTY)
    public static void cpMaxFollowsLevel(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(Electromaster.ID);

        ability.setLevel(2);
        check(helper, CPData.get(player).getMaxCP() == 2800f, "level 2 max CP should be 2800, was " + CPData.get(player).getMaxCP());
        ability.setLevel(3);
        CPData cp = CPData.get(player);
        check(helper, cp.getMaxCP() == 4000f, "level 3 max CP should be 4000, was " + cp.getMaxCP());
        check(helper, cp.getMaxOverload() == 240f, "level 3 max overload should be 240, was " + cp.getMaxOverload());
        check(helper, cp.getCP() == cp.getMaxCP(), "CP should be full after a level change");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void consumeFailsWithoutCpAndChangesNothing(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        CPData cp = CPData.get(player);
        cp.consumeWithForce(player, 0f, 1_000_000f); // vacia el CP
        check(helper, cp.getCP() == 0f, "CP should be 0 after forced drain");
        float overloadBefore = cp.getOverload();
        float maxBefore = cp.getMaxCP();

        boolean ok = cp.consume(player, 10f, 30f);
        check(helper, !ok, "consume with no CP must fail");
        check(helper, cp.getCP() == 0f, "CP must not change on a failed consume");
        check(helper, cp.getOverload() == overloadBefore, "overload must not change on a failed consume");
        check(helper, cp.getMaxCP() == maxBefore, "max CP bonus must not change on a failed consume");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void consumeSucceedsAndSpendsCp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        CPData cp = CPData.get(player);
        boolean ok = cp.consume(player, 10f, 30f);
        check(helper, ok, "consume with full CP must succeed");
        check(helper, cp.getCP() == 3970f, "CP should be 3970, was " + cp.getCP());
        check(helper, cp.getOverload() == 10f, "overload should be 10, was " + cp.getOverload());
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void fullOverloadBlocksAbilities(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        CPData cp = CPData.get(player);
        check(helper, cp.canUseAbility(), "should be able to use abilities before overload");

        cp.consumeWithForce(player, 1_000_000f, 0f);
        check(helper, cp.isOverloaded(), "overload should be full");
        check(helper, !cp.canUseAbility(), "full overload must block abilities");
        check(helper, !cp.consume(player, 1f, 1f), "consume must fail while overloaded");
        helper.succeed();
    }

    // --- SkillContexts.validateStart ---

    @GameTest(template = EMPTY)
    public static void validateRejectsWithoutCategory(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = Electromaster.ARC_GEN.get();
        StartResult result = SkillContexts.validateStart(player, arcGen);
        check(helper, result == StartResult.WRONG_CATEGORY, "expected WRONG_CATEGORY, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void validateRejectsNotLearned(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData.get(player).setCategory(Electromaster.ID);
        CPData.get(player).setActivated(player, true);
        StartResult result = SkillContexts.validateStart(player, Electromaster.ARC_GEN.get());
        check(helper, result == StartResult.NOT_LEARNED, "expected NOT_LEARNED, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void validateRejectsModeOff(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 1);
        CPData.get(player).setActivated(player, false);
        StartResult result = SkillContexts.validateStart(player, arcGen);
        check(helper, result == StartResult.MODE_OFF, "expected MODE_OFF, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void validateRejectsOverload(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 1);
        CPData.get(player).consumeWithForce(player, 1_000_000f, 0f);
        StartResult result = SkillContexts.validateStart(player, arcGen);
        check(helper, result == StartResult.OVERLOADED, "expected OVERLOADED, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void validateRejectsCooldown(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 1);
        CooldownData.get(player).set(arcGen.getId(), 10);
        StartResult result = SkillContexts.validateStart(player, arcGen);
        check(helper, result == StartResult.COOLDOWN, "expected COOLDOWN, was " + result);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void validateAcceptsCorrectCase(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 1);
        StartResult result = SkillContexts.validateStart(player, arcGen);
        check(helper, result == StartResult.OK, "expected OK, was " + result);
        helper.succeed();
    }

    // --- Arc Gen ---

    /** Un zombi a 3 bloques delante recibe dano al ejecutar la habilidad entera (start -> consumo -> dano -> exp -> cooldown). */
    @GameTest(template = EMPTY)
    public static void arcGenHurtsZombieAndSpendsResources(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 3);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        float before = zombie.getHealth();
        float cpBefore = CPData.get(player).getCP();

        StartResult result = SkillContexts.start(player, 1, arcGen);
        check(helper, result == StartResult.OK, "start should be accepted, was " + result);
        check(helper, zombie.getHealth() <= before - 4.5f,
                "zombie should lose ~5 health, had " + before + " now " + zombie.getHealth());
        check(helper, CPData.get(player).getCP() == cpBefore - 30f, "CP should drop by 30");
        check(helper, CooldownData.get(player).isInCooldown(arcGen.getId()), "cooldown should be set");
        check(helper, AbilityData.get(player).getSkillExp(arcGen.getId()) > 0f, "hitting an entity should give exp");
        check(helper, SkillContexts.active(player).isEmpty(), "context should have terminated itself");
        helper.succeed();
    }

    /** Estructura alta (12): el techo de barreras de los GameTests queda fuera del alcance minimo (6) del rayo. */
    @GameTest(template = "tall")
    public static void arcGenAtTheAirGivesNoExp(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 3);
        // Mirar hacia arriba: no hay nada en todo el alcance.
        player.moveTo(player.getX(), player.getY(), player.getZ(), 0f, -90f);

        HitResult probe = ArcGenSkill.trace(player, 6f);
        StartResult result = SkillContexts.start(player, 1, arcGen);
        check(helper, result == StartResult.OK, "start should be accepted, was " + result);
        check(helper, AbilityData.get(player).getSkillExp(arcGen.getId()) == 0f,
                "air shot must not give exp (trace gave " + probe + ", exp " + AbilityData.get(player).getSkillExp(arcGen.getId()) + ", xRot " + player.getXRot() + ")");
        check(helper, CooldownData.get(player).isInCooldown(arcGen.getId()), "air shot still sets cooldown");
        check(helper, CPData.get(player).getCP() < CPData.get(player).getMaxCP(), "air shot still spends CP");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void arcGenRejectedDuringCooldown(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 3);
        check(helper, SkillContexts.start(player, 1, arcGen) == StartResult.OK, "first shot should work");
        float cp = CPData.get(player).getCP();
        StartResult second = SkillContexts.start(player, 2, arcGen);
        check(helper, second == StartResult.COOLDOWN, "second shot should hit COOLDOWN, was " + second);
        check(helper, CPData.get(player).getCP() == cp, "rejected shot must not spend CP");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void traceHitsZombieInFront(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 4.5));
        HitResult hit = ArcGenSkill.trace(player, 10f);
        check(helper, hit instanceof EntityHitResult e && e.getEntity() == zombie, "trace should hit the zombie, got " + hit);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void waterStopsTheTrace(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        // Pared de agua a 2 bloques, zombi detras.
        for (int y = 1; y <= 4; y++) {
            for (int x = 3; x <= 6; x++) {
                helper.setBlock(new BlockPos(x, y, 3), Blocks.WATER);
            }
        }
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 6.5));
        float before = zombie.getHealth();

        HitResult hit = ArcGenSkill.trace(player, 15f);
        check(helper, hit instanceof BlockHitResult && hit.getType() == HitResult.Type.BLOCK,
                "trace should stop at the water, got " + hit);
        if (hit instanceof BlockHitResult b) {
            check(helper, helper.getLevel().getFluidState(b.getBlockPos()).isSource() || !helper.getLevel().getFluidState(b.getBlockPos()).isEmpty(),
                    "hit position should be a fluid block");
        }

        // Y la habilidad entera no toca al zombi de detras.
        Skill arcGen = Electromaster.ARC_GEN.get();
        SkillContexts.start(player, 1, arcGen);
        check(helper, zombie.getHealth() == before, "zombie behind water must not be hurt");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mayIgniteFalseWithoutMobGriefing(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 3);
        ArcGenSkill skill = (ArcGenSkill) arcGen;
        BlockPos pos = helper.absolutePos(new BlockPos(4, 1, 4));
        GameRules.BooleanValue rule = helper.getLevel().getGameRules().getRule(GameRules.RULE_MOBGRIEFING);
        boolean original = rule.get();
        try {
            rule.set(false, helper.getLevel().getServer());
            check(helper, !skill.mayIgnite(player, pos), "mayIgnite must be false with mobGriefing=false");
        } finally {
            rule.set(original, helper.getLevel().getServer());
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mayIgniteFalseWhenSkillCannotDestroyBlocks(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        setUpArcGen(player, 3);
        ArcGenSkill noDestroy = new ArcGenSkill(new Skill.Properties(Electromaster.ID, 1).destroyBlocks(false));
        BlockPos pos = helper.absolutePos(new BlockPos(4, 1, 4));
        check(helper, !noDestroy.mayIgnite(player, pos), "mayIgnite must be false when destroy_blocks is off");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void mayIgniteFalseInAdventureMode(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        ArcGenSkill skill = (ArcGenSkill) setUpArcGen(player, 3);
        player.setGameMode(net.minecraft.world.level.GameType.ADVENTURE);
        BlockPos pos = helper.absolutePos(new BlockPos(4, 1, 4));
        check(helper, !skill.mayIgnite(player, pos), "adventure mode players cannot place fire");
        helper.succeed();
    }

    // --- PresetRules (edicion de ranuras: comando y payload) ---

    @GameTest(template = EMPTY)
    public static void presetEditRejectsWithoutCategory(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        var result = PresetRules.applyEdit(player, 0, 0, Electromaster.ARC_GEN.get().getId());
        check(helper, result == PresetRules.Result.NO_CATEGORY, "expected NO_CATEGORY, was " + result);
        check(helper, PresetData.get(player).getSlot(0, 0) == null, "slot must stay empty");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void presetEditRejectsBadIndexWithoutThrowing(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill arcGen = setUpArcGen(player, 1);
        int[][] bad = {{-1, 0}, {0, -1}, {PresetData.MAX_PRESETS, 0}, {0, PresetData.MAX_SLOTS}, {99, 99}};
        for (int[] index : bad) {
            var result = PresetRules.applyEdit(player, index[0], index[1], arcGen.getId());
            check(helper, result == PresetRules.Result.BAD_INDEX, "expected BAD_INDEX for " + index[0] + "," + index[1]);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void presetEditRejectsUnknownAndNotLearned(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData.get(player).setCategory(Electromaster.ID);
        var unknown = PresetRules.applyEdit(player, 0, 0,
                ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "electromaster/nope"));
        check(helper, unknown == PresetRules.Result.UNKNOWN_SKILL, "expected UNKNOWN_SKILL, was " + unknown);
        var notLearned = PresetRules.applyEdit(player, 0, 0, Electromaster.ARC_GEN.get().getId());
        check(helper, notLearned == PresetRules.Result.NOT_LEARNED, "expected NOT_LEARNED, was " + notLearned);
        check(helper, PresetData.get(player).getSlot(0, 0) == null, "slot must stay empty");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void presetEditAssignsClearsAndRejectsDuplicates(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        ResourceLocation id = setUpArcGen(player, 1).getId();
        PresetData presets = PresetData.get(player);

        check(helper, PresetRules.applyEdit(player, 1, 0, id) == PresetRules.Result.OK, "assign must work");
        check(helper, id.equals(presets.getSlot(1, 0)), "slot 0 of preset 1 must hold the skill");
        check(helper, PresetRules.applyEdit(player, 1, 0, id) == PresetRules.Result.OK,
                "re-assigning the same slot is not a duplicate");
        check(helper, PresetRules.applyEdit(player, 1, 2, id) == PresetRules.Result.DUPLICATE,
                "same skill in another slot of the same preset must be rejected");
        check(helper, presets.getSlot(1, 2) == null, "rejected edit must not change anything");
        check(helper, PresetRules.applyEdit(player, 2, 2, id) == PresetRules.Result.OK,
                "the same skill in another preset is fine");
        check(helper, PresetRules.applyEdit(player, 1, 0, null) == PresetRules.Result.OK, "clearing must work");
        check(helper, presets.getSlot(1, 0) == null, "slot must be empty after clearing");
        helper.succeed();
    }

    // --- Developer (T20) ---

    /**
     * Developer portátil real en la mano principal (el menú exige que el ítem
     * con el que se abrió siga en la mano). El jugador falso no recibe PlayerTickEvent (no tiene conexión real que lo
     * haga avanzar), así que los tests llaman a {@code serverTick} a mano.
     */
    private static DeveloperMenu openPortable(GameTestHelper helper, ServerPlayer player) {
        player.setItemInHand(InteractionHand.MAIN_HAND, DeveloperEnergyTesting.chargedPortable());
        DeveloperMenu menu = DeveloperMenu.open(player, DeveloperType.PORTABLE, null);
        check(helper, menu != null && player.containerMenu == menu, "portable developer should open");
        return menu;
    }

    private static void tickMenu(DeveloperMenu menu, ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            menu.serverTick(player);
        }
    }

    @GameTest(template = EMPTY)
    public static void developerLearnWithoutCategoryFails(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        DeveloperMenu menu = openPortable(helper, player);
        DevelopResult result = menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get()));
        check(helper, result == DevelopResult.NO_CATEGORY, "expected NO_CATEGORY, was " + result);
        check(helper, menu.getState() == DevelopSession.State.FAILED, "state should be FAILED");
        check(helper, menu.getResult() == DevelopResult.NO_CATEGORY, "ContainerData should carry the reason");
        tickMenu(menu, player, 200);
        check(helper, AbilityData.get(player).getLearnedSkills().isEmpty(), "nothing must be learned");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerObtainCategoryGivesARandomCategoryLevel1(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        DeveloperMenu menu = openPortable(helper, player);
        DevelopResult result = menu.start(player, DevelopAction.level());
        check(helper, result == DevelopResult.OK, "start should be accepted, was " + result);
        check(helper, menu.getMaxStim() == 5, "obtaining a category costs 5 stims, was " + menu.getMaxStim());
        int total = DevelopRules.totalTicks(5, DeveloperType.PORTABLE);
        tickMenu(menu, player, total - 1);
        check(helper, !AbilityData.get(player).hasCategory(), "category must not be set before the last tick");
        tickMenu(menu, player, 1);
        AbilityData data = AbilityData.get(player);
        // Al azar entre las categorías registradas (Electromaster, Meltdowner, Teleporter...).
        check(helper, data.getCategory().flatMap(AbilityRegistries::category).isPresent(),
                "category should be one of the registered ones, was " + data.getCategory());
        check(helper, data.getLevel() == 1, "level should be 1, was " + data.getLevel());
        check(helper, menu.getState() == DevelopSession.State.DONE, "state should be DONE");
        check(helper, CPData.get(player).getMaxCP() > 0f, "max CP should be recalculated");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerLearnsArcGenAfterTicks(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData.get(player).setCategory(Electromaster.ID);
        DeveloperMenu menu = openPortable(helper, player);
        Skill arcGen = Electromaster.ARC_GEN.get();
        check(helper, arcGen.getGuiX() == 24 && arcGen.getGuiY() == 46, "arc_gen tree position should be 24,46");
        DevelopResult result = menu.start(player, DevelopAction.learn(arcGen));
        check(helper, result == DevelopResult.OK, "start should be accepted, was " + result);
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.BUSY, "second start must be BUSY");

        int total = DevelopRules.totalTicks(3, DeveloperType.PORTABLE); // 78
        tickMenu(menu, player, total - 1);
        check(helper, !AbilityData.get(player).isLearned(arcGen.getId()), "not learned before the last tick");
        check(helper, menu.getProgress() > 0.9f && menu.getProgress() < 1f, "progress ~0.99, was " + menu.getProgress());
        tickMenu(menu, player, 1);
        check(helper, AbilityData.get(player).isLearned(arcGen.getId()), "arc gen should be learned");
        check(helper, menu.getState() == DevelopSession.State.DONE && menu.getResult() == DevelopResult.OK,
                "state should be DONE/OK");
        DevelopResult again = menu.start(player, DevelopAction.learn(arcGen));
        check(helper, again == DevelopResult.ALREADY_LEARNED, "learning twice must fail, was " + again);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerLevelUpNeedsFullProgress(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        DeveloperMenu menu = openPortable(helper, player);
        // Progreso bruto completo del nivel 1 (depende de cuántas habilidades de nivel 1 haya registradas).
        float full = Electromaster.CATEGORY.get().levelUpThreshold(1);

        DevelopResult early = menu.start(player, DevelopAction.level());
        check(helper, early == DevelopResult.LEVEL_PROGRESS_INCOMPLETE, "expected LEVEL_PROGRESS_INCOMPLETE, was " + early);

        // Revalida al terminar: el progreso desaparece a mitad y falla sin subir.
        data.setLevelProgress(full);
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "full progress should start");
        int total = DevelopRules.totalTicks(10, DeveloperType.PORTABLE);
        tickMenu(menu, player, total / 2);
        data.setLevelProgress(0f);
        tickMenu(menu, player, total);
        check(helper, data.getLevel() == 1, "level must stay 1 when the final check fails");
        check(helper, menu.getResult() == DevelopResult.LEVEL_PROGRESS_INCOMPLETE, "final check reason expected");

        data.setLevelProgress(full);
        // El intento fallido ya gastó ~la mitad de la batería del portátil: recargar para el segundo.
        com.railgunreborn.item.DeveloperPortableItem.withEnergy(player.getMainHandItem(),
                com.railgunreborn.item.DeveloperPortableItem.CAPACITY);
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "full progress should start");
        tickMenu(menu, player, total);
        check(helper, data.getLevel() == 2, "level should be 2, was " + data.getLevel());
        check(helper, data.getLevelProgress() == 0f, "progress resets after leveling up");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerTypeTooWeakRejects(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        AbilityData data = AbilityData.get(player);
        data.setCategory(Electromaster.ID);
        data.setLevel(5);
        // Habilidades de prueba sin registrar: solo se validan (aplicarlas necesitaría un id).
        Skill level3 = new ArcGenSkill(new Skill.Properties(Electromaster.ID, 3));
        Skill level4 = new ArcGenSkill(new Skill.Properties(Electromaster.ID, 4));

        DeveloperMenu portable = openPortable(helper, player);
        DevelopResult weak = portable.start(player, DevelopAction.learn(level3));
        check(helper, weak == DevelopResult.DEVELOPER_TOO_WEAK, "portable must reject level 3, was " + weak);
        player.closeContainer();

        // Developer "normal": multibloque real.
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_NORMAL.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperEnergyTesting.fill(helper.getLevel(), block);
        DeveloperMenu normal = DeveloperMenu.open(player, DeveloperType.NORMAL, block);
        check(helper, normal != null, "normal developer should open next to the block");
        check(helper, normal.start(player, DevelopAction.learn(level4)) == DevelopResult.DEVELOPER_TOO_WEAK,
                "normal must reject level 4");
        check(helper, normal.start(player, DevelopAction.learn(level3)) == DevelopResult.OK,
                "normal must accept level 3");
        check(helper, level4.checkLearn(data, DeveloperType.ADVANCED) == DevelopResult.OK, "advanced accepts level 4");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerCancelAppliesNothing(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        AbilityData.get(player).setCategory(Electromaster.ID);
        DeveloperMenu menu = openPortable(helper, player);
        Skill arcGen = Electromaster.ARC_GEN.get();
        check(helper, menu.start(player, DevelopAction.learn(arcGen)) == DevelopResult.OK, "start should work");
        tickMenu(menu, player, 50);

        player.closeContainer();
        check(helper, player.containerMenu == player.inventoryMenu, "menu should be closed");
        check(helper, menu.getState() == DevelopSession.State.IDLE, "closing must cancel the session");
        tickMenu(menu, player, 200);
        check(helper, !AbilityData.get(player).isLearned(arcGen.getId()), "cancelled development must apply nothing");

        // Abortar con el botón (menú abierto) tampoco aplica nada.
        DeveloperMenu again = openPortable(helper, player);
        check(helper, again.start(player, DevelopAction.learn(arcGen)) == DevelopResult.OK, "start should work");
        tickMenu(again, player, 50);
        again.abort();
        tickMenu(again, player, 200);
        check(helper, again.getResult() == DevelopResult.ABORTED, "abort reason expected");
        check(helper, !AbilityData.get(player).isLearned(arcGen.getId()), "aborted development must apply nothing");
        helper.succeed();
    }

    /** T22b: la pantalla distingue un intento nuevo aunque el estado y el motivo se repitan. */
    @GameTest(template = EMPTY)
    public static void developerAttemptCounterAdvances(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        DeveloperMenu menu = openPortable(helper, player);
        Skill arcGen = Electromaster.ARC_GEN.get();
        check(helper, menu.getAttempt() == 0, "fresh menu starts at attempt 0");
        menu.start(player, DevelopAction.learn(arcGen));
        int first = menu.getAttempt();
        menu.start(player, DevelopAction.learn(arcGen));
        check(helper, menu.getResult() == DevelopResult.NO_CATEGORY && menu.getAttempt() == first + 1,
                "same rejection twice must still advance the attempt");
        menu.reject(DevelopResult.UNKNOWN_SKILL);
        check(helper, menu.getAttempt() == first + 2, "reject must advance the attempt");

        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "obtain category should start");
        int developing = menu.getAttempt();
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.BUSY, "second start must be BUSY");
        menu.reject(DevelopResult.UNKNOWN_SKILL);
        check(helper, menu.getAttempt() == developing && menu.getState() == DevelopSession.State.DEVELOPING,
                "BUSY and reject during a development must not touch it");
        player.closeContainer();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerInvalidWhenFarOrItemGone(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        AbilityData.get(player).setCategory(Electromaster.ID);
        BlockPos block = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_ADVANCED.get().place(helper.getLevel(), block, Direction.SOUTH);
        DeveloperEnergyTesting.fill(helper.getLevel(), block);
        DeveloperMenu menu = DeveloperMenu.open(player, DeveloperType.ADVANCED, block);
        check(helper, menu != null && menu.stillValid(player), "should be valid next to the block");
        check(helper, menu.start(player, DevelopAction.learn(Electromaster.ARC_GEN.get())) == DevelopResult.OK,
                "start should work");
        player.moveTo(player.getX() + 20, player.getY(), player.getZ());
        check(helper, !menu.stillValid(player), "20 blocks away must be invalid");
        tickMenu(menu, player, DevelopRules.totalTicks(3, DeveloperType.ADVANCED));
        check(helper, menu.getResult() == DevelopResult.INVALID_DEVELOPER, "far away must fail at the end");
        check(helper, !AbilityData.get(player).isLearned(Electromaster.ARC_GEN.get().getId()), "nothing learned");
        player.closeContainer();

        DeveloperMenu portable = openPortable(helper, player);
        player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        check(helper, !portable.stillValid(player), "portable without the item in hand must be invalid");
        player.closeContainer();
        helper.succeed();
    }

    // --- Bloques e ítem del Developer (T21) ---

    private static int countDevelopers(GameTestHelper helper, BlockPos origin, Direction facing) {
        int count = 0;
        for (int part = 0; part < DeveloperBlock.PART_COUNT; part++) {
            BlockPos pos = DeveloperBlock.partPos(origin, facing, part);
            if (helper.getLevel().getBlockState(pos).getBlock() instanceof DeveloperBlock) {
                count++;
            }
        }
        return count;
    }

    private static InteractionResult placeWithItem(ServerPlayer player, ItemStack stack, BlockPos below) {
        player.setItemInHand(InteractionHand.MAIN_HAND, stack);
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(below).add(0, 0.5, 0), Direction.UP, below, false);
        return stack.useOn(new UseOnContext(player, InteractionHand.MAIN_HAND, hit));
    }

    @GameTest(template = EMPTY)
    public static void developerMultiblockPlaceAndBreak(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper); // mira hacia +Z (sur)
        BlockPos below = helper.absolutePos(new BlockPos(4, 0, 3));
        BlockPos origin = below.above();

        InteractionResult result = placeWithItem(player, new ItemStack(ModItems.DEVELOPER_NORMAL.get()), below);
        check(helper, result.consumesAction(), "placing the normal developer should work, was " + result);
        check(helper, countDevelopers(helper, origin, Direction.SOUTH) == 8, "8 parts should be placed");
        BlockState controller = helper.getLevel().getBlockState(origin);
        check(helper, controller.getValue(DeveloperBlock.PART) == 0
                && controller.getValue(DeveloperBlock.FACING) == Direction.SOUTH, "controller faces the player direction");
        // La esquina de arriba del lado del controlador queda libre.
        check(helper, helper.getLevel().getBlockState(origin.above(2)).isAir(), "top corner next to the controller is empty");
        check(helper, helper.getLevel().getBlockState(origin.above(2).south()).getBlock() instanceof DeveloperBlock,
                "part (2,1) exists");

        // Romper una parte cualquiera (con pico de hierro) quita todas y suelta exactamente 1 ítem.
        BlockPos hitPart = DeveloperBlock.partPos(origin, Direction.SOUTH, 6);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.IRON_PICKAXE));
        check(helper, player.gameMode.destroyBlock(hitPart), "destroyBlock should succeed");
        check(helper, countDevelopers(helper, origin, Direction.SOUTH) == 0, "breaking one part removes all");
        AABB area = new AABB(origin).inflate(6);
        int drops = helper.getLevel().getEntitiesOfClass(ItemEntity.class, area,
                e -> e.getItem().is(ModItems.DEVELOPER_NORMAL.get())).stream().mapToInt(e -> e.getItem().getCount()).sum();
        check(helper, drops == 1, "exactly one item should drop, was " + drops);
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerMultiblockRotatesAndNeedsSpace(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        BlockPos below = helper.absolutePos(new BlockPos(4, 0, 4));
        BlockPos origin = below.above();
        player.moveTo(player.getX(), player.getY(), player.getZ(), -90f, 0f); // yaw -90 = mira al este (+X)
        player.setYHeadRot(-90f);

        // Un bloque sólido en el camino de la huella: no se coloca nada ni se gasta el ítem.
        helper.getLevel().setBlockAndUpdate(origin.east(2), Blocks.STONE.defaultBlockState());
        ItemStack stack = new ItemStack(ModItems.DEVELOPER_ADVANCED.get());
        InteractionResult blocked = placeWithItem(player, stack, below);
        check(helper, !blocked.consumesAction(), "must not place with a solid block in the footprint");
        check(helper, stack.getCount() == 1, "item must not be consumed");
        check(helper, countDevelopers(helper, origin, Direction.EAST) == 0, "nothing placed");

        helper.getLevel().setBlockAndUpdate(origin.east(2), Blocks.AIR.defaultBlockState());
        InteractionResult ok = placeWithItem(player, stack, below);
        check(helper, ok.consumesAction(), "should place now");
        check(helper, countDevelopers(helper, origin, Direction.EAST) == 8, "8 parts toward east");
        check(helper, helper.getLevel().getBlockState(origin).getValue(DeveloperBlock.FACING) == Direction.EAST,
                "facing follows the player");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerBlockAndItemOpenMenu(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper);
        BlockPos origin = helper.absolutePos(new BlockPos(4, 1, 3));
        ModBlocks.DEVELOPER_ADVANCED.get().place(helper.getLevel(), origin, Direction.SOUTH);

        // Clic derecho en una parte lejana del controlador: abre el menú con la posición del controlador y el tipo.
        BlockPos part = DeveloperBlock.partPos(origin, Direction.SOUTH, 4);
        BlockState state = helper.getLevel().getBlockState(part);
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(part), Direction.NORTH, part, false);
        InteractionResult used = state.useWithoutItem(helper.getLevel(), player, hit);
        check(helper, used.consumesAction(), "use should be consumed");
        check(helper, player.containerMenu instanceof DeveloperMenu, "menu should be open");
        DeveloperMenu menu = (DeveloperMenu) player.containerMenu;
        check(helper, menu.getDeveloperType() == DeveloperType.ADVANCED, "advanced block -> advanced type");
        check(helper, origin.equals(menu.getBlockPos()), "menu points to the controller");
        player.closeContainer();

        // Agachado no abre.
        player.setShiftKeyDown(true);
        check(helper, state.useWithoutItem(helper.getLevel(), player, hit) == InteractionResult.PASS, "sneaking passes");
        check(helper, player.containerMenu == player.inventoryMenu, "no menu when sneaking");
        player.setShiftKeyDown(false);

        // Ítem portátil: mano principal abre, mano secundaria no.
        ItemStack portable = new ItemStack(ModItems.DEVELOPER_PORTABLE.get());
        check(helper, portable.getMaxStackSize() == 1, "portable stacks to 1");
        player.setItemInHand(InteractionHand.MAIN_HAND, portable);
        portable.use(helper.getLevel(), player, InteractionHand.MAIN_HAND);
        check(helper, player.containerMenu instanceof DeveloperMenu m && m.getDeveloperType() == DeveloperType.PORTABLE
                && m.getBlockPos() == null, "portable opens its menu");
        player.closeContainer();
        player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        player.setItemInHand(InteractionHand.OFF_HAND, portable);
        portable.use(helper.getLevel(), player, InteractionHand.OFF_HAND);
        check(helper, player.containerMenu == player.inventoryMenu, "off hand does not open");
        helper.succeed();
    }

    // --- Induction Factor (T89) ---

    private static net.minecraft.world.level.storage.loot.LootContext chestContext(GameTestHelper helper,
            String tableId) {
        net.minecraft.world.level.storage.loot.LootParams params = new net.minecraft.world.level.storage.loot.LootParams
                .Builder(helper.getLevel()).create(net.minecraft.world.level.storage.loot.parameters.LootContextParamSets.EMPTY);
        net.minecraft.world.level.storage.loot.LootContext ctx = new net.minecraft.world.level.storage.loot.LootContext
                .Builder(params).create(java.util.Optional.empty());
        ctx.setQueriedLootTableId(ResourceLocation.parse(tableId));
        return ctx;
    }

    private static int factorsIn(java.util.List<ItemStack> loot) {
        return (int) loot.stream().filter(s -> s.is(ModItems.INDUCTION_FACTOR.get())).count();
    }

    @GameTest(template = EMPTY)
    public static void inductionFactorLootModifierOnlyForChestTables(GameTestHelper helper) {
        var always = new com.railgunreborn.loot.InductionFactorLootModifier(
                new net.minecraft.world.level.storage.loot.predicates.LootItemCondition[0], 1.0f);
        var never = new com.railgunreborn.loot.InductionFactorLootModifier(
                new net.minecraft.world.level.storage.loot.predicates.LootItemCondition[0], 0.0f);
        for (String table : new String[] {"minecraft:chests/village/village_weaponsmith",
                "othermod:chests/castle/treasure"}) {
            var loot = always.apply(new it.unimi.dsi.fastutil.objects.ObjectArrayList<ItemStack>(),
                    chestContext(helper, table));
            check(helper, factorsIn(loot) == 1, "chance 1 must add one factor to " + table);
            ResourceLocation cat = com.railgunreborn.item.InductionFactorItem.categoryOf(loot.get(0)).orElse(null);
            check(helper, cat != null && AbilityRegistries.category(cat).isPresent(),
                    "factor must carry a registered category, was " + cat);
            check(helper, factorsIn(never.apply(new it.unimi.dsi.fastutil.objects.ObjectArrayList<ItemStack>(),
                    chestContext(helper, table))) == 0, "chance 0 must add nothing to " + table);
        }
        for (String table : new String[] {"minecraft:blocks/stone", "minecraft:entities/zombie",
                "othermod:blocks/chests_ore"}) {
            var loot = always.apply(new it.unimi.dsi.fastutil.objects.ObjectArrayList<ItemStack>(),
                    chestContext(helper, table));
            check(helper, factorsIn(loot) == 0, "non-chest table " + table + " must not get a factor");
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerObtainCategoryByNameConsumesFactor(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        check(helper, com.railgunreborn.ability.develop.CategoryLookup.byName("  VECTOR   manipulation ")
                .filter(id -> id.getPath().equals("vecmanip")).isPresent(), "en name lookup");
        check(helper, com.railgunreborn.ability.develop.CategoryLookup.byName("manipulación vectorial").isPresent(),
                "es name lookup");
        check(helper, com.railgunreborn.ability.develop.CategoryLookup.byName("Teleporter").isPresent(), "id lookup");
        check(helper, com.railgunreborn.ability.develop.CategoryLookup.byName("nothing").isEmpty(), "unknown name");

        ResourceLocation tele = com.railgunreborn.ability.develop.CategoryLookup.byName("teleporter").orElseThrow();
        DeveloperMenu menu = openPortable(helper, player);
        // Sin factor: rechazado y no pasa nada.
        DevelopResult denied = menu.start(player, DevelopAction.levelWithFactor(tele));
        check(helper, denied == DevelopResult.NO_FACTOR, "expected NO_FACTOR, was " + denied);
        check(helper, !AbilityData.get(player).hasCategory(), "no category without a factor");

        // Con un factor de OTRA categoría tampoco.
        ResourceLocation other = Electromaster.ID;
        player.getInventory().add(com.railgunreborn.item.InductionFactorItem.of(other));
        check(helper, menu.start(player, DevelopAction.levelWithFactor(tele)) == DevelopResult.NO_FACTOR,
                "factor of another category must not work");

        player.getInventory().add(com.railgunreborn.item.InductionFactorItem.of(tele));
        check(helper, menu.start(player, DevelopAction.levelWithFactor(tele)) == DevelopResult.OK, "should start");
        tickMenu(menu, player, DevelopRules.totalTicks(5, DeveloperType.PORTABLE));
        AbilityData data = AbilityData.get(player);
        check(helper, tele.equals(data.getCategory().orElse(null)),
                "category should be teleporter, was " + data.getCategory());
        check(helper, data.getLevel() == 1, "level 1");
        check(helper, !com.railgunreborn.item.InductionFactorItem.has(player, tele), "factor must be consumed");
        check(helper, com.railgunreborn.item.InductionFactorItem.has(player, other), "other factor must be kept");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void developerLearnKeepsFactors(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        DeveloperMenu menu = openPortable(helper, player);
        int categories = 0;
        for (var category : AbilityRegistries.CATEGORY_REGISTRY) {
            player.getInventory().add(com.railgunreborn.item.InductionFactorItem.of(category.getId()));
            categories++;
        }
        check(helper, menu.start(player, DevelopAction.level()) == DevelopResult.OK, "learn should start");
        tickMenu(menu, player, DevelopRules.totalTicks(5, DeveloperType.PORTABLE));
        check(helper, AbilityData.get(player).hasCategory(), "learn gives some category");
        int left = 0;
        for (var category : AbilityRegistries.CATEGORY_REGISTRY) {
            left += com.railgunreborn.item.InductionFactorItem.has(player, category.getId()) ? 1 : 0;
        }
        check(helper, left == categories, "learn must not consume factors");
        helper.succeed();
    }
}
