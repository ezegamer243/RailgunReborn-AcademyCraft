package com.railgunreborn.gametest;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.teleporter.Teleporter;
import com.railgunreborn.ability.vecmanip.StormWingSkill;
import com.railgunreborn.ability.vecmanip.VecDeviationSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de integración de Vector Manipulation (T78): aprender todo por la misma vía que el comando, coherencia
 * del árbol, textos en los dos idiomas, cambio de categoría y apagado de los interruptores.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class VecManipIntegrationGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-vm-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Lo mismo que hace {@code /railgunreborn learn vecmanip/all} (RailgunCommands.learnAll). */
    private static int learnAll(ServerPlayer player) {
        AbilityData ability = AbilityData.get(player);
        Category category = AbilityRegistries.category(VecManip.ID).orElseThrow();
        int added = 0;
        for (Skill skill : category.getSkills()) {
            if (ability.learnSkill(skill.getId())) {
                added++;
            }
        }
        CPData.get(player);
        return added;
    }

    private static List<Skill> ownSkills() {
        return List.of(VecManip.DIR_SHOCK.get(), VecManip.GROUND_SHOCK.get(), VecManip.VEC_ACCEL.get(),
                VecManip.VEC_DEVIATION.get(), VecManip.DIR_BLAST.get(), VecManip.STORM_WING.get(),
                VecManip.BLOOD_RETRO.get(), VecManip.VEC_REFLECTION.get(), VecManip.PLASMA_CANNON.get());
    }

    private static CPData prepare(ServerPlayer player, int level) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(level);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return cp;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    private static void press(GameTestHelper helper, ServerPlayer player, Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, skill + " should start");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
    }

    @GameTest(template = EMPTY)
    public static void learnAllGivesNineSkillsAndGenerics(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        prepare(player, 5);
        int added = learnAll(player);
        AbilityData data = AbilityData.get(player);
        for (Skill s : ownSkills()) {
            check(helper, data.isLearned(s.getId()), s + " should be learned");
        }
        VecManip.GENERICS.values().forEach(h -> check(helper, data.isLearned(h.get().getId()),
                h.get() + " generic should be learned"));
        check(helper, added == ownSkills().size() + VecManip.GENERICS.size(),
                "added should be 9 + generics, was " + added);
        check(helper, learnAll(player) == 0, "second learn all adds nothing");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void skillTreeParentsAndLevelsAreConsistent(GameTestHelper helper) {
        Category category = VecManip.CATEGORY.get();
        List<Skill> skills = category.getSkills();
        check(helper, skills.size() == ownSkills().size() + VecManip.GENERICS.size(),
                "category skill count, was " + skills.size());
        for (Skill s : ownSkills()) {
            check(helper, skills.contains(s), s + " is listed in the category");
            check(helper, s.getLevel() >= 1 && s.getLevel() <= 5, s + " level in 1..5");
            check(helper, s.canControl(), s + " has a key");
            s.getParent().ifPresent(parent -> {
                Skill p = skills.stream().filter(k -> k.getId().equals(parent.skill())).findFirst().orElse(null);
                check(helper, p != null, s + " parent " + parent.skill() + " must exist in the category");
                if (p != null) {
                    check(helper, p.getLevel() <= s.getLevel(), s + " parent level must be <= its own");
                }
            });
            if (s.getParent().isEmpty()) {
                check(helper, s == VecManip.DIR_SHOCK.get(), s + " is not the root but has no parent");
            }
        }
        helper.succeed();
    }

    private static JsonObject lang(String file) throws Exception {
        try (InputStream in = VecManipIntegrationGameTests.class
                .getResourceAsStream("/assets/" + RailgunReborn.MODID + "/lang/" + file)) {
            if (in == null) {
                throw new IllegalStateException("missing " + file);
            }
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        }
    }

    @GameTest(template = EMPTY)
    public static void everySkillHasNameAndDescriptionInBothLanguages(GameTestHelper helper) {
        try {
            for (String file : List.of("en_us.json", "es_es.json")) {
                JsonObject json = lang(file);
                for (Skill s : VecManip.CATEGORY.get().getSkills()) {
                    for (String key : List.of(s.getNameKey(), s.getDescriptionKey())) {
                        check(helper, json.has(key) && !json.get(key).getAsString().isBlank(),
                                file + " is missing " + key);
                    }
                }
            }
        } catch (Exception e) {
            helper.fail("lang files unreadable: " + e);
        }
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void changingCategoryClearsActiveContexts(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        prepare(player, 5);
        learnAll(player);
        press(helper, player, VecManip.VEC_DEVIATION.get());
        check(helper, VecDeviationSkill.activeField(player) != null, "field on");
        check(helper, !SkillContexts.active(player).isEmpty(), "a context is alive");
        AbilityData.get(player).setCategory(Teleporter.ID);
        SkillContexts.tick(player);
        check(helper, SkillContexts.active(player).isEmpty(), "category change must end every context");
        check(helper, VecDeviationSkill.activeField(player) == null, "the field is gone");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleSkillsTurnOffWhenPlayerDies(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        prepare(player, 5);
        learnAll(player);
        press(helper, player, VecManip.VEC_DEVIATION.get());
        ping(player, 2);
        check(helper, VecDeviationSkill.activeField(player) != null, "deviation on before dying");
        player.setHealth(0f);
        SkillContexts.tick(player);
        check(helper, VecDeviationSkill.activeField(player) == null && SkillContexts.active(player).isEmpty(),
                "deviation must turn off when the player dies");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void toggleSkillsTurnOffWhenOverloaded(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        CPData cp = prepare(player, 5);
        learnAll(player);
        press(helper, player, VecManip.STORM_WING.get());
        ping(player, 2);
        check(helper, StormWingSkill.activeWing(player) != null, "storm wing on before overload");
        cp.consumeWithForce(player, cp.getMaxOverload() + 1f, 0f);
        check(helper, cp.isOverloaded(), "the player is overloaded");
        SkillContexts.tick(player);
        check(helper, StormWingSkill.activeWing(player) == null && SkillContexts.active(player).isEmpty(),
                "storm wing must turn off on overload");
        helper.succeed();
    }
}
