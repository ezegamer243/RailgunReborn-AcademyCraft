package com.railgunreborn.gametest;

import java.util.List;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.common.SafeTeleport;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.context.StartResult;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.vecmanip.StormWingRules;
import com.railgunreborn.ability.vecmanip.StormWingSkill;
import com.railgunreborn.ability.vecmanip.VecManip;
import com.railgunreborn.network.SkillContextActionPayload;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * GameTests de Storm Wing (T74). Jugador falso en (4.5, 1, 4.5). Salvo en la prueba de rotura, la exp es ≥ 0.15 para
 * que el sorteo de bloques al azar no toque las estructuras vecinas; la rotura se prueba en una casilla concreta.
 */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class StormWingGameTests {
    private static final String EMPTY = "empty";
    private static final int ID = 1;
    private static final float EPS = 1e-3f;
    /** Exp sin rotura de bloques (≥ 0.15). */
    private static final float SAFE_EXP = 0.2f;

    private static ServerPlayer player(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-sw-" + UUID.randomUUID().toString().substring(0, 6)), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 4.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar.
        player.setYHeadRot(0f);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    /** Vector Manipulation nivel 3 con Storm Wing (exp dada), CP lleno y modo habilidad encendido. */
    private static Skill setUp(ServerPlayer player, float exp) {
        AbilityData ability = AbilityData.get(player);
        ability.setCategory(VecManip.ID);
        ability.setLevel(3);
        Skill skill = VecManip.STORM_WING.get();
        ability.learnSkill(skill.getId());
        ability.setSkillExp(skill.getId(), exp);
        CPData cp = CPData.get(player);
        cp.setActivated(player, true);
        cp.recoverAll();
        return skill;
    }

    private static void ping(ServerPlayer player, int ticks) {
        for (int i = 0; i < ticks; i++) {
            SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEEP_ALIVE);
            SkillContexts.tick(player);
        }
    }

    /** Pulsa y suelta la tecla: empieza la carga (sin ningún tick todavía). */
    private static StormWingSkill.StormWingContext turnOn(GameTestHelper helper, ServerPlayer player, Skill skill) {
        check(helper, SkillContexts.start(player, ID, skill) == StartResult.OK, "start should be accepted");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.KEY_UP);
        StormWingSkill.StormWingContext wing = StormWingSkill.activeWing(player);
        check(helper, wing != null, "the wing should stay active after releasing the key");
        return wing;
    }

    // --- Registro ---

    @GameTest(template = EMPTY)
    public static void stormWingIsRegisteredAtLevel3UnderVecAccel(GameTestHelper helper) {
        Skill skill = VecManip.STORM_WING.get();
        check(helper, skill.getCategoryId().equals(VecManip.ID), "belongs to vecmanip");
        check(helper, skill.getLevel() == 3 && skill.canControl(), "level 3, controllable");
        check(helper, skill.isToggle(), "it is a toggle");
        check(helper, skill.getParent().isPresent()
                && skill.getParent().get().skill().equals(VecManip.VEC_ACCEL.getId())
                && Math.abs(skill.getParent().get().minExp()) < EPS, "parent: vec_accel (0.0)");
        check(helper, skill.getGuiX() == 130 && skill.getGuiY() == 20, "tree position should be 130, 20");
        List<Skill> skills = VecManip.CATEGORY.get().getSkills();
        check(helper, skills.indexOf(skill) == skills.indexOf(VecManip.DIR_BLAST.get()) + 1,
                "registered right after dir_blast");
        check(helper, skill.getIcon().getPath().equals("textures/skill/vecmanip/storm_wing.png"),
                "icon " + skill.getIcon());
        helper.succeed();
    }

    // --- Carga y coste ---

    @GameTest(template = EMPTY)
    public static void chargeIsFreeThenFlightConsumesEveryTick(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        CPData cp = CPData.get(player);
        float cpFull = cp.getCP();
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        int charge = StormWingRules.chargeTicks(SAFE_EXP);
        check(helper, wing.chargeTicks() == charge, "charge ticks " + wing.chargeTicks());
        ping(player, charge - 1);
        check(helper, !wing.isFlying(), "still charging one tick before the end");
        check(helper, cp.getCP() == cpFull && cp.getOverload() == 0f, "the charge is free");
        ping(player, 1);
        check(helper, wing.isFlying(), "the server itself switches to flight after " + charge + " ticks");
        check(helper, cp.getCP() == cpFull && cp.getOverload() == 0f, "switching costs nothing");
        ping(player, 5);
        check(helper, wing.flightTicks() == 5, "5 paid flight ticks, was " + wing.flightTicks());
        check(helper, Math.abs(cpFull - cp.getCP() - 5 * StormWingRules.cpPerTick(SAFE_EXP)) < 0.01f,
                "CP per tick, spent " + (cpFull - cp.getCP()));
        check(helper, Math.abs(cp.getOverload() - 5 * StormWingRules.overloadPerTick(SAFE_EXP)) < 0.01f,
                "overload per tick, was " + cp.getOverload());
        check(helper, AbilityData.get(player).getSkillExp(skill.getId()) > SAFE_EXP, "flying gives exp");
        // Segunda pulsación (o V): el cliente la cierra y avisa.
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, wing.isTerminated() && StormWingSkill.activeWing(player) == null, "pressing again ends it");
        check(helper, CooldownData.get(player).getRemaining(skill.getId(), 0) == StormWingRules.cooldown(SAFE_EXP),
                "cooldown after ending");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void flightLastsAboutFiveSecondsOnLevel3Overload(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0.15f);
        CPData cp = CPData.get(player);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, StormWingRules.chargeTicks(0.15f));
        check(helper, wing.isFlying(), "flying");
        ping(player, 200);
        check(helper, wing.isTerminated(), "the flight ends by itself");
        int flown = wing.flightTicks();
        check(helper, flown >= 95 && flown <= 125, "about 5-6 s of flight, was " + flown + " ticks");
        check(helper, cp.isOverloaded() || cp.getCP() < StormWingRules.cpPerTick(0.15f),
                "it ended because of overload or CP");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void runningOutOfCpEndsTheFlight(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        CPData cp = CPData.get(player);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, wing.chargeTicks());
        cp.consumeWithForce(player, 0f, cp.getCP() - 10f);
        ping(player, 1);
        check(helper, wing.isTerminated(), "without CP for a tick the flight ends");
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "and the cooldown is set");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void endingDuringTheChargeSetsCooldownToo(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, 3);
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, wing.isTerminated() && !wing.isFlying(), "ended while charging");
        check(helper, CooldownData.get(player).isInCooldown(skill.getId()), "the cooldown is always set");
        check(helper, SkillContexts.start(player, ID + 1, skill) != StartResult.OK, "cannot restart in cooldown");
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void abilityModeOffEndsIt(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, 2);
        CPData.get(player).setActivated(player, false);
        ping(player, 1);
        check(helper, wing.isTerminated(), "turning the ability mode off (V) ends it");
        helper.succeed();
    }

    // --- Caída y anti-kick ---

    @GameTest(template = EMPTY)
    public static void noFallDamageWhileActiveAndShortGuardAfter(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        player.fallDistance = 30f;
        player.connection.aboveGroundTickCount = 70;
        ping(player, 1);
        check(helper, player.fallDistance == 0f, "fall distance is reset while charging");
        check(helper, player.connection.aboveGroundTickCount == 0, "the anti-kick counter is reset");
        ping(player, wing.chargeTicks() + 2);
        player.fallDistance = 30f;
        player.connection.aboveGroundTickCount = 70;
        ping(player, 1);
        check(helper, player.fallDistance == 0f && player.connection.aboveGroundTickCount == 0,
                "and while flying");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        check(helper, SafeTeleport.isFallGuarded(player), "~3 s of fall immunity after ending");
        helper.succeed();
    }

    // --- Ráfaga con exp 1 ---

    @GameTest(template = EMPTY)
    public static void gustAtMaxExpPushesMobsButNotItems(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 1f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 7.5));
        zombie.setDeltaMovement(Vec3.ZERO);
        ItemEntity item = helper.spawnItem(Items.STONE, new Vec3(6.5, 1, 4.5));
        item.setNoGravity(true);
        item.setDeltaMovement(Vec3.ZERO);
        Vec3 playerMotion = player.getDeltaMovement();
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, StormWingRules.chargeTicks(1f));
        check(helper, wing.isFlying(), "flying");
        Vec3 push = zombie.getDeltaMovement();
        check(helper, push.length() >= 0.5 - EPS && push.length() <= 1.0 + EPS, "zombie pushed: " + push);
        check(helper, push.z > 0, "away from the player (+Z): " + push);
        check(helper, item.getDeltaMovement().equals(Vec3.ZERO), "items are not pushed");
        check(helper, player.getDeltaMovement().equals(playerMotion), "the caster is not pushed");
        item.discard();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void noGustBelowMaxExp(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0.9f);
        Zombie zombie = helper.spawnWithNoFreeWill(EntityType.ZOMBIE, new Vec3(4.5, 1, 7.5));
        zombie.setDeltaMovement(Vec3.ZERO);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, wing.chargeTicks());
        check(helper, wing.isFlying(), "flying");
        check(helper, zombie.getDeltaMovement().equals(Vec3.ZERO), "no gust below exp 1");
        helper.succeed();
    }

    // --- Rotura de bloques con exp baja ---

    @GameTest(template = EMPTY)
    public static void lowExpBreaksWeakBlocksWithDrops(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, 0.1f);
        helper.setBlock(new BlockPos(2, 0, 2), Blocks.STONE);
        helper.setBlock(new BlockPos(2, 1, 2), Blocks.DANDELION);
        helper.setBlock(new BlockPos(6, 1, 6), Blocks.STONE);
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        check(helper, wing.breaksBlocksNow(), "exp 0.1 breaks blocks");
        BlockPos flower = helper.absolutePos(new BlockPos(2, 1, 2));
        check(helper, wing.tryBreak(flower, true), "the dandelion breaks");
        check(helper, helper.getBlockState(new BlockPos(2, 1, 2)).isAir(), "and is gone");
        AABB area = new AABB(flower).inflate(1.5);
        List<ItemEntity> drops = helper.getLevel().getEntitiesOfClass(ItemEntity.class, area);
        check(helper, drops.stream().anyMatch(i -> i.getItem().is(Items.DANDELION)), "it drops its loot");
        drops.forEach(ItemEntity::discard);
        check(helper, !wing.tryBreak(helper.absolutePos(new BlockPos(6, 1, 6)), true), "stone is too hard");
        check(helper, helper.getBlockState(new BlockPos(6, 1, 6)).is(Blocks.STONE), "stone stays");

        // Protección: en modo aventura no se rompe nada.
        helper.setBlock(new BlockPos(2, 1, 2), Blocks.DANDELION);
        player.setGameMode(GameType.ADVENTURE);
        check(helper, !wing.tryBreak(flower, true), "protected: adventure mode cannot break");
        check(helper, helper.getBlockState(new BlockPos(2, 1, 2)).is(Blocks.DANDELION), "the flower stays");
        player.setGameMode(GameType.SURVIVAL);

        // Con exp 0.15 o más (en vivo) ya no rompe.
        AbilityData.get(player).setSkillExp(skill.getId(), 0.2f);
        check(helper, !wing.breaksBlocksNow(), "exp 0.2 does not break blocks");
        SkillContexts.handleAction(player, ID, SkillContextActionPayload.Action.TERMINATE);
        helper.succeed();
    }

    // --- Montura ---

    @GameTest(template = EMPTY)
    public static void flyingDismounts(GameTestHelper helper) {
        ServerPlayer player = player(helper);
        Skill skill = setUp(player, SAFE_EXP);
        var boat = helper.spawn(EntityType.BOAT, new Vec3(4.5, 1, 4.5));
        player.startRiding(boat, true);
        check(helper, player.isPassenger(), "riding the boat");
        StormWingSkill.StormWingContext wing = turnOn(helper, player, skill);
        ping(player, wing.chargeTicks() + 1);
        check(helper, !player.isPassenger(), "flying dismounts");
        boat.discard();
        helper.succeed();
    }
}
