package com.railgunreborn.gametest;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.item.CoinItem;
import com.railgunreborn.registry.ModItems;

import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** GameTests de la moneda (T32): lanzamiento, consumo, vuelo, ventana del QTE y devolución. */
@GameTestHolder(RailgunReborn.MODID)
@PrefixGameTestTemplate(false)
public class CoinGameTests {
    private static final String EMPTY = "empty";

    private static ServerPlayer player(GameTestHelper helper, GameType mode) {
        ServerLevel level = helper.getLevel();
        MinecraftServer server = level.getServer();
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(
                new GameProfile(UUID.randomUUID(), "test-coin-player"), false);
        ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(connection);
        player.connection = new QuietListener(server, connection, player, cookie);
        level.addNewPlayer(player);
        Vec3 pos = helper.absoluteVec(new Vec3(4.5, 1, 1.5));
        player.moveTo(pos.x, pos.y, pos.z, 0f, 0f);
        // moveTo no toca la cabeza: yHeadRot nace al azar (0-6 grados) y el trazado de la vista (getViewVector) la usa.
        player.setYHeadRot(0f);
        player.setGameMode(mode);
        return player;
    }

    private static final class QuietListener extends ServerGamePacketListenerImpl {
        QuietListener(MinecraftServer server, Connection connection, ServerPlayer player,
                CommonListenerCookie cookie) {
            super(server, connection, player, cookie);
        }

        @Override
        public void send(Packet<?> packet) {
        }

        @Override
        public void send(Packet<?> packet, PacketSendListener listener) {
        }
    }

    private static void floor(GameTestHelper helper) {
        for (int x = 0; x < 9; x++) {
            for (int z = 0; z < 9; z++) {
                helper.setBlock(new BlockPos(x, 0, z), Blocks.STONE);
            }
        }
    }

    private static void check(GameTestHelper helper, boolean condition, String message) {
        if (!condition) {
            helper.fail(message);
        }
    }

    private static InteractionResultHolder<ItemStack> throwCoin(ServerPlayer player) {
        CoinItem item = (CoinItem) ModItems.COIN.get();
        return item.use(player.level(), player, InteractionHand.MAIN_HAND);
    }

    @GameTest(template = EMPTY)
    public static void throwingConsumesOneCoinInSurvival(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.COIN.get(), 3));

        InteractionResultHolder<ItemStack> result = throwCoin(player);
        check(helper, result.getResult().consumesAction(), "throw should succeed");
        check(helper, player.getMainHandItem().getCount() == 2, "should have 2 coins left");
        CoinEntity coin = CoinEntity.findActive(player);
        check(helper, coin != null, "coin entity should exist");

        InteractionResultHolder<ItemStack> second = throwCoin(player);
        check(helper, !second.getResult().consumesAction(), "second throw while one is in the air must pass");
        check(helper, player.getMainHandItem().getCount() == 2, "second throw must not consume");
        coin.discard();
        helper.succeed();
    }

    @GameTest(template = EMPTY)
    public static void throwingDoesNotConsumeInCreative(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.CREATIVE);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.COIN.get(), 3));
        throwCoin(player);
        check(helper, player.getMainHandItem().getCount() == 3, "creative must keep the coins");
        CoinEntity coin = CoinEntity.findActive(player);
        check(helper, coin != null, "coin entity should exist");
        coin.discard();
        check(helper, player.getMainHandItem().getCount() == 3, "creative must not get a refund either");
        helper.succeed();
    }

    @GameTest(template = EMPTY, timeoutTicks = 80)
    public static void flightProgressesWindowAndRefund(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.COIN.get(), 1));
        throwCoin(player);
        CoinEntity coin = CoinEntity.findActive(player);
        check(helper, coin != null, "coin entity should exist");
        check(helper, player.getMainHandItem().isEmpty(), "the last coin is in the air");
        double baseY = coin.getY();
        double[] maxHeight = {0};
        float[] lastProgress = {0};

        helper.onEachTick(() -> {
            if (coin.isRemoved()) {
                return;
            }
            int age = coin.getAge();
            maxHeight[0] = Math.max(maxHeight[0], coin.getY() - baseY);
            if (age > 0) {
                float progress = coin.getProgress();
                check(helper, progress >= lastProgress[0] - 1e-6f, "progress must not decrease at age " + age);
                lastProgress[0] = progress;
                boolean strict = age >= 25 && age <= 29;
                check(helper, coin.isInQteWindow() == strict, "strict window wrong at age " + age);
                boolean tolerant = age >= 25 && age <= 33;
                check(helper, coin.isInQteWindow(CoinEntity.QTE_TOLERANCE_TICKS) == tolerant,
                        "tolerant window wrong at age " + age);
                check(helper, coin.isFlying() == (age < 30), "flying flag wrong at age " + age);
                check(helper, Math.abs(coin.getX() - player.getX()) < 1e-6, "coin must follow the owner in X");
            }
        });
        helper.runAfterDelay(60, () -> {
            check(helper, coin.isRemoved(), "coin should be gone after flight plus tolerance");
            check(helper, maxHeight[0] > 6.0 && maxHeight[0] < 7.0, "peak height was " + maxHeight[0]);
            check(helper, player.getMainHandItem().is(ModItems.COIN.get())
                    && player.getMainHandItem().getCount() == 1, "coin should return to the empty main hand");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void consumedCoinIsNotReturned(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.COIN.get(), 1));
        throwCoin(player);
        CoinEntity coin = CoinEntity.findActive(player);
        check(helper, coin != null, "coin entity should exist");
        helper.runAfterDelay(5, () -> {
            check(helper, !coin.isAttemptSpent(), "attempt should be fresh");
            coin.spendAttempt();
            check(helper, coin.isAttemptSpent(), "attempt should be spent");
            coin.consume();
            check(helper, coin.isRemoved(), "consumed coin should be removed");
            check(helper, player.getMainHandItem().isEmpty(), "consumed coin must not come back");
            check(helper, CoinEntity.findActive(player) == null, "no active coin after consume");
            helper.succeed();
        });
    }

    @GameTest(template = EMPTY)
    public static void refundGoesToInventoryWhenHandIsBusy(GameTestHelper helper) {
        floor(helper);
        ServerPlayer player = player(helper, GameType.SURVIVAL);
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.COIN.get(), 1));
        throwCoin(player);
        CoinEntity coin = CoinEntity.findActive(player);
        check(helper, coin != null, "coin entity should exist");
        player.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(net.minecraft.world.item.Items.STICK));
        coin.discard();
        int coins = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ModItems.COIN.get())) {
                coins += stack.getCount();
            }
        }
        check(helper, coins == 1, "coin should be back in the inventory, found " + coins);
        helper.succeed();
    }
}
