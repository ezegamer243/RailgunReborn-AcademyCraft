package com.railgunreborn.block;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Pilar del generador eólico: bloque simple con el modelo OBJ del original (columna de radio 0,4). */
public class WindGenPillarBlock extends Block {
    public static final MapCodec<WindGenPillarBlock> CODEC = simpleCodec(WindGenPillarBlock::new);
    private static final VoxelShape SHAPE = Block.box(3.2, 0, 3.2, 12.8, 16, 12.8);

    public WindGenPillarBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }
}
