package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Cabeza del generador eólico: guarda las aspas ({@code windgen_fan}) y cada {@link WindGenRules#CHECK_INTERVAL}
 * ticks revisa la estructura hacia abajo (8-40 pilares y la base) y que el cuadro de 15x15 del rotor sea todo aire.
 * No genera: la energía la produce y guarda la base ({@link WindGenBaseBlockEntity}), que lee este estado.
 *
 * <p>El estado, si el rotor tiene sitio y las aspas se mandan al cliente para el renderizador del rotor.
 */
public class WindGenMainBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_FAN = 0;

    public static final int DATA_STATUS = 0;
    /** Producción en centésimas de IF/t (2 ranuras: puede pasar de 32767 con el multiplicador). */
    public static final int DATA_OUTPUT = 1;
    public static final int DATA_HEIGHT = DATA_OUTPUT + ContainerDataInts.SLOTS;
    public static final int DATA_COUNT = DATA_HEIGHT + 1;

    private final ItemStackHandler items = new ItemStackHandler(1) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isFan(stack);
        }

        @Override
        public int getSlotLimit(int slot) {
            return 1;
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
            sync();
            checkTimer = 0; // revisar en el próximo tick: poner o quitar las aspas se nota enseguida
        }
    };

    private WindGenRules.Status status = WindGenRules.Status.INCOMPLETE;
    /** El cuadro del rotor está libre (independiente de la estructura: decide si se dibujan las aspas). */
    private boolean areaClear;
    private int checkTimer;

    // Solo cliente: giro acumulado del rotor (grados) y último instante dibujado (ticks con fracción).
    public float spinAngle;
    public float spinLastTime = -1f;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            int centi = WindGenRules.toCenti(getOutputPerTick());
            return switch (index) {
                case DATA_STATUS -> status.ordinal();
                case DATA_OUTPUT, DATA_OUTPUT + 1 -> ContainerDataInts.part(centi, index - DATA_OUTPUT);
                case DATA_HEIGHT -> worldPosition.getY();
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public WindGenMainBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WINDGEN_MAIN.get(), pos, state);
    }

    public static boolean isFan(ItemStack stack) {
        return stack.is(ModItems.WINDGEN_FAN.get());
    }

    // --- Tick ---

    public static void serverTick(Level level, BlockPos pos, BlockState state, WindGenMainBlockEntity be) {
        if (--be.checkTimer <= 0) {
            be.checkTimer = WindGenRules.CHECK_INTERVAL;
            be.refresh();
        }
    }

    /** Revisa estructura, aspas y aire ahora mismo; si algo cambió lo manda al cliente. */
    public void refresh() {
        if (level == null) {
            return;
        }
        BlockState state = getBlockState();
        if (!state.is(ModBlocks.WINDGEN_MAIN.get())) {
            return;
        }
        Direction facing = state.getValue(WindGenMainBlock.FACING);
        BlockPos below = worldPosition.below();
        WindGenRules.Scan scan = WindGenRules.scan(i -> partBelow(level, below.below(i)));
        boolean clear = isAreaClear(level, WindGenMainBlock.partPos(worldPosition, facing,
                WindGenMainBlock.PART_FRONT), facing);
        WindGenRules.Status next;
        if (!scan.complete()) {
            next = scan.status();
        } else if (!hasFan()) {
            next = WindGenRules.Status.NO_FAN;
        } else if (!clear) {
            next = WindGenRules.Status.BLOCKED;
        } else {
            next = WindGenRules.Status.WORKING;
        }
        if (next != status || clear != areaClear) {
            status = next;
            areaClear = clear;
            setChanged();
            sync();
        }
    }

    private static WindGenRules.Part partBelow(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.is(ModBlocks.WINDGEN_PILLAR.get())) {
            return WindGenRules.Part.PILLAR;
        }
        if (state.is(ModBlocks.WINDGEN_BASE.get()) && state.getValue(WindGenBaseBlock.HALF) == DoubleBlockHalf.UPPER) {
            return WindGenRules.Part.END;
        }
        return WindGenRules.Part.OTHER;
    }

    /**
     * Todo aire en el cuadro vertical de 15x15 centrado en la parte delantera (sin contarla), perpendicular a
     * {@code facing}: es por donde pasan las aspas. Las posiciones de chunks sin cargar no se miran (no se fuerza
     * su carga).
     */
    public static boolean isAreaClear(Level level, BlockPos front, Direction facing) {
        Direction side = facing.getClockWise();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        int r = WindGenRules.CLEAR_RADIUS;
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                if (a == 0 && b == 0) {
                    continue;
                }
                cursor.set(front.getX() + side.getStepX() * a, front.getY() + b, front.getZ() + side.getStepZ() * a);
                if (level.isLoaded(cursor) && !level.getBlockState(cursor).isAir()) {
                    return false;
                }
            }
        }
        return true;
    }

    // --- Acceso ---

    public boolean hasFan() {
        return isFan(items.getStackInSlot(SLOT_FAN));
    }

    public WindGenRules.Status getStatus() {
        return status;
    }

    public boolean isAreaClear() {
        return areaClear;
    }

    /** IF/t que da la estructura con esta cabeza (0 si no está funcionando). */
    public double getOutputPerTick() {
        return status == WindGenRules.Status.WORKING
                ? WindGenRules.outputPerTick(worldPosition.getY(), RailgunConfig.generatorMultiplier())
                : 0.0;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public ContainerData getData() {
        return data;
    }

    public Direction getFacing() {
        return getBlockState().getValue(WindGenMainBlock.FACING);
    }

    public void dropContents(Level level, BlockPos pos) {
        Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(SLOT_FAN));
    }

    private void sync() {
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    // --- Guardado y sincronización ---

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.putInt("Status", status.ordinal());
        tag.putBoolean("Clear", areaClear);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        status = WindGenRules.Status.byIndex(tag.getInt("Status"));
        areaClear = tag.getBoolean("Clear");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // --- Menú ---

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.windgen_main");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new WindGenMainMenu(containerId, inventory, this);
    }
}
