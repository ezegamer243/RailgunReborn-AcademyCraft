package com.railgunreborn.block;

/**
 * Medidas de las pantallas "TechUI" del original (Imag Fusor, Metal Former), sin clases de Minecraft: las usan los
 * menús (posición de las ranuras), las pantallas, un test de distribución y el script de vista previa
 * ({@code tools/preview/GuiPreview.java}).
 * <p>
 * El arte del original es de doble resolución (352x374 para una GUI de 176x187). Las coordenadas {@code *_U/*_V}
 * van en píxeles de textura; las demás, en píxeles de GUI. Las cajas del arte caen en filas impares de la textura,
 * así que el arte se dibuja medio píxel más arriba ({@link #ART_SHIFT_Y}): así cada caja queda en píxeles enteros y
 * la fila de textura {@code v} cae en la fila de GUI {@code (v - 1) / 2}. El original hacía lo mismo al poner los
 * elementos en y = 4.5, 8.5, 46.5...
 */
public final class TechUiLayout {
    public static final int WIDTH = 176;
    public static final int HEIGHT = 187;
    public static final int TEX_W = 352;
    public static final int TEX_H = 374;
    public static final float ART_SHIFT_Y = -0.5f;

    public static final int SLOT_SIZE = 16;
    public static final int SLOT_PITCH = 18;

    // Inventario del jugador: cuadrícula propia (no la del arte, que es de 16 px y deja los ítems pegados al borde).
    public static final int INV_X = 8;
    public static final int INV_Y = 105;
    public static final int HOTBAR_Y = 163;

    // Ranuras de la máquina: centradas en las cajas de 18x18 del arte (interior de 16x16).
    public static final int INPUT_X = 15;
    public static final int INPUT_Y = 49;
    public static final int OUTPUT_X = 145;
    public static final int OUTPUT_Y = 49;
    public static final int UNIT_IN_X = 15;
    public static final int UNIT_IN_Y = 10;
    public static final int UNIT_OUT_X = 145;
    public static final int UNIT_OUT_Y = 10;
    public static final int BATTERY_X = 44;
    public static final int BATTERY_Y = 80;

    // Logo "Academy tech." de inventory.png: solo se dibuja esta parte (las cajas de esa textura se reemplazan).
    public static final int LOGO_U = 210;
    public static final int LOGO_V = 164;
    public static final int LOGO_W = 132;
    public static final int LOGO_H = 40;

    // Imag Fusor: interior del depósito (textura) y su zona en la GUI (tooltip, texto de mB).
    public static final int TANK_U = 114;
    public static final int TANK_V = 22;
    public static final int TANK_UW = 123;
    public static final int TANK_VH = 30;
    public static final int TANK_X = 57;
    public static final int TANK_Y = 10;
    public static final int TANK_W = 62;
    public static final int TANK_H = 16;
    public static final int TANK_TEXT_CX = 90;
    public static final int TANK_TEXT_Y = 14;
    public static final int FUSOR_PROGRESS_U = 113;
    public static final int FUSOR_PROGRESS_V = 93;
    public static final int FUSOR_PROGRESS_W = 126;
    public static final int FUSOR_PROGRESS_H = 30;

    // Metal Former: barra de progreso, icono del modo y flechas (textura), más sus zonas de ratón en la GUI.
    public static final int FORMER_PROGRESS_U = 119;
    public static final int FORMER_PROGRESS_V = 93;
    public static final int FORMER_PROGRESS_W = 114;
    public static final int FORMER_PROGRESS_H = 30;
    public static final int ICON_U = 152;
    public static final int ICON_V = 9;
    public static final int ICON_TEX = 48;
    public static final int ARROW_LEFT_U = 120;
    public static final int ARROW_RIGHT_U = 200;
    public static final int ARROW_V = 17;
    public static final int ARROW_TEX = 32;
    public static final Rect ICON_AREA = new Rect(76, 4, 24, 24);
    public static final Rect LEFT_ARROW_AREA = new Rect(60, 8, 16, 16);
    public static final Rect RIGHT_ARROW_AREA = new Rect(100, 8, 16, 16);

    // Barra de energía de las dos máquinas, a la derecha de la ranura de batería y pasado el trazo decorativo del
    // arte (esa zona del arte está vacía).
    public static final Rect ENERGY_BAR = new Rect(96, 84, 64, 8);

    // Colores (ARGB). El arte es blanco con alfa: se tiñe de blanco celeste, como el original.
    public static final int ART_TINT = 0xEBD6F2FF;
    public static final int LINE_RGB = 0xD6F2FF;
    public static final int LINE_ALPHA = 0xE6;
    /** Alfa del brillo a 1, 2 y 3 píxeles de textura de la línea (copiado del arte). */
    public static final int[] GLOW_ALPHA = { 0x77, 0x47, 0x18 };
    public static final int BACKDROP = 0x58050A12;
    public static final int SLOT_FILL = 0x50000000;
    public static final int TANK_FILL = 0xA03C8CD2;
    public static final int NEEDED_MARK = 0xFFFFD27F;
    public static final int TEXT = 0xE6FFFFFF;
    public static final int ENERGY_FILL = 0xB0FFC84A;

    private TechUiLayout() {
    }

    /** Rectángulo en píxeles de GUI ({@code w}/{@code h} exclusivos). */
    public record Rect(int x, int y, int w, int h) {
        public boolean overlaps(Rect o) {
            return x < o.x + o.w && o.x < x + w && y < o.y + o.h && o.y < y + h;
        }

        public boolean contains(Rect o) {
            return o.x >= x && o.y >= y && o.x + o.w <= x + w && o.y + o.h <= y + h;
        }
    }

    public static int playerSlotX(int col) {
        return INV_X + col * SLOT_PITCH;
    }

    /** Filas 0-2: inventario; fila 3: barra rápida. */
    public static int playerSlotY(int row) {
        return row < 3 ? INV_Y + row * SLOT_PITCH : HOTBAR_Y;
    }

    public static Rect item(int x, int y) {
        return new Rect(x, y, SLOT_SIZE, SLOT_SIZE);
    }

    /**
     * Zona donde vanilla dibuja el ítem y su número con sombra (el número termina en x+16, y+16). Las líneas de un
     * marco propio ({@link #slotFrame}) quedan justo fuera.
     */
    public static Rect decorations(int x, int y) {
        return new Rect(x, y, SLOT_SIZE + 1, SLOT_SIZE + 1);
    }

    /** Marco propio de una ranura: línea de 1 px en x-1 y x+17; en la cuadrícula los vecinos comparten línea. */
    public static Rect slotFrame(int x, int y) {
        return new Rect(x - 1, y - 1, SLOT_PITCH + 1, SLOT_PITCH + 1);
    }

    /** Ranuras de máquina del Imag Fusor (x, y), en el orden en que las añade el menú. */
    public static int[][] imagFusorSlots() {
        return new int[][] { { INPUT_X, INPUT_Y }, { OUTPUT_X, OUTPUT_Y }, { UNIT_IN_X, UNIT_IN_Y },
                { BATTERY_X, BATTERY_Y }, { UNIT_OUT_X, UNIT_OUT_Y } };
    }

    /** Ranuras de máquina del Metal Former (entrada, salida, batería). */
    public static int[][] metalFormerSlots() {
        return new int[][] { { INPUT_X, INPUT_Y }, { OUTPUT_X, OUTPUT_Y }, { BATTERY_X, BATTERY_Y } };
    }
}
