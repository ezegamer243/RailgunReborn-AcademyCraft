package com.railgunreborn.block;

import java.util.Locale;
import java.util.function.IntFunction;

/**
 * Reglas puras del generador eólico (energy.md 1.3, {@code TileWindGenBase}/{@code TileWindGenMain} del original),
 * sin clases de Minecraft para poder probarlas con JUnit.
 *
 * <p>Estructura (de abajo arriba): base de 2 bloques de alto, entre {@link #MIN_PILLARS} y {@link #MAX_PILLARS}
 * pilares seguidos y la cabeza ({@code windgen_main}) justo encima. Producción: {@code 15 x lerp(0,5; 1; t)} IF/tick
 * con {@code t = clamp((Y - 70) / 90)}, donde Y es la altura de la cabeza (7,5 a Y<=70, 15 a Y>=160).
 */
public final class WindGenRules {
    public static final int MIN_PILLARS = 8;
    public static final int MAX_PILLARS = 40;
    public static final double MAX_OUTPUT = 15.0;
    public static final int LOW_Y = 70;
    public static final int HIGH_Y = 160;
    public static final double LOW_FACTOR = 0.5;
    /** Medio lado del cuadro de 15x15 que tiene que estar libre alrededor del rotor. */
    public static final int CLEAR_RADIUS = 7;
    /** Cada cuántos ticks se revisa la estructura y el aire (como el original). */
    public static final int CHECK_INTERVAL = 10;

    public static final int CAPACITY = 20_000;
    public static final int BANDWIDTH = 300;

    /** Vueltas del rotor a la altura mínima y a la máxima, en grados por segundo (solo visual). */
    public static final double SPIN_DEG_PER_SECOND = 90.0;

    private WindGenRules() {
    }

    /** Estado del generador; el orden es el de {@code ContainerData} (no cambiarlo sin cambiar las pantallas). */
    public enum Status {
        /** Tras los pilares no está la cabeza (vista desde la base) o la base (vista desde la cabeza). */
        INCOMPLETE,
        /** Menos de 8 pilares. */
        TOO_SHORT,
        /** Más de 40 pilares. */
        TOO_TALL,
        /** Estructura bien, sin aspas. */
        NO_FAN,
        /** Algo que no es aire en el cuadro de 15x15 del rotor. */
        BLOCKED,
        WORKING;

        public boolean structureComplete() {
            return ordinal() >= NO_FAN.ordinal();
        }

        public static Status byIndex(int index) {
            Status[] all = values();
            return all[Math.max(0, Math.min(all.length - 1, index))];
        }
    }

    /** Qué hay en cada posición de la columna, contando desde la primera tras la base (o bajo la cabeza). */
    public enum Part {
        PILLAR, END, OTHER
    }

    /** Resultado de recorrer la columna: estado de la estructura (uno de los tres primeros o NO_FAN = completa). */
    public record Scan(Status status, int pillars) {
        public boolean complete() {
            return status.structureComplete();
        }
    }

    /**
     * Recorre la columna de pilares: {@code partAt(i)} dice qué hay en la posición i (0 = la primera tras la base o
     * bajo la cabeza). Termina bien si tras 8..40 pilares aparece el otro extremo ({@link Part#END}). Mira como mucho
     * {@code MAX_PILLARS + 1} posiciones.
     */
    public static Scan scan(IntFunction<Part> partAt) {
        int pillars = 0;
        while (true) {
            Part part = partAt.apply(pillars);
            if (part == Part.PILLAR) {
                pillars++;
                if (pillars > MAX_PILLARS) {
                    return new Scan(Status.TOO_TALL, pillars);
                }
            } else if (part == Part.END) {
                return new Scan(pillars >= MIN_PILLARS ? Status.NO_FAN : Status.TOO_SHORT, pillars);
            } else {
                return new Scan(Status.INCOMPLETE, pillars);
            }
        }
    }

    /** Factor de altura: 0,5 hasta Y=70, sube lineal hasta 1 en Y=160. */
    public static double heightFactor(int mainY) {
        double t = (mainY - LOW_Y) / (double) (HIGH_Y - LOW_Y);
        t = Math.max(0.0, Math.min(1.0, t));
        return LOW_FACTOR + (1.0 - LOW_FACTOR) * t;
    }

    /** IF por tick con la cabeza a la altura {@code mainY}, por el multiplicador de generadores de la config. */
    public static double outputPerTick(int mainY, double multiplier) {
        return MAX_OUTPUT * heightFactor(mainY) * Math.max(0.0, multiplier);
    }

    /** Velocidad visual del rotor en grados por segundo (proporcional a la producción por altura). */
    public static double spinDegreesPerSecond(int mainY) {
        return SPIN_DEG_PER_SECOND * heightFactor(mainY);
    }

    /** Producción en centésimas de IF (para mandarla como entero a la pantalla). */
    public static int toCenti(double perTick) {
        return (int) Math.round(perTick * 100.0);
    }

    /** "7.5", "15", "10.83": centésimas a texto sin ceros de sobra. */
    public static String formatCenti(int centi) {
        if (centi % 100 == 0) {
            return Integer.toString(centi / 100);
        }
        if (centi % 10 == 0) {
            return String.format(Locale.ROOT, "%.1f", centi / 100.0);
        }
        return String.format(Locale.ROOT, "%.2f", centi / 100.0);
    }
}
