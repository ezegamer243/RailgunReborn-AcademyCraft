package com.railgunreborn.block;

import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Buffer de energía del Developer normal / avanzado (energy.md E3). Vive solo en la parte 0 (el controlador); las
 * otras 7 partes devuelven este mismo almacén por la capacidad FE (ver ModCapabilities), así que un cable vale en
 * cualquier cara de cualquier parte. Solo recibe: el desarrollo gasta con {@link ModEnergyStorage#tryConsume}.
 */
public class DeveloperBlockEntity extends BlockEntity {
    private final DeveloperType type;
    private final ModEnergyStorage energy;

    public DeveloperBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.DEVELOPER.get(), pos, state);
        this.type = ((DeveloperBlock) state.getBlock()).getDeveloperType();
        this.energy = ModEnergyStorage.receiver(type.energyCapacity(), type.energyBandwidth(), this::setChanged);
    }

    public DeveloperType getDeveloperType() {
        return type;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        energy.save(tag, "energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        energy.load(tag, "energy", registries);
    }
}
