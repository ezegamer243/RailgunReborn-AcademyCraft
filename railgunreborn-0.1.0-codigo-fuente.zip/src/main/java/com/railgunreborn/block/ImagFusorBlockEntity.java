package com.railgunreborn.block;

import java.util.Optional;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.railgunreborn.crafting.ImagFusorRecipe;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModRecipes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidActionResult;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Imag Fusor ({@code TileImagFusor} del original): funde un cristal con líquido de fase según las recetas
 * {@code railgunreborn:imag_fusor}. El líquido entra por la ranura de unidades llenas (unidad de materia, cubo o
 * cualquier recipiente con capacidad de fluido) o por tuberías; el depósito guarda 8000 mB.
 *
 * <p>El líquido se gasta al terminar la receta, no al empezar (si se saca el cristal a medias no se pierde nada).
 *
 * <p>Energía (energy.md, E2): buffer de {@link #ENERGY_CAPACITY} IF que se llena por cable (cualquier cara) o con la
 * ranura de batería. Cada tick de trabajo gasta {@code energy_per_tick} de la receta; si {@code energyRequired} está
 * activa y el buffer no la tiene entera, se pierde el progreso (como el original) y la luz se apaga.
 */
public class ImagFusorBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_INPUT = 0;
    public static final int SLOT_OUTPUT = 1;
    public static final int SLOT_UNIT_IN = 2;
    public static final int SLOT_BATTERY = 3;
    public static final int SLOT_UNIT_OUT = 4;
    public static final int SLOT_COUNT = 5;

    public static final int TANK_CAPACITY = 8000;
    public static final int ENERGY_CAPACITY = 2000;
    /** Tope por llamada para cables y otros mods (energy.md 1.1); la ranura de batería no lo usa. */
    public static final int ENERGY_MAX_RECEIVE = 50;

    // Índices de ContainerData (sincronizados como short: todos caben de sobra).
    public static final int DATA_PROGRESS = 0;
    public static final int DATA_MAX_PROGRESS = 1;
    public static final int DATA_TANK = 2;
    public static final int DATA_NEEDED = 3;
    /** Energía almacenada: ocupa dos ranuras ({@link ContainerDataInts}). */
    public static final int DATA_ENERGY = 4;
    public static final int DATA_COUNT = 4 + ContainerDataInts.SLOTS;

    /** Lo pone el cliente (ImagFusorClient) para el sonido en bucle; en el servidor no hace nada. */
    public static Consumer<ImagFusorBlockEntity> clientTickHook = be -> {
    };

    private final ItemStackHandler items = new ItemStackHandler(SLOT_COUNT) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isValidForSlot(level, slot, stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    private final FluidTank tank = new FluidTank(TANK_CAPACITY, ImagFusorBlockEntity::isPhaseLiquid) {
        @Override
        protected void onContentsChanged() {
            setChanged();
        }
    };

    private final ModEnergyStorage energy = ModEnergyStorage.receiver(ENERGY_CAPACITY, ENERGY_MAX_RECEIVE,
            this::setChanged);

    private final IFluidHandler fillOnlyTank = new FillOnlyFluidHandler(tank);

    private int progress;
    private int maxProgress;
    private int needed;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_PROGRESS -> progress;
                case DATA_MAX_PROGRESS -> maxProgress;
                case DATA_TANK -> tank.getFluidAmount();
                case DATA_NEEDED -> needed;
                case DATA_ENERGY, DATA_ENERGY + 1 ->
                    ContainerDataInts.part(energy.getEnergyStored(), index - DATA_ENERGY);
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            // Solo el servidor escribe estos valores; el cliente usa su propia copia (SimpleContainerData).
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public ImagFusorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.IMAG_FUSOR.get(), pos, state);
    }

    public static boolean isPhaseLiquid(FluidStack stack) {
        return stack.getFluid().isSame(ModFluids.PHASE_LIQUID.get());
    }

    /** Un recipiente lleno de líquido de fase (unidad de materia llena, cubo, o el de otro mod). */
    public static boolean isPhaseContainer(ItemStack stack) {
        return FluidUtil.getFluidContained(stack).map(ImagFusorBlockEntity::isPhaseLiquid).orElse(false);
    }

    /** Qué admite cada ranura (lo usa también la copia del cliente del menú). */
    public static boolean isValidForSlot(@Nullable Level level, int slot, ItemStack stack) {
        return switch (slot) {
            case SLOT_INPUT -> level == null || findRecipe(level, stack).isPresent();
            case SLOT_UNIT_IN -> isPhaseContainer(stack);
            // Cualquier ítem FE (energy.md, decisión 3); serverTick lo descarga al buffer.
            case SLOT_BATTERY -> BatterySlot.isEnergyItem(stack);
            default -> false; // salidas: solo las llena la máquina
        };
    }

    public static Optional<RecipeHolder<ImagFusorRecipe>> findRecipe(Level level, ItemStack stack) {
        if (stack.isEmpty()) {
            return Optional.empty();
        }
        return level.getRecipeManager().getRecipeFor(ModRecipes.IMAG_FUSOR.get(), new SingleRecipeInput(stack), level);
    }

    // --- Tick ---

    public static void serverTick(Level level, BlockPos pos, BlockState state, ImagFusorBlockEntity be) {
        be.drainContainer();
        BatterySlot.dischargeItem(be.items.getStackInSlot(SLOT_BATTERY), be.energy, Integer.MAX_VALUE);
        boolean working = be.process();
        if (state.getValue(ImagFusorBlock.WORKING) != working) {
            level.setBlock(pos, state.setValue(ImagFusorBlock.WORKING, working), Block.UPDATE_ALL);
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, ImagFusorBlockEntity be) {
        clientTickHook.accept(be);
    }

    /** Vacía un recipiente por tick de la ranura de unidades llenas al depósito (todo o nada). */
    private void drainContainer() {
        ItemStack full = items.getStackInSlot(SLOT_UNIT_IN);
        if (full.isEmpty() || tank.getSpace() <= 0) {
            return;
        }
        ItemStack one = full.copyWithCount(1);
        FluidActionResult simulated = FluidUtil.tryEmptyContainer(one, tank, tank.getSpace(), null, false);
        if (!simulated.isSuccess() || !fits(SLOT_UNIT_OUT, simulated.getResult())) {
            return;
        }
        FluidActionResult result = FluidUtil.tryEmptyContainer(one, tank, tank.getSpace(), null, true);
        if (!result.isSuccess()) {
            return;
        }
        full.shrink(1);
        items.setStackInSlot(SLOT_UNIT_IN, full);
        insertInternal(SLOT_UNIT_OUT, result.getResult());
    }

    /** @return true si la máquina está trabajando este tick */
    private boolean process() {
        ItemStack input = items.getStackInSlot(SLOT_INPUT);
        Optional<RecipeHolder<ImagFusorRecipe>> holder = findRecipe(level, input);
        if (holder.isEmpty()) {
            reset();
            return false;
        }
        ImagFusorRecipe recipe = holder.get().value();
        needed = recipe.liquid();
        maxProgress = recipe.time();
        ItemStack result = recipe.assemble(new SingleRecipeInput(input), level.registryAccess());
        if (tank.getFluidAmount() < recipe.liquid() || !fits(SLOT_OUTPUT, result)) {
            progress = 0;
            return false;
        }
        if (RailgunConfig.energyRequired() && !energy.tryConsume(recipe.energyPerTick())) {
            // Sin la energía del tick se pierde el progreso (decisión del usuario, igual que el original).
            if (progress != 0) {
                progress = 0;
                setChanged();
            }
            return false;
        }
        progress++;
        if (progress >= recipe.time()) {
            input.shrink(1);
            items.setStackInSlot(SLOT_INPUT, input);
            tank.drain(recipe.liquid(), IFluidHandler.FluidAction.EXECUTE);
            insertInternal(SLOT_OUTPUT, result);
            progress = 0;
        }
        setChanged();
        return true;
    }

    private void reset() {
        if (progress != 0) {
            setChanged();
        }
        progress = 0;
        maxProgress = 0;
        needed = 0;
    }

    private boolean fits(int slot, ItemStack stack) {
        if (stack.isEmpty()) {
            return true;
        }
        ItemStack current = items.getStackInSlot(slot);
        if (current.isEmpty()) {
            return true;
        }
        return ItemStack.isSameItemSameComponents(current, stack)
                && current.getCount() + stack.getCount() <= Math.min(current.getMaxStackSize(), items.getSlotLimit(slot));
    }

    private void insertInternal(int slot, ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        ItemStack current = items.getStackInSlot(slot);
        if (current.isEmpty()) {
            items.setStackInSlot(slot, stack.copy());
        } else {
            current.grow(stack.getCount());
            items.setStackInSlot(slot, current);
        }
    }

    // --- Acceso ---

    public ItemStackHandler getItems() {
        return items;
    }

    public FluidTank getTank() {
        return tank;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ContainerData getData() {
        return data;
    }

    public boolean isWorking() {
        return getBlockState().getValue(ImagFusorBlock.WORKING);
    }

    /** Capacidad de fluido para tuberías: solo admite llenar con líquido de fase. */
    public IFluidHandler getFluidHandler(@Nullable Direction side) {
        return fillOnlyTank;
    }

    /** Capacidad de ítems por cara: arriba = entrada, lados = unidades, abajo = salida. */
    public IItemHandler getItemHandler(@Nullable Direction side) {
        return new SidedItemHandler(items, side);
    }

    public void dropContents(Level level, BlockPos pos) {
        for (int i = 0; i < SLOT_COUNT; i++) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(i));
        }
    }

    // --- Guardado ---

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.put("Tank", tank.writeToNBT(registries, new CompoundTag()));
        tag.putInt("Progress", progress);
        energy.save(tag, "Energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        tank.readFromNBT(registries, tag.getCompound("Tank"));
        progress = tag.getInt("Progress");
        energy.load(tag, "Energy", registries);
    }

    // --- Menú ---

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.imag_fusor");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new ImagFusorMenu(containerId, inventory, this);
    }

    /** Envoltorio del depósito: llenar sí, vaciar nunca (como el original, el líquido solo se gasta fundiendo). */
    record FillOnlyFluidHandler(FluidTank tank) implements IFluidHandler {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int index) {
            return tank.getFluidInTank(index);
        }

        @Override
        public int getTankCapacity(int index) {
            return tank.getTankCapacity(index);
        }

        @Override
        public boolean isFluidValid(int index, FluidStack stack) {
            return tank.isFluidValid(index, stack);
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            return tank.fill(resource, action);
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            return FluidStack.EMPTY;
        }
    }

    /**
     * Vista de las ranuras para tolvas y tuberías de ítems. Arriba: solo meter en la entrada. Lados: meter unidades
     * llenas y sacar las vacías. Abajo: sacar el resultado. Sin cara (null): meter en entrada/unidades y sacar salidas.
     */
    private record SidedItemHandler(ItemStackHandler items, @Nullable Direction side) implements IItemHandler {
        private boolean canInsert(int slot) {
            if (side == null) {
                return slot == SLOT_INPUT || slot == SLOT_UNIT_IN;
            }
            return switch (side) {
                case UP -> slot == SLOT_INPUT;
                case DOWN -> false;
                default -> slot == SLOT_UNIT_IN;
            };
        }

        private boolean canExtract(int slot) {
            if (side == null) {
                return slot == SLOT_OUTPUT || slot == SLOT_UNIT_OUT;
            }
            return switch (side) {
                case UP -> false;
                case DOWN -> slot == SLOT_OUTPUT;
                default -> slot == SLOT_UNIT_OUT;
            };
        }

        @Override
        public int getSlots() {
            return items.getSlots();
        }

        @Override
        public ItemStack getStackInSlot(int slot) {
            return items.getStackInSlot(slot);
        }

        @Override
        public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            return canInsert(slot) ? items.insertItem(slot, stack, simulate) : stack;
        }

        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return canExtract(slot) ? items.extractItem(slot, amount, simulate) : ItemStack.EMPTY;
        }

        @Override
        public int getSlotLimit(int slot) {
            return items.getSlotLimit(slot);
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return canInsert(slot) && items.isItemValid(slot, stack);
        }
    }
}
