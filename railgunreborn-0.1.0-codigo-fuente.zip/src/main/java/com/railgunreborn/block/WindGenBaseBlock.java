package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * Base del generador eólico ({@code windgen_base}): 2 bloques de alto como en el original. La mitad de abajo es el
 * controlador (BlockEntity con el buffer, la ranura de batería y la pantalla) y lleva el modelo OBJ; la de arriba es
 * invisible y sólida. Los pilares van encima de la mitad de arriba. {@code COMPLETE} cambia la textura (la del
 * original se apaga si la estructura no está completa).
 */
public class WindGenBaseBlock extends BaseEntityBlock implements WindGenBlockItem.PartPlacer {
    public static final MapCodec<WindGenBaseBlock> CODEC = simpleCodec(WindGenBaseBlock::new);
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;
    public static final BooleanProperty COMPLETE = BooleanProperty.create("complete");

    public WindGenBaseBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(HALF, DoubleBlockHalf.LOWER).setValue(COMPLETE, false));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HALF, COMPLETE);
    }

    public static boolean isController(BlockState state) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER;
    }

    /** Posición del controlador (mitad de abajo) a partir de cualquiera de las dos mitades. */
    public static BlockPos originOf(BlockPos pos, BlockState state) {
        return isController(state) ? pos : pos.below();
    }

    @Nullable
    public static WindGenBaseBlockEntity originEntity(Level level, BlockPos pos, BlockState state) {
        return level.getBlockEntity(originOf(pos, state)) instanceof WindGenBaseBlockEntity be ? be : null;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return isController(state) ? new WindGenBaseBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide || !isController(state) ? null
                : createTickerHelper(type, ModBlockEntities.WINDGEN_BASE.get(), WindGenBaseBlockEntity::serverTick);
    }

    // --- Colocación / rotura ---

    /** Null (no se pone nada) si la mitad de arriba no cabe. */
    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos top = context.getClickedPos().above();
        if (level.isOutsideBuildHeight(top) || !level.getBlockState(top).canBeReplaced(context)
                || !level.isUnobstructed(defaultBlockState(), top, CollisionContext.empty())) {
            return null;
        }
        return defaultBlockState();
    }

    @Override
    public void placeParts(Level level, BlockPos origin, BlockState controller) {
        place(level, origin);
    }

    /** Pone las dos mitades sin comprobar nada (lo usan el ítem y los tests). */
    public void place(Level level, BlockPos origin) {
        level.setBlock(origin, defaultBlockState(), Block.UPDATE_ALL);
        level.setBlock(origin.above(), defaultBlockState().setValue(HALF, DoubleBlockHalf.UPPER), Block.UPDATE_ALL);
    }

    /** La otra mitad desaparece sin soltar nada; el ítem cae solo de la mitad rota (loot table). */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            if (level.getBlockEntity(pos) instanceof WindGenBaseBlockEntity be) {
                be.dropContents(level, pos);
            }
            BlockPos other = isController(state) ? pos.above() : pos.below();
            BlockState otherState = level.getBlockState(other);
            if (otherState.is(this) && otherState.getValue(HALF) != state.getValue(HALF)) {
                level.setBlock(other, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS | Block.UPDATE_KNOWN_SHAPE);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    // --- Uso ---

    /** Con un pilar en la mano se coloca el pilar (como el original) en vez de abrir la pantalla. */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
            Player player, InteractionHand hand, BlockHitResult hit) {
        if (stack.is(ModItems.WINDGEN_PILLAR.get())) {
            return ItemInteractionResult.SKIP_DEFAULT_BLOCK_INTERACTION;
        }
        return super.useItemOn(stack, state, level, pos, player, hand, hit);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        WindGenBaseBlockEntity be = originEntity(level, pos, state);
        if (player instanceof ServerPlayer serverPlayer && be != null) {
            serverPlayer.openMenu(be, be.getBlockPos());
        }
        return InteractionResult.CONSUME;
    }

    // --- Render ---

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return isController(state) ? RenderShape.MODEL : RenderShape.INVISIBLE;
    }
}
