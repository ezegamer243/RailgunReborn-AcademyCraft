package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * Cabeza del generador eólico ({@code windgen_main}): 3 bloques en fila horizontal como en el original. La parte 0
 * (centro) va encima del último pilar, tiene la BlockEntity (ranura de las aspas) y dibuja el cuerpo (OBJ); la 1 es
 * la delantera, donde gira el rotor ({@link #FACING} apunta hacia ella); la 2, la cola. Las partes 1 y 2 son
 * invisibles y sólidas. El rotor (aspas de ~7 bloques de radio) gira en el plano vertical de la parte 1.
 */
public class WindGenMainBlock extends BaseEntityBlock implements WindGenBlockItem.PartPlacer {
    public static final MapCodec<WindGenMainBlock> CODEC = simpleCodec(WindGenMainBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 2);
    public static final int PART_CENTER = 0;
    public static final int PART_FRONT = 1;
    public static final int PART_BACK = 2;

    public WindGenMainBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH).setValue(PART, PART_CENTER));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, PART);
    }

    public static boolean isController(BlockState state) {
        return state.getValue(PART) == PART_CENTER;
    }

    /** Posición de la parte {@code part} de una cabeza con el centro en {@code origin}. */
    public static BlockPos partPos(BlockPos origin, Direction facing, int part) {
        return switch (part) {
            case PART_FRONT -> origin.relative(facing);
            case PART_BACK -> origin.relative(facing.getOpposite());
            default -> origin;
        };
    }

    /** Posición del centro a partir de cualquier parte. */
    public static BlockPos originOf(BlockPos pos, BlockState state) {
        Direction facing = state.getValue(FACING);
        return switch (state.getValue(PART)) {
            case PART_FRONT -> pos.relative(facing.getOpposite());
            case PART_BACK -> pos.relative(facing);
            default -> pos;
        };
    }

    @Nullable
    public static WindGenMainBlockEntity originEntity(Level level, BlockPos pos, BlockState state) {
        return level.getBlockEntity(originOf(pos, state)) instanceof WindGenMainBlockEntity be ? be : null;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return isController(state) ? new WindGenMainBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide || !isController(state) ? null
                : createTickerHelper(type, ModBlockEntities.WINDGEN_MAIN.get(), WindGenMainBlockEntity::serverTick);
    }

    // --- Colocación / rotura ---

    /** El rotor mira al jugador que la coloca. Null si la parte delantera o la cola no caben. */
    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos origin = context.getClickedPos();
        Direction facing = context.getHorizontalDirection().getOpposite();
        for (int part = PART_FRONT; part <= PART_BACK; part++) {
            BlockPos pos = partPos(origin, facing, part);
            if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)
                    || !level.getBlockState(pos).canBeReplaced(context)
                    || !level.isUnobstructed(defaultBlockState(), pos, CollisionContext.empty())) {
                return null;
            }
        }
        return defaultBlockState().setValue(FACING, facing);
    }

    @Override
    public void placeParts(Level level, BlockPos origin, BlockState controller) {
        place(level, origin, controller.getValue(FACING));
    }

    /** Pone las 3 partes sin comprobar nada (lo usan el ítem y los tests). */
    public void place(Level level, BlockPos origin, Direction facing) {
        for (int part = PART_CENTER; part <= PART_BACK; part++) {
            level.setBlock(partPos(origin, facing, part),
                    defaultBlockState().setValue(FACING, facing).setValue(PART, part), Block.UPDATE_ALL);
        }
    }

    /** Si una parte desaparece (rotura, explosión, comando), las otras también; las aspas caen al suelo. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            if (level.getBlockEntity(pos) instanceof WindGenMainBlockEntity be) {
                be.dropContents(level, pos);
            }
            Direction facing = state.getValue(FACING);
            BlockPos origin = originOf(pos, state);
            for (int part = PART_CENTER; part <= PART_BACK; part++) {
                BlockPos other = partPos(origin, facing, part);
                BlockState otherState = level.getBlockState(other);
                if (!other.equals(pos) && otherState.is(this) && otherState.getValue(FACING) == facing
                        && otherState.getValue(PART) == part) {
                    level.setBlock(other, Blocks.AIR.defaultBlockState(),
                            Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS | Block.UPDATE_KNOWN_SHAPE);
                }
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    // --- Uso ---

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        WindGenMainBlockEntity be = originEntity(level, pos, state);
        if (player instanceof ServerPlayer serverPlayer && be != null) {
            serverPlayer.openMenu(be, be.getBlockPos());
        }
        return InteractionResult.CONSUME;
    }

    // --- Render ---

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return isController(state) ? RenderShape.MODEL : RenderShape.INVISIBLE;
    }
}
