package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** Cat Engine: solo creativo (sin receta). Sin modelo: lo dibuja {@code CatEngineRenderer} (gato flotando). */
public class CatEngineBlock extends BaseEntityBlock {
    public static final MapCodec<CatEngineBlock> CODEC = simpleCodec(CatEngineBlock::new);

    public CatEngineBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CatEngineBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : createTickerHelper(type, ModBlockEntities.CAT_ENGINE.get(), CatEngineBlockEntity::serverTick);
    }
}
