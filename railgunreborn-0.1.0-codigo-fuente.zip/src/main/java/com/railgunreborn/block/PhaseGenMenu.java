package com.railgunreborn.block;

import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModMenus;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/** Menú del generador de fase: unidad llena, unidad vacía, batería e inventario. Depósito y energía por ContainerData. */
public class PhaseGenMenu extends AbstractContainerMenu {
    public static final int UNIT_IN_X = 44;
    public static final int UNIT_OUT_X = 116;
    public static final int BATTERY_X = 80;
    public static final int SLOTS_Y = 80;

    private static final int MACHINE_SLOTS = PhaseGenBlockEntity.SLOT_COUNT;
    private static final int INV_START = MACHINE_SLOTS;
    private static final int INV_END = INV_START + 36;

    private final ContainerLevelAccess access;
    private final ContainerData data;

    public PhaseGenMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, clientItems(), new SimpleContainerData(PhaseGenBlockEntity.DATA_COUNT),
                ContainerLevelAccess.create(inventory.player.level(), buf.readBlockPos()));
    }

    public PhaseGenMenu(int containerId, Inventory inventory, PhaseGenBlockEntity be) {
        this(containerId, inventory, be.getItems(), be.getData(),
                ContainerLevelAccess.create(be.getLevel(), be.getBlockPos()));
    }

    private PhaseGenMenu(int containerId, Inventory inventory, IItemHandler items, ContainerData data,
            ContainerLevelAccess access) {
        super(ModMenus.PHASE_GEN.get(), containerId);
        this.access = access;
        this.data = data;
        addSlot(new SlotItemHandler(items, PhaseGenBlockEntity.SLOT_UNIT_IN, UNIT_IN_X, SLOTS_Y));
        addSlot(new SlotItemHandler(items, PhaseGenBlockEntity.SLOT_UNIT_OUT, UNIT_OUT_X, SLOTS_Y));
        addSlot(new SlotItemHandler(items, PhaseGenBlockEntity.SLOT_BATTERY, BATTERY_X, SLOTS_Y));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, TechUiLayout.playerSlotX(col),
                        TechUiLayout.playerSlotY(row)));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, TechUiLayout.playerSlotX(col), TechUiLayout.playerSlotY(3)));
        }
        addDataSlots(data);
    }

    private static ItemStackHandler clientItems() {
        return new ItemStackHandler(MACHINE_SLOTS) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return PhaseGenBlockEntity.isValidForSlot(slot, stack);
            }
        };
    }

    public int getTankAmount() {
        return data.get(PhaseGenBlockEntity.DATA_TANK);
    }

    public int getOutput() {
        return data.get(PhaseGenBlockEntity.DATA_OUTPUT);
    }

    public int getEnergy() {
        return data.get(PhaseGenBlockEntity.DATA_ENERGY);
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.PHASE_GEN.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < MACHINE_SLOTS) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) {
                return ItemStack.EMPTY;
            }
        } else if (ImagFusorBlockEntity.isPhaseContainer(stack)) {
            if (!moveItemStackTo(stack, PhaseGenBlockEntity.SLOT_UNIT_IN, PhaseGenBlockEntity.SLOT_UNIT_IN + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (BatterySlot.isEnergyItem(stack)) {
            if (!moveItemStackTo(stack, PhaseGenBlockEntity.SLOT_BATTERY, PhaseGenBlockEntity.SLOT_BATTERY + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (index < INV_END - 9) {
            if (!moveItemStackTo(stack, INV_END - 9, INV_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, INV_START, INV_END - 9, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }
}
