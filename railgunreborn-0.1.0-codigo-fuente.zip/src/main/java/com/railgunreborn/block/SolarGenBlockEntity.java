package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.EnergyPush;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Generador solar (energy.md 1.3): 3 IF/tick de día con cielo abierto encima, x0,2 con lluvia, nada de noche o tapado,
 * por {@code generatorMultiplier}. Buffer 1000, ancho de banda 100. Carga el ítem de su ranura y empuja a los vecinos.
 *
 * <p>Red inalámbrica (T103): un nodo enlazado saca energía de este mismo buffer por la capacidad FE
 * ({@link #getEnergy()}, hasta el ancho de banda), así que el generador no necesita código propio.
 */
public class SolarGenBlockEntity extends BlockEntity implements MenuProvider {
    public static final int CAPACITY = 1000;
    public static final int BANDWIDTH = 100;
    public static final double BASE_OUTPUT = 3.0;
    public static final double RAIN_FACTOR = 0.2;
    /** El día del original: del tick 0 al 12500 del ciclo de 24000. */
    public static final long DAY_END = 12500;

    public static final int SLOT_BATTERY = 0;

    public static final int DATA_ENERGY = 0;
    public static final int DATA_STATUS = 1;
    public static final int DATA_COUNT = 2;

    /** Estado mostrado en la pantalla; el orden es el de {@code ContainerData}. */
    public enum Status {
        DAY, RAIN, NIGHT, BLOCKED
    }

    private final ModEnergyStorage energy = ModEnergyStorage.provider(CAPACITY, BANDWIDTH, this::setChanged);

    private final ItemStackHandler items = new ItemStackHandler(1) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return BatterySlot.isEnergyItem(stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    private Status status = Status.NIGHT;
    /** Parte fraccionaria de lo generado (con lluvia salen 0,6 por tick): se acumula para no perderla. */
    private double carry;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_ENERGY -> energy.getEnergyStored();
                case DATA_STATUS -> status.ordinal();
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public SolarGenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SOLAR_GEN.get(), pos, state);
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public ContainerData getData() {
        return data;
    }

    public Status getStatus() {
        return status;
    }

    public static Status computeStatus(Level level, BlockPos pos) {
        if (level.getDayTime() % 24000L >= DAY_END) {
            return Status.NIGHT;
        }
        if (!skyOpen(level, pos)) {
            return Status.BLOCKED;
        }
        return level.isRaining() ? Status.RAIN : Status.DAY;
    }

    /**
     * Cielo abierto encima. No usa {@code canSeeSky} (depende del motor de luz, asíncrono: un bloque recién puesto
     * tarda en notarse): mira el mapa de alturas y recorre solo la columna hasta ahí buscando algo que tape.
     */
    private static boolean skyOpen(Level level, BlockPos pos) {
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, pos.getX(), pos.getZ());
        BlockPos.MutableBlockPos cursor = pos.above().mutable();
        for (int y = pos.getY() + 1; y < top; y++) {
            cursor.setY(y);
            BlockState state = level.getBlockState(cursor);
            if (state.blocksMotion() || state.getLightBlock(level, cursor) > 0) {
                return false;
            }
        }
        return true;
    }

    public static double outputPerTick(Status status) {
        double base = BASE_OUTPUT * RailgunConfig.generatorMultiplier();
        return switch (status) {
            case DAY -> base;
            case RAIN -> base * RAIN_FACTOR;
            default -> 0.0;
        };
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, SolarGenBlockEntity be) {
        be.status = computeStatus(level, pos);
        be.carry += outputPerTick(be.status);
        int whole = (int) be.carry;
        if (whole > 0) {
            be.carry -= whole;
            be.energy.addEnergy(whole, false);
        }
        BatterySlot.chargeItem(be.items.getStackInSlot(SLOT_BATTERY), be.energy, BANDWIDTH);
        EnergyPush.toNeighbors(level, pos, be.energy, BANDWIDTH);
    }

    public void dropContents(Level level, BlockPos pos) {
        Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(SLOT_BATTERY));
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        energy.save(tag, "Energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        energy.load(tag, "Energy", registries);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.solar_gen");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new SolarGenMenu(containerId, inventory, this);
    }
}
