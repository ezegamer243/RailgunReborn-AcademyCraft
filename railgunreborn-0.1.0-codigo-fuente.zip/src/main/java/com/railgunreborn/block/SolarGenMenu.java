package com.railgunreborn.block;

import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModMenus;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/** Menú del generador solar: una ranura de batería (que se carga) y el inventario. Energía y estado por ContainerData. */
public class SolarGenMenu extends AbstractContainerMenu {
    public static final int BATTERY_X = 80;
    public static final int BATTERY_Y = 66;

    private static final int INV_START = 1;
    private static final int INV_END = INV_START + 36;

    private final ContainerLevelAccess access;
    private final ContainerData data;

    public SolarGenMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, clientItems(), new SimpleContainerData(SolarGenBlockEntity.DATA_COUNT),
                ContainerLevelAccess.create(inventory.player.level(), buf.readBlockPos()));
    }

    public SolarGenMenu(int containerId, Inventory inventory, SolarGenBlockEntity be) {
        this(containerId, inventory, be.getItems(), be.getData(),
                ContainerLevelAccess.create(be.getLevel(), be.getBlockPos()));
    }

    private SolarGenMenu(int containerId, Inventory inventory, IItemHandler items, ContainerData data,
            ContainerLevelAccess access) {
        super(ModMenus.SOLAR_GEN.get(), containerId);
        this.access = access;
        this.data = data;
        addSlot(new SlotItemHandler(items, SolarGenBlockEntity.SLOT_BATTERY, BATTERY_X, BATTERY_Y));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, TechUiLayout.playerSlotX(col),
                        TechUiLayout.playerSlotY(row)));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, TechUiLayout.playerSlotX(col), TechUiLayout.playerSlotY(3)));
        }
        addDataSlots(data);
    }

    private static ItemStackHandler clientItems() {
        return new ItemStackHandler(1) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return BatterySlot.isEnergyItem(stack);
            }
        };
    }

    public int getEnergy() {
        return data.get(SolarGenBlockEntity.DATA_ENERGY);
    }

    public SolarGenBlockEntity.Status getStatus() {
        int i = data.get(SolarGenBlockEntity.DATA_STATUS);
        SolarGenBlockEntity.Status[] all = SolarGenBlockEntity.Status.values();
        return all[Math.max(0, Math.min(all.length - 1, i))];
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.SOLAR_GEN.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < INV_START) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) {
                return ItemStack.EMPTY;
            }
        } else if (BatterySlot.isEnergyItem(stack)) {
            if (!moveItemStackTo(stack, 0, 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (index < INV_END - 9) {
            if (!moveItemStackTo(stack, INV_END - 9, INV_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, INV_START, INV_END - 9, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }
}
