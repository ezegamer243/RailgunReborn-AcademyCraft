package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.EnergyPush;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidActionResult;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Generador de fase (energy.md 1.3): quema hasta {@link #MAX_BURN_PER_TICK} mB de líquido de fase por tick a 0,5 IF
 * por mB (50 IF/tick máximo), por {@code generatorMultiplier}. Depósito de 8000 mB, buffer de {@link #CAPACITY} IF,
 * ancho de banda 50. El líquido entra por la ranura de unidad llena (la unidad vacía sale por la otra) o por tubería.
 * No quema si el buffer no tiene sitio para lo generado: así nunca se desperdicia líquido.
 *
 * <p>Red inalámbrica (T103): un nodo enlazado saca energía de este mismo buffer por la capacidad FE
 * ({@link #getEnergy()}, hasta el ancho de banda), así que el generador no necesita código propio.
 */
public class PhaseGenBlockEntity extends BlockEntity implements MenuProvider {
    public static final int CAPACITY = 6000;
    public static final int BANDWIDTH = 50;
    public static final int TANK_CAPACITY = 8000;
    public static final int MAX_BURN_PER_TICK = 100;
    public static final double IF_PER_MB = 0.5;

    public static final int SLOT_UNIT_IN = 0;
    public static final int SLOT_UNIT_OUT = 1;
    public static final int SLOT_BATTERY = 2;
    public static final int SLOT_COUNT = 3;

    public static final int DATA_TANK = 0;
    /** IF generados en el último tick (para la pantalla). */
    public static final int DATA_OUTPUT = 1;
    public static final int DATA_ENERGY = 2;
    public static final int DATA_COUNT = 3;

    private final ModEnergyStorage energy = ModEnergyStorage.provider(CAPACITY, BANDWIDTH, this::setChanged);

    private final ItemStackHandler items = new ItemStackHandler(SLOT_COUNT) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isValidForSlot(slot, stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    private final FluidTank tank = new FluidTank(TANK_CAPACITY, ImagFusorBlockEntity::isPhaseLiquid) {
        @Override
        protected void onContentsChanged() {
            setChanged();
        }
    };

    private final IFluidHandler fillOnlyTank = new ImagFusorBlockEntity.FillOnlyFluidHandler(tank);

    /** Parte fraccionaria de lo generado (con multiplicadores raros salen decimales): se acumula para no perderla. */
    private double carry;
    private int lastOutput;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_TANK -> tank.getFluidAmount();
                case DATA_OUTPUT -> lastOutput;
                case DATA_ENERGY -> energy.getEnergyStored();
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public PhaseGenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PHASE_GEN.get(), pos, state);
    }

    /** Qué admite cada ranura (lo usa también la copia del cliente del menú). */
    public static boolean isValidForSlot(int slot, ItemStack stack) {
        return switch (slot) {
            case SLOT_UNIT_IN -> ImagFusorBlockEntity.isPhaseContainer(stack);
            case SLOT_BATTERY -> BatterySlot.isEnergyItem(stack);
            default -> false; // la salida solo la llena la máquina
        };
    }

    // --- Tick ---

    public static void serverTick(Level level, BlockPos pos, BlockState state, PhaseGenBlockEntity be) {
        be.drainContainer();
        be.burn();
        BatterySlot.chargeItem(be.items.getStackInSlot(SLOT_BATTERY), be.energy, BANDWIDTH);
        EnergyPush.toNeighbors(level, pos, be.energy, BANDWIDTH);
        int fillLevel = levelFor(be.tank.getFluidAmount());
        if (state.getValue(PhaseGenBlock.LEVEL) != fillLevel) {
            level.setBlock(pos, state.setValue(PhaseGenBlock.LEVEL, fillLevel), Block.UPDATE_CLIENTS);
        }
    }

    /** Nivel visual 0-4 del depósito (cualquier cantidad distinta de cero marca al menos 1). */
    public static int levelFor(int amount) {
        return (amount * 4 + TANK_CAPACITY - 1) / TANK_CAPACITY;
    }

    private void burn() {
        lastOutput = 0;
        double rate = IF_PER_MB * RailgunConfig.generatorMultiplier();
        int amount = tank.getFluidAmount();
        if (rate <= 0 || amount <= 0 || energy.getSpace() <= 0) {
            return;
        }
        // Tope de mB que caben: lo generado (con lo acumulado) tiene que entrar entero en el buffer.
        int byRoom = (int) Math.floor((energy.getSpace() + 1.0 - carry - 1e-6) / rate);
        int mb = Math.min(Math.min(MAX_BURN_PER_TICK, amount), byRoom);
        if (mb <= 0) {
            return;
        }
        tank.drain(mb, IFluidHandler.FluidAction.EXECUTE);
        carry += mb * rate;
        int whole = (int) carry;
        carry -= whole;
        energy.addEnergy(whole, false);
        lastOutput = whole;
        setChanged();
    }

    /** Vacía un recipiente por tick de la ranura de unidades llenas al depósito (todo o nada). */
    private void drainContainer() {
        ItemStack full = items.getStackInSlot(SLOT_UNIT_IN);
        if (full.isEmpty() || tank.getSpace() <= 0) {
            return;
        }
        ItemStack one = full.copyWithCount(1);
        FluidActionResult simulated = FluidUtil.tryEmptyContainer(one, tank, tank.getSpace(), null, false);
        if (!simulated.isSuccess() || !fitsOut(simulated.getResult())) {
            return;
        }
        FluidActionResult result = FluidUtil.tryEmptyContainer(one, tank, tank.getSpace(), null, true);
        if (!result.isSuccess()) {
            return;
        }
        full.shrink(1);
        items.setStackInSlot(SLOT_UNIT_IN, full);
        ItemStack out = result.getResult();
        if (!out.isEmpty()) {
            ItemStack current = items.getStackInSlot(SLOT_UNIT_OUT);
            if (current.isEmpty()) {
                items.setStackInSlot(SLOT_UNIT_OUT, out.copy());
            } else {
                current.grow(out.getCount());
                items.setStackInSlot(SLOT_UNIT_OUT, current);
            }
        }
    }

    private boolean fitsOut(ItemStack stack) {
        if (stack.isEmpty()) {
            return true;
        }
        ItemStack current = items.getStackInSlot(SLOT_UNIT_OUT);
        return current.isEmpty() || ItemStack.isSameItemSameComponents(current, stack)
                && current.getCount() + stack.getCount() <= Math.min(current.getMaxStackSize(), items.getSlotLimit(SLOT_UNIT_OUT));
    }

    // --- Acceso ---

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public FluidTank getTank() {
        return tank;
    }

    public ContainerData getData() {
        return data;
    }

    /** Capacidad de fluido para tuberías: solo admite llenar con líquido de fase. */
    public IFluidHandler getFluidHandler(@Nullable Direction side) {
        return fillOnlyTank;
    }

    public void dropContents(Level level, BlockPos pos) {
        for (int i = 0; i < SLOT_COUNT; i++) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(i));
        }
    }

    // --- Guardado ---

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.put("Tank", tank.writeToNBT(registries, new CompoundTag()));
        tag.putDouble("Carry", carry);
        energy.save(tag, "Energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        tank.readFromNBT(registries, tag.getCompound("Tank"));
        carry = tag.getDouble("Carry");
        energy.load(tag, "Energy", registries);
    }

    // --- Menú ---

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.phase_gen");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new PhaseGenMenu(containerId, inventory, this);
    }
}
