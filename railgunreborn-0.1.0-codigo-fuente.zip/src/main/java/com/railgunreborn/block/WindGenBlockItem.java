package com.railgunreborn.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Ítem de las piezas multibloque del generador eólico (base y cabeza): al colocar pone todas sus partes. */
public class WindGenBlockItem extends BlockItem {
    /** Bloque que sabe poner sus partes a partir del estado del controlador (ya validado al colocar). */
    public interface PartPlacer {
        void placeParts(Level level, BlockPos origin, BlockState controller);
    }

    public <B extends Block & PartPlacer> WindGenBlockItem(B block, Properties properties) {
        super(block, properties);
    }

    @Override
    protected boolean placeBlock(BlockPlaceContext context, BlockState state) {
        ((PartPlacer) getBlock()).placeParts(context.getLevel(), context.getClickedPos(), state);
        return true;
    }
}
