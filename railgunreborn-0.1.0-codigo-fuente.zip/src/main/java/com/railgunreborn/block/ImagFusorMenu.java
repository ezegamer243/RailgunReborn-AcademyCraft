package com.railgunreborn.block;

import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModMenus;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Menú del Imag Fusor (pantalla de 176x187). Las ranuras van centradas en las cajas del arte del original
 * ({@link TechUiLayout}). Progreso, depósito y líquido necesario van por {@link ContainerData} (vanilla).
 */
public class ImagFusorMenu extends AbstractContainerMenu {
    private static final int MACHINE_SLOTS = ImagFusorBlockEntity.SLOT_COUNT;
    private static final int INV_START = MACHINE_SLOTS;
    private static final int INV_END = INV_START + 36;

    private final ContainerLevelAccess access;
    private final ContainerData data;

    /** Cliente: el servidor manda la posición del bloque. */
    public ImagFusorMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, clientItems(inventory),
                new SimpleContainerData(ImagFusorBlockEntity.DATA_COUNT), readAccess(inventory, buf));
    }

    /** Servidor. */
    public ImagFusorMenu(int containerId, Inventory inventory, ImagFusorBlockEntity be) {
        this(containerId, inventory, be.getItems(), be.getData(),
                ContainerLevelAccess.create(be.getLevel(), be.getBlockPos()));
    }

    private ImagFusorMenu(int containerId, Inventory inventory, IItemHandler items, ContainerData data,
            ContainerLevelAccess access) {
        super(ModMenus.IMAG_FUSOR.get(), containerId);
        this.access = access;
        this.data = data;
        addSlot(new SlotItemHandler(items, ImagFusorBlockEntity.SLOT_INPUT,
                TechUiLayout.INPUT_X, TechUiLayout.INPUT_Y));
        addSlot(new SlotItemHandler(items, ImagFusorBlockEntity.SLOT_OUTPUT,
                TechUiLayout.OUTPUT_X, TechUiLayout.OUTPUT_Y));
        addSlot(new SlotItemHandler(items, ImagFusorBlockEntity.SLOT_UNIT_IN,
                TechUiLayout.UNIT_IN_X, TechUiLayout.UNIT_IN_Y));
        addSlot(new SlotItemHandler(items, ImagFusorBlockEntity.SLOT_BATTERY,
                TechUiLayout.BATTERY_X, TechUiLayout.BATTERY_Y));
        addSlot(new SlotItemHandler(items, ImagFusorBlockEntity.SLOT_UNIT_OUT,
                TechUiLayout.UNIT_OUT_X, TechUiLayout.UNIT_OUT_Y));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, TechUiLayout.playerSlotX(col),
                        TechUiLayout.playerSlotY(row)));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, TechUiLayout.playerSlotX(col), TechUiLayout.playerSlotY(3)));
        }
        addDataSlots(data);
    }

    /** Copia del cliente con las mismas reglas por ranura, para que no se puedan "poner" ítems en las salidas. */
    private static ItemStackHandler clientItems(Inventory inventory) {
        return new ItemStackHandler(MACHINE_SLOTS) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return ImagFusorBlockEntity.isValidForSlot(inventory.player.level(), slot, stack);
            }
        };
    }

    private static ContainerLevelAccess readAccess(Inventory inventory, RegistryFriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        return ContainerLevelAccess.create(inventory.player.level(), pos);
    }

    public int getProgress() {
        return data.get(ImagFusorBlockEntity.DATA_PROGRESS);
    }

    public int getMaxProgress() {
        return data.get(ImagFusorBlockEntity.DATA_MAX_PROGRESS);
    }

    public int getTankAmount() {
        return data.get(ImagFusorBlockEntity.DATA_TANK);
    }

    public int getNeeded() {
        return data.get(ImagFusorBlockEntity.DATA_NEEDED);
    }

    public int getEnergy() {
        return ContainerDataInts.get(data, ImagFusorBlockEntity.DATA_ENERGY);
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.IMAG_FUSOR.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < MACHINE_SLOTS) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) {
                return ItemStack.EMPTY;
            }
            slot.onQuickCraft(stack, original);
        } else if (ImagFusorBlockEntity.isPhaseContainer(stack)) {
            if (!moveItemStackTo(stack, ImagFusorBlockEntity.SLOT_UNIT_IN, ImagFusorBlockEntity.SLOT_UNIT_IN + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (BatterySlot.isEnergyItem(stack)) {
            if (!moveItemStackTo(stack, ImagFusorBlockEntity.SLOT_BATTERY, ImagFusorBlockEntity.SLOT_BATTERY + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (ImagFusorBlockEntity.findRecipe(player.level(), stack).isPresent()) {
            if (!moveItemStackTo(stack, ImagFusorBlockEntity.SLOT_INPUT, ImagFusorBlockEntity.SLOT_INPUT + 1, false)) {
                return ItemStack.EMPTY;
            }
        } else if (index < INV_END - 9) {
            if (!moveItemStackTo(stack, INV_END - 9, INV_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, INV_START, INV_END - 9, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }
}
