package com.railgunreborn.block;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;

/** Ítem de los Developer multibloque: al colocar pone las 8 partes (la validación está en el bloque). */
public class DeveloperBlockItem extends BlockItem {
    private final DeveloperBlock developerBlock;

    public DeveloperBlockItem(DeveloperBlock block, Properties properties) {
        super(block, properties);
        this.developerBlock = block;
    }

    @Override
    protected boolean placeBlock(BlockPlaceContext context, BlockState state) {
        developerBlock.place(context.getLevel(), context.getClickedPos(), state.getValue(DeveloperBlock.FACING));
        return true;
    }
}
