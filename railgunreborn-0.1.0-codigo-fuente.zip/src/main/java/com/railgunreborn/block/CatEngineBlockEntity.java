package com.railgunreborn.block;

import com.railgunreborn.energy.EnergyPush;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Cat Engine (energy.md 1.3): generador infinito solo creativo. Cada tick rellena su buffer (2000) y empuja hasta 500
 * IF a los vecinos; por cable otros mods pueden sacar hasta 500 por llamada. Sin GUI ni ranura.
 *
 * <p>Sale 500/tick (decisión del encargo) aunque la ficha dice ancho de banda 200: es un bloque de pruebas.
 * Se enlaza a un nodo inalámbrico como generador por su capacidad FE (T103), sin código propio.
 */
public class CatEngineBlockEntity extends BlockEntity {
    public static final int CAPACITY = 2000;
    public static final int OUTPUT = 500;

    private final ModEnergyStorage energy = ModEnergyStorage.provider(CAPACITY, OUTPUT, () -> {
    });

    public CatEngineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CAT_ENGINE.get(), pos, state);
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, CatEngineBlockEntity be) {
        be.energy.setEnergy(CAPACITY);
        EnergyPush.toNeighbors(level, pos, be.energy, OUTPUT);
    }
}
