package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.ability.develop.DeveloperType;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * Developer normal / avanzado: multibloque de 1 de ancho x 3 de alto x 3 de fondo con 8 partes
 * ({@code developer.md} 1.3). La parte 0 es el controlador: es la única que se dibuja (modelo OBJ en el blockstate);
 * las demás son invisibles pero sólidas.
 *
 * <p>Huella en (alto, fondo) respecto al controlador, con el fondo hacia donde miraba el jugador al colocarlo:
 * <pre>
 *  alto 2   .  X  X
 *  alto 1   X  X  X
 *  alto 0   O  X  X      O = controlador (parte 0)
 *         fondo 0 1 2
 * </pre>
 * Solo la parte 0 tiene BlockEntity (el buffer de energía, {@link DeveloperBlockEntity}); el estado (FACING + PART)
 * basta para encontrar el controlador desde cualquier parte.
 */
public class DeveloperBlock extends Block implements EntityBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 7);

    /** Alto de cada parte (índice = valor de PART). */
    private static final int[] PART_UP = { 0, 1, 0, 1, 2, 0, 1, 2 };
    /** Fondo de cada parte (índice = valor de PART). */
    private static final int[] PART_DEPTH = { 0, 0, 1, 1, 1, 2, 2, 2 };
    public static final int PART_COUNT = PART_UP.length;

    public static final MapCodec<DeveloperBlock> CODEC = RecordCodecBuilder.mapCodec(
            i -> i.group(propertiesCodec(), Codec.STRING.fieldOf("developer_type").forGetter(b -> b.type.name()))
                    .apply(i, (props, name) -> new DeveloperBlock(props, DeveloperType.valueOf(name))));

    private final DeveloperType type;

    public DeveloperBlock(Properties properties, DeveloperType type) {
        super(properties);
        this.type = type;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH).setValue(PART, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    public DeveloperType getDeveloperType() {
        return type;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(PART) == 0 ? new DeveloperBlockEntity(pos, state) : null;
    }

    /** BlockEntity del controlador de la parte {@code pos} (o null si aún no existe). */
    @Nullable
    public static DeveloperBlockEntity originEntity(Level level, BlockPos pos, BlockState state) {
        return level.getBlockEntity(originOf(pos, state)) instanceof DeveloperBlockEntity be ? be : null;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, PART);
    }

    // --- Huella ---

    /** Posición de la parte {@code part} de un multibloque con controlador en {@code origin}. */
    public static BlockPos partPos(BlockPos origin, Direction facing, int part) {
        return origin.above(PART_UP[part]).relative(facing, PART_DEPTH[part]);
    }

    /** Posición del controlador a partir de cualquier parte. */
    public static BlockPos originOf(BlockPos pos, BlockState state) {
        int part = state.getValue(PART);
        return pos.below(PART_UP[part]).relative(state.getValue(FACING).getOpposite(), PART_DEPTH[part]);
    }

    /** Coloca las 8 partes (sin comprobar nada: ver {@link #getStateForPlacement}). */
    public void place(Level level, BlockPos origin, Direction facing) {
        for (int part = 0; part < PART_COUNT; part++) {
            level.setBlock(partPos(origin, facing, part),
                    defaultBlockState().setValue(FACING, facing).setValue(PART, part), Block.UPDATE_ALL);
        }
    }

    // --- Colocación / rotura ---

    /** Null (no se pone nada ni se gasta el ítem) si alguno de los 8 destinos no es reemplazable o está ocupado. */
    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos origin = context.getClickedPos();
        Direction facing = context.getHorizontalDirection();
        for (int part = 0; part < PART_COUNT; part++) {
            BlockPos pos = partPos(origin, facing, part);
            if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
                return null;
            }
            // El destino del controlador ya lo valida BlockItem.place (BlockPlaceContext.canPlace).
            if (part > 0) {
                BlockState existing = level.getBlockState(pos);
                if (!existing.canBeReplaced() || level.getBlockEntity(pos) != null
                        || !level.isUnobstructed(defaultBlockState(), pos, CollisionContext.empty())) {
                    return null;
                }
            }
        }
        return defaultBlockState().setValue(FACING, facing).setValue(PART, 0);
    }

    /** Romper una parte quita las otras 7 sin drops propios; el ítem cae solo de la parte rota (loot table). */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide) {
            removeOthers(level, pos, state);
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    /** También cubre explosiones, comandos, etc.: si una parte desaparece, desaparecen las demás. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            removeOthers(level, pos, state);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    /** Evita que quitar las otras partes vuelva a disparar onRemove en cadena (y borre la parte que se está rompiendo). */
    private static boolean removingOthers;

    private void removeOthers(Level level, BlockPos pos, BlockState state) {
        if (removingOthers) {
            return;
        }
        removingOthers = true;
        try {
            removeOthersNow(level, pos, state);
        } finally {
            removingOthers = false;
        }
    }

    private void removeOthersNow(Level level, BlockPos pos, BlockState state) {
        Direction facing = state.getValue(FACING);
        BlockPos origin = originOf(pos, state);
        for (int part = 0; part < PART_COUNT; part++) {
            BlockPos other = partPos(origin, facing, part);
            if (other.equals(pos)) {
                continue;
            }
            BlockState otherState = level.getBlockState(other);
            // Solo las partes de ESTE multibloque (mismo bloque, orientación y número de parte).
            if (otherState.is(this) && otherState.getValue(FACING) == facing && otherState.getValue(PART) == part) {
                level.setBlock(other, Blocks.AIR.defaultBlockState(),
                        Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS | Block.UPDATE_KNOWN_SHAPE);
            }
        }
    }

    // --- Uso ---

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (player.isShiftKeyDown()) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            DeveloperMenu.open(serverPlayer, type, originOf(pos, state));
        }
        return InteractionResult.CONSUME;
    }

    // --- Render ---

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return state.getValue(PART) == 0 ? RenderShape.MODEL : RenderShape.INVISIBLE;
    }
}
