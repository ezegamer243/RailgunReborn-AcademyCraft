package com.railgunreborn.block;

import javax.annotation.Nullable;

import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;
import com.railgunreborn.energy.EnergyPush;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModBlocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Base del generador eólico (energy.md 1.3): produce, guarda y reparte la energía. Cada
 * {@link WindGenRules#CHECK_INTERVAL} ticks sube por la columna (8-40 pilares) buscando la cabeza y le pide su
 * estado (aspas y aire alrededor del rotor). Si funciona, genera {@link WindGenRules#outputPerTick} según la altura
 * de la cabeza, por {@code generatorMultiplier}. Buffer {@link WindGenRules#CAPACITY}, ancho de banda
 * {@link WindGenRules#BANDWIDTH}: carga el ítem de su ranura y empuja a los vecinos de sus dos bloques.
 *
 * <p>TODO(T103): el enlace inalámbrico a un nodo sacará energía de este mismo buffer; no hace falta tocar la
 * generación, solo exponer el almacén ({@link #getEnergy()}) a la red.
 */
public class WindGenBaseBlockEntity extends BlockEntity implements MenuProvider {
    public static final int SLOT_BATTERY = 0;

    public static final int DATA_STATUS = 0;
    public static final int DATA_PILLARS = 1;
    /** Altura (Y) de la cabeza, o {@link #NO_HEIGHT} si no hay estructura completa. */
    public static final int DATA_HEIGHT = 2;
    /** Producción en centésimas de IF/t (2 ranuras). */
    public static final int DATA_OUTPUT = 3;
    public static final int DATA_ENERGY = DATA_OUTPUT + ContainerDataInts.SLOTS;
    public static final int DATA_COUNT = DATA_ENERGY + ContainerDataInts.SLOTS;
    public static final int NO_HEIGHT = Short.MIN_VALUE;

    private final ModEnergyStorage energy = ModEnergyStorage.provider(WindGenRules.CAPACITY, WindGenRules.BANDWIDTH,
            this::setChanged);

    private final ItemStackHandler items = new ItemStackHandler(1) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return BatterySlot.isEnergyItem(stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    private WindGenRules.Status status = WindGenRules.Status.INCOMPLETE;
    private int pillars;
    private int mainY = NO_HEIGHT;
    private int checkTimer;
    /** Parte fraccionaria de lo generado (10,83 IF/t...): se acumula para no perderla. */
    private double carry;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            int centi = WindGenRules.toCenti(getOutputPerTick());
            int stored = energy.getEnergyStored();
            return switch (index) {
                case DATA_STATUS -> status.ordinal();
                case DATA_PILLARS -> pillars;
                case DATA_HEIGHT -> mainY;
                case DATA_OUTPUT, DATA_OUTPUT + 1 -> ContainerDataInts.part(centi, index - DATA_OUTPUT);
                case DATA_ENERGY, DATA_ENERGY + 1 -> ContainerDataInts.part(stored, index - DATA_ENERGY);
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    public WindGenBaseBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WINDGEN_BASE.get(), pos, state);
    }

    // --- Tick ---

    public static void serverTick(Level level, BlockPos pos, BlockState state, WindGenBaseBlockEntity be) {
        if (--be.checkTimer <= 0) {
            be.checkTimer = WindGenRules.CHECK_INTERVAL;
            be.refresh();
        }
        be.generate();
        BatterySlot.chargeItem(be.items.getStackInSlot(SLOT_BATTERY), be.energy, WindGenRules.BANDWIDTH);
        int pushed = EnergyPush.toNeighbors(level, pos, be.energy, WindGenRules.BANDWIDTH);
        EnergyPush.toNeighbors(level, pos.above(), be.energy, WindGenRules.BANDWIDTH - pushed);
    }

    /** Revisa la columna y la cabeza ahora mismo (también refresca la cabeza encontrada). */
    public void refresh() {
        if (level == null) {
            return;
        }
        BlockPos first = worldPosition.above(2);
        WindGenRules.Scan scan = WindGenRules.scan(i -> partAbove(level, first.above(i)));
        pillars = scan.pillars();
        WindGenRules.Status next = scan.status();
        int height = NO_HEIGHT;
        if (scan.complete() && level.getBlockEntity(first.above(scan.pillars())) instanceof WindGenMainBlockEntity main) {
            main.refresh();
            height = main.getBlockPos().getY();
            // La cabeza mira hacia abajo por su cuenta: si por lo que sea no ve la estructura, manda su vista.
            next = main.getStatus();
        } else if (scan.complete()) {
            next = WindGenRules.Status.INCOMPLETE;
        }
        if (next != status || height != mainY) {
            status = next;
            mainY = height;
            setChanged();
        }
        BlockState state = getBlockState();
        boolean complete = status.structureComplete();
        if (state.is(ModBlocks.WINDGEN_BASE.get()) && state.getValue(WindGenBaseBlock.COMPLETE) != complete) {
            level.setBlock(worldPosition, state.setValue(WindGenBaseBlock.COMPLETE, complete), Block.UPDATE_CLIENTS);
        }
    }

    private static WindGenRules.Part partAbove(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.is(ModBlocks.WINDGEN_PILLAR.get())) {
            return WindGenRules.Part.PILLAR;
        }
        if (state.is(ModBlocks.WINDGEN_MAIN.get()) && WindGenMainBlock.isController(state)) {
            return WindGenRules.Part.END;
        }
        return WindGenRules.Part.OTHER;
    }

    private void generate() {
        double rate = getOutputPerTick();
        if (rate <= 0 || energy.getSpace() <= 0) {
            return;
        }
        carry += rate;
        int whole = (int) carry;
        if (whole > 0) {
            carry -= whole;
            energy.addEnergy(whole, false);
        }
    }

    // --- Acceso ---

    /** IF/t que produce ahora (0 si no funciona). */
    public double getOutputPerTick() {
        return status == WindGenRules.Status.WORKING && mainY != NO_HEIGHT
                ? WindGenRules.outputPerTick(mainY, RailgunConfig.generatorMultiplier())
                : 0.0;
    }

    public WindGenRules.Status getStatus() {
        return status;
    }

    public int getPillars() {
        return pillars;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public ContainerData getData() {
        return data;
    }

    public void dropContents(Level level, BlockPos pos) {
        Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(SLOT_BATTERY));
    }

    // --- Guardado ---

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.putDouble("Carry", carry);
        energy.save(tag, "Energy", registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        carry = tag.getDouble("Carry");
        energy.load(tag, "Energy", registries);
    }

    // --- Menú ---

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.windgen_base");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new WindGenBaseMenu(containerId, inventory, this);
    }
}
