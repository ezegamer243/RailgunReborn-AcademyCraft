package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.context.SkillContexts;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Cliente → servidor: tecla soltada/abortada, keep-alive o terminar un contexto. No hay "keytick" por red: el
 * servidor sabe que la tecla sigue pulsada hasta recibir KEY_UP/KEY_ABORT y genera el tick él mismo.
 */
public record SkillContextActionPayload(int contextId, Action action) implements CustomPacketPayload {
    public enum Action {
        KEY_UP,
        KEY_ABORT,
        KEEP_ALIVE,
        TERMINATE
    }

    public static final Type<SkillContextActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "skill_context_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SkillContextActionPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT, SkillContextActionPayload::contextId,
                    NeoForgeStreamCodecs.enumCodec(Action.class), SkillContextActionPayload::action,
                    SkillContextActionPayload::new);

    @Override
    public Type<SkillContextActionPayload> type() {
        return TYPE;
    }

    static void handle(SkillContextActionPayload payload, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer player) {
            SkillContexts.handleAction(player, payload.contextId(), payload.action());
        }
    }
}
