package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.context.SkillContexts;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Cliente → servidor: se pulsó la tecla de una habilidad. {@code contextId} lo elige el cliente, así puede mandar
 * el soltar/abortar sin esperar respuesta (la conexión mantiene el orden). El servidor responde con
 * {@link SkillContextStatePayload} ALIVE o REJECTED.
 */
public record StartSkillPayload(int contextId, Skill skill) implements CustomPacketPayload {
    public static final Type<StartSkillPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "start_skill"));
    public static final StreamCodec<RegistryFriendlyByteBuf, StartSkillPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, StartSkillPayload::contextId,
            ByteBufCodecs.registry(AbilityRegistries.SKILL_KEY), StartSkillPayload::skill,
            StartSkillPayload::new);

    @Override
    public Type<StartSkillPayload> type() {
        return TYPE;
    }

    static void handle(StartSkillPayload payload, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer player) {
            SkillContexts.start(player, payload.contextId(), payload.skill());
        }
    }
}
