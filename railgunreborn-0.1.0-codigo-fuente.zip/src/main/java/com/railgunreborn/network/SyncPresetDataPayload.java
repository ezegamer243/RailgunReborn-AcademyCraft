package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.registry.ModAttachments;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: copia completa de {@link PresetData} del propio jugador. */
public record SyncPresetDataPayload(CompoundTag data) implements CustomPacketPayload {
    public static final Type<SyncPresetDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_preset_data"));
    public static final StreamCodec<ByteBuf, SyncPresetDataPayload> STREAM_CODEC =
            ByteBufCodecs.COMPOUND_TAG.map(SyncPresetDataPayload::new, SyncPresetDataPayload::data);

    public static SyncPresetDataPayload of(PresetData data) {
        return new SyncPresetDataPayload(PayloadTags.encode(PresetData.CODEC, data));
    }

    @Override
    public Type<SyncPresetDataPayload> type() {
        return TYPE;
    }

    static void handle(SyncPresetDataPayload payload, IPayloadContext context) {
        PayloadTags.decode(PresetData.CODEC, payload.data(), "preset data")
                .ifPresent(data -> context.player().setData(ModAttachments.PRESET_DATA, data));
    }
}
