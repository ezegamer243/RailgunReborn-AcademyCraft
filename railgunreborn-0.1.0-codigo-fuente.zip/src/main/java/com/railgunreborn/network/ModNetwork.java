package com.railgunreborn.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Registro de payloads. Un payload por attachment: cada uno tiene su propia cadencia de envío y así no se
 * reenvía AbilityData (con listas y mapas) cada pocos ticks junto con el CP.
 *
 * <p>Los handlers solo usan {@code context.player()} (en cliente es el jugador local) y clases comunes, así que
 * en servidor dedicado no se carga nada de cliente. NeoForge los ejecuta ya en el hilo principal por defecto.
 */
public final class ModNetwork {
    private static final String PROTOCOL_VERSION = "8";

    private ModNetwork() {
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
        registrar.playToClient(SyncAbilityDataPayload.TYPE, SyncAbilityDataPayload.STREAM_CODEC,
                SyncAbilityDataPayload::handle);
        registrar.playToClient(SyncCPDataPayload.TYPE, SyncCPDataPayload.STREAM_CODEC, SyncCPDataPayload::handle);
        registrar.playToClient(SyncPresetDataPayload.TYPE, SyncPresetDataPayload.STREAM_CODEC,
                SyncPresetDataPayload::handle);
        registrar.playToClient(SyncLocationDataPayload.TYPE, SyncLocationDataPayload.STREAM_CODEC,
                SyncLocationDataPayload::handle);
        registrar.playToClient(SyncTerminalDataPayload.TYPE, SyncTerminalDataPayload.STREAM_CODEC,
                SyncTerminalDataPayload::handle);
        registrar.playToServer(ToggleAbilityModePayload.TYPE, ToggleAbilityModePayload.STREAM_CODEC,
                ToggleAbilityModePayload::handle);
        registrar.playToServer(SwitchPresetPayload.TYPE, SwitchPresetPayload.STREAM_CODEC,
                SwitchPresetPayload::handle);
        registrar.playToServer(EditPresetSlotPayload.TYPE, EditPresetSlotPayload.STREAM_CODEC,
                EditPresetSlotPayload::handle);

        // Contextos de habilidad (T10). Los handlers de cliente llaman a client.context.*: solo se ejecutan en el
        // cliente y la JVM resuelve esas clases al llamarlas, así que el servidor dedicado no las carga.
        registrar.playToServer(StartSkillPayload.TYPE, StartSkillPayload.STREAM_CODEC, StartSkillPayload::handle);
        registrar.playToServer(SkillContextActionPayload.TYPE, SkillContextActionPayload.STREAM_CODEC,
                SkillContextActionPayload::handle);
        registrar.playToClient(SkillContextStatePayload.TYPE, SkillContextStatePayload.STREAM_CODEC,
                SkillContextStatePayload::handle);
        registrar.playBidirectional(SkillContextMessagePayload.TYPE, SkillContextMessagePayload.STREAM_CODEC,
                SkillContextMessagePayload::handle);
        registrar.playToClient(SkillEffectPayload.TYPE, SkillEffectPayload.STREAM_CODEC, SkillEffectPayload::handle);
        registrar.playToClient(SyncCooldownPayload.TYPE, SyncCooldownPayload.STREAM_CODEC,
                SyncCooldownPayload::handle);

        // Developer (T20): el estado vuelve por el ContainerData del DeveloperMenu.
        registrar.playToServer(DevelopActionPayload.TYPE, DevelopActionPayload.STREAM_CODEC,
                DevelopActionPayload::handle);

        // Red inalámbrica (T104): acciones de las pantallas y su vista (sin contraseñas) de vuelta.
        registrar.playToServer(WirelessActionPayload.TYPE, WirelessActionPayload.STREAM_CODEC,
                WirelessActionPayload::handle);
        registrar.playToClient(WirelessViewPayload.TYPE, WirelessViewPayload.STREAM_CODEC,
                WirelessViewPayload::handle);
    }
}
