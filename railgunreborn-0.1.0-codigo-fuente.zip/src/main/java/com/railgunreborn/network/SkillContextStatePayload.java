package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.context.ClientSkillContexts;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente que lo ejecuta: estado de un contexto (aceptado, rechazado, terminado o keep-alive). */
public record SkillContextStatePayload(int contextId, State state) implements CustomPacketPayload {
    public enum State {
        ALIVE,
        REJECTED,
        TERMINATED,
        KEEP_ALIVE
    }

    public static final Type<SkillContextStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "skill_context_state"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SkillContextStatePayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT, SkillContextStatePayload::contextId,
                    NeoForgeStreamCodecs.enumCodec(State.class), SkillContextStatePayload::state,
                    SkillContextStatePayload::new);

    @Override
    public Type<SkillContextStatePayload> type() {
        return TYPE;
    }

    // Solo se ejecuta en el cliente; la clase de cliente se resuelve al llamarla, no al cargar esta.
    static void handle(SkillContextStatePayload payload, IPayloadContext context) {
        ClientSkillContexts.handleState(payload.contextId(), payload.state());
    }
}
