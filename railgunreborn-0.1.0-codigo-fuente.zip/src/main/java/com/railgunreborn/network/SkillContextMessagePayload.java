package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.client.context.ClientSkillContexts;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Mensaje propio de una habilidad entre la mitad cliente local de un contexto y su mitad servidor, en ambos
 * sentidos: un canal con nombre y datos NBT. (Los efectos para jugadores cercanos van por {@link SkillEffectPayload}.)
 */
public record SkillContextMessagePayload(int contextId, String channel, CompoundTag data)
        implements CustomPacketPayload {
    public static final int MAX_CHANNEL_LENGTH = 64;

    public static final Type<SkillContextMessagePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "skill_context_message"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SkillContextMessagePayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT, SkillContextMessagePayload::contextId,
                    ByteBufCodecs.stringUtf8(MAX_CHANNEL_LENGTH), SkillContextMessagePayload::channel,
                    ByteBufCodecs.COMPOUND_TAG, SkillContextMessagePayload::data,
                    SkillContextMessagePayload::new);

    @Override
    public Type<SkillContextMessagePayload> type() {
        return TYPE;
    }

    static void handle(SkillContextMessagePayload payload, IPayloadContext context) {
        if (context.flow() == PacketFlow.SERVERBOUND) {
            if (context.player() instanceof ServerPlayer player) {
                SkillContexts.handleClientMessage(player, payload.contextId(), payload.channel(), payload.data());
            }
        } else {
            ClientSkillContexts.handleMessage(payload.contextId(), payload.channel(), payload.data());
        }
    }
}
