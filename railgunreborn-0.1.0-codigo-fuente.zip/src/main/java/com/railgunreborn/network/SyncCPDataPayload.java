package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModAttachments;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: copia completa de {@link CPData} del propio jugador (incluye las esperas de recuperación). */
public record SyncCPDataPayload(CompoundTag data) implements CustomPacketPayload {
    public static final Type<SyncCPDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_cp_data"));
    public static final StreamCodec<ByteBuf, SyncCPDataPayload> STREAM_CODEC =
            ByteBufCodecs.COMPOUND_TAG.map(SyncCPDataPayload::new, SyncCPDataPayload::data);

    public static SyncCPDataPayload of(CPData data) {
        return new SyncCPDataPayload(PayloadTags.encode(CPData.CODEC, data));
    }

    @Override
    public Type<SyncCPDataPayload> type() {
        return TYPE;
    }

    static void handle(SyncCPDataPayload payload, IPayloadContext context) {
        PayloadTags.decode(CPData.CODEC, payload.data(), "CP data")
                .ifPresent(data -> context.player().setData(ModAttachments.CP_DATA, data));
    }
}
