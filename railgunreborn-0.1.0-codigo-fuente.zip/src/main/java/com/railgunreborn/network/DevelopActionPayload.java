package com.railgunreborn.network;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.develop.DevelopAction;
import com.railgunreborn.ability.develop.DevelopResult;
import com.railgunreborn.ability.develop.DeveloperMenu;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.ByIdMap;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Cliente → servidor: pide al Developer abierto empezar una acción o abortar. Solo actúa sobre el
 * {@link DeveloperMenu} abierto con ese {@code containerId} (nunca confía en posiciones del cliente). El resultado
 * vuelve por el {@code ContainerData} del menú; los cambios de nivel/habilidades por el sync de {@code AbilityData}.
 *
 * @param target habilidad con {@link Request#START_SKILL}; categoría con {@link Request#START_CATEGORY}
 */
public record DevelopActionPayload(int containerId, Request request, Optional<ResourceLocation> target)
        implements CustomPacketPayload {
    public enum Request {
        /** Obtener categoría (sin categoría) o subir de nivel. */
        START_LEVEL,
        START_SKILL,
        ABORT,
        /** Obtener la categoría {@code target} gastando un Induction Factor (el servidor mira el inventario). */
        START_CATEGORY;

        static final StreamCodec<ByteBuf, Request> STREAM_CODEC = ByteBufCodecs.idMapper(
                ByIdMap.continuous(Request::ordinal, values(), ByIdMap.OutOfBoundsStrategy.ZERO), Request::ordinal);
    }

    public static final Type<DevelopActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "develop_action"));
    public static final StreamCodec<ByteBuf, DevelopActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DevelopActionPayload::containerId,
            Request.STREAM_CODEC, DevelopActionPayload::request,
            ByteBufCodecs.optional(ResourceLocation.STREAM_CODEC), DevelopActionPayload::target,
            DevelopActionPayload::new);

    public static DevelopActionPayload startLevel(int containerId) {
        return new DevelopActionPayload(containerId, Request.START_LEVEL, Optional.empty());
    }

    public static DevelopActionPayload startSkill(int containerId, ResourceLocation skill) {
        return new DevelopActionPayload(containerId, Request.START_SKILL, Optional.of(skill));
    }

    public static DevelopActionPayload startCategory(int containerId, ResourceLocation category) {
        return new DevelopActionPayload(containerId, Request.START_CATEGORY, Optional.of(category));
    }

    public static DevelopActionPayload abort(int containerId) {
        return new DevelopActionPayload(containerId, Request.ABORT, Optional.empty());
    }

    @Override
    public Type<DevelopActionPayload> type() {
        return TYPE;
    }

    static void handle(DevelopActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)
                || !(player.containerMenu instanceof DeveloperMenu menu)
                || menu.containerId != payload.containerId()) {
            return;
        }
        switch (payload.request()) {
            case ABORT -> menu.abort();
            case START_LEVEL -> menu.start(player, DevelopAction.level());
            case START_CATEGORY -> {
                if (payload.target().isPresent()) {
                    menu.start(player, DevelopAction.levelWithFactor(payload.target().get()));
                } else {
                    menu.reject(DevelopResult.NO_FACTOR);
                }
            }
            case START_SKILL -> {
                Optional<Skill> skill = payload.target().flatMap(AbilityRegistries::skill);
                if (skill.isPresent()) {
                    menu.start(player, DevelopAction.learn(skill.get()));
                } else {
                    menu.reject(DevelopResult.UNKNOWN_SKILL);
                }
            }
        }
    }
}
