package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.registry.ModSounds;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Cliente → servidor: pide pasar al siguiente preset (solo con el modo habilidad activo, como el original). */
public record SwitchPresetPayload() implements CustomPacketPayload {
    public static final SwitchPresetPayload INSTANCE = new SwitchPresetPayload();
    public static final Type<SwitchPresetPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "switch_preset"));
    public static final StreamCodec<ByteBuf, SwitchPresetPayload> STREAM_CODEC = StreamCodec.unit(INSTANCE);

    @Override
    public Type<SwitchPresetPayload> type() {
        return TYPE;
    }

    static void handle(SwitchPresetPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !CPData.get(player).isActivated()) {
            return;
        }
        PresetData.get(player).cycleActive();
        player.playNotifySound(ModSounds.PRESET_SWITCH.get(), SoundSource.PLAYERS, 1f, 1f);
    }
}
