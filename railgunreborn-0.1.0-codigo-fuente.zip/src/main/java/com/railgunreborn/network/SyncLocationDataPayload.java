package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.teleporter.LocationData;
import com.railgunreborn.registry.ModAttachments;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: copia completa de las ubicaciones de Location Teleport ({@link LocationData}) del jugador. */
public record SyncLocationDataPayload(CompoundTag data) implements CustomPacketPayload {
    public static final Type<SyncLocationDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_location_data"));
    public static final StreamCodec<ByteBuf, SyncLocationDataPayload> STREAM_CODEC =
            ByteBufCodecs.COMPOUND_TAG.map(SyncLocationDataPayload::new, SyncLocationDataPayload::data);

    public static SyncLocationDataPayload of(LocationData data) {
        return new SyncLocationDataPayload(PayloadTags.encode(LocationData.CODEC, data));
    }

    @Override
    public Type<SyncLocationDataPayload> type() {
        return TYPE;
    }

    static void handle(SyncLocationDataPayload payload, IPayloadContext context) {
        PayloadTags.decode(LocationData.CODEC, payload.data(), "location data")
                .ifPresent(data -> context.player().setData(ModAttachments.LOCATION_DATA, data));
    }
}
