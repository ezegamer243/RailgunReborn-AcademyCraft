package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.client.context.SkillEffects;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Servidor → el que lanza y los jugadores cercanos: efecto visual/sonoro de una habilidad (p. ej. Arc Gen manda
 * {@code effect} con el alcance). El cliente lo reparte a {@link SkillEffects} según la habilidad.
 *
 * @param casterId id de entidad del jugador que la usó (para anclar el efecto a su mano)
 */
public record SkillEffectPayload(int casterId, Skill skill, int contextId, String channel, CompoundTag data)
        implements CustomPacketPayload {
    public static final Type<SkillEffectPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "skill_effect"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SkillEffectPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT, SkillEffectPayload::casterId,
                    ByteBufCodecs.registry(AbilityRegistries.SKILL_KEY), SkillEffectPayload::skill,
                    ByteBufCodecs.VAR_INT, SkillEffectPayload::contextId,
                    ByteBufCodecs.stringUtf8(SkillContextMessagePayload.MAX_CHANNEL_LENGTH), SkillEffectPayload::channel,
                    ByteBufCodecs.COMPOUND_TAG, SkillEffectPayload::data,
                    SkillEffectPayload::new);

    @Override
    public Type<SkillEffectPayload> type() {
        return TYPE;
    }

    static void handle(SkillEffectPayload payload, IPayloadContext context) {
        SkillEffects.dispatch(payload);
    }
}
