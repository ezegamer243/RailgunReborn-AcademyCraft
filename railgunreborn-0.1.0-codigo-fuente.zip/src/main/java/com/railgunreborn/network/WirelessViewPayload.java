package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.wireless.WirelessMenu;
import com.railgunreborn.wireless.WirelessResult;
import com.railgunreborn.wireless.WirelessView;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Servidor → cliente: vista nueva de la pantalla inalámbrica abierta ({@code containerId}) y, si viene de una
 * acción, su resultado ({@code result} = ordinal de {@link WirelessResult}, -1 sin resultado). Sin contraseñas.
 */
public record WirelessViewPayload(int containerId, WirelessView view, int result) implements CustomPacketPayload {
    public static final Type<WirelessViewPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "wireless_view"));
    public static final StreamCodec<ByteBuf, WirelessViewPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, WirelessViewPayload::containerId,
            WirelessView.STREAM_CODEC, WirelessViewPayload::view,
            ByteBufCodecs.VAR_INT, WirelessViewPayload::result,
            WirelessViewPayload::new);

    @Override
    public Type<WirelessViewPayload> type() {
        return TYPE;
    }

    /** En el cliente: solo usa {@code context.player()} y clases comunes. */
    static void handle(WirelessViewPayload payload, IPayloadContext context) {
        if (context.player().containerMenu instanceof WirelessMenu menu
                && menu.containerId == payload.containerId()) {
            WirelessResult[] all = WirelessResult.values();
            WirelessResult result = payload.result() >= 0 && payload.result() < all.length ? all[payload.result()]
                    : null;
            menu.applyView(payload.view(), result);
        }
    }
}
