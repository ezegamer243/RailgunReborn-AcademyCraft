package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.terminal.TerminalData;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: si el jugador tiene el Terminal instalado ({@link TerminalData}). */
public record SyncTerminalDataPayload(CompoundTag data) implements CustomPacketPayload {
    public static final Type<SyncTerminalDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_terminal_data"));
    public static final StreamCodec<ByteBuf, SyncTerminalDataPayload> STREAM_CODEC =
            ByteBufCodecs.COMPOUND_TAG.map(SyncTerminalDataPayload::new, SyncTerminalDataPayload::data);

    public static SyncTerminalDataPayload of(TerminalData data) {
        return new SyncTerminalDataPayload(PayloadTags.encode(TerminalData.CODEC, data));
    }

    @Override
    public Type<SyncTerminalDataPayload> type() {
        return TYPE;
    }

    static void handle(SyncTerminalDataPayload payload, IPayloadContext context) {
        PayloadTags.decode(TerminalData.CODEC, payload.data(), "terminal data")
                .ifPresent(data -> context.player().setData(ModAttachments.TERMINAL_DATA, data));
    }
}
