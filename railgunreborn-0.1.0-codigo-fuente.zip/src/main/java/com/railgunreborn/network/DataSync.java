package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.teleporter.LocationData;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.terminal.TerminalData;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Cuándo se envían {@link AbilityData} y {@link CPData} al propio jugador (solo a él; ver la ficha, sección 8).
 *
 * <ul>
 * <li>Envío completo de ambos al entrar, al reaparecer (muerte o volver del End) y al cambiar de dimensión: en
 * esos casos el cliente crea un jugador local nuevo, sin attachments.</li>
 * <li>CPData: cada {@code (activado ? 1 : 3) * (cambios pendientes ? 4 : 10)} ticks, como el original (también
 * reenvía sin cambios: corrige al cliente cuando simule consumos, T10); inmediato si el cambio es urgente.</li>
 * <li>AbilityData: inmediato si cambia categoría/nivel/aprendidas; la exp ganada se agrupa y se envía
 * {@link #ABILITY_EXP_DELAY} ticks después del primer cambio sin enviar.</li>
 * </ul>
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class DataSync {
    /**
     * El original esperaba 25 ticks desde el último cambio; aquí se cuentan desde el primero para que una
     * habilidad continua (exp cada tick) no retrase el envío indefinidamente.
     */
    static final int ABILITY_EXP_DELAY = 25;

    private DataSync() {
    }

    /** Estado del sync por jugador (solo servidor, no se guarda). */
    public static final class State {
        private int cpTimer;
        /** Ticks que faltan para enviar AbilityData; -1 = nada pendiente. */
        private int abilityDelay = -1;
    }

    // LOWEST: después del tick de CPEvents, para enviar en el mismo tick lo que acaba de cambiar.
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        State state = player.getData(ModAttachments.SYNC_STATE);

        // CPData.get primero: aplica recálculos pendientes por cambios de nivel/categoría (marcan urgente).
        CPData cp = CPData.get(player);
        int period = (cp.isActivated() ? 1 : 3) * (cp.isDirty() ? 4 : 10);
        if (cp.isUrgent() || ++state.cpTimer >= period) {
            sendCP(player, cp, state);
        }

        PresetData preset = PresetData.get(player);
        if (preset.isDirty()) {
            sendPreset(player, preset);
        }

        if (LocationData.get(player).isDirty()) {
            sendLocations(player);
        }

        AbilityData ability = AbilityData.get(player);
        if (ability.isUrgent()) {
            sendAbility(player, ability, state);
        } else if (ability.isDirty()) {
            if (state.abilityDelay < 0) {
                state.abilityDelay = ABILITY_EXP_DELAY;
            } else if (--state.abilityDelay <= 0) {
                sendAbility(player, ability, state);
            }
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            sendAll(player);
        }
    }

    /** Se usa Respawn y no Clone: cuando llega, el cliente ya tiene el jugador local nuevo. */
    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            sendAll(player);
        }
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            sendAll(player);
        }
    }

    public static void sendAll(ServerPlayer player) {
        State state = player.getData(ModAttachments.SYNC_STATE);
        // Orden: AbilityData antes que CPData, por si el cliente lee el nivel al recibir el CP.
        sendAbility(player, AbilityData.get(player), state);
        sendCP(player, CPData.get(player), state);
        sendPreset(player, PresetData.get(player));
        sendLocations(player);
        sendTerminal(player);
    }

    public static void sendTerminal(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, SyncTerminalDataPayload.of(TerminalData.get(player)));
    }

    /** Envío completo de las ubicaciones de Location Teleport (al instante: la pantalla puede estar abierta). */
    public static void sendLocations(ServerPlayer player) {
        LocationData locations = LocationData.get(player);
        locations.consumeDirty();
        PacketDistributor.sendToPlayer(player, SyncLocationDataPayload.of(locations));
    }

    public static void sendPreset(ServerPlayer player, PresetData preset) {
        preset.consumeDirty();
        PacketDistributor.sendToPlayer(player, SyncPresetDataPayload.of(preset));
    }

    private static void sendCP(ServerPlayer player, CPData cp, State state) {
        cp.consumeDirty();
        state.cpTimer = 0;
        PacketDistributor.sendToPlayer(player, SyncCPDataPayload.of(cp));
    }

    private static void sendAbility(ServerPlayer player, AbilityData ability, State state) {
        ability.consumeDirty();
        state.abilityDelay = -1;
        PacketDistributor.sendToPlayer(player, SyncAbilityDataPayload.of(ability));
    }
}
