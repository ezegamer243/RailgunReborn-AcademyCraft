package com.railgunreborn.network;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.wireless.WirelessActions;
import com.railgunreborn.wireless.WirelessView;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Cliente → servidor: una acción de las pantallas inalámbricas (ver {@link WirelessActions.Action} para el sentido
 * de {@code pos}, {@code target}, {@code a} y {@code b}). Los textos llegan con tope de 64 caracteres; el servidor
 * valida los límites reales. Puede llevar la contraseña que el jugador escribió; no se guarda ni se registra.
 */
public record WirelessActionPayload(WirelessActions.Action action, BlockPos pos, Optional<BlockPos> target, String a,
        String b) implements CustomPacketPayload {
    public static final Type<WirelessActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "wireless_action"));
    private static final StreamCodec<ByteBuf, WirelessActions.Action> ACTION = ByteBufCodecs.VAR_INT.map(
            i -> WirelessActions.Action.values()[Math.floorMod(i, WirelessActions.Action.values().length)],
            Enum::ordinal);
    public static final StreamCodec<ByteBuf, WirelessActionPayload> STREAM_CODEC = StreamCodec.composite(
            ACTION, WirelessActionPayload::action,
            BlockPos.STREAM_CODEC, WirelessActionPayload::pos,
            ByteBufCodecs.optional(BlockPos.STREAM_CODEC), WirelessActionPayload::target,
            ByteBufCodecs.stringUtf8(WirelessView.MAX_TEXT), WirelessActionPayload::a,
            ByteBufCodecs.stringUtf8(WirelessView.MAX_TEXT), WirelessActionPayload::b,
            WirelessActionPayload::new);

    public WirelessActionPayload(WirelessActions.Action action, BlockPos pos) {
        this(action, pos, Optional.empty(), "", "");
    }

    /** Sin los textos: pueden llevar una contraseña y no deben acabar en ningún log. */
    @Override
    public String toString() {
        return "WirelessActionPayload[" + action + " @ " + pos.toShortString() + "]";
    }

    @Override
    public Type<WirelessActionPayload> type() {
        return TYPE;
    }

    static void handle(WirelessActionPayload payload, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer player) {
            WirelessActions.handle(player, payload);
        }
    }
}
