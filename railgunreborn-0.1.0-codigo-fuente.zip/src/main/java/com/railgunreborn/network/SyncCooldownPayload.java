package com.railgunreborn.network;

import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.CooldownData;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: foto completa de los cooldowns del propio jugador (se manda al fijar o borrar alguno). */
public record SyncCooldownPayload(List<CooldownData.Entry> entries) implements CustomPacketPayload {
    public static final Type<SyncCooldownPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_cooldowns"));
    public static final StreamCodec<ByteBuf, SyncCooldownPayload> STREAM_CODEC =
            CooldownData.Entry.STREAM_CODEC.apply(ByteBufCodecs.list(256))
                    .map(SyncCooldownPayload::new, SyncCooldownPayload::entries);

    public static SyncCooldownPayload of(CooldownData data) {
        return new SyncCooldownPayload(data.snapshot());
    }

    @Override
    public Type<SyncCooldownPayload> type() {
        return TYPE;
    }

    static void handle(SyncCooldownPayload payload, IPayloadContext context) {
        CooldownData.get(context.player()).applySnapshot(payload.entries());
    }
}
