package com.railgunreborn.network;

import java.util.Optional;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.data.PresetRules;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Cliente → servidor: cambia una ranura de un preset (0-based). Se valida con {@link PresetRules}; si se rechaza no
 * cambia nada, se reenvía el estado completo y se avisa en la action bar. El cambio válido vuelve por el sync normal.
 */
public record EditPresetSlotPayload(int preset, int slot, Optional<ResourceLocation> skill)
        implements CustomPacketPayload {
    public static final Type<EditPresetSlotPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "edit_preset_slot"));
    public static final StreamCodec<ByteBuf, EditPresetSlotPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, EditPresetSlotPayload::preset,
            ByteBufCodecs.VAR_INT, EditPresetSlotPayload::slot,
            ByteBufCodecs.optional(ResourceLocation.STREAM_CODEC), EditPresetSlotPayload::skill,
            EditPresetSlotPayload::new);

    @Override
    public Type<EditPresetSlotPayload> type() {
        return TYPE;
    }

    static void handle(EditPresetSlotPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        PresetRules.Result result = PresetRules.applyEdit(player, payload.preset(), payload.slot(),
                payload.skill().orElse(null));
        if (result != PresetRules.Result.OK) {
            DataSync.sendPreset(player, PresetData.get(player));
            player.displayClientMessage(Component.translatable("railgunreborn.preset.edit_rejected"), true);
        }
    }
}
