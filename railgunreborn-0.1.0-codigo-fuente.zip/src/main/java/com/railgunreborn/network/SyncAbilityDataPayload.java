package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.registry.ModAttachments;

import io.netty.buffer.ByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor → cliente: copia completa de {@link AbilityData} del propio jugador. */
public record SyncAbilityDataPayload(CompoundTag data) implements CustomPacketPayload {
    public static final Type<SyncAbilityDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "sync_ability_data"));
    public static final StreamCodec<ByteBuf, SyncAbilityDataPayload> STREAM_CODEC =
            ByteBufCodecs.COMPOUND_TAG.map(SyncAbilityDataPayload::new, SyncAbilityDataPayload::data);

    public static SyncAbilityDataPayload of(AbilityData data) {
        return new SyncAbilityDataPayload(PayloadTags.encode(AbilityData.CODEC, data));
    }

    @Override
    public Type<SyncAbilityDataPayload> type() {
        return TYPE;
    }

    static void handle(SyncAbilityDataPayload payload, IPayloadContext context) {
        PayloadTags.decode(AbilityData.CODEC, payload.data(), "ability data")
                .ifPresent(data -> context.player().setData(ModAttachments.ABILITY_DATA, data));
    }
}
