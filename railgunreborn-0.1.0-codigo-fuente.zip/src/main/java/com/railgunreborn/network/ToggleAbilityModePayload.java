package com.railgunreborn.network;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.registry.ModSounds;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Cliente → servidor: pide alternar el modo habilidad. El servidor valida y el sync devuelve el estado. */
public record ToggleAbilityModePayload() implements CustomPacketPayload {
    public static final ToggleAbilityModePayload INSTANCE = new ToggleAbilityModePayload();
    public static final Type<ToggleAbilityModePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "toggle_ability_mode"));
    public static final StreamCodec<ByteBuf, ToggleAbilityModePayload> STREAM_CODEC = StreamCodec.unit(INSTANCE);

    @Override
    public Type<ToggleAbilityModePayload> type() {
        return TYPE;
    }

    static void handle(ToggleAbilityModePayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        if (!AbilityData.get(player).hasCategory()) {
            player.playNotifySound(ModSounds.DENY.get(), SoundSource.PLAYERS, 1f, 1f);
            return;
        }
        CPData cp = CPData.get(player);
        cp.setActivated(player, !cp.isActivated());
    }
}
