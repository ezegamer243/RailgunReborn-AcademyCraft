package com.railgunreborn.network;

import java.util.Optional;

import com.mojang.serialization.Codec;
import com.railgunreborn.RailgunReborn;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;

/**
 * Los payloads llevan una foto NBT (hecha con el mismo Codec del guardado) y no el objeto: en un mundo de un
 * jugador la conexión es en memoria y no serializa, así que pasar el attachment mutable haría que cliente y
 * servidor compartieran la misma instancia.
 */
final class PayloadTags {
    private PayloadTags() {
    }

    static <T> CompoundTag encode(Codec<T> codec, T value) {
        return (CompoundTag) codec.encodeStart(NbtOps.INSTANCE, value).getOrThrow();
    }

    static <T> Optional<T> decode(Codec<T> codec, CompoundTag tag, String what) {
        return codec.parse(NbtOps.INSTANCE, tag)
                .resultOrPartial(error -> RailgunReborn.LOGGER.error("Failed to decode synced {}: {}", what, error));
    }
}
