package com.railgunreborn.debug;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.railgunreborn.RailgunReborn;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * SOLO DESARROLLO (T13): {@code /railgunreborn debug arc [length]} (nivel 2) pinta en el cliente de quien lo ejecuta
 * el arco de Arc Gen, sin daño ni coste, para revisar el VFX sin la habilidad. Brigadier fusiona este
 * {@code literal("railgunreborn")} con el de {@code RailgunCommands}. Borrable junto con el paquete {@code debug}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class DebugCommands {
    private static final float DEFAULT_LENGTH = 10.5f; // alcance de Arc Gen con exp 0.5

    private DebugCommands() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal(RailgunReborn.MODID)
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("debug")
                        .then(Commands.literal("arc")
                                .executes(ctx -> arc(ctx.getSource(), DEFAULT_LENGTH))
                                .then(Commands.argument("length", FloatArgumentType.floatArg(0.5f, 20f))
                                        .executes(ctx -> arc(ctx.getSource(),
                                                FloatArgumentType.getFloat(ctx, "length")))))));
    }

    private static int arc(CommandSourceStack source, float length) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        PacketDistributor.sendToPlayer(player, new DebugArcPayload(length));
        source.sendSuccess(() -> Component.literal("Debug arc, length " + length), false);
        return 1;
    }
}
