package com.railgunreborn.debug;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.effect.ArcEffects;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/**
 * SOLO DESARROLLO (T13): servidor → cliente, "dibuja un arco débil de esta longitud desde tu mano". Lo envía
 * {@code /railgunreborn debug arc}. Para quitarlo basta borrar el paquete {@code com.railgunreborn.debug}.
 *
 * <p>Se registra con su propio listener para no tocar {@code ModNetwork}. El handler solo se ejecuta en el cliente
 * (es {@code playToClient}), así que la referencia a {@link ArcEffects} no se resuelve nunca en un servidor dedicado.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, bus = EventBusSubscriber.Bus.MOD)
public record DebugArcPayload(float length) implements CustomPacketPayload {
    public static final Type<DebugArcPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "debug_arc"));
    public static final StreamCodec<ByteBuf, DebugArcPayload> STREAM_CODEC =
            ByteBufCodecs.FLOAT.map(DebugArcPayload::new, DebugArcPayload::length);

    @Override
    public Type<DebugArcPayload> type() {
        return TYPE;
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToClient(TYPE, STREAM_CODEC,
                (payload, context) -> ArcEffects.spawnWeakArc(context.player(), payload.length()));
    }
}
