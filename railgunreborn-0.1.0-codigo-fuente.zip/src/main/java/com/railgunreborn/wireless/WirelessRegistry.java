package com.railgunreborn.wireless;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.energy.EnergyCapabilities;
import com.railgunreborn.registry.ModCreativeTabs;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registros de la red inalámbrica (T103), aparte de ModBlocks/ModItems como el Metal Former y el reactor: matriz
 * (multibloque 2x2x2), nodos de 3 niveles y núcleos de matriz. Pantallas y recetas en T104.
 */
public final class WirelessRegistry {
    private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RailgunReborn.MODID);
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RailgunReborn.MODID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister
            .create(Registries.BLOCK_ENTITY_TYPE, RailgunReborn.MODID);
    private static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU,
            RailgunReborn.MODID);

    public static final DeferredBlock<MatrixBlock> MATRIX = BLOCKS.register("matrix",
            () -> new MatrixBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion()
                    .pushReaction(PushReaction.BLOCK)));
    public static final DeferredBlock<NodeBlock> NODE_BASIC = node(NodeType.BASIC);
    public static final DeferredBlock<NodeBlock> NODE_STANDARD = node(NodeType.STANDARD);
    public static final DeferredBlock<NodeBlock> NODE_ADVANCED = node(NodeType.ADVANCED);

    public static final DeferredItem<MatrixBlockItem> MATRIX_ITEM = ITEMS.register("matrix",
            () -> new MatrixBlockItem(MATRIX.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> NODE_BASIC_ITEM = ITEMS.registerSimpleBlockItem(NODE_BASIC);
    public static final DeferredItem<BlockItem> NODE_STANDARD_ITEM = ITEMS.registerSimpleBlockItem(NODE_STANDARD);
    public static final DeferredItem<BlockItem> NODE_ADVANCED_ITEM = ITEMS.registerSimpleBlockItem(NODE_ADVANCED);
    public static final DeferredItem<MatCoreItem> MAT_CORE_0 = matCore(1);
    public static final DeferredItem<MatCoreItem> MAT_CORE_1 = matCore(2);
    public static final DeferredItem<MatCoreItem> MAT_CORE_2 = matCore(3);

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MatrixBlockEntity>> MATRIX_BE =
            BLOCK_ENTITIES.register("matrix", () -> BlockEntityType.Builder
                    .of(MatrixBlockEntity::new, MATRIX.get()).build(null));
    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<NodeBlockEntity>> NODE_BE =
            BLOCK_ENTITIES.register("node", () -> BlockEntityType.Builder
                    .of(NodeBlockEntity::new, NODE_BASIC.get(), NODE_STANDARD.get(), NODE_ADVANCED.get())
                    .build(null));

    // Pantallas (T104): se registran en el cliente con RegisterMenuScreensEvent (WirelessClient).
    public static final DeferredHolder<MenuType<?>, MenuType<MatrixMenu>> MATRIX_MENU = MENUS.register("matrix",
            () -> IMenuTypeExtension.create(MatrixMenu::new));
    public static final DeferredHolder<MenuType<?>, MenuType<NodeMenu>> NODE_MENU = MENUS.register("node",
            () -> IMenuTypeExtension.create(NodeMenu::new));
    public static final DeferredHolder<MenuType<?>, MenuType<NodeLinkMenu>> NODE_LINK_MENU = MENUS.register(
            "node_link", () -> IMenuTypeExtension.create(NodeLinkMenu::new));

    private WirelessRegistry() {
    }

    private static DeferredBlock<NodeBlock> node(NodeType type) {
        return BLOCKS.register(type.id, () -> new NodeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                .strength(2.5f).sound(SoundType.METAL).requiresCorrectToolForDrops(), type));
    }

    /** {@code mat_core_0/1/2} como en el original (subtipo 0-2), nivel 1-3. */
    private static DeferredItem<MatCoreItem> matCore(int tier) {
        return ITEMS.register("mat_core_" + (tier - 1), () -> new MatCoreItem(tier, new Item.Properties()));
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        modEventBus.addListener(WirelessRegistry::registerCapabilities);
        modEventBus.addListener(WirelessRegistry::addToCreativeTab);
    }

    /** Los nodos dan y reciben FE por cualquier cara (hasta su ancho de banda por llamada) y exponen sus ranuras. */
    private static void registerCapabilities(RegisterCapabilitiesEvent event) {
        EnergyCapabilities.registerBlock(event, NODE_BE.get(), NodeBlockEntity::getEnergy);
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, NODE_BE.get(), (be, side) -> be.getItems());
    }

    /** Se añaden a la pestaña del mod por evento para no tocar la lista de {@link ModCreativeTabs}. */
    private static void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(ModCreativeTabs.MAIN.getKey())) {
            event.accept(MATRIX_ITEM.get());
            event.accept(NODE_BASIC_ITEM.get());
            event.accept(NODE_STANDARD_ITEM.get());
            event.accept(NODE_ADVANCED_ITEM.get());
            event.accept(MAT_CORE_0.get());
            event.accept(MAT_CORE_1.get());
            event.accept(MAT_CORE_2.get());
        }
    }
}
