package com.railgunreborn.wireless;

/**
 * Equilibrado de una red (energy.md 1.4), sin Minecraft para poder probarlo aparte.
 *
 * <p>Como el original: se calcula el llenado medio de los nodos cargados ({@code suma energía / suma capacidad},
 * aquí contando también el colchón) y
 * cada nodo tiende a {@code capacidad x media}. Los que tienen de más dan al colchón de la red y los que tienen de
 * menos toman de él, cada uno como mucho su ancho de banda por tick y entre todos como mucho el ancho de banda de la
 * matriz (para recoger y para entregar por separado).
 *
 * <p>Cambio respecto al original: allí el colchón sumaba en vez de restar (creaba energía) y recoger y entregar
 * gastaban el mismo ancho de banda en el orden barajado, así que la mitad de los ticks no se movía nada. Aquí lo
 * recogido nunca supera lo que cabe en el colchón tras la entrega de este mismo tick, de modo que el flujo es estable
 * y la energía se conserva (lo que queda en el colchón, hasta {@link WirelessNetwork#BUFFER_MAX}, se entrega después).
 */
public final class WirelessBalance {
    private WirelessBalance() {
    }

    /**
     * Equilibra {@code energy} (se modifica) y devuelve el colchón nuevo. Los tres arrays van en el mismo orden (ya
     * barajado por quien llama, para que nadie tenga siempre prioridad).
     */
    public static int balance(int[] energy, int[] capacity, int[] nodeBandwidth, int matrixBandwidth, int buffer) {
        int n = energy.length;
        long sum = 0;
        long max = 0;
        for (int i = 0; i < n; i++) {
            sum += energy[i];
            max += capacity[i];
        }
        if (n == 0 || max <= 0 || matrixBandwidth <= 0) {
            return buffer;
        }
        // El colchón cuenta como energía de la red: así lo que quede en él se acaba entregando.
        double ratio = Math.min(1.0, (sum + buffer) / (double) max);
        int[] give = new int[n];
        int[] take = new int[n];
        long supply = 0;
        long demand = 0;
        for (int i = 0; i < n; i++) {
            int target = (int) Math.round(capacity[i] * ratio);
            int diff = energy[i] - target;
            if (diff > 0) {
                give[i] = Math.min(diff, nodeBandwidth[i]);
                supply += give[i];
            } else if (diff < 0) {
                take[i] = Math.min(-diff, nodeBandwidth[i]);
                demand += take[i];
            }
        }
        int out = (int) Math.min(matrixBandwidth, demand);
        int in = (int) Math.min(Math.min(matrixBandwidth, supply), WirelessNetwork.BUFFER_MAX - buffer + (long) out);
        for (int i = 0; i < n && in > 0; i++) {
            int amount = Math.min(give[i], in);
            energy[i] -= amount;
            buffer += amount;
            in -= amount;
        }
        int deliver = Math.min(out, buffer);
        for (int i = 0; i < n && deliver > 0; i++) {
            int amount = Math.min(take[i], deliver);
            energy[i] += amount;
            buffer -= amount;
            deliver -= amount;
        }
        return buffer;
    }
}
