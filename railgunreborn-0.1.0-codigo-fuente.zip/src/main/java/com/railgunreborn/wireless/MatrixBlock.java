package com.railgunreborn.wireless;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;

/**
 * Matriz inalámbrica: multibloque 2x2x2 como el original ({@code BlockMatrix}: origen + 7 sub-bloques hacia +X, +Y y
 * +Z, sin orientación). Mismo esquema que el Developer: la parte 0 es el origen, lleva el BlockEntity y el modelo
 * OBJ; las demás son invisibles pero sólidas y llevan al origen.
 *
 * <p>Parte {@code p}: desplazamiento {@code (p & 1, (p >> 1) & 1, (p >> 2) & 1)} desde el origen.
 *
 * <p>Clic derecho abre {@link MatrixMenu}.
 */
public class MatrixBlock extends Block implements EntityBlock {
    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 7);
    public static final int PART_COUNT = 8;
    public static final MapCodec<MatrixBlock> CODEC = simpleCodec(MatrixBlock::new);

    public MatrixBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(PART, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(PART);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(PART) == 0 ? new MatrixBlockEntity(pos, state) : null;
    }

    // --- Huella ---

    public static BlockPos partPos(BlockPos origin, int part) {
        return origin.offset(part & 1, (part >> 1) & 1, (part >> 2) & 1);
    }

    public static BlockPos originOf(BlockPos pos, BlockState state) {
        int part = state.getValue(PART);
        return pos.offset(-(part & 1), -((part >> 1) & 1), -((part >> 2) & 1));
    }

    /** Origen de la matriz que ocupa {@code pos} (cualquier parte), o null si ahí no hay matriz. */
    @Nullable
    public static BlockPos originAt(BlockGetter level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.getBlock() instanceof MatrixBlock ? originOf(pos, state) : null;
    }

    /** BlockEntity de la matriz que ocupa {@code pos} (cualquier parte), o null. */
    @Nullable
    public static MatrixBlockEntity entityAt(BlockGetter level, BlockPos pos) {
        BlockPos origin = originAt(level, pos);
        return origin != null && level.getBlockEntity(origin) instanceof MatrixBlockEntity be ? be : null;
    }

    /** Coloca las 8 partes sin comprobar nada (la validación está en {@link #getStateForPlacement}). */
    public void place(Level level, BlockPos origin) {
        for (int part = 0; part < PART_COUNT; part++) {
            level.setBlock(partPos(origin, part), defaultBlockState().setValue(PART, part), Block.UPDATE_ALL);
        }
    }

    // --- Colocación / rotura ---

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos origin = context.getClickedPos();
        for (int part = 0; part < PART_COUNT; part++) {
            BlockPos pos = partPos(origin, part);
            if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
                return null;
            }
            if (part > 0) {
                BlockState existing = level.getBlockState(pos);
                if (!existing.canBeReplaced() || level.getBlockEntity(pos) != null
                        || !level.isUnobstructed(defaultBlockState(), pos, CollisionContext.empty())) {
                    return null;
                }
            }
        }
        return defaultBlockState();
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof MatrixBlockEntity be) {
            be.setPlacerName(player.getGameProfile().getName());
        }
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide) {
            removeOthers(level, pos, state);
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    /** Romper cualquier parte (jugador, explosión, comando) quita las demás, suelta las ranuras y disuelve la red. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            BlockPos origin = originOf(pos, state);
            if (state.getValue(PART) == 0 && level.getBlockEntity(pos) instanceof MatrixBlockEntity be) {
                be.dropContents(level, pos);
            }
            if (level instanceof ServerLevel serverLevel) {
                WirelessData.get(serverLevel).dissolveNetwork(origin);
            }
            removeOthers(level, pos, state);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private static boolean removingOthers;

    private void removeOthers(Level level, BlockPos pos, BlockState state) {
        if (removingOthers) {
            return;
        }
        removingOthers = true;
        try {
            BlockPos origin = originOf(pos, state);
            for (int part = 0; part < PART_COUNT; part++) {
                BlockPos other = partPos(origin, part);
                if (other.equals(pos)) {
                    continue;
                }
                BlockState otherState = level.getBlockState(other);
                if (otherState.is(this) && otherState.getValue(PART) == part) {
                    level.setBlock(other, Blocks.AIR.defaultBlockState(),
                            Block.UPDATE_CLIENTS | Block.UPDATE_SUPPRESS_DROPS | Block.UPDATE_KNOWN_SHAPE);
                }
            }
        } finally {
            removingOthers = false;
        }
    }

    // --- Uso ---

    /** Clic derecho en cualquier parte abre la pantalla de la matriz (ranuras, red, SSID y contraseña). */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        MatrixBlockEntity be = entityAt(level, pos);
        if (be == null) {
            return InteractionResult.PASS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            MatrixMenu.open(serverPlayer, be);
        }
        return InteractionResult.CONSUME;
    }

    // --- Render ---

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return state.getValue(PART) == 0 ? RenderShape.MODEL : RenderShape.INVISIBLE;
    }
}
