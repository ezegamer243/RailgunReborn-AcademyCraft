package com.railgunreborn.wireless;

/**
 * Los 3 niveles de nodo inalámbrico (energy.md 1.4): buffer, ancho de banda por tick (hacia generadores y hacia
 * receptores, por separado), alcance en bloques hasta sus generadores/receptores y cuántos puede enlazar.
 */
public enum NodeType {
    BASIC("node_basic", 15_000, 150, 9, 5),
    STANDARD("node_standard", 50_000, 300, 12, 10),
    ADVANCED("node_advanced", 200_000, 900, 19, 20);

    public final String id;
    public final int capacity;
    public final int bandwidth;
    public final double range;
    public final int maxLinks;

    NodeType(String id, int capacity, int bandwidth, double range, int maxLinks) {
        this.id = id;
        this.capacity = capacity;
        this.bandwidth = bandwidth;
        this.range = range;
        this.maxLinks = maxLinks;
    }
}
