package com.railgunreborn.wireless;

import javax.annotation.Nullable;

import com.railgunreborn.network.WirelessViewPayload;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Base de los menús inalámbricos (matriz, nodo, enlace): guardan la posición del bloque y la {@link WirelessView} que
 * muestra la pantalla. En el servidor la rehacen cada segundo y la mandan si cambió; tras cada acción se manda junto
 * con su resultado ({@link WirelessActions}). La vista nunca lleva contraseñas.
 */
public abstract class WirelessMenu extends AbstractContainerMenu {
    /** Distancia máxima (al cuadrado) del jugador al bloque para usar la pantalla, como los menús vanilla. */
    public static final double MAX_DISTANCE_SQ = 64.0;
    public static final int REFRESH_TICKS = 20;

    protected final BlockPos pos;
    protected final Player player;
    private WirelessView view;
    @Nullable
    private WirelessResult lastResult;
    private int resultSerial;
    private int refreshTicker;

    protected WirelessMenu(@Nullable MenuType<?> type, int containerId, Inventory inventory, BlockPos pos,
            WirelessView view) {
        super(type, containerId);
        this.pos = pos.immutable();
        this.player = inventory.player;
        this.view = view;
    }

    public BlockPos getPos() {
        return pos;
    }

    public WirelessView getView() {
        return view;
    }

    @Nullable
    public WirelessResult getLastResult() {
        return lastResult;
    }

    /** Sube cada vez que llega un resultado (la pantalla lo usa para saber si es nuevo). */
    public int getResultSerial() {
        return resultSerial;
    }

    /** Cliente: llega una vista nueva (y quizá el resultado de una acción). */
    public void applyView(WirelessView view, @Nullable WirelessResult result) {
        this.view = view;
        if (result != null) {
            this.lastResult = result;
            resultSerial++;
        }
    }

    /** Servidor: la vista actual de este bloque para este jugador. */
    protected abstract WirelessView buildView(ServerLevel level, WirelessData data);

    /** Servidor: rehace la vista y se la manda al jugador (siempre si hay resultado; si no, solo si cambió). */
    public void sendView(@Nullable WirelessResult result) {
        if (!(player instanceof ServerPlayer serverPlayer) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        WirelessView fresh = buildView(level, WirelessData.get(level));
        if (result == null && fresh.equals(view)) {
            return;
        }
        view = fresh;
        PacketDistributor.sendToPlayer(serverPlayer, new WirelessViewPayload(containerId, fresh,
                result == null ? -1 : result.ordinal()));
    }

    @Override
    public void broadcastChanges() {
        super.broadcastChanges();
        if (player instanceof ServerPlayer && ++refreshTicker >= REFRESH_TICKS) {
            refreshTicker = 0;
            sendView(null);
        }
    }

    public static boolean near(Player player, BlockPos pos) {
        return player.distanceToSqr(Vec3.atCenterOf(pos)) <= MAX_DISTANCE_SQ;
    }

    /** Quien colocó el bloque, un operador, o cualquiera si el bloque no tiene dueño (puesto por comando). */
    public static boolean canEdit(Player player, String placer) {
        return placer == null || placer.isEmpty() || placer.equals(player.getGameProfile().getName())
                || player.hasPermissions(2);
    }

    /** Mayús+clic: ranuras de la máquina [0, machineSlots) primero; si no, entre inventario y barra rápida. */
    protected ItemStack quickMove(Player player, int index, int machineSlots) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        int invEnd = machineSlots + 36;
        if (index < machineSlots) {
            if (!moveItemStackTo(stack, machineSlots, invEnd, true)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, 0, machineSlots, false)) {
            if (index < invEnd - 9) {
                if (!moveItemStackTo(stack, invEnd - 9, invEnd, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (!moveItemStackTo(stack, machineSlots, invEnd - 9, false)) {
                return ItemStack.EMPTY;
            }
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }

    protected void addPlayerInventory(Inventory inventory, int x, int y, int hotbarY) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, x + col * 18, y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, x + col * 18, hotbarY));
        }
    }
}
