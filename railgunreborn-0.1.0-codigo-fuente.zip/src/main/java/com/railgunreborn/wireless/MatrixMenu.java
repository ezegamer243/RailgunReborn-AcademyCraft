package com.railgunreborn.wireless;

import java.util.List;
import java.util.Optional;

import com.railgunreborn.block.TechUiLayout;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Menú de la matriz: 3 ranuras de placas + 1 de núcleo y el inventario. Nivel, capacidad, ancho de banda y alcance
 * salen de las ranuras (sincronizadas); SSID, nodos usados, dueño y permiso, de la {@link WirelessView}.
 */
public class MatrixMenu extends WirelessMenu {
    public static final int MACHINE_SLOTS = 4;

    private final IItemHandler items;

    /** Cliente. */
    public MatrixMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, buf.readBlockPos(), WirelessView.STREAM_CODEC.decode(buf), clientItems());
    }

    /** Servidor. */
    public MatrixMenu(int containerId, Inventory inventory, MatrixBlockEntity be, WirelessView view) {
        this(containerId, inventory, be.getBlockPos(), view, be.getItems());
    }

    private MatrixMenu(int containerId, Inventory inventory, BlockPos pos, WirelessView view, IItemHandler items) {
        super(WirelessRegistry.MATRIX_MENU.get(), containerId, inventory, pos, view);
        this.items = items;
        for (int i = 0; i < MatrixBlockEntity.PLATE_SLOTS; i++) {
            addSlot(new SlotItemHandler(items, i, WirelessUiLayout.MATRIX_PLATES[i][0],
                    WirelessUiLayout.MATRIX_PLATES[i][1]));
        }
        addSlot(new SlotItemHandler(items, MatrixBlockEntity.SLOT_CORE, WirelessUiLayout.MATRIX_CORE_X,
                WirelessUiLayout.MATRIX_CORE_Y));
        addPlayerInventory(inventory, TechUiLayout.INV_X, TechUiLayout.INV_Y, TechUiLayout.HOTBAR_Y);
    }

    private static ItemStackHandler clientItems() {
        return new ItemStackHandler(MACHINE_SLOTS) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return MatrixBlockEntity.isValidItem(slot, stack);
            }

            @Override
            public int getSlotLimit(int slot) {
                return 1;
            }
        };
    }

    /** Abre la pantalla de la matriz (origen {@code be}). */
    public static void open(ServerPlayer player, MatrixBlockEntity be) {
        WirelessView view = buildView(player, WirelessData.get((ServerLevel) be.getLevel()), be);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new MatrixMenu(id, inv, be, view),
                Component.translatable("block.railgunreborn.matrix")), buf -> {
                    buf.writeBlockPos(be.getBlockPos());
                    WirelessView.STREAM_CODEC.encode(buf, view);
                });
    }

    public static WirelessView buildView(Player player, WirelessData data, MatrixBlockEntity be) {
        WirelessNetwork net = data.getNetwork(be.getBlockPos());
        return new WirelessView(net == null ? "" : net.getSsid(), be.getPlacerName(),
                canEdit(player, be.getPlacerName()), "", Optional.empty(), net == null ? 0 : net.getLoad(),
                be.getCapacity(), List.of());
    }

    @Override
    protected WirelessView buildView(ServerLevel level, WirelessData data) {
        return level.getBlockEntity(pos) instanceof MatrixBlockEntity be ? buildView(player, data, be) : getView();
    }

    // --- Datos para la pantalla (de las ranuras) ---

    public int getPlateCount() {
        int count = 0;
        for (int i = 0; i < MatrixBlockEntity.PLATE_SLOTS; i++) {
            if (!items.getStackInSlot(i).isEmpty()) {
                count++;
            }
        }
        return count;
    }

    public int getCoreLevel() {
        return MatrixBlockEntity.tierOf(items.getStackInSlot(MatrixBlockEntity.SLOT_CORE));
    }

    /** Nivel con el que funciona (0 si le falta el núcleo o alguna placa). */
    public int getWorkingTier() {
        return getPlateCount() == MatrixBlockEntity.PLATE_SLOTS ? getCoreLevel() : 0;
    }

    public boolean hasNetwork() {
        return !getView().name().isEmpty();
    }

    @Override
    public boolean stillValid(Player player) {
        return near(player, pos) && (player.level().isClientSide
                || player.level().getBlockEntity(pos) instanceof MatrixBlockEntity);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return quickMove(player, index, MACHINE_SLOTS);
    }
}
