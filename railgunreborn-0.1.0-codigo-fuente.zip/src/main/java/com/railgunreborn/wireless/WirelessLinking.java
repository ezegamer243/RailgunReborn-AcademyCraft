package com.railgunreborn.wireless;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.DeveloperBlock;
import com.railgunreborn.block.WindGenBaseBlock;
import com.railgunreborn.reactor.CategoryReactorPartBlock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * "Current Node" (bus del juego): Mayús + clic derecho con las dos manos vacías en una máquina, generador o Developer
 * del mod abre la pantalla de enlace con un nodo ({@link NodeLinkMenu}). Solo bloques del mod: a los de otros mods no
 * se les puede abrir nuestra pantalla; para ellos queda el comando de operador {@code /railgunreborn wireless link}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class WirelessLinking {
    private WirelessLinking() {
    }

    /**
     * Posición con la que se enlaza el bloque en {@code pos} (el origen en los multibloques Developer y base del
     * generador de viento, el controlador en el reactor), o null si no es un bloque del mod con energía (los nodos y la matriz tampoco cuentan).
     */
    @Nullable
    public static BlockPos linkTarget(Level level, BlockPos pos) {
        if (!level.isLoaded(pos)) {
            return null;
        }
        BlockState state = level.getBlockState(pos);
        Block block = state.getBlock();
        if (!RailgunReborn.MODID.equals(BuiltInRegistries.BLOCK.getKey(block).getNamespace())
                || block instanceof NodeBlock || block instanceof MatrixBlock) {
            return null;
        }
        BlockPos target = pos;
        if (block instanceof DeveloperBlock) {
            target = DeveloperBlock.originOf(pos, state);
        } else if (block instanceof WindGenBaseBlock) {
            target = WindGenBaseBlock.originOf(pos, state);
        } else if (block instanceof CategoryReactorPartBlock) {
            target = CategoryReactorPartBlock.controllerPos(pos, state);
        }
        IEnergyStorage storage = WirelessData.energyAt(level, target);
        return storage != null && WirelessData.autoRole(storage) != null ? target.immutable() : null;
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        if (event.getHand() != InteractionHand.MAIN_HAND || !player.isShiftKeyDown()
                || !player.getMainHandItem().isEmpty() || !player.getOffhandItem().isEmpty()) {
            return;
        }
        BlockPos target = linkTarget(event.getLevel(), event.getPos());
        if (target == null) {
            return;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            NodeLinkMenu.open(serverPlayer, target);
        }
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }
}
