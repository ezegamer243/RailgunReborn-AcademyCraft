package com.railgunreborn.wireless;

import java.util.List;

import com.railgunreborn.energy.EnergyFormat;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** Núcleo de matriz ({@code mat_core_0/1/2}): puesto en la matriz fija su nivel (1, 2 o 3). */
public class MatCoreItem extends Item {
    private final int tier;

    public MatCoreItem(int tier, Properties properties) {
        super(properties);
        this.tier = tier;
    }

    /** 1, 2 o 3 (el subtipo del original + 1). */
    public int getTier() {
        return tier;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.railgunreborn.mat_core.tooltip", tier,
                MatrixBlockEntity.capacityFor(tier), EnergyFormat.format(MatrixBlockEntity.bandwidthFor(tier)),
                String.format(java.util.Locale.ROOT, "%.1f", MatrixBlockEntity.rangeFor(tier)))
                .withStyle(ChatFormatting.GRAY));
    }
}
