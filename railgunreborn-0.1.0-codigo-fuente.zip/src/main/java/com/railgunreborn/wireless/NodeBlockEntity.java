package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ModEnergyStorage;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.SectionPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Nodo inalámbrico: buffer FE (entra y sale por cable hasta su ancho de banda por llamada), 2 ranuras de batería
 * (0: el ítem carga el nodo; 1: el nodo carga el ítem), nombre, contraseña propia (para enlazar generadores y
 * receptores) y quién lo colocó. El reparto con la red y los enlaces lo hace {@link WirelessData} en el tick del nivel.
 */
public class NodeBlockEntity extends BlockEntity {
    public static final int SLOT_INPUT = 0;
    public static final int SLOT_OUTPUT = 1;
    public static final String DEFAULT_NAME = "Unnamed";
    public static final int MAX_NAME_LENGTH = 32;
    /** Cada cuántos ticks se refrescan los estados del bloque (carga y conectado), como el original. */
    public static final int STATE_INTERVAL = 10;

    private final NodeType type;
    private final ModEnergyStorage energy;

    private final ItemStackHandler items = new ItemStackHandler(2) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return BatterySlot.isEnergyItem(stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    private String nodeName = DEFAULT_NAME;
    private String password = "";
    private String placerName = "";
    private int stateTicker;

    public NodeBlockEntity(BlockPos pos, BlockState state) {
        super(WirelessRegistry.NODE_BE.get(), pos, state);
        this.type = state.getBlock() instanceof NodeBlock node ? node.getNodeType() : NodeType.BASIC;
        this.energy = new ModEnergyStorage(type.capacity, type.bandwidth, type.bandwidth, this::setChanged);
    }

    public NodeType getNodeType() {
        return type;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String name) {
        this.nodeName = name == null || name.isBlank() ? DEFAULT_NAME
                : name.substring(0, Math.min(name.length(), MAX_NAME_LENGTH));
        setChanged();
    }

    /** Compara en el servidor; la contraseña del nodo nunca se manda al cliente ni al log. */
    public boolean checkPassword(String attempt) {
        return password.equals(attempt == null ? "" : attempt);
    }

    public void setPassword(String password) {
        this.password = password == null ? "" : password;
        setChanged();
    }

    public String getPlacerName() {
        return placerName;
    }

    public void setPlacerName(String placerName) {
        this.placerName = placerName == null ? "" : placerName;
        setChanged();
    }

    /** Nivel de textura 0-4 como el original: {@code round(4 x llenado)}. */
    public static int energyLevel(int stored, int capacity) {
        return capacity <= 0 ? 0 : (int) Math.min(4, Math.round(4.0 * stored / capacity));
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, NodeBlockEntity be) {
        BatterySlot.dischargeItem(be.items.getStackInSlot(SLOT_INPUT), be.energy, be.type.bandwidth);
        BatterySlot.chargeItem(be.items.getStackInSlot(SLOT_OUTPUT), be.energy, be.type.bandwidth);
        if (++be.stateTicker >= STATE_INTERVAL) {
            be.stateTicker = 0;
            be.refreshState();
        }
    }

    /** Pone {@code energy} y {@code connected} del bloque según el buffer y si el nodo está en una red. */
    public void refreshState() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof NodeBlock)) {
            return;
        }
        boolean connected = WirelessData.get(serverLevel).networkOfNode(worldPosition) != null;
        BlockState updated = state
                .setValue(NodeBlock.ENERGY, energyLevel(energy.getEnergyStored(), energy.getMaxEnergyStored()))
                .setValue(NodeBlock.CONNECTED, connected);
        if (updated != state) {
            level.setBlock(worldPosition, updated, Block.UPDATE_CLIENTS);
        }
    }

    public void dropContents(Level level, BlockPos pos) {
        for (int slot = 0; slot < items.getSlots(); slot++) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(slot));
        }
    }

    /**
     * Nodos en chunks ya cargados a menos de {@code radius} bloques de {@code center}, del más cercano al más lejano,
     * como mucho {@code max} (la lista "Current Node" del original: radio 20, máximo 100). No carga chunks.
     */
    public static List<NodeBlockEntity> findNear(Level level, BlockPos center, double radius, int max) {
        List<NodeBlockEntity> found = new ArrayList<>();
        int r = (int) Math.ceil(radius);
        double radiusSq = radius * radius;
        int minX = SectionPos.blockToSectionCoord(center.getX() - r);
        int maxX = SectionPos.blockToSectionCoord(center.getX() + r);
        int minZ = SectionPos.blockToSectionCoord(center.getZ() - r);
        int maxZ = SectionPos.blockToSectionCoord(center.getZ() + r);
        for (int cx = minX; cx <= maxX; cx++) {
            for (int cz = minZ; cz <= maxZ; cz++) {
                if (!level.hasChunk(cx, cz)) {
                    continue;
                }
                LevelChunk chunk = level.getChunk(cx, cz);
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof NodeBlockEntity node && !node.isRemoved()
                            && node.getBlockPos().distSqr(center) <= radiusSq) {
                        found.add(node);
                    }
                }
            }
        }
        found.sort(Comparator.comparingDouble(n -> n.getBlockPos().distSqr(center)));
        return found.size() > max ? new ArrayList<>(found.subList(0, max)) : found;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        energy.save(tag, "Energy", registries);
        tag.putString("NodeName", nodeName);
        tag.putString("Password", password);
        tag.putString("Placer", placerName);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        energy.load(tag, "Energy", registries);
        nodeName = tag.contains("NodeName") ? tag.getString("NodeName") : DEFAULT_NAME;
        password = tag.getString("Password");
        placerName = tag.getString("Placer");
    }
}
