package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;

/**
 * Una red inalámbrica (energy.md 1.4): la matriz que la sostiene (posición del origen del multibloque), su SSID, su
 * contraseña y los nodos unidos. Solo posiciones: los BlockEntities se buscan en cada tick si su chunk está cargado.
 *
 * <p>La contraseña es solo del juego y se guarda tal cual en los datos del mundo; nunca se escribe en el log ni se
 * muestra en {@code toString}.
 */
public final class WirelessNetwork {
    public static final int MAX_SSID_LENGTH = 32;
    public static final int MAX_PASSWORD_LENGTH = 32;
    /** Colchón interno del reparto (el {@code BUFFER_MAX} del original). */
    public static final int BUFFER_MAX = 2000;

    public static final Codec<WirelessNetwork> CODEC = RecordCodecBuilder.create(i -> i.group(
            BlockPos.CODEC.fieldOf("matrix").forGetter(n -> n.matrix),
            Codec.STRING.fieldOf("ssid").forGetter(n -> n.ssid),
            Codec.STRING.optionalFieldOf("password", "").forGetter(n -> n.password),
            BlockPos.CODEC.listOf().optionalFieldOf("nodes", List.of()).forGetter(n -> List.copyOf(n.nodes)),
            Codec.INT.optionalFieldOf("buffer", 0).forGetter(n -> n.buffer))
            .apply(i, WirelessNetwork::new));

    private final BlockPos matrix;
    private String ssid;
    private String password;
    private final Set<BlockPos> nodes;
    private int buffer;

    public WirelessNetwork(BlockPos matrix, String ssid, String password, List<BlockPos> nodes, int buffer) {
        this.matrix = matrix.immutable();
        this.ssid = ssid;
        this.password = password;
        this.nodes = new LinkedHashSet<>(nodes);
        this.buffer = Math.max(0, Math.min(BUFFER_MAX, buffer));
    }

    public static boolean validSsid(String ssid) {
        return ssid != null && !ssid.isBlank() && ssid.length() <= MAX_SSID_LENGTH;
    }

    public static boolean validPassword(String password) {
        return password != null && password.length() <= MAX_PASSWORD_LENGTH;
    }

    public BlockPos getMatrix() {
        return matrix;
    }

    public String getSsid() {
        return ssid;
    }

    void setSsid(String ssid) {
        this.ssid = ssid;
    }

    /** Solo para comparar en el servidor (y para la pantalla de la matriz de T104, al dueño). */
    public boolean checkPassword(String attempt) {
        return password.equals(attempt == null ? "" : attempt);
    }

    void setPassword(String password) {
        this.password = password;
    }

    /** Nodos unidos (vista de solo lectura, en orden de unión). */
    public Set<BlockPos> getNodes() {
        return Collections.unmodifiableSet(nodes);
    }

    public int getLoad() {
        return nodes.size();
    }

    Set<BlockPos> mutableNodes() {
        return nodes;
    }

    List<BlockPos> nodeSnapshot() {
        return new ArrayList<>(nodes);
    }

    public int getBuffer() {
        return buffer;
    }

    void setBuffer(int buffer) {
        this.buffer = buffer;
    }

    @Override
    public String toString() {
        return "WirelessNetwork[" + ssid + " @ " + matrix.toShortString() + ", " + nodes.size() + " nodes]";
    }
}
