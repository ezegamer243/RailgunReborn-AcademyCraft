package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Menú "Current Node" (sin ranuras) de una máquina, generador o Developer: a qué nodo está enlazada y los nodos en
 * radio 20 (máx. 100, como el original) para enlazarla con la contraseña del nodo. Se abre con Mayús + clic derecho
 * y la mano vacía ({@link WirelessLinking}).
 */
public class NodeLinkMenu extends WirelessMenu {
    /** Cliente. */
    public NodeLinkMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, buf.readBlockPos(), WirelessView.STREAM_CODEC.decode(buf));
    }

    /** Servidor (y cliente). */
    public NodeLinkMenu(int containerId, Inventory inventory, BlockPos user, WirelessView view) {
        super(WirelessRegistry.NODE_LINK_MENU.get(), containerId, inventory, user, view);
    }

    /** Abre la pantalla de enlace de la máquina en {@code user} (ya resuelta con {@link WirelessLinking#linkTarget}). */
    public static void open(ServerPlayer player, BlockPos user) {
        ServerLevel level = player.serverLevel();
        WirelessView view = buildView(level, WirelessData.get(level), user);
        Component title = Component.translatable("gui.railgunreborn.wireless.link.title",
                level.getBlockState(user).getBlock().getName());
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new NodeLinkMenu(id, inv, user, view), title),
                buf -> {
                    buf.writeBlockPos(user);
                    WirelessView.STREAM_CODEC.encode(buf, view);
                });
    }

    public static WirelessView buildView(ServerLevel level, WirelessData data, BlockPos user) {
        BlockPos linked = data.nodeOfUser(user);
        String linkedName = "";
        if (linked != null && level.isLoaded(linked) && level.getBlockEntity(linked) instanceof NodeBlockEntity node) {
            linkedName = node.getNodeName();
        }
        List<WirelessView.Entry> entries = new ArrayList<>();
        for (NodeBlockEntity node : NodeBlockEntity.findNear(level, user, WirelessUiLayout.LINK_RADIUS,
                WirelessUiLayout.LINK_MAX)) {
            NodeLinks links = data.linksOf(node.getBlockPos());
            entries.add(new WirelessView.Entry(node.getBlockPos(), node.getNodeName(),
                    links == null ? 0 : links.getLoad(), node.getNodeType().maxLinks,
                    (int) Math.round(Math.sqrt(node.getBlockPos().distSqr(user))), node.getNodeType().ordinal() + 1));
        }
        return new WirelessView("", "", true, linkedName, Optional.ofNullable(linked), 0, 0, List.copyOf(entries));
    }

    @Override
    protected WirelessView buildView(ServerLevel level, WirelessData data) {
        return buildView(level, data, pos);
    }

    @Override
    public boolean stillValid(Player player) {
        return near(player, pos) && (player.level().isClientSide
                || WirelessLinking.linkTarget(player.level(), pos) != null);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }
}
