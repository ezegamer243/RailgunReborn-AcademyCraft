package com.railgunreborn.wireless;

import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Matriz inalámbrica (origen del multibloque 2x2x2): ranuras para 3 placas de metal de restricción y 1 núcleo. Solo
 * funciona con las 3 placas y un núcleo (como el original); el nivel del núcleo (1-3) da capacidad
 * {@code 8 x nivel} nodos, ancho de banda {@code nivel² x 60} IF/tick y alcance {@code 24 x raíz(nivel)} bloques.
 * La red en sí (SSID, contraseña, nodos) vive en {@link WirelessData}.
 */
public class MatrixBlockEntity extends BlockEntity {
    public static final int PLATE_SLOTS = 3;
    public static final int SLOT_CORE = 3;

    private final ItemStackHandler items = new ItemStackHandler(4) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isValidItem(slot, stack);
        }

        @Override
        public int getSlotLimit(int slot) {
            return 1;
        }

        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
            // El cliente necesita las ranuras para dibujar los escudos (solo con 3 placas y núcleo).
            if (level != null && !level.isClientSide) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_CLIENTS);
            }
        }
    };

    private String placerName = "";

    public MatrixBlockEntity(BlockPos pos, BlockState state) {
        super(WirelessRegistry.MATRIX_BE.get(), pos, state);
    }

    public static int capacityFor(int tier) {
        return 8 * tier;
    }

    public static int bandwidthFor(int tier) {
        return tier * tier * 60;
    }

    public static double rangeFor(int tier) {
        return 24 * Math.sqrt(tier);
    }

    /** Ranuras 0-2: placa de metal de restricción; 3: núcleo. Lo usan también los menús del cliente. */
    public static boolean isValidItem(int slot, ItemStack stack) {
        return slot == SLOT_CORE ? stack.getItem() instanceof MatCoreItem : stack.is(ModItems.CONSTRAINT_PLATE.get());
    }

    /** Nivel 1-3 del núcleo de esa pila (0 si no es un núcleo). */
    public static int tierOf(ItemStack stack) {
        return stack.getItem() instanceof MatCoreItem core ? core.getTier() : 0;
    }

    public ItemStackHandler getItems() {
        return items;
    }

    public int getPlateCount() {
        int count = 0;
        for (int i = 0; i < PLATE_SLOTS; i++) {
            if (!items.getStackInSlot(i).isEmpty()) {
                count++;
            }
        }
        return count;
    }

    /** 0 sin núcleo; 1-3 según el núcleo puesto. */
    public int getCoreLevel() {
        return items.getStackInSlot(SLOT_CORE).getItem() instanceof MatCoreItem core ? core.getTier() : 0;
    }

    public boolean isWorking() {
        return getCoreLevel() > 0 && getPlateCount() == PLATE_SLOTS;
    }

    /** Máximo de nodos (0 si no funciona). */
    public int getCapacity() {
        return isWorking() ? capacityFor(getCoreLevel()) : 0;
    }

    /** IF por tick que la red puede mover (0 si no funciona). */
    public int getBandwidth() {
        return isWorking() ? bandwidthFor(getCoreLevel()) : 0;
    }

    /** Alcance en bloques hasta los nodos (0 si no funciona). */
    public double getRange() {
        return isWorking() ? rangeFor(getCoreLevel()) : 0;
    }

    public String getPlacerName() {
        return placerName;
    }

    public void setPlacerName(String placerName) {
        this.placerName = placerName == null ? "" : placerName;
        setChanged();
    }

    public void dropContents(Level level, BlockPos pos) {
        for (int slot = 0; slot < items.getSlots(); slot++) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(slot));
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.putString("Placer", placerName);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        placerName = tag.getString("Placer");
    }

    /** Ranuras y colocador (nada secreto: SSID y contraseña viven en {@link WirelessData}). */
    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
