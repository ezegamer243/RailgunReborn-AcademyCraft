package com.railgunreborn.wireless;

import net.minecraft.network.chat.Component;

/** Resultado de las operaciones de {@link WirelessData}; cada uno tiene su texto traducido (comandos y pantallas). */
public enum WirelessResult {
    OK,
    /** No hay matriz en esa posición. */
    NO_MATRIX,
    /** La matriz ya tiene red. */
    ALREADY_EXISTS,
    /** SSID vacío o demasiado largo, o contraseña demasiado larga. */
    INVALID_NAME,
    /** La matriz no tiene red (o ninguna red con ese SSID al alcance). */
    NO_NETWORK,
    /** Falta el núcleo o alguna de las 3 placas: capacidad 0. */
    MATRIX_NOT_WORKING,
    WRONG_PASSWORD,
    OUT_OF_RANGE,
    /** La red o el nodo no tienen hueco. */
    FULL,
    /** No hay nodo en esa posición. */
    NO_NODE,
    /** El bloque no tiene energía FE (o no sirve para ese papel: dar o recibir). */
    NOT_ENERGY_BLOCK,
    /** El bloque no estaba enlazado / el nodo no estaba en una red. */
    NOT_LINKED,
    /** Solo quien colocó el bloque (o un operador) puede cambiarlo. */
    NO_PERMISSION,
    /** El jugador está demasiado lejos del bloque (pantallas). */
    TOO_FAR;

    public boolean ok() {
        return this == OK;
    }

    public String translationKey() {
        return "wireless.railgunreborn.result." + name().toLowerCase(java.util.Locale.ROOT);
    }

    public Component message() {
        return Component.translatable(translationKey());
    }
}
