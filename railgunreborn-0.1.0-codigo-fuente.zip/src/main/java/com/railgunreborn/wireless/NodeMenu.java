package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.energy.BatterySlot;
import com.railgunreborn.energy.ContainerDataInts;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Menú del nodo: ranura IN (el ítem carga el nodo), ranura OUT (el nodo carga el ítem) y el inventario. Energía y
 * capacidad por {@link ContainerData} (enteros grandes con {@link ContainerDataInts}); nombre, red actual, enlaces y
 * redes al alcance por la {@link WirelessView}.
 */
public class NodeMenu extends WirelessMenu {
    public static final int MACHINE_SLOTS = 2;
    public static final int DATA_ENERGY = 0;
    public static final int DATA_CAPACITY = DATA_ENERGY + ContainerDataInts.SLOTS;
    public static final int DATA_COUNT = DATA_CAPACITY + ContainerDataInts.SLOTS;

    private final ContainerData data;

    /** Cliente. */
    public NodeMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, buf.readBlockPos(), WirelessView.STREAM_CODEC.decode(buf), clientItems(),
                new SimpleContainerData(DATA_COUNT));
    }

    /** Servidor. */
    public NodeMenu(int containerId, Inventory inventory, NodeBlockEntity be, WirelessView view) {
        this(containerId, inventory, be.getBlockPos(), view, be.getItems(), serverData(be));
    }

    private NodeMenu(int containerId, Inventory inventory, BlockPos pos, WirelessView view, IItemHandler items,
            ContainerData data) {
        super(WirelessRegistry.NODE_MENU.get(), containerId, inventory, pos, view);
        this.data = data;
        addSlot(new SlotItemHandler(items, NodeBlockEntity.SLOT_INPUT, WirelessUiLayout.NODE_IN_X,
                WirelessUiLayout.NODE_IN_Y));
        addSlot(new SlotItemHandler(items, NodeBlockEntity.SLOT_OUTPUT, WirelessUiLayout.NODE_OUT_X,
                WirelessUiLayout.NODE_OUT_Y));
        addPlayerInventory(inventory, TechUiLayout.INV_X, TechUiLayout.INV_Y, TechUiLayout.HOTBAR_Y);
        addDataSlots(data);
    }

    private static ItemStackHandler clientItems() {
        return new ItemStackHandler(MACHINE_SLOTS) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return BatterySlot.isEnergyItem(stack);
            }
        };
    }

    private static ContainerData serverData(NodeBlockEntity be) {
        return new ContainerData() {
            @Override
            public int get(int index) {
                int value = index < DATA_CAPACITY ? be.getEnergy().getEnergyStored()
                        : be.getEnergy().getMaxEnergyStored();
                return ContainerDataInts.part(value, index % ContainerDataInts.SLOTS);
            }

            @Override
            public void set(int index, int value) {
            }

            @Override
            public int getCount() {
                return DATA_COUNT;
            }
        };
    }

    public static void open(ServerPlayer player, NodeBlockEntity be) {
        WirelessView view = buildView(player, (ServerLevel) be.getLevel(), WirelessData.get((ServerLevel) be.getLevel()),
                be);
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new NodeMenu(id, inv, be, view),
                be.getBlockState().getBlock().getName()), buf -> {
                    buf.writeBlockPos(be.getBlockPos());
                    WirelessView.STREAM_CODEC.encode(buf, view);
                });
    }

    public static WirelessView buildView(Player player, ServerLevel level, WirelessData data, NodeBlockEntity be) {
        BlockPos nodePos = be.getBlockPos();
        WirelessNetwork current = data.networkOfNode(nodePos);
        NodeLinks links = data.linksOf(nodePos);
        List<WirelessView.Entry> entries = new ArrayList<>();
        for (WirelessNetwork net : data.networksInRange(level, nodePos)) {
            if (entries.size() >= WirelessView.MAX_ENTRIES) {
                break;
            }
            MatrixBlockEntity matrix = (MatrixBlockEntity) level.getBlockEntity(net.getMatrix());
            entries.add(new WirelessView.Entry(net.getMatrix(), net.getSsid(), net.getLoad(), matrix.getCapacity(),
                    (int) Math.round(Math.sqrt(net.getMatrix().distSqr(nodePos))), matrix.getCoreLevel()));
        }
        return new WirelessView(be.getNodeName(), be.getPlacerName(), canEdit(player, be.getPlacerName()),
                current == null ? "" : current.getSsid(),
                current == null ? Optional.empty() : Optional.of(current.getMatrix()),
                links == null ? 0 : links.getLoad(), be.getNodeType().maxLinks, List.copyOf(entries));
    }

    @Override
    protected WirelessView buildView(ServerLevel level, WirelessData data) {
        return level.getBlockEntity(pos) instanceof NodeBlockEntity be ? buildView(player, level, data, be)
                : getView();
    }

    public int getEnergy() {
        return ContainerDataInts.get(data, DATA_ENERGY);
    }

    public int getCapacity() {
        return ContainerDataInts.get(data, DATA_CAPACITY);
    }

    @Override
    public boolean stillValid(Player player) {
        return near(player, pos) && (player.level().isClientSide
                || player.level().getBlockEntity(pos) instanceof NodeBlockEntity);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return quickMove(player, index, MACHINE_SLOTS);
    }
}
