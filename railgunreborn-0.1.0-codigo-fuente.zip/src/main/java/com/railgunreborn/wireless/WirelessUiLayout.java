package com.railgunreborn.wireless;

import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.block.TechUiLayout.Rect;

/**
 * Medidas de las pantallas inalámbricas (sin clases de Minecraft, las comprueba {@code WirelessUiLayoutTest}).
 * Matriz y nodo: panel principal de 176x187 como las máquinas (arte {@code ui_matrix}/{@code ui_node} del original,
 * ranuras centradas en sus cajas, inventario de {@link TechUiLayout}) y un panel lateral a la derecha con los textos,
 * campos y botones. Coordenadas del panel lateral relativas a su esquina; las del principal, a la GUI.
 */
public final class WirelessUiLayout {
    public static final int MAIN_W = TechUiLayout.WIDTH;
    public static final int HEIGHT = TechUiLayout.HEIGHT;
    public static final int SIDE_X = MAIN_W + 4;
    public static final int SIDE_W = 150;
    public static final int TOTAL_W = SIDE_X + SIDE_W;

    // --- Matriz: placas arriba, abajo-izquierda, abajo-derecha y núcleo en medio (iconos del arte) ---
    public static final int[][] MATRIX_PLATES = { { 80, 11 }, { 55, 60 }, { 106, 60 } };
    public static final int MATRIX_CORE_X = 80;
    public static final int MATRIX_CORE_Y = 36;
    /** Recuadro grande del arte de la matriz. */
    public static final Rect MATRIX_ART_BOX = new Rect(41, 6, 95, 74);
    /** Línea de mensajes bajo el arte. */
    public static final Rect MAIN_MESSAGE = new Rect(6, 84, 164, 18);

    // Panel lateral de la matriz.
    public static final int MATRIX_INFO_Y = 20;
    public static final int LINE_H = 12;
    public static final Rect MATRIX_SSID_FIELD = new Rect(8, 98, 134, 12);
    public static final Rect MATRIX_PASSWORD_FIELD = new Rect(8, 128, 134, 12);
    public static final Rect MATRIX_BUTTON = new Rect(8, 148, 134, 18);

    // --- Nodo: ranura IN y OUT en las cajas del arte, recuadro central con nombre y energía ---
    public static final int NODE_IN_X = 44;
    public static final int NODE_IN_Y = 10;
    public static final int NODE_OUT_X = 44;
    public static final int NODE_OUT_Y = 80;
    public static final Rect NODE_CENTER_BOX = new Rect(40, 33, 96, 40);
    public static final Rect NODE_ENERGY_BAR = new Rect(48, 50, 80, 6);
    public static final Rect NODE_MESSAGE = new Rect(76, 80, 96, 22);

    // Panel lateral del nodo.
    public static final Rect NODE_NAME_FIELD = new Rect(52, 6, 90, 12);
    public static final Rect NODE_PASSWORD_FIELD = new Rect(52, 22, 90, 12);
    public static final Rect NODE_SAVE_BUTTON = new Rect(8, 38, 60, 14);
    public static final Rect NODE_LEAVE_BUTTON = new Rect(100, 58, 42, 14);
    public static final Rect NODE_LIST = new Rect(8, 90, 134, 48);
    public static final Rect NODE_JOIN_PASSWORD_FIELD = new Rect(52, 142, 90, 12);
    public static final Rect NODE_JOIN_BUTTON = new Rect(8, 160, 134, 16);

    // --- Enlace "Current Node": un solo panel sin ranuras ---
    public static final int LINK_W = 200;
    public static final int LINK_H = 200;
    public static final Rect LINK_UNLINK_BUTTON = new Rect(8, 36, 60, 14);
    public static final Rect LINK_LIST = new Rect(8, 70, 184, 72);
    public static final Rect LINK_PASSWORD_FIELD = new Rect(60, 148, 132, 12);
    public static final Rect LINK_BUTTON = new Rect(8, 164, 184, 16);
    public static final Rect LINK_MESSAGE = new Rect(8, 184, 184, 12);

    public static final int ROW_H = 12;
    /** Radio y máximo de la lista "Current Node" (como el original). */
    public static final double LINK_RADIUS = 20;
    public static final int LINK_MAX = 100;

    private WirelessUiLayout() {
    }

    public static int rows(Rect list) {
        return list.h() / ROW_H;
    }
}
