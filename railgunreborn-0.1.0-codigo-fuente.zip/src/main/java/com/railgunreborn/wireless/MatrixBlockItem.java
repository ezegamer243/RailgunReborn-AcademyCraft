package com.railgunreborn.wireless;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;

/** Ítem de la matriz: al colocar pone las 8 partes (la validación está en el bloque). */
public class MatrixBlockItem extends BlockItem {
    private final MatrixBlock matrixBlock;

    public MatrixBlockItem(MatrixBlock block, Properties properties) {
        super(block, properties);
        this.matrixBlock = block;
    }

    @Override
    protected boolean placeBlock(BlockPlaceContext context, BlockState state) {
        matrixBlock.place(context.getLevel(), context.getClickedPos());
        return true;
    }
}
