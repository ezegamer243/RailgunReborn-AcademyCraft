package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.RailgunReborn;

import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Estado de la red inalámbrica de una dimensión (energy.md 1.4, {@code WiWorldData} del original): las redes (por
 * posición del origen de su matriz) y los enlaces de cada nodo con sus generadores y receptores. Se guarda con los
 * datos del mundo de esa dimensión. Todo son posiciones; los BlockEntities y capacidades se buscan en cada tick solo
 * si el chunk está cargado (nunca se fuerzan chunks): lo que está descargado se salta y lo que ya no existe se limpia.
 *
 * <p>Las operaciones devuelven un {@link WirelessResult}; son la API para las pantallas de T104 y los comandos.
 * Las contraseñas solo se comparan aquí, en el servidor.
 */
public final class WirelessData extends SavedData {
    public static final String NAME = RailgunReborn.MODID + "_wireless";

    public static final Codec<WirelessData> CODEC = RecordCodecBuilder.create(i -> i.group(
            WirelessNetwork.CODEC.listOf().optionalFieldOf("networks", List.of())
                    .forGetter(d -> List.copyOf(d.networks.values())),
            NodeLinks.CODEC.listOf().optionalFieldOf("links", List.of())
                    .forGetter(d -> List.copyOf(d.links.values())))
            .apply(i, WirelessData::new));

    private static final SavedData.Factory<WirelessData> FACTORY = new SavedData.Factory<>(WirelessData::new,
            WirelessData::load, null);

    /** Red por posición de la matriz (origen). */
    private final Map<BlockPos, WirelessNetwork> networks = new LinkedHashMap<>();
    /** Índice nodo -> matriz de su red. */
    private final Map<BlockPos, BlockPos> nodeNetwork = new HashMap<>();
    /** Enlaces por posición del nodo. */
    private final Map<BlockPos, NodeLinks> links = new LinkedHashMap<>();
    /** Índice usuario (generador o receptor) -> nodo. */
    private final Map<BlockPos, BlockPos> userNode = new HashMap<>();

    public WirelessData() {
    }

    public WirelessData(List<WirelessNetwork> networks, List<NodeLinks> links) {
        for (WirelessNetwork net : networks) {
            if (this.networks.containsKey(net.getMatrix())) {
                continue;
            }
            this.networks.put(net.getMatrix(), net);
            // Un nodo está en una sola red: si unos datos corruptos lo repiten, gana la primera.
            net.mutableNodes().removeIf(node -> nodeNetwork.putIfAbsent(node, net.getMatrix()) != null);
        }
        for (NodeLinks link : links) {
            if (this.links.containsKey(link.getNode())) {
                continue;
            }
            this.links.put(link.getNode(), link);
            for (BlockPos user : link.generatorSnapshot()) {
                if (userNode.putIfAbsent(user, link.getNode()) != null) {
                    link.remove(user);
                }
            }
            for (BlockPos user : link.receiverSnapshot()) {
                if (userNode.putIfAbsent(user, link.getNode()) != null) {
                    link.remove(user);
                }
            }
        }
    }

    /** Los datos de esa dimensión (se crean vacíos la primera vez). */
    public static WirelessData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, NAME);
    }

    // --- Guardado ---

    public static WirelessData load(CompoundTag tag, HolderLookup.Provider registries) {
        return CODEC.parse(registries.createSerializationContext(NbtOps.INSTANCE), tag.get("data"))
                .resultOrPartial(error -> RailgunReborn.LOGGER.warn("Could not read wireless network data"))
                .orElseGet(WirelessData::new);
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        Tag encoded = CODEC.encodeStart(registries.createSerializationContext(NbtOps.INSTANCE), this)
                .resultOrPartial(error -> RailgunReborn.LOGGER.warn("Could not save wireless network data"))
                .orElse(null);
        if (encoded != null) {
            tag.put("data", encoded);
        }
        return tag;
    }

    // --- Consultas ---

    public Collection<WirelessNetwork> getNetworks() {
        return Collections.unmodifiableCollection(networks.values());
    }

    @Nullable
    public WirelessNetwork getNetwork(BlockPos matrix) {
        return networks.get(matrix);
    }

    @Nullable
    public WirelessNetwork networkOfNode(BlockPos node) {
        BlockPos matrix = nodeNetwork.get(node);
        return matrix == null ? null : networks.get(matrix);
    }

    @Nullable
    public NodeLinks linksOf(BlockPos node) {
        return links.get(node);
    }

    /** Nodo al que está enlazado un generador o receptor, o null. */
    @Nullable
    public BlockPos nodeOfUser(BlockPos user) {
        return userNode.get(user);
    }

    /**
     * Redes cuya matriz (cargada y funcionando) tiene a {@code node} dentro de su alcance, de la más cercana a la más
     * lejana: lo que la pantalla del nodo ofrecerá para unirse.
     */
    public List<WirelessNetwork> networksInRange(Level level, BlockPos node) {
        List<WirelessNetwork> found = new ArrayList<>();
        for (WirelessNetwork net : networks.values()) {
            if (level.isLoaded(net.getMatrix())
                    && level.getBlockEntity(net.getMatrix()) instanceof MatrixBlockEntity matrix
                    && inRange(node, net.getMatrix(), matrix.getRange())) {
                found.add(net);
            }
        }
        found.sort(java.util.Comparator.comparingDouble(n -> n.getMatrix().distSqr(node)));
        return found;
    }

    public static boolean inRange(BlockPos a, BlockPos b, double range) {
        return range > 0 && a.distSqr(b) <= range * range;
    }

    // --- Redes ---

    /** Crea la red de la matriz que ocupa {@code matrixPos} (cualquier parte). */
    public WirelessResult createNetwork(Level level, BlockPos matrixPos, String ssid, String password) {
        BlockPos origin = MatrixBlock.originAt(level, matrixPos);
        if (origin == null || !(level.getBlockEntity(origin) instanceof MatrixBlockEntity)) {
            return WirelessResult.NO_MATRIX;
        }
        if (!WirelessNetwork.validSsid(ssid) || !WirelessNetwork.validPassword(password)) {
            return WirelessResult.INVALID_NAME;
        }
        if (networks.containsKey(origin)) {
            return WirelessResult.ALREADY_EXISTS;
        }
        networks.put(origin, new WirelessNetwork(origin, ssid, password, List.of(), 0));
        setDirty();
        return WirelessResult.OK;
    }

    /**
     * Cambia SSID y contraseña de una red existente (pantalla de la matriz, T104). {@code password} null deja la
     * contraseña actual (la pantalla no la conoce: nunca se manda al cliente).
     */
    public WirelessResult configureNetwork(BlockPos matrix, String ssid, @Nullable String password) {
        WirelessNetwork net = networks.get(matrix);
        if (net == null) {
            return WirelessResult.NO_NETWORK;
        }
        if (!WirelessNetwork.validSsid(ssid) || (password != null && !WirelessNetwork.validPassword(password))) {
            return WirelessResult.INVALID_NAME;
        }
        net.setSsid(ssid);
        if (password != null) {
            net.setPassword(password);
        }
        setDirty();
        return WirelessResult.OK;
    }

    /** Borra la red de esa matriz (rota o desmontada); sus nodos quedan sueltos con sus enlaces. */
    public boolean dissolveNetwork(BlockPos matrix) {
        WirelessNetwork net = networks.remove(matrix);
        if (net == null) {
            return false;
        }
        for (BlockPos node : net.getNodes()) {
            nodeNetwork.remove(node);
        }
        setDirty();
        return true;
    }

    /** Une el nodo a la red de {@code matrix} con su contraseña; si estaba en otra red, la deja. */
    public WirelessResult joinNetwork(Level level, BlockPos node, BlockPos matrix, String password) {
        // isLoaded antes de cada getBlockEntity: en el servidor, pedir un BE de un chunk descargado lo cargaría.
        if (!level.isLoaded(node) || !(level.getBlockEntity(node) instanceof NodeBlockEntity)) {
            return WirelessResult.NO_NODE;
        }
        WirelessNetwork net = networks.get(matrix);
        if (net == null) {
            return WirelessResult.NO_NETWORK;
        }
        if (!level.isLoaded(matrix) || !(level.getBlockEntity(matrix) instanceof MatrixBlockEntity matrixBe)) {
            return WirelessResult.NO_MATRIX;
        }
        if (!matrixBe.isWorking()) {
            return WirelessResult.MATRIX_NOT_WORKING;
        }
        if (!net.checkPassword(password)) {
            return WirelessResult.WRONG_PASSWORD;
        }
        if (!inRange(node, matrix, matrixBe.getRange())) {
            return WirelessResult.OUT_OF_RANGE;
        }
        if (net.getNodes().contains(node)) {
            return WirelessResult.OK;
        }
        if (net.getLoad() >= matrixBe.getCapacity()) {
            return WirelessResult.FULL;
        }
        leaveNetwork(node);
        net.mutableNodes().add(node.immutable());
        nodeNetwork.put(node.immutable(), matrix);
        setDirty();
        return WirelessResult.OK;
    }

    /**
     * Une el nodo a la red con ese SSID cuya matriz está más cerca (y lo tiene al alcance). Para el comando de
     * depuración; las pantallas eligen la red de {@link #networksInRange}.
     */
    public WirelessResult joinNetworkBySsid(Level level, BlockPos node, String ssid, String password) {
        boolean anyWithSsid = false;
        for (WirelessNetwork net : networksInRange(level, node)) {
            if (net.getSsid().equals(ssid)) {
                return joinNetwork(level, node, net.getMatrix(), password);
            }
        }
        for (WirelessNetwork net : networks.values()) {
            anyWithSsid |= net.getSsid().equals(ssid);
        }
        return anyWithSsid ? WirelessResult.OUT_OF_RANGE : WirelessResult.NO_NETWORK;
    }

    public WirelessResult leaveNetwork(BlockPos node) {
        BlockPos matrix = nodeNetwork.remove(node);
        if (matrix == null) {
            return WirelessResult.NOT_LINKED;
        }
        WirelessNetwork net = networks.get(matrix);
        if (net != null) {
            net.mutableNodes().remove(node);
        }
        setDirty();
        return WirelessResult.OK;
    }

    // --- Enlaces nodo <-> usuarios ---

    /** Papel por defecto de un bloque FE: generador si solo da, receptor si recibe; null si no sirve. */
    @Nullable
    public static NodeLinks.Role autoRole(IEnergyStorage storage) {
        if (storage.canExtract() && !storage.canReceive()) {
            return NodeLinks.Role.GENERATOR;
        }
        return storage.canReceive() ? NodeLinks.Role.RECEIVER : null;
    }

    @Nullable
    public static IEnergyStorage energyAt(Level level, BlockPos pos) {
        return level.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
    }

    /** Enlaza con el papel automático ({@link #autoRole}). */
    public WirelessResult linkUser(Level level, BlockPos user, BlockPos node, String password) {
        IEnergyStorage storage = level.isLoaded(user) ? energyAt(level, user) : null;
        NodeLinks.Role role = storage == null ? null : autoRole(storage);
        if (role == null) {
            return level.isLoaded(node) && level.getBlockEntity(node) instanceof NodeBlockEntity
                    ? WirelessResult.NOT_ENERGY_BLOCK : WirelessResult.NO_NODE;
        }
        return linkUser(level, user, node, password, role);
    }

    /**
     * Enlaza un generador o receptor (cualquier bloque con FE) al nodo, con la contraseña del nodo. Debe estar al
     * alcance del nodo y el nodo debe tener hueco. Si ya estaba enlazado a otro nodo, se pasa a este.
     */
    public WirelessResult linkUser(Level level, BlockPos user, BlockPos node, String password, NodeLinks.Role role) {
        if (!level.isLoaded(node) || !(level.getBlockEntity(node) instanceof NodeBlockEntity nodeBe)) {
            return WirelessResult.NO_NODE;
        }
        IEnergyStorage storage = level.isLoaded(user) ? energyAt(level, user) : null;
        if (user.equals(node) || storage == null
                || (role == NodeLinks.Role.GENERATOR ? !storage.canExtract() : !storage.canReceive())) {
            return WirelessResult.NOT_ENERGY_BLOCK;
        }
        if (!nodeBe.checkPassword(password)) {
            return WirelessResult.WRONG_PASSWORD;
        }
        if (!inRange(user, node, nodeBe.getNodeType().range)) {
            return WirelessResult.OUT_OF_RANGE;
        }
        NodeLinks existing = links.get(node);
        boolean already = node.equals(userNode.get(user));
        if (!already && existing != null && existing.getLoad() >= nodeBe.getNodeType().maxLinks) {
            return WirelessResult.FULL;
        }
        unlinkUser(user);
        links.computeIfAbsent(node.immutable(), n -> new NodeLinks(n, List.of(), List.of())).add(user, role);
        userNode.put(user.immutable(), node.immutable());
        setDirty();
        return WirelessResult.OK;
    }

    public WirelessResult unlinkUser(BlockPos user) {
        BlockPos node = userNode.remove(user);
        if (node == null) {
            return WirelessResult.NOT_LINKED;
        }
        NodeLinks link = links.get(node);
        if (link != null) {
            link.remove(user);
            if (link.isEmpty()) {
                links.remove(node);
            }
        }
        setDirty();
        return WirelessResult.OK;
    }

    /** El nodo desapareció: fuera de su red y sin enlaces. */
    public void removeNode(BlockPos node) {
        leaveNetwork(node);
        NodeLinks link = links.remove(node);
        if (link != null) {
            for (BlockPos user : link.generatorSnapshot()) {
                userNode.remove(user);
            }
            for (BlockPos user : link.receiverSnapshot()) {
                userNode.remove(user);
            }
            setDirty();
        }
    }

    /**
     * Solo para GameTests: mete un enlace sin comprobar nada (p. ej. hacia un chunk que no está cargado, que no se
     * puede enlazar por la vía normal).
     */
    public void forceLink(BlockPos user, BlockPos node, NodeLinks.Role role) {
        unlinkUser(user);
        links.computeIfAbsent(node.immutable(), n -> new NodeLinks(n, List.of(), List.of())).add(user, role);
        userNode.put(user.immutable(), node.immutable());
        setDirty();
    }

    // --- Tick ---

    /** Un tick del servidor en esa dimensión: primero se equilibra cada red, luego cada nodo con sus enlaces. */
    public void tick(ServerLevel level) {
        if (networks.isEmpty() && links.isEmpty()) {
            return;
        }
        for (WirelessNetwork net : new ArrayList<>(networks.values())) {
            tickNetwork(level, net);
        }
        for (NodeLinks link : new ArrayList<>(links.values())) {
            tickLinks(level, link);
        }
    }

    private void tickNetwork(ServerLevel level, WirelessNetwork net) {
        BlockPos matrixPos = net.getMatrix();
        if (!level.isLoaded(matrixPos)) {
            return;
        }
        if (!(level.getBlockEntity(matrixPos) instanceof MatrixBlockEntity matrix)) {
            dissolveNetwork(matrixPos);
            return;
        }
        int bandwidth = matrix.getBandwidth();
        if (bandwidth <= 0) {
            return;
        }
        List<NodeBlockEntity> nodes = new ArrayList<>();
        for (BlockPos pos : net.nodeSnapshot()) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            if (level.getBlockEntity(pos) instanceof NodeBlockEntity node) {
                nodes.add(node);
            } else {
                leaveNetwork(pos);
            }
        }
        if (nodes.isEmpty()) {
            return;
        }
        Util.shuffle(nodes, level.random);
        int n = nodes.size();
        int[] energy = new int[n];
        int[] capacity = new int[n];
        int[] nodeBandwidth = new int[n];
        for (int i = 0; i < n; i++) {
            NodeBlockEntity node = nodes.get(i);
            energy[i] = node.getEnergy().getEnergyStored();
            capacity[i] = node.getEnergy().getMaxEnergyStored();
            nodeBandwidth[i] = node.getNodeType().bandwidth;
        }
        int buffer = WirelessBalance.balance(energy, capacity, nodeBandwidth, bandwidth, net.getBuffer());
        for (int i = 0; i < n; i++) {
            nodes.get(i).getEnergy().setEnergy(energy[i]);
        }
        if (buffer != net.getBuffer()) {
            net.setBuffer(buffer);
            setDirty();
        }
    }

    /**
     * Como {@code NodeConn} del original: el nodo saca de sus generadores hasta su ancho de banda (y su hueco) y da a
     * sus receptores hasta su ancho de banda (y lo que tenga), en orden barajado. Los topes propios del generador o
     * del receptor los pone su capacidad FE ({@code maxExtract}/{@code maxReceive}).
     */
    private void tickLinks(ServerLevel level, NodeLinks link) {
        BlockPos nodePos = link.getNode();
        if (!level.isLoaded(nodePos)) {
            return;
        }
        if (!(level.getBlockEntity(nodePos) instanceof NodeBlockEntity node)) {
            removeNode(nodePos);
            return;
        }
        int bandwidth = node.getNodeType().bandwidth;
        int left = bandwidth;
        List<BlockPos> generators = link.generatorSnapshot();
        Util.shuffle(generators, level.random);
        for (BlockPos pos : generators) {
            int wanted = Math.min(left, node.getEnergy().getSpace());
            if (wanted <= 0) {
                break;
            }
            IEnergyStorage gen = usableUser(level, pos);
            if (gen != null) {
                int got = gen.extractEnergy(wanted, false);
                node.getEnergy().addEnergy(got, false);
                left -= got;
            }
        }
        left = bandwidth;
        List<BlockPos> receivers = link.receiverSnapshot();
        Util.shuffle(receivers, level.random);
        for (BlockPos pos : receivers) {
            int offered = Math.min(left, node.getEnergy().getEnergyStored());
            if (offered <= 0) {
                break;
            }
            IEnergyStorage receiver = usableUser(level, pos);
            if (receiver != null) {
                int accepted = receiver.receiveEnergy(offered, false);
                node.getEnergy().consumeEnergy(accepted, false);
                left -= accepted;
            }
        }
    }

    /** Capacidad FE del usuario si su chunk está cargado; si está cargado y ya no tiene FE, se desenlaza. */
    @Nullable
    private IEnergyStorage usableUser(ServerLevel level, BlockPos pos) {
        if (!level.isLoaded(pos)) {
            return null;
        }
        IEnergyStorage storage = energyAt(level, pos);
        if (storage == null) {
            unlinkUser(pos);
        }
        return storage;
    }
}
