package com.railgunreborn.wireless;

import com.railgunreborn.network.WirelessActionPayload;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Servidor: las acciones de las pantallas inalámbricas ({@link WirelessActionPayload}). Todo se valida aquí:
 * distancia del jugador al bloque, permisos (dueño u operador para matriz y nodo), longitudes (SSID/nombre 1-32,
 * contraseña hasta 32) y contraseñas, que solo se comparan en el servidor y nunca se escriben en el log.
 *
 * <p>Campo de contraseña vacío al configurar = no cambiarla (la pantalla no conoce la actual).
 */
public final class WirelessActions {
    public enum Action {
        /** pos = matriz (cualquier parte); a = SSID, b = contraseña. Crea la red o la actualiza. */
        MATRIX_CONFIGURE,
        /** pos = nodo; a = nombre, b = contraseña del nodo. */
        NODE_CONFIGURE,
        /** pos = nodo, target = matriz; a = contraseña de la red. */
        NODE_JOIN,
        /** pos = nodo. */
        NODE_LEAVE,
        /** pos = máquina, target = nodo; a = contraseña del nodo. */
        USER_LINK,
        /** pos = máquina. */
        USER_UNLINK
    }

    private WirelessActions() {
    }

    /** Desde el paquete: ejecuta con los datos de la dimensión y devuelve vista + resultado a la pantalla abierta. */
    public static WirelessResult handle(ServerPlayer player, WirelessActionPayload payload) {
        WirelessResult result = handle(player, payload, WirelessData.get(player.serverLevel()));
        if (player.containerMenu instanceof WirelessMenu menu) {
            menu.sendView(result);
        } else {
            player.displayClientMessage(result.message(), true);
        }
        return result;
    }

    /** La lógica, con un {@link WirelessData} dado (los GameTests usan uno propio). */
    public static WirelessResult handle(Player player, WirelessActionPayload payload, WirelessData data) {
        if (!(player.level() instanceof ServerLevel level)) {
            return WirelessResult.NO_PERMISSION;
        }
        BlockPos pos = payload.pos();
        if (!level.isLoaded(pos) || !WirelessMenu.near(player, pos)) {
            return WirelessResult.TOO_FAR;
        }
        String a = payload.a();
        String b = payload.b();
        return switch (payload.action()) {
            case MATRIX_CONFIGURE -> configureMatrix(player, level, data, pos, a, b);
            case NODE_CONFIGURE -> withNode(player, level, pos, node -> configureNode(node, a, b));
            case NODE_JOIN -> withNode(player, level, pos, node -> payload.target().map(
                    matrix -> data.joinNetwork(level, pos, matrix, a)).orElse(WirelessResult.NO_NETWORK));
            case NODE_LEAVE -> withNode(player, level, pos, node -> data.leaveNetwork(pos));
            case USER_LINK -> {
                BlockPos user = userPos(level, pos);
                yield payload.target().map(node -> data.linkUser(level, user, node, a))
                        .orElse(WirelessResult.NO_NODE);
            }
            case USER_UNLINK -> data.unlinkUser(userPos(level, pos));
        };
    }

    private static WirelessResult configureMatrix(Player player, ServerLevel level, WirelessData data, BlockPos pos,
            String ssid, String password) {
        MatrixBlockEntity be = MatrixBlock.entityAt(level, pos);
        if (be == null) {
            return WirelessResult.NO_MATRIX;
        }
        if (!WirelessMenu.canEdit(player, be.getPlacerName())) {
            return WirelessResult.NO_PERMISSION;
        }
        if (!WirelessNetwork.validSsid(ssid) || !WirelessNetwork.validPassword(password)) {
            return WirelessResult.INVALID_NAME;
        }
        if (data.getNetwork(be.getBlockPos()) == null) {
            return data.createNetwork(level, be.getBlockPos(), ssid, password);
        }
        return data.configureNetwork(be.getBlockPos(), ssid, password.isEmpty() ? null : password);
    }

    private static WirelessResult configureNode(NodeBlockEntity node, String name, String password) {
        if (name == null || name.isBlank() || name.length() > NodeBlockEntity.MAX_NAME_LENGTH
                || !WirelessNetwork.validPassword(password)) {
            return WirelessResult.INVALID_NAME;
        }
        node.setNodeName(name);
        if (!password.isEmpty()) {
            node.setPassword(password);
        }
        return WirelessResult.OK;
    }

    private static WirelessResult withNode(Player player, ServerLevel level, BlockPos pos,
            java.util.function.Function<NodeBlockEntity, WirelessResult> action) {
        if (!(level.getBlockEntity(pos) instanceof NodeBlockEntity node)) {
            return WirelessResult.NO_NODE;
        }
        if (!WirelessMenu.canEdit(player, node.getPlacerName())) {
            return WirelessResult.NO_PERMISSION;
        }
        return action.apply(node);
    }

    /** La parte de un multibloque del mod se enlaza por su origen; cualquier otro bloque, por su posición. */
    private static BlockPos userPos(ServerLevel level, BlockPos pos) {
        BlockPos target = WirelessLinking.linkTarget(level, pos);
        return target != null ? target : pos;
    }
}
