package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * Lo que una pantalla inalámbrica (matriz, nodo, enlace "Current Node") muestra y el servidor le manda: nombres,
 * dueño, permisos y la lista de redes o nodos al alcance. <b>Nunca lleva contraseñas.</b>
 *
 * <ul>
 * <li>Matriz: {@code name} = SSID ("" sin red), {@code load/max} = nodos de la red / capacidad.</li>
 * <li>Nodo: {@code name} = nombre del nodo, {@code current} = SSID de su red, {@code load/max} = enlaces,
 * {@code entries} = redes al alcance (pos = matriz).</li>
 * <li>Enlace: {@code current} = nombre del nodo enlazado, {@code entries} = nodos en radio 20.</li>
 * </ul>
 */
public record WirelessView(String name, String owner, boolean canEdit, String current, Optional<BlockPos> currentPos,
        int load, int max, List<Entry> entries) {
    /** Tope de texto en red (los límites reales, 32, los valida el servidor). */
    public static final int MAX_TEXT = 64;
    public static final int MAX_ENTRIES = 100;

    public static final WirelessView EMPTY = new WirelessView("", "", false, "", Optional.empty(), 0, 0, List.of());

    /** Una fila de la lista: red (matriz) o nodo. {@code tier} = nivel del núcleo o del nodo. */
    public record Entry(BlockPos pos, String name, int load, int max, int distance, int tier) {
        public static final StreamCodec<ByteBuf, Entry> STREAM_CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, Entry::pos,
                ByteBufCodecs.stringUtf8(MAX_TEXT), Entry::name,
                ByteBufCodecs.VAR_INT, Entry::load,
                ByteBufCodecs.VAR_INT, Entry::max,
                ByteBufCodecs.VAR_INT, Entry::distance,
                ByteBufCodecs.VAR_INT, Entry::tier,
                Entry::new);
    }

    public static final StreamCodec<ByteBuf, WirelessView> STREAM_CODEC = StreamCodec.of(WirelessView::encode,
            WirelessView::decode);

    private static final StreamCodec<ByteBuf, String> TEXT = ByteBufCodecs.stringUtf8(MAX_TEXT);
    private static final StreamCodec<ByteBuf, Optional<BlockPos>> OPT_POS = ByteBufCodecs
            .optional(BlockPos.STREAM_CODEC);

    private static void encode(ByteBuf buf, WirelessView view) {
        TEXT.encode(buf, clip(view.name));
        TEXT.encode(buf, clip(view.owner));
        ByteBufCodecs.BOOL.encode(buf, view.canEdit);
        TEXT.encode(buf, clip(view.current));
        OPT_POS.encode(buf, view.currentPos);
        ByteBufCodecs.VAR_INT.encode(buf, view.load);
        ByteBufCodecs.VAR_INT.encode(buf, view.max);
        int count = Math.min(MAX_ENTRIES, view.entries.size());
        ByteBufCodecs.VAR_INT.encode(buf, count);
        for (int i = 0; i < count; i++) {
            Entry e = view.entries.get(i);
            Entry.STREAM_CODEC.encode(buf, new Entry(e.pos, clip(e.name), e.load, e.max, e.distance, e.tier));
        }
    }

    private static WirelessView decode(ByteBuf buf) {
        String name = TEXT.decode(buf);
        String owner = TEXT.decode(buf);
        boolean canEdit = ByteBufCodecs.BOOL.decode(buf);
        String current = TEXT.decode(buf);
        Optional<BlockPos> currentPos = OPT_POS.decode(buf);
        int load = ByteBufCodecs.VAR_INT.decode(buf);
        int max = ByteBufCodecs.VAR_INT.decode(buf);
        int count = Math.min(MAX_ENTRIES, ByteBufCodecs.VAR_INT.decode(buf));
        List<Entry> entries = new ArrayList<>(Math.max(0, count));
        for (int i = 0; i < count; i++) {
            entries.add(Entry.STREAM_CODEC.decode(buf));
        }
        return new WirelessView(name, owner, canEdit, current, currentPos, load, max, List.copyOf(entries));
    }

    private static String clip(String s) {
        return s == null ? "" : s.length() > MAX_TEXT ? s.substring(0, MAX_TEXT) : s;
    }
}
