package com.railgunreborn.wireless;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;

/**
 * Enlaces de un nodo con sus "usuarios" (energy.md 1.4): generadores (el nodo saca energía de ellos) y receptores (el
 * nodo les da). Un usuario es cualquier bloque con capacidad FE, del mod o de otros mods. Solo posiciones.
 */
public final class NodeLinks {
    public static final Codec<NodeLinks> CODEC = RecordCodecBuilder.create(i -> i.group(
            BlockPos.CODEC.fieldOf("node").forGetter(l -> l.node),
            BlockPos.CODEC.listOf().optionalFieldOf("generators", List.of())
                    .forGetter(l -> List.copyOf(l.generators)),
            BlockPos.CODEC.listOf().optionalFieldOf("receivers", List.of())
                    .forGetter(l -> List.copyOf(l.receivers)))
            .apply(i, NodeLinks::new));

    /** Papel de un bloque enlazado. */
    public enum Role {
        GENERATOR, RECEIVER
    }

    private final BlockPos node;
    private final Set<BlockPos> generators;
    private final Set<BlockPos> receivers;

    public NodeLinks(BlockPos node, List<BlockPos> generators, List<BlockPos> receivers) {
        this.node = node.immutable();
        this.generators = new LinkedHashSet<>(generators);
        this.receivers = new LinkedHashSet<>(receivers);
    }

    public BlockPos getNode() {
        return node;
    }

    public Set<BlockPos> getGenerators() {
        return Collections.unmodifiableSet(generators);
    }

    public Set<BlockPos> getReceivers() {
        return Collections.unmodifiableSet(receivers);
    }

    public int getLoad() {
        return generators.size() + receivers.size();
    }

    public boolean isEmpty() {
        return generators.isEmpty() && receivers.isEmpty();
    }

    void add(BlockPos user, Role role) {
        (role == Role.GENERATOR ? generators : receivers).add(user.immutable());
    }

    boolean remove(BlockPos user) {
        return generators.remove(user) | receivers.remove(user);
    }

    List<BlockPos> generatorSnapshot() {
        return new ArrayList<>(generators);
    }

    List<BlockPos> receiverSnapshot() {
        return new ArrayList<>(receivers);
    }
}
