package com.railgunreborn.wireless;

import com.railgunreborn.RailgunReborn;

import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/** Tick de la red inalámbrica: al final de cada tick de cada dimensión del servidor (bus del juego). */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class WirelessEvents {
    private WirelessEvents() {
    }

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel level) {
            WirelessData.get(level).tick(level);
        }
    }
}
