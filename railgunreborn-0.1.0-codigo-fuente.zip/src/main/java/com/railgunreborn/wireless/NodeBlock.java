package com.railgunreborn.wireless;

import javax.annotation.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Nodo inalámbrico (3 niveles, {@link NodeType}). Estados del bloque como el original: {@code energy} 0-4 (textura
 * del lado según la carga) y {@code connected} (textura de arriba/abajo si está en una red); los refresca el
 * BlockEntity cada 10 ticks.
 *
 * <p>Clic derecho abre {@link NodeMenu}.
 */
public class NodeBlock extends BaseEntityBlock {
    public static final IntegerProperty ENERGY = IntegerProperty.create("energy", 0, 4);
    public static final BooleanProperty CONNECTED = BooleanProperty.create("connected");

    public static final MapCodec<NodeBlock> CODEC = RecordCodecBuilder.mapCodec(
            i -> i.group(propertiesCodec(), Codec.STRING.fieldOf("node_type").forGetter(b -> b.type.name()))
                    .apply(i, (props, name) -> new NodeBlock(props, NodeType.valueOf(name))));

    private final NodeType type;

    public NodeBlock(Properties properties, NodeType type) {
        super(properties);
        this.type = type;
        registerDefaultState(stateDefinition.any().setValue(ENERGY, 0).setValue(CONNECTED, false));
    }

    public NodeType getNodeType() {
        return type;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ENERGY, CONNECTED);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NodeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : createTickerHelper(type, WirelessRegistry.NODE_BE.get(), NodeBlockEntity::serverTick);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof NodeBlockEntity be) {
            be.setPlacerName(player.getGameProfile().getName());
        }
    }

    /** Romperlo suelta sus ranuras, lo saca de su red y borra sus enlaces. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            if (level.getBlockEntity(pos) instanceof NodeBlockEntity be) {
                be.dropContents(level, pos);
            }
            if (level instanceof ServerLevel serverLevel) {
                WirelessData.get(serverLevel).removeNode(pos);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    /** Clic derecho abre la pantalla del nodo (ranuras, nombre, contraseña, redes al alcance). */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer && level.getBlockEntity(pos) instanceof NodeBlockEntity be) {
            NodeMenu.open(serverPlayer, be);
        }
        return InteractionResult.CONSUME;
    }
}
