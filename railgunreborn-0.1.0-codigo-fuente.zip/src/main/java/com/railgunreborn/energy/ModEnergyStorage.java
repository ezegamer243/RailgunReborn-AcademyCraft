package com.railgunreborn.energy;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.energy.EnergyStorage;

/**
 * Almacén FE para BlockEntities. {@code maxReceive}/{@code maxExtract} son los topes para cables y otros mods
 * (por llamada); el propio bloque usa {@link #addEnergy}/{@link #consumeEnergy}, que ignoran esos topes (un
 * generador produce aunque no acepte entrada por cable, una máquina gasta aunque no deje extraer).
 *
 * <p>Cada cambio real llama a {@code onChanged} (típicamente {@code BlockEntity::setChanged}, o eso más un envío al
 * cliente).
 */
public class ModEnergyStorage extends EnergyStorage {
    private final Runnable onChanged;

    public ModEnergyStorage(int capacity, int maxReceive, int maxExtract, Runnable onChanged) {
        super(capacity, maxReceive, maxExtract, 0);
        this.onChanged = onChanged;
    }

    /** Solo recibe (máquinas, reactor): {@code maxReceive} por llamada desde fuera, nada sale. */
    public static ModEnergyStorage receiver(int capacity, int maxReceive, Runnable onChanged) {
        return new ModEnergyStorage(capacity, maxReceive, 0, onChanged);
    }

    /** Solo da (generadores). */
    public static ModEnergyStorage provider(int capacity, int maxExtract, Runnable onChanged) {
        return new ModEnergyStorage(capacity, 0, maxExtract, onChanged);
    }

    @Override
    public int receiveEnergy(int toReceive, boolean simulate) {
        int received = super.receiveEnergy(toReceive, simulate);
        if (!simulate && received > 0) {
            onChanged.run();
        }
        return received;
    }

    @Override
    public int extractEnergy(int toExtract, boolean simulate) {
        int extracted = super.extractEnergy(toExtract, simulate);
        if (!simulate && extracted > 0) {
            onChanged.run();
        }
        return extracted;
    }

    /** Pone la energía (recortada a [0, capacidad]). */
    public void setEnergy(int value) {
        int clamped = Math.max(0, Math.min(capacity, value));
        if (clamped != energy) {
            energy = clamped;
            onChanged.run();
        }
    }

    /** Uso interno (generar, cargar desde la ranura): mete hasta llenar, sin tope de ancho de banda. */
    public int addEnergy(int amount, boolean simulate) {
        int added = EnergyMath.transferAmount(amount, getSpace());
        if (!simulate && added > 0) {
            energy += added;
            onChanged.run();
        }
        return added;
    }

    /** Uso interno (gastar, cargar un ítem): saca lo que haya hasta {@code amount}, sin tope de ancho de banda. */
    public int consumeEnergy(int amount, boolean simulate) {
        int removed = EnergyMath.transferAmount(energy, amount);
        if (!simulate && removed > 0) {
            energy -= removed;
            onChanged.run();
        }
        return removed;
    }

    /** Gasta {@code amount} solo si está entero (todo o nada). Con 0 o menos no hace nada y devuelve true. */
    public boolean tryConsume(int amount) {
        if (amount <= 0) {
            return true;
        }
        if (energy < amount) {
            return false;
        }
        consumeEnergy(amount, false);
        return true;
    }

    public int getSpace() {
        return EnergyMath.space(energy, capacity);
    }

    public boolean isFull() {
        return energy >= capacity;
    }

    public float getFill() {
        return EnergyMath.fill(energy, capacity);
    }

    /** Guarda la energía como entero en {@code tag.key}. */
    public void save(CompoundTag tag, String key, HolderLookup.Provider registries) {
        tag.putInt(key, energy);
    }

    /** Lee lo guardado por {@link #save}; si falta la clave queda en 0. No llama a {@code onChanged}. */
    public void load(CompoundTag tag, String key, HolderLookup.Provider registries) {
        energy = Math.max(0, Math.min(capacity, tag.getInt(key)));
    }
}
