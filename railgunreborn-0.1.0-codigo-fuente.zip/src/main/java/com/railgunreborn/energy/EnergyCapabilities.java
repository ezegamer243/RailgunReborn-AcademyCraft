package com.railgunreborn.energy;

import java.util.function.Function;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.IEnergyStorage;

/** Registro de la capacidad FE de bloques: la misma en las 6 caras y sin cara (null), para cables de cualquier mod. */
public final class EnergyCapabilities {
    private EnergyCapabilities() {
    }

    public static <T extends BlockEntity> void registerBlock(RegisterCapabilitiesEvent event, BlockEntityType<T> type,
            Function<T, IEnergyStorage> storage) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, type, (be, side) -> storage.apply(be));
    }

    /** Registra la carga directa ({@link DirectChargeable}) de un tipo de BlockEntity. */
    public static <T extends BlockEntity> void registerDirect(RegisterCapabilitiesEvent event,
            BlockEntityType<T> type, Function<T, DirectChargeable> charger) {
        event.registerBlockEntity(DirectChargeable.BLOCK, type, (be, ctx) -> charger.apply(be));
    }
}
