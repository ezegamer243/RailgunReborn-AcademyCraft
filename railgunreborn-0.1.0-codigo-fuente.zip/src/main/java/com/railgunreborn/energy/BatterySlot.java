package com.railgunreborn.energy;

import javax.annotation.Nullable;

import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Ranura de batería de máquinas, generadores y nodos (energy.md 1.1): cualquier ítem con capacidad FE sirve (la
 * Energy Unit o la batería de otro mod). Las operaciones respetan el ancho de banda de las dos partes: el del ítem
 * (su propio {@code IEnergyStorage}) y el {@code rate} de la máquina.
 *
 * <p>La energía de un ítem vive en sus componentes: quien llame debe marcar la BlockEntity como cambiada si se movió
 * algo (los métodos devuelven la cantidad movida; {@link ModEnergyStorage} ya avisa de su lado).
 */
public final class BatterySlot {
    private BatterySlot() {
    }

    @Nullable
    public static IEnergyStorage itemStorage(ItemStack stack) {
        return stack.isEmpty() ? null : stack.getCapability(Capabilities.EnergyStorage.ITEM);
    }

    /** Si el ítem vale para una ranura de batería (tiene capacidad FE). */
    public static boolean isEnergyItem(ItemStack stack) {
        return itemStorage(stack) != null;
    }

    /** Máquinas: saca del ítem al almacén hasta {@code rate} (y el hueco). Devuelve lo movido. */
    public static int dischargeItem(ItemStack stack, ModEnergyStorage target, int rate) {
        IEnergyStorage item = itemStorage(stack);
        if (item == null || !item.canExtract()) {
            return 0;
        }
        int wanted = EnergyMath.transferAmount(rate, target.getSpace());
        int offered = item.extractEnergy(wanted, true);
        if (offered <= 0) {
            return 0;
        }
        int extracted = item.extractEnergy(offered, false);
        return target.addEnergy(extracted, false);
    }

    /** Generadores y nodos: carga el ítem desde el almacén hasta {@code rate}. Devuelve lo movido. */
    public static int chargeItem(ItemStack stack, ModEnergyStorage source, int rate) {
        IEnergyStorage item = itemStorage(stack);
        if (item == null || !item.canReceive()) {
            return 0;
        }
        int offered = EnergyMath.transferAmount(source.getEnergyStored(), Integer.MAX_VALUE, rate);
        int accepted = item.receiveEnergy(offered, true);
        if (accepted <= 0) {
            return 0;
        }
        int removed = source.consumeEnergy(accepted, false);
        int received = item.receiveEnergy(removed, false);
        if (received < removed) {
            // Un ítem de otro mod que simula distinto de lo que hace: no perder la diferencia.
            source.addEnergy(removed - received, false);
        }
        return received;
    }

    /**
     * Mueve hasta {@code rate} entre dos almacenes cualesquiera usando solo la API pública FE (respeta los topes de
     * ambos). Sirve para empujar a vecinos con cable o entre ítems. Devuelve lo movido.
     */
    public static int transfer(IEnergyStorage from, IEnergyStorage to, int rate) {
        if (rate <= 0 || !from.canExtract() || !to.canReceive()) {
            return 0;
        }
        int offered = from.extractEnergy(rate, true);
        int accepted = to.receiveEnergy(offered, true);
        if (accepted <= 0) {
            return 0;
        }
        int extracted = from.extractEnergy(accepted, false);
        return to.receiveEnergy(extracted, false);
    }
}
