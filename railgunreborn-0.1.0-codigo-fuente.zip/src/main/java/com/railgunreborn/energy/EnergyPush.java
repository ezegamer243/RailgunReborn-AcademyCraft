package com.railgunreborn.energy;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/** Reparto estándar de los generadores: empujar energía a los vecinos con capacidad FE (las 6 caras). */
public final class EnergyPush {
    private EnergyPush() {
    }

    /**
     * Empuja hasta {@code rate} en total (suma de todos los vecinos) desde {@code source} a los bloques adyacentes
     * que reciban FE. Usa solo la API pública, así que respeta los topes de ambos lados. Devuelve lo movido.
     */
    public static int toNeighbors(Level level, BlockPos pos, IEnergyStorage source, int rate) {
        int left = rate;
        for (Direction dir : Direction.values()) {
            if (left <= 0 || source.getEnergyStored() <= 0) {
                break;
            }
            @Nullable
            IEnergyStorage neighbor = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos.relative(dir),
                    dir.getOpposite());
            if (neighbor != null) {
                left -= BatterySlot.transfer(source, neighbor, left);
            }
        }
        return rate - left;
    }
}
