package com.railgunreborn.energy;

/** Cuentas puras de energía (sin Minecraft) que comparten los helpers y las pruebas JUnit. */
public final class EnergyMath {
    private EnergyMath() {
    }

    /**
     * Cuánto se puede mover en una operación: lo que tiene el origen, el hueco del destino y cada tope de ancho de
     * banda (los negativos cuentan como 0).
     */
    public static int transferAmount(int available, int space, int... limits) {
        int amount = Math.min(available, space);
        for (int limit : limits) {
            amount = Math.min(amount, limit);
        }
        return Math.max(0, amount);
    }

    /** Hueco libre de un almacén (nunca negativo). */
    public static int space(int stored, int capacity) {
        return Math.max(0, capacity - stored);
    }

    /** Llenado entre 0 y 1 (0 si la capacidad es 0). */
    public static float fill(int stored, int capacity) {
        if (capacity <= 0) {
            return 0f;
        }
        return Math.max(0f, Math.min(1f, stored / (float) capacity));
    }

    /** Ancho de una barra de {@code width} píxeles para ese llenado (redondeado; lleno = ancho entero). */
    public static int barWidth(int stored, int capacity, int width) {
        return Math.round(fill(stored, capacity) * width);
    }

    /**
     * Estado de textura de una batería como el original (predicado {@code energy}): 0 vacía, 0.5 media, 1 llena.
     * Umbrales del original (survival.md): llena por encima de 10/13 de carga, vacía por debajo de 3/13.
     */
    public static float chargeState(int stored, int capacity) {
        float fill = fill(stored, capacity);
        if (fill > 10f / 13f) {
            return 1f;
        }
        return fill < 3f / 13f ? 0f : 0.5f;
    }
}
