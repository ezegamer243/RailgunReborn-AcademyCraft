package com.railgunreborn.energy;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.capabilities.BlockCapability;

/**
 * Carga directa de energía, propia del mod: la usa Current Charging para saltarse el tope de ancho de banda por
 * llamada de nuestros bloques (el original hacía {@code ignoreBandwidth} con bloques). Respeta la capacidad. Se
 * expone como capacidad de bloque sin contexto ({@link #BLOCK}) para que las partes de multibloques lleguen al
 * controlador. Los generadores no la registran: no aceptan carga.
 */
@FunctionalInterface
public interface DirectChargeable {
    BlockCapability<DirectChargeable, Void> BLOCK = BlockCapability.createVoid(
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "direct_chargeable"), DirectChargeable.class);

    /** Mete hasta {@code amount} FE; devuelve lo aceptado. */
    int chargeDirect(int amount, boolean simulate);

    @Nullable
    static DirectChargeable find(Level level, BlockPos pos) {
        return level.getCapability(BLOCK, pos, null);
    }
}
