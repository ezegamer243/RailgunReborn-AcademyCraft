package com.railgunreborn.energy;

/**
 * Formato de energía para pantallas y tooltips: por dentro es FE, pero se muestra como "IF" (1:1, energy.md).
 * Los miles se separan con espacio ("10 000 IF"), igual en todos los idiomas. Sin dependencias de Minecraft.
 */
public final class EnergyFormat {
    public static final String UNIT = "IF";

    private EnergyFormat() {
    }

    /** "1 234 567" (con signo si es negativo). */
    public static String number(long value) {
        String digits = Long.toString(Math.abs(value));
        StringBuilder out = new StringBuilder(digits.length() + digits.length() / 3 + 1);
        if (value < 0) {
            out.append('-');
        }
        int first = digits.length() % 3;
        if (first == 0) {
            first = 3;
        }
        out.append(digits, 0, first);
        for (int i = first; i < digits.length(); i += 3) {
            out.append(' ').append(digits, i, i + 3);
        }
        return out.toString();
    }

    /** "1 234 IF". */
    public static String format(long value) {
        return number(value) + " " + UNIT;
    }

    /** "1 234 / 10 000 IF". */
    public static String fraction(long stored, long capacity) {
        return number(stored) + " / " + number(capacity) + " " + UNIT;
    }
}
