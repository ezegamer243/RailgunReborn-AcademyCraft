package com.railgunreborn.energy;

import net.minecraft.world.inventory.ContainerData;

/**
 * Enteros de más de 32767 por {@link ContainerData}: vanilla manda cada valor como {@code short} (se corta), así que
 * un entero ocupa dos ranuras consecutivas, la baja y la alta, de 16 bits sin signo cada una (sirve para cualquier
 * {@code int} >= 0, p. ej. buffers de 200 000 IF).
 *
 * <p>Servidor, en {@code ContainerData.get}: {@code case DATA_ENERGY -> ContainerDataInts.low(v)} y
 * {@code case DATA_ENERGY + 1 -> ContainerDataInts.high(v)}. Cliente (menú): {@code ContainerDataInts.get(data,
 * DATA_ENERGY)}.
 */
public final class ContainerDataInts {
    /** Ranuras que ocupa un entero. */
    public static final int SLOTS = 2;

    private ContainerDataInts() {
    }

    public static int low(int value) {
        return value & 0xFFFF;
    }

    public static int high(int value) {
        return value >>> 16 & 0xFFFF;
    }

    /** Une las dos mitades; tolera que lleguen con signo (un short negativo leído como int). */
    public static int combine(int low, int high) {
        return (low & 0xFFFF) | (high & 0xFFFF) << 16;
    }

    /** Lee el entero guardado en {@code index} (baja) e {@code index + 1} (alta). */
    public static int get(ContainerData data, int index) {
        return combine(data.get(index), data.get(index + 1));
    }

    /** Parte {@code slotOffset} (0 baja, 1 alta) de {@code value}, para el {@code get} del servidor. */
    public static int part(int value, int slotOffset) {
        return slotOffset == 0 ? low(value) : high(value);
    }
}
