package com.railgunreborn;

import org.slf4j.Logger;

import com.mojang.logging.LogUtils;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.network.ModNetwork;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.wireless.WirelessRegistry;
import com.railgunreborn.registry.ModAttachments;
import com.railgunreborn.registry.ModBlockEntities;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModCapabilities;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModCreativeTabs;
import com.railgunreborn.registry.ModDataComponents;
import com.railgunreborn.registry.ModDataMaps;
import com.railgunreborn.registry.ModLootModifiers;
import com.railgunreborn.registry.ModEntities;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModMenus;
import com.railgunreborn.registry.ModParticles;
import com.railgunreborn.registry.ModRecipes;
import com.railgunreborn.registry.ModSounds;

import com.railgunreborn.config.RailgunConfig;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod(RailgunReborn.MODID)
public class RailgunReborn {
    public static final String MODID = "railgunreborn";
    public static final Logger LOGGER = LogUtils.getLogger();

    public RailgunReborn(IEventBus modEventBus, ModContainer modContainer) {
        modContainer.registerConfig(ModConfig.Type.SERVER, RailgunConfig.SPEC);
        AbilityRegistries.register(modEventBus);
        ModAttachments.register(modEventBus);
        ModSounds.register(modEventBus);
        ModBlocks.register(modEventBus);
        ModFluids.register(modEventBus);
        ModDataComponents.register(modEventBus);
        ModBlockEntities.register(modEventBus);
        ModRecipes.register(modEventBus);
        ModItems.register(modEventBus);
        ModLootModifiers.register(modEventBus);
        ModEntities.register(modEventBus);
        ModCreativeTabs.register(modEventBus);
        ModMenus.register(modEventBus);
        ModParticles.register(modEventBus);
        MetalFormerRegistry.register(modEventBus);
        CategoryReactorRegistry.register(modEventBus);
        WirelessRegistry.register(modEventBus);
        modEventBus.addListener(ModNetwork::register);
        modEventBus.addListener(ModDataMaps::register);
        modEventBus.addListener(ModCapabilities::register);
        modEventBus.addListener(this::commonSetup);
        LOGGER.info("RailgunReborn-AcademyCraft loaded");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("RailgunReborn common setup");
    }
}
