package com.railgunreborn.config;

import javax.annotation.Nullable;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Opciones del servidor (fase de energía, energy.md "Decisiones del usuario"). Se registra como config SERVER en el
 * constructor del mod: cada mundo tiene la suya en {@code serverconfig/railgunreborn-server.toml}.
 *
 * <p>Los accesores devuelven el valor por defecto si la config aún no se cargó (antes de arrancar el servidor, en
 * pruebas o en el cliente sin mundo), en vez de lanzar la excepción de {@code ModConfigSpec}.
 */
public final class RailgunConfig {
    public static final int DEFAULT_REACTOR_CHARGE_RATE = 1000;

    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue ENERGY_REQUIRED;
    public static final ModConfigSpec.IntValue REACTOR_CHARGE_RATE;
    public static final ModConfigSpec.DoubleValue GENERATOR_MULTIPLIER;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.push("energy");
        ENERGY_REQUIRED = builder
                .comment("If false, the Imag Fusor, Metal Former, Developers and Category Reactor work without energy.")
                .define("energyRequired", true);
        REACTOR_CHARGE_RATE = builder
                .comment("Maximum IF (FE) per tick the Category Reactor accepts while charging.")
                .defineInRange("reactorChargeRate", DEFAULT_REACTOR_CHARGE_RATE, 1, Integer.MAX_VALUE);
        GENERATOR_MULTIPLIER = builder
                .comment("Multiplier applied to the output of every generator of the mod.")
                .defineInRange("generatorMultiplier", 1.0, 0.0, 100.0);
        builder.pop();
        SPEC = builder.build();
    }

    private RailgunConfig() {
    }

    /** Solo para GameTests: fuerza {@code energyRequired} (null = usar la config). Nunca se toca en el juego real. */
    @Nullable
    private static volatile Boolean energyRequiredOverride;

    public static boolean energyRequired() {
        Boolean forced = energyRequiredOverride;
        return forced != null ? forced : readOrDefault(SPEC, ENERGY_REQUIRED);
    }

    /** Solo para pruebas: el test que lo use debe devolverlo a {@code null} al terminar. */
    public static void setEnergyRequiredOverrideForTests(@Nullable Boolean value) {
        energyRequiredOverride = value;
    }

    public static int reactorChargeRate() {
        return readOrDefault(SPEC, REACTOR_CHARGE_RATE);
    }

    public static double generatorMultiplier() {
        return readOrDefault(SPEC, GENERATOR_MULTIPLIER);
    }

    /** Valor de la opción, o su valor por defecto si {@code spec} todavía no está cargada. */
    public static <T> T readOrDefault(ModConfigSpec spec, ModConfigSpec.ConfigValue<T> value) {
        if (!spec.isLoaded()) {
            return value.getDefault();
        }
        try {
            return value.get();
        } catch (IllegalStateException e) {
            // Carrera al descargar la config (cerrar el mundo): mejor el valor por defecto que un fallo.
            return value.getDefault();
        }
    }
}
