package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.develop.DeveloperMenu;
import com.railgunreborn.block.ImagFusorMenu;
import com.railgunreborn.block.PhaseGenMenu;
import com.railgunreborn.block.SolarGenMenu;
import com.railgunreborn.block.WindGenBaseMenu;
import com.railgunreborn.block.WindGenMainMenu;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModMenus {
    private static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU,
            RailgunReborn.MODID);

    /** La pantalla (T22) se registra en el cliente con {@code RegisterMenuScreensEvent}. */
    public static final DeferredHolder<MenuType<?>, MenuType<DeveloperMenu>> DEVELOPER = MENUS.register("developer",
            () -> IMenuTypeExtension.create(DeveloperMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<ImagFusorMenu>> IMAG_FUSOR = MENUS.register("imag_fusor",
            () -> IMenuTypeExtension.create(ImagFusorMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<SolarGenMenu>> SOLAR_GEN = MENUS.register("solar_gen",
            () -> IMenuTypeExtension.create(SolarGenMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<PhaseGenMenu>> PHASE_GEN = MENUS.register("phase_gen",
            () -> IMenuTypeExtension.create(PhaseGenMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<WindGenBaseMenu>> WINDGEN_BASE = MENUS.register(
            "windgen_base", () -> IMenuTypeExtension.create(WindGenBaseMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<WindGenMainMenu>> WINDGEN_MAIN = MENUS.register(
            "windgen_main", () -> IMenuTypeExtension.create(WindGenMainMenu::new));

    private ModMenus() {
    }

    public static void register(IEventBus modEventBus) {
        MENUS.register(modEventBus);
    }
}
