package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.DeveloperBlockItem;
import com.railgunreborn.block.WindGenBlockItem;
import com.railgunreborn.item.CoinItem;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.item.SilbarnItem;
import com.railgunreborn.item.TerminalInstallerItem;

import com.railgunreborn.item.MatterUnitItem;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RailgunReborn.MODID);

    public static final DeferredItem<DeveloperPortableItem> DEVELOPER_PORTABLE = ITEMS.register("developer_portable",
            () -> new DeveloperPortableItem(new Item.Properties()));
    public static final DeferredItem<DeveloperBlockItem> DEVELOPER_NORMAL = ITEMS.register("developer_normal",
            () -> new DeveloperBlockItem(ModBlocks.DEVELOPER_NORMAL.get(), new Item.Properties()));
    public static final DeferredItem<DeveloperBlockItem> DEVELOPER_ADVANCED = ITEMS.register("developer_advanced",
            () -> new DeveloperBlockItem(ModBlocks.DEVELOPER_ADVANCED.get(), new Item.Properties()));

    public static final DeferredItem<CoinItem> COIN = ITEMS.register("coin",
            () -> new CoinItem(new Item.Properties()));

    public static final DeferredItem<SilbarnItem> SILBARN = ITEMS.register("silbarn",
            () -> new SilbarnItem(new Item.Properties()));

    public static final DeferredItem<TerminalInstallerItem> TERMINAL_INSTALLER = ITEMS.register("terminal_installer",
            () -> new TerminalInstallerItem(new Item.Properties().stacksTo(1)));

    public static final DeferredItem<InductionFactorItem> INDUCTION_FACTOR = ITEMS.register("induction_factor",
            () -> new InductionFactorItem(new Item.Properties().stacksTo(16)));

    // Aguja de Threatening Teleport: ítem normal sin comportamiento propio; solo creativo, sin receta.
    public static final DeferredItem<Item> NEEDLE = ITEMS.registerSimpleItem("needle");

    // Materiales de supervivencia (T82): ítems simples sin comportamiento; las recetas llegan en T84+ y la generación en T83.
    public static final DeferredItem<Item> CONSTRAINT_INGOT = ITEMS.registerSimpleItem("constraint_ingot");
    public static final DeferredItem<Item> CONSTRAINT_PLATE = ITEMS.registerSimpleItem("constraint_plate");
    public static final DeferredItem<Item> IMAG_SILICON_INGOT = ITEMS.registerSimpleItem("imag_silicon_ingot");
    public static final DeferredItem<Item> WAFER = ITEMS.registerSimpleItem("wafer");
    public static final DeferredItem<Item> IMAG_SILICON_PIECE = ITEMS.registerSimpleItem("imag_silicon_piece");
    public static final DeferredItem<Item> CRYSTAL_LOW = ITEMS.registerSimpleItem("crystal_low");
    public static final DeferredItem<Item> CRYSTAL_NORMAL = ITEMS.registerSimpleItem("crystal_normal");
    public static final DeferredItem<Item> CRYSTAL_PURE = ITEMS.registerSimpleItem("crystal_pure");
    public static final DeferredItem<Item> RESO_CRYSTAL = ITEMS.registerSimpleItem("reso_crystal");
    public static final DeferredItem<Item> REINFORCED_IRON_PLATE = ITEMS.registerSimpleItem("reinforced_iron_plate");
    public static final DeferredItem<Item> DATA_CHIP = ITEMS.registerSimpleItem("data_chip");
    public static final DeferredItem<Item> CALC_CHIP = ITEMS.registerSimpleItem("calc_chip");
    public static final DeferredItem<Item> INFO_COMPONENT = ITEMS.registerSimpleItem("info_component");
    public static final DeferredItem<Item> BRAIN_COMPONENT = ITEMS.registerSimpleItem("brain_component");
    public static final DeferredItem<Item> RESONANCE_COMPONENT = ITEMS.registerSimpleItem("resonance_component");
    public static final DeferredItem<Item> ENERGY_CONVERT_COMPONENT = ITEMS.registerSimpleItem("energy_convert_component");
    public static final DeferredItem<Item> WINDGEN_FAN = ITEMS.registerSimpleItem("windgen_fan");
    public static final DeferredItem<EnergyUnitItem> ENERGY_UNIT = ITEMS.register("energy_unit",
            () -> new EnergyUnitItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<EnergyUnitItem> ENERGY_UNIT_HIGH = ITEMS.register("energy_unit_high",
            () -> new EnergyUnitItem(new Item.Properties().stacksTo(1), EnergyUnitItem.HIGH_CAPACITY,
                    EnergyUnitItem.HIGH_MAX_TRANSFER));
    public static final DeferredItem<EnergyUnitItem> ENERGY_UNIT_MEGA = ITEMS.register("energy_unit_mega",
            () -> new EnergyUnitItem(new Item.Properties().stacksTo(1), EnergyUnitItem.MEGA_CAPACITY,
                    EnergyUnitItem.MEGA_MAX_TRANSFER));
    public static final DeferredItem<BlockItem> CONSTRAINT_METAL = ITEMS.registerSimpleBlockItem(ModBlocks.CONSTRAINT_METAL);
    public static final DeferredItem<BlockItem> CRYSTAL_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.CRYSTAL_ORE);
    public static final DeferredItem<BlockItem> IMAGSIL_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.IMAGSIL_ORE);
    public static final DeferredItem<BlockItem> RESO_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.RESO_ORE);
    public static final DeferredItem<BlockItem> MACHINE_FRAME = ITEMS.registerSimpleBlockItem(ModBlocks.MACHINE_FRAME);

    // Líquido de fase (T85). El cubo es un BucketItem normal: NeoForge le da solo la capacidad de fluido
    // (FluidBucketWrapper), así funciona con tuberías y tanques de otros mods. La unidad de materia es el
    // recipiente del original: vacía o llena (1000 mB); capacidad registrada en ModCapabilities.
    public static final DeferredItem<BucketItem> PHASE_LIQUID_BUCKET = ITEMS.register("phase_liquid_bucket",
            () -> new BucketItem(ModFluids.PHASE_LIQUID.get(),
                    new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));
    public static final DeferredItem<MatterUnitItem> MATTER_UNIT = ITEMS.register("matter_unit",
            () -> new MatterUnitItem(false, new Item.Properties().stacksTo(16)));
    public static final DeferredItem<MatterUnitItem> MATTER_UNIT_PHASE_LIQUID = ITEMS.register("matter_unit_phase_liquid",
            () -> new MatterUnitItem(true, new Item.Properties().stacksTo(16)));

    public static final DeferredItem<BlockItem> IMAG_FUSOR = ITEMS.registerSimpleBlockItem(ModBlocks.IMAG_FUSOR);
    public static final DeferredItem<BlockItem> SOLAR_GEN = ITEMS.registerSimpleBlockItem(ModBlocks.SOLAR_GEN);
    public static final DeferredItem<BlockItem> PHASE_GEN = ITEMS.registerSimpleBlockItem(ModBlocks.PHASE_GEN);
    public static final DeferredItem<BlockItem> CAT_ENGINE = ITEMS.registerSimpleBlockItem(ModBlocks.CAT_ENGINE);

    public static final DeferredItem<WindGenBlockItem> WINDGEN_BASE = ITEMS.register("windgen_base",
            () -> new WindGenBlockItem(ModBlocks.WINDGEN_BASE.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> WINDGEN_PILLAR = ITEMS.registerSimpleBlockItem(ModBlocks.WINDGEN_PILLAR);
    public static final DeferredItem<WindGenBlockItem> WINDGEN_MAIN = ITEMS.register("windgen_main",
            () -> new WindGenBlockItem(ModBlocks.WINDGEN_MAIN.get(), new Item.Properties()));

    private ModItems() {
    }

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
    }
}
