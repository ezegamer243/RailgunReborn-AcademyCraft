package com.railgunreborn.registry;

import java.util.function.Supplier;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Eventos de sonido declarados en {@code sounds.json}. */
public final class ModSounds {
    private static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, RailgunReborn.MODID);

    public static final Supplier<SoundEvent> ARC_WEAK = register("electromaster.arc_weak");
    public static final Supplier<SoundEvent> CHARGE_LOOP = register("electromaster.charge_loop");
    public static final Supplier<SoundEvent> MOVE_LOOP = register("electromaster.move_loop");
    public static final Supplier<SoundEvent> LF_LOOP = register("electromaster.lf_loop");
    public static final Supplier<SoundEvent> MAG_MANIP = register("electromaster.mag_manip");
    public static final Supplier<SoundEvent> MINE_DETECT = register("electromaster.mine_detect");
    public static final Supplier<SoundEvent> INTENSIFY_LOOP = register("electromaster.intensify_loop");
    public static final Supplier<SoundEvent> INTENSIFY_ACTIVATE = register("electromaster.intensify_activate");
    public static final Supplier<SoundEvent> ARC_STRONG = register("electromaster.arc_strong");
    public static final Supplier<SoundEvent> RAILGUN = register("electromaster.railgun");
    public static final Supplier<SoundEvent> COIN_FLIP = register("entity.coin_flip");
    public static final Supplier<SoundEvent> SILBARN_LIGHT = register("entity.silbarn_light");
    public static final Supplier<SoundEvent> SILBARN_HEAVY = register("entity.silbarn_heavy");
    public static final Supplier<SoundEvent> MD_RAY_SMALL = register("meltdowner.ray_small");
    public static final Supplier<SoundEvent> MD_CHARGE = register("meltdowner.md_charge");
    public static final Supplier<SoundEvent> MELTDOWNER = register("meltdowner.meltdowner");
    public static final Supplier<SoundEvent> SHIELD_STARTUP = register("meltdowner.shield_startup");
    public static final Supplier<SoundEvent> SHIELD_LOOP = register("meltdowner.shield_loop");
    public static final Supplier<SoundEvent> MINE_LOOP = register("meltdowner.mine_loop");
    public static final Supplier<SoundEvent> MINE_BASIC_STARTUP = register("meltdowner.mine_basic_startup");
    public static final Supplier<SoundEvent> MINE_EXPERT_STARTUP = register("meltdowner.mine_expert_startup");
    public static final Supplier<SoundEvent> MINE_LUCK_STARTUP = register("meltdowner.mine_luck_startup");
    public static final Supplier<SoundEvent> TP = register("teleporter.tp");
    public static final Supplier<SoundEvent> GUTS = register("teleporter.guts");
    public static final Supplier<SoundEvent> TP_SHIFT = register("teleporter.tp_shift");
    public static final Supplier<SoundEvent> TP_FLASHING = register("teleporter.tp_flashing");
    public static final Supplier<SoundEvent> DENY = register("ability.deny");
    public static final Supplier<SoundEvent> PRESET_SWITCH = register("ability.preset_switch");
    public static final Supplier<SoundEvent> PRESET_CONFIRM = register("ability.preset_confirm");

    // Vector Manipulation
    public static final Supplier<SoundEvent> VM_DIRECTED_SHOCK = register("vecmanip.directed_shock");
    public static final Supplier<SoundEvent> VM_GROUNDSHOCK = register("vecmanip.groundshock");
    public static final Supplier<SoundEvent> VM_VEC_ACCEL = register("vecmanip.vec_accel");
    public static final Supplier<SoundEvent> VM_VEC_DEVIATION = register("vecmanip.vec_deviation");
    public static final Supplier<SoundEvent> VM_DIRECTED_BLAST = register("vecmanip.directed_blast");
    public static final Supplier<SoundEvent> VM_STORM_WING = register("vecmanip.storm_wing");
    public static final Supplier<SoundEvent> VM_BLOOD_RETRO = register("vecmanip.blood_retro");
    public static final Supplier<SoundEvent> VM_VEC_REFLECTION = register("vecmanip.vec_reflection");
    public static final Supplier<SoundEvent> VM_PLASMA_CANNON = register("vecmanip.plasma_cannon");
    public static final Supplier<SoundEvent> VM_PLASMA_CANNON_READY = register("vecmanip.plasma_cannon_ready");

    // Máquinas (T86). machine_work queda para el Metal Former.
    public static final Supplier<SoundEvent> IMAG_FUSOR_WORK = register("machine.imag_fusor_work");
    public static final Supplier<SoundEvent> MACHINE_WORK = register("machine.machine_work");

    private ModSounds() {
    }

    private static Supplier<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, name)));
    }

    public static void register(IEventBus modEventBus) {
        SOUNDS.register(modEventBus);
    }
}
