package com.railgunreborn.registry;

import com.mojang.serialization.MapCodec;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.loot.InductionFactorLootModifier;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public final class ModLootModifiers {
    private static final DeferredRegister<MapCodec<? extends IGlobalLootModifier>> MODIFIERS =
            DeferredRegister.create(NeoForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, RailgunReborn.MODID);

    public static final DeferredHolder<MapCodec<? extends IGlobalLootModifier>, MapCodec<InductionFactorLootModifier>>
            INDUCTION_FACTOR = MODIFIERS.register("induction_factor", () -> InductionFactorLootModifier.CODEC);

    private ModLootModifiers() {
    }

    public static void register(IEventBus modEventBus) {
        MODIFIERS.register(modEventBus);
    }
}
