package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.block.PhaseGenBlockEntity;
import com.railgunreborn.block.SolarGenBlockEntity;
import com.railgunreborn.block.WindGenBaseBlockEntity;
import com.railgunreborn.block.WindGenMainBlockEntity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(
            Registries.BLOCK_ENTITY_TYPE, RailgunReborn.MODID);

    @SuppressWarnings("DataFlowIssue") // el tipo de datos (DataFixer) es null en los mods
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ImagFusorBlockEntity>> IMAG_FUSOR =
            BLOCK_ENTITIES.register("imag_fusor", () -> BlockEntityType.Builder
                    .of(ImagFusorBlockEntity::new, ModBlocks.IMAG_FUSOR.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SolarGenBlockEntity>> SOLAR_GEN =
            BLOCK_ENTITIES.register("solar_gen", () -> BlockEntityType.Builder
                    .of(SolarGenBlockEntity::new, ModBlocks.SOLAR_GEN.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PhaseGenBlockEntity>> PHASE_GEN =
            BLOCK_ENTITIES.register("phase_gen", () -> BlockEntityType.Builder
                    .of(PhaseGenBlockEntity::new, ModBlocks.PHASE_GEN.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CatEngineBlockEntity>> CAT_ENGINE =
            BLOCK_ENTITIES.register("cat_engine", () -> BlockEntityType.Builder
                    .of(CatEngineBlockEntity::new, ModBlocks.CAT_ENGINE.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DeveloperBlockEntity>> DEVELOPER =
            BLOCK_ENTITIES.register("developer", () -> BlockEntityType.Builder
                    .of(DeveloperBlockEntity::new, ModBlocks.DEVELOPER_NORMAL.get(),
                            ModBlocks.DEVELOPER_ADVANCED.get())
                    .build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WindGenBaseBlockEntity>> WINDGEN_BASE =
            BLOCK_ENTITIES.register("windgen_base", () -> BlockEntityType.Builder
                    .of(WindGenBaseBlockEntity::new, ModBlocks.WINDGEN_BASE.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WindGenMainBlockEntity>> WINDGEN_MAIN =
            BLOCK_ENTITIES.register("windgen_main", () -> BlockEntityType.Builder
                    .of(WindGenMainBlockEntity::new, ModBlocks.WINDGEN_MAIN.get()).build(null));

    private ModBlockEntities() {
    }

    public static void register(IEventBus modEventBus) {
        BLOCK_ENTITIES.register(modEventBus);
    }
}
