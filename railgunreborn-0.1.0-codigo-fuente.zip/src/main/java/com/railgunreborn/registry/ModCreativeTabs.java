package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.reactor.CategoryReactorRegistry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    private static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB,
            RailgunReborn.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.railgunreborn"))
                    .icon(() -> new ItemStack(ModItems.DEVELOPER_PORTABLE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.DEVELOPER_PORTABLE.get());
                        output.accept(ModItems.DEVELOPER_NORMAL.get());
                        output.accept(ModItems.DEVELOPER_ADVANCED.get());
                        output.accept(ModItems.COIN.get());
                        output.accept(ModItems.SILBARN.get());
                        output.accept(ModItems.TERMINAL_INSTALLER.get());
                        output.accept(ModItems.NEEDLE.get());
                        AbilityRegistries.CATEGORY_REGISTRY.stream()
                                .forEach(c -> output.accept(InductionFactorItem.of(c.getId())));
                        output.accept(ModItems.CONSTRAINT_METAL.get());
                        output.accept(ModItems.CRYSTAL_ORE.get());
                        output.accept(ModItems.IMAGSIL_ORE.get());
                        output.accept(ModItems.RESO_ORE.get());
                        output.accept(ModItems.MACHINE_FRAME.get());
                        output.accept(MetalFormerRegistry.METAL_FORMER_ITEM.get());
                        output.accept(ModItems.IMAG_FUSOR.get());
                        output.accept(ModItems.SOLAR_GEN.get());
                        output.accept(ModItems.PHASE_GEN.get());
                        output.accept(ModItems.WINDGEN_BASE.get());
                        output.accept(ModItems.WINDGEN_PILLAR.get());
                        output.accept(ModItems.WINDGEN_MAIN.get());
                        output.accept(ModItems.CAT_ENGINE.get());
                        output.accept(CategoryReactorRegistry.ITEM.get());
                        output.accept(ModItems.CONSTRAINT_INGOT.get());
                        output.accept(ModItems.CONSTRAINT_PLATE.get());
                        output.accept(ModItems.IMAG_SILICON_INGOT.get());
                        output.accept(ModItems.WAFER.get());
                        output.accept(ModItems.IMAG_SILICON_PIECE.get());
                        output.accept(ModItems.REINFORCED_IRON_PLATE.get());
                        output.accept(ModItems.CRYSTAL_LOW.get());
                        output.accept(ModItems.CRYSTAL_NORMAL.get());
                        output.accept(ModItems.CRYSTAL_PURE.get());
                        output.accept(ModItems.RESO_CRYSTAL.get());
                        output.accept(ModItems.DATA_CHIP.get());
                        output.accept(ModItems.CALC_CHIP.get());
                        output.accept(ModItems.INFO_COMPONENT.get());
                        output.accept(ModItems.BRAIN_COMPONENT.get());
                        output.accept(ModItems.RESONANCE_COMPONENT.get());
                        output.accept(ModItems.ENERGY_CONVERT_COMPONENT.get());
                        output.accept(ModItems.WINDGEN_FAN.get());
                        output.accept(ModItems.ENERGY_UNIT.get());
                        output.accept(EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT.get()),
                                EnergyUnitItem.CAPACITY));
                        output.accept(ModItems.ENERGY_UNIT_HIGH.get());
                        output.accept(EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT_HIGH.get()),
                                EnergyUnitItem.HIGH_CAPACITY));
                        output.accept(ModItems.ENERGY_UNIT_MEGA.get());
                        output.accept(EnergyUnitItem.withEnergy(new ItemStack(ModItems.ENERGY_UNIT_MEGA.get()),
                                EnergyUnitItem.MEGA_CAPACITY));
                        output.accept(ModItems.MATTER_UNIT.get());
                        output.accept(ModItems.MATTER_UNIT_PHASE_LIQUID.get());
                        output.accept(ModItems.PHASE_LIQUID_BUCKET.get());
                    }).build());

    private ModCreativeTabs() {
    }

    public static void register(IEventBus modEventBus) {
        TABS.register(modEventBus);
    }
}
