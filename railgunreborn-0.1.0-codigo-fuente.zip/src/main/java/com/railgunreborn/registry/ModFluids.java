package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.SoundActions;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Líquido de fase imaginaria (T85). Números del original (Forge 1.12): luminosidad 8, viscosidad 6000 (como la lava:
 * fluye lento), material agua (se nada y se ahoga como en el agua, no quema ni frena) y 3 "quanta" por bloque
 * (se extiende solo 2 bloques). No se regenera: dos fuentes no crean una tercera.
 */
public final class ModFluids {
    private static final DeferredRegister<FluidType> FLUID_TYPES = DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES,
            RailgunReborn.MODID);
    private static final DeferredRegister<Fluid> FLUIDS = DeferredRegister.create(Registries.FLUID, RailgunReborn.MODID);

    public static final DeferredHolder<FluidType, FluidType> PHASE_LIQUID_TYPE = FLUID_TYPES.register("phase_liquid",
            () -> new FluidType(FluidType.Properties.create()
                    .lightLevel(8)
                    .density(1000)
                    .viscosity(6000)
                    .canExtinguish(true)
                    .fallDistanceModifier(0f)
                    .canHydrate(false)
                    .canConvertToSource(false)
                    .sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL)
                    .sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY)));

    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> PHASE_LIQUID = FLUIDS.register("phase_liquid",
            () -> new BaseFlowingFluid.Source(properties()));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> FLOWING_PHASE_LIQUID = FLUIDS.register("flowing_phase_liquid",
            () -> new BaseFlowingFluid.Flowing(properties()));

    private ModFluids() {
    }

    private static BaseFlowingFluid.Properties properties() {
        // tickRate 30 = viscosidad 6000 / 200 (regla de Forge 1.12); bajar 3 niveles por bloque = 2 bloques de alcance.
        return new BaseFlowingFluid.Properties(PHASE_LIQUID_TYPE, PHASE_LIQUID, FLOWING_PHASE_LIQUID)
                .block(ModBlocks.PHASE_LIQUID)
                .bucket(ModItems.PHASE_LIQUID_BUCKET)
                .tickRate(30)
                .levelDecreasePerBlock(3)
                .slopeFindDistance(2)
                .explosionResistance(100f);
    }

    public static void register(IEventBus modEventBus) {
        FLUID_TYPES.register(modEventBus);
        FLUIDS.register(modEventBus);
    }
}
