package com.railgunreborn.registry;

import com.railgunreborn.block.CatEngineBlockEntity;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.block.PhaseGenBlockEntity;
import com.railgunreborn.block.SolarGenBlockEntity;
import com.railgunreborn.block.WindGenBaseBlock;
import com.railgunreborn.block.WindGenBaseBlockEntity;
import com.railgunreborn.block.DeveloperBlock;
import com.railgunreborn.block.DeveloperBlockEntity;
import com.railgunreborn.item.DeveloperPortableItem;
import com.railgunreborn.energy.DirectChargeable;
import com.railgunreborn.energy.EnergyCapabilities;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorPartBlock;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.wireless.WirelessRegistry;
import com.railgunreborn.item.EnergyUnitItem;
import com.railgunreborn.item.MatterUnitFluidHandler;

import com.railgunreborn.metalformer.MetalFormerBlockEntity;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.energy.ModEnergyStorage;

import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.ComponentEnergyStorage;
import net.neoforged.neoforge.gametest.GameTestHooks;

/** Capacidades de NeoForge (bus del MOD). El cubo de líquido de fase ya la recibe de NeoForge por ser un BucketItem. */
public final class ModCapabilities {
    /** Solo para GameTests: almacén que "tiene" el bloque de oro cuando se registra bajo el servidor de pruebas. */
    public static final ModEnergyStorage TEST_RECEIVER = ModEnergyStorage.receiver(10_000, 1000, () -> {
    });

    private ModCapabilities() {
    }

    /**
     * Carga directa para Current Charging (T106): máquinas, Developers y nodos aceptan sin tope de ancho de banda
     * (solo capacidad). El reactor mantiene {@code reactorChargeRate()} como tope global por tick. Los generadores
     * no se registran: no aceptan carga.
     */
    private static void registerDirectCharge(RegisterCapabilitiesEvent event) {
        EnergyCapabilities.registerDirect(event, ModBlockEntities.IMAG_FUSOR.get(),
                be -> be.getEnergy()::addEnergy);
        EnergyCapabilities.registerDirect(event, MetalFormerRegistry.BLOCK_ENTITY.get(),
                be -> be.getEnergy()::addEnergy);
        EnergyCapabilities.registerDirect(event, WirelessRegistry.NODE_BE.get(), be -> be.getEnergy()::addEnergy);
        event.registerBlock(DirectChargeable.BLOCK, (level, pos, state, be, ctx) -> {
            DeveloperBlockEntity origin = DeveloperBlock.originEntity(level, pos, state);
            return origin == null ? null : origin.getEnergy()::addEnergy;
        }, ModBlocks.DEVELOPER_NORMAL.get(), ModBlocks.DEVELOPER_ADVANCED.get());
        // Reactor: pasa por su manejador, que ya limita la suma por tick (no por llamada).
        EnergyCapabilities.registerDirect(event, CategoryReactorRegistry.BLOCK_ENTITY.get(),
                be -> be.getEnergyHandler()::receiveEnergy);
        event.registerBlock(DirectChargeable.BLOCK, (level, pos, state, be, ctx) -> {
            CategoryReactorBlockEntity controller = CategoryReactorPartBlock.controller(level, pos, state);
            return controller == null ? null : controller.getEnergyHandler()::receiveEnergy;
        }, CategoryReactorRegistry.PART.get());
    }

    public static void register(RegisterCapabilitiesEvent event) {
        event.registerItem(Capabilities.FluidHandler.ITEM, (stack, ctx) -> new MatterUnitFluidHandler(stack),
                ModItems.MATTER_UNIT.get(), ModItems.MATTER_UNIT_PHASE_LIQUID.get());
        // Imag Fusor: tuberías de fluido (solo llenar, solo líquido de fase) y de ítems (por cara).
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.IMAG_FUSOR.get(),
                ImagFusorBlockEntity::getFluidHandler);
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.IMAG_FUSOR.get(),
                ImagFusorBlockEntity::getItemHandler);
        // Energía (T97): la Energy Unit es una batería FE guardada en su componente.
        event.registerItem(Capabilities.EnergyStorage.ITEM, (stack, ctx) -> EnergyUnitItem.createStorage(stack),
                ModItems.ENERGY_UNIT.get(), ModItems.ENERGY_UNIT_HIGH.get(), ModItems.ENERGY_UNIT_MEGA.get());
        // Energía de las máquinas (E2): FE en las 6 caras y sin cara, para cables y generadores de cualquier mod.
        EnergyCapabilities.registerBlock(event, ModBlockEntities.IMAG_FUSOR.get(), ImagFusorBlockEntity::getEnergy);
        EnergyCapabilities.registerBlock(event, MetalFormerRegistry.BLOCK_ENTITY.get(),
                MetalFormerBlockEntity::getEnergy);
        // Generadores (T100): solo dan energía, por todas las caras.
        EnergyCapabilities.registerBlock(event, ModBlockEntities.SOLAR_GEN.get(), SolarGenBlockEntity::getEnergy);
        EnergyCapabilities.registerBlock(event, ModBlockEntities.PHASE_GEN.get(), PhaseGenBlockEntity::getEnergy);
        // Generador de fase: tuberías de fluido (solo llenar, solo líquido de fase).
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.PHASE_GEN.get(),
                PhaseGenBlockEntity::getFluidHandler);
        EnergyCapabilities.registerBlock(event, ModBlockEntities.CAT_ENGINE.get(), CatEngineBlockEntity::getEnergy);
        // Generador eólico (T102): las dos mitades de la base dan el almacén del controlador (solo extraer).
        event.registerBlock(Capabilities.EnergyStorage.BLOCK, (level, pos, state, be, side) -> {
            WindGenBaseBlockEntity origin = WindGenBaseBlock.originEntity(level, pos, state);
            return origin == null ? null : origin.getEnergy();
        }, ModBlocks.WINDGEN_BASE.get());
        // Developer portátil: batería FE en su componente (se carga con Current Charging u otros cargadores).
        event.registerItem(Capabilities.EnergyStorage.ITEM, (stack, ctx) -> DeveloperPortableItem.createStorage(stack),
                ModItems.DEVELOPER_PORTABLE.get());
        // Developer de bloque: las 8 partes (y todas las caras) dan el almacén del controlador.
        event.registerBlock(Capabilities.EnergyStorage.BLOCK, (level, pos, state, be, side) -> {
            DeveloperBlockEntity origin = DeveloperBlock.originEntity(level, pos, state);
            return origin == null ? null : origin.getEnergy();
        }, ModBlocks.DEVELOPER_NORMAL.get(), ModBlocks.DEVELOPER_ADVANCED.get());
        registerDirectCharge(event);
        if (GameTestHooks.isGametestServer()) {
            // Solo en el servidor de GameTests: una "batería de otro mod" (pararrayos con FE) para probar que las
            // ranuras de batería aceptan cualquier ítem FE. En el juego (también en runClient) no se registra.
            event.registerItem(Capabilities.EnergyStorage.ITEM,
                    (stack, ctx) -> new ComponentEnergyStorage(stack, ModDataComponents.ENERGY.get(), 1000, 100),
                    Items.LIGHTNING_ROD);
            // Receptor FE de prueba (bloque de oro) para los tests de los generadores que empujan a vecinos.
            event.registerBlock(Capabilities.EnergyStorage.BLOCK, (level, pos, state, be, side) -> TEST_RECEIVER,
                    Blocks.GOLD_BLOCK);
        }
    }
}
