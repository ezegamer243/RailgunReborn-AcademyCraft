package com.railgunreborn.registry;

import java.util.function.Supplier;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.common.TeleportFallGuard;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.context.SkillContexts;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.CooldownData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.meltdowner.MdMark;
import com.railgunreborn.ability.teleporter.LocationData;
import com.railgunreborn.network.DataSync;
import com.railgunreborn.terminal.TerminalData;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public final class ModAttachments {
    private static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, RailgunReborn.MODID);

    // copyOnDeath: la ficha dice que nivel/exp no se pierden al morir.
    // Volver del End (Clone sin muerte) ya copia todo attachment serializable en NeoForge.
    public static final Supplier<AttachmentType<AbilityData>> ABILITY_DATA = ATTACHMENT_TYPES.register(
            "ability_data",
            () -> AttachmentType.builder(AbilityData::new)
                    .serialize(AbilityData.CODEC)
                    .copyOnDeath()
                    .build());

    // copyOnDeath: la ficha conserva CPData al morir; CPEvents restaura CP/overload y apaga el modo habilidad.
    public static final Supplier<AttachmentType<CPData>> CP_DATA = ATTACHMENT_TYPES.register(
            "cp_data",
            () -> AttachmentType.builder(CPData::new)
                    .serialize(CPData.CODEC)
                    .copyOnDeath()
                    .build());

    public static final Supplier<AttachmentType<PresetData>> PRESET_DATA = ATTACHMENT_TYPES.register(
            "preset_data",
            () -> AttachmentType.builder(PresetData::new)
                    .serialize(PresetData.CODEC)
                    .copyOnDeath()
                    .build());

    // Ubicaciones de Location Teleport: se guardan y sobreviven a la muerte (ficha §5).
    public static final Supplier<AttachmentType<LocationData>> LOCATION_DATA = ATTACHMENT_TYPES.register(
            "location_data",
            () -> AttachmentType.builder(LocationData::new)
                    .serialize(LocationData.CODEC)
                    .copyOnDeath()
                    .build());

    // Terminal de datos instalado: se guarda y sobrevive a la muerte (terminal.md sección 5).
    public static final Supplier<AttachmentType<TerminalData>> TERMINAL_DATA = ATTACHMENT_TYPES.register(
            "terminal_data",
            () -> AttachmentType.builder(() -> new TerminalData(false))
                    .serialize(TerminalData.CODEC)
                    .copyOnDeath()
                    .build());

    // Sin serializar ni copiar: tras clonar al jugador se hace un envío completo y los contadores empiezan de cero.
    public static final Supplier<AttachmentType<DataSync.State>> SYNC_STATE = ATTACHMENT_TYPES.register(
            "sync_state",
            () -> AttachmentType.builder(DataSync.State::new).build());

    // Sin serializar ni copyOnDeath (la ficha: no se guardan): morir o reconectar los deja vacíos.
    public static final Supplier<AttachmentType<CooldownData>> COOLDOWN_DATA = ATTACHMENT_TYPES.register(
            "cooldown_data",
            () -> AttachmentType.builder(CooldownData::new).build());

    // Contextos de habilidad activos del jugador (solo servidor).
    public static final Supplier<AttachmentType<SkillContexts.Active>> SKILL_CONTEXTS = ATTACHMENT_TYPES.register(
            "skill_contexts",
            () -> AttachmentType.builder(SkillContexts.Active::new).build());

    // Marca de Rad Intensify en cualquier ser vivo (solo servidor): ni se guarda ni se copia; morir la quita.
    public static final Supplier<AttachmentType<MdMark>> MD_MARK = ATTACHMENT_TYPES.register(
            "md_mark",
            () -> AttachmentType.builder(() -> new MdMark()).build());

    // Protección de caída tras un teletransporte de Teleporter (solo servidor, ni se guarda ni se copia).
    public static final Supplier<AttachmentType<TeleportFallGuard.Window>> TP_FALL_GUARD = ATTACHMENT_TYPES.register(
            "tp_fall_guard",
            () -> AttachmentType.builder(() -> new TeleportFallGuard.Window(0L, 0L)).build());

    // Marca "ya procesada" de Vector Manipulation en cualquier entidad (solo servidor): ni se guarda ni se copia; tras
    // recargar el mundo una entidad puede volver a procesarse como mucho una vez (vecmanip-targets.md §5).
    public static final Supplier<AttachmentType<Boolean>> VM_PROCESSED = ATTACHMENT_TYPES.register(
            "vm_processed",
            () -> AttachmentType.builder(() -> Boolean.FALSE).build());

    private ModAttachments() {
    }

    public static void register(IEventBus modEventBus) {
        ATTACHMENT_TYPES.register(modEventBus);
    }
}
