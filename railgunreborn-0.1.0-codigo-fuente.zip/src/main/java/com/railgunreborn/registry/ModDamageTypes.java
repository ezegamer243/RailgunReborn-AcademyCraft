package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;

/**
 * Tipos de daño propios. Son data-driven: cada uno tiene su JSON en {@code data/railgunreborn/damage_type/} y el
 * mensaje de muerte en el lang ({@code death.attack.railgunreborn.<id>}).
 */
public final class ModDamageTypes {
    public static final ResourceKey<DamageType> ARC_GEN = key("arc_gen");
    public static final ResourceKey<DamageType> THUNDER_BOLT = key("thunder_bolt");
    public static final ResourceKey<DamageType> RAILGUN = key("railgun");
    public static final ResourceKey<DamageType> MAG_MANIP = key("mag_manip");
    public static final ResourceKey<DamageType> THUNDER_CLAP = key("thunder_clap");
    public static final ResourceKey<DamageType> ELECTRON_BOMB = key("electron_bomb");
    public static final ResourceKey<DamageType> SCATTER_BOMB = key("scatter_bomb");
    /** Daño propio de Scatter Bomb al mantener hasta el tick 200 (sin atacante, ignora armadura). */
    public static final ResourceKey<DamageType> SCATTER_BOMB_SELF = key("scatter_bomb_self");
    public static final ResourceKey<DamageType> LIGHT_SHIELD = key("light_shield");
    public static final ResourceKey<DamageType> MELTDOWNER = key("meltdowner");
    public static final ResourceKey<DamageType> RAY_BARRAGE = key("ray_barrage");
    public static final ResourceKey<DamageType> JET_ENGINE = key("jet_engine");

    public static final ResourceKey<DamageType> ELECTRON_MISSILE = key("electron_missile");

    // Teleporter: los dos primeros ignoran armadura (etiqueta minecraft:bypasses_armor), Shift Teleport no.
    public static final ResourceKey<DamageType> THREATENING_TELEPORT = key("threatening_teleport");
    public static final ResourceKey<DamageType> FLESH_RIPPING = key("flesh_ripping");
    public static final ResourceKey<DamageType> SHIFT_TELEPORT = key("shift_teleport");

    // Vector Manipulation
    public static final ResourceKey<DamageType> DIR_SHOCK = key("dir_shock");
    public static final ResourceKey<DamageType> GROUND_SHOCK = key("ground_shock");
    public static final ResourceKey<DamageType> DIR_BLAST = key("dir_blast");
    public static final ResourceKey<DamageType> BLOOD_RETRO = key("blood_retro");
    /** Golpe devuelto y contragolpe de rayos de Vector Reflection (nunca se vuelve a reflejar). */
    public static final ResourceKey<DamageType> VEC_REFLECTION = key("vec_reflection");
    public static final ResourceKey<DamageType> PLASMA_CANNON = key("plasma_cannon");

    private ModDamageTypes() {
    }

    /** Fuente de daño de {@code type} causada directamente por {@code attacker} (respeta armadura). */
    public static DamageSource source(Entity attacker, ResourceKey<DamageType> type) {
        return attacker.damageSources().source(type, attacker);
    }

    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, name));
    }
}
