package com.railgunreborn.registry;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.RailgunReborn;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.entity.EntityType;
import net.neoforged.neoforge.registries.datamaps.DataMapType;
import net.neoforged.neoforge.registries.datamaps.RegisterDataMapTypesEvent;

/**
 * Data maps propios (NeoForge). Se registran en el bus del mod ({@link #register}, enganchado en el constructor del
 * mod). Archivos: {@code data/<ns>/data_maps/<registro>/<id>.json}; las claves de {@code values} admiten tipos
 * ({@code "minecraft:arrow"}) y etiquetas ({@code "#minecraft:arrows"}).
 */
public final class ModDataMaps {
    /**
     * Dificultad de Vector Manipulation por tipo de entidad ({@code docs/spec/vecmanip-targets.md} §4): multiplica el
     * coste en CP y la exp de Vector Deviation y Vector Reflection. Archivo:
     * {@code data/railgunreborn/data_maps/entity_type/vecmanip_difficulty.json}. Solo servidor (sin sincronizar).
     */
    public static final DataMapType<EntityType<?>, VecDifficulty> VECMANIP_DIFFICULTY = DataMapType
            .builder(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "vecmanip_difficulty"),
                    Registries.ENTITY_TYPE, VecDifficulty.CODEC)
            .build();

    /** Valor del mapa: {@code { "difficulty": número > 0 }}. */
    public record VecDifficulty(float difficulty) {
        public static final Codec<VecDifficulty> CODEC = RecordCodecBuilder.create(in -> in.group(
                ExtraCodecs.POSITIVE_FLOAT.fieldOf("difficulty").forGetter(VecDifficulty::difficulty))
                .apply(in, VecDifficulty::new));
    }

    private ModDataMaps() {
    }

    public static void register(RegisterDataMapTypesEvent event) {
        event.register(VECMANIP_DIFFICULTY);
    }
}
