package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.develop.DeveloperType;
import com.railgunreborn.block.DeveloperBlock;
import com.railgunreborn.block.CatEngineBlock;
import com.railgunreborn.block.ImagFusorBlock;
import com.railgunreborn.block.PhaseGenBlock;
import com.railgunreborn.block.SolarGenBlock;
import com.railgunreborn.block.WindGenBaseBlock;
import com.railgunreborn.block.WindGenMainBlock;
import com.railgunreborn.block.WindGenPillarBlock;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RailgunReborn.MODID);

    public static final DeferredBlock<DeveloperBlock> DEVELOPER_NORMAL = BLOCKS.register("developer_normal",
            () -> new DeveloperBlock(developerProperties(), DeveloperType.NORMAL));
    public static final DeferredBlock<DeveloperBlock> DEVELOPER_ADVANCED = BLOCKS.register("developer_advanced",
            () -> new DeveloperBlock(developerProperties(), DeveloperType.ADVANCED));

    // Menas y armazón (T82). Los drops de las menas son un placeholder (se sueltan a sí mismas): T83 los cambia por los del original con Fortuna.
    // Tags de herramienta en data/minecraft/tags/block (pickaxe, needs_stone_tool, needs_iron_tool).
    public static final DeferredBlock<Block> CONSTRAINT_METAL = BLOCKS.registerSimpleBlock("constraint_metal", stoneLike(4.0f));
    public static final DeferredBlock<Block> CRYSTAL_ORE = BLOCKS.registerSimpleBlock("crystal_ore", stoneLike(3.0f));
    public static final DeferredBlock<Block> IMAGSIL_ORE = BLOCKS.registerSimpleBlock("imagsil_ore", stoneLike(3.75f));
    public static final DeferredBlock<Block> RESO_ORE = BLOCKS.registerSimpleBlock("reso_ore", stoneLike(3.0f));
    public static final DeferredBlock<Block> MACHINE_FRAME = BLOCKS.registerSimpleBlock("machine_frame", stoneLike(4.0f));

    // Líquido de fase (T85): mismas propiedades que el bloque de agua vanilla, con luz 8 como el original.
    public static final DeferredBlock<LiquidBlock> PHASE_LIQUID = BLOCKS.register("phase_liquid",
            () -> new LiquidBlock(ModFluids.PHASE_LIQUID.get(), BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .replaceable().noCollission().strength(100.0f).lightLevel(state -> 8).pushReaction(PushReaction.DESTROY)
                    .noLootTable().liquid().sound(SoundType.EMPTY)));

    // Imag Fusor (T86): como el armazón de máquina (dureza 4, pico).
    public static final DeferredBlock<ImagFusorBlock> IMAG_FUSOR = BLOCKS.register("imag_fusor",
            () -> new ImagFusorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops()));

    // Generadores (T100): solar y Cat Engine (solo creativo).
    public static final DeferredBlock<SolarGenBlock> SOLAR_GEN = BLOCKS.register("solar_gen",
            () -> new SolarGenBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion()));
    public static final DeferredBlock<PhaseGenBlock> PHASE_GEN = BLOCKS.register("phase_gen",
            () -> new PhaseGenBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion()));
    public static final DeferredBlock<CatEngineBlock> CAT_ENGINE = BLOCKS.register("cat_engine",
            () -> new CatEngineBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f)
                    .sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion()));

    // Generador eólico (T102): base (2 de alto), pilares y cabeza (3 en fila). Dureza 4 y pico de hierro (original).
    public static final DeferredBlock<WindGenBaseBlock> WINDGEN_BASE = BLOCKS.register("windgen_base",
            () -> new WindGenBaseBlock(windGenProperties().pushReaction(PushReaction.BLOCK)));
    public static final DeferredBlock<WindGenPillarBlock> WINDGEN_PILLAR = BLOCKS.register("windgen_pillar",
            () -> new WindGenPillarBlock(windGenProperties()));
    public static final DeferredBlock<WindGenMainBlock> WINDGEN_MAIN = BLOCKS.register("windgen_main",
            () -> new WindGenMainBlock(windGenProperties().pushReaction(PushReaction.BLOCK)));

    private ModBlocks() {
    }

    /** Dureza 4, pico de hierro (tags en data/minecraft/tags/block/mineable y needs_iron_tool). */
    private static BlockBehaviour.Properties developerProperties() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f).sound(SoundType.STONE)
                .requiresCorrectToolForDrops().noOcclusion().pushReaction(PushReaction.BLOCK);
    }

    private static BlockBehaviour.Properties windGenProperties() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f).sound(SoundType.METAL)
                .requiresCorrectToolForDrops().noOcclusion();
    }

    /** Bloque de piedra/metal que solo suelta con la herramienta correcta. */
    private static BlockBehaviour.Properties stoneLike(float hardness) {
        return BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(hardness)
                .sound(SoundType.STONE).requiresCorrectToolForDrops();
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
    }
}
