package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.crafting.ImagFusorRecipe;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Tipos de receta propios (datos en {@code data/railgunreborn/recipe/}). */
public final class ModRecipes {
    private static final DeferredRegister<RecipeType<?>> TYPES = DeferredRegister.create(Registries.RECIPE_TYPE,
            RailgunReborn.MODID);
    private static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(
            Registries.RECIPE_SERIALIZER, RailgunReborn.MODID);

    public static final DeferredHolder<RecipeType<?>, RecipeType<ImagFusorRecipe>> IMAG_FUSOR = TYPES.register(
            "imag_fusor", () -> RecipeType.simple(ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "imag_fusor")));
    public static final DeferredHolder<RecipeSerializer<?>, ImagFusorRecipe.Serializer> IMAG_FUSOR_SERIALIZER =
            SERIALIZERS.register("imag_fusor", ImagFusorRecipe.Serializer::new);

    private ModRecipes() {
    }

    public static void register(IEventBus modEventBus) {
        TYPES.register(modEventBus);
        SERIALIZERS.register(modEventBus);
    }
}
