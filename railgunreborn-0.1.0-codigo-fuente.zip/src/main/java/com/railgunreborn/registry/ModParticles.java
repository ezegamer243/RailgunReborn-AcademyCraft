package com.railgunreborn.registry;

import java.util.function.Supplier;

import com.railgunreborn.RailgunReborn;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Tipos de partícula propios. Las texturas van en {@code assets/railgunreborn/particles/<id>.json}. */
public final class ModParticles {
    private static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, RailgunReborn.MODID);

    /**
     * Partícula "Md" de Meltdowner (punto verde de {@code textures/particle/md_particle.png}): marca de Rad Intensify
     * y efectos de las habilidades de la categoría. {@code overrideLimiter} true: se ve aunque haya muchas.
     */
    public static final Supplier<SimpleParticleType> MD = PARTICLES.register("md",
            () -> new SimpleParticleType(true));

    /** La misma partícula con el punto azul-violeta de {@code md_particle_luck.png} (Luck Mining Ray). */
    public static final Supplier<SimpleParticleType> MD_LUCK = PARTICLES.register("md_luck",
            () -> new SimpleParticleType(true));

    /**
     * Fórmula del crítico de espacio de Teleporter (una de {@code textures/particle/formula/0..9.png} al azar).
     * {@code overrideLimiter} false: es decorativa.
     */
    public static final Supplier<SimpleParticleType> FORMULA = PARTICLES.register("formula",
            () -> new SimpleParticleType(false));

    /** Mota azul de la estela de teletransporte de Teleporter ({@code textures/particle/tp_particle.png}). */
    public static final Supplier<SimpleParticleType> TP = PARTICLES.register("tp_particle",
            () -> new SimpleParticleType(false));

    private ModParticles() {
    }

    public static void register(IEventBus modEventBus) {
        PARTICLES.register(modEventBus);
    }
}
