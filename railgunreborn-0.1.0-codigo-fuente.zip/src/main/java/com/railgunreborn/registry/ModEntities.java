package com.railgunreborn.registry;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.entity.CoinEntity;
import com.railgunreborn.entity.MagneticBlockEntity;
import com.railgunreborn.entity.SilbarnEntity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    private static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE,
            RailgunReborn.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<CoinEntity>> COIN = ENTITIES.register("coin",
            () -> EntityType.Builder.<CoinEntity>of(CoinEntity::new, MobCategory.MISC)
                    .sized(0.2f, 0.2f).noSave().fireImmune().clientTrackingRange(10).updateInterval(1)
                    .build("coin"));

    /** Silicon Barn lanzado: fisica propia (sin gravedad de vanilla), no se guarda en disco. */
    public static final DeferredHolder<EntityType<?>, EntityType<SilbarnEntity>> SILBARN = ENTITIES.register(
            "silbarn", () -> EntityType.Builder.<SilbarnEntity>of(SilbarnEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f).noSave().clientTrackingRange(8).updateInterval(1).build("silbarn"));

    /** Bloque de Magnet Manipulation. Se guarda en disco (no se pierde el material si el mundo se guarda en vuelo). */
    public static final DeferredHolder<EntityType<?>, EntityType<MagneticBlockEntity>> MAGNETIC_BLOCK =
            ENTITIES.register("magnetic_block", () -> EntityType.Builder.<MagneticBlockEntity>of(
                    MagneticBlockEntity::new, MobCategory.MISC)
                    .sized(1.0f, 1.0f).fireImmune().clientTrackingRange(10).updateInterval(1)
                    .build("magnetic_block"));

    private ModEntities() {
    }

    public static void register(IEventBus modEventBus) {
        ENTITIES.register(modEventBus);
    }
}
