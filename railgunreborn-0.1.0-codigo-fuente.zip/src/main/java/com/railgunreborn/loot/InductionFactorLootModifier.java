package com.railgunreborn.loot;

import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.item.InductionFactorItem;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;

/**
 * Añade un Induction Factor (categoría al azar entre las registradas) con probabilidad {@code chance} a CUALQUIER
 * loot table de cofre: el id empieza por {@code chests/} en cualquier namespace (otros mods incluidos).
 */
public class InductionFactorLootModifier extends LootModifier {
    public static final float DEFAULT_CHANCE = 0.02f;

    public static final MapCodec<InductionFactorLootModifier> CODEC = RecordCodecBuilder.mapCodec(inst ->
            codecStart(inst).and(Codec.floatRange(0f, 1f).optionalFieldOf("chance", DEFAULT_CHANCE)
                    .forGetter(m -> m.chance)).apply(inst, InductionFactorLootModifier::new));

    private final float chance;

    public InductionFactorLootModifier(LootItemCondition[] conditions, float chance) {
        super(conditions);
        this.chance = chance;
    }

    public static boolean isChestTable(ResourceLocation tableId) {
        return tableId != null && tableId.getPath().startsWith("chests/");
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        if (!isChestTable(context.getQueriedLootTableId()) || context.getRandom().nextFloat() >= chance) {
            return loot;
        }
        List<Category> all = AbilityRegistries.CATEGORY_REGISTRY.stream().toList();
        if (all.isEmpty()) {
            return loot;
        }
        Category category = all.get(context.getRandom().nextInt(all.size()));
        loot.add(InductionFactorItem.of(category.getId()));
        return loot;
    }

    @Override
    public MapCodec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }
}
