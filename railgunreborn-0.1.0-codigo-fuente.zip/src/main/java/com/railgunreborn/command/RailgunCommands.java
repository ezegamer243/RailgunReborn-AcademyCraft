package com.railgunreborn.command;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.Category;
import com.railgunreborn.ability.Skill;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.ability.data.PresetData;
import com.railgunreborn.ability.data.PresetRules;
import com.railgunreborn.terminal.TerminalAccess;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Comandos de prueba {@code /railgunreborn <sub> [args] [target]} (nivel 2, salvo {@code needleonly}, libre). Sin target actúa sobre quien ejecuta.
 *
 * <p>Los ids se validan contra los registros de {@code AbilityRegistries}. Lo que se escribe sin namespace va en
 * {@code railgunreborn}. Categorías: {@code electromaster} -> {@code railgunreborn:electromaster}.
 * Habilidades: {@code electromaster/arc_gen} -> {@code railgunreborn:electromaster/arc_gen}
 * (ruta {@code <categoría>/<habilidad>}). El argumento id de Brigadier rellena {@code minecraft} cuando no hay
 * namespace, así que {@code minecraft:} se trata como "sin namespace" (no hay categorías de vanilla).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID)
public final class RailgunCommands {
    private static final SimpleCommandExceptionType NO_CATEGORY =
            new SimpleCommandExceptionType(Component.translatable("commands.railgunreborn.error.no_category"));

    private static final DynamicCommandExceptionType UNKNOWN_CATEGORY = new DynamicCommandExceptionType(
            id -> Component.translatable("commands.railgunreborn.error.unknown_category", id));
    private static final DynamicCommandExceptionType UNKNOWN_SKILL = new DynamicCommandExceptionType(
            id -> Component.translatable("commands.railgunreborn.error.unknown_skill", id));
    private static final Dynamic2CommandExceptionType WRONG_CATEGORY = new Dynamic2CommandExceptionType(
            (skill, category) -> Component.translatable("commands.railgunreborn.error.wrong_category", skill,
                    category));

    private static final DynamicCommandExceptionType DUPLICATE_SKILL = new DynamicCommandExceptionType(
            id -> Component.translatable("commands.railgunreborn.error.duplicate_skill", id));
    private static final DynamicCommandExceptionType NOT_LEARNED = new DynamicCommandExceptionType(
            id -> Component.translatable("commands.railgunreborn.error.not_learned", id));
    private static final DynamicCommandExceptionType NOT_CONTROLLABLE = new DynamicCommandExceptionType(
            id -> Component.translatable("commands.railgunreborn.error.not_controllable", id));

    // Sugerencias sacadas de los registros; las del mod se muestran sin namespace (así se escriben).
    private static final SuggestionProvider<CommandSourceStack> CATEGORY_SUGGESTIONS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Stream.concat(
                    AbilityRegistries.CATEGORY_REGISTRY.keySet().stream().map(RailgunCommands::shortId),
                    Stream.of("none")), builder);
    private static final SuggestionProvider<CommandSourceStack> SKILL_SUGGESTIONS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(
                    AbilityRegistries.SKILL_REGISTRY.keySet().stream().map(RailgunCommands::shortId), builder);
    /** {@code learn} acepta además {@code <categoría>/all}. */
    private static final String ALL_SUFFIX = "/all";
    private static final SuggestionProvider<CommandSourceStack> LEARN_SUGGESTIONS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Stream.concat(
                    AbilityRegistries.CATEGORY_REGISTRY.keySet().stream().map(id -> shortId(id) + ALL_SUFFIX),
                    AbilityRegistries.SKILL_REGISTRY.keySet().stream().map(RailgunCommands::shortId)), builder);

    private RailgunCommands() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal(RailgunReborn.MODID);
        // La raíz es libre: cada subcomando pide nivel 2 salvo needleonly (actúa solo sobre quien lo ejecuta).

        thenOp(root, withTarget(Commands.literal("info"), RailgunCommands::info));

        // "category none" es un literal aparte para que no se confunda con un id.
        thenOp(root, Commands.literal("category")
                .then(withTarget(Commands.literal("none"), t -> setCategory(t, null)))
                .then(withTarget(Commands.argument("id", ResourceLocationArgument.id())
                        .suggests(CATEGORY_SUGGESTIONS),
                        t -> setCategory(t, resolveCategory(t)))));

        thenOp(root, Commands.literal("level")
                .then(withTarget(Commands.argument("level", IntegerArgumentType.integer(1, AbilityData.MAX_LEVEL)),
                        RailgunCommands::setLevel)));

        thenOp(root, Commands.literal("learn")
                .then(withTarget(Commands.argument("skill", ResourceLocationArgument.id())
                        .suggests(LEARN_SUGGESTIONS), RailgunCommands::learn)));

        thenOp(root, Commands.literal("exp")
                .then(Commands.argument("skill", ResourceLocationArgument.id()).suggests(SKILL_SUGGESTIONS)
                        .then(withTarget(Commands.argument("exp", FloatArgumentType.floatArg(0f, 1f)),
                                RailgunCommands::setExp))));

        thenOp(root, Commands.literal("cp")
                .then(withTarget(Commands.literal("full"), RailgunCommands::cpFull)));

        thenOp(root, Commands.literal("activate")
                .then(withTarget(Commands.argument("value", BoolArgumentType.bool()),
                        RailgunCommands::activate)));

        // preset <1..4> <ranura 1..4> <skill|none> [target]
        thenOp(root, Commands.literal("preset")
                .then(Commands.argument("preset", IntegerArgumentType.integer(1, PresetData.MAX_PRESETS))
                        .then(Commands.argument("slot", IntegerArgumentType.integer(1, PresetData.MAX_SLOTS))
                                .then(withTarget(Commands.literal("none"), t -> setPreset(t, false)))
                                .then(withTarget(Commands.argument("skill", ResourceLocationArgument.id())
                                        .suggests(SKILL_SUGGESTIONS), t -> setPreset(t, true))))));

        thenOp(root, withTarget(Commands.literal("reset"), RailgunCommands::reset));

        thenOp(root, Commands.literal("terminal")
                .then(withTarget(Commands.literal("install"), t -> setTerminal(t, true)))
                .then(withTarget(Commands.literal("uninstall"), t -> setTerminal(t, false))));

        // Red inalámbrica (T103): depuración hasta las pantallas de T104.
        thenOp(root, WirelessCommands.build());

        root.then(Commands.literal("needleonly")
                .executes(RailgunCommands::needleOnlyShow)
                .then(Commands.literal("on").executes(ctx -> needleOnlySet(ctx, true)))
                .then(Commands.literal("off").executes(ctx -> needleOnlySet(ctx, false))));

        dispatcher.register(root);
    }

    /** Añade un subcomando que exige permiso de operador (nivel 2). */
    private static void thenOp(LiteralArgumentBuilder<CommandSourceStack> root,
            ArgumentBuilder<CommandSourceStack, ?> child) {
        root.then(child.requires(src -> src.hasPermission(2)));
    }

    private static int needleOnlyShow(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        boolean on = AbilityData.get(p).isNeedleOnly();
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.needleonly.state",
                onOff(on)), false);
        return on ? 1 : 0;
    }

    private static int needleOnlySet(CommandContext<CommandSourceStack> ctx, boolean on) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        AbilityData.get(p).setNeedleOnly(on);
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.needleonly.set",
                onOff(on)), false);
        return on ? 1 : 0;
    }

    private static Component onOff(boolean value) {
        return Component.translatable(value ? "commands.railgunreborn.on" : "commands.railgunreborn.off");
    }

    /** Ejecuta en el propio jugador y también con un {@code [target]} final (selector de jugadores). */
    private static <T extends ArgumentBuilder<CommandSourceStack, T>> T withTarget(T node, ContextAction action) {
        node.executes(ctx -> action.apply(new Targeted(ctx, ctx.getSource().getPlayerOrException())));
        node.then(Commands.argument("target", EntityArgument.player())
                .executes(ctx -> action.apply(new Targeted(ctx, EntityArgument.getPlayer(ctx, "target")))));
        return node;
    }

    /** Contexto + jugador objetivo, para que los handlers no repitan la resolución del target. */
    private record Targeted(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
    }

    @FunctionalInterface
    private interface ContextAction {
        int apply(Targeted t) throws CommandSyntaxException;
    }

    // --- Subcomandos ---

    private static int info(Targeted t) {
        ServerPlayer p = t.target();
        AbilityData ability = AbilityData.get(p);
        CPData cp = CPData.get(p);
        CommandSourceStack src = t.ctx().getSource();

        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.header", p.getDisplayName()),
                false);
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.category",
                ability.getCategory().map(ResourceLocation::toString).orElse("-")), false);
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.level",
                ability.getLevel(), progressText(ability)), false);
        String skills = ability.getLearnedSkills().stream()
                .map(id -> id + " (" + fmt(ability.getSkillExp(id) * 100f) + "%)")
                .collect(Collectors.joining(", "));
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.skills",
                skills.isEmpty() ? "-" : skills), false);
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.cp",
                fmt(cp.getCP()), fmt(cp.getMaxCP())), false);
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.overload",
                fmt(cp.getOverload()), fmt(cp.getMaxOverload())), false);
        src.sendSuccess(() -> Component.translatable("commands.railgunreborn.info.state",
                yesNo(cp.isActivated()), yesNo(cp.isOverloaded())), false);
        return 1;
    }

    private static int setCategory(Targeted t, ResourceLocation category) {
        ServerPlayer p = t.target();
        AbilityData.get(p).setCategory(category);
        CPData.get(p); // aplica el cambio de categoría pendiente (recalcula CP máximo)
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.category.set",
                p.getDisplayName(), category == null ? "-" : category.toString()), true);
        return 1;
    }

    private static int setLevel(Targeted t) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        AbilityData ability = AbilityData.get(p);
        if (!ability.hasCategory()) {
            throw NO_CATEGORY.create();
        }
        int level = IntegerArgumentType.getInteger(t.ctx(), "level");
        ability.setLevel(level);
        CPData.get(p);
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.level.set",
                p.getDisplayName(), level), true);
        return level;
    }

    private static int learn(Targeted t) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        AbilityData ability = AbilityData.get(p);
        if (!ability.hasCategory()) {
            throw NO_CATEGORY.create();
        }
        ResourceLocation raw = normalize(ResourceLocationArgument.getId(t.ctx(), "skill"));
        if (raw.getPath().endsWith(ALL_SUFFIX)) {
            return learnAll(t, ability, raw);
        }
        ResourceLocation skill = resolveSkill(t, ability);
        boolean added = ability.learnSkill(skill);
        t.ctx().getSource().sendSuccess(() -> Component.translatable(
                added ? "commands.railgunreborn.learn.success" : "commands.railgunreborn.learn.already",
                p.getDisplayName(), skill.toString()), added);
        return added ? 1 : 0;
    }

    /** {@code learn <categoría>/all}: aprende todas las habilidades (también pasivas) de la categoría del jugador. */
    private static int learnAll(Targeted t, AbilityData ability, ResourceLocation raw) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        String path = raw.getPath();
        ResourceLocation categoryId = ResourceLocation.fromNamespaceAndPath(raw.getNamespace(),
                path.substring(0, path.length() - ALL_SUFFIX.length()));
        Category category = AbilityRegistries.category(categoryId)
                .orElseThrow(() -> UNKNOWN_CATEGORY.create(categoryId.toString()));
        ResourceLocation own = ability.getCategory().orElseThrow(NO_CATEGORY::create);
        if (!own.equals(categoryId)) {
            throw WRONG_CATEGORY.create(raw.toString(), own.toString());
        }
        int added = 0;
        for (Skill skill : category.getSkills()) {
            if (ability.learnSkill(skill.getId())) {
                added++;
            }
        }
        CPData.get(p); // aplica el bonus de las genéricas recién aprendidas
        int count = added;
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.learn.all",
                p.getDisplayName(), count, categoryId.toString()), count > 0);
        return count;
    }

    private static int setExp(Targeted t) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        AbilityData ability = AbilityData.get(p);
        if (!ability.hasCategory()) {
            throw NO_CATEGORY.create();
        }
        ResourceLocation skill = resolveSkill(t, ability);
        float exp = FloatArgumentType.getFloat(t.ctx(), "exp");
        ability.setSkillExp(skill, exp);
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.exp.set",
                p.getDisplayName(), skill.toString(), fmt(exp)), true);
        return 1;
    }

    private static int cpFull(Targeted t) {
        ServerPlayer p = t.target();
        CPData.get(p).recoverAll();
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.cp.full",
                p.getDisplayName()), true);
        return 1;
    }

    private static int activate(Targeted t) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        boolean value = BoolArgumentType.getBool(t.ctx(), "value");
        if (value && !AbilityData.get(p).hasCategory()) {
            throw NO_CATEGORY.create();
        }
        CPData.get(p).setActivated(p, value);
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.activate.set",
                p.getDisplayName(), yesNo(value)), true);
        return 1;
    }

    private static int setPreset(Targeted t, boolean withSkill) throws CommandSyntaxException {
        ServerPlayer p = t.target();
        AbilityData ability = AbilityData.get(p);
        if (!ability.hasCategory()) {
            throw NO_CATEGORY.create();
        }
        int preset = IntegerArgumentType.getInteger(t.ctx(), "preset");
        int slot = IntegerArgumentType.getInteger(t.ctx(), "slot");
        ResourceLocation skillId = withSkill ? normalize(ResourceLocationArgument.getId(t.ctx(), "skill")) : null;
        // Misma validación que el payload de edición; con error no cambia nada.
        PresetRules.Result result = PresetRules.applyEdit(p, preset - 1, slot - 1, skillId);
        String id = String.valueOf(skillId);
        switch (result) {
            case NO_CATEGORY -> throw NO_CATEGORY.create();
            case UNKNOWN_SKILL -> throw UNKNOWN_SKILL.create(id);
            case WRONG_CATEGORY -> throw WRONG_CATEGORY.create(id, ability.getCategory().orElseThrow().toString());
            case NOT_LEARNED -> throw NOT_LEARNED.create(id);
            case NOT_CONTROLLABLE -> throw NOT_CONTROLLABLE.create(id);
            case DUPLICATE -> throw DUPLICATE_SKILL.create(id);
            case BAD_INDEX -> throw new IllegalStateException("Index already limited by Brigadier");
            case OK -> { }
        }
        String shown = skillId == null ? "-" : skillId.toString();
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.preset.set",
                p.getDisplayName(), preset, slot, shown), true);
        return 1;
    }

    private static int reset(Targeted t) {
        ServerPlayer p = t.target();
        AbilityData.get(p).setCategory(null);
        CPData cp = CPData.get(p);
        cp.setActivated(p, false);
        cp.recoverAll();
        t.ctx().getSource().sendSuccess(() -> Component.translatable("commands.railgunreborn.reset",
                p.getDisplayName()), true);
        return 1;
    }

    private static int setTerminal(Targeted t, boolean installed) {
        ServerPlayer p = t.target();
        TerminalAccess.setInstalled(p, installed);
        t.ctx().getSource().sendSuccess(() -> Component.translatable(
                installed ? "commands.railgunreborn.terminal.install" : "commands.railgunreborn.terminal.uninstall",
                p.getDisplayName()), true);
        return 1;
    }

    // --- Utilidades ---

    private static ResourceLocation resolveCategory(Targeted t) throws CommandSyntaxException {
        ResourceLocation id = normalize(ResourceLocationArgument.getId(t.ctx(), "id"));
        if (AbilityRegistries.category(id).isEmpty()) {
            throw UNKNOWN_CATEGORY.create(id.toString());
        }
        return id;
    }

    /** La habilidad debe existir y ser de la categoría actual del jugador (si no, no la podría usar). */
    private static ResourceLocation resolveSkill(Targeted t, AbilityData ability) throws CommandSyntaxException {
        ResourceLocation id = normalize(ResourceLocationArgument.getId(t.ctx(), "skill"));
        Skill skill = AbilityRegistries.skill(id).orElseThrow(() -> UNKNOWN_SKILL.create(id.toString()));
        ResourceLocation category = ability.getCategory().orElseThrow(NO_CATEGORY::create);
        if (!skill.getCategoryId().equals(category)) {
            throw WRONG_CATEGORY.create(id.toString(), category.toString());
        }
        return id;
    }

    /** Progreso bruto y fracción hacia el siguiente nivel (100% = la máquina le dejaría subir). */
    private static String progressText(AbilityData ability) {
        String raw = fmt(ability.getLevelProgress());
        return AbilityRegistries.category(ability.getCategory().orElse(null))
                .map(c -> raw + " = " + fmt(c.levelProgressFraction(ability.getLevel(), ability.getLevelProgress())
                        * 100f) + "%")
                .orElse(raw);
    }

    private static String shortId(ResourceLocation id) {
        return RailgunReborn.MODID.equals(id.getNamespace()) ? id.getPath() : id.toString();
    }

    /** Sin namespace explícito el argumento da {@code minecraft}: se reinterpreta como {@code railgunreborn}. */
    private static ResourceLocation normalize(ResourceLocation id) {
        return "minecraft".equals(id.getNamespace())
                ? ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, id.getPath())
                : id;
    }

    private static String fmt(float value) {
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    private static Component yesNo(boolean value) {
        return Component.translatable(value ? "commands.railgunreborn.yes" : "commands.railgunreborn.no");
    }
}
