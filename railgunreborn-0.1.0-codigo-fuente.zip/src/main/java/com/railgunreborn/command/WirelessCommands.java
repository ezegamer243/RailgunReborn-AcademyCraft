package com.railgunreborn.command;

import javax.annotation.Nullable;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.wireless.MatrixBlock;
import com.railgunreborn.wireless.MatrixBlockEntity;
import com.railgunreborn.wireless.NodeBlockEntity;
import com.railgunreborn.wireless.NodeLinks;
import com.railgunreborn.wireless.WirelessData;
import com.railgunreborn.wireless.WirelessNetwork;
import com.railgunreborn.wireless.WirelessResult;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Comandos de depuración de la red inalámbrica ({@code /railgunreborn wireless ...}, solo operadores) hasta que T104
 * traiga las pantallas. Actúan sobre el bloque al que mira el jugador. Nunca muestran contraseñas.
 * <ul>
 * <li>{@code create <ssid> <contraseña>}: crea la red de la matriz mirada.</li>
 * <li>{@code join <ssid> <contraseña>}: une el nodo mirado a la red con ese SSID más cercana a su alcance.</li>
 * <li>{@code leave}: saca de su red al nodo mirado.</li>
 * <li>{@code link <nodo x y z> <contraseña> [generator|receiver]}: enlaza el bloque FE mirado al nodo.</li>
 * <li>{@code unlink}: desenlaza el bloque mirado.</li>
 * <li>{@code info}: estado de la matriz, nodo o bloque enlazado mirado.</li>
 * </ul>
 * Las contraseñas vacías se escriben {@code ""}.
 */
final class WirelessCommands {
    private static final SimpleCommandExceptionType NO_TARGET = new SimpleCommandExceptionType(
            Component.translatable("commands.railgunreborn.wireless.no_target"));

    private WirelessCommands() {
    }

    static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("wireless")
                .then(Commands.literal("create")
                        .then(Commands.argument("ssid", StringArgumentType.string())
                                .then(Commands.argument("password", StringArgumentType.string())
                                        .executes(WirelessCommands::create))))
                .then(Commands.literal("join")
                        .then(Commands.argument("ssid", StringArgumentType.string())
                                .then(Commands.argument("password", StringArgumentType.string())
                                        .executes(WirelessCommands::join))))
                .then(Commands.literal("leave").executes(WirelessCommands::leave))
                .then(Commands.literal("link")
                        .then(Commands.argument("node", BlockPosArgument.blockPos())
                                .then(Commands.argument("password", StringArgumentType.string())
                                        .executes(ctx -> link(ctx, null))
                                        .then(Commands.literal("generator")
                                                .executes(ctx -> link(ctx, NodeLinks.Role.GENERATOR)))
                                        .then(Commands.literal("receiver")
                                                .executes(ctx -> link(ctx, NodeLinks.Role.RECEIVER))))))
                .then(Commands.literal("unlink").executes(WirelessCommands::unlink))
                .then(Commands.literal("info").executes(WirelessCommands::info));
    }

    /** Bloque al que mira quien ejecuta (al alcance de interacción). */
    private static BlockPos target(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        HitResult hit = player.pick(player.blockInteractionRange(), 0f, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            throw NO_TARGET.create();
        }
        return ((BlockHitResult) hit).getBlockPos();
    }

    private static int report(CommandContext<CommandSourceStack> ctx, WirelessResult result, String successKey,
            Object... args) {
        if (!result.ok()) {
            ctx.getSource().sendFailure(result.message());
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable(successKey, args), true);
        return 1;
    }

    private static int create(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        BlockPos pos = target(ctx);
        String ssid = StringArgumentType.getString(ctx, "ssid");
        WirelessResult result = WirelessData.get(level).createNetwork(level, pos,
                ssid, StringArgumentType.getString(ctx, "password"));
        return report(ctx, result, "commands.railgunreborn.wireless.created", ssid);
    }

    private static int join(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        BlockPos pos = target(ctx);
        String ssid = StringArgumentType.getString(ctx, "ssid");
        WirelessResult result = WirelessData.get(level).joinNetworkBySsid(level, pos, ssid,
                StringArgumentType.getString(ctx, "password"));
        return report(ctx, result, "commands.railgunreborn.wireless.joined", ssid);
    }

    private static int leave(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        return report(ctx, WirelessData.get(level).leaveNetwork(target(ctx)),
                "commands.railgunreborn.wireless.left");
    }

    private static int link(CommandContext<CommandSourceStack> ctx, @Nullable NodeLinks.Role role)
            throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        BlockPos user = target(ctx);
        BlockPos node = BlockPosArgument.getLoadedBlockPos(ctx, "node");
        String password = StringArgumentType.getString(ctx, "password");
        WirelessData data = WirelessData.get(level);
        WirelessResult result = role == null ? data.linkUser(level, user, node, password)
                : data.linkUser(level, user, node, password, role);
        return report(ctx, result, "commands.railgunreborn.wireless.linked", node.toShortString());
    }

    private static int unlink(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        return report(ctx, WirelessData.get(level).unlinkUser(target(ctx)),
                "commands.railgunreborn.wireless.unlinked");
    }

    private static int info(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerLevel level = ctx.getSource().getLevel();
        BlockPos pos = target(ctx);
        WirelessData data = WirelessData.get(level);
        CommandSourceStack source = ctx.getSource();
        MatrixBlockEntity matrix = MatrixBlock.entityAt(level, pos);
        if (matrix != null) {
            WirelessNetwork net = data.getNetwork(matrix.getBlockPos());
            source.sendSuccess(() -> Component.translatable("commands.railgunreborn.wireless.info.matrix",
                    matrix.getCoreLevel(), matrix.getPlateCount(), MatrixBlockEntity.PLATE_SLOTS,
                    matrix.getCapacity(), EnergyFormat.format(matrix.getBandwidth()),
                    String.format(java.util.Locale.ROOT, "%.1f", matrix.getRange())), false);
            if (net != null) {
                source.sendSuccess(() -> Component.translatable("commands.railgunreborn.wireless.info.network",
                        net.getSsid(), net.getLoad(), EnergyFormat.format(net.getBuffer())), false);
            } else {
                source.sendSuccess(() -> WirelessResult.NO_NETWORK.message(), false);
            }
            return 1;
        }
        if (level.getBlockEntity(pos) instanceof NodeBlockEntity node) {
            WirelessNetwork net = data.networkOfNode(pos);
            NodeLinks links = data.linksOf(pos);
            source.sendSuccess(() -> Component.translatable("commands.railgunreborn.wireless.info.node",
                    node.getNodeName(), node.getNodeType().id,
                    EnergyFormat.fraction(node.getEnergy().getEnergyStored(), node.getEnergy().getMaxEnergyStored()),
                    net == null ? "-" : net.getSsid(),
                    links == null ? 0 : links.getGenerators().size(),
                    links == null ? 0 : links.getReceivers().size(), node.getNodeType().maxLinks), false);
            return 1;
        }
        BlockPos node = data.nodeOfUser(pos);
        source.sendSuccess(() -> node == null ? WirelessResult.NOT_LINKED.message()
                : Component.translatable("commands.railgunreborn.wireless.info.user", node.toShortString()), false);
        return 1;
    }
}
