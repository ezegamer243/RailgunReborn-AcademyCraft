package com.railgunreborn.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.registry.ModRecipes;

import net.minecraft.core.HolderLookup;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.Level;

/**
 * Receta del Imag Fusor ({@code ImagFusorRecipes} del original): 1 ítem de entrada + {@code liquid} mB de líquido de
 * fase -> resultado, en {@code time} ticks. {@code energy_per_tick} se guarda para la fase de energía (12 IF/tick en
 * el original) pero hoy no se consume: las máquinas trabajan gratis (decisión del usuario, opción A de survival.md).
 */
public record ImagFusorRecipe(Ingredient ingredient, int liquid, ItemStack result, int time, int energyPerTick)
        implements Recipe<SingleRecipeInput> {

    public static final int DEFAULT_TIME = 120;
    public static final int DEFAULT_ENERGY_PER_TICK = 12;

    public static final MapCodec<ImagFusorRecipe> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter(ImagFusorRecipe::ingredient),
            Codec.intRange(1, Integer.MAX_VALUE).fieldOf("liquid").forGetter(ImagFusorRecipe::liquid),
            ItemStack.STRICT_CODEC.fieldOf("result").forGetter(ImagFusorRecipe::result),
            Codec.intRange(1, Integer.MAX_VALUE).optionalFieldOf("time", DEFAULT_TIME).forGetter(ImagFusorRecipe::time),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("energy_per_tick", DEFAULT_ENERGY_PER_TICK)
                    .forGetter(ImagFusorRecipe::energyPerTick))
            .apply(i, ImagFusorRecipe::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, ImagFusorRecipe> STREAM_CODEC = StreamCodec.composite(
            Ingredient.CONTENTS_STREAM_CODEC, ImagFusorRecipe::ingredient,
            ByteBufCodecs.VAR_INT, ImagFusorRecipe::liquid,
            ItemStack.STREAM_CODEC, ImagFusorRecipe::result,
            ByteBufCodecs.VAR_INT, ImagFusorRecipe::time,
            ByteBufCodecs.VAR_INT, ImagFusorRecipe::energyPerTick,
            ImagFusorRecipe::new);

    @Override
    public boolean matches(SingleRecipeInput input, Level level) {
        return ingredient.test(input.item());
    }

    @Override
    public ItemStack assemble(SingleRecipeInput input, HolderLookup.Provider registries) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return result;
    }

    /** Fuera del libro de recetas vanilla (si no, el cliente avisa de una categoría desconocida). */
    @Override
    public boolean isSpecial() {
        return true;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.IMAG_FUSOR_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return ModRecipes.IMAG_FUSOR.get();
    }

    public static final class Serializer implements RecipeSerializer<ImagFusorRecipe> {
        @Override
        public MapCodec<ImagFusorRecipe> codec() {
            return CODEC;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, ImagFusorRecipe> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
