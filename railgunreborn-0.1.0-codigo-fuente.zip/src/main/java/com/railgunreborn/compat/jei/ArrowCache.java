package com.railgunreborn.compat.jei;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.railgunreborn.energy.EnergyFormat;

import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.helpers.IGuiHelper;
import net.minecraft.network.chat.Component;

/** Flechas animadas de JEI por duración: crear una por fotograma reiniciaría la animación. */
final class ArrowCache {
    private final IGuiHelper gui;
    private final Map<Integer, IDrawableAnimated> arrows = new HashMap<>();

    ArrowCache(IGuiHelper gui) {
        this.gui = gui;
    }

    IDrawableAnimated get(int ticks) {
        return arrows.computeIfAbsent(Math.max(1, ticks), gui::createAnimatedRecipeArrow);
    }

    /** "Energía: 1 440 IF". */
    static Component energy(long total) {
        return Component.translatable("jei.railgunreborn.energy", EnergyFormat.format(total));
    }

    static Component seconds(int ticks) {
        return Component.translatable("jei.railgunreborn.time", String.format(Locale.ROOT, "%.1f", ticks / 20f));
    }
}
