package com.railgunreborn.compat.jei;

import java.util.ArrayList;
import java.util.List;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.screen.ImagFusorScreen;
import com.railgunreborn.crafting.ImagFusorRecipe;
import com.railgunreborn.metalformer.MetalFormerInput;
import com.railgunreborn.metalformer.MetalFormerMode;
import com.railgunreborn.metalformer.MetalFormerRecipe;
import com.railgunreborn.metalformer.MetalFormerRecipes;
import com.railgunreborn.metalformer.MetalFormerRegistry;
import com.railgunreborn.metalformer.client.MetalFormerScreen;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModItems;
import com.railgunreborn.registry.ModRecipes;
import com.railgunreborn.wireless.WirelessRegistry;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.neoforge.NeoForgeTypes;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * Compatibilidad opcional con JEI (T95). JEI encuentra esta clase por la anotación y solo si está instalado: ninguna
 * clase fuera de {@code compat.jei} toca la API de JEI, así que el mod carga igual sin él.
 */
@JeiPlugin
public class RailgunJeiPlugin implements IModPlugin {
    private static final ResourceLocation UID = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "jei_plugin");

    // Zonas clicables (barra de progreso) en píxeles de GUI: la mitad de TechUiLayout.*_PROGRESS_U/V/W/H (arte a 2x).
    private static final int FUSOR_CLICK_X = 57;
    private static final int FUSOR_CLICK_Y = 46;
    private static final int FUSOR_CLICK_W = 63;
    private static final int FUSOR_CLICK_H = 15;
    private static final int FORMER_CLICK_X = 59;
    private static final int FORMER_CLICK_Y = 46;
    private static final int FORMER_CLICK_W = 57;
    private static final int FORMER_CLICK_H = 15;

    @Override
    public ResourceLocation getPluginUid() {
        return UID;
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        IGuiHelper gui = registration.getJeiHelpers().getGuiHelper();
        registration.addRecipeCategories(new ImagFusorCategory(gui), new MetalFormerCategory(gui));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        Level level = Minecraft.getInstance().level;
        if (level != null) {
            RecipeManager recipes = level.getRecipeManager();
            List<RecipeHolder<ImagFusorRecipe>> fusor = recipes.getAllRecipesFor(ModRecipes.IMAG_FUSOR.get());
            registration.addRecipes(ImagFusorCategory.TYPE, fusor);
            registration.addRecipes(MetalFormerCategory.TYPE, metalFormerRecipes(level, recipes));
        }
        addInfo(registration);
    }

    /** Recetas del JSON + las de "refinar con el horno" para menas de otros mods (las que no tienen receta propia). */
    private static List<MetalFormerDisplay> metalFormerRecipes(Level level, RecipeManager recipes) {
        List<MetalFormerDisplay> list = new ArrayList<>();
        for (RecipeHolder<MetalFormerRecipe> holder : recipes.getAllRecipesFor(MetalFormerRegistry.RECIPE_TYPE.get())) {
            MetalFormerRecipe r = holder.value();
            list.add(new MetalFormerDisplay(r.mode(), List.of(r.ingredient().getItems()), r.result(), r.time(), r.energy(), false));
        }
        for (Holder<Item> item : BuiltInRegistries.ITEM.getTagOrEmpty(MetalFormerRecipes.REFINE_BY_SMELTING)) {
            ItemStack input = new ItemStack(item);
            if (recipes.getRecipeFor(MetalFormerRegistry.RECIPE_TYPE.get(),
                    new MetalFormerInput(input, MetalFormerMode.REFINE), level).isPresent()) {
                continue;
            }
            // Mismo cálculo que MetalFormerRecipes.find: el doble del horno, con tope de 64 y del stack.
            SingleRecipeInput smelt = new SingleRecipeInput(input);
            recipes.getRecipeFor(RecipeType.SMELTING, smelt, level).ifPresent(h -> {
                ItemStack out = h.value().assemble(smelt, level.registryAccess());
                out.setCount(Math.min(Math.min(out.getCount() * 2, 64), out.getMaxStackSize()));
                if (!out.isEmpty()) {
                    list.add(new MetalFormerDisplay(MetalFormerMode.REFINE, List.of(input), out,
                            MetalFormerRecipe.DEFAULT_TIME, MetalFormerRecipe.DEFAULT_ENERGY, true));
                }
            });
        }
        return list;
    }

    private static void addInfo(IRecipeRegistration registration) {
        registration.addIngredientInfo(CategoryReactorRegistry.ITEM.get(),
                Component.translatable("jei.railgunreborn.info.category_reactor"));
        registration.addIngredientInfo(ModItems.INDUCTION_FACTOR.get(),
                Component.translatable("jei.railgunreborn.info.induction_factor"));
        Component liquid = Component.translatable("jei.railgunreborn.info.phase_liquid");
        registration.addIngredientInfo(ModItems.PHASE_LIQUID_BUCKET.get(), liquid);
        registration.addIngredientInfo(new FluidStack(ModFluids.PHASE_LIQUID.get(), 1000), NeoForgeTypes.FLUID_STACK,
                liquid);
        registration.addIngredientInfo(ModItems.SOLAR_GEN.get(),
                Component.translatable("jei.railgunreborn.info.solar_gen"));
        registration.addIngredientInfo(ModItems.PHASE_GEN.get(),
                Component.translatable("jei.railgunreborn.info.phase_gen"));
        Component wind = Component.translatable("jei.railgunreborn.info.windgen");
        registration.addIngredientInfo(ModItems.WINDGEN_BASE.get(), wind);
        registration.addIngredientInfo(ModItems.WINDGEN_PILLAR.get(), wind);
        registration.addIngredientInfo(ModItems.WINDGEN_MAIN.get(), wind);
        registration.addIngredientInfo(ModItems.WINDGEN_FAN.get(), wind);
        registration.addIngredientInfo(ModItems.CAT_ENGINE.get(),
                Component.translatable("jei.railgunreborn.info.cat_engine"));
        Component matrix = Component.translatable("jei.railgunreborn.info.matrix");
        registration.addIngredientInfo(WirelessRegistry.MATRIX_ITEM.get(), matrix);
        registration.addIngredientInfo(WirelessRegistry.MAT_CORE_0.get(), matrix);
        registration.addIngredientInfo(WirelessRegistry.MAT_CORE_1.get(), matrix);
        registration.addIngredientInfo(WirelessRegistry.MAT_CORE_2.get(), matrix);
        Component node = Component.translatable("jei.railgunreborn.info.node");
        registration.addIngredientInfo(WirelessRegistry.NODE_BASIC_ITEM.get(), node);
        registration.addIngredientInfo(WirelessRegistry.NODE_STANDARD_ITEM.get(), node);
        registration.addIngredientInfo(WirelessRegistry.NODE_ADVANCED_ITEM.get(), node);
        registration.addIngredientInfo(ModItems.ENERGY_UNIT.get(),
                Component.translatable("jei.railgunreborn.info.energy_unit"));
        registration.addIngredientInfo(ModItems.ENERGY_UNIT_HIGH.get(),
                Component.translatable("jei.railgunreborn.info.energy_unit_high"));
        registration.addIngredientInfo(ModItems.ENERGY_UNIT_MEGA.get(),
                Component.translatable("jei.railgunreborn.info.energy_unit_mega"));
        Component developer = Component.translatable("jei.railgunreborn.info.developer");
        registration.addIngredientInfo(ModItems.DEVELOPER_NORMAL.get(), developer);
        registration.addIngredientInfo(ModItems.DEVELOPER_ADVANCED.get(), developer);
        registration.addIngredientInfo(ModItems.DEVELOPER_PORTABLE.get(), developer);
        registration.addIngredientInfo(MetalFormerRegistry.METAL_FORMER_ITEM.get(),
                Component.translatable("jei.railgunreborn.info.metal_former"));
        Component ore = Component.translatable("jei.railgunreborn.info.ore");
        registration.addIngredientInfo(ModItems.CONSTRAINT_METAL.get(), ore);
        registration.addIngredientInfo(ModItems.CRYSTAL_ORE.get(), ore);
        registration.addIngredientInfo(ModItems.IMAGSIL_ORE.get(), ore);
        registration.addIngredientInfo(ModItems.RESO_ORE.get(), ore);
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalyst(ModItems.IMAG_FUSOR.get(), ImagFusorCategory.TYPE);
        registration.addRecipeCatalyst(MetalFormerRegistry.METAL_FORMER_ITEM.get(), MetalFormerCategory.TYPE);
    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addRecipeClickArea(ImagFusorScreen.class, FUSOR_CLICK_X, FUSOR_CLICK_Y, FUSOR_CLICK_W,
                FUSOR_CLICK_H, ImagFusorCategory.TYPE);
        registration.addRecipeClickArea(MetalFormerScreen.class, FORMER_CLICK_X, FORMER_CLICK_Y, FORMER_CLICK_W,
                FORMER_CLICK_H, MetalFormerCategory.TYPE);
    }
}
