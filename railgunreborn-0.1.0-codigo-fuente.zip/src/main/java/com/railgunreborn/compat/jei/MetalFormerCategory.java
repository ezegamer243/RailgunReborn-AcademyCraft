package com.railgunreborn.compat.jei;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.metalformer.MetalFormerMode;
import com.railgunreborn.metalformer.MetalFormerRegistry;

import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Metal Former: modo (icono de la máquina + nombre), entrada con cantidad y resultado. */
public class MetalFormerCategory implements IRecipeCategory<MetalFormerDisplay> {
    public static final RecipeType<MetalFormerDisplay> TYPE = RecipeType.create(RailgunReborn.MODID, "metal_former",
            MetalFormerDisplay.class);

    private static final int WIDTH = 116;
    private static final int HEIGHT = 60;
    private static final int TEXT_COLOR = 0xFF808080;
    private static final int ROW_Y = 20;

    private final IDrawable icon;
    private final ArrowCache arrows;

    public MetalFormerCategory(IGuiHelper gui) {
        this.icon = gui.createDrawableItemLike(MetalFormerRegistry.METAL_FORMER.get());
        this.arrows = new ArrowCache(gui);
    }

    @Override
    public RecipeType<MetalFormerDisplay> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.translatable("block.railgunreborn.metal_former");
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, MetalFormerDisplay recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 1, ROW_Y + 1).setStandardSlotBackground()
                .addItemStacks(recipe.inputs());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 63, ROW_Y + 1).setOutputSlotBackground()
                .addItemStack(recipe.output());
    }

    @Override
    public void draw(MetalFormerDisplay recipe, IRecipeSlotsView slots, GuiGraphics graphics, double mouseX,
            double mouseY) {
        // El mismo icono de modo que la pantalla de la máquina (textura 48x48 dibujada a 16x16).
        graphics.blit(modeIcon(recipe.mode()), 0, 0, 16, 16, 0, 0, 48, 48, 48, 48);
        Font font = Minecraft.getInstance().font;
        graphics.drawString(font, Component.translatable("jei.railgunreborn.metal_former.mode",
                Component.translatable(recipe.mode().translationKey())), 20, 4, TEXT_COLOR, false);
        arrows.get(recipe.time()).draw(graphics, 28, ROW_Y + 1);
        if (recipe.fromSmelting()) {
            graphics.drawString(font, Component.translatable("jei.railgunreborn.metal_former.smelting"), 0,
                    HEIGHT - 9, TEXT_COLOR, false);
        }
        graphics.drawString(font, ArrowCache.energy(recipe.energy()), 0, HEIGHT - 19, TEXT_COLOR, false);
        Component time = ArrowCache.seconds(recipe.time());
        graphics.drawString(font, time, WIDTH - font.width(time), HEIGHT - 9, TEXT_COLOR, false);
    }

    private static ResourceLocation modeIcon(MetalFormerMode mode) {
        return ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
                "textures/gui/metal_former/icon_former_" + mode.getSerializedName() + ".png");
    }
}
