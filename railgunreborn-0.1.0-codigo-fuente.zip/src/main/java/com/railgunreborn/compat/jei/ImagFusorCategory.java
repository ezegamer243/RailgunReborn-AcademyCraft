package com.railgunreborn.compat.jei;

import com.railgunreborn.crafting.ImagFusorRecipe;
import com.railgunreborn.registry.ModBlocks;
import com.railgunreborn.registry.ModFluids;
import com.railgunreborn.registry.ModRecipes;

import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.crafting.RecipeHolder;

/** Imag Fusor: ítem + líquido de fase -> resultado. */
public class ImagFusorCategory implements IRecipeCategory<RecipeHolder<ImagFusorRecipe>> {
    public static final RecipeType<RecipeHolder<ImagFusorRecipe>> TYPE = RecipeType
            .createRecipeHolderType(ModRecipes.IMAG_FUSOR.getId());

    private static final int WIDTH = 116;
    private static final int HEIGHT = 54;
    private static final int TEXT_COLOR = 0xFF808080;

    private final IDrawable icon;
    private final ArrowCache arrows;

    public ImagFusorCategory(IGuiHelper gui) {
        this.icon = gui.createDrawableItemLike(ModBlocks.IMAG_FUSOR.get());
        this.arrows = new ArrowCache(gui);
    }

    @Override
    public RecipeType<RecipeHolder<ImagFusorRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.translatable("block.railgunreborn.imag_fusor");
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, RecipeHolder<ImagFusorRecipe> holder, IFocusGroup focuses) {
        ImagFusorRecipe recipe = holder.value();
        builder.addSlot(RecipeIngredientRole.INPUT, 1, 1).setStandardSlotBackground()
                .addIngredients(recipe.ingredient());
        // El depósito entero es la cantidad de la receta: la barra sale llena y el tooltip dice los mB.
        builder.addSlot(RecipeIngredientRole.INPUT, 1, 27).setStandardSlotBackground()
                .setFluidRenderer(recipe.liquid(), false, 16, 16)
                .addFluidStack(ModFluids.PHASE_LIQUID.get(), recipe.liquid());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 63, 14).setOutputSlotBackground()
                .addItemStack(recipe.result());
    }

    @Override
    public void draw(RecipeHolder<ImagFusorRecipe> holder, IRecipeSlotsView slots, GuiGraphics graphics,
            double mouseX, double mouseY) {
        ImagFusorRecipe recipe = holder.value();
        arrows.get(recipe.time()).draw(graphics, 28, 15);
        Font font = Minecraft.getInstance().font;
        graphics.drawString(font, Component.translatable("jei.railgunreborn.liquid", recipe.liquid()), 21, 33,
                TEXT_COLOR, false);
        Component time = ArrowCache.seconds(recipe.time());
        graphics.drawString(font, time, WIDTH - font.width(time), 44, TEXT_COLOR, false);
        graphics.drawString(font, ArrowCache.energy((long) recipe.energyPerTick() * recipe.time()), 0, 44,
                TEXT_COLOR, false);
    }
}
