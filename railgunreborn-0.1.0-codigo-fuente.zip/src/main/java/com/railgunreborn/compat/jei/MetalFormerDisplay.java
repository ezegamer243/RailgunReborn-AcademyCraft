package com.railgunreborn.compat.jei;

import java.util.List;

import com.railgunreborn.metalformer.MetalFormerMode;

import net.minecraft.world.item.ItemStack;

/**
 * Lo que JEI muestra de una operación del Metal Former: una receta JSON o una de "refinar con el horno"
 * ({@code fromSmelting}) generada para menas de otros mods.
 */
public record MetalFormerDisplay(MetalFormerMode mode, List<ItemStack> inputs, ItemStack output, int time,
        int energy, boolean fromSmelting) {
}
