package com.railgunreborn.reactor;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;

/**
 * Sonido de activación del reactor (decisión del usuario: "imponente", pero el usuario prefiere volúmenes
 * moderados). No hay audio propio, así que se compone con tres capas a la vez, cada una su evento en
 * {@code sounds.json} con archivos vanilla a otro tono:
 * <ul>
 * <li>{@code category_reactor_activate}: subida de faro a medio tono (cuerpo grave, con subtítulo);</li>
 * <li>{@code category_reactor_activate_boom}: estampido sónico del Warden, más grave;</li>
 * <li>{@code category_reactor_activate_rumble}: trueno lejano, grave (cola que retumba).</li>
 * </ul>
 * Se oye a 16 bloques (volumen &lt; 1).
 */
public final class CategoryReactorSounds {
    public static final float ACTIVATE_VOLUME = 0.75f;
    public static final float BOOM_VOLUME = 0.55f;
    public static final float RUMBLE_VOLUME = 0.6f;
    /** Zumbido en bucle mientras hay factor y líquido: discreto. */
    public static final float HUM_VOLUME = 0.2f;

    private CategoryReactorSounds() {
    }

    /** Solo servidor: lo oyen todos los cercanos, también quien lo activa. */
    public static void playActivation(Level level, BlockPos pos) {
        level.playSound(null, pos, CategoryReactorRegistry.SOUND_ACTIVATE.get(), SoundSource.BLOCKS, ACTIVATE_VOLUME,
                1.0f);
        level.playSound(null, pos, CategoryReactorRegistry.SOUND_ACTIVATE_BOOM.get(), SoundSource.BLOCKS,
                BOOM_VOLUME, 1.0f);
        level.playSound(null, pos, CategoryReactorRegistry.SOUND_ACTIVATE_RUMBLE.get(), SoundSource.BLOCKS,
                RUMBLE_VOLUME, 1.0f);
    }
}
