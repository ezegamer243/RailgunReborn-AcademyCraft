package com.railgunreborn.reactor;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;
import com.railgunreborn.block.ImagFusorBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.fluids.FluidUtil;

/**
 * Controlador del reactor de categoría: el bloque del centro (el contenedor de cristal), con el BlockEntity.
 * Las piezas de alrededor le reenvían los clics con {@link #interactWithItem} y {@link #openMenu}.
 */
public class CategoryReactorBlock extends BaseEntityBlock {
    public static final MapCodec<CategoryReactorBlock> CODEC = simpleCodec(CategoryReactorBlock::new);

    public CategoryReactorBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CategoryReactorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
            BlockEntityType<T> type) {
        return createTickerHelper(type, CategoryReactorRegistry.BLOCK_ENTITY.get(),
                level.isClientSide ? CategoryReactorBlockEntity::clientTick : CategoryReactorBlockEntity::serverTick);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
            Player player, InteractionHand hand, BlockHitResult hit) {
        return interactWithItem(stack, level, pos, player, hand, hit.getDirection());
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        return openMenu(level, pos, player);
    }

    /**
     * Clic con un recipiente de líquido de fase: lo vacía en el depósito y devuelve el recipiente vacío. Clic con un
     * Induction Factor y la ranura vacía: lo mete. Cualquier otra cosa abre el menú.
     */
    static ItemInteractionResult interactWithItem(ItemStack stack, Level level, BlockPos controllerPos,
            Player player, InteractionHand hand, Direction side) {
        if (ImagFusorBlockEntity.isPhaseContainer(stack)) {
            if (FluidUtil.interactWithFluidHandler(player, hand, level, controllerPos, side)) {
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (CategoryReactorBlockEntity.isFactor(stack)
                && level.getBlockEntity(controllerPos) instanceof CategoryReactorBlockEntity be
                && be.getFactor().isEmpty()) {
            if (!level.isClientSide) {
                be.getItems().setStackInSlot(0, stack.copyWithCount(1));
                stack.consume(1, player);
                level.playSound(null, controllerPos, SoundEvents.END_PORTAL_FRAME_FILL, SoundSource.BLOCKS, 1.0f, 1.0f);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    static InteractionResult openMenu(Level level, BlockPos controllerPos, Player player) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(controllerPos) instanceof CategoryReactorBlockEntity be) {
            serverPlayer.openMenu(be, controllerPos);
        }
        return InteractionResult.CONSUME;
    }

    /** Suelta el factor (el líquido se pierde) y quita las 26 piezas que apuntan a este controlador. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof CategoryReactorBlockEntity be) {
                be.dropContents(level, pos);
            }
            for (BlockPos partPos : CategoryReactorStructure.volume(pos)) {
                BlockState partState = level.getBlockState(partPos);
                if (partState.is(CategoryReactorRegistry.PART.get())
                        && CategoryReactorPartBlock.controllerPos(partPos, partState).equals(pos)) {
                    level.setBlock(partPos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                }
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
        return new ItemStack(CategoryReactorRegistry.ITEM.get());
    }
}
