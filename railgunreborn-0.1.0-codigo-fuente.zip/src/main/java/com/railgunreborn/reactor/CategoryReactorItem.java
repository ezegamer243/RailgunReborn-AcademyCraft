package com.railgunreborn.reactor;

import java.util.List;
import java.util.Optional;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * Ítem del reactor de categoría: al usarlo sobre un bloque construye el reactor 3x3x3 con la capa de abajo centrada
 * donde iría un bloque normal (encima de la cara apuntada). Si el volumen no está libre o no hay permiso, no coloca
 * nada y avisa.
 */
public class CategoryReactorItem extends Item {
    public CategoryReactorItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        ItemStack stack = context.getItemInHand();
        BlockPos base = new BlockPlaceContext(context).getClickedPos();
        Optional<Component> problem = CategoryReactorStructure.checkPlacement(level, base, player, stack);
        if (problem.isPresent()) {
            if (!level.isClientSide && player != null) {
                player.displayClientMessage(problem.get(), true);
            }
            return InteractionResult.FAIL;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (!CategoryReactorStructure.build(level, base, player)) {
            player.displayClientMessage(
                    Component.translatable("message.railgunreborn.category_reactor.no_permission"), true);
            return InteractionResult.FAIL;
        }
        level.playSound(null, CategoryReactorStructure.controllerFromBase(base), SoundEvents.NETHERITE_BLOCK_PLACE,
                SoundSource.BLOCKS, 1.0f, 0.8f);
        stack.consume(1, player);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.railgunreborn.category_reactor.tooltip")
                .withStyle(ChatFormatting.GRAY));
    }
}
