package com.railgunreborn.reactor;

import javax.annotation.Nullable;

import com.railgunreborn.energy.ContainerDataInts;

import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Menú del reactor: ranura del factor, depósito y botón "Activar". El botón usa {@link #clickMenuButton} (vanilla):
 * el servidor revalida y decide, sin paquete propio. El estado (por qué se puede o no activar) lo calcula el
 * servidor para el jugador que tiene el menú abierto y viaja por {@link ContainerData}.
 */
public class CategoryReactorMenu extends AbstractContainerMenu {
    public static final int BUTTON_ACTIVATE = 0;

    public static final int DATA_TANK = 0;
    public static final int DATA_STATUS = 1;
    /** Energía (2 ranuras: pasa de 32 767). */
    public static final int DATA_ENERGY = 2;
    public static final int DATA_COUNT = DATA_ENERGY + ContainerDataInts.SLOTS;

    public static final int FACTOR_X = 80;
    public static final int FACTOR_Y = 46;
    public static final int INV_Y = 100;

    private static final int MACHINE_SLOTS = 1;
    private static final int INV_START = MACHINE_SLOTS;
    private static final int INV_END = INV_START + 36;

    @Nullable
    private final CategoryReactorBlockEntity blockEntity;
    private final ContainerLevelAccess access;
    private final ContainerData data;

    /** Cliente: el servidor manda la posición del controlador. */
    public CategoryReactorMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf buf) {
        this(containerId, inventory, null, clientItems(), new SimpleContainerData(DATA_COUNT),
                ContainerLevelAccess.create(inventory.player.level(), buf.readBlockPos()));
    }

    /** Servidor. */
    public CategoryReactorMenu(int containerId, Inventory inventory, CategoryReactorBlockEntity be, Player player) {
        this(containerId, inventory, be, be.getItems(), serverData(be, player),
                ContainerLevelAccess.create(be.getLevel(), be.getBlockPos()));
    }

    private CategoryReactorMenu(int containerId, Inventory inventory, @Nullable CategoryReactorBlockEntity be,
            IItemHandler items, ContainerData data, ContainerLevelAccess access) {
        super(CategoryReactorRegistry.MENU.get(), containerId);
        this.blockEntity = be;
        this.access = access;
        this.data = data;
        addSlot(new SlotItemHandler(items, 0, FACTOR_X, FACTOR_Y));
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, 8 + col * 18, INV_Y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, INV_Y + 58));
        }
        addDataSlots(data);
    }

    private static ItemStackHandler clientItems() {
        return new ItemStackHandler(1) {
            @Override
            public boolean isItemValid(int slot, ItemStack stack) {
                return CategoryReactorBlockEntity.isFactor(stack);
            }

            @Override
            public int getSlotLimit(int slot) {
                return 1;
            }
        };
    }

    /** El depósito cabe en un short (30 000 < 32 767), que es como viaja ContainerData. */
    private static ContainerData serverData(CategoryReactorBlockEntity be, Player player) {
        return new ContainerData() {
            @Override
            public int get(int index) {
                return switch (index) {
                    case DATA_TANK -> be.getTank().getFluidAmount();
                    case DATA_STATUS -> be.statusFor(player).ordinal();
                    case DATA_ENERGY, DATA_ENERGY + 1 ->
                        ContainerDataInts.part(be.getEnergy().getEnergyStored(), index - DATA_ENERGY);
                    default -> 0;
                };
            }

            @Override
            public void set(int index, int value) {
            }

            @Override
            public int getCount() {
                return DATA_COUNT;
            }
        };
    }

    public int getTankAmount() {
        return data.get(DATA_TANK);
    }

    public int getEnergyAmount() {
        return ContainerDataInts.get(data, DATA_ENERGY);
    }

    public CategoryReactorBlockEntity.Status getStatus() {
        return CategoryReactorBlockEntity.Status.byId(data.get(DATA_STATUS));
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (blockEntity == null || id != BUTTON_ACTIVATE) {
            return false;
        }
        CategoryReactorBlockEntity.Status result = blockEntity.tryActivate(player);
        if (result != CategoryReactorBlockEntity.Status.READY) {
            player.displayClientMessage(Component.translatable(result.translationKey()), true);
        }
        return true;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, CategoryReactorRegistry.CONTROLLER.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < MACHINE_SLOTS) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) {
                return ItemStack.EMPTY;
            }
        } else if (CategoryReactorBlockEntity.isFactor(stack)) {
            if (!moveItemStackTo(stack, 0, MACHINE_SLOTS, false)) {
                return ItemStack.EMPTY;
            }
        } else if (index < INV_END - 9) {
            if (!moveItemStackTo(stack, INV_END - 9, INV_END, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, INV_START, INV_END - 9, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        if (stack.getCount() == original.getCount()) {
            return ItemStack.EMPTY;
        }
        slot.onTake(player, stack);
        return original;
    }
}
