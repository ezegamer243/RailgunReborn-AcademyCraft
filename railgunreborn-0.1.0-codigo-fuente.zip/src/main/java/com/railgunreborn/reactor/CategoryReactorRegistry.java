package com.railgunreborn.reactor;

import com.railgunreborn.RailgunReborn;

import java.util.function.Supplier;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registros del reactor de categoría (T90), juntos y aparte de ModBlocks/ModItems como el Metal Former.
 * El ítem {@code category_reactor} no es un BlockItem: coloca la estructura 3x3x3 entera (controlador + 26 partes).
 */
public final class CategoryReactorRegistry {
    private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(RailgunReborn.MODID);
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(RailgunReborn.MODID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister
            .create(Registries.BLOCK_ENTITY_TYPE, RailgunReborn.MODID);
    private static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU,
            RailgunReborn.MODID);
    private static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT,
            RailgunReborn.MODID);

    /** Centro de la estructura (el contenedor de cristal) con el BlockEntity. */
    public static final DeferredBlock<CategoryReactorBlock> CONTROLLER = BLOCKS.register("category_reactor",
            () -> new CategoryReactorBlock(properties()));
    /** Las otras 26 posiciones; no sueltan nada (el ítem lo suelta el controlador). */
    public static final DeferredBlock<CategoryReactorPartBlock> PART = BLOCKS.register("category_reactor_part",
            () -> new CategoryReactorPartBlock(properties().noLootTable()));

    public static final DeferredItem<CategoryReactorItem> ITEM = ITEMS.register("category_reactor",
            () -> new CategoryReactorItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CategoryReactorBlockEntity>> BLOCK_ENTITY =
            BLOCK_ENTITIES.register("category_reactor", () -> BlockEntityType.Builder
                    .of(CategoryReactorBlockEntity::new, CONTROLLER.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<CategoryReactorMenu>> MENU = MENUS.register(
            "category_reactor", () -> IMenuTypeExtension.create(CategoryReactorMenu::new));

    /** Capas del sonido de activación (ver {@link CategoryReactorSounds}). */
    public static final Supplier<SoundEvent> SOUND_ACTIVATE = sound("machine.category_reactor_activate");
    public static final Supplier<SoundEvent> SOUND_ACTIVATE_BOOM = sound("machine.category_reactor_activate_boom");
    public static final Supplier<SoundEvent> SOUND_ACTIVATE_RUMBLE = sound("machine.category_reactor_activate_rumble");
    /** Zumbido en bucle mientras tiene factor y líquido. */
    public static final Supplier<SoundEvent> SOUND_HUM = sound("machine.category_reactor_hum");

    private CategoryReactorRegistry() {
    }

    /**
     * Sin {@code requiresCorrectToolForDrops}: es caro y romperlo a mano no debe perderlo. Resistencia a explosiones
     * de obsidiana (es un "reactor"). Sin oclusión para ver el núcleo a través del cristal.
     */
    private static BlockBehaviour.Properties properties() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(5.0f, 1200.0f).sound(SoundType.METAL)
                .noOcclusion().pushReaction(PushReaction.BLOCK).isRedstoneConductor((s, l, p) -> false)
                .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false);
    }

    private static Supplier<SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, name)));
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        SOUNDS.register(modEventBus);
        modEventBus.addListener(CategoryReactorRegistry::registerCapabilities);
    }

    /** Tuberías de fluido (solo llenar) e ítems (ranura del factor) por cualquier cara de cualquier bloque. */
    private static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, BLOCK_ENTITY.get(),
                (be, side) -> be.getFluidHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BLOCK_ENTITY.get(),
                (be, side) -> be.getItems());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, BLOCK_ENTITY.get(),
                (be, side) -> be.getEnergyHandler());
        event.registerBlock(Capabilities.EnergyStorage.BLOCK, (level, pos, state, be, side) -> {
            CategoryReactorBlockEntity controller = CategoryReactorPartBlock.controller(level, pos, state);
            return controller == null ? null : controller.getEnergyHandler();
        }, PART.get());
        event.registerBlock(Capabilities.FluidHandler.BLOCK, (level, pos, state, be, side) -> {
            CategoryReactorBlockEntity controller = CategoryReactorPartBlock.controller(level, pos, state);
            return controller == null ? null : controller.getFluidHandler();
        }, PART.get());
        event.registerBlock(Capabilities.ItemHandler.BLOCK, (level, pos, state, be, side) -> {
            CategoryReactorBlockEntity controller = CategoryReactorPartBlock.controller(level, pos, state);
            return controller == null ? null : controller.getItems();
        }, PART.get());
    }
}
