package com.railgunreborn.reactor;

import javax.annotation.Nullable;

import com.railgunreborn.RailgunReborn;

import net.minecraft.resources.ResourceLocation;

/**
 * Reglas puras del aspecto del reactor (sin clases de cliente, para poder testearlas): color del líquido según la
 * categoría del factor (decisión del usuario, survival.md "Decisiones para el port" 2), altura de la columna y
 * alcance de los efectos.
 */
public final class CategoryReactorVisuals {
    /** Sin efectos (partículas, rayos, torbellinos) más allá de esta distancia al jugador. */
    public static final double EFFECT_RANGE = 32.0;
    /** El temblor de cámara al activarlo solo llega hasta aquí, y se atenúa con la distancia. */
    public static final double SHAKE_RANGE = 16.0;

    private CategoryReactorVisuals() {
    }

    /** Aspecto del líquido; {@link #PHASE} = líquido de fase normal (sin factor o categoría de otro mod). */
    public enum Look {
        PHASE(0xFFFFFF),
        /** Negro (con un punto violeta para que no sea un agujero plano) y partículas de enderman. */
        TELEPORTER(0x1C0E2A),
        /** Verde de Meltdowner. */
        MELTDOWNER(0x3CFF64),
        /** Blanco, con torbellinos y esferas de plasma. */
        VECMANIP(0xF4F7FF),
        /** Celeste, con rayos. */
        ELECTROMASTER(0x6FD6FF);

        private final int color;

        Look(int color) {
            this.color = color;
        }

        /** Tinte RGB (0xRRGGBB) que multiplica la textura gris del líquido; PHASE usa la textura original. */
        public int color() {
            return color;
        }
    }

    public static Look lookOf(@Nullable ResourceLocation category) {
        if (category == null || !RailgunReborn.MODID.equals(category.getNamespace())) {
            return Look.PHASE;
        }
        return switch (category.getPath()) {
            case "teleporter" -> Look.TELEPORTER;
            case "meltdowner" -> Look.MELTDOWNER;
            case "vecmanip" -> Look.VECMANIP;
            case "electromaster" -> Look.ELECTROMASTER;
            default -> Look.PHASE;
        };
    }

    /**
     * Fracción de la columna llena (0..1). Al activarse el depósito se vacía de golpe: mientras "dispara" la columna
     * baja poco a poco ({@code firingTicks / FIRING_DURATION}) en vez de desaparecer.
     */
    public static float displayedFill(int amount, int capacity, int firingTicks, int firingDuration) {
        float fill = capacity <= 0 ? 0f : Math.max(0f, Math.min(1f, amount / (float) capacity));
        if (firingTicks > 0 && firingDuration > 0) {
            fill = Math.max(fill, Math.min(1f, firingTicks / (float) firingDuration));
        }
        return fill;
    }

    /** Mezcla {@code rgb} hacia el blanco ({@code t} 0..1): el pulso de brillo al disparar. */
    public static int towardWhite(int rgb, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        r = Math.round(r + (255 - r) * t);
        g = Math.round(g + (255 - g) * t);
        b = Math.round(b + (255 - b) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static boolean inEffectRange(double distanceSqr) {
        return distanceSqr <= EFFECT_RANGE * EFFECT_RANGE;
    }

    /** Fuerza del temblor (0..1): máxima al empezar a disparar y cerca; 0 fuera de {@link #SHAKE_RANGE}. */
    public static float shakeStrength(double distance, int firingTicks, int firingDuration) {
        if (firingTicks <= 0 || firingDuration <= 0 || distance >= SHAKE_RANGE) {
            return 0f;
        }
        float near = (float) (1.0 - distance / SHAKE_RANGE);
        float time = Math.min(1f, firingTicks / (float) firingDuration);
        return near * time;
    }
}
