package com.railgunreborn.reactor;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Una de las 26 piezas del reactor que rodean al controlador. Su posición relativa va en el blockstate
 * ({@code ox/oy/oz} = desplazamiento desde el controlador + 1), así no necesita BlockEntity. Todo (clics,
 * capacidades) se reenvía al controlador; romper cualquier pieza rompe el reactor entero.
 */
public class CategoryReactorPartBlock extends Block {
    public static final IntegerProperty OX = IntegerProperty.create("ox", 0, 2);
    public static final IntegerProperty OY = IntegerProperty.create("oy", 0, 2);
    public static final IntegerProperty OZ = IntegerProperty.create("oz", 0, 2);
    /** Solo visual: las ventanas de cristal de la capa del medio (el blockstate elige el modelo por posición). */
    public static final BooleanProperty GLASS = BooleanProperty.create("glass");

    public CategoryReactorPartBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(OX, 0).setValue(OY, 0).setValue(OZ, 0)
                .setValue(GLASS, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(OX, OY, OZ, GLASS);
    }

    /** Estado de la pieza que está en {@code controller + (dx, dy, dz)}. */
    public static BlockState stateFor(int dx, int dy, int dz) {
        return CategoryReactorRegistry.PART.get().defaultBlockState().setValue(OX, dx + 1).setValue(OY, dy + 1)
                .setValue(OZ, dz + 1).setValue(GLASS, CategoryReactorStructure.isGlass(dx, dy, dz));
    }

    public static BlockPos controllerPos(BlockPos pos, BlockState state) {
        return pos.offset(1 - state.getValue(OX), 1 - state.getValue(OY), 1 - state.getValue(OZ));
    }

    /** El controlador de esta pieza, o null si ya no está (estructura a medio romper). */
    @Nullable
    public static CategoryReactorBlockEntity controller(BlockGetter level, BlockPos pos, BlockState state) {
        if (!state.is(CategoryReactorRegistry.PART.get())) {
            return null;
        }
        return level.getBlockEntity(controllerPos(pos, state)) instanceof CategoryReactorBlockEntity be ? be : null;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
            Player player, InteractionHand hand, BlockHitResult hit) {
        if (controller(level, pos, state) == null) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        return CategoryReactorBlock.interactWithItem(stack, level, controllerPos(pos, state), player, hand,
                hit.getDirection());
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hit) {
        if (controller(level, pos, state) == null) {
            return InteractionResult.PASS;
        }
        return CategoryReactorBlock.openMenu(level, controllerPos(pos, state), player);
    }

    /** En creativo no se suelta el ítem (como cualquier bloque); el factor sí, como el contenido de un cofre. */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        CategoryReactorBlockEntity be = controller(level, pos, state);
        if (be != null && player.isCreative()) {
            be.suppressItemDrop();
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    /**
     * Al quitar una pieza (a mano, explosión, comando...) se rompe el controlador, que suelta el ítem y el factor y
     * quita las demás piezas. Cuando es el controlador el que las quita, aquí ya no lo encuentra y no hace nada.
     */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            CategoryReactorBlockEntity be = controller(level, pos, state);
            if (be != null) {
                level.destroyBlock(be.getBlockPos(), !be.isItemDropSuppressed());
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
        return new ItemStack(CategoryReactorRegistry.ITEM.get());
    }
}
