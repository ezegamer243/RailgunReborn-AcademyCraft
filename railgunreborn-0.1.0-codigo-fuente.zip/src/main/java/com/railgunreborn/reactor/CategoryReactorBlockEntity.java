package com.railgunreborn.reactor;

import java.util.Optional;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.railgunreborn.ability.AbilityRegistries;
import com.railgunreborn.ability.data.AbilityData;
import com.railgunreborn.ability.data.CPData;
import com.railgunreborn.block.ImagFusorBlockEntity;
import com.railgunreborn.config.RailgunConfig;
import com.railgunreborn.energy.ModEnergyStorage;
import com.railgunreborn.item.InductionFactorItem;
import com.railgunreborn.registry.ModItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * Reactor de categoría (decisión del usuario, survival.md "Decisiones para el port" 2-3; sustituye al método
 * {@code magnetic_coil} del original). Depósito de 30 000 mB de líquido de fase y una ranura para un Induction
 * Factor. Al activarlo con el depósito lleno: gasta el líquido y el factor, y el jugador que lo activa pasa a la
 * categoría del factor con nivel 1 (mismo camino que el comando {@code /railgunreborn category}).
 *
 * <p>Estado sincronizado al cliente para T91 (modelo, color del líquido, efectos): cantidad de líquido, el factor
 * (su categoría), los ticks de "disparo" tras activarlo ({@link #isFiring()}) y la categoría inducida mientras dura.
 */
public class CategoryReactorBlockEntity extends BlockEntity implements MenuProvider {
    public static final int TANK_CAPACITY = 30_000;
    /** Buffer de energía (decisión del usuario, energy.md): 50 Energy Units; se gasta entero al activar. */
    public static final int ENERGY_CAPACITY = 500_000;
    /** Duración del estado "disparando" tras activarlo (efectos de T91). */
    public static final int FIRING_DURATION = 60;

    /** Por qué se puede o no activar; el orden (ordinal) viaja al cliente por ContainerData. */
    public enum Status {
        READY, FIRING, NEED_FACTOR, INVALID_FACTOR, NEED_LIQUID, SAME_CATEGORY, NEED_ENERGY;

        public String translationKey() {
            return "gui.railgunreborn.category_reactor.status." + name().toLowerCase(java.util.Locale.ROOT);
        }

        public static Status byId(int id) {
            Status[] values = values();
            return id >= 0 && id < values.length ? values[id] : NEED_FACTOR;
        }
    }

    /** Lo pone el cliente en T91 (sonido/partículas según categoría); en el servidor no hace nada. */
    public static Consumer<CategoryReactorBlockEntity> clientTickHook = be -> {
    };

    private final ItemStackHandler items = new ItemStackHandler(1) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isFactor(stack);
        }

        @Override
        public int getSlotLimit(int slot) {
            return 1;
        }

        @Override
        protected void onContentsChanged(int slot) {
            changed();
        }
    };

    private final FluidTank tank = new FluidTank(TANK_CAPACITY, ImagFusorBlockEntity::isPhaseLiquid) {
        @Override
        protected void onContentsChanged() {
            changed();
        }
    };

    private final IFluidHandler fillOnlyTank = new FillOnlyFluidHandler(tank);

    private final ModEnergyStorage energy = ModEnergyStorage.receiver(ENERGY_CAPACITY, ENERGY_CAPACITY, this::changed);
    private final IEnergyStorage chargeHandler = new ChargeHandler();
    /** Tope de carga por tick (no por llamada): energía aceptada en el tick {@link #chargeTick}. */
    private long chargeTick = Long.MIN_VALUE;
    private int chargedThisTick;

    private int firingTicks;
    /** Categoría que se acaba de inducir: el factor ya se gastó, pero los efectos del disparo la necesitan. */
    @Nullable
    private ResourceLocation firingCategory;
    /** Solo en memoria: lo marca la pieza al romperla un jugador en creativo. */
    private boolean itemDropSuppressed;

    public CategoryReactorBlockEntity(BlockPos pos, BlockState state) {
        super(CategoryReactorRegistry.BLOCK_ENTITY.get(), pos, state);
    }

    /** Un Induction Factor con categoría (los de creativo sin componente no sirven). */
    public static boolean isFactor(ItemStack stack) {
        return stack.is(ModItems.INDUCTION_FACTOR.get()) && InductionFactorItem.categoryOf(stack).isPresent();
    }

    // --- Tick ---

    public static void serverTick(Level level, BlockPos pos, BlockState state, CategoryReactorBlockEntity be) {
        if (be.firingTicks > 0 && --be.firingTicks == 0) {
            be.firingCategory = null;
            be.changed();
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, CategoryReactorBlockEntity be) {
        if (be.firingTicks > 0 && --be.firingTicks == 0) {
            be.firingCategory = null;
        }
        clientTickHook.accept(be);
    }

    // --- Activación ---

    /** Estado para ese jugador (null = sin jugador: no se comprueba la categoría). */
    public Status statusFor(@Nullable Player player) {
        if (firingTicks > 0) {
            return Status.FIRING;
        }
        Optional<ResourceLocation> category = getFactorCategory();
        if (category.isEmpty()) {
            return Status.NEED_FACTOR;
        }
        if (AbilityRegistries.category(category.get()).isEmpty()) {
            return Status.INVALID_FACTOR;
        }
        if (tank.getFluidAmount() < TANK_CAPACITY) {
            return Status.NEED_LIQUID;
        }
        // Decisión del port: con la misma categoría se rechaza (gastaría el factor solo para bajar a nivel 1).
        if (player != null && category.equals(AbilityData.get(player).getCategory())) {
            return Status.SAME_CATEGORY;
        }
        if (RailgunConfig.energyRequired() && !energy.isFull()) {
            return Status.NEED_ENERGY;
        }
        return Status.READY;
    }

    /**
     * Activa el reactor para {@code player} (solo servidor). Revalida todo; si está listo gasta los 30 000 mB y el
     * factor, cambia la categoría del jugador y pone el nivel 1.
     *
     * @return el estado que impidió activarlo, o {@link Status#READY} si se activó
     */
    public Status tryActivate(Player player) {
        Status status = statusFor(player);
        if (status != Status.READY || level == null || level.isClientSide) {
            return status;
        }
        ResourceLocation category = getFactorCategory().orElseThrow();
        tank.drain(TANK_CAPACITY, IFluidHandler.FluidAction.EXECUTE);
        if (RailgunConfig.energyRequired()) {
            energy.setEnergy(0);
        }
        items.setStackInSlot(0, ItemStack.EMPTY);

        // Igual que /railgunreborn category + level: setCategory borra habilidades, exps, presets y contextos.
        AbilityData data = AbilityData.get(player);
        data.setCategory(category);
        data.setLevel(1);
        CPData.get(player); // aplica al momento el recálculo pendiente de CP

        firingTicks = FIRING_DURATION;
        firingCategory = category;
        changed();
        CategoryReactorSounds.playActivation(level, worldPosition);
        player.displayClientMessage(Component.translatable("message.railgunreborn.category_reactor.activated",
                categoryName(category)), false);
        return Status.READY;
    }

    public static Component categoryName(ResourceLocation category) {
        return Component.translatable(category.getNamespace() + ".ability." + category.getPath() + ".name");
    }

    // --- Acceso ---

    public ItemStackHandler getItems() {
        return items;
    }

    public FluidTank getTank() {
        return tank;
    }

    /** Capacidad de fluido de todas las caras de todas las piezas: solo llenar, solo líquido de fase. */
    public IFluidHandler getFluidHandler() {
        return fillOnlyTank;
    }

    public ModEnergyStorage getEnergy() {
        return energy;
    }

    /** Capacidad FE de todas las caras de todas las piezas: solo recibe, con tope por tick. */
    public IEnergyStorage getEnergyHandler() {
        return chargeHandler;
    }

    public ItemStack getFactor() {
        return items.getStackInSlot(0);
    }

    /** Categoría del factor colocado (T91: color del líquido y efectos). */
    public Optional<ResourceLocation> getFactorCategory() {
        return InductionFactorItem.categoryOf(getFactor());
    }

    /**
     * Categoría que se ve en el reactor: la del factor o, mientras dispara (el factor ya se gastó), la que se acaba
     * de inducir.
     */
    public Optional<ResourceLocation> getDisplayCategory() {
        if (firingTicks > 0 && firingCategory != null) {
            return Optional.of(firingCategory);
        }
        return getFactorCategory();
    }

    public int getFiringTicks() {
        return firingTicks;
    }

    /** True durante {@link #FIRING_DURATION} ticks tras activarse (T91: efectos de disparo). */
    public boolean isFiring() {
        return firingTicks > 0;
    }

    void suppressItemDrop() {
        itemDropSuppressed = true;
    }

    boolean isItemDropSuppressed() {
        return itemDropSuppressed;
    }

    public void dropContents(Level level, BlockPos pos) {
        Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), items.getStackInSlot(0));
        items.setStackInSlot(0, ItemStack.EMPTY);
    }

    /** Guarda y manda el estado al cliente (cantidad, factor, disparo) para el renderizado de T91. */
    private void changed() {
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    // --- Guardado y sincronización ---

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.put("Tank", tank.writeToNBT(registries, new CompoundTag()));
        energy.save(tag, "Energy", registries);
        tag.putInt("Firing", firingTicks);
        if (firingCategory != null) {
            tag.putString("FiringCategory", firingCategory.toString());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items.deserializeNBT(registries, tag.getCompound("Items"));
        tank.readFromNBT(registries, tag.getCompound("Tank"));
        energy.load(tag, "Energy", registries);
        firingTicks = tag.getInt("Firing");
        firingCategory = tag.contains("FiringCategory") ? ResourceLocation.tryParse(tag.getString("FiringCategory"))
                : null;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // --- Menú ---

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.railgunreborn.category_reactor");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new CategoryReactorMenu(containerId, inventory, this, player);
    }

    /** Solo recibe, y como mucho {@code reactorChargeRate()} IF por tick sumando todas las llamadas y caras. */
    private final class ChargeHandler implements IEnergyStorage {
        @Override
        public int receiveEnergy(int toReceive, boolean simulate) {
            long now = level == null ? 0 : level.getGameTime();
            if (now != chargeTick) {
                chargeTick = now;
                chargedThisTick = 0;
            }
            int allowed = Math.max(0, Math.min(toReceive, RailgunConfig.reactorChargeRate() - chargedThisTick));
            int accepted = energy.addEnergy(allowed, simulate);
            if (!simulate) {
                chargedThisTick += accepted;
            }
            return accepted;
        }

        @Override
        public int extractEnergy(int toExtract, boolean simulate) {
            return 0;
        }

        @Override
        public int getEnergyStored() {
            return energy.getEnergyStored();
        }

        @Override
        public int getMaxEnergyStored() {
            return energy.getMaxEnergyStored();
        }

        @Override
        public boolean canExtract() {
            return false;
        }

        @Override
        public boolean canReceive() {
            return true;
        }
    }

    /** Llenar sí, vaciar nunca: el líquido solo se gasta al activarlo. */
    private record FillOnlyFluidHandler(FluidTank tank) implements IFluidHandler {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int index) {
            return tank.getFluidInTank(index);
        }

        @Override
        public int getTankCapacity(int index) {
            return tank.getTankCapacity(index);
        }

        @Override
        public boolean isFluidValid(int index, FluidStack stack) {
            return tank.isFluidValid(index, stack);
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            return tank.fill(resource, action);
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            return FluidStack.EMPTY;
        }
    }
}
