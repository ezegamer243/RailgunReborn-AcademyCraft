package com.railgunreborn.reactor.client;

import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.vecmanip.TornadoRenderType;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorVisuals;
import com.railgunreborn.reactor.CategoryReactorVisuals.Look;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Núcleo del reactor (en el controlador, dentro del tubo de cristal del modelo): columna de líquido de fase cuya
 * altura es lo lleno que está el depósito, teñida según la categoría del factor (decisión del usuario). Además, con
 * factor y a menos de {@link CategoryReactorVisuals#EFFECT_RANGE} bloques: esferas verdes (Meltdowner) o mini
 * torbellinos y esferas de plasma (Vector Manipulation). Al disparar: el líquido late hacia el blanco mientras baja
 * y sale una onda horizontal que se expande (nunca pegada a la cámara).
 */
public final class CategoryReactorRenderer implements BlockEntityRenderer<CategoryReactorBlockEntity> {
    private static final ResourceLocation PHASE_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "block/phase_liquid");
    /** Versión gris de la textura del líquido de fase, para teñirla. */
    private static final ResourceLocation TINTED_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID, "block/category_reactor_liquid");

    // Interior del tubo de cristal del modelo (2..14 en X/Z, aros de 2 px arriba y abajo).
    private static final float MIN_XZ = 2.6f / 16f;
    private static final float MAX_XZ = 13.4f / 16f;
    private static final float BOTTOM = 2f / 16f;
    private static final float MAX_HEIGHT = 12f / 16f;
    private static final float LIQUID_ALPHA = 0.88f;

    private static final int WAVE_TICKS = 25;
    private static final double WAVE_START_RADIUS = 0.6;
    private static final double WAVE_SPEED = 0.12;
    private static final double WAVE_CAMERA_GAP = 1.2;
    private static final int RING_SEGMENTS = 20;

    public CategoryReactorRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(CategoryReactorBlockEntity be, float partialTick, PoseStack poseStack,
            MultiBufferSource buffers, int packedLight, int packedOverlay) {
        if (be.getLevel() == null) {
            return;
        }
        Look look = CategoryReactorVisuals.lookOf(be.getDisplayCategory().orElse(null));
        int firingTicks = be.getFiringTicks();
        float fill = CategoryReactorVisuals.displayedFill(be.getTank().getFluidAmount(),
                CategoryReactorBlockEntity.TANK_CAPACITY, firingTicks, CategoryReactorBlockEntity.FIRING_DURATION);
        float time = be.getLevel().getGameTime() + partialTick;

        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        BlockPos pos = be.getBlockPos();
        Vec3 cam = camera.getPosition().subtract(pos.getX(), pos.getY(), pos.getZ());
        PoseStack.Pose pose = poseStack.last();

        if (fill > 0.001f) {
            int color = look.color();
            if (firingTicks > 0) {
                float firing = firingTicks / (float) CategoryReactorBlockEntity.FIRING_DURATION;
                float pulse = 0.5f + 0.5f * Mth.sin(time * 0.9f);
                color = CategoryReactorVisuals.towardWhite(color, firing * (0.25f + 0.55f * pulse));
            }
            drawLiquid(buffers.getBuffer(CategoryReactorRenderType.LIQUID), pose, look, color, fill, cam);
        }

        if (!CategoryReactorVisuals.inEffectRange(cam.subtract(0.5, 0.5, 0.5).lengthSqr())) {
            return;
        }
        float top = BOTTOM + MAX_HEIGHT * Math.max(fill, 0.25f);
        if (look == Look.MELTDOWNER) {
            drawMeltdownerOrbs(buffers.getBuffer(TornadoRenderType.PLASMA_GLOW), pose, camera, time, top);
        } else if (look == Look.VECMANIP) {
            drawMiniTornadoes(buffers.getBuffer(TornadoRenderType.TORNADO), pose, time, top);
            drawPlasmaSpheres(buffers.getBuffer(TornadoRenderType.PLASMA_GLOW), pose, camera, time, top);
        }
        if (firingTicks > 0) {
            float age = CategoryReactorBlockEntity.FIRING_DURATION - firingTicks + partialTick;
            if (age < WAVE_TICKS) {
                drawShockwave(buffers.getBuffer(TornadoRenderType.TORNADO), pose, look, cam, age);
            }
        }
    }

    // --- Líquido ---

    private static void drawLiquid(VertexConsumer consumer, PoseStack.Pose pose, Look look, int color, float fill,
            Vec3 cam) {
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
                .apply(look == Look.PHASE ? PHASE_TEXTURE : TINTED_TEXTURE);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (int) (LIQUID_ALPHA * 255);
        float y0 = BOTTOM;
        float y1 = BOTTOM + MAX_HEIGHT * fill;
        float u0 = sprite.getU(MIN_XZ);
        float u1 = sprite.getU(MAX_XZ);
        float vTop = sprite.getV(1f - y1);
        float vBottom = sprite.getV(1f - y0);
        Liquid l = new Liquid(consumer, pose, r, g, b, a);

        // Sin culling en el RenderType: solo se dibujan las caras que miran a la cámara (la caja es convexa).
        if (cam.y > y1) {
            float v0 = sprite.getV(MIN_XZ);
            float v1 = sprite.getV(MAX_XZ);
            l.quad(0, 1, 0,
                    MIN_XZ, y1, MIN_XZ, u0, v0,
                    MIN_XZ, y1, MAX_XZ, u0, v1,
                    MAX_XZ, y1, MAX_XZ, u1, v1,
                    MAX_XZ, y1, MIN_XZ, u1, v0);
        }
        if (cam.z < MIN_XZ) {
            l.quad(0, 0, -1,
                    MAX_XZ, y0, MIN_XZ, u1, vBottom,
                    MIN_XZ, y0, MIN_XZ, u0, vBottom,
                    MIN_XZ, y1, MIN_XZ, u0, vTop,
                    MAX_XZ, y1, MIN_XZ, u1, vTop);
        }
        if (cam.z > MAX_XZ) {
            l.quad(0, 0, 1,
                    MIN_XZ, y0, MAX_XZ, u0, vBottom,
                    MAX_XZ, y0, MAX_XZ, u1, vBottom,
                    MAX_XZ, y1, MAX_XZ, u1, vTop,
                    MIN_XZ, y1, MAX_XZ, u0, vTop);
        }
        if (cam.x < MIN_XZ) {
            l.quad(-1, 0, 0,
                    MIN_XZ, y0, MIN_XZ, u0, vBottom,
                    MIN_XZ, y0, MAX_XZ, u1, vBottom,
                    MIN_XZ, y1, MAX_XZ, u1, vTop,
                    MIN_XZ, y1, MIN_XZ, u0, vTop);
        }
        if (cam.x > MAX_XZ) {
            l.quad(1, 0, 0,
                    MAX_XZ, y0, MAX_XZ, u1, vBottom,
                    MAX_XZ, y0, MIN_XZ, u0, vBottom,
                    MAX_XZ, y1, MIN_XZ, u0, vTop,
                    MAX_XZ, y1, MAX_XZ, u1, vTop);
        }
    }

    private record Liquid(VertexConsumer consumer, PoseStack.Pose pose, int r, int g, int b, int a) {
        void quad(float nx, float ny, float nz,
                float x1, float y1, float z1, float u1, float v1,
                float x2, float y2, float z2, float u2, float v2,
                float x3, float y3, float z3, float u3, float v3,
                float x4, float y4, float z4, float u4, float v4) {
            vertex(x1, y1, z1, u1, v1, nx, ny, nz);
            vertex(x2, y2, z2, u2, v2, nx, ny, nz);
            vertex(x3, y3, z3, u3, v3, nx, ny, nz);
            vertex(x4, y4, z4, u4, v4, nx, ny, nz);
        }

        private void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz) {
            // A plena luz: el núcleo brilla aunque el reactor esté a oscuras.
            consumer.addVertex(pose, x, y, z).setColor(r, g, b, a).setUv(u, v)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT)
                    .setNormal(pose, nx, ny, nz);
        }
    }

    // --- Efectos por categoría ---

    /** Dos esferas de electrones verdes que flotan en el líquido. */
    private static void drawMeltdownerOrbs(VertexConsumer consumer, PoseStack.Pose pose, Camera camera, float time,
            float top) {
        for (int i = 0; i < 2; i++) {
            double angle = time * 0.05 + i * Math.PI;
            double y = BOTTOM + (top - BOTTOM) * (0.4 + 0.25 * Math.sin(time * 0.07 + i * 2.1));
            Vec3 at = new Vec3(0.5 + Math.cos(angle) * 0.15, y, 0.5 + Math.sin(angle) * 0.15);
            float size = 0.26f + 0.04f * Mth.sin(time * 0.3f + i);
            billboard(consumer, pose, camera, at, size, 90, 255, 120, 200);
        }
    }

    /** Esferitas de plasma blanco azulado que orbitan dentro del tubo. */
    private static void drawPlasmaSpheres(VertexConsumer consumer, PoseStack.Pose pose, Camera camera, float time,
            float top) {
        for (int i = 0; i < 3; i++) {
            double angle = time * 0.11 + i * (Math.PI * 2 / 3);
            double y = BOTTOM + (top - BOTTOM) * (0.5 + 0.35 * Math.sin(time * 0.09 + i * 1.7));
            Vec3 at = new Vec3(0.5 + Math.cos(angle) * 0.22, y, 0.5 + Math.sin(angle) * 0.22);
            billboard(consumer, pose, camera, at, 0.14f, 200, 225, 255, 230);
        }
    }

    /** Dos torbellinos de anillos que giran y se pasean por el tubo. */
    private static void drawMiniTornadoes(VertexConsumer consumer, PoseStack.Pose pose, float time, float top) {
        int rings = 5;
        for (int t = 0; t < 2; t++) {
            double wander = time * 0.04 + t * Math.PI;
            double cx = 0.5 + Math.cos(wander) * 0.14;
            double cz = 0.5 + Math.sin(wander * 1.3) * 0.14;
            double height = top - BOTTOM;
            for (int i = 0; i < rings; i++) {
                double f = i / (double) rings;
                double y = BOTTOM + height * f;
                double radius = Mth.lerp(f, 0.05, 0.19);
                double spin = time * (0.45 - 0.03 * i) + i * 0.9 + t;
                double sway = Math.sin(time * 0.15 + i * 0.7) * 0.03 * f;
                ring(consumer, pose, new Vec3(cx + sway, y, cz), radius, height / rings * 0.7, spin,
                        0xFFFFFF, (int) (255 * (0.35f + 0.35f * (float) f)), 1.1);
            }
        }
    }

    /** Onda horizontal que sale del núcleo al activarlo; el tramo que pasaría junto a la cámara no se dibuja. */
    private static void drawShockwave(VertexConsumer consumer, PoseStack.Pose pose, Look look, Vec3 cam,
            float age) {
        double radius = WAVE_START_RADIUS + age * WAVE_SPEED;
        Vec3 center = new Vec3(0.5, 0.35, 0.5);
        double horizontal = Math.hypot(cam.x - center.x, cam.z - center.z);
        if (Math.hypot(horizontal - radius, cam.y - center.y) < WAVE_CAMERA_GAP) {
            return;
        }
        int alpha = (int) (200 * (1f - age / WAVE_TICKS));
        ring(consumer, pose, center, radius, 0.3, age * 0.2, effectColor(look), alpha, 1.0);
    }

    /** Color de los efectos de luz: el negro de Teleporter no se vería, así que va en violeta. */
    private static int effectColor(Look look) {
        return switch (look) {
            case TELEPORTER -> 0x9050E0;
            case PHASE -> 0x7FC8FF;
            default -> look.color();
        };
    }

    private static void ring(VertexConsumer consumer, PoseStack.Pose pose, Vec3 c, double radius, double height,
            double spin, int rgb, int alpha, double flare) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        float vOffset = (float) ((spin * 0.05) % 1.0);
        for (int s = 0; s < RING_SEGMENTS; s++) {
            double t0 = spin + Math.PI * 2 * s / RING_SEGMENTS;
            double t1 = spin + Math.PI * 2 * (s + 1) / RING_SEGMENTS;
            double cos0 = Math.cos(t0) * radius;
            double sin0 = Math.sin(t0) * radius;
            double cos1 = Math.cos(t1) * radius;
            double sin1 = Math.sin(t1) * radius;
            float uA = (float) s / RING_SEGMENTS;
            float uB = (float) (s + 1) / RING_SEGMENTS;
            effectVertex(consumer, pose, c.x + cos0, c.y, c.z + sin0, r, g, b, alpha, uA, vOffset);
            effectVertex(consumer, pose, c.x + cos1, c.y, c.z + sin1, r, g, b, alpha, uB, vOffset);
            effectVertex(consumer, pose, c.x + cos1 * flare, c.y + height, c.z + sin1 * flare, r, g, b, alpha, uB,
                    vOffset + 0.5f);
            effectVertex(consumer, pose, c.x + cos0 * flare, c.y + height, c.z + sin0 * flare, r, g, b, alpha, uA,
                    vOffset + 0.5f);
        }
    }

    private static void billboard(VertexConsumer consumer, PoseStack.Pose pose, Camera camera, Vec3 at, float size,
            int r, int g, int b, int alpha) {
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        double h = size * 0.5;
        double rx = -left.x() * h;
        double ry = -left.y() * h;
        double rz = -left.z() * h;
        double ux = up.x() * h;
        double uy = up.y() * h;
        double uz = up.z() * h;
        effectVertex(consumer, pose, at.x + rx - ux, at.y + ry - uy, at.z + rz - uz, r, g, b, alpha, 1f, 1f);
        effectVertex(consumer, pose, at.x + rx + ux, at.y + ry + uy, at.z + rz + uz, r, g, b, alpha, 1f, 0f);
        effectVertex(consumer, pose, at.x - rx + ux, at.y - ry + uy, at.z - rz + uz, r, g, b, alpha, 0f, 0f);
        effectVertex(consumer, pose, at.x - rx - ux, at.y - ry - uy, at.z - rz - uz, r, g, b, alpha, 0f, 1f);
    }

    private static void effectVertex(VertexConsumer consumer, PoseStack.Pose pose, double x, double y, double z,
            int r, int g, int b, int alpha, float u, float v) {
        consumer.addVertex(pose, (float) x, (float) y, (float) z)
                .setColor(r, g, b, Mth.clamp(alpha, 0, 255))
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 1f, 0f);
    }

    /** Cubre el 3x3x3 entero y la onda de activación (que sale hasta ~3.6 bloques del centro). */
    @Override
    public AABB getRenderBoundingBox(CategoryReactorBlockEntity be) {
        return new AABB(be.getBlockPos()).inflate(4.0, 1.0, 4.0);
    }
}
