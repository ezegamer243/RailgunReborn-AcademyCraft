package com.railgunreborn.reactor.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorRegistry;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/**
 * Registro de cliente del reactor (bus del MOD): pantalla, renderizador del núcleo y gancho del tick de cliente
 * para los efectos. Los eventos del bus del juego (temblor de cámara) están en {@link CategoryReactorEffects}.
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class CategoryReactorClient {
    private CategoryReactorClient() {
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(CategoryReactorRegistry.MENU.get(), CategoryReactorScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(CategoryReactorRegistry.BLOCK_ENTITY.get(), CategoryReactorRenderer::new);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        CategoryReactorBlockEntity.clientTickHook = CategoryReactorEffects::tick;
    }
}
