package com.railgunreborn.reactor.client;

import java.util.Map;
import java.util.WeakHashMap;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.client.effect.ArcEffects;
import com.railgunreborn.client.effect.ArcPatterns;
import com.railgunreborn.client.effect.PointArcEffect;
import com.railgunreborn.client.sound.MachineLoopSound;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorRegistry;
import com.railgunreborn.reactor.CategoryReactorSounds;
import com.railgunreborn.reactor.CategoryReactorVisuals;
import com.railgunreborn.reactor.CategoryReactorVisuals.Look;
import com.railgunreborn.registry.ModParticles;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Efectos de cliente del reactor (bus del juego): partículas y rayos según la categoría del factor, zumbido en bucle,
 * ráfaga al activarlo y un temblor de cámara leve (nada que tape la pantalla). El tick lo llama el propio
 * BlockEntity por {@link CategoryReactorBlockEntity#clientTickHook} (lo engancha {@link CategoryReactorClient}).
 */
@EventBusSubscriber(modid = RailgunReborn.MODID, value = Dist.CLIENT)
public final class CategoryReactorEffects {
    /** Grados de giro/cabeceo como mucho, con el reactor al lado y recién activado. */
    private static final float MAX_SHAKE_DEGREES = 0.6f;
    /** Las partículas de la ráfaga solo si se ve el inicio (no al cargar el chunk a mitad). */
    private static final int BURST_WINDOW = 10;

    private static final Map<CategoryReactorBlockEntity, MachineLoopSound> HUMS = new WeakHashMap<>();
    private static final Map<CategoryReactorBlockEntity, Integer> LAST_FIRING = new WeakHashMap<>();

    private static float shakeStrength;
    private static long shakeGameTime = -100L;

    private CategoryReactorEffects() {
    }

    static void tick(CategoryReactorBlockEntity be) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        Level level = be.getLevel();
        if (player == null || level == null || level != mc.level) {
            return;
        }
        BlockPos pos = be.getBlockPos();
        Vec3 center = Vec3.atCenterOf(pos);
        double distSqr = player.distanceToSqr(center);
        int firing = be.getFiringTicks();
        Integer previous = LAST_FIRING.put(be, firing);

        if (!CategoryReactorVisuals.inEffectRange(distSqr)) {
            return;
        }
        Look look = CategoryReactorVisuals.lookOf(be.getDisplayCategory().orElse(null));
        RandomSource random = level.random;
        updateHum(mc, be);

        if (firing > 0) {
            boolean started = previous == null ? firing >= CategoryReactorBlockEntity.FIRING_DURATION - BURST_WINDOW
                    : firing > previous;
            if (started) {
                burst(level, center, look, random);
            }
            firingTick(level, center, look, firing, random);
            float strength = CategoryReactorVisuals.shakeStrength(Math.sqrt(distSqr), firing,
                    CategoryReactorBlockEntity.FIRING_DURATION);
            if (strength > 0f) {
                shakeStrength = shakeGameTime == level.getGameTime() ? Math.max(shakeStrength, strength) : strength;
                shakeGameTime = level.getGameTime();
            }
        }
        if (be.getFactorCategory().isPresent() || firing > 0) {
            idle(level, be, look, random);
        }
    }

    // --- Sonido ---

    /** Zumbido grave mientras hay factor y líquido; se corta solo al quitar uno de los dos o al romperlo. */
    private static void updateHum(Minecraft mc, CategoryReactorBlockEntity be) {
        if (!hums(be)) {
            return;
        }
        MachineLoopSound current = HUMS.get(be);
        if (current != null && mc.getSoundManager().isActive(current)) {
            return;
        }
        MachineLoopSound sound = new MachineLoopSound(CategoryReactorRegistry.SOUND_HUM.get(), be.getBlockPos(),
                CategoryReactorSounds.HUM_VOLUME,
                () -> !be.isRemoved() && hums(be) && be.getLevel() == Minecraft.getInstance().level);
        HUMS.put(be, sound);
        mc.getSoundManager().play(sound);
    }

    private static boolean hums(CategoryReactorBlockEntity be) {
        return be.getFactorCategory().isPresent() && be.getTank().getFluidAmount() > 0;
    }

    // --- Partículas en reposo ---

    private static void idle(Level level, CategoryReactorBlockEntity be, Look look, RandomSource random) {
        BlockPos pos = be.getBlockPos();
        Vec3 center = Vec3.atCenterOf(pos);
        double bottom = pos.getY() + 2 / 16.0;
        double fill = CategoryReactorVisuals.displayedFill(be.getTank().getFluidAmount(),
                CategoryReactorBlockEntity.TANK_CAPACITY, be.getFiringTicks(), CategoryReactorBlockEntity.FIRING_DURATION);
        double top = bottom + 12 / 16.0 * Math.max(fill, 0.25);
        switch (look) {
            case TELEPORTER -> {
                // Como el enderman: motas de portal que se arremolinan hacia el núcleo.
                if (random.nextFloat() < 0.6f) {
                    level.addParticle(ParticleTypes.PORTAL, center.x, Mth.lerp(random.nextDouble(), bottom, top),
                            center.z, (random.nextDouble() - 0.5) * 1.6, (random.nextDouble() - 0.6) * 0.8,
                            (random.nextDouble() - 0.5) * 1.6);
                }
                if (random.nextFloat() < 0.15f) {
                    Vec3 out = aroundWindows(center, random, 1.6);
                    level.addParticle(ParticleTypes.PORTAL, out.x, out.y, out.z, (random.nextDouble() - 0.5),
                            (random.nextDouble() - 0.5), (random.nextDouble() - 0.5));
                }
            }
            case MELTDOWNER -> {
                for (int i = 0; i < 2; i++) {
                    Vec3 at = inColumn(center, random, 0.3, Mth.lerp(random.nextDouble(), bottom, top));
                    level.addParticle(ModParticles.MD.get(), at.x, at.y, at.z, 0, 0.01 + random.nextDouble() * 0.02,
                            0);
                }
                if (random.nextFloat() < 0.12f) {
                    Vec3 out = aroundWindows(center, random, 1.55);
                    Vec3 dir = out.subtract(center).normalize().scale(0.02);
                    level.addParticle(ModParticles.MD.get(), out.x, out.y, out.z, dir.x, 0.01, dir.z);
                }
            }
            case VECMANIP -> {
                // Los torbellinos y esferas los dibuja el renderizador; aquí solo un polvillo blanco que sube.
                if (random.nextFloat() < 0.25f) {
                    Vec3 at = inColumn(center, random, 0.6, top);
                    level.addParticle(ParticleTypes.WHITE_ASH, at.x, at.y, at.z, 0, 0.02, 0);
                }
            }
            case ELECTROMASTER -> {
                // Arcos diminutos dentro del tubo y, de vez en cuando, uno que salta hasta una columna de la esquina.
                if (random.nextInt(8) == 0) {
                    arc(level, inColumn(center, random, 0.5, bottom + 0.05), inColumn(center, random, 0.5, top),
                            4 + random.nextInt(4));
                }
                if (random.nextInt(50) == 0) {
                    arc(level, center, corner(center, random), 5 + random.nextInt(4));
                }
                if (random.nextFloat() < 0.1f) {
                    Vec3 at = inColumn(center, random, 0.5, top);
                    level.addParticle(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 0, 0.02, 0);
                }
            }
            case PHASE -> {
            }
        }
    }

    // --- Activación ---

    /** Ráfaga al empezar a disparar: chispas de luz hacia fuera y las partículas de la categoría. */
    private static void burst(Level level, Vec3 center, Look look, RandomSource random) {
        for (int i = 0; i < 24; i++) {
            Vec3 dir = randomDir(random).scale(0.15 + random.nextDouble() * 0.15);
            level.addParticle(ParticleTypes.END_ROD, center.x, center.y, center.z, dir.x, dir.y * 0.5 + 0.05, dir.z);
        }
        ParticleOptions particle = switch (look) {
            case TELEPORTER -> ParticleTypes.REVERSE_PORTAL;
            case MELTDOWNER -> ModParticles.MD.get();
            case VECMANIP -> ParticleTypes.CLOUD;
            case ELECTROMASTER -> ParticleTypes.ELECTRIC_SPARK;
            case PHASE -> ParticleTypes.END_ROD;
        };
        for (int i = 0; i < 50; i++) {
            Vec3 dir = randomDir(random).scale(0.1 + random.nextDouble() * 0.25);
            level.addParticle(particle, center.x, center.y, center.z, dir.x, dir.y * 0.4, dir.z);
        }
        if (look == Look.ELECTROMASTER) {
            for (int i = 0; i < 4; i++) {
                arc(level, center, corner(center, random), 8 + random.nextInt(6));
            }
        }
    }

    /** Mientras dispara: chorro de luz que sale por la tapa, y más rayos en Electromaster. */
    private static void firingTick(Level level, Vec3 center, Look look, int firing, RandomSource random) {
        double capTop = center.y + 1.6;
        for (int i = 0; i < 2; i++) {
            level.addParticle(ParticleTypes.END_ROD, center.x + (random.nextDouble() - 0.5) * 0.5, capTop,
                    center.z + (random.nextDouble() - 0.5) * 0.5, 0, 0.1 + random.nextDouble() * 0.1, 0);
        }
        switch (look) {
            case TELEPORTER -> level.addParticle(ParticleTypes.REVERSE_PORTAL, center.x, capTop, center.z,
                    (random.nextDouble() - 0.5) * 0.2, 0.15, (random.nextDouble() - 0.5) * 0.2);
            case MELTDOWNER -> level.addParticle(ModParticles.MD.get(), center.x, capTop, center.z,
                    (random.nextDouble() - 0.5) * 0.1, 0.12, (random.nextDouble() - 0.5) * 0.1);
            case VECMANIP -> level.addParticle(ParticleTypes.CLOUD, center.x, capTop, center.z,
                    (random.nextDouble() - 0.5) * 0.1, 0.12, (random.nextDouble() - 0.5) * 0.1);
            case ELECTROMASTER -> {
                if (firing % 5 == 0) {
                    arc(level, center, corner(center, random), 5 + random.nextInt(4));
                }
            }
            case PHASE -> {
            }
        }
    }

    // --- Utilidades ---

    private static void arc(Level level, Vec3 from, Vec3 to, int life) {
        double length = from.distanceTo(to);
        // Los patrones "thin" miden 1.5-2: se encogen para que el arco entero quepa en la distancia.
        ArcEffects.spawn(new PointArcEffect(level, ArcPatterns.surroundThin(), from, to)
                .scale(Math.min(1.0, length / 1.5)).life(life));
    }

    /** Punto al azar dentro del tubo (cuadrado de lado {@code width} centrado) a la altura {@code y}. */
    private static Vec3 inColumn(Vec3 center, RandomSource random, double width, double y) {
        return new Vec3(center.x + (random.nextDouble() - 0.5) * width, y,
                center.z + (random.nextDouble() - 0.5) * width);
    }

    /** Un punto delante de una de las cuatro ventanas, por fuera. */
    private static Vec3 aroundWindows(Vec3 center, RandomSource random, double distance) {
        int side = random.nextInt(4);
        double dx = side == 0 ? 1 : side == 1 ? -1 : 0;
        double dz = side == 2 ? 1 : side == 3 ? -1 : 0;
        double along = (random.nextDouble() - 0.5) * 0.8;
        return new Vec3(center.x + dx * distance + dz * along, center.y + (random.nextDouble() - 0.5) * 0.8,
                center.z + dz * distance + dx * along);
    }

    /** La cara interior de una de las cuatro columnas de las esquinas (se ve el arco por la ventana). */
    private static Vec3 corner(Vec3 center, RandomSource random) {
        double sx = random.nextBoolean() ? 1 : -1;
        double sz = random.nextBoolean() ? 1 : -1;
        return new Vec3(center.x + sx * 0.55, center.y + (random.nextDouble() - 0.5) * 0.8, center.z + sz * 0.55);
    }

    private static Vec3 randomDir(RandomSource random) {
        double yaw = random.nextDouble() * Math.PI * 2;
        double y = random.nextDouble() * 2 - 1;
        double h = Math.sqrt(1 - y * y);
        return new Vec3(Math.cos(yaw) * h, y, Math.sin(yaw) * h);
    }

    // --- Temblor de cámara ---

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.getGameTime() - shakeGameTime > 1 || shakeStrength <= 0f) {
            return;
        }
        // Respeta la opción de accesibilidad "efectos de distorsión" del jugador.
        float scale = shakeStrength * MAX_SHAKE_DEGREES * mc.options.screenEffectScale().get().floatValue();
        if (scale <= 0f) {
            return;
        }
        double t = mc.level.getGameTime() + event.getPartialTick();
        event.setRoll(event.getRoll() + (float) Math.sin(t * 1.9) * scale);
        event.setPitch(event.getPitch() + (float) Math.sin(t * 2.7 + 1.3) * scale * 0.6f);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        HUMS.clear();
        LAST_FIRING.clear();
        shakeStrength = 0f;
        shakeGameTime = -100L;
    }
}
