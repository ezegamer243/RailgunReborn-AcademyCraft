package com.railgunreborn.reactor.client;

import com.railgunreborn.RailgunReborn;
import com.railgunreborn.block.TechUiLayout;
import com.railgunreborn.client.screen.AcStyle;
import com.railgunreborn.energy.EnergyFormat;
import com.railgunreborn.reactor.CategoryReactorBlockEntity;
import com.railgunreborn.reactor.CategoryReactorBlockEntity.Status;
import com.railgunreborn.reactor.CategoryReactorMenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla del reactor (sin arte propio en el original): fondo y marcos en el estilo de {@link AcStyle}, barra del
 * depósito con mB, ranura del factor, botón "Activar" y una línea de estado. El botón solo se habilita cuando el
 * servidor dice READY.
 */
public class CategoryReactorScreen extends AbstractContainerScreen<CategoryReactorMenu> {
    private static final int TANK_X = 8;
    private static final int TANK_Y = 16;
    private static final int TANK_W = 160;
    private static final int TANK_H = 11;
    private static final int ENERGY_Y = 31;
    private static final int ENERGY_H = 11;
    private static final int BUTTON_W = 70;
    private static final int BUTTON_H = 18;
    private static final int STATUS_Y = 86;

    private static final int TANK_BG = 0x50000000;
    /** Mismo fondo que las máquinas TechUI (negro translúcido con las barras de arriba y abajo). */
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(RailgunReborn.MODID,
            "textures/gui/imag_fusor/background.png");

    private Button activate;

    public CategoryReactorScreen(CategoryReactorMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 182;
        inventoryLabelY = CategoryReactorMenu.INV_Y - 11;
    }

    @Override
    protected void init() {
        super.init();
        activate = addRenderableWidget(Button.builder(Component.translatable("gui.railgunreborn.category_reactor.activate"),
                b -> {
                    if (minecraft != null && minecraft.gameMode != null) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId,
                                CategoryReactorMenu.BUTTON_ACTIVATE);
                    }
                }).bounds(leftPos + CategoryReactorMenu.FACTOR_X + 24, topPos + CategoryReactorMenu.FACTOR_Y - 1,
                        BUTTON_W, BUTTON_H).build());
        activate.active = false;
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        activate.active = menu.getStatus() == Status.READY;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        int rx = mouseX - leftPos;
        int ry = mouseY - topPos;
        if (rx >= TANK_X && rx < TANK_X + TANK_W && ry >= TANK_Y && ry < TANK_Y + TANK_H) {
            graphics.renderTooltip(font, Component.translatable("gui.railgunreborn.category_reactor.tank",
                    menu.getTankAmount(), CategoryReactorBlockEntity.TANK_CAPACITY), mouseX, mouseY);
        }
        if (rx >= TANK_X && rx < TANK_X + TANK_W && ry >= ENERGY_Y && ry < ENERGY_Y + ENERGY_H) {
            int stored = menu.getEnergyAmount();
            int percent = Math.round(100f * stored / CategoryReactorBlockEntity.ENERGY_CAPACITY);
            graphics.renderComponentTooltip(font, java.util.List.of(
                    Component.literal(EnergyFormat.fraction(stored, CategoryReactorBlockEntity.ENERGY_CAPACITY)),
                    Component.translatable("gui.railgunreborn.category_reactor.energy_percent", percent)),
                    mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        AcStyle.begin();
        AcStyle.panel(graphics, BACKGROUND, x, y, imageWidth, imageHeight);

        graphics.fill(x + TANK_X, y + TANK_Y, x + TANK_X + TANK_W, y + TANK_Y + TANK_H, TANK_BG);
        int amount = menu.getTankAmount();
        int fill = Math.round(TANK_W * Math.min(1f, amount / (float) CategoryReactorBlockEntity.TANK_CAPACITY));
        if (fill > 0) {
            graphics.fill(x + TANK_X, y + TANK_Y, x + TANK_X + fill, y + TANK_Y + TANK_H, TechUiLayout.TANK_FILL);
        }
        AcStyle.frame(graphics, x + TANK_X - 1, y + TANK_Y - 1, TANK_W + 2, TANK_H + 2);
        Component label = Component.literal(amount + " / " + CategoryReactorBlockEntity.TANK_CAPACITY + " mB");
        graphics.drawString(font, label, x + TANK_X + (TANK_W - font.width(label)) / 2, y + TANK_Y + 2,
                TechUiLayout.TEXT, false);

        graphics.fill(x + TANK_X, y + ENERGY_Y, x + TANK_X + TANK_W, y + ENERGY_Y + ENERGY_H, TANK_BG);
        int energyFill = Math.round(TANK_W
                * Math.min(1f, menu.getEnergyAmount() / (float) CategoryReactorBlockEntity.ENERGY_CAPACITY));
        if (energyFill > 0) {
            graphics.fill(x + TANK_X, y + ENERGY_Y, x + TANK_X + energyFill, y + ENERGY_Y + ENERGY_H,
                    TechUiLayout.ENERGY_FILL);
        }
        AcStyle.frame(graphics, x + TANK_X - 1, y + ENERGY_Y - 1, TANK_W + 2, ENERGY_H + 2);
        Component energyLabel = Component.literal(EnergyFormat.fraction(menu.getEnergyAmount(),
                CategoryReactorBlockEntity.ENERGY_CAPACITY));
        graphics.drawString(font, energyLabel, x + TANK_X + (TANK_W - font.width(energyLabel)) / 2, y + ENERGY_Y + 2,
                TechUiLayout.TEXT, false);

        AcStyle.slotGrid(graphics, x + CategoryReactorMenu.FACTOR_X, y + CategoryReactorMenu.FACTOR_Y, 1, 1);
        AcStyle.slotGrid(graphics, x + 8, y + CategoryReactorMenu.INV_Y, 9, 3);
        AcStyle.slotGrid(graphics, x + 8, y + CategoryReactorMenu.INV_Y + 58, 9, 1);
        AcStyle.end();
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, titleLabelX, titleLabelY, 0xFFE6F6FF, false);
        graphics.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, 0xFFB8D4E0, false);
        Component factor = Component.translatable("gui.railgunreborn.category_reactor.factor");
        graphics.drawString(font, factor, CategoryReactorMenu.FACTOR_X - 6 - font.width(factor),
                CategoryReactorMenu.FACTOR_Y + 4, 0xFFB8D4E0, false);

        Status status = menu.getStatus();
        int color = switch (status) {
            case READY -> 0xFF7FFF7F;
            case FIRING -> 0xFFFFD27F;
            default -> 0xFFFF8080;
        };
        Component text = Component.translatable(status.translationKey());
        graphics.drawString(font, text, (imageWidth - font.width(text)) / 2, STATUS_Y - 18, color, false);
        if (status == Status.READY) {
            Component warning = Component.translatable("gui.railgunreborn.category_reactor.warning");
            graphics.drawString(font, warning, (imageWidth - font.width(warning)) / 2, STATUS_Y - 8, 0xFFFFB060,
                    false);
        }
    }
}
