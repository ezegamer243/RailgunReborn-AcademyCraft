package com.railgunreborn.reactor.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.inventory.InventoryMenu;

/**
 * Líquido del reactor: como {@code entityTranslucent} sobre el atlas de bloques pero sin escribir profundidad, así
 * las partículas y rayos que se dibujan después se ven "dentro" del líquido en vez de quedar tapados por su
 * superficie. Sin culling: el renderizador elige él mismo las caras que miran a la cámara. Hereda de
 * {@link RenderType} solo para acceder a los "shards" protegidos; nunca se instancia.
 */
final class CategoryReactorRenderType extends RenderType {
    static final RenderType LIQUID = create(
            "railgunreborn_reactor_liquid",
            DefaultVertexFormat.NEW_ENTITY,
            VertexFormat.Mode.QUADS,
            256,
            false,
            true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_SHADER)
                    .setTextureState(new TextureStateShard(InventoryMenu.BLOCK_ATLAS, false, false))
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setLightmapState(LIGHTMAP)
                    .setOverlayState(OVERLAY)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));

    private CategoryReactorRenderType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
            boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
    }
}
