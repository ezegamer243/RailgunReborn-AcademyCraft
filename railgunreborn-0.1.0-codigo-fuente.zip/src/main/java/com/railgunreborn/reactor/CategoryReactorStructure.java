package com.railgunreborn.reactor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.neoforged.neoforge.common.util.BlockSnapshot;
import net.neoforged.neoforge.event.EventHooks;

/**
 * Geometría del reactor: un cubo 3x3x3 cuyo centro es el controlador. La "base" es el centro de la capa de abajo
 * (donde se apunta al colocarlo); el controlador queda justo encima.
 */
public final class CategoryReactorStructure {
    private CategoryReactorStructure() {
    }

    public static BlockPos controllerFromBase(BlockPos base) {
        return base.above();
    }

    /** Las 27 posiciones; el controlador va primero (el evento de colocación múltiple usa la primera). */
    public static List<BlockPos> volume(BlockPos controller) {
        List<BlockPos> list = new ArrayList<>(27);
        list.add(controller);
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx != 0 || dy != 0 || dz != 0) {
                        list.add(controller.offset(dx, dy, dz));
                    }
                }
            }
        }
        return list;
    }

    /** Las caras laterales de la capa del medio son de cristal (se ve el núcleo); el resto, armazón. */
    public static boolean isGlass(int dx, int dy, int dz) {
        return dy == 0 && (dx == 0) != (dz == 0);
    }

    /**
     * Comprueba si se puede construir con la base en {@code base}: todo reemplazable, dentro del mundo, sin entidades
     * estorbando y con permiso de construir en cada posición.
     *
     * @return el motivo del rechazo, o vacío si se puede
     */
    public static Optional<Component> checkPlacement(Level level, BlockPos base, @Nullable Player player,
            ItemStack stack) {
        if (player == null) {
            return Optional.of(Component.translatable("message.railgunreborn.category_reactor.no_player"));
        }
        BlockState partState = CategoryReactorRegistry.PART.get().defaultBlockState();
        CollisionContext collision = CollisionContext.of(player);
        for (BlockPos pos : volume(controllerFromBase(base))) {
            if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
                return Optional.of(Component.translatable("message.railgunreborn.category_reactor.outside_world"));
            }
            if (!level.getBlockState(pos).canBeReplaced()) {
                return Optional.of(Component.translatable("message.railgunreborn.category_reactor.no_space"));
            }
            if (!player.mayUseItemAt(pos, Direction.UP, stack)) {
                return Optional.of(Component.translatable("message.railgunreborn.category_reactor.no_permission"));
            }
            if (!level.isUnobstructed(partState, pos, collision)) {
                return Optional.of(Component.translatable("message.railgunreborn.category_reactor.obstructed"));
            }
        }
        return Optional.empty();
    }

    /**
     * Coloca las 27 piezas (ya validado con {@link #checkPlacement}) y lanza el evento de colocación de NeoForge para
     * que los mods de protección puedan cancelarlo; si lo cancelan, deja todo como estaba.
     *
     * @return false si un mod de protección lo canceló
     */
    public static boolean build(Level level, BlockPos base, Player player) {
        BlockPos controller = controllerFromBase(base);
        List<BlockPos> positions = volume(controller);
        List<BlockSnapshot> snapshots = new ArrayList<>(positions.size());
        for (BlockPos pos : positions) {
            snapshots.add(BlockSnapshot.create(level.dimension(), level, pos));
        }
        level.setBlock(controller, CategoryReactorRegistry.CONTROLLER.get().defaultBlockState(), Block.UPDATE_ALL);
        for (BlockPos pos : positions) {
            if (!pos.equals(controller)) {
                level.setBlock(pos, CategoryReactorPartBlock.stateFor(pos.getX() - controller.getX(),
                        pos.getY() - controller.getY(), pos.getZ() - controller.getZ()), Block.UPDATE_ALL);
            }
        }
        if (EventHooks.onMultiBlockPlace(player, snapshots, Direction.UP)) {
            // El controlador primero: al quitarlo se llevan las partes sin soltar el ítem (ver onRemove).
            for (BlockSnapshot snapshot : snapshots) {
                snapshot.restore(Block.UPDATE_ALL);
            }
            return false;
        }
        return true;
    }
}
