package com.railgunreborn.terminal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.world.entity.player.Player;

/** Dato persistente por jugador: si instaló el Terminal de datos ({@code terminal.md} sección 5). Inmutable. */
public record TerminalData(boolean installed) {
    // optionalFieldOf: los mundos viejos no tienen el campo y quedan como "no instalado".
    public static final Codec<TerminalData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.BOOL.optionalFieldOf("installed", false).forGetter(TerminalData::installed)
    ).apply(inst, TerminalData::new));

    public TerminalData() {
        this(false);
    }

    public static TerminalData get(Player player) {
        return player.getData(ModAttachments.TERMINAL_DATA);
    }
}
