package com.railgunreborn.terminal;

import com.railgunreborn.network.DataSync;
import com.railgunreborn.registry.ModAttachments;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Acceso al Terminal de datos ({@code docs/spec/terminal.md}). Común: lo puede consultar cliente o servidor.
 *
 * <p>Regla: los jugadores en creativo siempre tienen acceso (para probar); en supervivencia hace falta haber usado el
 * ítem {@code terminal_installer} (o el comando {@code /railgunreborn terminal install}).
 */
public final class TerminalAccess {
    private TerminalAccess() {
    }

    public static boolean isInstalled(Player player) {
        return player.isCreative() || TerminalData.get(player).installed();
    }

    /** Si el jugador tiene el dato de instalación (sin contar el acceso por creativo). */
    public static boolean hasInstalledFlag(Player player) {
        return TerminalData.get(player).installed();
    }

    /** Marca el Terminal como instalado/desinstalado y avisa al cliente. Solo servidor. */
    public static void setInstalled(ServerPlayer player, boolean installed) {
        player.setData(ModAttachments.TERMINAL_DATA, new TerminalData(installed));
        DataSync.sendTerminal(player);
    }
}
