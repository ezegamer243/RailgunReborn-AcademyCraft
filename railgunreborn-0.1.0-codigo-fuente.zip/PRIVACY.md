# Privacidad

**RailgunReborn no envía ningún dato a nadie.** No hay analíticas, ni telemetría, ni buscador de actualizaciones,
ni descargas. La única comunicación es la normal de Minecraft entre tu cliente y el servidor en el que juegas.

## Qué tenía el original y NO se porta
Encontrado al revisar `AcademyCraft-1.1.3.jar`:

| Original | Qué hacía | Estado |
|---|---|---|
| `cn/academy/analytic/*` (`AnalysisTask`, `AnalyticDataListener`, `AnalyticInfoSender`, `DelaySender`, eventos) | Enviaba datos de juego (subidas de nivel, uso de habilidades) a `ac.li-dev.cn/analytics` | **Eliminado** |
| `AnalyticDataListener` | Consultaba `myip.ipip.net` para obtener tu **IP pública** | **Eliminado** |
| `cn/academy/terminal/DonatorList` | Descargaba la lista de donadores desde `ac.li-dev.cn/donators` | **Eliminado** |
| Opción de config de analíticas y eventos de login asociados | Activaba lo anterior | **Eliminado** |
| URL `ac.li-dev.cn` (servidor ya cerrado) | Web del mod | Solo aparece como texto de crédito, sin conexión |

## Regla para el código
Prohibido en todo el proyecto (el build falla si aparece):
`java.net.URL`, `URLConnection`, `HttpURLConnection`, `java.net.http.*`, `Socket`, `ServerSocket`, `DatagramSocket`,
cualquier cliente HTTP de terceros, y literales `http://` / `https://` en código Java
(excepto en `CREDITS.md` / `neoforge.mods.toml` como texto).

Si alguna vez una función necesita leer un archivo local (por ejemplo música propia), se usa `java.nio.file`, nunca URLs.

Esta regla se verifica con `.\gradlew.bat checkPrivacy` (definida en `gradle/privacy.gradle`), que corre sola en cada `build` (es parte de `check`). Si encuentra algo, el build falla y lista archivo:línea y el patrón.
