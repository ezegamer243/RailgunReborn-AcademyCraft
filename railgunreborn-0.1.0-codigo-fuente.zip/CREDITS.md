# Créditos

RailgunReborn-AcademyCraft es un port **no oficial** y una reescritura de **AcademyCraft**, para NeoForge 1.21.1.

- **AcademyCraft** y **LambdaLib2**: creados por **LambdaInnovation**. Repositorio original: https://github.com/LambdaInnovation/AcademyCraft
- El mod original es **GPLv3** con la condición adicional de **no vender** el mod en ninguna forma. Este port mantiene esa condición: está prohibido vender este mod o cobrar por su distribución.
- Este port también se distribuye bajo **GPLv3** (ver `LICENSE`).
- Proyecto base: MDK oficial de NeoForge con ModDevGradle: https://github.com/neoforged/MDK

Port por Zeryu.
